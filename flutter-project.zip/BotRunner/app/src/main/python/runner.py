"""Telegram bot runner (Chaquopy ke andar chalta hai).

Java side se call hota hai:
    runner.run(token, path, files_dir, promo_enabled, promo_text, promo_url, promo_every)
  - path: user ki .py file ya .zip project
  - token: env variables me set hota hai (BOT_TOKEN, TOKEN, TELEGRAM_BOT_TOKEN, ...)
  - saara output files_dir/bot.log me jata hai (token <TOKEN> se chhupa diya jata hai)
  - promo: bot ke text messages ke end me channel promo jodta hai (python-telegram-bot / pyTelegramBotAPI)
"""
import asyncio
import os
import runpy
import shutil
import signal
import sys
import threading
import traceback
import zipfile

ENTRY_NAMES = ("main.py", "bot.py", "app.py", "run.py", "index.py")
TOKEN_ENV_NAMES = (
    "BOT_TOKEN", "TOKEN", "TELEGRAM_BOT_TOKEN", "TELEGRAM_TOKEN",
    "API_TOKEN", "BOT_API_TOKEN", "TG_BOT_TOKEN",
)


class _Log:
    """Log file wrapper: token ko <TOKEN> se badal deta hai, taaki screenshot/log share karne par leak na ho."""
    encoding = "utf-8"
    errors = "replace"

    def __init__(self, f, secrets):
        self._f = f
        self._secrets = [s for s in secrets if s]

    def write(self, s):
        if not isinstance(s, str):
            s = str(s)
        for sec in self._secrets:
            s = s.replace(sec, "<TOKEN>")
        return self._f.write(s)

    def flush(self):
        self._f.flush()

    def isatty(self):
        return False

    def writable(self):
        return True


def _patch_signals():
    """Signal handlers kuch libraries ke liye fail ho sakte hain. Unhe no-op karo."""
    real_signal = signal.signal

    def safe_signal(signum, handler):
        try:
            return real_signal(signum, handler)
        except ValueError:
            return None

    signal.signal = safe_signal

    try:
        from asyncio import unix_events

        def no_signal_handler(self, *args, **kwargs):
            # PTB isko NotImplementedError par fallback me handle karta hai
            raise NotImplementedError

        unix_events._UnixSelectorEventLoop.add_signal_handler = no_signal_handler
    except Exception:
        pass


def _safe_extract(zip_path, dest):
    if os.path.isdir(dest):
        shutil.rmtree(dest)
    os.makedirs(dest)
    root = os.path.realpath(dest)
    with zipfile.ZipFile(zip_path) as z:
        for member in z.infolist():
            target = os.path.realpath(os.path.join(dest, member.filename))
            if not (target == root or target.startswith(root + os.sep)):
                raise ValueError("Zip me galat path mila: " + member.filename)
        z.extractall(dest)


def _find_entry(folder):
    # pehle root, phir ek level andar (zip me aksar ek folder hota hai)
    candidates = [folder]
    for name in sorted(os.listdir(folder)):
        p = os.path.join(folder, name)
        if os.path.isdir(p) and not name.startswith((".", "__")):
            candidates.append(p)
    for d in candidates:
        for name in ENTRY_NAMES:
            p = os.path.join(d, name)
            if os.path.isfile(p):
                return p
    # kuch na mile aur sirf ek .py ho to wahi
    for d in candidates:
        pys = [f for f in os.listdir(d) if f.endswith(".py")]
        if len(pys) == 1:
            return os.path.join(d, pys[0])
    raise FileNotFoundError(
        "Zip me main.py / bot.py / app.py nahi mila. Entry file ka naam inme se rakho: "
        + ", ".join(ENTRY_NAMES)
    )


def _install_promo(footer, every):
    """Bot ke plain-text messages (send_message / reply_text) ke end me footer jodta hai.
    parse_mode (HTML/Markdown) wale messages ko chhedta nahi, taaki formatting na toote."""
    state = {"n": 0}

    def maybe(text):
        if not isinstance(text, str) or not text:
            return text
        state["n"] += 1
        if state["n"] % every != 0:
            return text
        if len(text) + len(footer) > 4000:
            return text
        return text + footer

    installed = []

    try:
        import telegram

        orig_ptb = telegram.Bot.send_message

        async def ptb_send_message(self, chat_id, text, *args, **kwargs):
            pm = kwargs.get("parse_mode")
            pm = getattr(pm, "value", pm)  # DefaultValue(None) -> None
            defaults = getattr(self, "defaults", None)
            if pm is None and not getattr(defaults, "parse_mode", None):
                text = maybe(text)
            return await orig_ptb(self, chat_id, text, *args, **kwargs)

        telegram.Bot.send_message = ptb_send_message
        installed.append("python-telegram-bot")
    except Exception:
        pass

    try:
        import telebot

        orig_tb = telebot.TeleBot.send_message

        def tb_send_message(self, chat_id, text, *args, **kwargs):
            pm = args[0] if args else kwargs.get("parse_mode")
            if pm is None and getattr(self, "parse_mode", None) is None:
                text = maybe(text)
            return orig_tb(self, chat_id, text, *args, **kwargs)

        telebot.TeleBot.send_message = tb_send_message
        installed.append("pyTelegramBotAPI")
    except Exception:
        pass

    return installed


def run(token, path, files_dir, promo_enabled=False, promo_text="", promo_url="", promo_every=1):
    raw = open(os.path.join(files_dir, "bot.log"), "a", buffering=1, encoding="utf-8")
    log = _Log(raw, [token])
    sys.stdout = log
    sys.stderr = log
    os.environ["PYTHONUNBUFFERED"] = "1"

    try:
        print("[runner] start, thread:", threading.current_thread().name)
        _patch_signals()
        asyncio.set_event_loop(asyncio.new_event_loop())

        for name in TOKEN_ENV_NAMES:
            os.environ[name] = token

        promo_text = (promo_text or "").strip()
        promo_url = (promo_url or "").strip()
        os.environ["PROMO_TEXT"] = promo_text
        os.environ["PROMO_URL"] = promo_url

        if path.lower().endswith(".zip"):
            project_dir = os.path.join(files_dir, "bot_project")
            _safe_extract(path, project_dir)
            entry = _find_entry(project_dir)
        else:
            entry = path

        workdir = os.path.dirname(entry)
        os.chdir(workdir)
        sys.path.insert(0, workdir)
        print("[runner] running:", entry)
        print("[runner] token env: BOT_TOKEN / TOKEN / TELEGRAM_BOT_TOKEN set hai")

        footer = "\n\n" + " ".join(x for x in (promo_text, promo_url) if x)
        if promo_enabled and footer.strip():
            every = max(1, int(promo_every or 1))
            libs = _install_promo(footer, every)
            print("[runner] promo ON (har %d message), libs: %s" % (every, ", ".join(libs) or "koi nahi mili"))
        print()

        runpy.run_path(entry, run_name="__main__")
        print("\n[runner] script khatam ho gayi (bot band).")
    except SystemExit as e:
        print("\n[runner] script ne exit kiya:", e)
    except BaseException:
        print("\n[runner] ERROR:")
        traceback.print_exc()
    finally:
        raw.flush()
