package com.botrunner.app;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private static final int REQ_PICK = 101;
    private static final Pattern TOKEN_RE = Pattern.compile("^\\d{5,}:[A-Za-z0-9_-]{20,}$");

    private EditText tokenInput;
    private TextView fileText, statusText, logView;
    private ScrollView logScroll;
    private Button pickBtn, startBtn, stopBtn;
    private SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final Runnable poll = new Runnable() {
        @Override
        public void run() {
            refreshStatus();
            refreshLog();
            handler.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("cfg", MODE_PRIVATE);

        tokenInput = findViewById(R.id.tokenInput);
        fileText = findViewById(R.id.fileText);
        statusText = findViewById(R.id.statusText);
        logView = findViewById(R.id.logView);
        logScroll = findViewById(R.id.logScroll);
        pickBtn = findViewById(R.id.pickBtn);
        startBtn = findViewById(R.id.startBtn);
        stopBtn = findViewById(R.id.stopBtn);

        tokenInput.setText(prefs.getString("token", ""));
        String saved = prefs.getString("path", null);
        if (saved != null && new File(saved).exists()) {
            fileText.setText("File: " + new File(saved).getName());
        }

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }

        pickBtn.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            startActivityForResult(i, REQ_PICK);
        });

        startBtn.setOnClickListener(v -> startBot());
        stopBtn.setOnClickListener(v -> {
            stopService(new Intent(this, BotService.class));
            Toast.makeText(this, "Bot band kar diya", Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(poll);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(poll);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_PICK || res != RESULT_OK || data == null || data.getData() == null) return;

        Uri uri = data.getData();
        String name = queryName(uri);
        if (name == null || name.isEmpty()) name = "bot.py";
        name = new File(name).getName(); // path traversal se bachao

        File dir = new File(getFilesDir(), "uploads");
        dir.mkdirs();
        File out = new File(dir, name);

        try (InputStream in = getContentResolver().openInputStream(uri);
             OutputStream os = new FileOutputStream(out)) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
        } catch (Exception e) {
            Toast.makeText(this, "File copy fail: " + e.getMessage(), Toast.LENGTH_LONG).show();
            return;
        }

        prefs.edit().putString("path", out.getAbsolutePath()).apply();
        fileText.setText("File: " + name);
    }

    private String queryName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) return c.getString(idx);
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private void startBot() {
        String token = BotControl.cleanToken(tokenInput.getText().toString());
        String path = prefs.getString("path", null);

        if (!TOKEN_RE.matcher(token).matches()) {
            Toast.makeText(this, "Bot token galat lag raha hai (123456:ABC... format)", Toast.LENGTH_LONG).show();
            return;
        }
        if (path == null || !new File(path).exists()) {
            Toast.makeText(this, "Pehle bot ki .py ya .zip file chuno", Toast.LENGTH_LONG).show();
            return;
        }
        if (isServiceRunning()) {
            Toast.makeText(this, "Bot pehle se chal raha hai", Toast.LENGTH_SHORT).show();
            return;
        }

        prefs.edit().putString("token", token).apply();

        String err = BotControl.start(this);
        if (err != null) {
            Toast.makeText(this, err, Toast.LENGTH_LONG).show();
        }
    }

    @SuppressWarnings("deprecation")
    private boolean isServiceRunning() {
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo s : am.getRunningServices(Integer.MAX_VALUE)) {
            if (BotService.class.getName().equals(s.service.getClassName())) return true;
        }
        return false;
    }

    private void refreshStatus() {
        boolean running = isServiceRunning();
        statusText.setText(running ? "Status: CHAL RAHA HAI" : "Status: band");
        statusText.setTextColor(running ? 0xFF2E7D32 : 0xFF757575);
        startBtn.setEnabled(!running);
        stopBtn.setEnabled(running);
    }

    private void refreshLog() {
        File f = new File(getFilesDir(), "bot.log");
        if (!f.exists()) return;
        try (RandomAccessFile raf = new RandomAccessFile(f, "r")) {
            long len = raf.length();
            long start = Math.max(0, len - 20000);
            raf.seek(start);
            byte[] b = new byte[(int) (len - start)];
            raf.readFully(b);
            String text = new String(b, StandardCharsets.UTF_8);
            if (!text.contentEquals(logView.getText())) {
                logView.setText(text);
                logScroll.post(() -> logScroll.fullScroll(View.FOCUS_DOWN));
            }
        } catch (Exception ignored) {
        }
    }
}
