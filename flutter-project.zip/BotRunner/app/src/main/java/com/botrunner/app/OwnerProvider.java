package com.botrunner.app;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * Owner app ke liye control API. Manifest me signature permission hai, aur har call me dobara check bhi hota hai.
 * Token kabhi wapas bahar nahi jata (sirf set hota hai).
 */
public class OwnerProvider extends ContentProvider {

    static final String PERM = "com.botrunner.app.permission.OWNER";
    private static final int MAX_SCRIPT_BYTES = 800 * 1024;

    @Override
    public boolean onCreate() {
        return true;
    }

    private void check() {
        Context c = getContext();
        if (c == null || c.checkCallingPermission(PERM) != PackageManager.PERMISSION_GRANTED) {
            throw new SecurityException("Owner permission chahiye");
        }
    }

    private static Bundle ok() {
        Bundle b = new Bundle();
        b.putBoolean("ok", true);
        return b;
    }

    private static Bundle fail(String msg) {
        Bundle b = new Bundle();
        b.putBoolean("ok", false);
        b.putString("error", msg);
        return b;
    }

    @Override
    public Bundle call(String method, String arg, Bundle extras) {
        check();
        Context c = getContext();
        SharedPreferences p = BotControl.prefs(c);
        if (method == null) method = "";
        if (extras == null) extras = new Bundle();

        try {
            switch (method) {
                case "status": {
                    Bundle b = ok();
                    String path = p.getString("path", null);
                    b.putBoolean("running", BotControl.isRunning(c));
                    b.putString("file", path == null ? "" : new File(path).getName());
                    b.putBoolean("token_set", BotControl.isValidToken(p.getString("token", "")));
                    b.putBoolean("promo_enabled", p.getBoolean("promo_enabled", false));
                    b.putString("promo_url", p.getString("promo_url", ""));
                    b.putString("promo_text", p.getString("promo_text", ""));
                    b.putInt("promo_every", p.getInt("promo_every", 1));
                    return b;
                }

                case "stop":
                    BotControl.stop(c);
                    return ok();

                case "set_token": {
                    String t = BotControl.cleanToken(extras.getString("token"));
                    if (!BotControl.isValidToken(t)) {
                        return fail("Token galat lag raha hai (123456:ABC... format)");
                    }
                    p.edit().putString("token", t).commit();
                    return ok();
                }

                case "set_promo": {
                    String url = extras.getString("url", "").trim();
                    if (url.startsWith("@")) {
                        url = "https://t.me/" + url.substring(1);
                    } else if (url.startsWith("t.me/")) {
                        url = "https://" + url;
                    }
                    if (!url.isEmpty() && !url.startsWith("https://") && !url.startsWith("http://")) {
                        return fail("Channel link https://t.me/... jaisa do");
                    }
                    String text = extras.getString("text", "").trim();
                    if (text.length() > 200) text = text.substring(0, 200);
                    int every = Math.max(1, Math.min(1000, extras.getInt("every", 1)));
                    p.edit()
                            .putBoolean("promo_enabled", extras.getBoolean("enabled", false))
                            .putString("promo_url", url)
                            .putString("promo_text", text)
                            .putInt("promo_every", every)
                            .commit();
                    return ok();
                }

                case "use_file": {
                    String name = new File(arg == null ? "" : arg).getName();
                    String lower = name.toLowerCase();
                    File f = new File(new File(c.getFilesDir(), "uploads"), name);
                    if (name.isEmpty() || !(lower.endsWith(".py") || lower.endsWith(".zip")) || !f.isFile()) {
                        return fail("File nahi mili");
                    }
                    p.edit().putString("path", f.getAbsolutePath()).commit();
                    return ok();
                }

                case "get_script_text": {
                    String path = p.getString("path", null);
                    if (path == null || !new File(path).isFile()) return fail("Abhi koi bot file nahi hai");
                    if (path.toLowerCase().endsWith(".zip")) {
                        return fail("Zip project ka code yahan edit nahi hota, nayi file push karo");
                    }
                    File f = new File(path);
                    if (f.length() > MAX_SCRIPT_BYTES) return fail("File bahut badi hai");
                    Bundle b = ok();
                    b.putString("name", f.getName());
                    b.putString("text", new String(readAll(f), StandardCharsets.UTF_8));
                    return b;
                }

                case "put_script_text": {
                    String text = extras.getString("text");
                    if (text == null || text.trim().isEmpty()) return fail("Code khali hai");
                    byte[] data = text.getBytes(StandardCharsets.UTF_8);
                    if (data.length > MAX_SCRIPT_BYTES) return fail("Code bahut bada hai");
                    String path = p.getString("path", null);
                    File dir = new File(c.getFilesDir(), "uploads");
                    dir.mkdirs();
                    File f = (path != null && path.toLowerCase().endsWith(".py"))
                            ? new File(path)
                            : new File(dir, "bot.py");
                    try (FileOutputStream out = new FileOutputStream(f)) {
                        out.write(data);
                    }
                    p.edit().putString("path", f.getAbsolutePath()).commit();
                    return ok();
                }

                case "log": {
                    File f = new File(c.getFilesDir(), "bot.log");
                    Bundle b = ok();
                    b.putString("log", f.exists() ? readTail(f, 20000) : "");
                    return b;
                }

                default:
                    return fail("Unknown command: " + method);
            }
        } catch (Exception e) {
            return fail(e.toString());
        }
    }

    /** Code file upload: content://com.botrunner.app.owner/upload/<naam.py|naam.zip> */
    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        check();
        List<String> seg = uri.getPathSegments();
        if (seg.size() != 2 || !"upload".equals(seg.get(0))) {
            throw new FileNotFoundException("bad uri");
        }
        String name = new File(seg.get(1)).getName();
        String lower = name.toLowerCase();
        if (!(lower.endsWith(".py") || lower.endsWith(".zip"))) {
            throw new FileNotFoundException("sirf .py ya .zip");
        }
        File dir = new File(getContext().getFilesDir(), "uploads");
        dir.mkdirs();
        return ParcelFileDescriptor.open(new File(dir, name), ParcelFileDescriptor.parseMode(mode));
    }

    private static byte[] readAll(File f) throws IOException {
        byte[] buf = new byte[(int) f.length()];
        try (FileInputStream in = new FileInputStream(f)) {
            int off = 0;
            while (off < buf.length) {
                int n = in.read(buf, off, buf.length - off);
                if (n < 0) break;
                off += n;
            }
        }
        return buf;
    }

    private static String readTail(File f, int max) throws IOException {
        try (RandomAccessFile raf = new RandomAccessFile(f, "r")) {
            long len = raf.length();
            long start = Math.max(0, len - max);
            raf.seek(start);
            byte[] b = new byte[(int) (len - start)];
            raf.readFully(b);
            return new String(b, StandardCharsets.UTF_8);
        }
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        return null;
    }

    @Override
    public String getType(Uri uri) {
        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        return 0;
    }
}
