package com.botrunner.app;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import java.io.File;
import java.io.FileOutputStream;
import java.util.regex.Pattern;

/** Bot start/stop ka shared logic (MainActivity, ControlActivity aur OwnerProvider teeno use karte hain). */
final class BotControl {

    static final String PREFS = "cfg";
    private static final Pattern TOKEN_RE = Pattern.compile("^\\d{5,}:[A-Za-z0-9_-]{20,}$");

    private BotControl() {
    }

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /** Quotes, comma, spaces aur "TOKEN =" jaisa code ka hissa hata deta hai. */
    static String cleanToken(String t) {
        if (t == null) return "";
        t = t.replaceAll("[\\s\"'`,;]", "");
        int eq = t.lastIndexOf('=');
        if (eq >= 0) t = t.substring(eq + 1);
        return t;
    }

    static boolean isValidToken(String t) {
        return t != null && TOKEN_RE.matcher(t).matches();
    }

    @SuppressWarnings("deprecation")
    static boolean isRunning(Context c) {
        ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo s : am.getRunningServices(Integer.MAX_VALUE)) {
            if (BotService.class.getName().equals(s.service.getClassName())) return true;
        }
        return false;
    }

    /** null = start ho gaya, warna error message. */
    static String start(Context c) {
        SharedPreferences p = prefs(c);
        String token = p.getString("token", "");
        String path = p.getString("path", null);

        if (!isValidToken(token)) return "Bot token galat ya khali hai";
        if (path == null || !new File(path).exists()) return "Bot file nahi mili";
        if (isRunning(c)) return "Bot pehle se chal raha hai";

        try {
            new FileOutputStream(new File(c.getFilesDir(), "bot.log")).close();
        } catch (Exception ignored) {
        }

        Intent i = new Intent(c, BotService.class);
        i.putExtra("token", token);
        i.putExtra("path", path);
        i.putExtra("promo_enabled", p.getBoolean("promo_enabled", false));
        i.putExtra("promo_text", p.getString("promo_text", ""));
        i.putExtra("promo_url", p.getString("promo_url", ""));
        i.putExtra("promo_every", p.getInt("promo_every", 1));

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            c.startForegroundService(i);
        } else {
            c.startService(i);
        }
        return null;
    }

    static void stop(Context c) {
        c.stopService(new Intent(c, BotService.class));
    }
}
