package com.botrunner.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.Process;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

/**
 * Foreground service jo alag process (:bot) me chalta hai.
 * Stop dabane par process kill hota hai, isse bot ka Python thread bhi saaf band ho jata hai.
 */
public class BotService extends Service {

    private static final String CHANNEL_ID = "bot_runner";
    private static final int NOTIF_ID = 1;

    private boolean started = false;
    private PowerManager.WakeLock wakeLock;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        showNotification();

        if (started || intent == null) {
            return START_NOT_STICKY;
        }
        started = true;

        final String token = intent.getStringExtra("token");
        final String path = intent.getStringExtra("path");
        final String filesDir = getFilesDir().getAbsolutePath();
        final boolean promoEnabled = intent.getBooleanExtra("promo_enabled", false);
        final String promoText = intent.getStringExtra("promo_text");
        final String promoUrl = intent.getStringExtra("promo_url");
        final int promoEvery = intent.getIntExtra("promo_every", 1);

        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "botrunner:bot");
        wakeLock.acquire();

        Thread t = new Thread(() -> {
            try {
                if (!Python.isStarted()) {
                    Python.start(new AndroidPlatform(this));
                }
                PyObject runner = Python.getInstance().getModule("runner");
                runner.callAttr("run", token, path, filesDir, promoEnabled,
                        promoText == null ? "" : promoText,
                        promoUrl == null ? "" : promoUrl,
                        promoEvery);
            } catch (Throwable e) {
                try {
                    java.io.FileWriter fw = new java.io.FileWriter(
                            new java.io.File(filesDir, "bot.log"), true);
                    fw.write("\n[service error] " + e + "\n");
                    fw.close();
                } catch (Exception ignored) {
                }
            }
        }, "bot-python");
        t.start();

        return START_NOT_STICKY;
    }

    private void showNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "Bot status", NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
        }

        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(
                this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        Notification n = b.setContentTitle("Telegram bot chal raha hai")
                .setContentText("Band karne ke liye app kholo aur Stop dabao")
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    @Override
    public void onDestroy() {
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
        }
        super.onDestroy();
        // Poora :bot process maar do, taaki Python thread bhi band ho.
        Process.killProcess(Process.myPid());
    }
}
