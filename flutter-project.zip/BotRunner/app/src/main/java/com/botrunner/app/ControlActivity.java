package com.botrunner.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

/**
 * Owner app yahan se bot start/restart karwata hai.
 * Manifest me signature permission laga hai, isliye sirf same key se sign hui owner app hi ise khol sakti hai.
 * (Foreground service background se start nahi ho sakti, isliye ye chhoti visible activity use hoti hai.)
 */
public class ControlActivity extends Activity {

    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String cmd = getIntent().getStringExtra("cmd");

        if ("start".equals(cmd)) {
            report(BotControl.start(this));
            finish();
        } else if ("restart".equals(cmd)) {
            BotControl.stop(this);
            // :bot process ko band hone ka time do
            handler.postDelayed(() -> {
                report(BotControl.start(this));
                finish();
            }, 2000);
        } else {
            finish();
        }
    }

    private void report(String err) {
        Toast.makeText(this, err == null ? "Bot start ho gaya" : err, Toast.LENGTH_LONG).show();
    }
}
