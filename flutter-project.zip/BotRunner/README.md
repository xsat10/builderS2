# Bot Runner (Telegram bot ko phone pe chalane wala app)

App me 3 kaam: **bot token daalo -> bot file (.py ya .zip) chuno -> Start**.
Bot phone ke andar hi chalta hai (Python = Chaquopy), foreground service me, notification ke saath.

## File kaise banani hai

- **Token env se lo** (app token in names se deta hai):
  `BOT_TOKEN`, `TOKEN`, `TELEGRAM_BOT_TOKEN`, `TELEGRAM_TOKEN`, `API_TOKEN`

  ```python
  import os
  TOKEN = os.environ["BOT_TOKEN"]
  ```
  Agar script me token hardcoded hai to wo hi use hoga, app wala nahi.

- **Single file**: bas `bot.py` chuno.
- **Project (kai files)**: zip banao, root me `main.py` / `bot.py` / `app.py` rakho. Zip ke andar ek folder ho to bhi chalega.

## Libraries

APK me pehle se bundled: `requests`, `python-telegram-bot==21.6`, `pyTelegramBotAPI` (telebot).
Runtime pe `pip install` nahi chalta. Aur library chahiye to `app/build.gradle` me `pip { install "..." }` me add karke dobara build karo.
(Sirf pure-Python ya Chaquopy ke wheels wali libraries chalti hain. aiogram jaisi pydantic-core wali library ke liye alag check karna padega.)

## Build: Termux

```bash
pkg update && pkg upgrade
pkg install openjdk-17 gradle aapt2 python git unzip wget

# Android SDK (sirf platform + build-tools chahiye)
mkdir -p ~/android-sdk/cmdline-tools && cd ~/android-sdk/cmdline-tools
wget https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
unzip commandlinetools-linux-*.zip && mv cmdline-tools latest
export ANDROID_HOME=$HOME/android-sdk
yes | $ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager --licenses
$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager "platforms;android-35" "build-tools;35.0.0"

# Project
cd ~ && unzip BotRunner.zip && cd BotRunner
echo "sdk.dir=$ANDROID_HOME" > local.properties
```

Phir `gradle.properties` kholo aur ye line **uncomment** karo (Termux ka aapt2 use karne ke liye):

```
android.aapt2FromMavenOverride=/data/data/com.termux/files/usr/bin/aapt2
```

Build:

```bash
gradle assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
cp app/build/outputs/apk/debug/app-debug.apk ~/storage/downloads/BotRunner.apk
```

(`termux-setup-storage` ek baar chalana padega.)

## Agar Termux me build fail ho

Chaquopy ko build ke time host Python se pip chalana padta hai aur Termux pe ye kabhi kabhi atak jata hai.
Plan B: project ko GitHub repo me daalo. `.github/workflows/build.yml` already hai, push karte hi APK build hoke
Actions -> Artifacts me mil jayegi. (Is case me `gradle.properties` wali aapt2 line comment hi rehne do.)

## Limitations

- Phone ki battery optimization me app ko "Unrestricted" kar do, warna kuch phones bot ko kill kar dete hain.
- Stop dabane se poora bot process band hota hai.
- Android 15 pe foreground service kabhi kabhi system band kar sakta hai; zyada reliable 24x7 ke liye server/VPS behtar hai.

---

## Owner app (`owner/` module)

Ek hi `gradle assembleDebug` se do APK banti hain:
- `app/build/outputs/apk/debug/app-debug.apk`  -> **Bot Runner** (bot chalata hai)
- `owner/build/outputs/apk/debug/owner-debug.apk` -> **Bot Owner** (bot app ko control karta hai)

Install order: **pehle Bot Runner, phir Bot Owner** (permission Bot Runner define karta hai).
Dono APK ek hi build se / ek hi keystore se sign honi chahiye (Termux me automatic), warna Owner ko access nahi milega.
GitHub Actions me har run ki debug key alag hoti hai, isliye wahan se bani APKs ko ek saath hi install karna, aur baad me sirf ek ko update mat karna.

Owner app se:
- Start / Stop / Restart
- Token update (token kabhi wapas dikhaya nahi jata)
- Nayi `.py` / `.zip` push karo, bot chal raha ho to auto restart
- Code seedha edit karo (sirf `.py`), Save + Restart
- Channel promotion: link, text, har kitne message me. Bot ke plain-text messages ke end me jud jata hai
  (parse_mode HTML/Markdown wale messages me nahi judta). Env me `PROMO_TEXT`, `PROMO_URL` bhi milte hain.
- Live log (token log me `<TOKEN>` ban jata hai)

Security: control sirf same-signature app kar sakti hai (Android signature permission). Network se koi remote control nahi hai.
