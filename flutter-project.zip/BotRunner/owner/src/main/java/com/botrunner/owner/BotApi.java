package com.botrunner.owner;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

/** Bot app se baat karne ka chhota client. */
final class BotApi {

    static final String BOT_PKG = "com.botrunner.app";
    static final String AUTH = "com.botrunner.app.owner";
    static final Uri BASE = Uri.parse("content://" + AUTH);

    private BotApi() {
    }

    /** Hamesha Bundle lautata hai; error ho to "error" key me message hota hai. */
    static Bundle call(Context c, String method, String arg, Bundle extras) {
        try {
            Bundle r = c.getContentResolver().call(BASE, method, arg, extras);
            if (r == null) {
                r = new Bundle();
                r.putString("error", "Bot app se jawab nahi mila. Bot app install hai? (pehle bot app, phir owner app)");
            }
            return r;
        } catch (Exception e) {
            Bundle r = new Bundle();
            r.putString("error", "Access nahi mila: " + e.getMessage());
            return r;
        }
    }

    /** cmd = "start" ya "restart". null = theek, warna error. */
    static String startActivityCmd(Context c, String cmd) {
        try {
            Intent i = new Intent();
            i.setComponent(new ComponentName(BOT_PKG, BOT_PKG + ".ControlActivity"));
            i.putExtra("cmd", cmd);
            c.startActivity(i);
            return null;
        } catch (Exception e) {
            return "Bot app nahi khul payi: " + e.getMessage();
        }
    }
}
