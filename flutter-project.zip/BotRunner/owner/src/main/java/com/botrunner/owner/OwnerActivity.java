package com.botrunner.owner;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;

public class OwnerActivity extends Activity {

    private static final int REQ_PICK = 201;

    private TextView statusText, fileInfo, logView;
    private EditText tokenInput, promoUrl, promoText, promoEvery;
    private Switch promoSwitch;

    private boolean running = false;
    private boolean configLoaded = false;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final Runnable poll = new Runnable() {
        @Override
        public void run() {
            refresh();
            handler.postDelayed(this, 2000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_owner);

        statusText = findViewById(R.id.statusText);
        fileInfo = findViewById(R.id.fileInfo);
        logView = findViewById(R.id.logView);
        tokenInput = findViewById(R.id.tokenInput);
        promoUrl = findViewById(R.id.promoUrl);
        promoText = findViewById(R.id.promoText);
        promoEvery = findViewById(R.id.promoEvery);
        promoSwitch = findViewById(R.id.promoSwitch);

        findViewById(R.id.startBtn).setOnClickListener(v ->
                toastIfError(BotApi.startActivityCmd(this, "start")));

        findViewById(R.id.stopBtn).setOnClickListener(v -> {
            Bundle r = BotApi.call(this, "stop", null, null);
            report(r, "Bot band kar diya");
        });

        findViewById(R.id.restartBtn).setOnClickListener(v ->
                toastIfError(BotApi.startActivityCmd(this, "restart")));

        findViewById(R.id.tokenBtn).setOnClickListener(v -> {
            Bundle ex = new Bundle();
            ex.putString("token", tokenInput.getText().toString());
            Bundle r = BotApi.call(this, "set_token", null, ex);
            if (r.getString("error") == null) {
                tokenInput.setText("");
                restartIfRunning("Token update ho gaya");
            } else {
                report(r, "");
            }
        });

        findViewById(R.id.pickBtn).setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            startActivityForResult(i, REQ_PICK);
        });

        findViewById(R.id.editBtn).setOnClickListener(v ->
                startActivity(new Intent(this, CodeEditActivity.class)));

        findViewById(R.id.promoBtn).setOnClickListener(v -> {
            int every = 1;
            try {
                every = Integer.parseInt(promoEvery.getText().toString().trim());
            } catch (Exception ignored) {
            }
            Bundle ex = new Bundle();
            ex.putBoolean("enabled", promoSwitch.isChecked());
            ex.putString("url", promoUrl.getText().toString());
            ex.putString("text", promoText.getText().toString());
            ex.putInt("every", every);
            Bundle r = BotApi.call(this, "set_promo", null, ex);
            if (r.getString("error") == null) {
                restartIfRunning("Promo save ho gaya");
            } else {
                report(r, "");
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(poll);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(poll);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_PICK || res != RESULT_OK || data == null || data.getData() == null) return;
        pushFile(data.getData());
    }

    private void pushFile(Uri uri) {
        String name = queryName(uri);
        if (name == null || name.isEmpty()) name = "bot.py";
        name = new File(name).getName();
        String lower = name.toLowerCase();
        if (!lower.endsWith(".py") && !lower.endsWith(".zip")) {
            toast("Sirf .py ya .zip file chuno");
            return;
        }

        Uri dest = Uri.parse("content://" + BotApi.AUTH + "/upload/" + Uri.encode(name));
        try (InputStream in = getContentResolver().openInputStream(uri);
             OutputStream out = getContentResolver().openOutputStream(dest, "wt")) {
            if (in == null || out == null) {
                toast("File open nahi hui");
                return;
            }
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        } catch (Exception e) {
            toast("Push fail: " + e.getMessage());
            return;
        }

        Bundle r = BotApi.call(this, "use_file", name, null);
        if (r.getString("error") == null) {
            restartIfRunning("Code push ho gaya: " + name);
        } else {
            report(r, "");
        }
    }

    private String queryName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) return c.getString(idx);
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private void restartIfRunning(String doneMsg) {
        if (running) {
            toast(doneMsg + ". Bot restart ho raha hai...");
            toastIfError(BotApi.startActivityCmd(this, "restart"));
        } else {
            toast(doneMsg + ". Ab Start dabao.");
        }
    }

    private void refresh() {
        Bundle s = BotApi.call(this, "status", null, null);
        String err = s.getString("error");
        if (err != null) {
            statusText.setText("Status: " + err);
            statusText.setTextColor(0xFFC62828);
            return;
        }

        running = s.getBoolean("running");
        statusText.setText(running ? "Bot: CHAL RAHA HAI" : "Bot: band");
        statusText.setTextColor(running ? 0xFF2E7D32 : 0xFF757575);

        String file = s.getString("file", "");
        fileInfo.setText("File: " + (file.isEmpty() ? "koi nahi" : file)
                + "   |   Token: " + (s.getBoolean("token_set") ? "set hai" : "set nahi"));

        if (!configLoaded) {
            promoSwitch.setChecked(s.getBoolean("promo_enabled"));
            promoUrl.setText(s.getString("promo_url", ""));
            promoText.setText(s.getString("promo_text", ""));
            promoEvery.setText(String.valueOf(s.getInt("promo_every", 1)));
            configLoaded = true;
        }

        Bundle l = BotApi.call(this, "log", null, null);
        String log = l.getString("log", "");
        if (log.length() > 3000) log = log.substring(log.length() - 3000);
        if (!log.contentEquals(logView.getText())) {
            logView.setText(log);
        }
    }

    private void report(Bundle r, String okMsg) {
        String e = r.getString("error");
        toast(e != null ? e : okMsg);
    }

    private void toastIfError(String err) {
        if (err != null) toast(err);
    }

    private void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_LONG).show();
    }
}
