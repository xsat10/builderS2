package com.botrunner.owner;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/** Bot ka .py code seedha yahan edit karo aur bot app me save karo. */
public class CodeEditActivity extends Activity {

    private EditText codeEdit;
    private TextView titleText;
    private Button saveBtn, saveRunBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_code);

        codeEdit = findViewById(R.id.codeEdit);
        titleText = findViewById(R.id.titleText);
        saveBtn = findViewById(R.id.saveBtn);
        saveRunBtn = findViewById(R.id.saveRunBtn);

        Bundle r = BotApi.call(this, "get_script_text", null, null);
        String err = r.getString("error");
        if (err != null) {
            titleText.setText(err);
            saveBtn.setEnabled(false);
            saveRunBtn.setEnabled(false);
            codeEdit.setEnabled(false);
        } else {
            titleText.setText("Code: " + r.getString("name", "bot.py"));
            codeEdit.setText(r.getString("text", ""));
        }

        saveBtn.setOnClickListener(v -> {
            if (save()) toast("Save ho gaya");
        });

        saveRunBtn.setOnClickListener(v -> {
            if (!save()) return;
            String e = BotApi.startActivityCmd(this, "restart");
            if (e != null) toast(e);
        });
    }

    private boolean save() {
        Bundle ex = new Bundle();
        ex.putString("text", codeEdit.getText().toString());
        Bundle r = BotApi.call(this, "put_script_text", null, ex);
        String err = r.getString("error");
        if (err != null) {
            toast(err);
            return false;
        }
        return true;
    }

    private void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_LONG).show();
    }
}
