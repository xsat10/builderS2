#!/usr/bin/env python3
"""Tambah permission yang dibutuhkan (internet, kamera, mic, dll) ke AndroidManifest.
Aman dijalankan berulang kali (idempotent)."""
import re, sys, pathlib

p = pathlib.Path("android/app/src/main/AndroidManifest.xml")
if not p.exists():
    sys.exit("AndroidManifest.xml tidak ditemukan - jalankan flutter create dulu")

s = p.read_text(encoding="utf-8")
perms = [
    "android.permission.INTERNET",
    "android.permission.ACCESS_NETWORK_STATE",
    "android.permission.CAMERA",
    "android.permission.RECORD_AUDIO",
    "android.permission.MODIFY_AUDIO_SETTINGS",
]
add = "".join(
    f'    <uses-permission android:name="{x}"/>\n'
    for x in perms if x not in s
)
if add:
    s = s.replace("<application", add + "    <application", 1)

s = re.sub(r'android:label="[^"]*"', 'android:label="Xyzora Chat"', s, count=1)
p.write_text(s, encoding="utf-8")
print("AndroidManifest dipatch OK")
