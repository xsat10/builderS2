# Firebase Push Notification

The app reads its Firebase client configuration from the same GitHub Raw `Config.json` used for the API server. This keeps server URL changes build-free.

Add:
```json
"firebase": {
  "apiKey": "YOUR_FIREBASE_API_KEY",
  "appId": "YOUR_FIREBASE_ANDROID_APP_ID",
  "messagingSenderId": "YOUR_FIREBASE_SENDER_ID",
  "projectId": "YOUR_FIREBASE_PROJECT_ID",
  "storageBucket": "YOUR_FIREBASE_STORAGE_BUCKET"
}
```

After notification permission is granted and the user has opened/logged into the app once, it subscribes to `developer_notifications`. The server `/notif` command sends to that topic, so the Android system can display the notification when the app is backgrounded or not open.

The Firebase service-account private key belongs only on the server; never put it in Config.json or the APK.


## Firebase configuration added

The Android Firebase config from Firebase Console is bundled at `android/app/google-services.json`.
The registered Android package is `com.x.xeternalz` and the Firebase project ID is `notif-3b442`.

For runtime server switching, keep the Firebase block in the GitHub Raw `Config.json` optional; the app can fall back to the bundled Firebase configuration.
Do not put a Firebase service-account private key in the APK or GitHub Raw config.
