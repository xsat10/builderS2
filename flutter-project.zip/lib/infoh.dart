import 'servers.dart';
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class InfoPage extends StatefulWidget {
  final String sessionKey;

  const InfoPage({super.key, required this.sessionKey});

  @override
  State<InfoPage> createState() => _InfoPageState();
}

class _InfoPageState extends State<InfoPage> with AutomaticKeepAliveClientMixin {
  // --- State Data ---
  Map<String, dynamic>? serverInfo;
  bool isLoading = true;

  // API Status State
  bool isApiOnline = false;
  int apiPingMs = 0;
  Color apiStatusColor = Colors.grey;
  String apiStatusText = "Checking...";
  Timer? _pingTimer;

  String baseUrl = "";

  // Cache untuk config
  static String? _cachedBaseUrl;

  // --- 🏁 BMW M GARAGE PALETTE ---
  final Color garageBlack = const Color(0xFF0A0A0A);      // Base asphalt
  final Color carbonDark = const Color(0xFF121212);       // Carbon fiber dark
  final Color carbonCard = const Color(0xFF1A1A1A);       // Card panel
  final Color chromeSilver = const Color(0xFFC8C8C8);     // Chrome trim
  final Color bmwLightBlue = const Color(0xFF0066B1);     // BMW M Light Blue
  final Color bmwDarkBlue = const Color(0xFF0F3D77);      // BMW M Dark Blue
  final Color bmwRed = const Color(0xFFE32119);           // BMW M Red
  final Color bmwBlueGlow = const Color(0xFF1C69D4);      // Electric blue
  final Color textGrey = Colors.grey.shade400;
  final Color textLight = const Color(0xFFE8E8E8);

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _loadConfigAndFetch();
  }

  @override
  void dispose() {
    _pingTimer?.cancel();
    super.dispose();
  }

  Future<void> _loadConfig() async {
    if (_cachedBaseUrl != null) {
      baseUrl = _cachedBaseUrl!;
      return;
    }

    try {
      final response = await http.get(
        Uri.parse(Servers.configUrl),
      ).timeout(const Duration(seconds: 3));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        baseUrl = data['base_url'];
        _cachedBaseUrl = baseUrl;
      } else {
        baseUrl = "https://your-fallback-url.com";
        _cachedBaseUrl = baseUrl;
      }
    } catch (e) {
      baseUrl = "https://your-fallback-url.com";
      _cachedBaseUrl = baseUrl;
    }
  }

  Future<void> _loadConfigAndFetch() async {
    await Future.wait([
      _loadConfig(),
      _fetchServerInfo(),
    ]);
    _startApiPingLoop();
  }

  Future<void> _fetchServerInfo() async {
    try {
      final res = await http.get(
        Uri.parse('$baseUrl/getServerInfo?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 5));

      if (res.statusCode == 200) {
        if (mounted) {
          setState(() {
            serverInfo = jsonDecode(res.body);
            isLoading = false;
          });
        }
      } else {
        if (mounted) setState(() => isLoading = false);
      }
    } catch (e) {
      if (mounted) setState(() => isLoading = false);
    }
  }

  void _startApiPingLoop() {
    _checkApiPing();
    _pingTimer = Timer.periodic(const Duration(seconds: 10), (_) {
      _checkApiPing();
    });
  }

  Future<void> _checkApiPing() async {
    final start = DateTime.now();
    try {
      final res = await http.get(
        Uri.parse('$baseUrl/ping?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 2));

      final end = DateTime.now();
      final duration = end.difference(start).inMilliseconds;

      if (res.statusCode == 200 && mounted) {
        setState(() {
          isApiOnline = true;
          apiPingMs = duration;
          if (duration < 200) {
            apiStatusColor = const Color(0xFF00C853); // Green
          } else if (duration < 500) {
            apiStatusColor = const Color(0xFFFFB300); // Amber
          } else {
            apiStatusColor = bmwRed;
          }
          apiStatusText = "Online (${duration}ms)";
        });
      } else {
        throw Exception("Failed");
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          isApiOnline = false;
          apiPingMs = 0;
          apiStatusColor = Colors.grey;
          apiStatusText = "Offline";
        });
      }
    }
  }

  // 🏁 M-Stripe Widget
  Widget _mStripe({double height = 3, double width = 40}) {
    return Container(
      height: height,
      width: width,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(2),
        gradient: const LinearGradient(
          colors: [Color(0xFF0066B1), Color(0xFF0F3D77), Color(0xFFE32119)],
          stops: [0.0, 0.5, 1.0],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);

    if (isLoading) {
      return Scaffold(
        backgroundColor: garageBlack,
        body: Container(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              colors: [carbonCard, garageBlack],
              radius: 1.2,
            ),
          ),
          child: const Center(
            child: CircularProgressIndicator(color: Color(0xFF1C69D4)),
          ),
        ),
      );
    }

    final List<Map<String, String>> rulesList = [
      {
        "title": "Larangan Barter Akun",
        "desc": "Akun tidak boleh ditukar dengan barang, jasa, atau akun lain dalam bentuk apa pun."
      },
      {
        "title": "Larangan Bug Orang Sembarangan",
        "desc": "Dilarang bug orang sembarangan atau orang yang tidak bersalah."
      },
      {
        "title": "Larangan Membagikan Akun",
        "desc": "Setiap akun bersifat pribadi dan hanya boleh digunakan oleh pemilik akun yang terdaftar."
      },
      {
        "title": "Larangan Menjual Akun",
        "desc": "Member TIDAK diperbolehkan menjual akun. Penjualan akun hanya boleh dilakukan oleh role yang diizinkan secara resmi."
      },
      {
        "title": "Larangan tidak mengurus buyer",
        "desc": "Dilarang mentelantarkan buyer!!, buatkan akun buyer, jangan mau duit nya doang ngentod, jika ada yg mentelantarkan buyer langsung lapor @Skylinnereal siap membantu, tapi ga bisa mempertanggung jawabkan hak anda."
      },
      {
        "title": "Larangan Banting Harga",
        "desc": "Dilarang merusak atau menurunkan harga yang telah ditentukan (banting harga) di bawah ketentuan GhostCrasher."
      },
    ];

    return Scaffold(
      backgroundColor: garageBlack,
      appBar: AppBar(
        backgroundColor: carbonDark,
        elevation: 0,
        automaticallyImplyLeading: false,
        centerTitle: true,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(3),
          child: _mStripe(height: 3, width: double.infinity),
        ),
        title: Column(
          children: [
            const Text(
              "BMW ///M GARAGE",
              style: TextStyle(
                color: Colors.white,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold,
                fontSize: 16,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              "RULES • INFO • TELEMETRY",
              style: TextStyle(
                color: chromeSilver.withOpacity(0.7),
                fontSize: 9,
                letterSpacing: 3,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ],
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [carbonDark, garageBlack, const Color(0xFF050505)],
          ),
        ),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildCompactApiStatus(),
              const SizedBox(height: 20),
              // === RULES HEADER ===
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      carbonCard,
                      carbonDark,
                    ],
                  ),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: chromeSilver.withOpacity(0.15)),
                  boxShadow: [
                    BoxShadow(
                      color: bmwBlueGlow.withOpacity(0.15),
                      blurRadius: 12,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: garageBlack,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: bmwBlueGlow.withOpacity(0.5),
                          width: 1.5,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: bmwBlueGlow.withOpacity(0.4),
                            blurRadius: 8,
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.sports_motorsports,
                        color: Color(0xFF1C69D4),
                        size: 22,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            "GARAGE RULES",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Orbitron',
                              letterSpacing: 1.5,
                            ),
                          ),
                          const SizedBox(height: 2),
                          _mStripe(height: 2, width: 60),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // === RULES LIST ===
              ...rulesList.asMap().entries.map((entry) {
                int index = entry.key + 1;
                Map<String, String> rule = entry.value;
                return Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          carbonCard,
                          carbonDark,
                        ],
                      ),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: chromeSilver.withOpacity(0.12),
                        width: 1,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.6),
                          blurRadius: 8,
                          offset: const Offset(0, 3),
                        ),
                      ],
                    ),
                    child: Stack(
                      children: [
                        // Left M-stripe accent
                        Positioned(
                          left: 0,
                          top: 0,
                          bottom: 0,
                          child: Container(
                            width: 4,
                            decoration: const BoxDecoration(
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(14),
                                bottomLeft: Radius.circular(14),
                              ),
                              gradient: LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: [
                                  Color(0xFF0066B1),
                                  Color(0xFF0F3D77),
                                  Color(0xFFE32119),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(20, 16, 16, 16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 10,
                                      vertical: 4,
                                    ),
                                    decoration: BoxDecoration(
                                      gradient: const LinearGradient(
                                        colors: [
                                          Color(0xFF0066B1),
                                          Color(0xFF0F3D77),
                                        ],
                                      ),
                                      borderRadius: BorderRadius.circular(6),
                                      border: Border.all(
                                        color: bmwBlueGlow.withOpacity(0.6),
                                        width: 1,
                                      ),
                                    ),
                                    child: Text(
                                      "RULE $index",
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 11,
                                        fontWeight: FontWeight.bold,
                                        fontFamily: 'Orbitron',
                                        letterSpacing: 1,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: Container(
                                      height: 1,
                                      decoration: BoxDecoration(
                                        gradient: LinearGradient(
                                          colors: [
                                            chromeSilver.withOpacity(0.3),
                                            Colors.transparent,
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 10),
                              Text(
                                rule['title']!,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 15,
                                  letterSpacing: 0.3,
                                ),
                              ),
                              const SizedBox(height: 6),
                              Text(
                                rule['desc']!,
                                style: TextStyle(
                                  color: textGrey,
                                  fontSize: 13,
                                  height: 1.45,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),

              const SizedBox(height: 24),

              // === SANKSI PANEL - Red Alert Style ===
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      const Color(0xFF2A0808),
                      const Color(0xFF1A0505),
                      carbonDark,
                    ],
                  ),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: bmwRed.withOpacity(0.6),
                    width: 1.5,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: bmwRed.withOpacity(0.25),
                      blurRadius: 18,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: Stack(
                  children: [
                    // Top M-stripe bar
                    Positioned(
                      top: -20,
                      left: -20,
                      right: -20,
                      child: Container(
                        height: 3,
                        margin: const EdgeInsets.symmetric(horizontal: 20),
                        decoration: const BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Color(0xFF0066B1),
                              Color(0xFF0F3D77),
                              Color(0xFFE32119),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: bmwRed.withOpacity(0.15),
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: bmwRed.withOpacity(0.5),
                                ),
                              ),
                              child: const Icon(
                                Icons.warning_amber_rounded,
                                color: Color(0xFFE32119),
                                size: 26,
                              ),
                            ),
                            const SizedBox(width: 10),
                            const Text(
                              "PENALTY ZONE",
                              style: TextStyle(
                                color: Color(0xFFFF5252),
                                fontSize: 20,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Orbitron',
                                letterSpacing: 1.5,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 14),
                        const Text(
                          "Jika pengguna terbukti melanggar salah satu peraturan di atas:",
                          style: TextStyle(color: Colors.white70, fontSize: 13),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 10),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 14,
                            vertical: 8,
                          ),
                          decoration: BoxDecoration(
                            color: bmwRed.withOpacity(0.12),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(
                              color: bmwRed.withOpacity(0.4),
                            ),
                          ),
                          child: const Text(
                            "AKUN DIHAPUS PERMANEN & BLACKLISTED",
                            style: TextStyle(
                              color: Color(0xFFFF5252),
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 0.5,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          "Tanpa pengembalian akun, saldo, atau kompensasi apa pun",
                          style: TextStyle(
                            color: chromeSilver.withOpacity(0.75),
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 24),

              // === FOOTER ===
              Center(
                child: Column(
                  children: [
                    // BMW Roundel-ish icon
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: const LinearGradient(
                          colors: [
                            Color(0xFF0066B1),
                            Color(0xFF0F3D77),
                            Color(0xFFE32119),
                          ],
                          stops: [0.0, 0.5, 1.0],
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: bmwBlueGlow.withOpacity(0.4),
                            blurRadius: 15,
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.shield_moon_rounded,
                        color: Colors.white,
                        size: 26,
                      ),
                    ),
                    const SizedBox(height: 14),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      child: Text(
                        "Peraturan ini dibuat untuk menjaga keamanan, kenyamanan, dan kestabilan ekosistem GhostCrasher Apps. Dengan menggunakan aplikasi ini, pengguna dianggap telah menyetujui seluruh peraturan di atas.",
                        style: TextStyle(
                          color: textGrey,
                          fontSize: 12,
                          fontStyle: FontStyle.italic,
                          height: 1.5,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    const SizedBox(height: 16),
                    _mStripe(height: 4, width: 120),
                    const SizedBox(height: 8),
                    Text(
                      "/// M POWER",
                      style: TextStyle(
                        color: chromeSilver.withOpacity(0.5),
                        fontSize: 10,
                        letterSpacing: 4,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCompactApiStatus() {
    final statusColor = isApiOnline ? const Color(0xFF00C853) : apiStatusColor;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            carbonCard,
            carbonDark,
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: chromeSilver.withOpacity(0.15)),
        boxShadow: [
          BoxShadow(
            color: statusColor.withOpacity(0.15),
            blurRadius: 10,
          ),
        ],
      ),
      child: Row(
        children: [
          // Telemetry dot
          Container(
            width: 10,
            height: 10,
            decoration: BoxDecoration(
              color: statusColor,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: statusColor.withOpacity(0.8),
                  blurRadius: 8,
                  spreadRadius: 1,
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "TELEMETRY STATUS",
                  style: TextStyle(
                    color: chromeSilver.withOpacity(0.6),
                    fontSize: 9,
                    letterSpacing: 2,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  isApiOnline ? apiStatusText : "OFFLINE",
                  style: TextStyle(
                    color: textLight,
                    fontSize: 13,
                    fontFamily: 'ShareTechMono',
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          // Mini gauge
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: garageBlack,
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: chromeSilver.withOpacity(0.2)),
            ),
            child: Row(
              children: [
                Icon(
                  isApiOnline ? Icons.speed : Icons.power_off,
                  color: statusColor,
                  size: 14,
                ),
                const SizedBox(width: 4),
                Text(
                  isApiOnline ? "${apiPingMs}ms" : "OFF",
                  style: TextStyle(
                    color: statusColor,
                    fontSize: 11,
                    fontFamily: 'ShareTechMono',
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}