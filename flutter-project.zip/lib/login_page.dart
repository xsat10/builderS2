import 'servers.dart';
import 'dart:ui';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'splash.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with SingleTickerProviderStateMixin {
  final userController = TextEditingController();
  final passController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool isLoading = false;
  bool _obscurePassword = true;
  String? androidId;
  String baseUrl = "";

  late AnimationController _controller;
  late Animation<double> _fadeAnim;
  late Animation<double> _slideAnim;

  // ─── 🏁 BMW M GARAGE PALETTE ──────────────────────────────
  static const Color garageBlack   = Color(0xFF0A0A0A);   // Base asphalt
  static const Color carbonDark    = Color(0xFF121212);   // Carbon fiber dark
  static const Color cardColor     = Color(0xFF1A1A1A);   // Card panel
  static const Color surfaceColor  = Color(0xFF202020);   // Input surface
  static const Color chromeSilver  = Color(0xFFC8C8C8);   // Chrome trim
  static const Color bmwLightBlue  = Color(0xFF0066B1);   // BMW M Light Blue
  static const Color bmwDarkBlue   = Color(0xFF0F3D77);   // BMW M Dark Blue
  static const Color bmwRed        = Color(0xFFE32119);   // BMW M Red
  static const Color bmwBlueGlow   = Color(0xFF1C69D4);   // Electric blue glow
  static const Color textPrimary   = Color(0xFFF5F5F5);
  static const Color textSecondary = Color(0xFF9E9E9E);
  static const Color dividerColor  = Color(0xFF2A2A2A);

  String appVersion = "2.0.2";

  @override
  void initState() {
    super.initState();
    _initAnim();
    _initAndLoad();
  }

  Future<void> _initAndLoad() async {
    await loadConfig();
    androidId = await getAndroidId();
    try {
      final info = await PackageInfo.fromPlatform();
      if (mounted) setState(() => appVersion = info.version);
    } catch (_) {}
    await initLogin();
  }

  void _initAnim() {
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..forward();

    _fadeAnim = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );

    _slideAnim = Tween<double>(begin: 50, end: 0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOut),
    );
  }

  Future<void> loadConfig() async {
    try {
      final response = await http.get(
        Uri.parse(
            Servers.configUrl),
      );
      final data = jsonDecode(response.body);
      baseUrl = data['base_url'];
    } catch (e) {
      // ignore, keep default
    }
  }

  Future<String> getAndroidId() async {
    final deviceInfo = DeviceInfoPlugin();
    final android = await deviceInfo.androidInfo;
    return android.id ?? "unknown_device";
  }

  Future<void> initLogin() async {
    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString("username");
    final savedPass = prefs.getString("password");
    final savedKey = prefs.getString("key");

    if (savedUser != null && savedPass != null && savedKey != null) {
      if (baseUrl.isEmpty) return;

      final uri = Uri.parse(
          "$baseUrl/myInfo?username=$savedUser&password=$savedPass&androidId=$androidId&key=$savedKey");

      try {
        final res = await http.get(uri);
        final data = jsonDecode(res.body);

        if (data['valid'] == true && data['expired'] != true) {
          final pairingId = data['pair_id']?.toString().trim() ?? '';
          if (pairingId.isNotEmpty) {
            await prefs.setString('pairing_id_$savedUser', pairingId);
          }
          if (!mounted) return;
          Navigator.pushReplacement(
            context,
            PageRouteBuilder(
              pageBuilder: (_, __, ___) => SplashScreen(
                username: savedUser,
                password: savedPass,
                role: data['role'],
                sessionKey: data['key'],
                expiredDate: data['expiredDate'],
                listBug: (data['listBug'] as List? ?? [])
                    .map((e) => Map<String, dynamic>.from(e as Map))
                    .toList(),
                listDoos: (data['listDDoS'] as List? ?? [])
                    .map((e) => Map<String, dynamic>.from(e as Map))
                    .toList(),
                news: (data['news'] as List? ?? [])
                    .map((e) => Map<String, dynamic>.from(e as Map))
                    .toList(),
              ),
              transitionDuration: const Duration(milliseconds: 400),
              transitionsBuilder: (_, animation, __, child) =>
                  FadeTransition(opacity: animation, child: child),
            ),
          );
        }
      } catch (_) {}
    }
  }

  Future<void> login() async {
    if (!_formKey.currentState!.validate()) return;

    final username = userController.text.trim();
    final password = passController.text.trim();

    setState(() => isLoading = true);

    try {
      if (baseUrl.isEmpty) {
        await loadConfig();
      }
      if (!mounted) return;
      if (baseUrl.isEmpty) {
        _showPopup(
          title: "SERVER ERROR",
          message: "Server belum siap. Coba lagi.",
          color: bmwRed,
        );
        setState(() => isLoading = false);
        return;
      }

      androidId ??= await getAndroidId();

      final validate = await http.post(
        Uri.parse("$baseUrl/validate"),
        body: {
          "username": username,
          "password": password,
          "androidId": androidId ?? "unknown_device",
          "version": appVersion,
        },
      );

      final validData = jsonDecode(validate.body);
      print("VALIDATE RESPONSE => $validData");

      if (!mounted) return;

      if (validData['expired'] == true) {
        _showPopup(
          title: "ACCESS EXPIRED",
          message: "Your access has expired.\nPlease renew it.",
          color: Colors.orange,
          showContact: true,
        );
      } else if (validData['valid'] != true) {
        _showPopup(
          title: "ACCESS DENIED",
          message: "Invalid username or password.",
          color: bmwRed,
        );
      } else {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString("username", username);
        await prefs.setString("password", password);
        await prefs.setString("key", validData['key']);
        final pairingId = validData['pair_id']?.toString().trim() ?? '';
        if (pairingId.isNotEmpty) {
          await prefs.setString('pairing_id_$username', pairingId);
        } else {
          await prefs.remove('pairing_id_$username');
        }

        if (!mounted) return;
        Navigator.pushReplacement(
          context,
          PageRouteBuilder(
            pageBuilder: (_, __, ___) => SplashScreen(
              username: username,
              password: password,
              role: validData['role'],
              sessionKey: validData['key'],
              expiredDate: validData['expiredDate'],
              listBug: (validData['listBug'] as List? ?? [])
                  .map((e) => Map<String, dynamic>.from(e as Map))
                  .toList(),
              listDoos: (validData['listDDoS'] as List? ?? [])
                  .map((e) => Map<String, dynamic>.from(e as Map))
                  .toList(),
              news: (validData['news'] as List? ?? [])
                  .map((e) => Map<String, dynamic>.from(e as Map))
                  .toList(),
            ),
            transitionDuration: const Duration(milliseconds: 400),
            transitionsBuilder: (_, animation, __, child) =>
                FadeTransition(opacity: animation, child: child),
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;
      _showPopup(
        title: "CONNECTION ERROR",
        message:
            "Failed to connect to the server.\nPlease check your internet connection.",
        color: bmwRed,
      );
    }

    if (mounted) setState(() => isLoading = false);
  }

  // ─── POPUP (SYSTEM ALERT STYLE) ───────────────────────────
  void _showPopup({
    required String title,
    required String message,
    Color color = bmwRed,
    bool showContact = false,
  }) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                cardColor,
                carbonDark,
              ],
            ),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: color.withOpacity(0.6), width: 1.5),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.3),
                blurRadius: 25,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Stack(
            children: [
              // Top M-stripe
              Positioned(
                top: 0,
                left: 0,
                right: 0,
                child: ClipRRect(
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(16),
                    topRight: Radius.circular(16),
                  ),
                  child: Container(
                    height: 3,
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        colors: [bmwLightBlue, bmwDarkBlue, bmwRed],
                        stops: [0.0, 0.5, 1.0],
                      ),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(24, 28, 24, 24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 54,
                      height: 54,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: color.withOpacity(0.12),
                        border: Border.all(
                            color: color.withOpacity(0.5), width: 1.5),
                        boxShadow: [
                          BoxShadow(
                            color: color.withOpacity(0.3),
                            blurRadius: 15,
                          ),
                        ],
                      ),
                      child: Icon(
                        color == Colors.orange
                            ? Icons.warning_amber_rounded
                            : Icons.error_outline_rounded,
                        color: color,
                        size: 28,
                      ),
                    ),
                    const SizedBox(height: 18),
                    Text(
                      title,
                      style: const TextStyle(
                        color: textPrimary,
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                        letterSpacing: 2,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      message,
                      style: const TextStyle(
                        color: textSecondary,
                        fontSize: 13,
                        height: 1.5,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 22),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        if (showContact)
                          OutlinedButton(
                            onPressed: () async {
                              final uri =
                                  Uri.parse("https://t.me/Skylinnereal");
                              await launchUrl(uri,
                                  mode: LaunchMode.externalApplication);
                            },
                            style: OutlinedButton.styleFrom(
                              foregroundColor: chromeSilver,
                              side: BorderSide(
                                  color: chromeSilver.withOpacity(0.4)),
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 14, vertical: 8),
                            ),
                            child: const Text("SUPPORT",
                                style: TextStyle(
                                    fontSize: 11,
                                    letterSpacing: 1.5,
                                    fontFamily: 'ShareTechMono',
                                    fontWeight: FontWeight.bold)),
                          ),
                        const SizedBox(width: 8),
                        ElevatedButton(
                          onPressed: () => Navigator.pop(context),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: color,
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(
                                horizontal: 20, vertical: 8),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(6),
                            ),
                          ),
                          child: const Text("ACKNOWLEDGE",
                              style: TextStyle(
                                  fontSize: 11,
                                  letterSpacing: 1.5,
                                  fontFamily: 'ShareTechMono',
                                  fontWeight: FontWeight.bold)),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    userController.dispose();
    passController.dispose();
    super.dispose();
  }

  // 🏁 M-Stripe Widget
  Widget _mStripe({double height = 3, double width = 40}) {
    return Container(
      height: height,
      width: width,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(2),
        gradient: const LinearGradient(
          colors: [bmwLightBlue, bmwDarkBlue, bmwRed],
          stops: [0.0, 0.5, 1.0],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: garageBlack,
      body: Stack(
        children: [
          // ─── CARBON BACKGROUND ───
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [carbonDark, garageBlack, Color(0xFF050505)],
                ),
              ),
            ),
          ),

          // ─── BLUE HEADLIGHT GLOW (TOP-LEFT) ───
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: const Alignment(-0.8, -0.7),
                  radius: 1.4,
                  colors: [
                    bmwBlueGlow.withOpacity(0.12),
                    Colors.transparent,
                  ],
                  stops: const [0.0, 1.0],
                ),
              ),
            ),
          ),

          // ─── RED TAIL-LIGHT GLOW (BOTTOM-RIGHT) ───
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: const Alignment(1.0, 1.0),
                  radius: 1.2,
                  colors: [
                    bmwRed.withOpacity(0.08),
                    Colors.transparent,
                  ],
                  stops: const [0.0, 1.0],
                ),
              ),
            ),
          ),

          // ─── CARBON GRID ───
          Positioned.fill(
              child: CustomPaint(painter: _GridPatternPainter())),

          SafeArea(
            child: AnimatedBuilder(
              animation: _controller,
              builder: (context, child) {
                return Transform.translate(
                  offset: Offset(0, _slideAnim.value),
                  child: Opacity(opacity: _fadeAnim.value, child: child),
                );
              },
              child: Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // ─── TOP TELEMETRY BADGE ───
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 7),
                        decoration: BoxDecoration(
                          color: cardColor.withOpacity(0.7),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: chromeSilver.withOpacity(0.2),
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              width: 7,
                              height: 7,
                              decoration: BoxDecoration(
                                color: bmwBlueGlow,
                                shape: BoxShape.circle,
                                boxShadow: [
                                  BoxShadow(
                                    color: bmwBlueGlow.withOpacity(0.8),
                                    blurRadius: 8,
                                    spreadRadius: 1,
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 8),
                            Text(
                              "AUTHENTICATION SYSTEM  ///M SECURE",
                              style: TextStyle(
                                color: chromeSilver.withOpacity(0.8),
                                fontSize: 9,
                                letterSpacing: 2,
                                fontFamily: 'ShareTechMono',
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 24),

                      // ─── LOGO (BMW ROUNDEL STYLE) ───
                      Container(
                        width: 110,
                        height: 110,
                        padding: const EdgeInsets.all(3),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: const LinearGradient(
                            colors: [bmwLightBlue, bmwDarkBlue, bmwRed],
                            stops: [0.0, 0.5, 1.0],
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: bmwBlueGlow.withOpacity(0.5),
                              blurRadius: 30,
                              spreadRadius: 4,
                            ),
                            BoxShadow(
                              color: bmwRed.withOpacity(0.2),
                              blurRadius: 40,
                              spreadRadius: 2,
                            ),
                          ],
                        ),
                        child: Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: garageBlack,
                            border: Border.all(
                              color: chromeSilver.withOpacity(0.4),
                              width: 1,
                            ),
                          ),
                          padding: const EdgeInsets.all(3),
                          child: Container(
                            decoration: const BoxDecoration(
                              shape: BoxShape.circle,
                              image: DecorationImage(
                                image: AssetImage('assets/images/login.jpg'),
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 28),

                      // ─── TITLE ───
                      Column(
                        children: [
                          ShaderMask(
                            shaderCallback: (bounds) => const LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [
                                Color(0xFFFFFFFF),
                                Color(0xFFC8C8C8),
                                Color(0xFF7A7A7A),
                              ],
                              stops: [0.0, 0.5, 1.0],
                            ).createShader(bounds),
                            child: const Text(
                              "GHOST",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 40,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 8,
                                fontFamily: 'Orbitron',
                              ),
                            ),
                          ),
                          const SizedBox(height: 8),
                          _mStripe(height: 3, width: 80),
                          const SizedBox(height: 8),
                          const Text(
                            "/// M DIVISION ACCESS",
                            style: TextStyle(
                              color: chromeSilver,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 4,
                              fontFamily: 'ShareTechMono',
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 40),

                      // ─── LOGIN CARD (DASHBOARD PANEL) ───
                      Container(
                        width: MediaQuery.of(context).size.width * 0.9,
                        constraints: const BoxConstraints(maxWidth: 400),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              cardColor.withOpacity(0.85),
                              carbonDark.withOpacity(0.95),
                            ],
                          ),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: chromeSilver.withOpacity(0.18),
                            width: 1,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.5),
                              blurRadius: 30,
                              spreadRadius: 2,
                            ),
                            BoxShadow(
                              color: bmwBlueGlow.withOpacity(0.08),
                              blurRadius: 30,
                              spreadRadius: 2,
                            ),
                          ],
                        ),
                        child: Stack(
                          children: [
                            // Top M-stripe
                            Positioned(
                              top: 0,
                              left: 0,
                              right: 0,
                              child: ClipRRect(
                                borderRadius: const BorderRadius.only(
                                  topLeft: Radius.circular(16),
                                  topRight: Radius.circular(16),
                                ),
                                child: Container(
                                  height: 3,
                                  decoration: const BoxDecoration(
                                    gradient: LinearGradient(
                                      colors: [
                                        bmwLightBlue,
                                        bmwDarkBlue,
                                        bmwRed,
                                      ],
                                      stops: [0.0, 0.5, 1.0],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.fromLTRB(28, 32, 28, 28),
                              child: Form(
                                key: _formKey,
                                child: Column(
                                  children: [
                                    const Text(
                                      "DRIVER LOGIN",
                                      style: TextStyle(
                                        color: textPrimary,
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold,
                                        fontFamily: 'Orbitron',
                                        letterSpacing: 3,
                                      ),
                                    ),
                                    const SizedBox(height: 6),
                                    Text(
                                      "Enter credentials to start engine",
                                      style: TextStyle(
                                        color: chromeSilver.withOpacity(0.6),
                                        fontSize: 12,
                                        fontFamily: 'ShareTechMono',
                                      ),
                                    ),
                                    const SizedBox(height: 28),

                                    // Username Field
                                    TextFormField(
                                      controller: userController,
                                      style: const TextStyle(
                                          color: textPrimary, fontSize: 15),
                                      decoration: InputDecoration(
                                        labelText: "Username",
                                        labelStyle: const TextStyle(
                                            color: textSecondary,
                                            fontSize: 13),
                                        prefixIcon: const Icon(
                                            Icons.person_outline,
                                            color: bmwBlueGlow,
                                            size: 20),
                                        filled: true,
                                        fillColor:
                                            surfaceColor.withOpacity(0.6),
                                        border: OutlineInputBorder(
                                            borderRadius:
                                                BorderRadius.circular(10),
                                            borderSide: BorderSide(
                                                color: dividerColor,
                                                width: 1)),
                                        enabledBorder: OutlineInputBorder(
                                            borderRadius:
                                                BorderRadius.circular(10),
                                            borderSide: BorderSide(
                                                color:
                                                    chromeSilver.withOpacity(
                                                        0.15),
                                                width: 1)),
                                        focusedBorder: OutlineInputBorder(
                                            borderRadius:
                                                BorderRadius.circular(10),
                                            borderSide: const BorderSide(
                                                color: bmwBlueGlow,
                                                width: 1.5)),
                                        contentPadding:
                                            const EdgeInsets.symmetric(
                                                horizontal: 16,
                                                vertical: 14),
                                      ),
                                      validator: (v) => v == null || v.isEmpty
                                          ? "Please enter username"
                                          : null,
                                    ),
                                    const SizedBox(height: 18),

                                    // Password Field
                                    TextFormField(
                                      controller: passController,
                                      obscureText: _obscurePassword,
                                      style: const TextStyle(
                                          color: textPrimary, fontSize: 15),
                                      decoration: InputDecoration(
                                        labelText: "Password",
                                        labelStyle: const TextStyle(
                                            color: textSecondary,
                                            fontSize: 13),
                                        prefixIcon: const Icon(
                                            Icons.lock_outline,
                                            color: bmwRed,
                                            size: 20),
                                        suffixIcon: IconButton(
                                          icon: Icon(
                                            _obscurePassword
                                                ? Icons.visibility_outlined
                                                : Icons
                                                    .visibility_off_outlined,
                                            color: textSecondary,
                                            size: 20,
                                          ),
                                          onPressed: () => setState(() =>
                                              _obscurePassword =
                                                  !_obscurePassword),
                                        ),
                                        filled: true,
                                        fillColor:
                                            surfaceColor.withOpacity(0.6),
                                        border: OutlineInputBorder(
                                            borderRadius:
                                                BorderRadius.circular(10),
                                            borderSide: BorderSide(
                                                color: dividerColor,
                                                width: 1)),
                                        enabledBorder: OutlineInputBorder(
                                            borderRadius:
                                                BorderRadius.circular(10),
                                            borderSide: BorderSide(
                                                color:
                                                    chromeSilver.withOpacity(
                                                        0.15),
                                                width: 1)),
                                        focusedBorder: OutlineInputBorder(
                                            borderRadius:
                                                BorderRadius.circular(10),
                                            borderSide: const BorderSide(
                                                color: bmwRed,
                                                width: 1.5)),
                                        contentPadding:
                                            const EdgeInsets.symmetric(
                                                horizontal: 16,
                                                vertical: 14),
                                      ),
                                      validator: (v) => v == null || v.isEmpty
                                          ? "Please enter password"
                                          : null,
                                    ),
                                    const SizedBox(height: 28),

                                    // ─── SIGN IN BUTTON (M-GRADIENT) ───
                                    SizedBox(
                                      width: double.infinity,
                                      height: 52,
                                      child: ElevatedButton(
                                        onPressed: isLoading ? null : login,
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor: Colors.transparent,
                                          foregroundColor: Colors.white,
                                          shadowColor: Colors.transparent,
                                          padding: EdgeInsets.zero,
                                          shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(10),
                                          ),
                                        ),
                                        child: Ink(
                                          decoration: BoxDecoration(
                                            gradient: const LinearGradient(
                                              colors: [
                                                bmwLightBlue,
                                                bmwDarkBlue,
                                                bmwRed,
                                              ],
                                              stops: [0.0, 0.5, 1.0],
                                              begin: Alignment.centerLeft,
                                              end: Alignment.centerRight,
                                            ),
                                            borderRadius:
                                                BorderRadius.circular(10),
                                            border: Border.all(
                                              color: chromeSilver
                                                  .withOpacity(0.35),
                                              width: 1,
                                            ),
                                            boxShadow: [
                                              BoxShadow(
                                                color: bmwBlueGlow
                                                    .withOpacity(0.4),
                                                blurRadius: 18,
                                                spreadRadius: 1,
                                              ),
                                              BoxShadow(
                                                color: bmwRed
                                                    .withOpacity(0.25),
                                                blurRadius: 18,
                                                offset: const Offset(6, 0),
                                              ),
                                            ],
                                          ),
                                          child: Container(
                                            alignment: Alignment.center,
                                            child: isLoading
                                                ? const SizedBox(
                                                    width: 22,
                                                    height: 22,
                                                    child:
                                                        CircularProgressIndicator(
                                                      strokeWidth: 2,
                                                      valueColor:
                                                          AlwaysStoppedAnimation<
                                                                  Color>(
                                                              Colors.white),
                                                    ),
                                                  )
                                                : Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    children: const [
                                                      Icon(
                                                          Icons
                                                              .power_settings_new_rounded,
                                                          size: 18),
                                                      SizedBox(width: 10),
                                                      Text(
                                                        "START ENGINE",
                                                        style: TextStyle(
                                                          fontSize: 13,
                                                          fontWeight:
                                                              FontWeight.w800,
                                                          letterSpacing: 2.5,
                                                          fontFamily:
                                                              'Orbitron',
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 32),

                      // ─── FOOTER ───
                      Column(
                        children: [
                          _mStripe(height: 2, width: 140),
                          const SizedBox(height: 16),
                          Text(
                            "© 2026 GHOSTCRASHER · ///M DIVISION",
                            style: TextStyle(
                              color: textSecondary.withOpacity(0.7),
                              fontSize: 10,
                              letterSpacing: 1.5,
                              fontFamily: 'ShareTechMono',
                            ),
                          ),
                          const SizedBox(height: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 3),
                            decoration: BoxDecoration(
                              color: cardColor.withOpacity(0.5),
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                color: chromeSilver.withOpacity(0.15),
                              ),
                            ),
                            child: Text(
                              "BUILD v$appVersion",
                              style: TextStyle(
                                color: chromeSilver.withOpacity(0.6),
                                fontSize: 9,
                                letterSpacing: 1.5,
                                fontFamily: 'ShareTechMono',
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─── CARBON GRID PAINTER ───────────────────────────────────────────────────
class _GridPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF1C69D4).withOpacity(0.04)
      ..strokeWidth = 0.5
      ..style = PaintingStyle.stroke;

    const double spacing = 50;
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}