import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'splash.dart';
import 'main.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with SingleTickerProviderStateMixin {
  final userController = TextEditingController();
  final passController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool isLoading = false;
  bool _obscurePassword = true;
  String? androidId;

  late AnimationController _controller;
  late Animation<double> _fadeAnim;
  late Animation<double> _slideAnim;
  late AnimationController _robotController;
  late Animation<double> _blinkAnim;
  bool _robotBlinking = false;

  // TTS
  final FlutterTts _flutterTts = FlutterTts();

  String get _passwordStrength {
    final p = passController.text;
    if (p.isEmpty) return "WAITING FOR PASSWORD";
    if (p.length < 6) return "WEAK • TOO SHORT";
    final hasUpper = p.contains(RegExp(r'[A-Z]'));
    final hasLower = p.contains(RegExp(r'[a-z]'));
    final hasDigit = p.contains(RegExp(r'[0-9]'));
    final hasSymbol = p.contains(RegExp(r'[^A-Za-z0-9]'));
    final score = [hasUpper, hasLower, hasDigit, hasSymbol].where((v) => v).length + (p.length >= 10 ? 1 : 0);
    if (score <= 2) return "MEDIUM • ADD NUMBERS / SYMBOLS";
    if (score <= 4) return "STRONG • NICE PASSWORD";
    return "VERY STRONG • LOCKED IN";
  }

  Color get _passwordStrengthColor {
    final p = passController.text;
    if (p.isEmpty) return const Color(0xFF7D849B);
    if (p.length < 6) return const Color(0xFFFF5D73);
    final hasUpper = p.contains(RegExp(r'[A-Z]'));
    final hasLower = p.contains(RegExp(r'[a-z]'));
    final hasDigit = p.contains(RegExp(r'[0-9]'));
    final hasSymbol = p.contains(RegExp(r'[^A-Za-z0-9]'));
    final score = [hasUpper, hasLower, hasDigit, hasSymbol].where((v) => v).length + (p.length >= 10 ? 1 : 0);
    return score <= 2 ? const Color(0xFFFFB84D) : const Color(0xFF39E6B0);
  }

  // === PALET WARNA BARU: DARK RED COMIC ===
  static const Color primaryRed = Color(0xFF8B0000);       // merah gelap utama
  static const Color darkRed = Color(0xFF1A0A0A);           // merah sangat gelap
  static const Color accentRed = Color(0xFFD32F2F);         // aksen merah
  static const Color backgroundColor = Color(0xFF0F0505);   // background merah-hitam
  static const Color cardColor = Color(0xFF2A0E0E);         // kartu merah gelap
  static const Color surfaceColor = Color(0xFF3D1414);      // permukaan merah
  static const Color textPrimary = Color(0xFFFFF5F5);
  static const Color textSecondary = Color(0xFFC9A0A0);
  static const Color dividerColor = Color(0xFF4A1A1A);
  static const Color buttonYellow = Color(0xFFB8860B);      // kuning gelap (dark goldenrod)
  static const Color comicBlack = Color(0xFF000000);        // garis hitam kartun
  static const Color comicOutline = Color(0xFF1A0000);      // outline hitam kemerahan

  String appVersion = "6.3";

  @override
  void initState() {
    super.initState();
    _initAnim();
    _robotController = AnimationController(vsync: this, duration: const Duration(milliseconds: 260));
    _blinkAnim = Tween<double>(begin: 1, end: 0.08).animate(CurvedAnimation(parent: _robotController, curve: Curves.easeInOut));
    passController.addListener(() { if (mounted) setState(() {}); });
    _initTts();
    _initAndLoad();
  }

  // === INISIALISASI TTS ROBOT ===
  Future<void> _initTts() async {
    try {
      await _flutterTts.setLanguage("id-ID");
      await _flutterTts.setSpeechRate(0.45);   // lambat seperti robot
      await _flutterTts.setVolume(1.0);
      await _flutterTts.setPitch(0.6);         // pitch rendah = suara robot
      // Coba pilih voice robot jika tersedia
      if (Theme.of(context).platform == TargetPlatform.android) {
        await _flutterTts.setEngine("com.google.android.tts");
      }
    } catch (_) {}
  }

  Future<void> _speakWelcome() async {
    try {
      await _flutterTts.stop();
      await _flutterTts.setPitch(0.5);
      await _flutterTts.setSpeechRate(0.4);
      await _flutterTts.speak("Selamat datang di X SPYDER");
    } catch (_) {}
  }

  Future<void> _initAndLoad() async {
    androidId = await getAndroidId();
    try {
      final info = await PackageInfo.fromPlatform();
      if (mounted) setState(() => appVersion = info.version);
    } catch (_) {}
    await initLogin();
  }

  void _initAnim() {
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..forward();

    _fadeAnim = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );

    _slideAnim = Tween<double>(begin: 50, end: 0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOut),
    );
  }

  Future<void> initLogin() async {
    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString("username");
    final savedPass = prefs.getString("password");
    final savedKey = prefs.getString("key");

    if (savedUser != null && savedPass != null && savedKey != null) {
      final uri = Uri.parse(
          "http://shinoa-cpanelpanel.xtxintax.my.id:2003/myInfo?username=$savedUser&password=$savedPass&androidId=$androidId&key=$savedKey");

      try {
        final res = await http.get(uri);
        final data = jsonDecode(res.body);

        if (data['valid'] == true && data['expired'] != true) {
          if (!mounted) return;
          Navigator.pushReplacement(
            context,
            PageRouteBuilder(
              pageBuilder: (_, __, ___) => SplashScreen(
                username: savedUser,
                password: savedPass,
                role: data['role'],
                sessionKey: data['key'],
                expiredDate: data['expiredDate'],
                listBug: (data['listBug'] as List? ?? [])
                    .map((e) => Map<String, dynamic>.from(e as Map))
                    .toList(),
                listDoos: (data['listDDoS'] as List? ?? [])
                    .map((e) => Map<String, dynamic>.from(e as Map))
                    .toList(),
                news: (data['news'] as List? ?? [])
                    .map((e) => Map<String, dynamic>.from(e as Map))
                    .toList(),
              ),
              transitionDuration: const Duration(milliseconds: 400),
              transitionsBuilder: (_, animation, __, child) =>
                  FadeTransition(opacity: animation, child: child),
            ),
          );
        } else if (data['reason'] == 'device') {
          if (!mounted) return;
          _showPopup(
            title: "Device Mismatch",
            message: "Akun ini sudah digunakan di perangkat lain.",
            color: accentRed,
          );
        }
      } catch (_) {}
    }
  }

  Future<String> getAndroidId() async {
    final deviceInfo = DeviceInfoPlugin();
    final android = await deviceInfo.androidInfo;
    return android.id;
  }

  Future<void> login() async {
    if (!_formKey.currentState!.validate()) return;

    // === SUARA ROBOT TTS SAAT LOGIN DITEKAN ===
    _speakWelcome();

    final username = userController.text.trim();
    final password = passController.text.trim();

    setState(() => isLoading = true);

    try {
      androidId ??= await getAndroidId();

      if (username == "Cloude" && password == "syamanjing") {
        if (!mounted) return;
        Navigator.pushReplacement(
          context,
          PageRouteBuilder(
            pageBuilder: (_, __, ___) => SplashScreen(
              username: username,
              password: password,
              role: "owner_utama",
              sessionKey: "local_key",
              expiredDate:
                  DateTime.now().add(const Duration(days: 365)).toString(),
              listBug: [],
              listDoos: [],
              news: [],
            ),
            transitionDuration: const Duration(milliseconds: 400),
            transitionsBuilder: (_, animation, __, child) =>
                FadeTransition(opacity: animation, child: child),
          ),
        );
        setState(() => isLoading = false);
        return;
      }

      final validate = await http.post(
        Uri.parse("http://shinoa-cpanelpanel.xtxintax.my.id:2003/validate"),
        body: {
          "username": username,
          "password": password,
          "androidId": androidId!,
          "version": appVersion,
        },
      );

      final validData = jsonDecode(validate.body);

      if (!mounted) return;

      if (validData['expired'] == true) {
        _showPopup(
          title: "Access Expired",
          message: "Your access has expired.\nPlease renew it.",
          color: Colors.orange,
          showContact: true,
        );
      } else if (validData['valid'] != true) {
        _showPopup(
          title: "Login Failed",
          message: "Invalid username or password.",
          color: accentRed,
        );
      } else {
        final prefs = await SharedPreferences.getInstance();
        prefs.setString("username", username);
        prefs.setString("password", password);
        prefs.setString("key", validData['key']);

        if (!mounted) return;
        Navigator.pushReplacement(
          context,
          PageRouteBuilder(
            pageBuilder: (_, __, ___) => SplashScreen(
              username: username,
              password: password,
              role: validData['role'],
              sessionKey: validData['key'],
              expiredDate: validData['expiredDate'],
              listBug: (validData['listBug'] as List? ?? [])
                  .map((e) => Map<String, dynamic>.from(e as Map))
                  .toList(),
              listDoos: (validData['listDDoS'] as List? ?? [])
                  .map((e) => Map<String, dynamic>.from(e as Map))
                  .toList(),
              news: (validData['news'] as List? ?? [])
                  .map((e) => Map<String, dynamic>.from(e as Map))
                  .toList(),
            ),
            transitionDuration: const Duration(milliseconds: 400),
            transitionsBuilder: (_, animation, __, child) =>
                FadeTransition(opacity: animation, child: child),
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;
      _showPopup(
        title: "Connection Error",
        message:
            "Failed to connect to the server.\nPlease check your internet connection.",
        color: accentRed,
      );
    }

    if (mounted) setState(() => isLoading = false);
  }

  void _showPopup({
    required String title,
    required String message,
    Color color = primaryRed,
    bool showContact = false,
  }) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          decoration: BoxDecoration(
            color: cardColor,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: comicBlack, width: 3),
            boxShadow: const [
              BoxShadow(color: comicBlack, offset: Offset(5, 5), blurRadius: 0),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: color.withOpacity(0.15),
                    border: Border.all(color: comicBlack, width: 2.5),
                  ),
                  child: Icon(
                    color == Colors.orange ? Icons.warning : Icons.error,
                    color: color,
                    size: 24,
                  ),
                ),
                const SizedBox(height: 16),
                Text(title,
                    style: const TextStyle(
                        color: textPrimary,
                        fontSize: 18,
                        fontWeight: FontWeight.w900)),
                const SizedBox(height: 12),
                Text(message,
                    style: const TextStyle(
                        color: textSecondary, fontSize: 14, height: 1.5),
                    textAlign: TextAlign.center),
                const SizedBox(height: 24),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    if (showContact)
                      OutlinedButton(
                        onPressed: () async {
                          final uri = Uri.parse("https://t.me/dilzxxwkwk");
                          await launchUrl(uri,
                              mode: LaunchMode.externalApplication);
                        },
                        style: OutlinedButton.styleFrom(
                          foregroundColor: textSecondary,
                          side: const BorderSide(color: comicBlack, width: 2),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 8),
                        ),
                        child: const Text("Contact Admin",
                            style: TextStyle(fontSize: 13)),
                      ),
                    const SizedBox(width: 8),
                    ElevatedButton(
                      onPressed: () => Navigator.pop(context),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: primaryRed,
                        foregroundColor: Colors.white,
                        side: const BorderSide(color: comicBlack, width: 2.5),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 8),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      child: const Text("Close",
                          style: TextStyle(fontWeight: FontWeight.w800)),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    _robotController.dispose();
    userController.dispose();
    passController.dispose();
    _flutterTts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: backgroundColor,
      body: Stack(
        children: [
          Positioned.fill(child: CustomPaint(painter: _ComicSpacePainter())),
          SafeArea(
            child: AnimatedBuilder(
              animation: _controller,
              builder: (context, child) => Transform.translate(
                offset: Offset(0, _slideAnim.value),
                child: Opacity(opacity: _fadeAnim.value, child: child),
              ),
              child: Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(22, 28, 22, 24),
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 430),
                    child: Column(
                      children: [
                        // === HEADER DENGAN WARNA MERAH ===
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              width: 12,
                              height: 12,
                              decoration: BoxDecoration(
                                color: primaryRed,
                                shape: BoxShape.circle,
                                border: Border.all(color: comicBlack, width: 2.5),
                              ),
                            ),
                            const SizedBox(width: 9),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: cardColor,
                                border: Border.all(color: comicBlack, width: 2.5),
                                borderRadius: BorderRadius.circular(6),
                                boxShadow: const [
                                  BoxShadow(color: comicBlack, offset: Offset(3, 3), blurRadius: 0),
                                ],
                              ),
                              child: const Text(
                                'X-SPYDER // ACCESS GATE',
                                style: TextStyle(
                                  color: textPrimary,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 2,
                                ),
                              ),
                            ),
                            const SizedBox(width: 9),
                            Container(
                              width: 12,
                              height: 12,
                              decoration: BoxDecoration(
                                color: accentRed,
                                shape: BoxShape.circle,
                                border: Border.all(color: comicBlack, width: 2.5),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 18),
                        // === ROBOT KARTUN ===
                        AnimatedBuilder(
                          animation: _blinkAnim,
                          builder: (_, __) => GestureDetector(
                            onTap: () async {
                              if (_robotController.isAnimating) return;
                              await _robotController.forward();
                              await _robotController.reverse();
                            },
                            child: CustomPaint(
                              size: const Size(230, 188),
                              painter: _ComicRobotPainter(
                                  eyeOpen: _blinkAnim.value,
                                  isLoading: isLoading),
                            ),
                          ),
                        ),
                        const SizedBox(height: 8),
                        // === SPEECH BUBBLE ROBOT ===
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 18, vertical: 12),
                          decoration: BoxDecoration(
                            color: cardColor,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: comicBlack, width: 3),
                            boxShadow: const [
                              BoxShadow(
                                  color: comicBlack,
                                  offset: Offset(4, 4),
                                  blurRadius: 0),
                            ],
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Container(
                                width: 10,
                                height: 10,
                                decoration: BoxDecoration(
                                  color: accentRed,
                                  shape: BoxShape.circle,
                                  border: Border.all(color: comicBlack, width: 2),
                                ),
                              ),
                              const SizedBox(width: 9),
                              Text(
                                isLoading
                                    ? 'Checking credentials...'
                                    : 'Beep boop. Identify yourself.',
                                style: const TextStyle(
                                    color: textPrimary,
                                    fontSize: 13,
                                    fontWeight: FontWeight.w800),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 18),
                        // === KARTU LOGIN UTAMA ===
                        Container(
                          width: width,
                          padding: const EdgeInsets.fromLTRB(22, 24, 22, 22),
                          decoration: BoxDecoration(
                            color: cardColor,
                            borderRadius: BorderRadius.circular(28),
                            border: Border.all(color: comicBlack, width: 3.5),
                            boxShadow: const [
                              BoxShadow(
                                  color: comicBlack,
                                  offset: Offset(8, 8),
                                  blurRadius: 0),
                            ],
                          ),
                          child: Form(
                            key: _formKey,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text('WELCOME, PILOT.',
                                    style: TextStyle(
                                        color: textPrimary,
                                        fontSize: 25,
                                        fontWeight: FontWeight.w900,
                                        letterSpacing: 1)),
                                const SizedBox(height: 6),
                                const Text(
                                    'Enter your credentials to unlock the X-SPYDER core.',
                                    style: TextStyle(
                                        color: textSecondary,
                                        fontSize: 13,
                                        height: 1.4)),
                                const SizedBox(height: 24),
                                _comicLabel('USERNAME'),
                                const SizedBox(height: 8),
                                _comicField(
                                  controller: userController,
                                  hint: 'Your username',
                                  icon: Icons.person_rounded,
                                  obscure: false,
                                  onToggle: null,
                                  validator: (v) => v == null || v.trim().isEmpty
                                      ? 'Please enter username'
                                      : null,
                                ),
                                const SizedBox(height: 17),
                                _comicLabel('PASSWORD'),
                                const SizedBox(height: 8),
                                _comicField(
                                  controller: passController,
                                  hint: 'Your secret password',
                                  icon: Icons.lock_rounded,
                                  obscure: _obscurePassword,
                                  onToggle: () => setState(
                                      () => _obscurePassword = !_obscurePassword),
                                  validator: (v) =>
                                      v == null || v.isEmpty
                                          ? 'Please enter password'
                                          : null,
                                ),
                                const SizedBox(height: 10),
                                Row(
                                  children: [
                                    Expanded(
                                      child: ClipRRect(
                                        borderRadius: BorderRadius.circular(8),
                                        child: LinearProgressIndicator(
                                          value: passController.text.isEmpty
                                              ? 0
                                              : (_passwordStrength
                                                      .startsWith('WEAK')
                                                  ? .25
                                                  : _passwordStrength
                                                          .startsWith('MEDIUM')
                                                      ? .55
                                                      : _passwordStrength
                                                              .startsWith(
                                                                  'STRONG')
                                                          ? .8
                                                          : 1),
                                          minHeight: 6,
                                          backgroundColor:
                                              const Color(0xFF3D1414),
                                          valueColor: AlwaysStoppedAnimation(
                                              _passwordStrengthColor),
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 10),
                                    Text(_passwordStrength,
                                        style: TextStyle(
                                            color: _passwordStrengthColor,
                                            fontSize: 9,
                                            fontWeight: FontWeight.w900,
                                            letterSpacing: .5)),
                                  ],
                                ),
                                const SizedBox(height: 24),
                                // === TOMBOL LOGIN KUNING GELAP GAYA KARTUN 3D ===
                                SizedBox(
                                  width: double.infinity,
                                  height: 62,
                                  child: Container(
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(16),
                                      boxShadow: const [
                                        BoxShadow(
                                          color: comicBlack,
                                          offset: Offset(0, 6),
                                          blurRadius: 0,
                                        ),
                                      ],
                                    ),
                                    child: ElevatedButton(
                                      onPressed: isLoading ? null : login,
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: buttonYellow,
                                        foregroundColor: comicBlack,
                                        elevation: 0,
                                        padding: EdgeInsets.zero,
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(16),
                                          side: const BorderSide(
                                              color: comicBlack, width: 3.5),
                                        ),
                                      ),
                                      child: isLoading
                                          ? const SizedBox(
                                              width: 24,
                                              height: 24,
                                              child:
                                                  CircularProgressIndicator(
                                                      strokeWidth: 3,
                                                      color: comicBlack),
                                            )
                                          : const Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                Icon(Icons.login_rounded,
                                                    size: 22,
                                                    color: comicBlack),
                                                SizedBox(width: 10),
                                                Text(
                                                  'LOGIN',
                                                  style: TextStyle(
                                                    fontSize: 18,
                                                    fontWeight: FontWeight.w900,
                                                    letterSpacing: 2,
                                                    color: comicBlack,
                                                  ),
                                                ),
                                                SizedBox(width: 10),
                                                Icon(
                                                    Icons
                                                        .arrow_forward_rounded,
                                                    size: 22,
                                                    color: comicBlack),
                                              ],
                                            ),
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 16),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    const Icon(Icons.shield_outlined,
                                        size: 14, color: textSecondary),
                                    const SizedBox(width: 6),
                                    Text('SECURE SESSION  •  v$appVersion',
                                        style: const TextStyle(
                                            color: textSecondary,
                                            fontSize: 10,
                                            fontWeight: FontWeight.w700,
                                            letterSpacing: .6)),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 18),
                        const Text('© 2026 X-SPYDER CORE SYSTEMS',
                            style: TextStyle(
                                color: Color(0xFF7A5050),
                                fontSize: 10,
                                letterSpacing: 1.4,
                                fontWeight: FontWeight.w700)),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _comicLabel(String text) => Text(text,
      style: const TextStyle(
          color: textSecondary,
          fontSize: 10,
          fontWeight: FontWeight.w900,
          letterSpacing: 1.5));

  Widget _comicField({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    required bool obscure,
    required VoidCallback? onToggle,
    required String? Function(String?) validator,
  }) {
    return TextFormField(
      controller: controller,
      obscureText: obscure,
      validator: validator,
      style: const TextStyle(
          color: textPrimary, fontSize: 14, fontWeight: FontWeight.w700),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: Color(0xFF8A6060), fontSize: 13),
        prefixIcon: Icon(icon, color: const Color(0xFFB08080), size: 21),
        suffixIcon: onToggle == null
            ? null
            : IconButton(
                onPressed: onToggle,
                icon: Icon(
                    obscure
                        ? Icons.visibility_rounded
                        : Icons.visibility_off_rounded,
                    color: const Color(0xFFB08080))),
        filled: true,
        fillColor: const Color(0xFF1A0808),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: comicBlack, width: 3)),
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: comicBlack, width: 3)),
        focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: accentRed, width: 3)),
        errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: Color(0xFFFF4D78), width: 3)),
      ),
    );
  }
}

// === BACKGROUND PAINTER MERAH GELAP ===
class _ComicSpacePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final bg = Paint()..color = const Color(0xFF0F0505);
    canvas.drawRect(Offset.zero & size, bg);

    // Titik-titik pola
    final dots = Paint()..color = const Color(0xFF2A0E0E);
    for (double x = 10; x < size.width; x += 27) {
      for (double y = 10; y < size.height; y += 27) {
        canvas.drawCircle(Offset(x, y), 1.2, dots);
      }
    }

    // Garis diagonal
    final line = Paint()
      ..color = const Color(0xFF3D1414)
      ..strokeWidth = 1.5;
    for (double y = 100; y < size.height; y += 180) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y + 35), line);
    }

    // Aksen merah
    final slash = Paint()
      ..color = const Color(0xFF8B0000).withOpacity(.25)
      ..strokeWidth = 4
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(Offset(size.width * .05, size.height * .35),
        Offset(size.width * .35, size.height * .18), slash);
    canvas.drawLine(Offset(size.width * .72, size.height * .75),
        Offset(size.width * .98, size.height * .62), slash);

    // Bintang kecil merah
    final star = Paint()..color = const Color(0xFFD32F2F).withOpacity(.4);
    canvas.drawCircle(Offset(size.width * .15, size.height * .12), 3, star);
    canvas.drawCircle(Offset(size.width * .88, size.height * .45), 2.5, star);
    canvas.drawCircle(Offset(size.width * .25, size.height * .88), 2, star);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// === ROBOT KARTUN DENGAN OUTLINE HITAM ===
class _ComicRobotPainter extends CustomPainter {
  final double eyeOpen;
  final bool isLoading;
  _ComicRobotPainter({required this.eyeOpen, required this.isLoading});

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final p = Paint()..style = PaintingStyle.fill;
    final outline = Paint()
      ..style = PaintingStyle.stroke
      ..color = const Color(0xFF000000)
      ..strokeWidth = 3.5
      ..strokeJoin = StrokeJoin.round;

    // Kepala robot (merah gelap)
    final headRect = RRect.fromRectAndRadius(
        Rect.fromLTWH(cx - 75, 35, 150, 112), const Radius.circular(32));
    p.color = const Color(0xFF8B0000);
    canvas.drawRRect(headRect, p);
    canvas.drawRRect(headRect, outline);

    // Wajah/layar gelap
    final faceRect = RRect.fromRectAndRadius(
        Rect.fromLTWH(cx - 58, 53, 116, 76), const Radius.circular(24));
    p.color = const Color(0xFF1A0808);
    canvas.drawRRect(faceRect, p);
    canvas.drawRRect(faceRect, outline);

    // Telinga robot
    final earL = RRect.fromRectAndRadius(
        Rect.fromLTWH(cx - 88, 65, 15, 47), const Radius.circular(8));
    final earR = RRect.fromRectAndRadius(
        Rect.fromLTWH(cx + 73, 65, 15, 47), const Radius.circular(8));
    p.color = const Color(0xFF5C1010);
    canvas.drawRRect(earL, p);
    canvas.drawRRect(earR, p);
    canvas.drawRRect(earL, outline);
    canvas.drawRRect(earR, outline);

    // Lampu telinga
    p.color = const Color(0xFFFF4D4D);
    canvas.drawRRect(
        RRect.fromRectAndRadius(
            Rect.fromLTWH(cx - 82, 77, 5, 22), const Radius.circular(3)),
        p);
    canvas.drawRRect(
        RRect.fromRectAndRadius(
            Rect.fromLTWH(cx + 77, 77, 5, 22), const Radius.circular(3)),
        p);

    // Mata merah menyala
    final eye = Paint()..color = const Color(0xFFFF3B3B);
    final eyeRectL = Rect.fromCenter(
        center: Offset(cx - 27, 87), width: 25, height: 25 * eyeOpen);
    final eyeRectR = Rect.fromCenter(
        center: Offset(cx + 27, 87), width: 25, height: 25 * eyeOpen);
    canvas.drawOval(eyeRectL, eye);
    canvas.drawOval(eyeRectR, eye);
    canvas.drawOval(eyeRectL, outline);
    canvas.drawOval(eyeRectR, outline);

    // Kilau mata
    p.color = Colors.white;
    canvas.drawCircle(Offset(cx - 23, 84), 4, p);
    canvas.drawCircle(Offset(cx + 31, 84), 4, p);

    // Mulut
    final mouth = RRect.fromRectAndRadius(
        Rect.fromLTWH(cx - 9, 111, 18, 5), const Radius.circular(3));
    p.color = const Color(0xFFFF3B3B);
    canvas.drawRRect(mouth, p);
    canvas.drawRRect(mouth, outline);

    // Pipi blush merah
    p.color = const Color(0xFFFF5D73);
    canvas.drawCircle(Offset(cx - 43, 117), 5, p);
    canvas.drawCircle(Offset(cx + 43, 117), 5, p);

    // Antena
    final antenna = Paint()
      ..color = const Color(0xFF000000)
      ..strokeWidth = 5
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(Offset(cx, 35), Offset(cx, 18), antenna);

    // Bola antena
    final antBall = Paint()..color = isLoading
        ? const Color(0xFFFFB84D)
        : const Color(0xFFFF3B3B);
    canvas.drawCircle(Offset(cx, 12), 8, antBall);
    final antOutline = Paint()
      ..style = PaintingStyle.stroke
      ..color = const Color(0xFF000000)
      ..strokeWidth = 3;
    canvas.drawCircle(Offset(cx, 12), 8, antOutline);
    p.color = const Color(0xFF1A0808);
    canvas.drawCircle(Offset(cx, 12), 3, p);
  }

  @override
  bool shouldRepaint(covariant _ComicRobotPainter oldDelegate) =>
      oldDelegate.eyeOpen != eyeOpen || oldDelegate.isLoading != isLoading;
}

class _DotsPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF4A1A1A).withOpacity(0.15)
      ..style = PaintingStyle.fill;

    const double spacing = 40;
    const double radius = 1.5;

    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        canvas.drawCircle(Offset(x, y), radius, paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}