import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'api_config.dart';
import 'splash.dart';

class _C {
  static const bg = Color(0xFF08080A);
  static const surface = Color(0xFF0F0F13);
  static const card = Color(0xFF18181E);
  static const cardAlt = Color(0xFF202028);
  static const border = Color(0xFF2A2A32);
  static const borderLight = Color(0xFF3A3A44);
  static const gold = Color(0xFFD4AF37);
  static const goldLight = Color(0xFFE8C84A);
  static const goldDark = Color(0xFFB8962E);
  static const platinum = Color(0xFFA8A8B8);
  static const silver = Color(0xFF8A8A9A);
  static const rose = Color(0xFFE8B4B8);
  static const text = Color(0xFFEEEEF0);
  static const textSub = Color(0xFF9A9AA8);
  static const textDim = Color(0xFF5A5A68);
  
  static const LinearGradient goldGrad = LinearGradient(
    colors: [Color(0xFFD4AF37), Color(0xFFE8C84A), Color(0xFFB8962E)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  static const LinearGradient darkGoldGrad = LinearGradient(
    colors: [Color(0xFF2A2520), Color(0xFF1A1815)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with TickerProviderStateMixin, SingleTickerProviderStateMixin {
  final userCtrl = TextEditingController();
  final passCtrl = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool _isLoading = false;
  bool _obscurePass = true;
  String? _androidId;

  late AnimationController _bgCtrl;
  late AnimationController _entranceCtrl;
  late AnimationController _glowCtrl;
  late AnimationController _particleCtrl;

  late Animation<double> _fade;
  late Animation<Offset> _slide;
  late Animation<double> _glowPulse;
  late Animation<double> _particleRotate;

  @override
  void initState() {
    super.initState();

    _bgCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 24))
      ..repeat();

    _entranceCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1200));
    _fade = CurvedAnimation(
        parent: _entranceCtrl, curve: Curves.easeOutCubic);
    _slide = Tween<Offset>(begin: const Offset(0, 0.08), end: Offset.zero)
        .animate(CurvedAnimation(
            parent: _entranceCtrl, curve: Curves.easeOutQuint));

    _glowCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 3))
      ..repeat(reverse: true);
    _glowPulse = Tween<double>(begin: 0.6, end: 1.0)
        .animate(CurvedAnimation(
            parent: _glowCtrl, curve: Curves.easeInOutSine));

    _particleCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 20))
      ..repeat();
    _particleRotate = Tween<double>(begin: 0, end: 2 * math.pi)
        .animate(CurvedAnimation(
            parent: _particleCtrl, curve: Curves.linear));

    _entranceCtrl.forward();
    _initLogin();
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    _entranceCtrl.dispose();
    _glowCtrl.dispose();
    _particleCtrl.dispose();
    userCtrl.dispose();
    passCtrl.dispose();
    super.dispose();
  }

  Future<void> _initLogin() async {
    final info = await DeviceInfoPlugin().androidInfo;
    _androidId = info.id;

    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString('username');
    final savedPass = prefs.getString('password');
    final savedKey = prefs.getString('key');

    if (savedUser != null && savedPass != null && savedKey != null) {
      try {
        final res = await http.get(Uri.parse(
            '$baseUrl/myInfo?username=$savedUser&password=$savedPass&androidId=$_androidId&key=$savedKey'));
        final data = jsonDecode(res.body);

        if (data['valid'] == true && mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => SplashScreen(
              username: savedUser,
              password: savedPass,
              role: data['role'],
              sessionKey: data['key'],
              expiredDate: data['expiredDate'],
              listBug: _parseList(data['listBug']),
              listGb: _parseList(data['listGb']),
              news: _parseList(data['news']),
            )),
          );
        }
      } catch (_) {}
    }
  }

  List<Map<String, dynamic>> _parseList(dynamic raw) =>
      (raw as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;

    final username = userCtrl.text.trim();
    final password = passCtrl.text.trim();

    setState(() => _isLoading = true);

    try {
      final res = await http.post(Uri.parse('$baseUrl/validate'), body: {
        'username': username,
        'password': password,
        'androidId': _androidId ?? 'unknown',
      });
      final data = jsonDecode(res.body);

      if (data['expired'] == true) {
        _showAlert(
          title: 'Access Expired',
          message: 'Your access period has ended. Please renew.',
          type: _AlertType.warning,
          showContact: true,
        );
      } else if (data['valid'] != true) {
        final msg = (data['message'] ?? '').toString().toLowerCase();
        if (msg.contains('perangkat') || msg.contains('device') ||
            msg.contains('another')) {
          _showAlert(
            title: 'Active Session',
            message: 'This account is logged in on another device.',
            type: _AlertType.warning,
          );
        } else {
          _showAlert(
            title: 'Login Failed',
            message: 'Invalid username or password.',
            type: _AlertType.error,
          );
        }
      } else {
        final prefs = await SharedPreferences.getInstance();
        prefs.setString('username', username);
        prefs.setString('password', password);
        prefs.setString('key', data['key']);

        if (mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => SplashScreen(
              username: username,
              password: password,
              role: data['role'],
              sessionKey: data['key'],
              expiredDate: data['expiredDate'],
              listBug: _parseList(data['listBug']),
              listGb: _parseList(data['listGb']),
              news: _parseList(data['news']),
            )),
          );
        }
      }
    } catch (_) {
      _showAlert(
        title: 'Connection Error',
        message: 'Failed to connect to server. Check your network.',
        type: _AlertType.error,
      );
    }

    if (mounted) setState(() => _isLoading = false);
  }

  void _showAlert({
    required String title,
    required String message,
    required _AlertType type,
    bool showContact = false,
  }) {
    final color = switch (type) {
      _AlertType.error => const Color(0xFFE8A0A0),
      _AlertType.warning => const Color(0xFFE8C84A),
      _AlertType.success => const Color(0xFF7CCF9E),
    };
    final icon = switch (type) {
      _AlertType.error => Icons.close_rounded,
      _AlertType.warning => Icons.warning_rounded,
      _AlertType.success => Icons.check_rounded,
    };

    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: '',
      barrierColor: Colors.black.withOpacity(0.8),
      transitionDuration: const Duration(milliseconds: 400),
      transitionBuilder: (_, anim, __, child) => FadeTransition(
        opacity: CurvedAnimation(parent: anim, curve: Curves.easeOutQuart),
        child: ScaleTransition(
          scale: CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
          child: child,
        ),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24),
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [_C.card, _C.surface],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(32),
            border: Border.all(
              color: color.withOpacity(0.3),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.1),
                blurRadius: 40,
                spreadRadius: 4,
              ),
            ],
          ),
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 72,
                height: 72,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [color.withOpacity(0.2), color.withOpacity(0.05)],
                  ),
                  border: Border.all(
                    color: color.withOpacity(0.4),
                    width: 2,
                  ),
                ),
                child: Icon(icon, color: color, size: 32),
              ),
              const SizedBox(height: 20),
              Text(
                title,
                style: const TextStyle(
                  color: _C.text,
                  fontSize: 22,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.5,
                  fontFamily: 'Orbitron',
                ),
              ),
              const SizedBox(height: 12),
              Text(
                message,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: _C.textSub,
                  fontSize: 14,
                  height: 1.6,
                ),
              ),
              const SizedBox(height: 28),
              if (showContact) ...[
                _ElegantButton(
                  label: 'CONTACT OWNER',
                  icon: Icons.send_rounded,
                  onTap: () async {
                    Navigator.pop(ctx);
                    await launchUrl(
                      Uri.parse('https://t.me/RixzzNotDev'),
                      mode: LaunchMode.externalApplication,
                    );
                  },
                ),
                const SizedBox(height: 12),
              ],
              _OutlineButton(
                label: showContact ? 'CLOSE' : 'OK',
                onTap: () => Navigator.pop(ctx),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.light,
        child: Stack(
          children: [
            Positioned.fill(
              child: _BackgroundPainter(
                controller: _bgCtrl,
                particleRotate: _particleRotate,
              ),
            ),
            SafeArea(
              child: FadeTransition(
                opacity: _fade,
                child: SlideTransition(
                  position: _slide,
                  child: Center(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 24,
                        vertical: 32,
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          _buildLogo(),
                          const SizedBox(height: 32),
                          _buildHeader(),
                          const SizedBox(height: 40),
                          _buildForm(),
                          const SizedBox(height: 28),
                          _buildFooter(),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLogo() {
    return AnimatedBuilder(
      animation: _glowPulse,
      builder: (_, __) => Stack(
        alignment: Alignment.center,
        children: [
          // Outer glow
          Container(
            width: 160,
            height: 160,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [
                  _C.gold.withOpacity(_glowPulse.value * 0.12),
                  Colors.transparent,
                ],
                radius: 0.9,
              ),
            ),
          ),
          // Ring 1
          Container(
            width: 140,
            height: 140,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: _C.gold.withOpacity(_glowPulse.value * 0.2),
                width: 1.5,
              ),
            ),
          ),
          // Ring 2
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: _C.gold.withOpacity(_glowPulse.value * 0.4),
                width: 2,
              ),
            ),
          ),
          // Logo
          Hero(
            tag: 'logo',
            child: Container(
              width: 90,
              height: 90,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(28),
                gradient: const LinearGradient(
                  colors: [Color(0xFF1A1815), Color(0xFF0F0E0C)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                border: Border.all(
                  color: _C.gold.withOpacity(_glowPulse.value * 0.7),
                  width: 2.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: _C.gold.withOpacity(_glowPulse.value * 0.3),
                    blurRadius: 30,
                    spreadRadius: 4,
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(26),
                child: Image.asset(
                  'assets/images/logo.png',
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Icon(
                    Icons.shield_rounded,
                    color: _C.gold,
                    size: 44,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Column(
      children: [
        ShaderMask(
          shaderCallback: (b) => _C.goldGrad.createShader(b),
          child: const Text(
            'ZENZO X RAT',
            style: TextStyle(
              fontSize: 34,
              fontWeight: FontWeight.w900,
              color: Colors.white,
              letterSpacing: 2,
              fontFamily: 'Orbitron',
              height: 1.1,
            ),
          ),
        ),
        const SizedBox(height: 10),
        Container(
          width: 60,
          height: 2,
          decoration: BoxDecoration(
            gradient: _C.goldGrad,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(height: 14),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
          decoration: BoxDecoration(
            gradient: _C.darkGoldGrad,
            borderRadius: BorderRadius.circular(30),
            border: Border.all(
              color: _C.gold.withOpacity(0.2),
              width: 1,
            ),
          ),
          child: const Text(
            'SECURE ACCESS',
            style: TextStyle(
              color: _C.gold,
              fontSize: 11,
              fontWeight: FontWeight.w600,
              letterSpacing: 3,
              fontFamily: 'Orbitron',
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildForm() {
    return Container(
      padding: const EdgeInsets.all(28),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [_C.card, _C.surface],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(32),
        border: Border.all(
          color: _C.border,
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 40,
            offset: const Offset(0, 20),
          ),
          BoxShadow(
            color: _C.gold.withOpacity(0.03),
            blurRadius: 60,
            offset: const Offset(0, 0),
          ),
        ],
      ),
      child: Form(
        key: _formKey,
        child: Column(
          children: [
            // Header form
            Row(
              children: [
                Container(
                  width: 4,
                  height: 24,
                  decoration: BoxDecoration(
                    gradient: _C.goldGrad,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(width: 14),
                const Icon(
                  Icons.key_rounded,
                  color: _C.gold,
                  size: 18,
                ),
                const SizedBox(width: 10),
                const Text(
                  'CREDENTIALS',
                  style: TextStyle(
                    color: _C.text,
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 2,
                    fontFamily: 'Orbitron',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            // Username field
            _ElegantTextField(
              controller: userCtrl,
              label: 'Username',
              hint: 'Enter your username',
              icon: Icons.person_outline_rounded,
              validator: (v) => (v == null || v.isEmpty)
                  ? 'Username is required'
                  : null,
            ),
            const SizedBox(height: 18),
            // Password field
            _ElegantTextField(
              controller: passCtrl,
              label: 'Password',
              hint: 'Enter your password',
              icon: Icons.lock_outline_rounded,
              obscure: _obscurePass,
              onToggleObscure: () =>
                  setState(() => _obscurePass = !_obscurePass),
              validator: (v) => (v == null || v.isEmpty)
                  ? 'Password is required'
                  : null,
            ),
            const SizedBox(height: 32),
            // Login button
            _LoginActionButton(
              isLoading: _isLoading,
              onTap: _login,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFooter() {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              'Need access? ',
              style: TextStyle(
                color: _C.textSub,
                fontSize: 13,
              ),
            ),
            GestureDetector(
              onTap: () => launchUrl(
                Uri.parse('https://t.me/RixzzNotDev'),
                mode: LaunchMode.externalApplication,
              ),
              child: ShaderMask(
                shaderCallback: (b) => _C.goldGrad.createShader(b),
                child: const Text(
                  'Contact Owner',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.5,
                  ),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 4,
              height: 4,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _C.gold.withOpacity(0.5),
              ),
            ),
            const SizedBox(width: 10),
            const Text(
              'ZENZO X EYE',
              style: TextStyle(
                color: _C.textDim,
                fontSize: 11,
                fontWeight: FontWeight.w500,
                letterSpacing: 0.5,
              ),
            ),
            const SizedBox(width: 10),
            Container(
              width: 4,
              height: 4,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _C.gold.withOpacity(0.5),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

// ========== Elegant Text Field ==========
class _ElegantTextField extends StatefulWidget {
  final TextEditingController controller;
  final String label;
  final String hint;
  final IconData icon;
  final bool obscure;
  final VoidCallback? onToggleObscure;
  final String? Function(String?)? validator;

  const _ElegantTextField({
    required this.controller,
    required this.label,
    required this.hint,
    required this.icon,
    this.obscure = false,
    this.onToggleObscure,
    this.validator,
  });

  @override
  State<_ElegantTextField> createState() => _ElegantTextFieldState();
}

class _ElegantTextFieldState extends State<_ElegantTextField> {
  bool _focused = false;
  final _focus = FocusNode();

  @override
  void initState() {
    super.initState();
    _focus.addListener(() => setState(() => _focused = _focus.hasFocus));
  }

  @override
  void dispose() {
    _focus.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      decoration: BoxDecoration(
        color: _C.bg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: _focused ? _C.gold : _C.border,
          width: _focused ? 1.5 : 1,
        ),
        boxShadow: _focused
            ? [
                BoxShadow(
                  color: _C.gold.withOpacity(0.08),
                  blurRadius: 20,
                  offset: const Offset(0, 4),
                ),
              ]
            : [],
      ),
      child: TextFormField(
        controller: widget.controller,
        focusNode: _focus,
        obscureText: widget.obscure,
        validator: widget.validator,
        style: const TextStyle(
          color: _C.text,
          fontSize: 15,
          fontWeight: FontWeight.w500,
          letterSpacing: 0.3,
        ),
        cursorColor: _C.gold,
        decoration: InputDecoration(
          labelText: widget.label,
          labelStyle: TextStyle(
            color: _focused ? _C.gold : _C.textSub,
            fontSize: 12,
            fontWeight: FontWeight.w600,
            letterSpacing: 0.5,
          ),
          hintText: widget.hint,
          hintStyle: TextStyle(
            color: _C.textDim,
            fontSize: 14,
            fontWeight: FontWeight.w400,
          ),
          prefixIcon: Icon(
            widget.icon,
            color: _focused ? _C.gold : _C.textSub,
            size: 20,
          ),
          suffixIcon: widget.onToggleObscure != null
              ? IconButton(
                  icon: Icon(
                    widget.obscure
                        ? Icons.visibility_off_rounded
                        : Icons.visibility_rounded,
                    color: _focused ? _C.gold : _C.textSub,
                    size: 20,
                  ),
                  onPressed: widget.onToggleObscure,
                )
              : null,
          errorStyle: const TextStyle(
            color: Color(0xFFE8A0A0),
            fontSize: 11,
            fontWeight: FontWeight.w500,
          ),
          border: InputBorder.none,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 18, vertical: 18),
        ),
      ),
    );
  }
}

// ========== Login Action Button ==========
class _LoginActionButton extends StatefulWidget {
  final bool isLoading;
  final VoidCallback onTap;

  const _LoginActionButton({
    required this.isLoading,
    required this.onTap,
  });

  @override
  State<_LoginActionButton> createState() => _LoginActionButtonState();
}

class _LoginActionButtonState extends State<_LoginActionButton> {
  bool _hovered = false;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) => setState(() => _hovered = true),
      onExit: (_) => setState(() => _hovered = false),
      child: GestureDetector(
        onTap: widget.isLoading ? null : widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          height: 58,
          width: double.infinity,
          decoration: BoxDecoration(
            gradient: widget.isLoading
                ? const LinearGradient(
                    colors: [Color(0xFF2A2A32), Color(0xFF1A1A22)],
                  )
                : _C.goldGrad,
            borderRadius: BorderRadius.circular(18),
            boxShadow: widget.isLoading || !_hovered
                ? []
                : [
                    BoxShadow(
                      color: _C.gold.withOpacity(0.4),
                      blurRadius: 30,
                      offset: const Offset(0, 10),
                    ),
                  ],
          ),
          child: Center(
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 300),
              child: widget.isLoading
                  ? const SizedBox(
                      key: ValueKey('loading'),
                      width: 24,
                      height: 24,
                      child: CircularProgressIndicator(
                        strokeWidth: 2.5,
                        color: Colors.white,
                      ),
                    )
                  : Row(
                      key: const ValueKey('idle'),
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          Icons.login_rounded,
                          color: Colors.black,
                          size: 22,
                        ),
                        const SizedBox(width: 14),
                        const Text(
                          'LOGIN',
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 15,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 2,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                        const SizedBox(width: 8),
                        Icon(
                          Icons.arrow_forward_rounded,
                          color: Colors.black.withOpacity(0.6),
                          size: 18,
                        ),
                      ],
                    ),
            ),
          ),
        ),
      ),
    );
  }
}

// ========== Elegant Button ==========
class _ElegantButton extends StatefulWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;

  const _ElegantButton({
    required this.label,
    required this.icon,
    required this.onTap,
  });

  @override
  State<_ElegantButton> createState() => _ElegantButtonState();
}

class _ElegantButtonState extends State<_ElegantButton> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) {
        setState(() => _down = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedScale(
        scale: _down ? 0.97 : 1,
        duration: const Duration(milliseconds: 150),
        child: Container(
          height: 50,
          width: double.infinity,
          decoration: BoxDecoration(
            gradient: _C.goldGrad,
            borderRadius: BorderRadius.circular(16),
            boxShadow: _down
                ? []
                : [
                    BoxShadow(
                      color: _C.gold.withOpacity(0.3),
                      blurRadius: 20,
                      offset: const Offset(0, 6),
                    ),
                  ],
          ),
          child: Center(
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(widget.icon, color: Colors.black, size: 18),
                const SizedBox(width: 10),
                Text(
                  widget.label,
                  style: const TextStyle(
                    color: Colors.black,
                    fontSize: 13,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.5,
                    fontFamily: 'Orbitron',
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ========== Outline Button ==========
class _OutlineButton extends StatefulWidget {
  final String label;
  final VoidCallback onTap;

  const _OutlineButton({
    required this.label,
    required this.onTap,
  });

  @override
  State<_OutlineButton> createState() => _OutlineButtonState();
}

class _OutlineButtonState extends State<_OutlineButton> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) {
        setState(() => _down = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        height: 50,
        width: double.infinity,
        decoration: BoxDecoration(
          color: _down ? _C.border.withOpacity(0.3) : Colors.transparent,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: _C.border,
            width: 1.5,
          ),
        ),
        child: Center(
          child: Text(
            widget.label,
            style: const TextStyle(
              color: _C.textSub,
              fontSize: 13,
              fontWeight: FontWeight.w700,
              letterSpacing: 1.5,
              fontFamily: 'Orbitron',
            ),
          ),
        ),
      ),
    );
  }
}

// ========== Background Painter ==========
class _BackgroundPainter extends StatefulWidget {
  final AnimationController controller;
  final Animation<double> particleRotate;

  const _BackgroundPainter({
    required this.controller,
    required this.particleRotate,
  });

  @override
  State<_BackgroundPainter> createState() => _BackgroundPainterState();
}

class _BackgroundPainterState extends State<_BackgroundPainter> {
  late List<_Particle> _particles;

  @override
  void initState() {
    super.initState();
    _particles = List.generate(30, (_) => _Particle());
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge([widget.controller, widget.particleRotate]),
      builder: (_, __) => CustomPaint(
        painter: _BgPainter(
          t: widget.controller.value,
          particles: _particles,
          rotate: widget.particleRotate.value,
        ),
        size: MediaQuery.of(context).size,
      ),
    );
  }
}

class _Particle {
  double x = math.Random().nextDouble();
  double y = math.Random().nextDouble();
  double size = 1 + math.Random().nextDouble() * 2;
  double speed = 0.001 + math.Random().nextDouble() * 0.003;
  double opacity = 0.1 + math.Random().nextDouble() * 0.2;
}

class _BgPainter extends CustomPainter {
  final double t;
  final List<_Particle> particles;
  final double rotate;

  _BgPainter({
    required this.t,
    required this.particles,
    required this.rotate,
  });

  @override
  void paint(Canvas canvas, Size size) {
    // Grid pattern
    final gridPaint = Paint()
      ..color = _C.border.withOpacity(0.15)
      ..strokeWidth = 0.5;
    const step = 50.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), gridPaint);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    }

    // Radial glow 1 - top
    final glow1 = Paint()
      ..shader = RadialGradient(
        colors: [
          _C.gold.withOpacity(0.08 + math.sin(t * math.pi * 2) * 0.03),
          Colors.transparent,
        ],
        radius: 0.8,
      ).createShader(Rect.fromCircle(
        center: Offset(size.width / 2, size.height * 0.3),
        radius: size.width * 0.7,
      ));
    canvas.drawCircle(
      Offset(size.width / 2, size.height * 0.3),
      size.width * 0.7,
      glow1,
    );

    // Radial glow 2 - bottom
    final glow2 = Paint()
      ..shader = RadialGradient(
        colors: [
          _C.platinum.withOpacity(0.05 + math.cos(t * math.pi * 2) * 0.02),
          Colors.transparent,
        ],
        radius: 0.6,
      ).createShader(Rect.fromCircle(
        center: Offset(size.width * 0.2, size.height * 0.8),
        radius: size.width * 0.5,
      ));
    canvas.drawCircle(
      Offset(size.width * 0.2, size.height * 0.8),
      size.width * 0.5,
      glow2,
    );

    // Particles
    final particlePaint = Paint()
      ..style = PaintingStyle.fill;
    for (final p in particles) {
      final px = (p.x + rotate * p.speed * 2) % 1 * size.width;
      final py = (p.y + t * p.speed * 0.5) % 1 * size.height;
      particlePaint.color = _C.gold.withOpacity(p.opacity);
      canvas.drawCircle(Offset(px, py), p.size, particlePaint);
    }

    // Decorative ring
    final ringPaint = Paint()
      ..color = _C.gold.withOpacity(0.04 + math.sin(t * math.pi * 2) * 0.02)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;
    canvas.drawCircle(
      Offset(size.width / 2, size.height / 2),
      size.width * 0.35,
      ringPaint,
    );
    canvas.drawCircle(
      Offset(size.width / 2, size.height / 2),
      size.width * 0.45,
      ringPaint,
    );
  }

  @override
  bool shouldRepaint(_BgPainter old) =>
      old.t != t || old.rotate != rotate;
}

enum _AlertType { error, warning, success }