import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:video_player/video_player.dart';
import 'api_config.dart';
import 'splash.dart';

// ─── Palette ───────────────────────────────────────────────────────────────
class _C {
  static const bg          = Color(0xFF0A0A1A);
  static const surface     = Color(0xFF12122A);
  static const card        = Color(0xFF161632);
  static const border      = Color(0xFF2A2A4A);
  static const cyan        = Color(0xFF00E5FF);
  static const cyanLight   = Color(0xFF80F0FF);
  static const cyanDark    = Color(0xFF0097A7);
  static const green       = Color(0xFF22C55E);
  static const amber       = Color(0xFFF59E0B);
  static const red         = Color(0xFFEF4444);
  static const text        = Color(0xFFF3F4F6);
  static const textSub     = Color(0xFF9CA3AF);
  static const textDim     = Color(0xFF6B7280);

  static const cardWhite   = Color(0xFFF5F0E8);
  static const textDark    = Color(0xFF1A1A1A);
  static const textGray    = Color(0xFF6B7280);
  static const btnBlue     = Color(0xFF2E75B6);
  static const btnBlueDark = Color(0xFF1E5A96);
  static const fieldBorder = Color(0xFFD0D5DD);

  // ── Warna text input (FIX) ──
  static const inputText   = Color(0xFF1A1A1A); // hitam, biar keliatan
  static const inputHint   = Color(0xFF9CA3AF); // abu untuk hint
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with TickerProviderStateMixin {
  final userCtrl = TextEditingController();
  final passCtrl = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool _isLoading = false;
  bool _obscurePass = true;
  String? _androidId;

  late VideoPlayerController _videoCtrl;

  late AnimationController _entranceCtrl;
  late AnimationController _shakeCtrl;

  late Animation<double> _fade;
  late Animation<Offset> _slide;
  late Animation<double> _shake;

  @override
  void initState() {
    super.initState();

    userCtrl.clear();
    passCtrl.clear();
    FocusManager.instance.primaryFocus?.unfocus();

    _videoCtrl = VideoPlayerController.asset('assets/videos/splash.mp4')
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() {});
        _videoCtrl.setLooping(true);
        _videoCtrl.setVolume(0.0);
        _videoCtrl.play();
      });

    _entranceCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900));
    _fade = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOut);
    _slide = Tween<Offset>(begin: const Offset(0, 0.06), end: Offset.zero)
        .animate(CurvedAnimation(
            parent: _entranceCtrl, curve: Curves.easeOutCubic));

    _shakeCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 500));
    _shake = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 0.0, end: -8.0), weight: 1),
      TweenSequenceItem(tween: Tween(begin: -8.0, end: 8.0), weight: 2),
      TweenSequenceItem(tween: Tween(begin: 8.0, end: -5.0), weight: 2),
      TweenSequenceItem(tween: Tween(begin: -5.0, end: 5.0), weight: 2),
      TweenSequenceItem(tween: Tween(begin: 5.0, end: 0.0), weight: 1),
    ]).animate(CurvedAnimation(parent: _shakeCtrl, curve: Curves.easeInOut));

    _entranceCtrl.forward();
    _initLogin();
  }

  @override
  void dispose() {
    _entranceCtrl.dispose();
    _shakeCtrl.dispose();
    _videoCtrl.dispose();
    userCtrl.dispose();
    passCtrl.dispose();
    super.dispose();
  }

  Future<void> _initLogin() async {
    try {
      final info = await DeviceInfoPlugin().androidInfo;
      _androidId = info.id;

      final prefs = await SharedPreferences.getInstance();
      final savedUser = prefs.getString('username');
      final savedPass = prefs.getString('password');
      final savedKey = prefs.getString('key');

      if (savedUser == null || savedPass == null || savedKey == null) return;

      final res = await http.get(Uri.parse(
          'http://deylegal-panel.pterodactylxcz.my.id:2151/myInfo?username=$savedUser&password=$savedPass&androidId=$_androidId&key=$savedKey'));
      final data = jsonDecode(res.body);

      if (data['valid'] == true && mounted) {
        // ⬇️⬇️ PERBAIKAN: Simpan UID saat auto-login ⬇️⬇️
        if (data['uid'] != null) {
          prefs.setString('uid', data['uid'].toString());
        }
        // ⬆️⬆️ PERBAIKAN SELESAI ⬆️⬆️

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
              builder: (_) => SplashScreen(
                    username: savedUser,
                    password: savedPass,
                    role: data['role'],
                    sessionKey: data['key'],
                    expiredDate: data['expiredDate'],
                    listBug: _parseList(data['listBug']),
                    listDoos: _parseList(data['listDDoS']),
                    news: _parseList(data['news']),
                  )),
        );
      }
    } catch (_) {}
  }

  List<Map<String, dynamic>> _parseList(dynamic raw) =>
      (raw as List? ?? [])
          .map((e) => Map<String, dynamic>.from(e as Map))
          .toList();

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;

    final username = userCtrl.text.trim();
    final password = passCtrl.text.trim();

    setState(() => _isLoading = true);

    try {
      final res = await http.post(
          Uri.parse('http://deylegal-panel.pterodactylxcz.my.id:2151/validate'),
          body: {
            'username': username,
            'password': password,
            'androidId': _androidId ?? 'unknown',
          });
      final data = jsonDecode(res.body);

      if (data['expired'] == true) {
        _shakeCtrl.forward(from: 0);
        _showAlert(
          title: 'Akses Habis',
          message: 'Masa akses Anda telah berakhir. Silakan perpanjang.',
          type: _AlertType.warning,
          showContact: true,
        );
      } else if (data['valid'] != true) {
        _shakeCtrl.forward(from: 0);
        final msg = (data['message'] ?? '').toString().toLowerCase();
        if (msg.contains('perangkat') ||
            msg.contains('device') ||
            msg.contains('another')) {
          _showAlert(
            title: 'Sesi Aktif',
            message: 'Akun ini sedang login di perangkat lain.',
            type: _AlertType.warning,
          );
        } else {
          _showAlert(
            title: 'Login Gagal',
            message: 'Username atau password salah.',
            type: _AlertType.error,
          );
        }
      } else {
        final prefs = await SharedPreferences.getInstance();
        prefs.setString('username', username);
        prefs.setString('password', password);
        prefs.setString('key', data['key']);

        // ⬇️⬇️ PERBAIKAN: Simpan UID saat login manual ⬇️⬇️
        if (data['uid'] != null) {
          prefs.setString('uid', data['uid'].toString());
        }
        // ⬆️⬆️ PERBAIKAN SELESAI ⬆️⬆️

        if (mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
                builder: (_) => SplashScreen(
                      username: username,
                      password: password,
                      role: data['role'],
                      sessionKey: data['key'],
                      expiredDate: data['expiredDate'],
                      listBug: _parseList(data['listBug']),
                      listDoos: _parseList(data['listDDoS']),
                      news: _parseList(data['news']),
                    )),
          );
        }
      }
    } catch (_) {
      _shakeCtrl.forward(from: 0);
      _showAlert(
        title: 'Koneksi Error',
        message: 'Gagal terhubung ke server. Periksa jaringan Anda.',
        type: _AlertType.error,
      );
    }

    if (mounted) setState(() => _isLoading = false);
  }

  void _showAlert({
    required String title,
    required String message,
    required _AlertType type,
    bool showContact = false,
  }) {
    final color = switch (type) {
      _AlertType.error => _C.red,
      _AlertType.warning => _C.amber,
      _AlertType.success => _C.green,
    };
    final icon = switch (type) {
      _AlertType.error => Icons.error_rounded,
      _AlertType.warning => Icons.warning_amber_rounded,
      _AlertType.success => Icons.check_circle_rounded,
    };

    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: '',
      barrierColor: Colors.black87,
      transitionDuration: const Duration(milliseconds: 320),
      transitionBuilder: (_, anim, __, child) => ScaleTransition(
        scale: CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
        child: FadeTransition(opacity: anim, child: child),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 28),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: color.withValues(alpha: 0.3), width: 1.5),
            boxShadow: [
              BoxShadow(
                  color: color.withValues(alpha: 0.15), blurRadius: 50),
            ],
          ),
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: color.withValues(alpha: 0.1),
                  border:
                      Border.all(color: color.withValues(alpha: 0.3)),
                ),
                child: Icon(icon, color: color, size: 30),
              ),
              const SizedBox(height: 18),
              Text(title,
                  style: const TextStyle(
                      color: _C.textDark,
                      fontSize: 20,
                      fontWeight: FontWeight.w800)),
              const SizedBox(height: 10),
              Text(message,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      color: _C.textGray, fontSize: 13, height: 1.5)),
              const SizedBox(height: 24),
              if (showContact) ...[
                _GradBtn(
                  label: 'HUBUNGI ADMIN',
                  fullWidth: true,
                  onTap: () async {
                    Navigator.pop(ctx);
                    await launchUrl(Uri.parse('https://t.me/Arkxcode'),
                        mode: LaunchMode.externalApplication);
                  },
                ),
                const SizedBox(height: 12),
              ],
              _OutlineBtn(
                label: showContact ? 'TUTUP' : 'OK',
                fullWidth: true,
                onTap: () => Navigator.pop(ctx),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0F1A),
      body: Stack(
        children: [
          Positioned.fill(
            child: _videoCtrl.value.isInitialized
                ? FittedBox(
                    fit: BoxFit.cover,
                    child: SizedBox(
                      width: _videoCtrl.value.size.width,
                      height: _videoCtrl.value.size.height,
                      child: VideoPlayer(_videoCtrl),
                    ),
                  )
                : Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Color(0xFF0A1A3F), Color(0xFF06131A)],
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                      ),
                    ),
                  ),
          ),

          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withValues(alpha: 0.35),
                    Colors.black.withValues(alpha: 0.55),
                    Colors.black.withValues(alpha: 0.75),
                  ],
                ),
              ),
            ),
          ),

          SafeArea(
            child: FadeTransition(
              opacity: _fade,
              child: SlideTransition(
                position: _slide,
                child: Center(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 24),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _buildLogo(),
                        const SizedBox(height: 20),
                        _buildSubtitle(),
                        const SizedBox(height: 28),
                        AnimatedBuilder(
                          animation: _shake,
                          builder: (_, child) => Transform.translate(
                            offset: Offset(_shake.value, 0),
                            child: child,
                          ),
                          child: _buildForm(),
                        ),
                        const SizedBox(height: 24),
                        _buildFooter(),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLogo() {
    return Hero(
      tag: 'logo',
      child: ConstrainedBox(
        constraints: const BoxConstraints(
          maxWidth: 220,
          maxHeight: 220,
        ),
        child: Image.asset(
          'assets/images/reze.png',
          fit: BoxFit.contain,
          errorBuilder: (_, __, ___) => Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white.withValues(alpha: 0.1),
              border: Border.all(color: Colors.white, width: 2),
            ),
            child: const Icon(Icons.sailing_rounded,
                color: Colors.white, size: 60),
          ),
        ),
      ),
    );
  }

  Widget _buildSubtitle() {
    return const Text(
      'Masuk ke akunmu',
      style: TextStyle(
        color: Colors.white,
        fontSize: 16,
        fontWeight: FontWeight.w500,
        letterSpacing: 2,
      ),
    );
  }

  Widget _buildForm() {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: _C.cardWhite,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.25),
            blurRadius: 30,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Selamat datang',
              style: TextStyle(
                color: _C.textDark,
                fontSize: 24,
                fontWeight: FontWeight.w900,
                letterSpacing: 0.5,
              ),
            ),
            const SizedBox(height: 4),
            const Text(
              'Username & password',
              style: TextStyle(
                color: _C.textGray,
                fontSize: 13,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 22),

            _LoginField(
              controller: userCtrl,
              label: 'Username',
              icon: Icons.person_outline_rounded,
              validator: (v) =>
                  (v == null || v.isEmpty) ? 'Username tidak boleh kosong' : null,
            ),
            const SizedBox(height: 14),

            _LoginField(
              controller: passCtrl,
              label: 'Password',
              icon: Icons.lock_outline_rounded,
              obscure: _obscurePass,
              onToggleObscure: () =>
                  setState(() => _obscurePass = !_obscurePass),
              validator: (v) =>
                  (v == null || v.isEmpty) ? 'Password tidak boleh kosong' : null,
            ),
            const SizedBox(height: 24),

            _LoginButton(
              isLoading: _isLoading,
              onTap: _login,
            ),
            const SizedBox(height: 12),

            _TroubleshootButton(
              onTap: () async {
                await launchUrl(Uri.parse('https://t.me/Arkxcode'),
                    mode: LaunchMode.externalApplication);
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFooter() {
    return Text(
      'v2.0.17  ·  © 2026 SYAM',
      style: TextStyle(
        color: Colors.white.withValues(alpha: 0.5),
        fontSize: 12,
        fontWeight: FontWeight.w400,
        letterSpacing: 0.5,
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
//  LOGIN FIELD — FIX: text input HITAM, gak putih lagi
// ══════════════════════════════════════════════════════════════════════════════
class _LoginField extends StatefulWidget {
  final TextEditingController controller;
  final String label;
  final IconData icon;
  final bool obscure;
  final VoidCallback? onToggleObscure;
  final String? Function(String?)? validator;

  const _LoginField({
    required this.controller,
    required this.label,
    required this.icon,
    this.obscure = false,
    this.onToggleObscure,
    this.validator,
  });

  @override
  State<_LoginField> createState() => _LoginFieldState();
}

class _LoginFieldState extends State<_LoginField> {
  bool _focused = false;
  final _focus = FocusNode();

  @override
  void initState() {
    super.initState();
    _focus.addListener(() => setState(() => _focused = _focus.hasFocus));
  }

  @override
  void dispose() {
    _focus.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: _focused ? _C.btnBlue : _C.fieldBorder,
          width: _focused ? 1.8 : 1.2,
        ),
      ),
      child: Stack(
        children: [
          Positioned(
            top: -6,
            left: 14,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 6),
              color: _C.cardWhite,
              child: Text(
                widget.label,
                style: TextStyle(
                  color: _focused ? _C.btnBlue : _C.textGray,
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
          TextFormField(
            controller: widget.controller,
            focusNode: _focus,
            obscureText: widget.obscure,
            validator: widget.validator,
            autofillHints: null,
            enableSuggestions: false,
            autocorrect: false,
            // ── FIX UTAMA: warna text HITAM eksplisit ──
            style: const TextStyle(
              color: _C.inputText,
              fontSize: 15,
              fontWeight: FontWeight.w500,
            ),
            cursorColor: _C.btnBlue,
            // ── FIX: cursor biar keliatan di Android ──
            cursorWidth: 2,
            cursorHeight: 18,
            decoration: InputDecoration(
              hintText: '',
              hintStyle: const TextStyle(
                color: _C.inputHint,
                fontSize: 15,
              ),
              prefixIcon: Icon(widget.icon,
                  color: _focused ? _C.btnBlue : _C.textGray, size: 20),
              suffixIcon: widget.onToggleObscure != null
                  ? GestureDetector(
                      onTap: widget.onToggleObscure,
                      child: Icon(
                        widget.obscure
                            ? Icons.visibility_off_outlined
                            : Icons.visibility_outlined,
                        color: _C.textGray,
                        size: 20,
                      ),
                    )
                  : null,
              errorStyle: const TextStyle(color: _C.red, fontSize: 11),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(
                  horizontal: 18, vertical: 18),
            ),
          ),
        ],
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
//  LOGIN BUTTON
// ══════════════════════════════════════════════════════════════════════════════
class _LoginButton extends StatefulWidget {
  final bool isLoading;
  final VoidCallback onTap;

  const _LoginButton({required this.isLoading, required this.onTap});

  @override
  State<_LoginButton> createState() => _LoginButtonState();
}

class _LoginButtonState extends State<_LoginButton> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) {
        setState(() => _down = false);
        if (!widget.isLoading) widget.onTap();
      },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedScale(
        scale: _down ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: Container(
          height: 54,
          width: double.infinity,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [_C.btnBlue, _C.btnBlueDark],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(14),
            boxShadow: _down || widget.isLoading
                ? []
                : [
                    BoxShadow(
                      color: _C.btnBlue.withValues(alpha: 0.35),
                      blurRadius: 16,
                      offset: const Offset(0, 6),
                    ),
                  ],
          ),
          child: Center(
            child: widget.isLoading
                ? const SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(
                        strokeWidth: 2.5, color: Colors.white),
                  )
                : const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        'MASUK',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 2,
                        ),
                      ),
                      SizedBox(width: 8),
                      Icon(Icons.arrow_forward_rounded,
                          color: Colors.white, size: 20),
                    ],
                  ),
          ),
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
//  TROUBLESHOOT BUTTON
// ══════════════════════════════════════════════════════════════════════════════
class _TroubleshootButton extends StatefulWidget {
  final VoidCallback onTap;
  const _TroubleshootButton({required this.onTap});

  @override
  State<_TroubleshootButton> createState() => _TroubleshootButtonState();
}

class _TroubleshootButtonState extends State<_TroubleshootButton> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) {
        setState(() => _down = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedScale(
        scale: _down ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: Container(
          height: 54,
          width: double.infinity,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [_C.btnBlue, _C.btnBlueDark],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(14),
            boxShadow: _down
                ? []
                : [
                    BoxShadow(
                      color: _C.btnBlue.withValues(alpha: 0.35),
                      blurRadius: 16,
                      offset: const Offset(0, 6),
                    ),
                  ],
          ),
          child: const Center(
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.headset_mic_rounded,
                    color: Colors.white, size: 20),
                SizedBox(width: 10),
                Text(
                  'TROUBLESHOOT',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 2,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
//  GRADIENT BUTTON (dialog)
// ══════════════════════════════════════════════════════════════════════════════
class _GradBtn extends StatefulWidget {
  final String label;
  final VoidCallback onTap;
  final bool fullWidth;

  const _GradBtn(
      {required this.label, required this.onTap, this.fullWidth = false});

  @override
  State<_GradBtn> createState() => _GradBtnState();
}

class _GradBtnState extends State<_GradBtn> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) {
        setState(() => _down = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedScale(
        scale: _down ? 0.96 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: Container(
          height: 48,
          width: widget.fullWidth ? double.infinity : null,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [_C.btnBlue, _C.btnBlueDark],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(14),
            boxShadow: _down
                ? []
                : [
                    BoxShadow(
                        color: _C.btnBlue.withValues(alpha: 0.4),
                        blurRadius: 16,
                        offset: const Offset(0, 6)),
                  ],
          ),
          child: Center(
            child: Text(widget.label,
                style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                    fontSize: 14,
                    letterSpacing: 0.5)),
          ),
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
//  OUTLINE BUTTON (dialog)
// ══════════════════════════════════════════════════════════════════════════════
class _OutlineBtn extends StatefulWidget {
  final String label;
  final VoidCallback onTap;
  final bool fullWidth;

  const _OutlineBtn(
      {required this.label, required this.onTap, this.fullWidth = false});

  @override
  State<_OutlineBtn> createState() => _OutlineBtnState();
}

class _OutlineBtnState extends State<_OutlineBtn> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) {
        setState(() => _down = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 120),
        height: 48,
        width: widget.fullWidth ? double.infinity : null,
        decoration: BoxDecoration(
          color: _down
              ? _C.fieldBorder.withValues(alpha: 0.3)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _C.fieldBorder, width: 1.5),
        ),
        child: Center(
          child: Text(widget.label,
              style: const TextStyle(
                  color: _C.textGray,
                  fontWeight: FontWeight.w700,
                  fontSize: 14,
                  letterSpacing: 0.5)),
        ),
      ),
    );
  }
}

enum _AlertType { error, warning, success }