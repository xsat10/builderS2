export 'ghostcrasher_trader.dart' show TradePosition, MarketInfo, TimeframeInfo, kMarkets, kTimeframes, fmtPrice, fmtMoney;

import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:web_socket_channel/io.dart';
import 'package:shared_preferences/shared_preferences.dart';

// Gunakan nama berbeda untuk menghindari konflik dengan Position dari geolocator
class TradePosition {
  final String id;
  final String symbol;
  final bool isBuy;
  final double entryPrice;
  final double quantity;
  final DateTime openTime;
  double? closePrice;
  DateTime? closeTime;
  double? realizedPnl;

  TradePosition({
    required this.id,
    required this.symbol,
    required this.isBuy,
    required this.entryPrice,
    required this.quantity,
    required this.openTime,
    this.closePrice,
    this.closeTime,
    this.realizedPnl,
  });

  bool get isOpen => closeTime == null;

  double floatingPnl(double currentPrice) {
    final diff = isBuy ? (currentPrice - entryPrice) : (entryPrice - currentPrice);
    return diff * quantity;
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'symbol': symbol,
        'isBuy': isBuy,
        'entryPrice': entryPrice,
        'quantity': quantity,
        'openTime': openTime.toIso8601String(),
        'closePrice': closePrice,
        'closeTime': closeTime?.toIso8601String(),
        'realizedPnl': realizedPnl,
      };

  factory TradePosition.fromJson(Map<String, dynamic> j) => TradePosition(
        id: j['id'],
        symbol: j['symbol'],
        isBuy: j['isBuy'],
        entryPrice: (j['entryPrice'] as num).toDouble(),
        quantity: (j['quantity'] as num).toDouble(),
        openTime: DateTime.parse(j['openTime']),
        closePrice: j['closePrice'] != null ? (j['closePrice'] as num).toDouble() : null,
        closeTime: j['closeTime'] != null ? DateTime.parse(j['closeTime']) : null,
        realizedPnl: j['realizedPnl'] != null ? (j['realizedPnl'] as num).toDouble() : null,
      );
}

class MarketInfo {
  final String symbol; // e.g. BTCUSDT
  final String display; // e.g. BTC/USDT
  final String name; // e.g. Bitcoin vs Tether
  const MarketInfo(this.symbol, this.display, this.name);
}

class TimeframeInfo {
  final String label; // M1, M5 ...
  final String interval; // 1m, 5m ...
  final Duration duration;
  const TimeframeInfo(this.label, this.interval, this.duration);
}

const List<MarketInfo> kMarkets = [
  MarketInfo('BTCUSDT', 'BTC/USDT', 'Bitcoin vs Tether'),
  MarketInfo('ETHUSDT', 'ETH/USDT', 'Ethereum vs Tether'),
  MarketInfo('BNBUSDT', 'BNB/USDT', 'Binance Coin vs Tether'),
  MarketInfo('SOLUSDT', 'SOL/USDT', 'Solana vs Tether'),
  MarketInfo('XRPUSDT', 'XRP/USDT', 'Ripple vs Tether'),
  MarketInfo('DOGEUSDT', 'DOGE/USDT', 'Dogecoin vs Tether'),
  MarketInfo('ADAUSDT', 'ADA/USDT', 'Cardano vs Tether'),
  MarketInfo('LTCUSDT', 'LTC/USDT', 'Litecoin vs Tether'),
];

const List<TimeframeInfo> kTimeframes = [
  TimeframeInfo('M1', '1m', Duration(minutes: 1)),
  TimeframeInfo('M5', '5m', Duration(minutes: 5)),
  TimeframeInfo('M15', '15m', Duration(minutes: 15)),
  TimeframeInfo('M30', '30m', Duration(minutes: 30)),
  TimeframeInfo('H1', '1h', Duration(hours: 1)),
  TimeframeInfo('H4', '4h', Duration(hours: 4)),
  TimeframeInfo('D1', '1d', Duration(days: 1)),
];

String fmtPrice(double p) {
  if (p >= 1000) return p.toStringAsFixed(2);
  if (p >= 1) return p.toStringAsFixed(4);
  return p.toStringAsFixed(6);
}

String fmtMoney(double v) {
  final neg = v < 0;
  v = v.abs();
  final s = v.toStringAsFixed(2);
  final parts = s.split('.');
  final intPart = parts[0];
  final buf = StringBuffer();
  for (int i = 0; i < intPart.length; i++) {
    final posFromEnd = intPart.length - i;
    buf.write(intPart[i]);
    if (posFromEnd > 1 && posFromEnd % 3 == 1) buf.write('.');
  }
  return '${neg ? '-' : ''}${buf.toString()},${parts[1]}';
}

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(const GhostCrasherTraderApp());
}

// =============================================================================
// THEME COLORS
// =============================================================================
class AppColors {
  static const bg = Color(0xFF0B0E11);
  static const panel = Color(0xFF14181D);
  static const panelLight = Color(0xFF1C2128);
  static const border = Color(0xFF2A2F37);
  static const green = Color(0xFF26A69A);
  static const red = Color(0xFFEF5350);
  static const gold = Color(0xFFF0B90B);
  static const textDim = Color(0xFF848E9C);
  static const white = Color(0xFFEAECEF);
}

// =============================================================================
// APP ROOT
// =============================================================================
class GhostCrasherTraderApp extends StatelessWidget {
  const GhostCrasherTraderApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'GhostCrasher Trader',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: AppColors.bg,
        fontFamily: 'Orbitron',
        useMaterial3: true,
        colorScheme: const ColorScheme.dark(
          primary: AppColors.gold,
          surface: AppColors.panel,
        ),
      ),
      home: const TraderHomePage(),
    );
  }
}

// =============================================================================
// MODELS
// =============================================================================
class Candle {
  final DateTime time;
  double open;
  double high;
  double low;
  double close;

  Candle({
    required this.time,
    required this.open,
    required this.high,
    required this.low,
    required this.close,
  });

  bool get isBull => close >= open;
}

// =============================================================================
// HOME PAGE
// =============================================================================
class TraderHomePage extends StatefulWidget {
  const TraderHomePage({super.key});
  @override
  State<TraderHomePage> createState() => _TraderHomePageState();
}

class _TraderHomePageState extends State<TraderHomePage> {
  MarketInfo market = kMarkets[0];
  TimeframeInfo timeframe = kTimeframes[1]; // M5 default, like screenshot

  List<Candle> candles = [];
  double currentPrice = 0;
  double prevClose = 0;
  bool loading = true;
  bool wsConnected = false;

  IOWebSocketChannel? _channel;
  StreamSubscription? _wsSub;

  double balance = 10000000;
  DateTime lastReset = DateTime.now();

  List<TradePosition> openPositions = [];
  List<TradePosition> closedPositions = [];

  double quantity = 0.01;

  int bottomTab = 1; // 0 Quote, 1 Chart, 2 Riwayat, 3 Akun

  final ScrollController _scrollCtrl = ScrollController();
  Timer? _tickTimer;

  @override
  void initState() {
    super.initState();
    _bootstrap();
  }

  Future<void> _bootstrap() async {
    await _loadState();
    await _loadMarket();
    // Periodic UI refresh so floating PnL & clock stay live even without new ticks.
    _tickTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  // ---------------------------------------------------------------------
  // PERSISTENCE
  // ---------------------------------------------------------------------
  Future<void> _loadState() async {
    final prefs = await SharedPreferences.getInstance();
    final savedBalance = prefs.getDouble('balance');
    final savedResetMs = prefs.getInt('lastReset');
    final savedOpen = prefs.getString('openPositions');
    final savedClosed = prefs.getString('closedPositions');

    final now = DateTime.now();
    if (savedResetMs == null) {
      balance = 10000000;
      lastReset = now;
    } else {
      lastReset = DateTime.fromMillisecondsSinceEpoch(savedResetMs);
      balance = savedBalance ?? 10000000;
      if (now.difference(lastReset).inDays >= 7) {
        // Waktunya reset mingguan.
        balance = 10000000;
        lastReset = now;
        openPositions = [];
        closedPositions = [];
      }
    }

    if (savedOpen != null && now.difference(lastReset).inDays < 7) {
      try {
        final list = (jsonDecode(savedOpen) as List)
            .map((e) => TradePosition.fromJson(e as Map<String, dynamic>))
            .toList();
        openPositions = list;
      } catch (_) {}
    }
    if (savedClosed != null && now.difference(lastReset).inDays < 7) {
      try {
        final list = (jsonDecode(savedClosed) as List)
            .map((e) => TradePosition.fromJson(e as Map<String, dynamic>))
            .toList();
        closedPositions = list;
      } catch (_) {}
    }

    await _saveState();
    if (mounted) setState(() {});
  }

  Future<void> _saveState() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('balance', balance);
    await prefs.setInt('lastReset', lastReset.millisecondsSinceEpoch);
    await prefs.setString(
        'openPositions', jsonEncode(openPositions.map((e) => e.toJson()).toList()));
    await prefs.setString(
        'closedPositions', jsonEncode(closedPositions.map((e) => e.toJson()).toList()));
  }

  // ---------------------------------------------------------------------
  // MARKET DATA (Binance public REST + WebSocket — free, no API key)
  // ---------------------------------------------------------------------
  Future<void> _loadMarket() async {
    setState(() {
      loading = true;
      candles = [];
    });
    await _fetchInitialCandles();
    _connectWebSocket();
    setState(() => loading = false);
    WidgetsBinding.instance.addPostFrameCallback((_) => _jumpToEnd());
  }

  Future<void> _fetchInitialCandles() async {
    try {
      final uri = Uri.parse(
          'https://api.binance.com/api/v3/klines?symbol=${market.symbol}&interval=${timeframe.interval}&limit=150');
      final res = await http.get(uri).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body) as List;
        final list = data.map((raw) {
          final row = raw as List;
          return Candle(
            time: DateTime.fromMillisecondsSinceEpoch(row[0] as int),
            open: double.parse(row[1].toString()),
            high: double.parse(row[2].toString()),
            low: double.parse(row[3].toString()),
            close: double.parse(row[4].toString()),
          );
        }).toList();
        setState(() {
          candles = list;
          if (candles.isNotEmpty) {
            currentPrice = candles.last.close;
            prevClose = candles.length > 1 ? candles[candles.length - 2].close : currentPrice;
          }
        });
      }
    } catch (e) {
      debugPrint('Gagal mengambil candle awal: $e');
    }
  }

  void _connectWebSocket() {
    _wsSub?.cancel();
    _channel?.sink.close();
    wsConnected = false;

    final streamName = '${market.symbol.toLowerCase()}@kline_${timeframe.interval}';
    try {
      _channel = IOWebSocketChannel.connect(Uri.parse('wss://stream.binance.com:9443/ws/$streamName'));
      _wsSub = _channel!.stream.listen(
        (event) => _onTick(event),
        onError: (e) {
          debugPrint('WS error: $e');
          _scheduleReconnect();
        },
        onDone: () {
          debugPrint('WS closed');
          _scheduleReconnect();
        },
      );
      wsConnected = true;
    } catch (e) {
      debugPrint('Gagal konek WebSocket: $e');
      _scheduleReconnect();
    }
  }

  void _scheduleReconnect() {
    wsConnected = false;
    Future.delayed(const Duration(seconds: 3), () {
      if (mounted) _connectWebSocket();
    });
  }

  void _onTick(dynamic raw) {
    try {
      final msg = jsonDecode(raw as String);
      final k = msg['k'];
      if (k == null) return;
      final openTime = DateTime.fromMillisecondsSinceEpoch(k['t'] as int);
      final o = double.parse(k['o'].toString());
      final h = double.parse(k['h'].toString());
      final l = double.parse(k['l'].toString());
      final c = double.parse(k['c'].toString());
      final closed = k['x'] as bool;

      setState(() {
        if (candles.isNotEmpty && candles.last.time == openTime) {
          candles.last
            ..open = o
            ..high = h
            ..low = l
            ..close = c;
        } else {
          candles.add(Candle(time: openTime, open: o, high: h, low: l, close: c));
          if (candles.length > 300) candles.removeAt(0);
        }
        prevClose = currentPrice == 0 ? c : currentPrice;
        currentPrice = c;
        if (closed) {
          // candle ditutup, candle baru akan datang di tick berikutnya
        }
      });
      _jumpToEnd();
    } catch (e) {
      debugPrint('Parse tick error: $e');
    }
  }

  void _jumpToEnd() {
    if (_scrollCtrl.hasClients) {
      _scrollCtrl.jumpTo(_scrollCtrl.position.maxScrollExtent);
    }
  }

  void _switchMarket(MarketInfo m) {
    if (m.symbol == market.symbol) return;
    setState(() => market = m);
    _loadMarket();
  }

  void _switchTimeframe(TimeframeInfo tf) {
    if (tf.interval == timeframe.interval) return;
    setState(() => timeframe = tf);
    _loadMarket();
  }

  // ---------------------------------------------------------------------
  // TRADING LOGIC
  // ---------------------------------------------------------------------
  double get spread => currentPrice * 0.0006; // simulasi spread kecil
  double get bidPrice => currentPrice - spread / 2;
  double get askPrice => currentPrice + spread / 2;

  double get floatingTotal =>
      openPositions.fold(0.0, (sum, p) => sum + p.floatingPnl(currentPrice));

  double get equity => balance + floatingTotal;

  void _openPosition(bool isBuy) {
    if (currentPrice <= 0) return;
    final entry = isBuy ? askPrice : bidPrice;
    final pos = TradePosition(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      symbol: market.symbol,
      isBuy: isBuy,
      entryPrice: entry,
      quantity: quantity,
      openTime: DateTime.now(),
    );
    setState(() => openPositions.insert(0, pos));
    _saveState();
    HapticFeedback.lightImpact();
    _showSnack(
      '${isBuy ? 'BUY' : 'SELL'} ${market.display} x$quantity dibuka @ ${fmtPrice(entry)}',
      isBuy ? AppColors.green : AppColors.red,
    );
  }

  void _closePosition(TradePosition p) {
    final exit = p.isBuy ? bidPrice : askPrice;
    final pnl = p.floatingPnl(exit);
    setState(() {
      p.closePrice = exit;
      p.closeTime = DateTime.now();
      p.realizedPnl = pnl;
      openPositions.removeWhere((e) => e.id == p.id);
      closedPositions.insert(0, p);
      balance += pnl;
    });
    _saveState();
    _showSnack(
      'Posisi ditutup: ${pnl >= 0 ? '+' : ''}${fmtMoney(pnl)} (${p.isBuy ? 'BUY' : 'SELL'} ${p.symbol})',
      pnl >= 0 ? AppColors.green : AppColors.red,
    );
  }

  void _closeAll() {
    for (final p in List<TradePosition>.from(openPositions)) {
      _closePosition(p);
    }
  }

  void _showSnack(String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        backgroundColor: color.withOpacity(0.9),
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  void dispose() {
    _wsSub?.cancel();
    _channel?.sink.close();
    _tickTimer?.cancel();
    _scrollCtrl.dispose();
    super.dispose();
  }

  // ---------------------------------------------------------------------
  // BUILD
  // ---------------------------------------------------------------------
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Column(
          children: [
            _buildTopBar(),
            _buildPriceBar(),
            _buildQuantityBar(),
            _buildSymbolHeader(),
            Expanded(child: _buildBody()),
            _buildBottomNav(),
          ],
        ),
      ),
    );
  }

  Widget _buildBody() {
    switch (bottomTab) {
      case 0:
        return _buildQuoteTab();
      case 2:
        return _buildHistoryTab();
      case 3:
        return _buildAccountTab();
      default:
        return _buildChartArea();
    }
  }

  // ---- TOP BAR ----
  Widget _buildTopBar() {
    return Container(
      color: AppColors.panel,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      child: Row(
        children: [
          const Icon(Icons.menu, color: AppColors.white, size: 22),
          const Spacer(),
          Icon(Icons.add_chart, color: AppColors.textDim, size: 20),
          const SizedBox(width: 16),
          Icon(Icons.show_chart, color: AppColors.textDim, size: 20),
          const SizedBox(width: 12),
          GestureDetector(
            onTap: _showTimeframeSheet,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: AppColors.panelLight,
                borderRadius: BorderRadius.circular(4),
                border: Border.all(color: AppColors.border),
              ),
              child: Text(timeframe.label,
                  style: const TextStyle(color: AppColors.white, fontWeight: FontWeight.bold, fontSize: 13)),
            ),
          ),
          const SizedBox(width: 12),
          Icon(wsConnected ? Icons.wifi : Icons.wifi_off,
              color: wsConnected ? AppColors.green : AppColors.red, size: 18),
        ],
      ),
    );
  }

  // ---- SELL / BUY PRICE BAR ----
  Widget _buildPriceBar() {
    return Container(
      height: 62,
      color: AppColors.panel,
      child: Row(
        children: [
          Expanded(
            child: GestureDetector(
              onTap: () => _confirmOrder(false),
              child: Container(
                color: AppColors.red,
                alignment: Alignment.center,
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('SELL', style: TextStyle(color: Colors.white70, fontSize: 11, fontWeight: FontWeight.bold)),
                    Text(
                      currentPrice > 0 ? fmtPrice(bidPrice) : '--',
                      style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Container(
            width: 120,
            color: AppColors.panelLight,
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                  icon: const Icon(Icons.remove, color: AppColors.white, size: 18),
                  onPressed: () => setState(() {
                    quantity = math.max(0.01, double.parse((quantity - 0.01).toStringAsFixed(2)));
                  }),
                ),
                Text(quantity.toStringAsFixed(2),
                    style: const TextStyle(color: AppColors.white, fontWeight: FontWeight.bold, fontSize: 15)),
                IconButton(
                  icon: const Icon(Icons.add, color: AppColors.white, size: 18),
                  onPressed: () => setState(() {
                    quantity = double.parse((quantity + 0.01).toStringAsFixed(2));
                  }),
                ),
              ],
            ),
          ),
          Expanded(
            child: GestureDetector(
              onTap: () => _confirmOrder(true),
              child: Container(
                color: AppColors.green,
                alignment: Alignment.center,
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    const Text('BUY', style: TextStyle(color: Colors.white70, fontSize: 11, fontWeight: FontWeight.bold)),
                    Text(
                      currentPrice > 0 ? fmtPrice(askPrice) : '--',
                      style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuantityBar() => const SizedBox(height: 2);

  // ---- SYMBOL HEADER ----
  Widget _buildSymbolHeader() {
    final isUp = currentPrice >= prevClose;
    return Container(
      color: AppColors.bg,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      child: Row(
        children: [
          GestureDetector(
            onTap: _showMarketSheet,
            child: Row(
              children: [
                Text(market.display,
                    style: const TextStyle(
                        color: AppColors.gold, fontWeight: FontWeight.bold, fontSize: 15)),
                const Icon(Icons.arrow_drop_down, color: AppColors.gold, size: 18),
              ],
            ),
          ),
          const SizedBox(width: 6),
          Expanded(
            child: Text(market.name,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: AppColors.textDim, fontSize: 12)),
          ),
          Icon(isUp ? Icons.arrow_upward : Icons.arrow_downward,
              color: isUp ? AppColors.green : AppColors.red, size: 14),
          Text(
            currentPrice > 0 ? fmtPrice(currentPrice) : '--',
            style: TextStyle(
                color: isUp ? AppColors.green : AppColors.red,
                fontWeight: FontWeight.bold,
                fontSize: 13),
          ),
        ],
      ),
    );
  }

  // ---- CHART ----
  Widget _buildChartArea() {
    if (loading) {
      return const Center(child: CircularProgressIndicator(color: AppColors.gold));
    }
    if (candles.isEmpty) {
      return const Center(
          child: Text('Tidak ada data candle', style: TextStyle(color: AppColors.textDim)));
    }

    const candleWidth = 8.0;
    const candleGap = 4.0;
    final totalWidth = candles.length * (candleWidth + candleGap) + 60;

    return LayoutBuilder(builder: (context, constraints) {
      final width = math.max(constraints.maxWidth, totalWidth);
      return SingleChildScrollView(
        controller: _scrollCtrl,
        scrollDirection: Axis.horizontal,
        reverse: true,
        child: SizedBox(
          width: width,
          height: constraints.maxHeight,
          child: CustomPaint(
            painter: CandleChartPainter(
              candles: candles,
              currentPrice: currentPrice,
              candleWidth: candleWidth,
              candleGap: candleGap,
            ),
          ),
        ),
      );
    });
  }

  // ---- QUOTE TAB ----
  Widget _buildQuoteTab() {
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        _quoteRow('Symbol', market.display),
        _quoteRow('Nama', market.name),
        _quoteRow('Bid', currentPrice > 0 ? fmtPrice(bidPrice) : '--'),
        _quoteRow('Ask', currentPrice > 0 ? fmtPrice(askPrice) : '--'),
        _quoteRow('Spread', currentPrice > 0 ? fmtPrice(spread) : '--'),
        _quoteRow('Timeframe', timeframe.label),
        _quoteRow('Status Live', wsConnected ? 'Terhubung' : 'Menghubungkan...'),
      ],
    );
  }

  Widget _quoteRow(String label, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: const BoxDecoration(
          border: Border(bottom: BorderSide(color: AppColors.border))),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: AppColors.textDim)),
          Text(value, style: const TextStyle(color: AppColors.white, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  // ---- HISTORY / RIWAYAT TAB ----
  Widget _buildHistoryTab() {
    return Column(
      children: [
        if (openPositions.isNotEmpty)
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 10, 14, 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Posisi Terbuka',
                    style: TextStyle(color: AppColors.white, fontWeight: FontWeight.bold, fontSize: 15)),
                TextButton(
                  onPressed: _closeAll,
                  child: const Text('Tutup Semua', style: TextStyle(color: AppColors.red)),
                ),
              ],
            ),
          ),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(14),
            children: [
              ...openPositions.map((p) => _positionCard(p, open: true)),
              if (closedPositions.isNotEmpty) ...[
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 10),
                  child: Text('Riwayat Transaksi',
                      style: TextStyle(color: AppColors.white, fontWeight: FontWeight.bold, fontSize: 15)),
                ),
                ...closedPositions.map((p) => _positionCard(p, open: false)),
              ],
              if (openPositions.isEmpty && closedPositions.isEmpty)
                const Padding(
                  padding: EdgeInsets.only(top: 60),
                  child: Center(
                    child: Text('Belum ada transaksi.\nBuka posisi BUY/SELL untuk mulai latihan.',
                        textAlign: TextAlign.center, style: TextStyle(color: AppColors.textDim)),
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _positionCard(TradePosition p, {required bool open}) {
    final pnl = open ? p.floatingPnl(currentPrice) : (p.realizedPnl ?? 0);
    final pnlColor = pnl >= 0 ? AppColors.green : AppColors.red;
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.panel,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Container(
            width: 6,
            height: 40,
            decoration: BoxDecoration(
              color: p.isBuy ? AppColors.green : AppColors.red,
              borderRadius: BorderRadius.circular(3),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('${p.isBuy ? 'BUY' : 'SELL'} ${p.symbol}  x${p.quantity.toStringAsFixed(2)}',
                    style: const TextStyle(color: AppColors.white, fontWeight: FontWeight.bold)),
                const SizedBox(height: 2),
                Text('Entry: ${fmtPrice(p.entryPrice)}${open ? '' : '  →  Exit: ${fmtPrice(p.closePrice ?? 0)}'}',
                    style: const TextStyle(color: AppColors.textDim, fontSize: 12)),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text('${pnl >= 0 ? '+' : ''}${fmtMoney(pnl)}',
                  style: TextStyle(color: pnlColor, fontWeight: FontWeight.bold)),
              if (open)
                TextButton(
                  style: TextButton.styleFrom(
                      padding: const EdgeInsets.symmetric(horizontal: 8), minimumSize: Size.zero),
                  onPressed: () => _closePosition(p),
                  child: const Text('Tutup', style: TextStyle(color: AppColors.gold, fontSize: 12)),
                ),
            ],
          ),
        ],
      ),
    );
  }

  // ---- AKUN TAB ----
  Widget _buildAccountTab() {
    final nextReset = lastReset.add(const Duration(days: 7));
    final daysLeft = nextReset.difference(DateTime.now()).inHours / 24;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF1C2128), Color(0xFF0B0E11)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: AppColors.border),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('SALDO (VIRTUAL)', style: TextStyle(color: AppColors.textDim, fontSize: 12)),
              const SizedBox(height: 4),
              Text(fmtMoney(balance),
                  style: const TextStyle(color: AppColors.white, fontSize: 30, fontWeight: FontWeight.bold)),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(child: _accStat('Equity', fmtMoney(equity), AppColors.gold)),
                  Expanded(
                      child: _accStat('Floating P/L', '${floatingTotal >= 0 ? '+' : ''}${fmtMoney(floatingTotal)}',
                          floatingTotal >= 0 ? AppColors.green : AppColors.red)),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: AppColors.panel,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: AppColors.border),
          ),
          child: Row(
            children: [
              const Icon(Icons.refresh, color: AppColors.gold),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  'Saldo otomatis di-reset ke Rp10.000.000 setiap 7 hari.\nSisa waktu: ${daysLeft.clamp(0, 7).toStringAsFixed(1)} hari lagi.',
                  style: const TextStyle(color: AppColors.textDim, fontSize: 12),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        ElevatedButton.icon(
          onPressed: () async {
            setState(() {
              balance = 10000000;
              lastReset = DateTime.now();
              openPositions = [];
              closedPositions = [];
            });
            await _saveState();
            _showSnack('Saldo direset manual ke Rp10.000.000', AppColors.gold);
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.panelLight,
            padding: const EdgeInsets.symmetric(vertical: 12),
          ),
          icon: const Icon(Icons.restart_alt, color: AppColors.white),
          label: const Text('Reset Saldo Sekarang (Latihan)', style: TextStyle(color: AppColors.white)),
        ),
      ],
    );
  }

  Widget _accStat(String label, String value, Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(color: AppColors.textDim, fontSize: 11)),
        Text(value, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 15)),
      ],
    );
  }

  // ---- BOTTOM NAV ----
  Widget _buildBottomNav() {
    final items = [
      ('Quote', Icons.swap_vert),
      ('Chart', Icons.show_chart),
      ('Riwayat', Icons.history),
      ('Akun', Icons.account_balance_wallet),
    ];
    return Container(
      color: AppColors.panel,
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: List.generate(items.length, (i) {
          final selected = bottomTab == i;
          final badge = i == 2 && openPositions.isNotEmpty;
          return Expanded(
            child: GestureDetector(
              onTap: () => setState(() => bottomTab = i),
              child: Column(
                children: [
                  Stack(
                    clipBehavior: Clip.none,
                    children: [
                      Icon(items[i].$2, color: selected ? AppColors.gold : AppColors.textDim, size: 22),
                      if (badge)
                        Positioned(
                          right: -6,
                          top: -4,
                          child: Container(
                            padding: const EdgeInsets.all(3),
                            decoration: const BoxDecoration(color: AppColors.red, shape: BoxShape.circle),
                            child: Text('${openPositions.length}',
                                style: const TextStyle(color: Colors.white, fontSize: 9)),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 2),
                  Text(items[i].$1,
                      style: TextStyle(
                          color: selected ? AppColors.gold : AppColors.textDim,
                          fontSize: 11,
                          fontWeight: selected ? FontWeight.bold : FontWeight.normal)),
                ],
              ),
            ),
          );
        }),
      ),
    );
  }

  // ---- SHEETS & DIALOGS ----
  void _showTimeframeSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.panel,
      builder: (_) => SafeArea(
        child: Wrap(
          children: kTimeframes.map((tf) {
            return ListTile(
              title: Text(tf.label,
                  style: TextStyle(
                      color: tf.interval == timeframe.interval ? AppColors.gold : AppColors.white)),
              trailing: tf.interval == timeframe.interval
                  ? const Icon(Icons.check, color: AppColors.gold)
                  : null,
              onTap: () {
                Navigator.pop(context);
                _switchTimeframe(tf);
              },
            );
          }).toList(),
        ),
      ),
    );
  }

  void _showMarketSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.panel,
      isScrollControlled: true,
      builder: (_) => SafeArea(
        child: SizedBox(
          height: 420,
          child: Column(
            children: [
              const Padding(
                padding: EdgeInsets.all(14),
                child: Text('Pilih Market', style: TextStyle(color: AppColors.white, fontWeight: FontWeight.bold, fontSize: 16)),
              ),
              Expanded(
                child: ListView(
                  children: kMarkets.map((m) {
                    final sel = m.symbol == market.symbol;
                    return ListTile(
                      leading: CircleAvatar(
                        backgroundColor: AppColors.panelLight,
                        child: Text(m.display.substring(0, 1), style: const TextStyle(color: AppColors.gold)),
                      ),
                      title: Text(m.display, style: TextStyle(color: sel ? AppColors.gold : AppColors.white, fontWeight: FontWeight.bold)),
                      subtitle: Text(m.name, style: const TextStyle(color: AppColors.textDim, fontSize: 12)),
                      trailing: sel ? const Icon(Icons.check, color: AppColors.gold) : null,
                      onTap: () {
                        Navigator.pop(context);
                        _switchMarket(m);
                      },
                    );
                  }).toList(),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _confirmOrder(bool isBuy) {
    if (currentPrice <= 0) return;
    final price = isBuy ? askPrice : bidPrice;
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.panel,
        title: Text(isBuy ? 'Konfirmasi BUY' : 'Konfirmasi SELL',
            style: TextStyle(color: isBuy ? AppColors.green : AppColors.red, fontWeight: FontWeight.bold)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _dialogRow('Symbol', market.display),
            _dialogRow('Volume', quantity.toStringAsFixed(2)),
            _dialogRow('Harga', fmtPrice(price)),
            _dialogRow('Saldo tersedia', fmtMoney(balance)),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: isBuy ? AppColors.green : AppColors.red),
            onPressed: () {
              Navigator.pop(context);
              _openPosition(isBuy);
            },
            child: const Text('Konfirmasi', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  Widget _dialogRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: AppColors.textDim)),
          Text(value, style: const TextStyle(color: AppColors.white, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}

// =============================================================================
// CANDLESTICK CHART PAINTER
// =============================================================================
class CandleChartPainter extends CustomPainter {
  final List<Candle> candles;
  final double currentPrice;
  final double candleWidth;
  final double candleGap;

  CandleChartPainter({
    required this.candles,
    required this.currentPrice,
    required this.candleWidth,
    required this.candleGap,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (candles.isEmpty) return;

    const rightAxisWidth = 60.0;
    const bottomAxisHeight = 22.0;
    final chartWidth = size.width - rightAxisWidth;
    final chartHeight = size.height - bottomAxisHeight;

    double minP = candles.map((c) => c.low).reduce(math.min);
    double maxP = candles.map((c) => c.high).reduce(math.max);
    if (currentPrice > 0) {
      minP = math.min(minP, currentPrice);
      maxP = math.max(maxP, currentPrice);
    }
    final pad = (maxP - minP) * 0.08;
    minP -= pad;
    maxP += (maxP - minP) == 0 ? 1 : pad;
    if (maxP == minP) maxP += 1;

    double yFor(double price) => chartHeight - ((price - minP) / (maxP - minP)) * chartHeight;

    // --- Grid lines & price labels ---
    final gridPaint = Paint()
      ..color = AppColors.border.withOpacity(0.5)
      ..strokeWidth = 0.5;
    const rows = 8;
    for (int i = 0; i <= rows; i++) {
      final y = chartHeight * i / rows;
      canvas.drawLine(Offset(0, y), Offset(chartWidth, y), gridPaint);
      final price = maxP - (maxP - minP) * i / rows;
      final tp = TextPainter(
        text: TextSpan(text: fmtPrice(price), style: const TextStyle(color: AppColors.textDim, fontSize: 10)),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, Offset(chartWidth + 6, y - tp.height / 2));
    }

    // --- Vertical grid + time labels ---
    final step = math.max(1, (candles.length / 6).round());
    for (int i = 0; i < candles.length; i += step) {
      final x = i * (candleWidth + candleGap) + candleWidth / 2;
      canvas.drawLine(Offset(x, 0), Offset(x, chartHeight), gridPaint);
      final t = candles[i].time;
      final label = '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
      final tp = TextPainter(
        text: TextSpan(text: label, style: const TextStyle(color: AppColors.textDim, fontSize: 10)),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, Offset(x - tp.width / 2, chartHeight + 4));
    }

    // --- Candles ---
    for (int i = 0; i < candles.length; i++) {
      final c = candles[i];
      final x = i * (candleWidth + candleGap);
      final isBull = c.isBull;
      final color = isBull ? AppColors.green : AppColors.red;
      final paint = Paint()..color = color;
      final wickPaint = Paint()
        ..color = Colors.white70
        ..strokeWidth = 1;

      final xCenter = x + candleWidth / 2;
      canvas.drawLine(Offset(xCenter, yFor(c.high)), Offset(xCenter, yFor(c.low)), wickPaint);

      final openY = yFor(c.open);
      final closeY = yFor(c.close);
      final top = math.min(openY, closeY);
      var bottom = math.max(openY, closeY);
      if (bottom - top < 1) bottom = top + 1;
      canvas.drawRect(Rect.fromLTRB(x, top, x + candleWidth, bottom), paint);
    }

    // --- Current price dashed line + tag ---
    if (currentPrice > 0) {
      final y = yFor(currentPrice);
      final isUp = candles.isNotEmpty && currentPrice >= candles.last.open;
      final lineColor = isUp ? AppColors.green : AppColors.red;
      final dashPaint = Paint()
        ..color = lineColor
        ..strokeWidth = 1;
      double dx = 0;
      while (dx < chartWidth) {
        canvas.drawLine(Offset(dx, y), Offset(dx + 4, y), dashPaint);
        dx += 8;
      }
      final tagRect = Rect.fromLTWH(chartWidth, y - 10, rightAxisWidth, 20);
      canvas.drawRect(tagRect, Paint()..color = lineColor);
      final tp = TextPainter(
        text: TextSpan(
            text: fmtPrice(currentPrice),
            style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)),
        textDirection: TextDirection.ltr,
      )..layout(maxWidth: rightAxisWidth);
      tp.paint(canvas, Offset(chartWidth + 4, y - tp.height / 2));
    }
  }

  @override
  bool shouldRepaint(covariant CandleChartPainter oldDelegate) {
    return oldDelegate.candles.length != candles.length ||
        oldDelegate.currentPrice != currentPrice ||
        (candles.isNotEmpty &&
            oldDelegate.candles.isNotEmpty &&
            oldDelegate.candles.last.close != candles.last.close);
  }
}