import '../servers.dart';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class BugSenderPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const BugSenderPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<BugSenderPage> createState() => _BugSenderPageState();
}

class _BugSenderPageState extends State<BugSenderPage>
    with SingleTickerProviderStateMixin {
  List<dynamic> senderList = [];
  bool isLoading = false;
  bool isRefreshing = false;
  String? errorMessage;
  String baseUrl = "";
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late PageController _pageController;
  int _currentPage = 0;

  // ─── 🏁 BMW M GARAGE PALETTE ──────────────────────────────
  static const Color garageBlack   = Color(0xFF0A0A0A);
  static const Color carbonDark    = Color(0xFF121212);
  static const Color cardColor     = Color(0xFF1A1A1A);
  static const Color surfaceColor  = Color(0xFF202020);
  static const Color chromeSilver  = Color(0xFFC8C8C8);
  static const Color bmwLightBlue  = Color(0xFF0066B1);
  static const Color bmwDarkBlue   = Color(0xFF0F3D77);
  static const Color bmwRed        = Color(0xFFE32119);
  static const Color bmwBlueGlow   = Color(0xFF1C69D4);
  static const Color textPrimary   = Color(0xFFF5F5F5);
  static const Color textSecondary = Color(0xFF9E9E9E);
  static const Color successGreen  = Color(0xFF00C853);

  @override
  void initState() {
    super.initState();

    _animationController = AnimationController(
      duration: const Duration(seconds: 3),
      vsync: this,
    )..repeat(reverse: true);

    _fadeAnimation = Tween<double>(begin: 0.4, end: 0.7).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeInOut,
      ),
    );

    _pageController = PageController(
      viewportFraction: 0.88,
      initialPage: 0,
    );

    _loadConfigAndFetch();
  }

  @override
  void dispose() {
    _animationController.dispose();
    _pageController.dispose();
    super.dispose();
  }

  Future<void> _loadConfig() async {
    final response = await http.get(Uri.parse(
        Servers.configUrl));
    final data = jsonDecode(response.body);
    baseUrl = data['base_url'];
  }

  Future<void> _loadConfigAndFetch() async {
    await _loadConfig();
    await _fetchSenders();
  }

  Future<void> _fetchSenders() async {
    setState(() {
      isLoading = true;
      errorMessage = null;
    });

    try {
      final response = await http.get(
        Uri.parse("$baseUrl/mySender?key=${widget.sessionKey}"),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data["valid"] == true) {
          setState(() {
            senderList = data["connections"] ?? [];
          });
        } else {
          setState(() {
            errorMessage = data["message"] ?? "Failed to fetch senders";
          });
        }
      } else {
        setState(() {
          errorMessage = "Server error: ${response.statusCode}";
        });
      }
    } catch (e) {
      setState(() {
        errorMessage = "Connection failed: $e";
      });
    } finally {
      setState(() {
        isLoading = false;
        isRefreshing = false;
      });
    }
  }

  Future<void> _refreshSenders() async {
    setState(() => isRefreshing = true);
    await _fetchSenders();
  }

  // 🏁 M-Stripe Widget
  Widget _mStripe({double height = 3, double width = 40}) {
    return Container(
      height: height,
      width: width,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(2),
        gradient: const LinearGradient(
          colors: [bmwLightBlue, bmwDarkBlue, bmwRed],
          stops: [0.0, 0.5, 1.0],
        ),
      ),
    );
  }

  Widget _buildGarageBackground() {
    return Stack(
      children: [
        Positioned.fill(
          child: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [carbonDark, garageBlack, Color(0xFF050505)],
              ),
            ),
          ),
        ),
        Positioned.fill(
          child: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(-0.8, -0.7),
                radius: 1.4,
                colors: [
                  bmwBlueGlow.withOpacity(0.12),
                  Colors.transparent,
                ],
                stops: const [0.0, 1.0],
              ),
            ),
          ),
        ),
        Positioned.fill(
          child: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(1.0, 1.0),
                radius: 1.2,
                colors: [
                  bmwRed.withOpacity(0.08),
                  Colors.transparent,
                ],
                stops: const [0.0, 1.0],
              ),
            ),
          ),
        ),
        Positioned.fill(
          child: CustomPaint(painter: _GridPatternPainter()),
        ),
      ],
    );
  }

  Widget _buildGarageHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      decoration: BoxDecoration(
        color: carbonDark.withOpacity(0.85),
        border: Border(
          bottom: BorderSide(
            color: chromeSilver.withOpacity(0.1),
            width: 1,
          ),
        ),
      ),
      child: Column(
        children: [
          Row(
            children: [
              // Roundel icon
              Container(
                width: 46,
                height: 46,
                padding: const EdgeInsets.all(2),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(
                    colors: [bmwLightBlue, bmwDarkBlue, bmwRed],
                    stops: [0.0, 0.5, 1.0],
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: bmwBlueGlow.withOpacity(0.4),
                      blurRadius: 15,
                    ),
                  ],
                ),
                child: Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: garageBlack,
                    border: Border.all(
                      color: chromeSilver.withOpacity(0.4),
                      width: 0.8,
                    ),
                  ),
                  child: const Icon(
                    Icons.send_rounded,
                    color: chromeSilver,
                    size: 20,
                  ),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      "SENDER BAY",
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: textPrimary,
                        letterSpacing: 2.5,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      "/// M CONNECTION MODULE",
                      style: TextStyle(
                        color: chromeSilver.withOpacity(0.6),
                        fontSize: 9,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 2,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ],
                ),
              ),
              // Status pill
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 12, vertical: 7),
                decoration: BoxDecoration(
                  color: cardColor.withOpacity(0.7),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: chromeSilver.withOpacity(0.2),
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: successGreen,
                        boxShadow: [
                          BoxShadow(
                            color: successGreen.withOpacity(0.8),
                            blurRadius: 6,
                            spreadRadius: 1,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      "${senderList.length} LIVE",
                      style: const TextStyle(
                        color: textPrimary,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.5,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          _mStripe(height: 3, width: double.infinity),
        ],
      ),
    );
  }

  Widget _buildCarouselSenderCards() {
    if (senderList.isEmpty) {
      return _buildEmptyState();
    }

    return Column(
      children: [
        SizedBox(
          height: 310,
          child: PageView.builder(
            controller: _pageController,
            itemCount: senderList.length,
            onPageChanged: (index) {
              setState(() {
                _currentPage = index;
              });
            },
            itemBuilder: (context, index) {
              final sender = Map<String, dynamic>.from(senderList[index]);
              return _buildGarageSenderCard(sender, index);
            },
          ),
        ),
        const SizedBox(height: 22),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(senderList.length, (index) {
            final isActive = index == _currentPage;
            return AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              margin: const EdgeInsets.symmetric(horizontal: 3),
              width: isActive ? 26 : 6,
              height: 4,
              decoration: BoxDecoration(
                gradient: isActive
                    ? const LinearGradient(
                        colors: [bmwLightBlue, bmwDarkBlue, bmwRed],
                      )
                    : null,
                color: isActive ? null : chromeSilver.withOpacity(0.2),
                borderRadius: BorderRadius.circular(2),
              ),
            );
          }),
        ),
        const SizedBox(height: 28),
      ],
    );
  }

  Widget _buildGarageSenderCard(Map<String, dynamic> sender, int index) {
    final name = sender['sessionName'] ?? 'Unnamed Sender';
    final phone = sender['id']?.split(':')[0]?.split('@')[0] ?? 'Unknown';
    final isActive = index == _currentPage;

    return AnimatedBuilder(
      animation: _pageController,
      builder: (context, child) {
        double scale = 1.0;
        double opacity = 1.0;
        if (_pageController.position.haveDimensions) {
          final value = (_pageController.page ?? 0) - index;
          scale = (1 - (value.abs() * 0.15)).clamp(0.85, 1.0);
          opacity = (1 - (value.abs() * 0.3)).clamp(0.7, 1.0);
        }

        return Transform.scale(
          scale: scale,
          child: Opacity(
            opacity: opacity,
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
              child: Stack(
                children: [
                  Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(18),
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          cardColor.withOpacity(0.9),
                          carbonDark.withOpacity(0.95),
                        ],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.5),
                          blurRadius: 20,
                          offset: const Offset(0, 4),
                        ),
                        if (isActive)
                          BoxShadow(
                            color: bmwBlueGlow.withOpacity(0.15),
                            blurRadius: 30,
                            spreadRadius: 2,
                          ),
                      ],
                      border: Border.all(
                        color: chromeSilver.withOpacity(0.15),
                        width: 1,
                      ),
                    ),
                    child: Stack(
                      children: [
                        // Top M-stripe
                        Positioned(
                          top: 0,
                          left: 0,
                          right: 0,
                          child: ClipRRect(
                            borderRadius: const BorderRadius.only(
                              topLeft: Radius.circular(18),
                              topRight: Radius.circular(18),
                            ),
                            child: Container(
                              height: 3,
                              decoration: const BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    bmwLightBlue,
                                    bmwDarkBlue,
                                    bmwRed,
                                  ],
                                  stops: [0.0, 0.5, 1.0],
                                ),
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(20, 22, 20, 20),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Header row
                              Row(
                                children: [
                                  Container(
                                    width: 46,
                                    height: 46,
                                    padding: const EdgeInsets.all(2),
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      gradient: const LinearGradient(
                                        colors: [bmwLightBlue, bmwDarkBlue],
                                      ),
                                      boxShadow: [
                                        BoxShadow(
                                          color: bmwBlueGlow.withOpacity(0.4),
                                          blurRadius: 12,
                                        ),
                                      ],
                                    ),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: garageBlack,
                                        border: Border.all(
                                          color: chromeSilver.withOpacity(0.3),
                                          width: 0.8,
                                        ),
                                      ),
                                      child: const Icon(
                                        Icons.phone_android_rounded,
                                        color: chromeSilver,
                                        size: 20,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 14),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          name.toUpperCase(),
                                          style: const TextStyle(
                                            color: textPrimary,
                                            fontSize: 14,
                                            fontWeight: FontWeight.bold,
                                            letterSpacing: 1,
                                            fontFamily: 'Orbitron',
                                          ),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          phone,
                                          style: TextStyle(
                                            color: chromeSilver
                                                .withOpacity(0.7),
                                            fontSize: 12,
                                            fontFamily: 'ShareTechMono',
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 8,
                                      vertical: 4,
                                    ),
                                    decoration: BoxDecoration(
                                      color: successGreen.withOpacity(0.12),
                                      borderRadius: BorderRadius.circular(10),
                                      border: Border.all(
                                        color: successGreen.withOpacity(0.4),
                                        width: 1,
                                      ),
                                      boxShadow: [
                                        BoxShadow(
                                          color: successGreen
                                              .withOpacity(0.2),
                                          blurRadius: 8,
                                        ),
                                      ],
                                    ),
                                    child: Row(
                                      children: [
                                        Container(
                                          width: 5,
                                          height: 5,
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            color: successGreen,
                                            boxShadow: [
                                              BoxShadow(
                                                color: successGreen
                                                    .withOpacity(0.8),
                                                blurRadius: 5,
                                              ),
                                            ],
                                          ),
                                        ),
                                        const SizedBox(width: 5),
                                        const Text(
                                          "ONLINE",
                                          style: TextStyle(
                                            color: successGreen,
                                            fontSize: 9,
                                            fontWeight: FontWeight.bold,
                                            letterSpacing: 1,
                                            fontFamily: 'ShareTechMono',
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 20),

                              // Divider
                              _mStripe(
                                  height: 1,
                                  width: double.infinity),

                              const SizedBox(height: 20),

                              // Action buttons
                              Row(
                                children: [
                                  Expanded(
                                    child: Material(
                                      color: Colors.transparent,
                                      borderRadius: BorderRadius.circular(10),
                                      child: InkWell(
                                        onTap: () => _refreshSenders(),
                                        borderRadius: BorderRadius.circular(10),
                                        child: Container(
                                          padding: const EdgeInsets.symmetric(
                                            vertical: 12,
                                          ),
                                          decoration: BoxDecoration(
                                            color: surfaceColor.withOpacity(0.6),
                                            borderRadius:
                                                BorderRadius.circular(10),
                                            border: Border.all(
                                              color: chromeSilver
                                                  .withOpacity(0.15),
                                              width: 1,
                                            ),
                                          ),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              Icon(
                                                Icons.refresh_rounded,
                                                color: chromeSilver
                                                    .withOpacity(0.9),
                                                size: 15,
                                              ),
                                              const SizedBox(width: 6),
                                              Text(
                                                "REFRESH",
                                                style: TextStyle(
                                                  color: chromeSilver
                                                      .withOpacity(0.9),
                                                  fontSize: 11,
                                                  fontWeight: FontWeight.bold,
                                                  letterSpacing: 1,
                                                  fontFamily:
                                                      'ShareTechMono',
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: Material(
                                      color: Colors.transparent,
                                      borderRadius: BorderRadius.circular(10),
                                      child: InkWell(
                                        onTap: () =>
                                            _deleteSender(sender['id']),
                                        borderRadius: BorderRadius.circular(10),
                                        child: Container(
                                          padding: const EdgeInsets.symmetric(
                                            vertical: 12,
                                          ),
                                          decoration: BoxDecoration(
                                            color: bmwRed.withOpacity(0.08),
                                            borderRadius:
                                                BorderRadius.circular(10),
                                            border: Border.all(
                                              color:
                                                  bmwRed.withOpacity(0.35),
                                              width: 1,
                                            ),
                                          ),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              const Icon(
                                                Icons.delete_outline_rounded,
                                                color: bmwRed,
                                                size: 15,
                                              ),
                                              const SizedBox(width: 6),
                                              const Text(
                                                "DELETE",
                                                style: TextStyle(
                                                  color: bmwRed,
                                                  fontSize: 11,
                                                  fontWeight: FontWeight.bold,
                                                  letterSpacing: 1,
                                                  fontFamily:
                                                      'ShareTechMono',
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 14),

                              // Info row
                              Container(
                                padding: const EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  color: surfaceColor.withOpacity(0.4),
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(
                                    color: bmwBlueGlow.withOpacity(0.2),
                                    width: 1,
                                  ),
                                ),
                                child: Row(
                                  children: [
                                    const Icon(
                                      Icons.info_outline_rounded,
                                      color: bmwBlueGlow,
                                      size: 13,
                                    ),
                                    const SizedBox(width: 8),
                                    Expanded(
                                      child: Text(
                                        "Engine linked · WhatsApp Web active",
                                        style: TextStyle(
                                          color: chromeSilver
                                              .withOpacity(0.7),
                                          fontSize: 10,
                                          letterSpacing: 0.5,
                                          fontFamily: 'ShareTechMono',
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Empty roundel
            Container(
              width: 100,
              height: 100,
              padding: const EdgeInsets.all(3),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [
                    chromeSilver.withOpacity(0.2),
                    chromeSilver.withOpacity(0.05),
                  ],
                ),
                border: Border.all(
                  color: chromeSilver.withOpacity(0.15),
                  width: 1,
                ),
              ),
              child: Container(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: garageBlack,
                  border: Border.all(
                    color: chromeSilver.withOpacity(0.15),
                  ),
                ),
                child: Icon(
                  Icons.phone_iphone_rounded,
                  color: chromeSilver.withOpacity(0.4),
                  size: 38,
                ),
              ),
            ),
            const SizedBox(height: 28),
            ShaderMask(
              shaderCallback: (bounds) => const LinearGradient(
                colors: [Color(0xFFFFFFFF), Color(0xFFC8C8C8), Color(0xFF7A7A7A)],
                stops: [0.0, 0.5, 1.0],
              ).createShader(bounds),
              child: const Text(
                "NO SENDER BAY",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 3,
                  fontFamily: 'Orbitron',
                ),
              ),
            ),
            const SizedBox(height: 12),
            _mStripe(height: 3, width: 100),
            const SizedBox(height: 24),
            Container(
              padding: const EdgeInsets.all(18),
              width: 280,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    cardColor.withOpacity(0.85),
                    carbonDark.withOpacity(0.95),
                  ],
                ),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: chromeSilver.withOpacity(0.15),
                ),
              ),
              child: Column(
                children: [
                  const Icon(
                    Icons.add_circle_outline_rounded,
                    color: bmwBlueGlow,
                    size: 26,
                  ),
                  const SizedBox(height: 12),
                  Text(
                    "Add your first WhatsApp sender\nto start using premium features",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: chromeSilver.withOpacity(0.7),
                      fontSize: 12,
                      height: 1.5,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 36),
            _buildPrimaryButton(
              label: "ADD FIRST SENDER",
              icon: Icons.add_rounded,
              onTap: _showAddSenderDialog,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildErrorState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: bmwRed.withOpacity(0.1),
                border: Border.all(
                  color: bmwRed.withOpacity(0.4),
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: bmwRed.withOpacity(0.3),
                    blurRadius: 15,
                  ),
                ],
              ),
              child: const Icon(
                Icons.error_outline_rounded,
                color: bmwRed,
                size: 30,
              ),
            ),
            const SizedBox(height: 22),
            const Text(
              "CONNECTION ERROR",
              style: TextStyle(
                color: textPrimary,
                fontSize: 15,
                fontWeight: FontWeight.bold,
                letterSpacing: 2,
                fontFamily: 'Orbitron',
              ),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(16),
              width: 280,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    cardColor.withOpacity(0.85),
                    carbonDark.withOpacity(0.95),
                  ],
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: bmwRed.withOpacity(0.25)),
              ),
              child: Text(
                errorMessage ?? "Unknown error occurred",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: chromeSilver.withOpacity(0.7),
                  fontSize: 11,
                  height: 1.5,
                  fontFamily: 'ShareTechMono',
                ),
              ),
            ),
            const SizedBox(height: 24),
            _buildOutlineButton(
              label: "RETRY CONNECTION",
              icon: Icons.refresh_rounded,
              onTap: _fetchSenders,
            ),
          ],
        ),
      ),
    );
  }

  // ─── PRIMARY BUTTON (M-Gradient) ───
  Widget _buildPrimaryButton({
    required String label,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(10),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(10),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [bmwLightBlue, bmwDarkBlue, bmwRed],
              stops: [0.0, 0.5, 1.0],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: chromeSilver.withOpacity(0.35),
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: bmwBlueGlow.withOpacity(0.4),
                blurRadius: 16,
                spreadRadius: 1,
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: Colors.white, size: 16),
              const SizedBox(width: 10),
              Text(
                label,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 2,
                  fontFamily: 'Orbitron',
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── OUTLINE BUTTON (Chrome) ───
  Widget _buildOutlineButton({
    required String label,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(10),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(10),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 12),
          decoration: BoxDecoration(
            color: cardColor.withOpacity(0.6),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: chromeSilver.withOpacity(0.4),
              width: 1,
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: chromeSilver, size: 15),
              const SizedBox(width: 8),
              Text(
                label,
                style: const TextStyle(
                  color: chromeSilver,
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.5,
                  fontFamily: 'ShareTechMono',
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showAddSenderDialog() {
    final phoneController = TextEditingController();

    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.75),
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.all(24),
        child: Container(
          width: MediaQuery.of(context).size.width * 0.85,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                cardColor.withOpacity(0.95),
                carbonDark.withOpacity(0.98),
              ],
            ),
            border: Border.all(
              color: chromeSilver.withOpacity(0.2),
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.6),
                blurRadius: 30,
              ),
              BoxShadow(
                color: bmwBlueGlow.withOpacity(0.15),
                blurRadius: 30,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Stack(
            children: [
              // Top M-stripe
              Positioned(
                top: 0,
                left: 0,
                right: 0,
                child: ClipRRect(
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(18),
                    topRight: Radius.circular(18),
                  ),
                  child: Container(
                    height: 3,
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        colors: [bmwLightBlue, bmwDarkBlue, bmwRed],
                        stops: [0.0, 0.5, 1.0],
                      ),
                    ),
                  ),
                ),
              ),
              Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(22, 24, 22, 16),
                    child: Row(
                      children: [
                        Container(
                          width: 38,
                          height: 38,
                          padding: const EdgeInsets.all(2),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: const LinearGradient(
                              colors: [bmwLightBlue, bmwDarkBlue],
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: bmwBlueGlow.withOpacity(0.4),
                                blurRadius: 10,
                              ),
                            ],
                          ),
                          child: Container(
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: garageBlack,
                              border: Border.all(
                                color: chromeSilver.withOpacity(0.3),
                                width: 0.8,
                              ),
                            ),
                            child: const Icon(
                              Icons.add_rounded,
                              color: chromeSilver,
                              size: 18,
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        const Expanded(
                          child: Text(
                            "ADD NEW SENDER",
                            style: TextStyle(
                              color: textPrimary,
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 2,
                              fontFamily: 'Orbitron',
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  _mStripe(height: 1, width: double.infinity),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(22, 20, 22, 22),
                    child: Column(
                      children: [
                        _buildGarageTextField(
                          controller: phoneController,
                          label: "PHONE NUMBER",
                          icon: Icons.phone_rounded,
                          hint: "62xxxxxxxxxx",
                          isPhone: true,
                        ),
                        const SizedBox(height: 22),
                        Row(
                          children: [
                            Expanded(
                              child: _buildOutlineButton(
                                label: "CANCEL",
                                icon: Icons.close_rounded,
                                onTap: () => Navigator.pop(context),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: _buildPrimaryButton(
                                label: "CONNECT",
                                icon: Icons.power_settings_new_rounded,
                                onTap: () async {
                                  final number =
                                      phoneController.text.trim();
                                  if (number.isEmpty) {
                                    _showSnackBar(
                                      "Please enter phone number",
                                      isError: true,
                                    );
                                    return;
                                  }
                                  Navigator.pop(context);
                                  await _addSender(number, "");
                                },
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildGarageTextField({
    required TextEditingController controller,
    required String label,
    required dynamic icon,
    required String hint,
    bool isPhone = false,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            color: chromeSilver.withOpacity(0.8),
            fontSize: 10,
            fontWeight: FontWeight.bold,
            letterSpacing: 2,
            fontFamily: 'ShareTechMono',
          ),
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: surfaceColor.withOpacity(0.6),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: chromeSilver.withOpacity(0.15),
              width: 1,
            ),
          ),
          child: TextField(
            controller: controller,
            keyboardType:
                isPhone ? TextInputType.phone : TextInputType.text,
            style: const TextStyle(
              color: textPrimary,
              fontSize: 14,
              fontFamily: 'ShareTechMono',
            ),
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: TextStyle(
                color: chromeSilver.withOpacity(0.4),
                fontFamily: 'ShareTechMono',
              ),
              prefixIcon: Icon(icon, color: bmwBlueGlow, size: 18),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 14,
                vertical: 14,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Future<void> _addSender(String number, String name) async {
    BuildContext? loadingContext;
    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withOpacity(0.75),
      builder: (context) {
        loadingContext = context;
        return Dialog(
          backgroundColor: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.all(28),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              gradient: LinearGradient(
                colors: [
                  cardColor.withOpacity(0.95),
                  carbonDark.withOpacity(0.98),
                ],
              ),
              border: Border.all(
                color: chromeSilver.withOpacity(0.2),
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const LinearGradient(
                      colors: [bmwLightBlue, bmwDarkBlue],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: bmwBlueGlow.withOpacity(0.5),
                        blurRadius: 15,
                      ),
                    ],
                  ),
                  child: const Icon(
                    Icons.qr_code_2_rounded,
                    color: Colors.white,
                    size: 24,
                  ),
                ),
                const SizedBox(height: 16),
                const Text(
                  "GENERATING CODE",
                  style: TextStyle(
                    color: textPrimary,
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                    fontFamily: 'Orbitron',
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  "Please wait while we create your pairing code",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: chromeSilver.withOpacity(0.6),
                    fontSize: 11,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
                const SizedBox(height: 16),
                const SizedBox(
                  width: 24,
                  height: 24,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    valueColor: AlwaysStoppedAnimation(bmwBlueGlow),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );

    setState(() => isLoading = true);

    try {
      final response = await http.get(
        Uri.parse(
            "$baseUrl/getPairing?key=${widget.sessionKey}&number=$number"),
      );

      if (loadingContext != null && mounted) {
        Navigator.of(loadingContext!).pop();
      }

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data["valid"] == true) {
          _showPairingCodeDialog(number, data['pairingCode'], name);
          _showSnackBar("Pairing code generated successfully!",
              isError: false);
        } else {
          _showSnackBar(data['message'] ?? "Failed to generate pairing code",
              isError: true);
        }
      } else {
        _showSnackBar("Server error: ${response.statusCode}", isError: true);
      }
    } catch (e) {
      if (loadingContext != null && mounted) {
        Navigator.of(loadingContext!).pop();
      }
      _showSnackBar("Connection failed: $e", isError: true);
    } finally {
      setState(() => isLoading = false);
      _fetchSenders();
    }
  }

  void _showPairingCodeDialog(String number, String code, String name) {
    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withOpacity(0.8),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.all(20),
        child: Container(
          width: MediaQuery.of(context).size.width * 0.85,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                cardColor.withOpacity(0.95),
                carbonDark.withOpacity(0.98),
              ],
            ),
            border: Border.all(
              color: chromeSilver.withOpacity(0.2),
            ),
            boxShadow: [
              BoxShadow(
                color: bmwBlueGlow.withOpacity(0.15),
                blurRadius: 30,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Stack(
            children: [
              // Top M-stripe
              Positioned(
                top: 0,
                left: 0,
                right: 0,
                child: ClipRRect(
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(18),
                    topRight: Radius.circular(18),
                  ),
                  child: Container(
                    height: 3,
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        colors: [bmwLightBlue, bmwDarkBlue, bmwRed],
                        stops: [0.0, 0.5, 1.0],
                      ),
                    ),
                  ),
                ),
              ),
              Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 22, 20, 14),
                    child: Row(
                      children: [
                        Container(
                          width: 40,
                          height: 40,
                          padding: const EdgeInsets.all(2),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: const LinearGradient(
                              colors: [bmwLightBlue, bmwDarkBlue],
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: bmwBlueGlow.withOpacity(0.4),
                                blurRadius: 10,
                              ),
                            ],
                          ),
                          child: Container(
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: garageBlack,
                              border: Border.all(
                                color: chromeSilver.withOpacity(0.3),
                                width: 0.8,
                              ),
                            ),
                            child: const Icon(
                              Icons.qr_code_scanner_rounded,
                              color: chromeSilver,
                              size: 18,
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        const Expanded(
                          child: Text(
                            "PAIRING REQUIRED",
                            style: TextStyle(
                              color: textPrimary,
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 2,
                              fontFamily: 'Orbitron',
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: Column(
                      children: [
                        // Phone number display
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: surfaceColor.withOpacity(0.5),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: chromeSilver.withOpacity(0.15),
                            ),
                          ),
                          child: Row(
                            children: [
                              const Icon(Icons.phone_rounded,
                                  color: bmwBlueGlow, size: 16),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "PHONE NUMBER",
                                      style: TextStyle(
                                        color: chromeSilver
                                            .withOpacity(0.6),
                                        fontSize: 9,
                                        fontWeight: FontWeight.bold,
                                        letterSpacing: 1.5,
                                        fontFamily: 'ShareTechMono',
                                      ),
                                    ),
                                    const SizedBox(height: 3),
                                    Text(
                                      number,
                                      style: const TextStyle(
                                        color: textPrimary,
                                        fontSize: 13,
                                        fontWeight: FontWeight.bold,
                                        fontFamily: 'ShareTechMono',
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),

                        // Pairing code display
                        Container(
                          padding: const EdgeInsets.symmetric(
                              vertical: 22, horizontal: 16),
                          decoration: BoxDecoration(
                            color: garageBlack,
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(
                              color: bmwBlueGlow.withOpacity(0.4),
                              width: 1.5,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: bmwBlueGlow.withOpacity(0.2),
                                blurRadius: 20,
                                spreadRadius: 2,
                              ),
                            ],
                          ),
                          child: Column(
                            children: [
                              Text(
                                "PAIRING CODE",
                                style: TextStyle(
                                  color: chromeSilver.withOpacity(0.7),
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 2,
                                  fontFamily: 'ShareTechMono',
                                ),
                              ),
                              const SizedBox(height: 12),
                              ShaderMask(
                                shaderCallback: (bounds) =>
                                    const LinearGradient(
                                  colors: [
                                    bmwLightBlue,
                                    chromeSilver,
                                    bmwRed,
                                  ],
                                  stops: [0.0, 0.5, 1.0],
                                ).createShader(bounds),
                                child: Text(
                                  code,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 32,
                                    fontWeight: FontWeight.w900,
                                    fontFamily: 'RobotoMono',
                                    letterSpacing: 6,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                "VALID FOR 20 MINUTES",
                                style: TextStyle(
                                  color: chromeSilver.withOpacity(0.5),
                                  fontSize: 9,
                                  letterSpacing: 1.5,
                                  fontFamily: 'ShareTechMono',
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),

                        // Instructions
                        Container(
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(
                            color: surfaceColor.withOpacity(0.4),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: chromeSilver.withOpacity(0.1),
                            ),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  const Icon(
                                    Icons.info_outline_rounded,
                                    color: bmwBlueGlow,
                                    size: 14,
                                  ),
                                  const SizedBox(width: 8),
                                  Text(
                                    "PROCEDURE",
                                    style: TextStyle(
                                      color: chromeSilver.withOpacity(0.9),
                                      fontSize: 10,
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 2,
                                      fontFamily: 'ShareTechMono',
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 12),
                              _buildInstructionStep(
                                number: "1",
                                title: "Open WhatsApp",
                                description: "Go to Settings menu",
                              ),
                              const SizedBox(height: 8),
                              _buildInstructionStep(
                                number: "2",
                                title: "Linked Devices",
                                description: "Tap on 'Linked Devices'",
                              ),
                              const SizedBox(height: 8),
                              _buildInstructionStep(
                                number: "3",
                                title: "Link a Device",
                                description: "Select 'Link a Device'",
                              ),
                              const SizedBox(height: 8),
                              _buildInstructionStep(
                                number: "4",
                                title: "Enter Code",
                                description: "Type the 6-digit code above",
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 18),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
                    child: Row(
                      children: [
                        Expanded(
                          child: _buildOutlineButton(
                            label: "CLOSE",
                            icon: Icons.close_rounded,
                            onTap: () => Navigator.pop(context),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: _buildPrimaryButton(
                            label: "REFRESH",
                            icon: Icons.refresh_rounded,
                            onTap: () {
                              Navigator.pop(context);
                              _fetchSenders();
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInstructionStep({
    required String number,
    required String title,
    required String description,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 20,
          height: 20,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const LinearGradient(
              colors: [bmwLightBlue, bmwDarkBlue],
            ),
            boxShadow: [
              BoxShadow(
                color: bmwBlueGlow.withOpacity(0.3),
                blurRadius: 6,
              ),
            ],
          ),
          child: Center(
            child: Text(
              number,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 10,
                fontWeight: FontWeight.bold,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  color: textPrimary,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 0.5,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                description,
                style: TextStyle(
                  color: chromeSilver.withOpacity(0.6),
                  fontSize: 10,
                  height: 1.4,
                  fontFamily: 'ShareTechMono',
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Future<void> _deleteSender(String senderId) async {
    final confirmed = await showDialog<bool>(
      context: context,
      barrierColor: Colors.black.withOpacity(0.8),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          width: MediaQuery.of(context).size.width * 0.78,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            gradient: LinearGradient(
              colors: [
                cardColor.withOpacity(0.95),
                carbonDark.withOpacity(0.98),
              ],
            ),
            border: Border.all(color: bmwRed.withOpacity(0.4), width: 1.5),
            boxShadow: [
              BoxShadow(
                color: bmwRed.withOpacity(0.3),
                blurRadius: 25,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Stack(
            children: [
              Positioned(
                top: 0,
                left: 0,
                right: 0,
                child: ClipRRect(
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(16),
                    topRight: Radius.circular(16),
                  ),
                  child: Container(
                    height: 3,
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        colors: [bmwLightBlue, bmwDarkBlue, bmwRed],
                        stops: [0.0, 0.5, 1.0],
                      ),
                    ),
                  ),
                ),
              ),
              Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 22, 20, 16),
                    child: Row(
                      children: [
                        Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: bmwRed.withOpacity(0.15),
                            border: Border.all(
                              color: bmwRed.withOpacity(0.5),
                              width: 1.5,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: bmwRed.withOpacity(0.3),
                                blurRadius: 12,
                              ),
                            ],
                          ),
                          child: const Icon(
                            Icons.warning_amber_rounded,
                            color: bmwRed,
                            size: 20,
                          ),
                        ),
                        const SizedBox(width: 12),
                        const Expanded(
                          child: Text(
                            "CONFIRM DELETE",
                            style: TextStyle(
                              color: textPrimary,
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 2,
                              fontFamily: 'Orbitron',
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
                    child: Column(
                      children: [
                        Text(
                          "Are you sure you want to delete this sender?\nThis action cannot be undone.",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: chromeSilver.withOpacity(0.75),
                            fontSize: 12,
                            height: 1.5,
                            fontFamily: 'ShareTechMono',
                          ),
                        ),
                        const SizedBox(height: 22),
                        Row(
                          children: [
                            Expanded(
                              child: _buildOutlineButton(
                                label: "CANCEL",
                                icon: Icons.close_rounded,
                                onTap: () => Navigator.pop(context, false),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Material(
                                color: Colors.transparent,
                                borderRadius: BorderRadius.circular(10),
                                child: InkWell(
                                  onTap: () =>
                                      Navigator.pop(context, true),
                                  borderRadius: BorderRadius.circular(10),
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 12),
                                    decoration: BoxDecoration(
                                      gradient: const LinearGradient(
                                        colors: [
                                          bmwRed,
                                          Color(0xFF8B0F0A),
                                        ],
                                      ),
                                      borderRadius:
                                          BorderRadius.circular(10),
                                      boxShadow: [
                                        BoxShadow(
                                          color: bmwRed.withOpacity(0.4),
                                          blurRadius: 15,
                                        ),
                                      ],
                                    ),
                                    child: const Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Icon(Icons.delete_outline_rounded,
                                            color: Colors.white, size: 15),
                                        SizedBox(width: 6),
                                        Text(
                                          "DELETE",
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 11,
                                            fontWeight: FontWeight.bold,
                                            letterSpacing: 1.5,
                                            fontFamily: 'ShareTechMono',
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );

    if (confirmed == true) {
      setState(() => isLoading = true);

      try {
        final response = await http.delete(
          Uri.parse(
              "$baseUrl/deleteSender?key=${widget.sessionKey}&id=$senderId"),
        );

        if (response.statusCode == 200) {
          final data = jsonDecode(response.body);
          if (data["valid"] == true) {
            _showSnackBar("Sender deleted successfully!", isError: false);
            _fetchSenders();
          } else {
            _showSnackBar(data["message"] ?? "Failed to delete sender",
                isError: true);
          }
        } else {
          _showSnackBar("Server error: ${response.statusCode}",
              isError: true);
        }
      } catch (e) {
        _showSnackBar("Connection failed: $e", isError: true);
      } finally {
        setState(() => isLoading = false);
      }
    }
  }

  void _showSnackBar(String message, {bool isError = false}) {
    final color = isError ? bmwRed : successGreen;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                cardColor.withOpacity(0.95),
                carbonDark.withOpacity(0.95),
              ],
            ),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: color.withOpacity(0.5), width: 1.5),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.3),
                blurRadius: 15,
              ),
            ],
          ),
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: color.withOpacity(0.15),
                  border: Border.all(color: color.withOpacity(0.5)),
                ),
                child: Icon(
                  isError
                      ? Icons.error_outline_rounded
                      : Icons.check_circle_rounded,
                  color: color,
                  size: 14,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  message,
                  style: const TextStyle(
                    color: textPrimary,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'ShareTechMono',
                    letterSpacing: 0.5,
                  ),
                ),
              ),
            ],
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 3),
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: garageBlack,
      body: Stack(
        children: [
          _buildGarageBackground(),
          SafeArea(
            child: Column(
              children: [
                _buildGarageHeader(),
                Expanded(
                  child: isLoading && senderList.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              SizedBox(
                                width: 44,
                                height: 44,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2.5,
                                  valueColor: const AlwaysStoppedAnimation(
                                      bmwBlueGlow),
                                ),
                              ),
                              const SizedBox(height: 16),
                              Text(
                                "SCANNING BAYS...",
                                style: TextStyle(
                                  color: chromeSilver.withOpacity(0.7),
                                  fontSize: 10,
                                  letterSpacing: 3,
                                  fontFamily: 'ShareTechMono',
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        )
                      : errorMessage != null && senderList.isEmpty
                          ? _buildErrorState()
                          : _buildCarouselSenderCards(),
                ),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: Container(
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: const LinearGradient(
            colors: [bmwLightBlue, bmwDarkBlue, bmwRed],
            stops: [0.0, 0.5, 1.0],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          boxShadow: [
            BoxShadow(
              color: bmwBlueGlow.withOpacity(0.5),
              blurRadius: 20,
              spreadRadius: 2,
            ),
            BoxShadow(
              color: bmwRed.withOpacity(0.3),
              blurRadius: 20,
              offset: const Offset(4, 4),
            ),
          ],
        ),
        child: FloatingActionButton(
          backgroundColor: Colors.transparent,
          foregroundColor: Colors.white,
          onPressed: _showAddSenderDialog,
          elevation: 0,
          child: const Icon(Icons.add_rounded, size: 26),
        ),
      ),
    );
  }
}

// ─── CARBON GRID PAINTER ───────────────────────────────────────────────────
class _GridPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF1C69D4).withOpacity(0.04)
      ..strokeWidth = 0.5
      ..style = PaintingStyle.stroke;

    const double spacing = 50;
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}