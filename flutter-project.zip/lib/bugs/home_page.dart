import '../servers.dart';
import 'dart:async';
import 'dart:convert';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'dart:core';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  final groupLinkController = TextEditingController();
  String selectedBugId = "";
  bool _isSending = false;
  String? _responseMessage;
  int _selectedPrivateBugIndex = 0;
  int _selectedGlobalBugIndex = 0;
  int _selectedGroupBugIndex = 0;
  bool _isRefreshing = false;
  late VideoPlayerController _videoController;
  bool _isVideoInitialized = false;
  bool _isGroupMode = false;

  // ─── 🏁 BMW M GARAGE PALETTE ──────────────────────────────
  static const Color garageBlack   = Color(0xFF0A0A0A);
  static const Color carbonDark    = Color(0xFF121212);
  static const Color cardColor     = Color(0xFF1A1A1A);
  static const Color surfaceColor  = Color(0xFF202020);
  static const Color chromeSilver  = Color(0xFFC8C8C8);
  static const Color bmwLightBlue  = Color(0xFF0066B1);
  static const Color bmwDarkBlue   = Color(0xFF0F3D77);
  static const Color bmwRed        = Color(0xFFE32119);
  static const Color bmwBlueGlow   = Color(0xFF1C69D4);
  static const Color textPrimary   = Color(0xFFF5F5F5);
  static const Color textSecondary = Color(0xFF9E9E9E);
  static const Color successGreen  = Color(0xFF00C853);

  // Compatibility aliases (supaya logic lama tidak error)
  final Color primaryDark = garageBlack;
  final Color cardDark = cardColor;
  final Color cardDarker = carbonDark;
  final Color goldColor = const Color(0xFFFFD700);
  final Color blueColor = bmwBlueGlow;

  late AnimationController _controller;
  late AnimationController _fadeController;
  late Animation<double> _animation;
  late Animation<double> _fadeAnimation;

  // Variabel untuk sender status
  String _selectedSenderMode = "private";
  int _privateActive = 0;
  int _globalActive = 0;
  bool _isLoadingSenders = false;
  Timer? _refreshTimer;

  // Cooldown global sender
  bool _isGlobalCooldown = false;
  int _globalCooldownSeconds = 0;
  Timer? _cooldownTimer;

  String baseUrl = "";

  List<Map<String, dynamic>> groupBugs = [];

  // GLOBAL BUGS DIAMBIL DARI API (TIDAK HARDCODE)
  List<Map<String, dynamic>> globalBugs = [];

  @override
  void initState() {
    super.initState();

    if (widget.listBug.isNotEmpty) {
      selectedBugId = widget.listBug[0]['bug_id'];
      _selectedPrivateBugIndex = 0;
    }

    if (groupBugs.isNotEmpty) {
      _selectedGroupBugIndex = 0;
    }

    _controller = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    );

    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeInOut),
    );

    _controller.forward();
    _fadeController.forward();

    _initializeVideoPlayer();
    _loadConfigAndFetch();

    _refreshTimer = Timer.periodic(const Duration(seconds: 30), (timer) {
      if (mounted) {
        fetchActiveSenders();
      }
    });
  }

  Future<void> _loadConfig() async {
    final response = await http.get(Uri.parse(Servers.configUrl));
    final data = jsonDecode(response.body);
    baseUrl = data['base_url'];
  }

  Future<void> _loadGlobalBugs() async {
    try {
      final response = await http.get(
        Uri.parse("$baseUrl/getGlobalBugs"),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true && data['bugs'] != null) {
          setState(() {
            globalBugs = List<Map<String, dynamic>>.from(data['bugs']);
            if (globalBugs.isNotEmpty && _selectedGlobalBugIndex == 0) {
              _selectedGlobalBugIndex = 0;
            }
          });
        }
      }
    } catch (e) {
      print("Error load global bugs: $e");
      setState(() {
        globalBugs = [];
      });
    }
  }

  Future<void> _loadConfigAndFetch() async {
    await _loadConfig();
    await _loadGlobalBugs();
    await _loadGroupBugs();
    await fetchActiveSenders();
  }

  void _initializeVideoPlayer() {
    _videoController = VideoPlayerController.asset(
      'assets/videos/banner.mp4',
    );

    _videoController.initialize().then((_) {
      setState(() {
        _videoController.setVolume(0.5);
        _videoController.setLooping(true);
        _videoController.play();
        _isVideoInitialized = true;
      });
    }).catchError((error) {
      print("Video initialization error: $error");
      setState(() {
        _isVideoInitialized = false;
      });
    });
  }

  static const String cyberFont = "Orbitron";

  @override
  void dispose() {
    targetController.dispose();
    groupLinkController.dispose();
    _videoController.dispose();
    _controller.dispose();
    _fadeController.dispose();
    _refreshTimer?.cancel();
    _cooldownTimer?.cancel();
    super.dispose();
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  // ─── Helper: konversi apapun ke int aman ────────────────────
  int _parseInt(dynamic v) {
    if (v == null) return 0;
    if (v is int) return v;
    if (v is num) return v.toInt();
    if (v is String) return int.tryParse(v) ?? 0;
    if (v is bool) return v ? 1 : 0;
    return 0;
  }

  // ─── Helper: cari nilai dari banyak kemungkinan key & nested ─
  dynamic _pick(Map<String, dynamic> data, List<String> keys) {
    for (final k in keys) {
      if (data.containsKey(k) && data[k] != null) return data[k];
    }
    // cek nested di dalam 'data'
    final inner = data['data'];
    if (inner is Map) {
      for (final k in keys) {
        if (inner.containsKey(k) && inner[k] != null) return inner[k];
      }
    }
    // cek nested di dalam 'result'
    final result = data['result'];
    if (result is Map) {
      for (final k in keys) {
        if (result.containsKey(k) && result[k] != null) return result[k];
      }
    }
    return null;
  }

  // ─── FIXED: fetchActiveSenders ──────────────────────────────
  Future<void> fetchActiveSenders() async {
    setState(() {
      _isLoadingSenders = true;
    });

    try {
      final url =
          "$baseUrl/getAllActiveSenders?privateUsername=${widget.username}";

      // 🔍 DEBUG — lihat di console
      debugPrint("🔵 [SENDERS] URL: $url");

      final response =
          await http.get(Uri.parse(url)).timeout(const Duration(seconds: 10));

      // 🔍 DEBUG — print status & body mentah
      debugPrint("🔵 [SENDERS] Status: ${response.statusCode}");
      debugPrint("🔵 [SENDERS] Body: ${response.body}");

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body) as Map<String, dynamic>;

        // Terima status true ATAU valid true
        final ok = (data['status'] == true) || (data['valid'] == true);

        if (ok) {
          final privateVal = _pick(data, [
            'private_active',
            'privateActive',
            'privateActiveCount',
            'private_count',
            'privateCount',
            'private',
          ]);

          final globalVal = _pick(data, [
            'global_active',
            'globalActive',
            'globalActiveCount',
            'global_count',
            'globalCount',
            'global',
            'totalGlobal',
            'total_global',
          ]);

          setState(() {
            _privateActive = _parseInt(privateVal);
            _globalActive = _parseInt(globalVal);
            _isLoadingSenders = false;
          });

          debugPrint(
              "✅ [SENDERS] private=$_privateActive global=$_globalActive");
        } else {
          setState(() => _isLoadingSenders = false);
        }
      } else {
        setState(() => _isLoadingSenders = false);
      }
    } catch (e) {
      debugPrint("❌ [SENDERS] Error: $e");
      setState(() => _isLoadingSenders = false);
    }
  }

  Future<void> _loadGroupBugs() async {
    try {
      final response = await http.get(
        Uri.parse("$baseUrl/groupBugs"),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true && data['bugs'] != null) {
          setState(() {
            groupBugs = List<Map<String, dynamic>>.from(data['bugs']);
            if (groupBugs.isNotEmpty && _selectedGroupBugIndex == 0) {
              _selectedGroupBugIndex = 0;
              selectedBugId = groupBugs[0]['bug_id'];
            }
          });
        }
      }
    } catch (e) {
      print("Error load group bugs: $e");
      setState(() {
        groupBugs = [];
      });
    }
  }

  // ─── FIXED: checkGlobalCooldown URL ─────────────────────────
  Future<void> checkGlobalCooldown() async {
    if (_selectedSenderMode != "global") return;

    try {
      final response = await http.get(
        Uri.parse("$baseUrl/checkGlobalCooldown?key=${widget.sessionKey}"),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['onCooldown'] == true) {
          setState(() {
            _isGlobalCooldown = true;
            _globalCooldownSeconds = _parseInt(data['remainingSeconds']);
          });
          startCooldownTimer();
        } else {
          setState(() {
            _isGlobalCooldown = false;
            _globalCooldownSeconds = 0;
          });
          _cooldownTimer?.cancel();
        }
      }
    } catch (e) {
      print("Error check cooldown: $e");
    }
  }

  void startCooldownTimer() {
    _cooldownTimer?.cancel();
    _cooldownTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_globalCooldownSeconds <= 1) {
        setState(() {
          _isGlobalCooldown = false;
          _globalCooldownSeconds = 0;
        });
        timer.cancel();
      } else {
        setState(() {
          _globalCooldownSeconds--;
        });
      }
    });
  }

  Future<void> _sendBug() async {
    if (_isGroupMode) {
      await _attackGroup();
    } else {
      await _sendContactBug();
    }
  }

  Future<void> _sendContactBug() async {
    final rawInput = targetController.text.trim();
    final target = formatPhoneNumber(rawInput);
    final key = widget.sessionKey;
    final senderMode = _selectedSenderMode;

    if (senderMode == "global") {
      await checkGlobalCooldown();
      if (_isGlobalCooldown) {
        _showAlert("Cooldown",
            "Global sender sedang cooldown!\nTunggu ${_globalCooldownSeconds} detik lagi.");
        return;
      }
    }

    String bugToSend = "";
    if (senderMode == "global") {
      if (globalBugs.isNotEmpty && _selectedGlobalBugIndex < globalBugs.length) {
        bugToSend = globalBugs[_selectedGlobalBugIndex]['bug_id'];
      } else {
        bugToSend = "delay";
      }
    } else {
      bugToSend = selectedBugId;
    }

    if (target == null || key.isEmpty) {
      _showAlert("Invalid Number",
          "Gunakan nomor internasional (misal: +62, +1, +44), bukan 08xxx.");
      return;
    }

    setState(() {
      _isSending = true;
      _responseMessage = null;
    });

    try {
      final res = await http.get(Uri.parse(
          "$baseUrl/sendBug?key=$key&target=$target&bug=$bugToSend&senderMode=$senderMode"));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        _showAlert("Cooldown", data["message"] ?? "Tunggu beberapa saat.");
        await checkGlobalCooldown();
      } else if (data["valid"] == false) {
        setState(() => _responseMessage = "Key Invalid: Silakan login ulang.");
      } else if (senderMode != "global" && data['sender'] == false) {
        _showAlert("Failed",
            "kamu tidak memiliki sender pribadi!\nsilahkan add sender terlebih dahulu");
      } else if (data["sended"] == false) {
        setState(
            () => _responseMessage = "Gagal: Server sedang maintenance.");
      } else {
        final modeText = senderMode == "global" ? "GLOBAL" : "PRIVATE";
        String bugName = "";
        if (senderMode == "global") {
          if (globalBugs.isNotEmpty &&
              _selectedGlobalBugIndex < globalBugs.length) {
            bugName = globalBugs[_selectedGlobalBugIndex]['bug_name'];
          } else {
            bugName = "Global Bug";
          }
        } else {
          bugName = widget.listBug[_selectedPrivateBugIndex]['bug_name'];
        }

        _showAlert("Success",
            "Berhasil mengirim bug ke $target!\nMode: $modeText\nBug: $bugName");
        targetController.clear();
        fetchActiveSenders();

        if (senderMode == "global") {
          await checkGlobalCooldown();
        }
      }
    } catch (_) {
      setState(
          () => _responseMessage = "Error: Terjadi kesalahan. Coba lagi.");
    } finally {
      setState(() {
        _isSending = false;
      });
    }
  }

  Future<void> _attackGroup() async {
    final groupLink = groupLinkController.text.trim();
    final key = widget.sessionKey;
    final senderMode = "private";

    if (groupLink.isEmpty || !groupLink.contains('chat.whatsapp.com')) {
      _showAlert("Invalid Link", "Please enter a valid WhatsApp group link.");
      return;
    }

    setState(() {
      _isSending = true;
    });

    try {
      final response = await http.get(
        Uri.parse(
            "$baseUrl/raidGroup?key=$key&link=$groupLink&bug=$selectedBugId&senderMode=$senderMode"),
      ).timeout(
        const Duration(seconds: 30),
        onTimeout: () {
          throw Exception('Request timeout');
        },
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        if (data['valid'] == false) {
          _showAlert("Failed", "Invalid session key. Please login again.");
          return;
        }

        if (data["cooldown"] == true) {
          _showAlert("Cooldown", "Tunggu beberapa saat.");
          return;
        }

        if (data['sender'] == false) {
          _showAlert("Failed",
              "kamu tidak memiliki sender pribadi!\nsilahkan add sender terlebih dahulu");
          return;
        }

        if (data['sended'] == true) {
          _showAlert("Success",
              "Successfully sent bug to group!\nUsing PRIVATE sender");
          groupLinkController.clear();
          fetchActiveSenders();
        } else {
          _showAlert("Failed",
              "Failed to send bug to group. Please try again.");
        }
      } else {
        _showAlert("Server Error",
            "Failed to connect to server. Please try again.");
      }
    } catch (e) {
      print('Group bug error: $e');
      _showAlert("Error",
          "An error occurred. Please check your connection and try again.");
    } finally {
      setState(() {
        _isSending = false;
      });
    }
  }

  // 🏁 M-Stripe Widget
  Widget _mStripe({double height = 3, double width = 40}) {
    return Container(
      height: height,
      width: width,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(2),
        gradient: const LinearGradient(
          colors: [bmwLightBlue, bmwDarkBlue, bmwRed],
          stops: [0.0, 0.5, 1.0],
        ),
      ),
    );
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.75),
      builder: (_) => BackdropFilter(
        filter: ui.ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.all(24),
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  cardColor.withOpacity(0.95),
                  carbonDark.withOpacity(0.98),
                ],
              ),
              border: Border.all(
                color: chromeSilver.withOpacity(0.2),
                width: 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.6),
                  blurRadius: 30,
                ),
                BoxShadow(
                  color: bmwBlueGlow.withOpacity(0.15),
                  blurRadius: 30,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: Stack(
              children: [
                // Top M-stripe
                Positioned(
                  top: 0,
                  left: 0,
                  right: 0,
                  child: ClipRRect(
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(18),
                      topRight: Radius.circular(18),
                    ),
                    child: Container(
                      height: 3,
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          colors: [bmwLightBlue, bmwDarkBlue, bmwRed],
                          stops: [0.0, 0.5, 1.0],
                        ),
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(28, 32, 28, 28),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 60,
                        height: 60,
                        padding: const EdgeInsets.all(2),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(
                            colors: title.toLowerCase().contains('success')
                                ? [successGreen, successGreen.withOpacity(0.7)]
                                : title.toLowerCase().contains('fail') ||
                                        title.toLowerCase().contains('error')
                                    ? [bmwRed, const Color(0xFF8B0F0A)]
                                    : [bmwLightBlue, bmwDarkBlue],
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: (title.toLowerCase().contains('success')
                                      ? successGreen
                                      : title.toLowerCase().contains('fail') ||
                                              title
                                                  .toLowerCase()
                                                  .contains('error')
                                          ? bmwRed
                                          : bmwBlueGlow)
                                  .withOpacity(0.4),
                              blurRadius: 15,
                            ),
                          ],
                        ),
                        child: Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: garageBlack,
                            border: Border.all(
                              color: chromeSilver.withOpacity(0.3),
                              width: 0.8,
                            ),
                          ),
                          child: Icon(
                            title.toLowerCase().contains('success')
                                ? Icons.check_circle_rounded
                                : title.toLowerCase().contains('fail') ||
                                        title.toLowerCase().contains('error')
                                    ? Icons.error_outline_rounded
                                    : Icons.info_outline_rounded,
                            color: chromeSilver,
                            size: 28,
                          ),
                        ),
                      ),
                      const SizedBox(height: 22),
                      Text(
                        title.toUpperCase(),
                        style: const TextStyle(
                          color: textPrimary,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.5,
                          fontFamily: 'Orbitron',
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 14),
                      Text(
                        msg,
                        style: TextStyle(
                          color: chromeSilver.withOpacity(0.8),
                          fontSize: 13,
                          height: 1.5,
                          fontFamily: 'ShareTechMono',
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 28),
                      SizedBox(
                        width: double.infinity,
                        child: Material(
                          color: Colors.transparent,
                          borderRadius: BorderRadius.circular(10),
                          child: InkWell(
                            onTap: () => Navigator.pop(context),
                            borderRadius: BorderRadius.circular(10),
                            child: Container(
                              padding: const EdgeInsets.symmetric(vertical: 14),
                              decoration: BoxDecoration(
                                gradient: const LinearGradient(
                                  colors: [bmwLightBlue, bmwDarkBlue, bmwRed],
                                  stops: [0.0, 0.5, 1.0],
                                ),
                                borderRadius: BorderRadius.circular(10),
                                boxShadow: [
                                  BoxShadow(
                                    color: bmwBlueGlow.withOpacity(0.4),
                                    blurRadius: 12,
                                  ),
                                ],
                              ),
                              child: const Center(
                                child: Text(
                                  "GOT IT",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 13,
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 2,
                                    fontFamily: 'Orbitron',
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildGlassCard({required Widget child}) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            cardColor.withOpacity(0.9),
            carbonDark.withOpacity(0.95),
          ],
        ),
        border: Border.all(
          color: chromeSilver.withOpacity(0.15),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.45),
            blurRadius: 18,
            offset: const Offset(0, 4),
          ),
          BoxShadow(
            color: bmwBlueGlow.withOpacity(0.08),
            blurRadius: 20,
            spreadRadius: 1,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: Stack(
          children: [
            // Top M-stripe
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              child: Container(
                height: 3,
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [bmwLightBlue, bmwDarkBlue, bmwRed],
                    stops: [0.0, 0.5, 1.0],
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 22, 20, 20),
              child: child,
            ),
          ],
        ),
      ),
    );
  }

  Widget _iconBox(IconData icon) {
    return Container(
      width: 42,
      height: 42,
      padding: const EdgeInsets.all(2),
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const LinearGradient(
          colors: [bmwLightBlue, bmwDarkBlue],
        ),
        boxShadow: [
          BoxShadow(
            color: bmwBlueGlow.withOpacity(0.35),
            blurRadius: 10,
          ),
        ],
      ),
      child: Container(
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: garageBlack,
          border: Border.all(
            color: chromeSilver.withOpacity(0.3),
            width: 0.8,
          ),
        ),
        child: Icon(icon, color: chromeSilver, size: 18),
      ),
    );
  }

  Widget _buildVideoBanner() {
    return SlideTransition(
      position: Tween<Offset>(
        begin: const Offset(0, -0.5),
        end: Offset.zero,
      ).animate(CurvedAnimation(
        parent: _controller,
        curve: Curves.easeOut,
      )),
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
        width: double.infinity,
        height: 280,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
              color: bmwBlueGlow.withOpacity(0.15),
              blurRadius: 24,
              spreadRadius: 2,
            ),
            BoxShadow(
              color: Colors.black.withOpacity(0.5),
              blurRadius: 20,
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: Stack(
            fit: StackFit.expand,
            children: [
              if (_isVideoInitialized)
                FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: _videoController.value.size.width,
                    height: _videoController.value.size.height,
                    child: VideoPlayer(_videoController),
                  ),
                )
              else
                Container(
                  color: carbonDark,
                  child: const Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.play_arrow_rounded,
                            color: chromeSilver, size: 40),
                        SizedBox(height: 8),
                        Text(
                          "Loading Video...",
                          style: TextStyle(
                              color: chromeSilver,
                              fontFamily: 'ShareTechMono'),
                        ),
                      ],
                    ),
                  ),
                ),
              // Gradient overlay
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.black.withOpacity(0.75),
                      Colors.transparent,
                      Colors.black.withOpacity(0.85),
                    ],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    stops: const [0.0, 0.5, 1.0],
                  ),
                ),
              ),
              // Content
              Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    FadeTransition(
                      opacity:
                          Tween(begin: 0.6, end: 1.0).animate(_fadeController),
                      child: Container(
                        width: 86,
                        height: 86,
                        padding: const EdgeInsets.all(3),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: const LinearGradient(
                            colors: [bmwLightBlue, bmwDarkBlue, bmwRed],
                            stops: [0.0, 0.5, 1.0],
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: bmwBlueGlow.withOpacity(0.45),
                              blurRadius: 20,
                            ),
                          ],
                        ),
                        child: Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: garageBlack,
                            border: Border.all(
                              color: chromeSilver.withOpacity(0.35),
                              width: 1,
                            ),
                          ),
                          child: const CircleAvatar(
                            radius: 38,
                            backgroundImage:
                                AssetImage('assets/images/login.jpg'),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    ShaderMask(
                      shaderCallback: (bounds) => const LinearGradient(
                        colors: [Colors.white, chromeSilver, bmwLightBlue],
                      ).createShader(bounds),
                      child: Text(
                        widget.username,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 22,
                          letterSpacing: 1.5,
                          color: Colors.white,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: bmwBlueGlow.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                                color: bmwBlueGlow.withOpacity(0.4)),
                          ),
                          child: Text(
                            widget.role.toUpperCase(),
                            style: const TextStyle(
                              color: textPrimary,
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1.2,
                              fontFamily: 'ShareTechMono',
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: surfaceColor.withOpacity(0.6),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                                color: chromeSilver.withOpacity(0.25)),
                          ),
                          child: Text(
                            "Exp: ${widget.expiredDate}",
                            style: TextStyle(
                              color: chromeSilver.withOpacity(0.9),
                              fontSize: 11,
                              fontFamily: 'ShareTechMono',
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatusBoxes() {
    final allowedRoles = ['ADMIN', 'OWNER', 'MODERATOR', 'STAFF', 'DEVELOPER'];
    final isAllowed = allowedRoles.contains(widget.role.toUpperCase());

    if (_isGroupMode || !isAllowed) {
      return const SizedBox.shrink();
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          Expanded(
            child: _buildSenderButton(
              mode: "private",
              label: "PRIVATE",
              icon: Icons.person_rounded,
              activeCount: _privateActive,
              isSelected: _selectedSenderMode == "private",
              onTap: () {
                setState(() {
                  _selectedSenderMode = "private";
                  _selectedPrivateBugIndex = 0;
                  selectedBugId = widget.listBug.isNotEmpty
                      ? widget.listBug[0]['bug_id']
                      : "";
                });
                _cooldownTimer?.cancel();
                setState(() {
                  _isGlobalCooldown = false;
                  _globalCooldownSeconds = 0;
                });
              },
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _buildSenderButton(
              mode: "global",
              label: "GLOBAL",
              icon: Icons.language_rounded,
              activeCount: _globalActive,
              isSelected: _selectedSenderMode == "global",
              isOnCooldown: _isGlobalCooldown,
              cooldownSeconds: _globalCooldownSeconds,
              onTap: () {
                setState(() {
                  _selectedSenderMode = "global";
                  _selectedGlobalBugIndex = 0;
                });
                checkGlobalCooldown();
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSenderButton({
    required String mode,
    required String label,
    required IconData icon,
    required int activeCount,
    required bool isSelected,
    required VoidCallback onTap,
    bool isOnCooldown = false,
    int cooldownSeconds = 0,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          gradient: isSelected
              ? LinearGradient(
                  colors: [
                    bmwBlueGlow.withOpacity(0.18),
                    bmwDarkBlue.withOpacity(0.12),
                  ],
                )
              : null,
          color: isSelected ? null : surfaceColor.withOpacity(0.4),
          border: Border.all(
            color: isSelected
                ? bmwBlueGlow.withOpacity(0.55)
                : chromeSilver.withOpacity(0.12),
            width: isSelected ? 1.5 : 1,
          ),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: bmwBlueGlow.withOpacity(0.2),
                    blurRadius: 12,
                  )
                ]
              : null,
        ),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  icon,
                  color:
                      isSelected ? chromeSilver : chromeSilver.withOpacity(0.5),
                  size: 17,
                ),
                const SizedBox(width: 7),
                Text(
                  label,
                  style: TextStyle(
                    color: isSelected
                        ? textPrimary
                        : chromeSilver.withOpacity(0.6),
                    fontSize: 12,
                    fontWeight:
                        isSelected ? FontWeight.bold : FontWeight.w600,
                    letterSpacing: 1.2,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 5),
            Text(
              _isLoadingSenders ? "..." : "$activeCount Active",
              style: TextStyle(
                color: isSelected
                    ? chromeSilver.withOpacity(0.8)
                    : chromeSilver.withOpacity(0.4),
                fontSize: 10,
                fontFamily: 'ShareTechMono',
              ),
            ),
            if (isOnCooldown && mode == "global")
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(
                  "⏱️ ${cooldownSeconds}s",
                  style: TextStyle(
                    color: Colors.orange.withOpacity(0.9),
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildModeSwitcher() {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
      child: Row(
        children: [
          Expanded(
            child: _buildModeButton(
              icon: Icons.person_rounded,
              label: "Contact Bug",
              isSelected: !_isGroupMode,
              onTap: () {
                setState(() {
                  _isGroupMode = false;
                  _selectedSenderMode = "private";
                  _selectedPrivateBugIndex = 0;
                  selectedBugId = widget.listBug.isNotEmpty
                      ? widget.listBug[0]['bug_id']
                      : "";
                });
                _cooldownTimer?.cancel();
                setState(() {
                  _isGlobalCooldown = false;
                  _globalCooldownSeconds = 0;
                });
              },
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _buildModeButton(
              icon: Icons.groups_rounded,
              label: "Group Bug",
              isSelected: _isGroupMode,
              onTap: () {
                setState(() {
                  _isGroupMode = true;
                  _selectedGroupBugIndex = 0;
                  selectedBugId =
                      groupBugs.isNotEmpty ? groupBugs[0]['bug_id'] : "";
                  _selectedSenderMode = "private";
                });
                _cooldownTimer?.cancel();
                setState(() {
                  _isGlobalCooldown = false;
                  _globalCooldownSeconds = 0;
                });
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildModeButton({
    required IconData icon,
    required String label,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 15),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          gradient: isSelected
              ? LinearGradient(
                  colors: [
                    bmwBlueGlow.withOpacity(0.2),
                    bmwDarkBlue.withOpacity(0.12),
                  ],
                )
              : null,
          color: isSelected ? null : surfaceColor.withOpacity(0.35),
          border: Border.all(
            color: isSelected
                ? bmwBlueGlow.withOpacity(0.55)
                : chromeSilver.withOpacity(0.12),
            width: 1.4,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              color: isSelected ? chromeSilver : chromeSilver.withOpacity(0.6),
              size: 18,
            ),
            const SizedBox(width: 8),
            Text(
              label,
              style: TextStyle(
                color: isSelected ? textPrimary : chromeSilver.withOpacity(0.7),
                fontSize: 13,
                fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
                letterSpacing: 0.8,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTargetNumberCard() {
    if (_isGroupMode) {
      return _buildGlassCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                _iconBox(Icons.link_rounded),
                const SizedBox(width: 14),
                const Text(
                  "GROUP LINK",
                  style: TextStyle(
                    color: textPrimary,
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                    letterSpacing: 1.5,
                    fontFamily: 'Orbitron',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),
            Container(
              decoration: BoxDecoration(
                color: surfaceColor.withOpacity(0.5),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: chromeSilver.withOpacity(0.15),
                ),
              ),
              child: TextField(
                controller: groupLinkController,
                style: const TextStyle(
                  color: textPrimary,
                  fontSize: 13,
                  fontFamily: 'ShareTechMono',
                ),
                cursorColor: bmwBlueGlow,
                decoration: InputDecoration(
                  hintText: "https://chat.whatsapp.com/...",
                  hintStyle: TextStyle(
                    color: chromeSilver.withOpacity(0.35),
                    fontSize: 12,
                    fontFamily: 'ShareTechMono',
                  ),
                  prefixIcon: Icon(
                    Icons.link_rounded,
                    color: chromeSilver.withOpacity(0.6),
                    size: 18,
                  ),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 15,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: bmwBlueGlow.withOpacity(0.08),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: bmwBlueGlow.withOpacity(0.25),
                ),
              ),
              child: Row(
                children: [
                  Icon(
                    Icons.info_outline_rounded,
                    color: bmwBlueGlow.withOpacity(0.9),
                    size: 16,
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      "This tool will automatically join the group, send a bug, and leave without any trace.",
                      style: TextStyle(
                        color: chromeSilver.withOpacity(0.7),
                        fontSize: 11,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    } else {
      return _buildGlassCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                _iconBox(Icons.phone_android_rounded),
                const SizedBox(width: 14),
                const Text(
                  "TARGET NUMBER",
                  style: TextStyle(
                    color: textPrimary,
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                    letterSpacing: 1.5,
                    fontFamily: 'Orbitron',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),
            Container(
              decoration: BoxDecoration(
                color: surfaceColor.withOpacity(0.5),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: chromeSilver.withOpacity(0.15),
                ),
              ),
              child: TextField(
                controller: targetController,
                style: const TextStyle(
                  color: textPrimary,
                  fontSize: 14,
                  fontFamily: 'ShareTechMono',
                ),
                cursorColor: bmwBlueGlow,
                decoration: InputDecoration(
                  hintText: "e.g. +62xxxxxxxxxx",
                  hintStyle: TextStyle(
                    color: chromeSilver.withOpacity(0.35),
                    fontSize: 13,
                    fontFamily: 'ShareTechMono',
                  ),
                  prefixIcon: Icon(
                    Icons.language_rounded,
                    color: chromeSilver.withOpacity(0.6),
                    size: 20,
                  ),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 15,
                  ),
                ),
              ),
            ),
          ],
        ),
      );
    }
  }

  Widget _buildBugTypeCard() {
    if (_isGroupMode) {
      return _buildBugCardList(groupBugs, _selectedGroupBugIndex, (index) {
        setState(() {
          _selectedGroupBugIndex = index;
          selectedBugId = groupBugs[index]['bug_id'];
        });
      }, "GROUP BUG TYPE");
    }

    if (!_isGroupMode && _selectedSenderMode == "global") {
      if (globalBugs.isEmpty) {
        return _buildBugCardList([], 0, (index) {}, "GLOBAL BUG TYPE");
      }
      return _buildBugCardList(globalBugs, _selectedGlobalBugIndex, (index) {
        setState(() {
          _selectedGlobalBugIndex = index;
          selectedBugId = globalBugs[index]['bug_id'];
        });
      }, "GLOBAL BUG TYPE");
    }

    return _buildBugCardList(widget.listBug, _selectedPrivateBugIndex, (index) {
      setState(() {
        _selectedPrivateBugIndex = index;
        selectedBugId = widget.listBug[index]['bug_id'];
      });
    }, "BUG TYPE");
  }

  Widget _buildBugCardList(
    List<Map<String, dynamic>> bugs,
    int selectedIndex,
    Function(int) onTap,
    String titleText,
  ) {
    return _buildGlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              _iconBox(Icons.bug_report_rounded),
              const SizedBox(width: 12),
              Text(
                titleText,
                style: const TextStyle(
                  fontFamily: 'Orbitron',
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  color: textPrimary,
                  letterSpacing: 1.3,
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          if (bugs.isEmpty)
            Container(
              height: 120,
              alignment: Alignment.center,
              child: Text(
                "Loading bugs...",
                style: TextStyle(
                  color: chromeSilver.withOpacity(0.5),
                  fontFamily: 'ShareTechMono',
                ),
              ),
            )
          else
            SizedBox(
              height: 125,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: bugs.length,
                itemBuilder: (context, index) {
                  final bug = bugs[index];
                  final bool isSelected = selectedIndex == index;

                  return GestureDetector(
                    onTap: () => onTap(index),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 250),
                      width: 185,
                      margin: const EdgeInsets.only(right: 12),
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(14),
                        gradient: isSelected
                            ? LinearGradient(
                                colors: [
                                  bmwBlueGlow.withOpacity(0.2),
                                  bmwDarkBlue.withOpacity(0.15),
                                ],
                              )
                            : null,
                        color:
                            isSelected ? null : surfaceColor.withOpacity(0.5),
                        border: Border.all(
                          color: isSelected
                              ? bmwBlueGlow.withOpacity(0.6)
                              : chromeSilver.withOpacity(0.12),
                          width: 1.4,
                        ),
                        boxShadow: isSelected
                            ? [
                                BoxShadow(
                                  color: bmwBlueGlow.withOpacity(0.25),
                                  blurRadius: 12,
                                )
                              ]
                            : [],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              const Icon(FontAwesomeIcons.whatsapp,
                                  color: chromeSilver, size: 18),
                              const Spacer(),
                              if (isSelected)
                                Icon(Icons.check_circle_rounded,
                                    color: bmwBlueGlow, size: 17),
                            ],
                          ),
                          const SizedBox(height: 12),
                          Text(
                            bug['bug_name'].toString(),
                            style: const TextStyle(
                              color: textPrimary,
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'ShareTechMono',
                            ),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          const SizedBox(height: 14),
          if (bugs.isNotEmpty)
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(bugs.length, (index) {
                final isActive = selectedIndex == index;
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  width: isActive ? 22 : 6,
                  height: 4,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(2),
                    gradient: isActive
                        ? const LinearGradient(
                            colors: [bmwLightBlue, bmwDarkBlue, bmwRed],
                          )
                        : null,
                    color: isActive ? null : chromeSilver.withOpacity(0.25),
                  ),
                );
              }),
            ),
        ],
      ),
    );
  }

  Widget _buildSendButton() {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
      width: double.infinity,
      height: 58,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        gradient: const LinearGradient(
          colors: [bmwLightBlue, bmwDarkBlue, bmwRed],
          stops: [0.0, 0.5, 1.0],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
        boxShadow: [
          BoxShadow(
            color: bmwBlueGlow.withOpacity(0.4),
            blurRadius: 18,
            spreadRadius: 1,
          ),
          BoxShadow(
            color: bmwRed.withOpacity(0.25),
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(14),
        child: InkWell(
          onTap: _isSending ? null : _sendBug,
          borderRadius: BorderRadius.circular(14),
          child: Center(
            child: _isSending
                ? const SizedBox(
                    height: 24,
                    width: 24,
                    child: CircularProgressIndicator(
                      color: Colors.white,
                      strokeWidth: 2.5,
                    ),
                  )
                : Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        _isGroupMode
                            ? Icons.groups_rounded
                            : Icons.send_rounded,
                        color: Colors.white,
                        size: 20,
                      ),
                      const SizedBox(width: 10),
                      Text(
                        _isGroupMode ? "ATTACK GROUP" : "SEND BUG",
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                          letterSpacing: 2,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                    ],
                  ),
          ),
        ),
      ),
    );
  }

  Widget _buildDisclaimer() {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: surfaceColor.withOpacity(0.35),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: chromeSilver.withOpacity(0.1),
        ),
      ),
      child: Row(
        children: [
          Icon(
            Icons.info_outline_rounded,
            color: chromeSilver.withOpacity(0.5),
            size: 18,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              _isGroupMode
                  ? "This tool will join the group, send a bug, and leave without any trace."
                  : "Use responsibly. We are not responsible for misuse.",
              style: TextStyle(
                color: chromeSilver.withOpacity(0.5),
                fontSize: 11,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGarageBackground() {
    return Stack(
      children: [
        Positioned.fill(
          child: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [carbonDark, garageBlack, Color(0xFF050505)],
              ),
            ),
          ),
        ),
        // Blue ambient glow
        Positioned.fill(
          child: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(-0.8, -0.7),
                radius: 1.4,
                colors: [
                  bmwBlueGlow.withOpacity(0.12),
                  Colors.transparent,
                ],
              ),
            ),
          ),
        ),
        // Red ambient glow
        Positioned.fill(
          child: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(1.0, 1.0),
                radius: 1.2,
                colors: [
                  bmwRed.withOpacity(0.08),
                  Colors.transparent,
                ],
              ),
            ),
          ),
        ),
        // Carbon grid
        Positioned.fill(
          child: CustomPaint(painter: _GridPatternPainter()),
        ),
      ],
    );
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: garageBlack,
      body: Stack(
        children: [
          _buildGarageBackground(),

          // Video background (sangat transparan)
          if (_isVideoInitialized)
            Positioned.fill(
              child: Opacity(
                opacity: 0.12,
                child: FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: _videoController.value.size.width,
                    height: _videoController.value.size.height,
                    child: VideoPlayer(_videoController),
                  ),
                ),
              ),
            ),

          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(vertical: 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _buildVideoBanner(),
                  _buildModeSwitcher(),
                  _buildTargetNumberCard(),
                  _buildBugTypeCard(),
                  _buildStatusBoxes(),
                  _buildSendButton(),
                  _buildDisclaimer(),
                  const SizedBox(height: 24),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─── CARBON GRID PAINTER ───────────────────────────────────────────────────
class _GridPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF1C69D4).withOpacity(0.04)
      ..strokeWidth = 0.5
      ..style = PaintingStyle.stroke;

    const double spacing = 50;
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}