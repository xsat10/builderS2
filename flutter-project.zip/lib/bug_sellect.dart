import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'home_page.dart';
import 'bug_group.dart';
import 'bug_pair.dart';

class SellectbugPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listGb;

  const SellectbugPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listGb,
  });

  @override
  State<SellectbugPage> createState() => _SellectbugPageState();
}

class _SellectbugPageState extends State<SellectbugPage>
    with SingleTickerProviderStateMixin {
  late PageController _pageController;
  late AnimationController _animationController;
  int _currentPage = 0;

  final List<String> _pageTitles = [
    'Bug Personal', 
    'Bug Group', 
    'Spam Pairing'
  ];
  final List<String> _pageSubtitles = [
    'Kelola bug chat private',
    'Kelola bug dalam grup',
    'Spam pairing code WhatsApp'
  ];
  final List<IconData> _pageIcons = [
    Icons.chat_rounded,
    Icons.group_rounded,
    Icons.bolt_rounded,
  ];

  @override
  void initState() {
    super.initState();
    _pageController = PageController(viewportFraction: 0.92);
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
  }

  @override
  void dispose() {
    _pageController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0E1A),
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            const SizedBox(height: 8),
            _buildPageIndicator(),
            const SizedBox(height: 8),
            _buildPageTitle(),
            const SizedBox(height: 12),
            Expanded(
              child: PageView(
                controller: _pageController,
                onPageChanged: (page) {
                  setState(() {
                    _currentPage = page;
                  });
                  _animationController.forward(from: 0);
                },
                children: [
                  // Page 1: Bug Private
                  PageBugPrivateWrapper(
                    username: widget.username,
                    password: widget.password,
                    role: widget.role,
                    expiredDate: widget.expiredDate,
                    sessionKey: widget.sessionKey,
                    listBug: widget.listBug,
                  ),
                  // Page 2: Bug Group
                  PageBugGroupWrapper(
                    username: widget.username,
                    password: widget.password,
                    role: widget.role,
                    expiredDate: widget.expiredDate,
                    sessionKey: widget.sessionKey,
                    listGb: widget.listGb,
                  ),
                  // Page 3: Spam Pairing
                  PageSpamPairWrapper(
                    username: widget.username,
                    password: widget.password,
                    role: widget.role,
                    expiredDate: widget.expiredDate,
                    sessionKey: widget.sessionKey,
                  ),
                ],
              ),
            ),
            _buildBottomNavigation(),
            _buildSwipeHint(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
      child: Row(
        children: [
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF7B2FBE), Color(0xFF00D4FF)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(14),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF7B2FBE).withOpacity(0.3),
                  blurRadius: 20,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: const Icon(
              Icons.shield_rounded,
              color: Colors.white,
              size: 26,
            ),
          ),
          const SizedBox(width: 14),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ShaderMask(
                shaderCallback: (bounds) => const LinearGradient(
                  colors: [Color(0xFF7B2FBE), Color(0xFF00D4FF)],
                ).createShader(bounds),
                child: const Text(
                  'ZENZO x EYE APPS',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2.0,
                    fontFamily: 'Orbitron',
                  ),
                ),
              ),
              Row(
                children: [
                  const Text(
                    'Select menu bug',
                    style: TextStyle(
                      color: Color(0xFF8A9BB5),
                      fontSize: 11,
                      fontFamily: 'Orbitron',
                      letterSpacing: 0.5,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 6,
                      vertical: 2,
                    ),
                    decoration: BoxDecoration(
                      color: const Color(0xFF7B2FBE).withOpacity(0.2),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      widget.role.toUpperCase(),
                      style: const TextStyle(
                        color: Color(0xFF7B2FBE),
                        fontSize: 8,
                        fontWeight: FontWeight.w700,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 12,
              vertical: 6,
            ),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  const Color(0xFF7B2FBE).withOpacity(0.2),
                  const Color(0xFF00D4FF).withOpacity(0.2),
                ],
              ),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: const Color(0xFF7B2FBE).withOpacity(0.2),
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 6,
                  height: 6,
                  decoration: const BoxDecoration(
                    color: Color(0xFF00D4FF),
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 4),
                const Text(
                  'ONLINE',
                  style: TextStyle(
                    color: Color(0xFF8A9BB5),
                    fontSize: 8,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPageIndicator() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _buildIndicator(0),
        const SizedBox(width: 8),
        _buildIndicator(1),
        const SizedBox(width: 8),
        _buildIndicator(2),
      ],
    );
  }

  Widget _buildIndicator(int index) {
    bool isActive = _currentPage == index;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      width: isActive ? 30 : 8,
      height: 8,
      decoration: BoxDecoration(
        gradient: isActive
            ? const LinearGradient(
                colors: [Color(0xFF7B2FBE), Color(0xFF00D4FF)],
              )
            : null,
        color: isActive ? null : const Color(0xFF2A3555),
        borderRadius: BorderRadius.circular(4),
        boxShadow: isActive
            ? [
                BoxShadow(
                  color: const Color(0xFF7B2FBE).withOpacity(0.4),
                  blurRadius: 10,
                ),
              ]
            : null,
      ),
    );
  }

  Widget _buildPageTitle() {
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 300),
      child: Column(
        key: ValueKey<int>(_currentPage),
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                _pageIcons[_currentPage],
                color: const Color(0xFF7B2FBE),
                size: 20,
              ),
              const SizedBox(width: 8),
              Text(
                _pageTitles[_currentPage],
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 2),
          Text(
            _pageSubtitles[_currentPage],
            style: TextStyle(
              color: const Color(0xFF8A9BB5).withOpacity(0.7),
              fontSize: 11,
              fontFamily: 'Orbitron',
              letterSpacing: 0.3,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomNavigation() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          _buildNavDot(0),
          const SizedBox(width: 12),
          _buildNavDot(1),
          const SizedBox(width: 12),
          _buildNavDot(2),
        ],
      ),
    );
  }

  Widget _buildNavDot(int index) {
    bool isActive = _currentPage == index;
    return GestureDetector(
      onTap: () {
        _pageController.animateToPage(
          index,
          duration: const Duration(milliseconds: 400),
          curve: Curves.easeInOut,
        );
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        padding: EdgeInsets.symmetric(
          horizontal: isActive ? 16 : 10,
          vertical: isActive ? 8 : 6,
        ),
        decoration: BoxDecoration(
          gradient: isActive
              ? const LinearGradient(
                  colors: [Color(0xFF7B2FBE), Color(0xFF00D4FF)],
                )
              : null,
          color: isActive ? null : const Color(0xFF1A2340),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isActive
                ? Colors.transparent
                : const Color(0xFF2A3555),
            width: 1,
          ),
          boxShadow: isActive
              ? [
                  BoxShadow(
                    color: const Color(0xFF7B2FBE).withOpacity(0.3),
                    blurRadius: 12,
                  ),
                ]
              : null,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              _pageIcons[index],
              color: isActive ? Colors.white : const Color(0xFF5A6A8A),
              size: 14,
            ),
            if (isActive) ...[
              const SizedBox(width: 6),
              Text(
                _pageTitles[index].split(' ')[0],
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                  fontFamily: 'Orbitron',
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildSwipeHint() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            _currentPage > 0 ? Icons.arrow_back_ios : Icons.arrow_forward_ios,
            color: const Color(0xFF7B2FBE).withOpacity(0.5),
            size: 12,
          ),
          const SizedBox(width: 8),
          Text(
            _currentPage == 0 
                ? 'Geser ke kanan' 
                : _currentPage == 1
                ? 'Geser ke kiri/kanan'
                : 'Geser ke kiri',
            style: TextStyle(
              color: const Color(0xFF8A9BB5).withOpacity(0.6),
              fontSize: 10,
              fontFamily: 'Orbitron',
              letterSpacing: 0.3,
            ),
          ),
          const SizedBox(width: 8),
          Icon(
            _currentPage < 2 ? Icons.arrow_forward_ios : Icons.arrow_back_ios,
            color: const Color(0xFF00D4FF).withOpacity(0.5),
            size: 12,
          ),
        ],
      ),
    );
  }
}

// ─── Wrapper Widgets ─────────────────────────────────────────────────────

class PageBugPrivateWrapper extends StatelessWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;

  const PageBugPrivateWrapper({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
  });

  @override
  Widget build(BuildContext context) {
    return HomePage(
      username: username,
      password: password,
      role: role,
      expiredDate: expiredDate,
      sessionKey: sessionKey,
      listBug: listBug,
    );
  }
}

class PageBugGroupWrapper extends StatelessWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listGb;

  const PageBugGroupWrapper({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listGb,
  });

  @override
  Widget build(BuildContext context) {
    return PageGroupBug(
      username: username,
      password: password,
      role: role,
      expiredDate: expiredDate,
      sessionKey: sessionKey,
      listGb: listGb,
    );
  }
}

class PageSpamPairWrapper extends StatelessWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;

  const PageSpamPairWrapper({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
  });

  @override
  Widget build(BuildContext context) {
    return SpamPairPage(
      username: username,
      password: password,
      role: role,
      expiredDate: expiredDate,
      sessionKey: sessionKey,
    );
  }
}