import 'package:flutter/material.dart';

import 'trading_models.dart';

// ─── QUOTE PAGE ───────────────────────────────────────────────────────────
class QuotePage extends StatefulWidget {
  final String sessionKey;
  final String role;
  final VoidCallback? onChartPressed;
  final VoidCallback? onTradePressed;
  final VoidCallback? onHistoryPressed;

  const QuotePage({
    Key? key,
    required this.sessionKey,
    required this.role,
    this.onChartPressed,
    this.onTradePressed,
    this.onHistoryPressed,
  }) : super(key: key);

  @override
  State<QuotePage> createState() => _QuotePageState();
}

class _QuotePageState extends State<QuotePage> {
  final TextEditingController _searchCtrl = TextEditingController();
  String _searchQuery = '';

  List<Quote> allQuotes = [
    Quote(
      symbol: 'AUDCHF',
      displayName: 'Australian Dollar vs Swiss Franc',
      bid: 0.5795,
      ask: 0.5820,
      change: 0.0181,
      changePercent: 0.31,
      lastUpdate: DateTime.now(),
      low: 0.5790,
      high: 0.5823,
      isWatching: true,
    ),
    Quote(
      symbol: 'AUDJPY',
      displayName: 'Australian Dollar vs Japanese Yen',
      bid: 114.50,
      ask: 114.65,
      change: 0.0000,
      changePercent: -0.02,
      lastUpdate: DateTime.now(),
      low: 114.50,
      high: 114.96,
    ),
    Quote(
      symbol: 'AUDNZD',
      displayName: 'Australian Dollar vs New Zealand Dollar',
      bid: 1.2100,
      ask: 1.2113,
      change: 0.0232,
      changePercent: 0.19,
      lastUpdate: DateTime.now(),
      low: 1.2072,
      high: 1.2120,
    ),
    Quote(
      symbol: 'AUDSEK',
      displayName: 'Australian Dollar vs Swedish Krona',
      bid: 0.0,
      ask: 0.0,
      change: 0.0,
      changePercent: 0.00,
      lastUpdate: DateTime.now(),
      low: 0.0,
      high: 0.0,
    ),
    Quote(
      symbol: 'AUDUSD',
      displayName: 'Australian Dollar vs US Dollar',
      bid: 0.7155,
      ask: 0.7161,
      change: -0.0338,
      changePercent: -0.47,
      lastUpdate: DateTime.now(),
      low: 0.7155,
      high: 0.7207,
      isWatching: true,
    ),
    Quote(
      symbol: 'CADJPY',
      displayName: 'Canadian Dollar vs Japanese Yen',
      bid: 115.01,
      ask: 115.12,
      change: 0.0081,
      changePercent: 0.07,
      lastUpdate: DateTime.now(),
      low: 115.01,
      high: 115.32,
    ),
    Quote(
      symbol: 'CHFJPY',
      displayName: 'Swiss Franc vs Japanese Yen',
      bid: 197.75,
      ask: 197.84,
      change: -0.0433,
      changePercent: -0.22,
      lastUpdate: DateTime.now(),
      low: 197.68,
      high: 198.77,
    ),
    Quote(
      symbol: 'CHFSGD',
      displayName: 'Swiss Franc vs Singapore Dollar',
      bid: 1.5973,
      ask: 1.6010,
      change: 0.0025,
      changePercent: 0.16,
      lastUpdate: DateTime.now(),
      low: 1.5973,
      high: 1.6010,
    ),
    Quote(
      symbol: 'AUDCAD',
      displayName: 'Australian Dollar vs Canadian Dollar',
      bid: 0.9951,
      ask: 0.9960,
      change: -0.0060,
      changePercent: -0.06,
      lastUpdate: DateTime.now(),
      low: 0.9951,
      high: 0.9979,
    ),
    Quote(
      symbol: 'BTCUSD',
      displayName: 'Bitcoin vs US Dollar',
      bid: 77670.00,
      ask: 77697.00,
      change: 31900,
      changePercent: 0.41,
      lastUpdate: DateTime.now(),
      low: 77200.00,
      high: 77800.00,
      isWatching: true,
    ),
  ];

  late List<Quote> filteredQuotes;

  @override
  void initState() {
    super.initState();
    filteredQuotes = allQuotes;
    _searchCtrl.addListener(_filterQuotes);
  }

  void _filterQuotes() {
    setState(() {
      _searchQuery = _searchCtrl.text.toLowerCase();
      if (_searchQuery.isEmpty) {
        filteredQuotes = allQuotes;
      } else {
        filteredQuotes = allQuotes
            .where((q) =>
                q.symbol.toLowerCase().contains(_searchQuery) ||
                q.displayName.toLowerCase().contains(_searchQuery))
            .toList();
      }
    });
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: TradingTheme.bg,
      body: Column(
        children: [
          // ─── HEADER ───────────────────────────────────
          _buildHeader(),

          // ─── SEARCH BAR ────────────────────────────────
          _buildSearchBar(),

          // ─── QUOTES LIST ──────────────────────────────
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              itemCount: filteredQuotes.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (context, index) {
                return _buildQuoteCard(filteredQuotes[index], index);
              },
            ),
          ),

          // ─── BOTTOM NAV ────────────────────────────────
          _buildBottomNav(),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: TradingTheme.card,
        border: Border(
          bottom: BorderSide(color: TradingTheme.accent.withOpacity(0.25)),
        ),
        boxShadow: [
          BoxShadow(
            color: TradingTheme.accent.withOpacity(0.08),
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Quote',
            style: TextStyle(
              color: TradingTheme.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
              fontFamily: 'Astral',
            ),
          ),
          Text(
            'Harga pasar real-time',
            style: TextStyle(
              color: TradingTheme.grey,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: TradingTheme.card,
        border: Border(
          bottom: BorderSide(color: TradingTheme.accent.withOpacity(0.15)),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _searchCtrl,
              style: const TextStyle(color: TradingTheme.white),
              decoration: InputDecoration(
                hintText: 'Cari simbol...',
                hintStyle: TextStyle(color: TradingTheme.grey),
                prefixIcon: const Icon(Icons.search_rounded,
                    color: TradingTheme.grey, size: 18),
                suffixIcon: _searchQuery.isNotEmpty
                    ? GestureDetector(
                        onTap: () {
                          _searchCtrl.clear();
                          _filterQuotes();
                        },
                        child: const Icon(Icons.clear_rounded,
                            color: TradingTheme.grey, size: 18),
                      )
                    : null,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(
                    color: TradingTheme.accent.withOpacity(0.2),
                  ),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(
                    color: TradingTheme.accent.withOpacity(0.2),
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide:
                      const BorderSide(color: TradingTheme.accent, width: 1.5),
                ),
                contentPadding: const EdgeInsets.symmetric(vertical: 10),
              ),
            ),
          ),
          const SizedBox(width: 8),
          Container(
            decoration: BoxDecoration(
              color: TradingTheme.accent.withOpacity(0.18),
              border: Border.all(
                color: TradingTheme.accent.withOpacity(0.5),
              ),
              borderRadius: BorderRadius.circular(12),
              boxShadow: TradingTheme.neonGlow(TradingTheme.accent),
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: _showAddSymbolDialog,
                borderRadius: BorderRadius.circular(12),
                child: const Padding(
                  padding: EdgeInsets.all(10),
                  child: Icon(Icons.add_rounded, color: TradingTheme.accent, size: 20),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuoteCard(Quote quote, int index) {
    final isPositive = quote.changePercent >= 0;
    final changeColor = isPositive ? TradingTheme.success : TradingTheme.primary;

    return GestureDetector(
      onTap: () => _showOrderMenuDialog(quote),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: TradingTheme.cardAlt,
          border: Border.all(color: TradingTheme.accent.withOpacity(0.15)),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      quote.symbol,
                      style: const TextStyle(
                        color: TradingTheme.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'Astral',
                      ),
                    ),
                    Text(
                      quote.displayName,
                      style: TextStyle(
                        color: TradingTheme.grey,
                        fontSize: 11,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      formatPrice(quote.ask),
                      style: const TextStyle(
                        color: TradingTheme.white,
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Astral',
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: changeColor.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        '${isPositive ? '+' : ''}${quote.changePercent.toStringAsFixed(2)}%',
                        style: TextStyle(
                          color: changeColor,
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Bid: ${formatPrice(quote.bid)}',
                      style: TextStyle(
                        color: TradingTheme.grey,
                        fontSize: 10,
                      ),
                    ),
                    Text(
                      'Low: ${formatPrice(quote.low)}',
                      style: TextStyle(
                        color: TradingTheme.grey,
                        fontSize: 10,
                      ),
                    ),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      'Ask: ${formatPrice(quote.ask)}',
                      style: TextStyle(
                        color: TradingTheme.grey,
                        fontSize: 10,
                      ),
                    ),
                    Text(
                      'High: ${formatPrice(quote.high)}',
                      style: TextStyle(
                        color: TradingTheme.grey,
                        fontSize: 10,
                      ),
                    ),
                  ],
                ),
                GestureDetector(
                  onTap: () {
                    setState(() {
                      quote.isWatching = !quote.isWatching;
                    });
                  },
                  child: Icon(
                    quote.isWatching
                        ? Icons.star_rounded
                        : Icons.star_outline_rounded,
                    color: quote.isWatching
                        ? TradingTheme.warning
                        : TradingTheme.white54,
                    size: 20,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBottomNav() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        color: TradingTheme.card,
        border: Border(
          top: BorderSide(color: TradingTheme.accent.withOpacity(0.2)),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _buildNavButton(
            icon: Icons.compare_arrows_rounded,
            label: 'Trade',
            onTap: widget.onTradePressed ?? () {},
          ),
          _buildNavButton(
            icon: Icons.show_chart_rounded,
            label: 'Chart',
            onTap: widget.onChartPressed ?? () {},
          ),
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                '${filteredQuotes.length}',
                style: const TextStyle(
                  color: TradingTheme.white,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
              Text(
                'Quotes',
                style: TextStyle(color: TradingTheme.grey, fontSize: 10),
              ),
            ],
          ),
          _buildNavButton(
            icon: Icons.access_time_rounded,
            label: 'Riwayat',
            onTap: widget.onHistoryPressed ?? () {},
          ),
          Stack(
            clipBehavior: Clip.none,
            children: [
              _buildNavButton(
                icon: Icons.notifications_active_rounded,
                label: 'Pesan',
                onTap: () {},
              ),
              Positioned(
                top: -4,
                right: -4,
                child: Container(
                  width: 16,
                  height: 16,
                  decoration: BoxDecoration(
                    color: TradingTheme.primary,
                    shape: BoxShape.circle,
                  ),
                  child: const Center(
                    child: Text(
                      '1',
                      style: TextStyle(
                        color: TradingTheme.white,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildNavButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: TradingTheme.white54, size: 20),
          const SizedBox(height: 2),
          Text(
            label,
            style: TextStyle(color: TradingTheme.grey, fontSize: 10),
          ),
        ],
      ),
    );
  }

  void _showOrderMenuDialog(Quote quote) {
    showModalBottomSheet(
      context: context,
      backgroundColor: TradingTheme.card,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) => Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: TradingTheme.border,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 20),
            Text(
              quote.symbol,
              style: const TextStyle(
                color: TradingTheme.white,
                fontSize: 20,
                fontWeight: FontWeight.bold,
                fontFamily: 'Astral',
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Ask: ${formatPrice(quote.ask)}',
              style: const TextStyle(
                color: TradingTheme.white54,
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 30),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildOrderButton('Order Baru', TradingTheme.success, () {
                  Navigator.pop(context);
                  _showNewOrderDialog(quote);
                }),
                _buildOrderButton('Chart', TradingTheme.warning, () {
                  Navigator.pop(context);
                }),
                _buildOrderButton('Properti', TradingTheme.primary, () {
                  Navigator.pop(context);
                }),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildOrderButton('Market Info', const Color(0xFF8E24AA), () {
                  Navigator.pop(context);
                }),
                _buildOrderButton('Statistics', const Color(0xFF00BCD4), () {
                  Navigator.pop(context);
                }),
              ],
            ),
            const SizedBox(height: 20),
            TextButton(
              onPressed: () => Navigator.pop(context),
              style: TextButton.styleFrom(
                backgroundColor: TradingTheme.cardAlt,
              ),
              child: const Text('Close'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOrderButton(String label, Color color, VoidCallback onTap) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: color.withOpacity(0.2),
            border: Border.all(color: color.withOpacity(0.4)),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: color,
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ),
    );
  }

  void _showAddSymbolDialog() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: TradingTheme.card,
        title: const Text(
          'Tambah Simbol',
          style: TextStyle(
            color: TradingTheme.white,
            fontFamily: 'Astral',
          ),
        ),
        content: TextField(
          style: const TextStyle(color: TradingTheme.white),
          decoration: InputDecoration(
            hintText: 'Masukkan simbol...',
            hintStyle: TextStyle(color: TradingTheme.grey),
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide(color: TradingTheme.border),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide:
                  const BorderSide(color: TradingTheme.primary, width: 2),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Tambah'),
          ),
        ],
      ),
    );
  }

  void _showNewOrderDialog(Quote quote) {
    showModalBottomSheet(
      context: context,
      backgroundColor: TradingTheme.card,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) => SingleChildScrollView(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(context).viewInsets.bottom,
        ),
        child: Container(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Order Baru',
                style: TextStyle(
                  color: TradingTheme.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Astral',
                ),
              ),
              const SizedBox(height: 20),
              Text(
                'Simbol: ${quote.symbol}',
                style: const TextStyle(color: TradingTheme.white54),
              ),
              const SizedBox(height: 10),
              TextField(
                style: const TextStyle(color: TradingTheme.white),
                decoration: InputDecoration(
                  labelText: 'Volume',
                  labelStyle: TextStyle(color: TradingTheme.grey),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: TradingTheme.border),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: const BorderSide(
                        color: TradingTheme.primary, width: 2),
                  ),
                ),
                keyboardType: TextInputType.number,
              ),
              const SizedBox(height: 15),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () => Navigator.pop(context),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: TradingTheme.success,
                      ),
                      child: const Text('BUY'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () => Navigator.pop(context),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: TradingTheme.primary,
                      ),
                      child: const Text('SELL'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  String formatPrice(double price) {
    if (price > 1000) {
      return price.toStringAsFixed(2);
    }
    return price.toStringAsFixed(4);
  }
}
