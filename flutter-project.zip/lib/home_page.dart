import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

// ══════════════════════════════════════════════════════════════════════════════
//  COLORS — TEMA BIRU
// ══════════════════════════════════════════════════════════════════════════════
const Color _kBg        = Color(0xFFF0F4FA);
const Color _kCard      = Colors.white;
const Color _kBorder    = Color(0xFF1A1A1A);
const Color _kBlue      = Color(0xFF2E75B6);
const Color _kBlueDark  = Color(0xFF1E5A96);
const Color _kBlueLight = Color(0xFF4A90D9);
const Color _kCream     = Color(0xFFF5E6C8);
const Color _kYellow    = Color(0xFFFFD600);
const Color _kWhite     = Colors.white;
const Color _kBlack     = Color(0xFF1A1A1A);
const Color _kGrey      = Color(0xFF757575);
const Color _kGreen     = Color(0xFF00CC66);

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  late AnimationController _pulseCtrl;
  late AnimationController _floatCtrl;
  late Animation<double> _floatAnim;
  late VideoPlayerController _videoCtrl;

  final _targetCtrl = TextEditingController();
  final _bugPageCtrl = PageController(viewportFraction: 0.72);

  String? _selectedBugId;
  bool _isSending = false;
  String? _responseMessage;
  int _currentBugPage = 0;

  List<String> _globalSenders = [];
  bool _isLoadingSenders = false;
  int _privateSenderCount = 0;
  int _globalSenderCount = 0;
  bool _loadingSender = false;
  Timer? _senderTimer;
  String _selectedSender = 'private';

  int _remainingQuota = 7;
  int _maxQuota = 7;

  bool get canAccessGlobalSender {
    final r = widget.role.toLowerCase();
    return r == 'owner' ||
        r == 'admin' ||
        r == 'moderator' ||
        r == 'partner' ||
        r == 'vip';
  }

  @override
  void initState() {
    super.initState();

    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat(reverse: true);

    _floatCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    )..repeat(reverse: true);

    _floatAnim = Tween<double>(begin: -6.0, end: 6.0).animate(
      CurvedAnimation(parent: _floatCtrl, curve: Curves.easeInOut),
    );

    // Init video banner
    _videoCtrl = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() {});
        _videoCtrl.setLooping(true);
        _videoCtrl.setVolume(0.0);
        _videoCtrl.play();
      });

    _fetchSenderStats();
    _loadGlobalSenders();
    _senderTimer =
        Timer.periodic(const Duration(seconds: 30), (_) => _fetchSenderStats());

    if (widget.listBug.isNotEmpty) {
      _selectedBugId = widget.listBug[0]['bug_id'] as String? ?? '0';
    }
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _floatCtrl.dispose();
    _videoCtrl.dispose();
    _targetCtrl.dispose();
    _bugPageCtrl.dispose();
    _senderTimer?.cancel();
    super.dispose();
  }

  // ── API FUNCTIONS ────────────────────────────────────────────────
  Future<void> _fetchSenderStats() async {
    if (_loadingSender) return;
    setState(() => _loadingSender = true);
    try {
      final res = await http.get(Uri.parse(
        'http://deylegal-panel.pterodactylxcz.my.id:2151/getSenderStats?key=${widget.sessionKey}',
      )).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true && mounted) {
          setState(() {
            _privateSenderCount = data['private'] ?? 0;
            _globalSenderCount = data['global'] ?? 0;
            _remainingQuota = data['remaining'] ?? 7;
            _maxQuota = data['max'] ?? 7;
          });
        }
      }
    } catch (_) {}
    if (mounted) setState(() => _loadingSender = false);
  }

  Future<void> _loadGlobalSenders() async {
    setState(() => _isLoadingSenders = true);
    try {
      final res = await http.get(Uri.parse(
        'http://deylegal-panel.pterodactylxcz.my.id:2151/getActiveSenders?key=${widget.sessionKey}',
      )).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['senders'] != null && mounted) {
        setState(() {
          _globalSenders = List<String>.from(data['senders']);
          _globalSenderCount = _globalSenders.length;
        });
      } else if (mounted) {
        setState(() => _globalSenders = []);
      }
    } catch (_) {
      if (mounted) setState(() => _globalSenders = []);
    } finally {
      if (mounted) setState(() => _isLoadingSenders = false);
    }
  }

  String? _formatPhone(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  void _setResponse(String type, String msg) {
    if (!mounted) return;
    setState(() => _responseMessage = '$type|$msg');
  }

  Future<void> _sendBug() async {
    final raw = _targetCtrl.text.trim();
    if (_formatPhone(raw) == null) {
      _showAlert('❌ Nomor Tidak Valid',
          'Gunakan format internasional.\nContoh: +62812xxxxxxxx');
      return;
    }
    if (_selectedSender == 'global' && !canAccessGlobalSender) {
      _showAlert('❌ Akses Ditolak',
          'Sender Global hanya untuk VIP, Admin, Owner.');
      return;
    }
    if (_selectedBugId == null || _selectedBugId!.isEmpty) {
      _showAlert('❌ No Bug Selected', 'Pilih 1 bug untuk dikirim.');
      return;
    }
    if (_selectedSender == 'private' && _privateSenderCount == 0) {
      _showAlert('❌ No Private Sender',
          'Tidak ada private sender tersedia.');
      return;
    }
    if (_selectedSender == 'global' && _globalSenderCount == 0) {
      _showAlert('❌ No Global Sender', 'Tidak ada global sender tersedia.');
      return;
    }

    setState(() {
      _isSending = true;
      _responseMessage = null;
    });
    try {
      final encodedTarget = Uri.encodeComponent(raw);
      final res = await http.get(Uri.parse(
        'http://deylegal-panel.pterodactylxcz.my.id:2151/sendBug'
        '?key=${widget.sessionKey}'
        '&target=$encodedTarget'
        '&bug=${_selectedBugId}'
        '${_selectedSender == 'global' ? '&senderMode=global' : '&sender=private'}',
      )).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);

      if (data['valid'] == false) {
        _setResponse('error', 'Session key tidak valid. Login ulang.');
      } else if (data['cooldown'] == true) {
        _setResponse(
            'warning', 'Cooldown! Tunggu ${data['wait'] ?? 0} detik lagi.');
      } else if (data['sended'] == true) {
        _setResponse('success',
            'Bug berhasil dikirim ke $raw! [${data['role'] ?? widget.role}]');
        _targetCtrl.clear();
        _fetchSenderStats();
      } else {
        _setResponse('error', 'Gagal mengirim. Server maintenance.');
      }
    } on Exception catch (e) {
      _setResponse(
          'error',
          e.toString().contains('Timeout')
              ? 'Request timeout. Periksa koneksi.'
              : 'Koneksi error. Coba lagi.');
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: AlertDialog(
          backgroundColor: _kWhite,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: const BorderSide(color: _kBorder, width: 2),
          ),
          title: Text(
            title,
            style: const TextStyle(
              color: _kBlue,
              fontWeight: FontWeight.bold,
              fontSize: 15,
            ),
          ),
          content: Text(
            msg,
            style: const TextStyle(
              color: _kBlack,
              fontSize: 13,
              height: 1.5,
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text(
                'OK',
                style: TextStyle(
                  color: _kBlue,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  APP BAR
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          // Logo kiri
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _kWhite,
              border: Border.all(
                  color: _kBlue.withValues(alpha: 0.3), width: 1.5),
            ),
            child: const Icon(Icons.android_rounded, color: _kBlue, size: 20),
          ),
          const Spacer(),
          // Badge SYAM BUG tengah
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
            decoration: BoxDecoration(
              color: _kBlue,
              borderRadius: BorderRadius.circular(30),
              border: Border.all(color: _kBlueDark, width: 2),
              boxShadow: [
                BoxShadow(
                  color: _kBlue.withValues(alpha: 0.4),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.shield_rounded, color: _kWhite, size: 18),
                SizedBox(width: 8),
                Text(
                  'SYAM BUG',
                  style: TextStyle(
                    color: _kWhite,
                    fontWeight: FontWeight.w900,
                    fontSize: 14,
                    letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
          ),
          const Spacer(),
          // Icon pin (refresh stats)
          GestureDetector(
            onTap: () {
              _fetchSenderStats();
              _loadGlobalSenders();
            },
            child: Container(
              width: 38,
              height: 38,
              child: const Icon(Icons.push_pin_rounded,
                  color: _kBlue, size: 22),
            ),
          ),
          const SizedBox(width: 4),
          // Icon history
          Container(
            width: 38,
            height: 38,
            child: const Icon(Icons.access_time_rounded,
                color: _kBlue, size: 22),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  BANNER VIDEO (banner.mp4)
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildBanner() {
    return Container(
      height: 210,
      width: double.infinity,
      margin: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.15),
            blurRadius: 15,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (_videoCtrl.value.isInitialized)
              FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoCtrl.value.size.width,
                  height: _videoCtrl.value.size.height,
                  child: VideoPlayer(_videoCtrl),
                ),
              )
            else
              Container(
                color: _kBlue,
                child: const Center(
                  child: CircularProgressIndicator(
                    color: _kWhite,
                    strokeWidth: 2,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  NOMOR TARGET (tanpa save)
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildNomorTarget() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _kBlue,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: _kBlue.withValues(alpha: 0.35),
            blurRadius: 15,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _kWhite.withValues(alpha: 0.2),
                  border: Border.all(
                      color: _kWhite.withValues(alpha: 0.4), width: 1.5),
                ),
                child: const Icon(Icons.phone_android_rounded,
                    color: _kWhite, size: 20),
              ),
              const SizedBox(width: 12),
              const Text(
                'NOMOR TARGET',
                style: TextStyle(
                  color: _kWhite,
                  fontWeight: FontWeight.w900,
                  fontSize: 14,
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Container(
            decoration: BoxDecoration(
              color: _kWhite,
              borderRadius: BorderRadius.circular(12),
            ),
            child: TextField(
              controller: _targetCtrl,
              style: const TextStyle(
                color: _kBlack,
                fontSize: 15,
                fontWeight: FontWeight.w600,
              ),
              cursorColor: _kBlue,
              keyboardType: TextInputType.phone,
              decoration: InputDecoration(
                hintText: '62xxxxxxxxxxx',
                hintStyle: TextStyle(
                  color: _kBlack.withValues(alpha: 0.3),
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                ),
                prefixIcon: const Icon(
                  Icons.public_rounded,
                  color: _kBlue,
                  size: 22,
                ),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(
                    vertical: 16, horizontal: 8),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  PILIH BUG (dengan efek naik-turun)
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildPilihBug() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _kBlue,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: _kBlue.withValues(alpha: 0.35),
            blurRadius: 15,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _kWhite.withValues(alpha: 0.2),
                  border: Border.all(
                      color: _kWhite.withValues(alpha: 0.4), width: 1.5),
                ),
                child: const Icon(Icons.bug_report_rounded,
                    color: _kWhite, size: 20),
              ),
              const SizedBox(width: 10),
              const Text(
                'PILIH BUG',
                style: TextStyle(
                  color: _kWhite,
                  fontWeight: FontWeight.w900,
                  fontSize: 14,
                  letterSpacing: 1.5,
                ),
              ),
              const Spacer(),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  color: _kWhite,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: const BoxDecoration(
                          color: _kGreen, shape: BoxShape.circle),
                    ),
                    const SizedBox(width: 6),
                    const Text(
                      'Engine lokal aktif',
                      style: TextStyle(
                        color: _kBlack,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      'WA belum connect',
                      style: TextStyle(
                        color: _kGrey.withValues(alpha: 0.7),
                        fontSize: 10,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),

          SizedBox(
            height: 180,
            child: widget.listBug.isEmpty
                ? const Center(
                    child: Text(
                      'Tidak ada bug tersedia.',
                      style: TextStyle(color: _kWhite, fontSize: 13),
                    ),
                  )
                : PageView.builder(
                    controller: _bugPageCtrl,
                    itemCount: widget.listBug.length,
                    onPageChanged: (i) => setState(() {
                      _currentBugPage = i;
                      _selectedBugId =
                          widget.listBug[i]['bug_id'] as String? ?? '$i';
                    }),
                    itemBuilder: (ctx, i) {
                      final bug = widget.listBug[i];
                      final bugId = bug['bug_id'] as String? ?? '$i';
                      final isSelected = _selectedBugId == bugId;

                      return GestureDetector(
                        onTap: () => setState(() => _selectedBugId = bugId),
                        child: AnimatedBuilder(
                          animation: _floatAnim,
                          builder: (context, child) {
                            return Transform.translate(
                              offset: Offset(
                                  0, isSelected ? _floatAnim.value : 0),
                              child: child,
                            );
                          },
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 250),
                            margin: const EdgeInsets.only(right: 10),
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: isSelected
                                  ? _kWhite
                                  : _kWhite.withValues(alpha: 0.85),
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(
                                color: isSelected
                                    ? _kGreen
                                    : _kWhite.withValues(alpha: 0.3),
                                width: isSelected ? 2.5 : 1.5,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: isSelected
                                      ? _kGreen.withValues(alpha: 0.4)
                                      : Colors.black.withValues(alpha: 0.15),
                                  blurRadius: isSelected ? 15 : 8,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Container(
                                      width: 40,
                                      height: 40,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: isSelected
                                            ? _kBlue
                                            : _kBlue.withValues(alpha: 0.15),
                                      ),
                                      child: Icon(
                                        Icons.shield_rounded,
                                        color: isSelected
                                            ? _kWhite
                                            : _kBlue.withValues(alpha: 0.5),
                                        size: 22,
                                      ),
                                    ),
                                    if (isSelected)
                                      Container(
                                        width: 28,
                                        height: 28,
                                        decoration: const BoxDecoration(
                                          color: _kGreen,
                                          shape: BoxShape.circle,
                                        ),
                                        child: const Icon(Icons.check_rounded,
                                            color: _kWhite, size: 16),
                                      ),
                                  ],
                                ),
                                const Spacer(),
                                Text(
                                  (bug['bug_name'] as String? ?? 'BUG')
                                      .toUpperCase(),
                                  style: const TextStyle(
                                    color: _kBlack,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 13,
                                    letterSpacing: 0.5,
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: _kBlue.withValues(alpha: 0.1),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: Text(
                                    bug['bug_id']?.toString().toLowerCase() ??
                                        'bug',
                                    style: const TextStyle(
                                      color: _kBlue,
                                      fontSize: 10,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
          ),
          const SizedBox(height: 12),

          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(widget.listBug.length, (i) {
              final active = i == _currentBugPage;
              return AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                margin: const EdgeInsets.symmetric(horizontal: 3),
                width: active ? 22 : 7,
                height: 7,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(4),
                  color: active ? _kWhite : _kWhite.withValues(alpha: 0.4),
                ),
              );
            }),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  PILIH SENDER
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildSenderPanel() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _kBlue,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: _kBlue.withValues(alpha: 0.35),
            blurRadius: 15,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _kWhite.withValues(alpha: 0.2),
                  border: Border.all(
                      color: _kWhite.withValues(alpha: 0.4), width: 1.5),
                ),
                child: const Icon(Icons.swap_horiz_rounded,
                    color: _kWhite, size: 18),
              ),
              const SizedBox(width: 10),
              const Text(
                'PILIH SENDER',
                style: TextStyle(
                  color: _kWhite,
                  fontWeight: FontWeight.w900,
                  fontSize: 14,
                  letterSpacing: 1,
                ),
              ),
              const Spacer(),
              GestureDetector(
                onTap: () {
                  _fetchSenderStats();
                  _loadGlobalSenders();
                },
                child: _isLoadingSenders || _loadingSender
                    ? const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(
                            strokeWidth: 2, color: _kWhite),
                      )
                    : const Icon(Icons.refresh_rounded,
                        color: _kWhite, size: 20),
              ),
              const SizedBox(width: 10),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: _kWhite,
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.circle, color: _kGreen, size: 7),
                    const SizedBox(width: 5),
                    Text(
                      _loadingSender
                          ? '-- sender'
                          : '${_privateSenderCount + _globalSenderCount} sender online',
                      style: const TextStyle(
                        color: _kBlack,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          Row(
            children: [
              Expanded(
                child: GestureDetector(
                  onTap: () => setState(() => _selectedSender = 'private'),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    height: 130,
                    decoration: BoxDecoration(
                      color: _selectedSender == 'private'
                          ? _kWhite
                          : _kWhite.withValues(alpha: 0.85),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: _selectedSender == 'private'
                            ? _kGreen
                            : _kWhite.withValues(alpha: 0.3),
                        width: _selectedSender == 'private' ? 2.5 : 1.5,
                      ),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.person_rounded,
                          color: _selectedSender == 'private'
                              ? _kBlue
                              : _kBlue.withValues(alpha: 0.4),
                          size: 38,
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Pribadi',
                          style: TextStyle(
                            color: _selectedSender == 'private'
                                ? _kBlue
                                : _kBlack.withValues(alpha: 0.6),
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                        const SizedBox(height: 6),
                        _privateSenderCount == 0
                            ? const Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.close_rounded,
                                      color: Colors.redAccent, size: 14),
                                  SizedBox(width: 4),
                                  Text('Kosong',
                                      style: TextStyle(
                                        color: Colors.redAccent,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 12,
                                      )),
                                ],
                              )
                            : Text(
                                '$_privateSenderCount sender',
                                style: TextStyle(
                                  color: _selectedSender == 'private'
                                      ? _kBlueDark
                                      : _kGrey,
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),

              Expanded(
                child: GestureDetector(
                  onTap: () {
                    if (!canAccessGlobalSender) {
                      _showAlert('❌ Akses Ditolak',
                          'Sender Global hanya untuk VIP, Admin, Owner.');
                      return;
                    }
                    setState(() => _selectedSender = 'global');
                    _loadGlobalSenders();
                  },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    height: 130,
                    decoration: BoxDecoration(
                      color: _selectedSender == 'global'
                          ? _kWhite
                          : _kWhite.withValues(alpha: 0.85),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: _selectedSender == 'global'
                            ? _kGreen
                            : _kWhite.withValues(alpha: 0.3),
                        width: _selectedSender == 'global' ? 2.5 : 1.5,
                      ),
                    ),
                    child: Stack(
                      children: [
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.public_rounded,
                              color: _selectedSender == 'global'
                                  ? _kBlue
                                  : _kBlue.withValues(alpha: 0.4),
                              size: 38,
                            ),
                            const SizedBox(height: 8),
                            Text(
                              'Global',
                              style: TextStyle(
                                color: _selectedSender == 'global'
                                    ? _kBlue
                                    : _kBlack.withValues(alpha: 0.6),
                                fontWeight: FontWeight.bold,
                                fontSize: 14,
                              ),
                            ),
                            const SizedBox(height: 6),
                            _globalSenderCount == 0
                                ? const Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.center,
                                    children: [
                                      Icon(Icons.close_rounded,
                                          color: Colors.redAccent, size: 14),
                                      SizedBox(width: 4),
                                      Text('Kosong',
                                          style: TextStyle(
                                            color: Colors.redAccent,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 12,
                                          )),
                                    ],
                                  )
                                : Text(
                                    '$_globalSenderCount sender',
                                    style: TextStyle(
                                      color: _selectedSender == 'global'
                                          ? _kBlueDark
                                          : _kGrey,
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                          ],
                        ),
                        if (!canAccessGlobalSender)
                          Positioned(
                            top: 8,
                            right: 8,
                            child: Container(
                              width: 22,
                              height: 22,
                              decoration: const BoxDecoration(
                                color: Colors.amber,
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(Icons.lock_rounded,
                                  color: _kWhite, size: 12),
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),

          Row(
            children: [
              const Icon(Icons.info_outline_rounded,
                  color: _kWhite, size: 14),
              const SizedBox(width: 6),
              Text(
                'Sisa kirim global hari ini: $_remainingQuota / $_maxQuota',
                style: const TextStyle(
                  color: _kWhite,
                  fontSize: 11,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),

          if (_selectedSender == 'global' && _globalSenders.isNotEmpty) ...[
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _kWhite,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Column(
                children: [
                  ..._globalSenders.take(3).map((s) => Padding(
                        padding: const EdgeInsets.only(bottom: 4),
                        child: Row(
                          children: [
                            const Icon(Icons.circle,
                                color: _kGreen, size: 7),
                            const SizedBox(width: 8),
                            Text(
                              s,
                              style: const TextStyle(
                                color: _kBlack,
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      )),
                  if (_globalSenders.length > 3)
                    Text(
                      '+ ${_globalSenders.length - 3} lainnya...',
                      style: TextStyle(
                        color: _kGrey.withValues(alpha: 0.6),
                        fontSize: 10,
                      ),
                    ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  RESPONSE BANNER
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildResponse() {
    if (_responseMessage == null) return const SizedBox.shrink();
    final parts = _responseMessage!.split('|');
    final type = parts[0];
    final msg = parts.length > 1 ? parts[1] : '';

    Color color;
    IconData icon;
    String title;
    switch (type) {
      case 'success':
        color = _kGreen;
        icon = Icons.check_circle_outline;
        title = 'Berhasil';
        break;
      case 'warning':
        color = Colors.amber;
        icon = Icons.warning_rounded;
        title = 'Peringatan';
        break;
      default:
        color = Colors.redAccent;
        icon = Icons.error_outline;
        title = 'Gagal';
    }

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _kWhite,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withValues(alpha: 0.4), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: color.withValues(alpha: 0.15),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color.withValues(alpha: 0.15),
            ),
            child: Icon(icon, color: color, size: 18),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: color,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  msg,
                  style: const TextStyle(
                    color: _kBlack,
                    fontSize: 12,
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: () => setState(() => _responseMessage = null),
            child: const Icon(Icons.close_rounded, color: _kGrey, size: 16),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  KIRIM BUG BUTTON
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: _pulseCtrl,
      builder: (_, __) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Container(
          height: 62,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            color: _kCream,
            border: Border.all(color: _kBlue, width: 2),
            boxShadow: [
              BoxShadow(
                color: _kBlue.withValues(alpha: 0.25),
                blurRadius: 15,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: ElevatedButton(
            onPressed: _isSending ? null : _sendBug,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.transparent,
              shadowColor: Colors.transparent,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
              elevation: 0,
            ),
            child: _isSending
                ? const SizedBox(
                    width: 26,
                    height: 26,
                    child: CircularProgressIndicator(
                        color: _kBlue, strokeWidth: 3),
                  )
                : const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.play_arrow_rounded,
                          color: _kBlue, size: 26),
                      SizedBox(width: 10),
                      Text(
                        'KIRIM BUG',
                        style: TextStyle(
                          color: _kBlue,
                          fontWeight: FontWeight.w900,
                          fontSize: 16,
                          letterSpacing: 2,
                        ),
                      ),
                    ],
                  ),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  FOOTER
  // ═══════════════════════════════════════════════════════════════════
  Widget _buildFooter() {
    return Column(
      children: [
        Text(
          'NEBULA TEAM',
          style: TextStyle(
            color: _kBlack.withValues(alpha: 0.5),
            fontSize: 11,
            letterSpacing: 2,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          '© 2026 NEBULA Always For You',
          style: TextStyle(
            color: _kBlack.withValues(alpha: 0.4),
            fontSize: 10,
          ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════════════
  //  BUILD
  // ═══════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _kBg,
      body: Stack(
        children: [
          // Background gradient
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Color(0xFFE8EEF7),
                    Color(0xFFF0F4FA),
                    Color(0xFFFFFFFF),
                  ],
                ),
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                _buildAppBar(),
                Expanded(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    child: Column(
                      children: [
                        _buildBanner(),
                        const SizedBox(height: 20),
                        _buildNomorTarget(),
                        const SizedBox(height: 20),
                        _buildPilihBug(),
                        const SizedBox(height: 20),
                        _buildSenderPanel(),
                        const SizedBox(height: 20),
                        _buildResponse(),
                        if (_responseMessage != null)
                          const SizedBox(height: 14),
                        _buildSendButton(),
                        const SizedBox(height: 20),
                        _buildFooter(),
                        const SizedBox(height: 30),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}