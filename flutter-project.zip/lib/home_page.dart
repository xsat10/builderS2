// ============================================================
// 🎨 MCQUEEN BUG — DARK RED COMIC 3D Edition
// File: home_page.dart
// v7 — Background Image (JPG) + Global Sender Quota + BUG MENU
// ============================================================
import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'api_config.dart';
import 'cek_ban_page.dart';
import 'custom_payload.dart';

class _MC {
  // ═══ DARK RED COMIC PALETTE ═══
  static const red          = Color(0xFF8B0000);
  static const redDeep      = Color(0xFF1A0A0A);
  static const redDark      = Color(0xFF4A0000);
  static const redSoft      = Color(0xFF2A0E0E);
  static const redLight     = Color(0xFF3D1414);
  static const accentRed    = Color(0xFFD32F2F);
  static const brightRed    = Color(0xFFFF3B3B);
  static const violet       = Color(0xFFA855F7);
  static const cyan         = Color(0xFF22D3EE);
  static const green        = Color(0xFF22C55E);
  static const greenLite    = Color(0xFF4ADE80);
  static const amber        = Color(0xFFFBBF24);
  static const gold         = Color(0xFFFDE68A);
  static const blueCheck    = Color(0xFF60A5FA);
  static const white        = Color(0xFFFFF5F5);
  static const cream        = Color(0xFF0F0505);
  static const textDark     = Color(0xFFFFF5F5);
  static const textGrey     = Color(0xFFC9A0A0);
  static const textLight    = Color(0xFF8A6060);
  // ═══ COMIC OUTLINE ═══
  static const comicBlack   = Color(0xFF000000);
  static const comicOutline = Color(0xFF1A0000);
  static const buttonYellow = Color(0xFFB8860B);
  static const buttonDark   = Color(0xFF1A1A1A);
}

// ════════════════════════════════════════════════════════════
// 🎯 GLOBAL SENDER QUOTA PER ROLE
// ════════════════════════════════════════════════════════════
class _GlobalQuota {
  static const Map<String, int> defaultQuota = {
    'member': 3,
    'owner': 10,
    'staff': 15,
    'reseller': 5,
    // Role lain default 100
  };

  static int getQuota(String role) {
    final r = role.toLowerCase();
    return defaultQuota[r] ?? 100;
  }
}

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  late AnimationController _pulseController;
  late AnimationController _resultCtrl;
  late AnimationController _ringController;
  late AnimationController _bannerController;
  late Animation<double> _resultFade;
  late Animation<Offset> _resultSlide;
  late Animation<double> _bannerSwing;

  final targetController = TextEditingController();
  final PageController _itemPageController =
      PageController(viewportFraction: 0.82);

  String? _selectedItemId;
  bool _isSending = false;
  String? _responseMessage;
  int _currentItemPage = 0;
  String _targetMode = 'contact';

  List<String> _activeSenders = [];
  bool _isLoadingSenders = false;
  int _privateSenderCount = 0;
  int _globalSenderCount = 0;
  bool _loadingSender = false;
  Timer? _senderTimer;
  String _selectedSenderMode = 'private';
  String? _selectedSenderNumber;

  // ═══ GLOBAL SENDER QUOTA SYSTEM ═══
  int _globalQuotaMax = 100;
  int _globalQuotaUsed = 0;

  int get _globalQuotaLeft =>
      (_globalQuotaMax - _globalQuotaUsed).clamp(0, _globalQuotaMax);
  bool get _globalQuotaEmpty => _globalQuotaLeft <= 0;

  // ═══ SAVED NUMBERS ═══
  List<String> _savedNumbers = [];
  bool _showSavedNumbers = false;

  Map<String, dynamic>? _groupInfo;
  bool _loadingGroupInfo = false;
  String? _groupError;
  Timer? _groupDebounce;

  bool _showProcessing = false;
  int _processingStep = 0;
  String _processingStatus = '';
  String _processingMessage = '';
  double _processingProgress = 0.0;
  Timer? _processingTimer;

  static const List<String> _globalRoles = [
    'owner_utama', 'owner', 'staff', 'executorius', 'forius_utama',
    'moderator', 'ceo_utama', 'tangan_kanan', 'tangan_kiri',
    'developers', 'partner_pribadi', 'partner', 'admin', 'reseller',
    'tukang_bubur', 'vip', 'member',
  ];

  bool get _canAccessGlobal {
    // Semua user bisa akses global sender (dengan kuota terbatas)
    return true;
  }

  Color _roleColor(String role) {
    switch (role.toLowerCase()) {
      case 'owner_utama': return _MC.gold;
      case 'owner': return const Color(0xFFFFB300);
      case 'staff': return const Color(0xFFE53935);
      case 'executorius': return const Color(0xFFFF6B00);
      case 'forius_utama': return const Color(0xFFFF8F00);
      case 'moderator': return const Color(0xFF8E24AA);
      case 'ceo_utama': return const Color(0xFF7E57C2);
      case 'tangan_kanan': return const Color(0xFF26C6DA);
      case 'tangan_kiri': return const Color(0xFF4DD0E1);
      case 'developers': return const Color(0xFF29B6F6);
      case 'partner_pribadi': return const Color(0xFF66BB6A);
      case 'partner': return const Color(0xFF43A047);
      case 'admin': return const Color(0xFF26A69A);
      case 'tukang_bubur': return const Color(0xFFFFCA28);
      case 'reseller': return const Color(0xFF9CCC65);
      case 'vip': return const Color(0xFFFFD54F);
      default: return _MC.red;
    }
  }

  int _roleRingLevel(String role) {
    switch (role.toLowerCase()) {
      case 'member': return 1;
      case 'vip': return 2;
      case 'reseller':
      case 'tukang_bubur': return 3;
      case 'admin':
      case 'partner':
      case 'partner_pribadi': return 4;
      case 'tangan_kiri':
      case 'tangan_kanan':
      case 'developers':
      case 'ceo_utama':
      case 'moderator': return 5;
      case 'forius_utama':
      case 'executorius':
      case 'staff': return 6;
      case 'owner': return 7;
      case 'owner_utama': return 8;
      default: return 1;
    }
  }

  bool _isPremiumRole(String role) {
    final r = role.toLowerCase();
    return _globalRoles.contains(r) && r != 'vip' && r != 'partner';
  }

  @override
  void initState() {
    super.initState();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _ringController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    )..repeat();

    // ═══ BANNER SWING ANIMATION ═══
    _bannerController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2200),
    )..repeat(reverse: true);
    _bannerSwing = Tween<double>(begin: -0.08, end: 0.08).animate(
      CurvedAnimation(parent: _bannerController, curve: Curves.easeInOut),
    );

    _resultCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 500));
    _resultFade =
        CurvedAnimation(parent: _resultCtrl, curve: Curves.easeOut);
    _resultSlide = Tween<Offset>(
      begin: const Offset(0, 0.15),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _resultCtrl, curve: Curves.easeOutCubic));

    targetController.addListener(_onTargetChanged);

    _initGlobalQuota();
    _fetchSenderStats();
    _loadActiveSenders();
    _loadSavedNumbers();
    _senderTimer = Timer.periodic(
        const Duration(seconds: 30), (_) => _fetchSenderStats());

    final first = _itemsForMode();
    if (first.isNotEmpty) {
      _selectedItemId = _resolveId(first[0]);
    }
  }

  // ════════════════════════════════════════════════════════════
  // 🎯 GLOBAL QUOTA INIT
  // ════════════════════════════════════════════════════════════
  Future<void> _initGlobalQuota() async {
    _globalQuotaMax = _GlobalQuota.getQuota(widget.role);
    final prefs = await SharedPreferences.getInstance();
    final key = 'global_quota_used_${widget.username}';
    final used = prefs.getInt(key) ?? 0;
    if (mounted) {
      setState(() {
        _globalQuotaUsed = used.clamp(0, _globalQuotaMax);
      });
    }
  }

  Future<void> _consumeGlobalQuota() async {
    if (_globalQuotaEmpty) return;
    final prefs = await SharedPreferences.getInstance();
    final key = 'global_quota_used_${widget.username}';
    _globalQuotaUsed = (_globalQuotaUsed + 1).clamp(0, _globalQuotaMax);
    await prefs.setInt(key, _globalQuotaUsed);
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    targetController.removeListener(_onTargetChanged);
    _pulseController.dispose();
    _ringController.dispose();
    _bannerController.dispose();
    _resultCtrl.dispose();
    targetController.dispose();
    _itemPageController.dispose();
    _senderTimer?.cancel();
    _processingTimer?.cancel();
    _groupDebounce?.cancel();
    super.dispose();
  }

  // ════════════════════════════════════════════════════════════
  // 💾 SAVED NUMBERS SYSTEM
  // ════════════════════════════════════════════════════════════
  Future<void> _loadSavedNumbers() async {
    final prefs = await SharedPreferences.getInstance();
    final key = 'saved_numbers_${widget.username}';
    final list = prefs.getStringList(key) ?? [];
    if (mounted) setState(() => _savedNumbers = list);
  }

  Future<void> _saveNumber() async {
    final raw = targetController.text.trim();
    if (raw.isEmpty) {
      _showAlert("❌ Kosong", "Masukkan nomor target dulu sebelum disave.");
      return;
    }
    if (!_savedNumbers.contains(raw)) {
      _savedNumbers.insert(0, raw);
      final prefs = await SharedPreferences.getInstance();
      await prefs.setStringList(
          'saved_numbers_${widget.username}', _savedNumbers);
      if (mounted) setState(() {});
      _showAlert("✅ Tersimpan", "Nomor berhasil disimpan:\n$raw");
    } else {
      _showAlert("⚠️ Duplikat", "Nomor ini sudah ada di daftar simpanan.");
    }
  }

  Future<void> _deleteSavedNumber(String number) async {
    _savedNumbers.remove(number);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(
        'saved_numbers_${widget.username}', _savedNumbers);
    if (mounted) setState(() {});
  }

  Widget _buildSaveNumberBar() {
    if (_targetMode != 'contact') return const SizedBox.shrink();
    return Container(
      margin: const EdgeInsets.only(top: 12),
      child: Row(
        children: [
          Expanded(
            child: GestureDetector(
              onTap: _saveNumber,
              child: Container(
                height: 48,
                decoration: BoxDecoration(
                  color: _MC.red,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: _MC.comicBlack, width: 3),
                  boxShadow: const [
                    BoxShadow(
                        color: _MC.comicBlack,
                        offset: Offset(4, 4),
                        blurRadius: 0),
                  ],
                ),
                child: const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.save_rounded, color: _MC.white, size: 20),
                    SizedBox(width: 8),
                    Text(
                      'SAVE NOMOR',
                      style: TextStyle(
                        color: _MC.white,
                        fontWeight: FontWeight.w900,
                        fontSize: 13,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          GestureDetector(
            onTap: () =>
                setState(() => _showSavedNumbers = !_showSavedNumbers),
            child: Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: _MC.buttonDark,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: _MC.comicBlack, width: 3),
                boxShadow: const [
                  BoxShadow(
                      color: _MC.comicBlack,
                      offset: Offset(4, 4),
                      blurRadius: 0),
                ],
              ),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  const Icon(Icons.list_rounded,
                      color: _MC.white, size: 22),
                  if (_savedNumbers.isNotEmpty)
                    Positioned(
                      right: 4,
                      top: 4,
                      child: Container(
                        padding: const EdgeInsets.all(3),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _MC.brightRed,
                          border: Border.all(
                              color: _MC.comicBlack, width: 1.5),
                        ),
                        constraints: const BoxConstraints(
                            minWidth: 16, minHeight: 16),
                        child: Text(
                          '${_savedNumbers.length}',
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: _MC.white,
                            fontSize: 9,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSavedNumbersList() {
    if (!_showSavedNumbers || _savedNumbers.isEmpty) {
      return const SizedBox.shrink();
    }
    return Container(
      margin: const EdgeInsets.only(top: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _MC.redSoft,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _MC.comicBlack, width: 3),
        boxShadow: const [
          BoxShadow(
              color: _MC.comicBlack, offset: Offset(4, 4), blurRadius: 0),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.bookmark_rounded,
                  color: _MC.brightRed, size: 16),
              const SizedBox(width: 8),
              const Text(
                'NOMOR TERSIMPAN',
                style: TextStyle(
                  color: _MC.white,
                  fontWeight: FontWeight.w900,
                  fontSize: 12,
                  letterSpacing: 1.5,
                ),
              ),
              const Spacer(),
              GestureDetector(
                onTap: () => setState(() => _showSavedNumbers = false),
                child: Container(
                  width: 24,
                  height: 24,
                  decoration: BoxDecoration(
                    color: _MC.buttonDark,
                    borderRadius: BorderRadius.circular(8),
                    border:
                        Border.all(color: _MC.comicBlack, width: 2),
                  ),
                  child: const Icon(Icons.close_rounded,
                      color: _MC.white, size: 14),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          ..._savedNumbers.map((n) => GestureDetector(
                onTap: () {
                  targetController.text = n;
                  setState(() => _showSavedNumbers = false);
                },
                child: Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 10),
                  decoration: BoxDecoration(
                    color: _MC.buttonDark,
                    borderRadius: BorderRadius.circular(10),
                    border:
                        Border.all(color: _MC.comicBlack, width: 2.5),
                    boxShadow: const [
                      BoxShadow(
                          color: _MC.comicBlack,
                          offset: Offset(3, 3),
                          blurRadius: 0),
                    ],
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 8,
                        height: 8,
                        decoration: const BoxDecoration(
                          color: _MC.greenLite,
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          n,
                          style: const TextStyle(
                            color: _MC.white,
                            fontSize: 12.5,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                      GestureDetector(
                        onTap: () => _deleteSavedNumber(n),
                        child: Container(
                          width: 26,
                          height: 26,
                          decoration: BoxDecoration(
                            color: _MC.red,
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(
                                color: _MC.comicBlack, width: 2),
                          ),
                          child: const Icon(Icons.delete_rounded,
                              color: _MC.white, size: 14),
                        ),
                      ),
                    ],
                  ),
                ),
              )),
        ],
      ),
    );
  }

  // ════════════════════════════════════════════════════════════
  // 🔍 AUTO-DETECT GROUP INFO
  // ════════════════════════════════════════════════════════════
  void _onTargetChanged() {
    if (_targetMode != 'group') return;
    _groupDebounce?.cancel();
    final text = targetController.text.trim();

    if (text.isEmpty) {
      if (mounted) {
        setState(() {
          _groupInfo = null;
          _groupError = null;
          _loadingGroupInfo = false;
        });
      }
      return;
    }

    _groupDebounce = Timer(const Duration(milliseconds: 900), () {
      _fetchGroupInfo(text);
    });
  }

  Future<void> _fetchGroupInfo(String input) async {
    if (!mounted) return;
    setState(() {
      _loadingGroupInfo = true;
      _groupError = null;
      _groupInfo = null;
    });

    try {
      final res = await http
          .post(
            Uri.parse('$baseUrl/groupInfo'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'key': widget.sessionKey,
              'groupInput': input,
            }),
          )
          .timeout(const Duration(seconds: 20));

      final data = jsonDecode(res.body);
      if (!mounted) return;

      if (data['valid'] == true && data['success'] == true) {
        setState(() {
          _groupInfo = Map<String, dynamic>.from(data);
          _loadingGroupInfo = false;
        });
      } else {
        setState(() {
          _groupError = data['message'] ?? 'Gagal ambil info grup';
          _loadingGroupInfo = false;
        });
      }
    } on TimeoutException {
      if (mounted) {
        setState(() {
          _groupError = '⏱️ Timeout. Coba lagi.';
          _loadingGroupInfo = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _groupError = '❌ Koneksi error';
          _loadingGroupInfo = false;
        });
      }
    }
  }

  Widget _buildGroupInfoCard() {
    if (_targetMode != 'group') return const SizedBox.shrink();

    if (_loadingGroupInfo) {
      return Container(
        margin: const EdgeInsets.only(top: 14),
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: _MC.redSoft,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: _MC.comicBlack, width: 3.5),
          boxShadow: const [
            BoxShadow(
                color: _MC.comicBlack,
                offset: Offset(5, 5),
                blurRadius: 0),
          ],
        ),
        child: const Column(
          children: [
            SizedBox(
              width: 42, height: 42,
              child: CircularProgressIndicator(
                  color: _MC.brightRed, strokeWidth: 3),
            ),
            SizedBox(height: 14),
            Text('MENGAMBIL DATA GROUP...',
                style: TextStyle(
                  color: _MC.white,
                  fontWeight: FontWeight.w900,
                  fontSize: 12,
                  letterSpacing: 1.5,
                )),
            SizedBox(height: 4),
            Text('Menghubungkan ke WhatsApp API',
                style: TextStyle(
                  color: _MC.textGrey,
                  fontSize: 11,
                  fontWeight: FontWeight.w500,
                )),
          ],
        ),
      );
    }

    if (_groupError != null) {
      return Container(
        margin: const EdgeInsets.only(top: 14),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: _MC.redSoft,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: _MC.comicBlack, width: 3.5),
          boxShadow: const [
            BoxShadow(
                color: _MC.comicBlack,
                offset: Offset(5, 5),
                blurRadius: 0),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 44, height: 44,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _MC.red,
                border: Border.all(color: _MC.comicBlack, width: 3),
              ),
              child: const Icon(Icons.error_outline_rounded,
                  color: _MC.white, size: 22),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('GAGAL DETEKSI GROUP',
                      style: TextStyle(
                        color: _MC.white,
                        fontWeight: FontWeight.w900,
                        fontSize: 12,
                        letterSpacing: 1,
                      )),
                  const SizedBox(height: 4),
                  Text(_groupError!,
                      style: const TextStyle(
                        color: _MC.textGrey,
                        fontSize: 11.5,
                        fontWeight: FontWeight.w600,
                        height: 1.4,
                      )),
                ],
              ),
            ),
          ],
        ),
      );
    }

    if (_groupInfo == null) return const SizedBox.shrink();

    final info = _groupInfo!;
    final name = (info['name'] ?? 'Unknown Group').toString();
    final description = (info['description'] ?? '').toString();
    final memberCount = info['memberCount'] ?? 0;
    final joined = info['joined'] == true;
    final status = (info['status'] ?? 'active').toString();
    final photoUrl = (info['photoUrl'] ?? '').toString();
    final createdAt = (info['createdAt'] ?? '').toString();
    final groupId = (info['id'] ?? '').toString();

    return Container(
      margin: const EdgeInsets.only(top: 14),
      decoration: BoxDecoration(
        color: _MC.redSoft,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _MC.comicBlack, width: 3.5),
        boxShadow: const [
          BoxShadow(
              color: _MC.comicBlack,
              offset: Offset(5, 6),
              blurRadius: 0),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(15),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              height: 100,
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [_MC.redDark, _MC.red],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: Stack(
                children: [
                  Positioned.fill(
                    child: CustomPaint(painter: _GroupBannerPainter()),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    child: Row(
                      children: [
                        Container(
                          width: 68, height: 68,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: _MC.white,
                            border: Border.all(
                                color: _MC.comicBlack, width: 3),
                            boxShadow: const [
                              BoxShadow(
                                  color: _MC.comicBlack,
                                  offset: Offset(3, 4),
                                  blurRadius: 0),
                            ],
                          ),
                          child: ClipOval(
                            child: photoUrl.isNotEmpty
                                ? Image.network(
                                    photoUrl,
                                    fit: BoxFit.cover,
                                    loadingBuilder: (_, child, progress) =>
                                        progress == null
                                            ? child
                                            : const Center(
                                                child: SizedBox(
                                                  width: 24, height: 24,
                                                  child:
                                                      CircularProgressIndicator(
                                                    strokeWidth: 2,
                                                    color: _MC.red,
                                                  ),
                                                ),
                                              ),
                                    errorBuilder: (_, __, ___) =>
                                        const Icon(
                                      Icons.group_rounded,
                                      color: _MC.redDark,
                                      size: 32,
                                    ),
                                  )
                                : const Icon(
                                    Icons.group_rounded,
                                    color: _MC.redDark,
                                    size: 32,
                                  ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                name.toUpperCase(),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  color: _MC.white,
                                  fontSize: 15,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 1,
                                  shadows: [
                                    Shadow(
                                      color: _MC.comicBlack,
                                      offset: Offset(2, 2),
                                      blurRadius: 0,
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 4),
                              Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 8, vertical: 2),
                                    decoration: BoxDecoration(
                                      color: joined
                                          ? _MC.greenLite
                                          : _MC.amber,
                                      borderRadius:
                                          BorderRadius.circular(10),
                                      border: Border.all(
                                          color: _MC.comicBlack,
                                          width: 2),
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Icon(
                                          joined
                                              ? Icons.check_circle_rounded
                                              : Icons.info_rounded,
                                          color: _MC.comicBlack,
                                          size: 10,
                                        ),
                                        const SizedBox(width: 3),
                                        Text(
                                          joined ? 'JOINED' : 'NOT JOINED',
                                          style: const TextStyle(
                                            color: _MC.comicBlack,
                                            fontSize: 8,
                                            fontWeight: FontWeight.w900,
                                            letterSpacing: 0.8,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(width: 6),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 8, vertical: 2),
                                    decoration: BoxDecoration(
                                      color: _MC.white.withOpacity(0.25),
                                      borderRadius:
                                          BorderRadius.circular(10),
                                      border: Border.all(
                                          color: _MC.comicBlack,
                                          width: 1.5),
                                    ),
                                    child: Text(
                                      status.toUpperCase(),
                                      style: const TextStyle(
                                        color: _MC.white,
                                        fontSize: 8,
                                        fontWeight: FontWeight.w900,
                                        letterSpacing: 0.8,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (description.isNotEmpty) ...[
                    Row(
                      children: [
                        Container(
                          width: 26, height: 26,
                          decoration: BoxDecoration(
                            color: _MC.red,
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(
                                color: _MC.comicBlack, width: 2.5),
                          ),
                          child: const Icon(Icons.description_rounded,
                              color: _MC.white, size: 14),
                        ),
                        const SizedBox(width: 8),
                        const Text('DESKRIPSI',
                            style: TextStyle(
                              color: _MC.white,
                              fontWeight: FontWeight.w900,
                              fontSize: 11,
                              letterSpacing: 1.2,
                            )),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: _MC.cream,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                            color: _MC.comicBlack, width: 2),
                      ),
                      child: Text(
                        description,
                        style: const TextStyle(
                          color: _MC.textDark,
                          fontSize: 12,
                          height: 1.5,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),
                  ],
                  Row(
                    children: [
                      Expanded(
                        child: _buildStatBox(
                          icon: Icons.people_alt_rounded,
                          label: 'ANGGOTA',
                          value: '$memberCount',
                          color: _MC.red,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _buildStatBox(
                          icon: joined
                              ? Icons.check_circle_rounded
                              : Icons.cancel_rounded,
                          label: 'STATUS',
                          value: joined ? 'JOINED' : 'NONE',
                          color: joined ? _MC.green : _MC.amber,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: _buildStatBox(
                          icon: Icons.calendar_today_rounded,
                          label: 'DIBUAT',
                          value: createdAt.isNotEmpty
                              ? _formatDate(createdAt)
                              : '-',
                          color: _MC.cyan,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _buildStatBox(
                          icon: Icons.fingerprint_rounded,
                          label: 'ID',
                          value: groupId.isNotEmpty
                              ? groupId.substring(
                                  0, math.min(8, groupId.length))
                              : '-',
                          color: _MC.blueCheck,
                        ),
                      ),
                    ],
                  ),
                  if (joined) ...[
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: _MC.green.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                            color: _MC.comicBlack, width: 2.5),
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 26, height: 26,
                            decoration: const BoxDecoration(
                              shape: BoxShape.circle,
                              color: _MC.green,
                            ),
                            child: const Icon(Icons.check_rounded,
                                color: _MC.white, size: 14),
                          ),
                          const SizedBox(width: 10),
                          const Expanded(
                            child: Text(
                              'Akun sender sudah join group ini ✓',
                              style: TextStyle(
                                color: _MC.green,
                                fontSize: 11.5,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatBox({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _MC.comicBlack, width: 2.5),
        boxShadow: const [
          BoxShadow(
              color: _MC.comicBlack, offset: Offset(3, 3), blurRadius: 0),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: color, size: 14),
              const SizedBox(width: 6),
              Text(
                label,
                style: TextStyle(
                  color: color,
                  fontSize: 9.5,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 0.8,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: _MC.textDark,
              fontSize: 15,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }

  String _formatDate(String iso) {
    try {
      final d = DateTime.parse(iso);
      return '${d.day}/${d.month}/${d.year}';
    } catch (_) {
      return '-';
    }
  }

  String? _resolveId(Map<String, dynamic> item) {
    if (_targetMode == 'group') {
      return (item['id_ban'] ?? item['bug_id'] ?? '').toString();
    }
    return (item['id_bug'] ?? item['bug_id'] ?? '').toString();
  }

  String _resolveName(Map<String, dynamic> item) {
    if (_targetMode == 'group') {
      return (item['ban_name'] ?? item['bug_name'] ?? 'BAN').toString();
    }
    return (item['bug_name'] ?? 'BUG').toString();
  }

  List<Map<String, dynamic>> _itemsForMode() {
    if (_targetMode == 'group') {
      final filtered = widget.listBug.where((b) {
        if (b['id_ban'] != null || b['ban_name'] != null) return true;
        final n = (b['bug_name'] ?? '').toString().toLowerCase();
        final id = (b['bug_id'] ?? '').toString().toLowerCase();
        return n.contains('ban') || id.contains('ban') || n.contains('kudet');
      }).toList();
      return filtered.isEmpty ? widget.listBug : filtered;
    }
    final filtered = widget.listBug.where((b) {
      if (b['id_bug'] != null || b['bug_name'] != null) {
        if (b['id_ban'] != null) return false;
        final n = (b['bug_name'] ?? '').toString().toLowerCase();
        if (n.contains('ban gb') || n.contains('ban-group')) return false;
        return true;
      }
      final n = (b['bug_name'] ?? '').toString().toLowerCase();
      return !n.contains('ban gb') && !n.contains('kudet');
    }).toList();
    return filtered.isEmpty ? widget.listBug : filtered;
  }

  Future<void> _fetchSenderStats() async {
    if (_loadingSender) return;
    setState(() => _loadingSender = true);
    try {
      final response = await http
          .get(Uri.parse("$baseUrl/getSenderStats?key=${widget.sessionKey}"))
          .timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true && mounted) {
          setState(() {
            _privateSenderCount = data['private'] ?? 0;
            _globalSenderCount = data['global'] ?? 0;
          });
        }
      }
    } catch (_) {}
    if (mounted) setState(() => _loadingSender = false);
  }

  Future<void> _loadActiveSenders() async {
    setState(() => _isLoadingSenders = true);
    try {
      final mode = _selectedSenderMode == 'global'
          ? 'getActiveSenders'
          : 'mySender';
      final url = mode == 'getActiveSenders'
          ? '$baseUrl/getActiveSenders?key=${widget.sessionKey}'
          : '$baseUrl/mySender?key=${widget.sessionKey}';
      final res = await http
          .get(Uri.parse(url))
          .timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);

      if (data['valid'] == true && mounted) {
        if (mode == 'getActiveSenders') {
          _activeSenders = List<String>.from(data['senders'] ?? []);
        } else {
          final conns = data['connections'] ?? [];
          _activeSenders = conns
              .map<String>((c) => (c['sessionName'] ?? '').toString())
              .where((s) => s.isNotEmpty)
              .toList();
        }
        if (_activeSenders.isNotEmpty) {
          if (_selectedSenderNumber == null ||
              !_activeSenders.contains(_selectedSenderNumber)) {
            _selectedSenderNumber = _activeSenders.first;
          }
        }
      } else if (mounted) {
        _activeSenders = [];
        _selectedSenderNumber = null;
      }
    } catch (_) {
      if (mounted) {
        _activeSenders = [];
        _selectedSenderNumber = null;
      }
    }
    if (mounted) setState(() => _isLoadingSenders = false);
  }

  Future<bool> _checkTarget(String target) async {
    try {
      final encoded = Uri.encodeComponent(target);
      final res = await http
          .get(Uri.parse('$baseUrl/checkBan?nomor=$encoded'))
          .timeout(const Duration(seconds: 20));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        return data['success'] == true || data['registered'] == true;
      }
    } catch (_) {}
    return true;
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();

    if (_targetMode == 'contact') {
      if (formatPhoneNumber(rawInput) == null) {
        _showAlert("❌ Nomor Tidak Valid",
            "Gunakan format internasional.\nContoh: +62812xxxxxxxx");
        return;
      }
    } else {
      if (rawInput.isEmpty) {
        _showAlert("❌ Input Kosong", "Masukkan link atau ID group.");
        return;
      }
    }

    // ═══ CEK KUOTA GLOBAL ═══
    if (_selectedSenderMode == 'global') {
      if (_globalQuotaEmpty) {
        _showAlert(
          "❌ Kuota Global Habis",
          "Kuota global sender Anda sudah habis.\n"
              "Kuota: $_globalQuotaUsed / $_globalQuotaMax\n\n"
              "Hubungi admin untuk reset kuota atau upgrade role.",
        );
        return;
      }
    }

    if (_selectedItemId == null || _selectedItemId!.isEmpty) {
      _showAlert("❌ Belum Dipilih",
          _targetMode == 'group'
              ? "Pilih salah satu BAN untuk dikirim."
              : "Pilih salah satu BUG untuk dikirim.");
      return;
    }

    if (_selectedSenderMode == 'private' && _privateSenderCount == 0) {
      _showAlert("❌ Sender Pribadi Kosong",
          "Hubungkan WhatsApp kamu di menu Manage Sender dulu.");
      return;
    }
    if (_selectedSenderMode == 'global' && _globalSenderCount == 0) {
      _showAlert("❌ Sender Global Kosong",
          "Belum ada sender global yang tersedia.");
      return;
    }

    if (_activeSenders.isEmpty &&
        _privateSenderCount > 0 &&
        _selectedSenderMode == 'private') {
      await _loadActiveSenders();
    }

    await _runProcessing(rawInput);
  }

  Future<void> _runProcessing(String target) async {
    setState(() {
      _showProcessing = true;
      _processingStep = 0;
      _processingStatus = 'checking';
      _processingProgress = 0.0;
      _processingMessage = _targetMode == 'group'
          ? 'Mengecek Group target...'
          : 'Mengecek Nomor target...';
    });

    for (int i = 0; i <= 50; i += 5) {
      if (!mounted || !_showProcessing) return;
      await Future.delayed(const Duration(milliseconds: 60));
      if (mounted) setState(() => _processingProgress = i / 100);
    }

    final checkOk = await _checkTarget(target);

    if (!checkOk) {
      if (mounted) {
        setState(() {
          _processingStatus = 'failed';
          _processingMessage = _targetMode == 'group'
              ? '❌ Group tidak ditemukan / invalid'
              : '❌ Nomor tidak terdaftar di WhatsApp';
        });
      }
      await Future.delayed(const Duration(seconds: 3));
      if (mounted) setState(() => _showProcessing = false);
      return;
    }

    if (mounted) {
      setState(() {
        _processingStep = 1;
        _processingMessage = _targetMode == 'group'
            ? '✓ Group valid, mengirim BAN...'
            : '✓ Nomor valid, mengirim BUG...';
        _processingProgress = 0.55;
      });
    }

    for (int i = 55; i <= 90; i += 5) {
      if (!mounted || !_showProcessing) return;
      await Future.delayed(const Duration(milliseconds: 50));
      if (mounted) setState(() => _processingProgress = i / 100);
    }

    // ═══ DELAY 5 DETIK SEBELUM BUG TERKIRIM ═══
    if (mounted) {
      setState(() {
        _processingMessage = '⏳ Menunggu 5 detik sebelum kirim...';
      });
    }
    for (int i = 0; i < 5; i++) {
      if (!mounted || !_showProcessing) return;
      await Future.delayed(const Duration(seconds: 1));
      if (mounted) {
        setState(() {
          _processingMessage =
              '⏳ Mengirim dalam ${5 - i - 1} detik...';
        });
      }
    }

    if (!mounted || !_showProcessing) return;

    if (mounted) {
      setState(() {
        _processingMessage = '🚀 Mengirim bug...';
        _processingProgress = 0.95;
      });
    }

    bool sended = false;
    String resultMsg = '';
    try {
      final encoded = Uri.encodeComponent(target);
      final senderParam = _selectedSenderMode == 'global'
          ? '&senderMode=global'
          : '&sender=private';
      final senderNum = _selectedSenderNumber != null
          ? '&senderNumber=${Uri.encodeComponent(_selectedSenderNumber!)}'
          : '';
      final url = '$baseUrl/sendBug'
          '?key=${widget.sessionKey}'
          '&target=$encoded'
          '&bug=$_selectedItemId'
          '$senderParam$senderNum';
      final res =
          await http.get(Uri.parse(url)).timeout(const Duration(seconds: 25));
      final data = jsonDecode(res.body);

      if (data['valid'] == false) {
        resultMsg = 'Session key tidak valid';
      } else if (data['cooldown'] == true) {
        resultMsg = 'Cooldown aktif! Tunggu ${data['wait'] ?? 0} detik.';
      } else if (data['sended'] == true) {
        sended = true;
        resultMsg = 'Berhasil terkirim!';
      } else {
        resultMsg = 'Server tidak merespon';
      }
    } on TimeoutException {
      resultMsg = 'Request timeout';
    } catch (e) {
      resultMsg = 'Koneksi error';
    }

    // ═══ KURANGI KUOTA GLOBAL JIKA BERHASIL ═══
    if (sended && _selectedSenderMode == 'global') {
      await _consumeGlobalQuota();
    }

    if (mounted) {
      setState(() {
        _processingProgress = 1.0;
        _processingStep = 2;
        _processingStatus = sended ? 'success' : 'failed';
        _processingMessage = sended
            ? '✅ ${_targetMode == 'group' ? 'BAN' : 'BUG'} berhasil terkirim ke $target'
            : '❌ Gagal kirim: $resultMsg';
      });
    }

    if (sended) {
      targetController.clear();
      final extraInfo = _selectedSenderMode == 'global'
          ? ' [GLOBAL: $_globalQuotaLeft/$_globalQuotaMax]'
          : ' [PRIVATE]';
      _setResponse('success',
          'Berhasil kirim ke $target [${widget.role.toUpperCase()}]$extraInfo');
    } else {
      _setResponse('error', resultMsg);
    }

    await Future.delayed(const Duration(seconds: 3));
    if (mounted) setState(() => _showProcessing = false);
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  void _setResponse(String type, String msg) {
    if (!mounted) return;
    setState(() => _responseMessage = '$type|$msg');
    _resultCtrl.forward(from: 0);
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: _MC.redSoft,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: _MC.comicBlack, width: 3.5),
            boxShadow: const [
              BoxShadow(
                  color: _MC.comicBlack,
                  offset: Offset(6, 8),
                  blurRadius: 0),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 60, height: 60,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _MC.red,
                  border: Border.all(color: _MC.comicBlack, width: 3),
                ),
                child: const Icon(Icons.warning_rounded,
                    color: _MC.white, size: 32),
              ),
              const SizedBox(height: 14),
              Text(title,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      color: _MC.textDark,
                      fontWeight: FontWeight.w900,
                      fontSize: 16)),
              const SizedBox(height: 8),
              Text(msg,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      color: _MC.textGrey, fontSize: 13, height: 1.4)),
              const SizedBox(height: 20),
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 32, vertical: 12),
                  decoration: BoxDecoration(
                    color: _MC.red,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: _MC.comicBlack, width: 3),
                    boxShadow: const [
                      BoxShadow(
                          color: _MC.comicBlack,
                          offset: Offset(3, 4),
                          blurRadius: 0),
                    ],
                  ),
                  child: const Text('OK',
                      style: TextStyle(
                          color: _MC.white,
                          fontWeight: FontWeight.w900,
                          fontSize: 14,
                          letterSpacing: 1.5)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _card3D({
    required Widget child,
    EdgeInsets padding = const EdgeInsets.all(16),
    Color bg = _MC.redSoft,
    Color borderColor = _MC.comicBlack,
    double radius = 20,
  }) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: borderColor, width: 3.5),
        boxShadow: const [
          BoxShadow(
            color: _MC.comicBlack,
            offset: Offset(6, 6),
            blurRadius: 0,
          ),
        ],
      ),
      child: child,
    );
  }

  // ═══ HEADER BANNER X SPYDER BERGELANTUNGAN ═══
  Widget _buildXSpyderBanner() {
    return AnimatedBuilder(
      animation: _bannerController,
      builder: (_, __) {
        return Transform.rotate(
          angle: _bannerSwing.value,
          alignment: Alignment.topCenter,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 10),
            decoration: BoxDecoration(
              color: _MC.red,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _MC.comicBlack, width: 3.5),
              boxShadow: const [
                BoxShadow(
                  color: _MC.comicBlack,
                  offset: Offset(4, 5),
                  blurRadius: 0,
                ),
              ],
            ),
            child: const Text(
              'X SPYDER',
              style: TextStyle(
                color: _MC.white,
                fontSize: 20,
                fontWeight: FontWeight.w900,
                letterSpacing: 4,
                fontFamily: 'Astral',
                shadows: [
                  Shadow(
                    color: _MC.comicBlack,
                    offset: Offset(2, 2),
                    blurRadius: 0,
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ═══ PAPAN TEKS "BUG MENU" DI ATAS KANAN ═══
  Widget _buildBugMenuBadge() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
      decoration: BoxDecoration(
        color: _MC.red,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _MC.comicBlack, width: 3),
        boxShadow: const [
          BoxShadow(
            color: _MC.comicBlack,
            offset: Offset(3, 4),
            blurRadius: 0,
          ),
        ],
      ),
      child: const Text(
        'BUG MENU',
        style: TextStyle(
          color: _MC.white,
          fontSize: 12,
          fontWeight: FontWeight.w900,
          letterSpacing: 1.8,
          fontFamily: 'Astral',
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Positioned.fill(
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: _MC.comicBlack, width: 4),
              boxShadow: const [
                BoxShadow(
                  color: _MC.comicBlack,
                  offset: Offset(6, 8),
                  blurRadius: 0,
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(21),
              child: Stack(
                fit: StackFit.expand,
                children: [
                  Image.asset(
                    'assets/images/tools.png',
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(
                      color: _MC.redSoft,
                      child: const Center(
                        child: Icon(Icons.build_rounded,
                            color: _MC.white, size: 60),
                      ),
                    ),
                  ),
                  Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          _MC.redDeep.withOpacity(0.85),
                          _MC.red.withOpacity(0.65),
                          _MC.redDark.withOpacity(0.9),
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 20),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              _buildProfileWithRing(),
              const SizedBox(width: 14),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'X-SPYDER CORE',
                      style: TextStyle(
                        color: _MC.white,
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 2,
                        fontFamily: 'Astral',
                        shadows: [
                          Shadow(
                            color: _MC.comicBlack,
                            offset: Offset(3, 3),
                            blurRadius: 0,
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 6),
                    Text(
                      'X-SPYDER SYSTEM • FAST & FLUID',
                      style: TextStyle(
                        color: Color(0xFFFFC0C0),
                        fontSize: 10,
                        fontFamily: 'Astral',
                        letterSpacing: 0.6,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildProfileWithRing() {
    final roleColor = _roleColor(widget.role);
    final level = _roleRingLevel(widget.role);
    final premium = _isPremiumRole(widget.role);

    return SizedBox(
      width: 86, height: 86,
      child: Stack(
        alignment: Alignment.center,
        children: [
          AnimatedBuilder(
            animation: _ringController,
            builder: (_, __) => Transform.rotate(
              angle: _ringController.value * 2 * math.pi,
              child: CustomPaint(
                size: const Size(86, 86),
                painter: _RoleRingPainter(
                  color: roleColor,
                  level: level,
                  premium: premium,
                ),
              ),
            ),
          ),
          Container(
            width: 58, height: 58,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _MC.white,
              border: Border.all(color: _MC.comicBlack, width: 3.5),
              boxShadow: const [
                BoxShadow(
                  color: _MC.comicBlack,
                  offset: Offset(3, 3),
                  blurRadius: 0,
                ),
              ],
            ),
            child: ClipOval(
              child: Padding(
                padding: const EdgeInsets.all(4),
                child: Image.asset(
                  'assets/images/bug.png',
                  fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) => Container(
                    color: _MC.red,
                    child: const Icon(
                      Icons.bug_report_rounded,
                      color: _MC.white,
                      size: 26,
                    ),
                  ),
                ),
              ),
            ),
          ),
          Positioned(
            right: 2, bottom: 4,
            child: Container(
              width: 22, height: 22,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: roleColor,
                border: Border.all(color: _MC.comicBlack, width: 2.5),
              ),
              child: Center(
                child: Text(
                  widget.username.isNotEmpty
                      ? widget.username.substring(0, 1).toUpperCase()
                      : '?',
                  style: const TextStyle(
                    color: _MC.white,
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ),
          ),
          if (premium)
            Positioned(
              right: 2, top: 4,
              child: Container(
                width: 20, height: 20,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _MC.blueCheck,
                  border: Border.all(color: _MC.comicBlack, width: 2.5),
                ),
                child: const Icon(Icons.check_rounded,
                    color: _MC.white, size: 12),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildModeToggle() {
    return _card3D(
      padding: const EdgeInsets.all(6),
      radius: 18,
      child: Row(
        children: [
          _buildToggleBtn('CONTACT BUG', 'contact', Icons.phone_android_rounded),
          const SizedBox(width: 6),
          _buildToggleBtn('GROUP BAN', 'group', Icons.group_rounded),
        ],
      ),
    );
  }

  Widget _buildToggleBtn(String label, String value, IconData icon) {
    final active = _targetMode == value;
    return Expanded(
      child: GestureDetector(
        onTap: () {
          if (active) return;
          setState(() {
            _targetMode = value;
            targetController.clear();
            _responseMessage = null;
            _groupInfo = null;
            _groupError = null;
            _showSavedNumbers = false;
            _currentItemPage = 0;
            final list = _itemsForMode();
            _selectedItemId = list.isNotEmpty ? _resolveId(list[0]) : null;
            if (_itemPageController.hasClients) {
              _itemPageController.jumpToPage(0);
            }
          });
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 220),
          padding: const EdgeInsets.symmetric(vertical: 13),
          decoration: BoxDecoration(
            color: active ? _MC.red : _MC.buttonDark,
            borderRadius: BorderRadius.circular(13),
            border: Border.all(color: _MC.comicBlack, width: 3),
            boxShadow: const [
              BoxShadow(
                color: _MC.comicBlack,
                offset: Offset(3, 3),
                blurRadius: 0,
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: _MC.white, size: 18),
              const SizedBox(width: 8),
              Text(
                label,
                style: const TextStyle(
                  color: _MC.white,
                  fontWeight: FontWeight.w900,
                  fontSize: 12,
                  letterSpacing: 1.1,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTargetInput() {
    final isContact = _targetMode == 'contact';
    return Container(
      decoration: BoxDecoration(
        color: _MC.cream,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _MC.comicBlack, width: 3),
        boxShadow: const [
          BoxShadow(
            color: _MC.comicBlack,
            offset: Offset(4, 4),
            blurRadius: 0,
          ),
        ],
      ),
      child: TextField(
        controller: targetController,
        style: const TextStyle(
          color: _MC.textDark,
          fontSize: 15,
          fontWeight: FontWeight.w700,
        ),
        cursorColor: _MC.brightRed,
        keyboardType: isContact ? TextInputType.phone : TextInputType.text,
        decoration: InputDecoration(
          hintText: isContact
              ? 'Contoh: +62812xxxxxxxx'
              : 'Paste link group atau ID grup',
          hintStyle: const TextStyle(
            color: _MC.textLight,
            fontSize: 13,
          ),
          prefixIcon: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: Icon(
              isContact ? Icons.phone_android_rounded : Icons.link_rounded,
              color: _MC.brightRed,
              size: 22,
            ),
          ),
          prefixIconConstraints:
              const BoxConstraints(minWidth: 50, minHeight: 50),
          suffixIcon:
              _targetMode == 'group' && targetController.text.isNotEmpty
                  ? Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      child: _loadingGroupInfo
                          ? const SizedBox(
                              width: 20, height: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: _MC.brightRed,
                              ),
                            )
                          : _groupInfo != null
                              ? Container(
                                  width: 24, height: 24,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: _MC.green,
                                    border: Border.all(
                                        color: _MC.comicBlack,
                                        width: 2),
                                  ),
                                  child: const Icon(Icons.check_rounded,
                                      color: _MC.white, size: 14),
                                )
                              : null,
                    )
                  : null,
          border: InputBorder.none,
          contentPadding:
              const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
        ),
      ),
    );
  }

  Widget _buildItemCarousel() {
    final items = _itemsForMode();
    final isGroup = _targetMode == 'group';
    final label = isGroup ? 'PILIH BAN' : 'PILIH BUG';

    if (items.isEmpty) {
      return _card3D(
        padding: const EdgeInsets.symmetric(vertical: 30),
        child: Center(
          child: Column(
            children: [
              Icon(Icons.inbox_rounded, color: _MC.textLight, size: 50),
              const SizedBox(height: 12),
              Text(
                isGroup ? 'Belum Ada BAN' : 'Belum Ada BUG',
                style: const TextStyle(
                  color: _MC.textGrey,
                  fontWeight: FontWeight.w700,
                  fontSize: 14,
                ),
              ),
            ],
          ),
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 38, height: 38,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _MC.buttonDark,
                border: Border.all(color: _MC.comicBlack, width: 3),
              ),
              child: Icon(
                isGroup ? Icons.gpp_maybe_rounded : Icons.bug_report_rounded,
                color: _MC.white,
                size: 20,
              ),
            ),
            const SizedBox(width: 10),
            Text(
              label,
              style: const TextStyle(
                color: _MC.textDark,
                fontWeight: FontWeight.w900,
                fontSize: 15,
                letterSpacing: 1.5,
              ),
            ),
            const Spacer(),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
              decoration: BoxDecoration(
                color: _MC.buttonDark,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _MC.comicBlack, width: 2.5),
              ),
              child: Text(
                '${_currentItemPage + 1}/${items.length}',
                style: const TextStyle(
                  color: _MC.white,
                  fontWeight: FontWeight.w900,
                  fontSize: 12,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),
        SizedBox(
          height: 165,
          child: PageView.builder(
            controller: _itemPageController,
            itemCount: items.length,
            onPageChanged: (i) {
              setState(() {
                _currentItemPage = i;
                _selectedItemId = _resolveId(items[i]);
              });
            },
            itemBuilder: (_, index) {
              final item = items[index];
              final id = _resolveId(item);
              final name = _resolveName(item);
              final selected = _selectedItemId == id;

              return AnimatedBuilder(
                animation: _itemPageController,
                builder: (_, child) {
                  double scale = 1.0;
                  if (_itemPageController.position.haveDimensions) {
                    final diff = (_itemPageController.page! - index).abs();
                    scale = (1 - diff * 0.06).clamp(0.92, 1.0);
                  }
                  return Transform.scale(scale: scale, child: child);
                },
                child: Padding(
                  padding: const EdgeInsets.only(right: 12),
                  child: GestureDetector(
                    onTap: () => setState(() => _selectedItemId = id),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 250),
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: selected ? _MC.red : _MC.buttonDark,
                        borderRadius: BorderRadius.circular(18),
                        border:
                            Border.all(color: _MC.comicBlack, width: 3.5),
                        boxShadow: const [
                          BoxShadow(
                            color: _MC.comicBlack,
                            offset: Offset(4, 5),
                            blurRadius: 0,
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment:
                                MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                width: 42, height: 42,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: selected
                                      ? _MC.white
                                      : _MC.red,
                                  border: Border.all(
                                      color: _MC.comicBlack, width: 3),
                                ),
                                child: Icon(
                                  isGroup
                                      ? Icons.gpp_maybe_rounded
                                      : Icons.bug_report_rounded,
                                  color: selected
                                      ? _MC.redDark
                                      : _MC.white,
                                  size: 22,
                                ),
                              ),
                              if (selected)
                                Container(
                                  width: 26, height: 26,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: _MC.white,
                                    border: Border.all(
                                        color: _MC.comicBlack,
                                        width: 2.5),
                                  ),
                                  child: const Icon(
                                    Icons.check_rounded,
                                    color: _MC.redDark,
                                    size: 16,
                                  ),
                                ),
                            ],
                          ),
                          const Spacer(),
                          Text(
                            name.toUpperCase(),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: _MC.white,
                              fontWeight: FontWeight.w900,
                              fontSize: 14,
                              letterSpacing: 0.8,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: selected
                                  ? _MC.white.withOpacity(0.3)
                                  : _MC.redDark,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                  color: _MC.comicBlack, width: 2),
                            ),
                            child: Text(
                              id ?? '-',
                              style: const TextStyle(
                                color: _MC.white,
                                fontWeight: FontWeight.w700,
                                fontSize: 11,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(items.length, (i) {
            final active = i == _currentItemPage;
            return AnimatedContainer(
              duration: const Duration(milliseconds: 220),
              margin: const EdgeInsets.symmetric(horizontal: 3),
              width: active ? 26 : 8,
              height: 6,
              decoration: BoxDecoration(
                color: active ? _MC.brightRed : _MC.redDark,
                borderRadius: BorderRadius.circular(4),
                border: Border.all(color: _MC.comicBlack, width: 1.5),
              ),
            );
          }),
        ),
      ],
    );
  }

  Widget _buildSenderPanel() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 38, height: 38,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _MC.buttonDark,
                border: Border.all(color: _MC.comicBlack, width: 3),
              ),
              child: const Icon(Icons.swap_horiz_rounded,
                  color: _MC.white, size: 20),
            ),
            const SizedBox(width: 10),
            const Text(
              'PILIH SENDER',
              style: TextStyle(
                color: _MC.textDark,
                fontWeight: FontWeight.w900,
                fontSize: 15,
                letterSpacing: 1.5,
              ),
            ),
            const Spacer(),
            GestureDetector(
              onTap: () {
                _fetchSenderStats();
                _loadActiveSenders();
              },
              child: Container(
                width: 32, height: 32,
                decoration: BoxDecoration(
                  color: _MC.buttonDark,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: _MC.comicBlack, width: 2.5),
                ),
                child: (_isLoadingSenders || _loadingSender)
                    ? const Padding(
                        padding: EdgeInsets.all(6),
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: _MC.white,
                        ),
                      )
                    : const Icon(Icons.refresh_rounded,
                        color: _MC.white, size: 16),
              ),
            ),
            const SizedBox(width: 8),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: _MC.buttonDark,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: _MC.comicBlack, width: 2.5),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 8, height: 8,
                    decoration: BoxDecoration(
                      color: (_privateSenderCount + _globalSenderCount) > 0
                          ? _MC.greenLite
                          : _MC.brightRed,
                      shape: BoxShape.circle,
                      border: Border.all(
                          color: _MC.comicBlack, width: 1.5),
                    ),
                  ),
                  const SizedBox(width: 6),
                  Text(
                    '${_privateSenderCount + _globalSenderCount} online',
                    style: const TextStyle(
                      color: _MC.white,
                      fontWeight: FontWeight.w800,
                      fontSize: 11.5,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: _buildSenderModeCard(
                'Pribadi',
                'private',
                Icons.person_rounded,
                _privateSenderCount,
                _MC.green,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _buildSenderModeCard(
                'Global',
                'global',
                Icons.public_rounded,
                _globalSenderCount,
                _MC.red,
                locked: false,
              ),
            ),
          ],
        ),
        if (_activeSenders.isNotEmpty) ...[
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: _MC.buttonDark,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _MC.comicBlack, width: 3),
              boxShadow: const [
                BoxShadow(
                    color: _MC.comicBlack,
                    offset: Offset(4, 4),
                    blurRadius: 0),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.format_list_bulleted_rounded,
                        color: _MC.white, size: 15),
                    const SizedBox(width: 8),
                    Text(
                      'Nomor sender aktif (${_activeSenders.length})',
                      style: const TextStyle(
                        color: _MC.white,
                        fontSize: 11.5,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                ..._activeSenders.map((s) {
                  final selected = _selectedSenderNumber == s;
                  return GestureDetector(
                    onTap: () =>
                        setState(() => _selectedSenderNumber = s),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 180),
                      margin: const EdgeInsets.only(bottom: 6),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 8),
                      decoration: BoxDecoration(
                        color: selected ? _MC.red : _MC.redDeep,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                            color: _MC.comicBlack, width: 2),
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 8, height: 8,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: selected
                                  ? _MC.white
                                  : _MC.greenLite,
                              border: Border.all(
                                  color: _MC.comicBlack, width: 1.5),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              s,
                              style: const TextStyle(
                                color: _MC.white,
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                          if (selected)
                            const Icon(Icons.check_rounded,
                                color: _MC.white, size: 16),
                        ],
                      ),
                    ),
                  );
                }),
              ],
            ),
          ),
        ] else if (_selectedSenderMode == 'private' &&
            _privateSenderCount > 0) ...[
          const SizedBox(height: 12),
          const Row(
            children: [
              Icon(Icons.info_outline_rounded,
                  color: _MC.textGrey, size: 14),
              SizedBox(width: 8),
              Text(
                'Nomor sender private belum tersinkron',
                style: TextStyle(
                  color: _MC.textGrey,
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ],
      ],
    );
  }

  // ═══ SENDER MODE CARD — DENGAN KUOTA GLOBAL ═══
  Widget _buildSenderModeCard(
    String label,
    String value,
    IconData icon,
    int count,
    Color accent, {
    bool locked = false,
  }) {
    final active = _selectedSenderMode == value;
    final isGlobal = value == 'global';
    final quotaEmpty = isGlobal && _globalQuotaEmpty;

    return GestureDetector(
      onTap: () {
        if (locked) {
          _showAlert(
            '🔒 Akses Terbatas',
            'Sender Global hanya bisa digunakan oleh role tertentu.',
          );
          return;
        }
        if (quotaEmpty) {
          _showAlert(
            '❌ Kuota Habis',
            'Kuota global sender Anda sudah habis.\n'
                'Kuota: $_globalQuotaUsed / $_globalQuotaMax',
          );
          return;
        }
        setState(() {
          _selectedSenderMode = value;
          _selectedSenderNumber = null;
        });
        _loadActiveSenders();
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        height: 110,
        decoration: BoxDecoration(
          color: active ? _MC.red : _MC.buttonDark,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _MC.comicBlack, width: 3.5),
          boxShadow: const [
            BoxShadow(
              color: _MC.comicBlack,
              offset: Offset(4, 4),
              blurRadius: 0,
            ),
          ],
        ),
        child: Stack(
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, color: _MC.white, size: 26),
                const SizedBox(height: 5),
                Text(
                  label,
                  style: const TextStyle(
                    color: _MC.white,
                    fontWeight: FontWeight.w900,
                    fontSize: 13,
                    letterSpacing: 1,
                    fontStyle: FontStyle.normal,
                  ),
                ),
                const SizedBox(height: 3),
                if (isGlobal)
                  Text(
                    quotaEmpty
                        ? '✕ Kuota Habis'
                        : '$_globalQuotaLeft / $_globalQuotaMax',
                    style: TextStyle(
                      color: quotaEmpty
                          ? _MC.brightRed
                          : _MC.greenLite,
                      fontWeight: FontWeight.w900,
                      fontSize: 11,
                      fontStyle: FontStyle.normal,
                    ),
                  )
                else
                  Text(
                    count == 0 ? '✕ Kosong' : '$count sender',
                    style: TextStyle(
                      color: count == 0 ? _MC.textGrey : _MC.greenLite,
                      fontWeight: FontWeight.w700,
                      fontSize: 10.5,
                      fontStyle: FontStyle.normal,
                    ),
                  ),
              ],
            ),
            if (active)
              Positioned(
                top: 6, right: 6,
                child: Container(
                  width: 20, height: 20,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _MC.white,
                    border: Border.all(
                        color: _MC.comicBlack, width: 2),
                  ),
                  child: const Icon(Icons.check_rounded,
                      color: _MC.redDark, size: 12),
                ),
              ),
            if (locked)
              Positioned(
                top: 6, right: 6,
                child: Container(
                  width: 20, height: 20,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _MC.amber,
                    border: Border.all(
                        color: _MC.comicBlack, width: 2),
                  ),
                  child: const Icon(Icons.lock_rounded,
                      color: _MC.white, size: 11),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildSendButton() {
    final isGroup = _targetMode == 'group';
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (_, __) {
        return GestureDetector(
          onTap: _isSending ? null : _sendBug,
          child: Container(
            height: 62,
            decoration: BoxDecoration(
              color: _MC.buttonYellow,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: _MC.comicBlack, width: 4),
              boxShadow: [
                BoxShadow(
                  color: _MC.comicBlack,
                  offset: Offset(5, 6 + _pulseController.value * 2),
                  blurRadius: 0,
                ),
              ],
            ),
            child: Center(
              child: _isSending
                  ? const SizedBox(
                      width: 26, height: 26,
                      child: CircularProgressIndicator(
                        color: _MC.comicBlack,
                        strokeWidth: 3,
                      ),
                    )
                  : Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          isGroup
                              ? Icons.gpp_maybe_rounded
                              : Icons.bug_report_rounded,
                          color: _MC.comicBlack,
                          size: 22,
                        ),
                        const SizedBox(width: 10),
                        Text(
                          isGroup ? 'KIRIM BAN' : 'KIRIM BUG',
                          style: const TextStyle(
                            color: _MC.comicBlack,
                            fontWeight: FontWeight.w900,
                            fontSize: 16,
                            letterSpacing: 2.5,
                          ),
                        ),
                      ],
                    ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildResponse() {
    if (_responseMessage == null) return const SizedBox.shrink();
    final parts = _responseMessage!.split('|');
    final type = parts[0];
    final msg = parts.length > 1 ? parts[1] : '';
    Color color;
    IconData icon;
    switch (type) {
      case 'success':
        color = _MC.green;
        icon = Icons.check_circle_rounded;
        break;
      case 'warning':
        color = _MC.amber;
        icon = Icons.warning_rounded;
        break;
      default:
        color = _MC.red;
        icon = Icons.error_rounded;
    }
    return FadeTransition(
      opacity: _resultFade,
      child: SlideTransition(
        position: _resultSlide,
        child: Container(
          margin: const EdgeInsets.only(top: 14),
          padding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            color: _MC.buttonDark,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _MC.comicBlack, width: 3),
            boxShadow: const [
              BoxShadow(
                color: _MC.comicBlack,
                offset: Offset(4, 5),
                blurRadius: 0,
              ),
            ],
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, color: color, size: 22),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  msg,
                  style: const TextStyle(
                    color: _MC.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    height: 1.4,
                  ),
                ),
              ),
              GestureDetector(
                onTap: () {
                  setState(() => _responseMessage = null);
                  _resultCtrl.reset();
                },
                child: const Icon(Icons.close_rounded,
                    color: _MC.textGrey, size: 18),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildProcessingModal() {
    if (!_showProcessing) return const SizedBox.shrink();
    final status = _processingStatus;
    final Color accent;
    final IconData icon;
    if (status == 'checking') {
      accent = _MC.brightRed;
      icon = Icons.search_rounded;
    } else if (status == 'success') {
      accent = _MC.green;
      icon = Icons.check_circle_rounded;
    } else if (status == 'failed') {
      accent = _MC.red;
      icon = Icons.error_rounded;
    } else {
      accent = _MC.brightRed;
      icon = Icons.hourglass_top_rounded;
    }

    return Positioned.fill(
      child: Container(
        color: Colors.black.withOpacity(0.6),
        child: Center(
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 32),
            padding: const EdgeInsets.all(26),
            decoration: BoxDecoration(
              color: _MC.redSoft,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: _MC.comicBlack, width: 4),
              boxShadow: const [
                BoxShadow(
                  color: _MC.comicBlack,
                  offset: Offset(6, 8),
                  blurRadius: 0,
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Stack(
                  alignment: Alignment.center,
                  children: [
                    SizedBox(
                      width: 80, height: 80,
                      child: status == 'checking'
                          ? CircularProgressIndicator(
                              strokeWidth: 4,
                              value: _processingProgress,
                              color: accent,
                              backgroundColor: _MC.redLight,
                            )
                          : Container(
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: accent.withOpacity(0.2),
                                border: Border.all(
                                    color: _MC.comicBlack, width: 3),
                              ),
                            ),
                    ),
                    Container(
                      width: 56, height: 56,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _MC.buttonDark,
                        border:
                            Border.all(color: _MC.comicBlack, width: 3),
                      ),
                      child: Icon(icon, color: accent, size: 30),
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                const Text(
                  'PROCESSING',
                  style: TextStyle(
                    color: _MC.white,
                    fontWeight: FontWeight.w900,
                    fontSize: 15,
                    letterSpacing: 2,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  _processingMessage,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: accent,
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 16),
                ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: LinearProgressIndicator(
                    value: _processingProgress,
                    minHeight: 10,
                    backgroundColor: _MC.buttonDark,
                    valueColor: AlwaysStoppedAnimation<Color>(accent),
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  '${(_processingProgress * 100).toStringAsFixed(0)}%',
                  style: TextStyle(
                    color: accent,
                    fontWeight: FontWeight.w900,
                    fontSize: 13,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _smoothEntry(int index, Widget child) {
    final begin = 0.86 + (index * 0.018);
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: begin, end: 1.0),
      duration: Duration(milliseconds: 520 + (index * 55)),
      curve: Curves.easeOutCubic,
      builder: (context, value, _) {
        final opacity = ((value - begin) / (1.0 - begin)).clamp(0.0, 1.0);
        return Opacity(
          opacity: opacity,
          child: Transform.translate(
            offset: Offset(0, 22 * (1 - opacity)),
            child:
                Transform.scale(scale: 0.98 + (0.02 * opacity), child: child),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _MC.cream,
      extendBody: true,
      body: Stack(
        children: [
          // ═══ BACKGROUND IMAGE JPG ═══
          Positioned.fill(
            child: Image.asset(
              'assets/images/background.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(color: _MC.cream),
            ),
          ),
          AnimatedBuilder(
            animation: _pulseController,
            builder: (_, __) {
              final glow = 0.18 + (_pulseController.value * 0.08);
              return Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      _MC.redDeep.withOpacity(0.28),
                      const Color(0xFF0A0303).withOpacity(0.45),
                      _MC.redDark.withOpacity(0.22 + (glow * 0.35)),
                    ],
                  ),
                ),
              );
            },
          ),
          IgnorePointer(
            child: CustomPaint(
              size: Size.infinite,
              painter: _MCLARENGridPainter(_ringController),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                // ═══ TOP BAR: BACK + X SPYDER BANNER + REFRESH + BUG MENU ═══
                Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 8),
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      // X SPYDER BANNER (tengah, bergelantungan)
                      _buildXSpyderBanner(),

                      // Row: back (kiri), refresh & bug menu (kanan)
                      Row(
                        children: [
                          GestureDetector(
                            onTap: () => Navigator.maybePop(context),
                            child: Container(
                              width: 40, height: 40,
                              decoration: BoxDecoration(
                                color: _MC.buttonDark,
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                    color: _MC.comicBlack, width: 3),
                                boxShadow: const [
                                  BoxShadow(
                                    color: _MC.comicBlack,
                                    offset: Offset(3, 4),
                                    blurRadius: 0,
                                  ),
                                ],
                              ),
                              child: const Icon(
                                  Icons.arrow_back_ios_new_rounded,
                                  color: _MC.white, size: 18),
                            ),
                          ),
                          const Spacer(),
                          // ═══ PAPAN TEKS BUG MENU DI ATAS KANAN ═══
                          _buildBugMenuBadge(),
                          const SizedBox(width: 8),
                          GestureDetector(
                            onTap: () {
                              _fetchSenderStats();
                              _loadActiveSenders();
                              _initGlobalQuota();
                            },
                            child: Container(
                              width: 40, height: 40,
                              decoration: BoxDecoration(
                                color: _MC.buttonDark,
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                    color: _MC.comicBlack, width: 3),
                                boxShadow: const [
                                  BoxShadow(
                                    color: _MC.comicBlack,
                                    offset: Offset(3, 4),
                                    blurRadius: 0,
                                  ),
                                ],
                              ),
                              child: const Icon(Icons.refresh_rounded,
                                  color: _MC.white, size: 20),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 4),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        _smoothEntry(0, _buildHeader()),
                        const SizedBox(height: 18),
                        _smoothEntry(
                            1,
                            _card3D(
                              child: Column(
                                children: [
                                  _buildModeToggle(),
                                  const SizedBox(height: 16),
                                  _buildTargetInput(),
                                  _buildSaveNumberBar(),
                                  _buildSavedNumbersList(),
                                  _buildGroupInfoCard(),
                                ],
                              ),
                            )),
                        const SizedBox(height: 18),
                        _smoothEntry(
                            2, _card3D(child: _buildItemCarousel())),
                        const SizedBox(height: 18),
                        _smoothEntry(
                            3, _card3D(child: _buildSenderPanel())),
                        const SizedBox(height: 22),
                        _smoothEntry(4, _buildSendButton()),
                        _buildResponse(),
                        const SizedBox(height: 30),
                        Center(
                          child: Column(
                            children: [
                              Text(
                                'X-SPYDER SYSTEM',
                                style: TextStyle(
                                  color: _MC.redDark.withOpacity(0.9),
                                  fontWeight: FontWeight.w900,
                                  fontSize: 13,
                                  letterSpacing: 3,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                '© 2026 X-SPYDER • Built For Motion',
                                style: TextStyle(
                                  color: _MC.textGrey.withOpacity(0.7),
                                  fontSize: 10.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 20),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          _buildProcessingModal(),
        ],
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════
// ✦ BACKGROUND GRID / AMBIENT PARTICLES (DARK RED)
// ════════════════════════════════════════════════════════════
class _MCLARENGridPainter extends CustomPainter {
  final Animation<double> animation;
  _MCLARENGridPainter(this.animation) : super(repaint: animation);

  @override
  void paint(Canvas canvas, Size size) {
    final t = animation.value * math.pi * 2;
    final grid = Paint()
      ..color = const Color(0xFFFF3B3B).withOpacity(0.05)
      ..strokeWidth = 1;
    const step = 34.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
    final glow = Paint()
      ..color = const Color(0xFFD32F2F).withOpacity(0.10)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 48);
    canvas.drawCircle(
      Offset(size.width * 0.18 + math.sin(t) * 18, size.height * 0.22),
      110, glow,
    );
    canvas.drawCircle(
      Offset(size.width * 0.82, size.height * 0.72 + math.cos(t) * 20),
      130, glow,
    );
  }

  @override
  bool shouldRepaint(covariant _MCLARENGridPainter oldDelegate) => true;
}

// ════════════════════════════════════════════════════════════
// 🎨 GROUP BANNER PATTERN PAINTER
// ════════════════════════════════════════════════════════════
class _GroupBannerPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = _MC.white.withOpacity(0.08)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;

    for (double i = -size.height; i < size.width; i += 20) {
      canvas.drawLine(
        Offset(i, 0),
        Offset(i + size.height, size.height),
        paint,
      );
    }

    final circlePaint = Paint()
      ..color = _MC.white.withOpacity(0.06)
      ..style = PaintingStyle.fill;
    canvas.drawCircle(
        Offset(size.width * 0.85, size.height * 0.3), 40, circlePaint);
    canvas.drawCircle(
        Offset(size.width * 0.9, size.height * 0.7), 25, circlePaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ════════════════════════════════════════════════════════════
// 🎨 ROLE RING PAINTER — 8 LEVELS (COMIC OUTLINE)
// ════════════════════════════════════════════════════════════
class _RoleRingPainter extends CustomPainter {
  final Color color;
  final int level;
  final bool premium;

  _RoleRingPainter({
    required this.color,
    required this.level,
    required this.premium,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 3;

    final outlinePaint = Paint()
      ..color = _MC.comicBlack
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.5;
    canvas.drawCircle(center, radius + 2, outlinePaint);

    final glowPaint = Paint()
      ..color = color.withOpacity(0.3 + (level * 0.04))
      ..style = PaintingStyle.stroke
      ..strokeWidth = 5 + level.toDouble()
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8);
    canvas.drawCircle(center, radius, glowPaint);

    final mainPaint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.5 + (level * 0.3)
      ..strokeCap = StrokeCap.round;
    canvas.drawCircle(center, radius, mainPaint);

    if (level >= 2) {
      final innerPaint = Paint()
        ..color = color.withOpacity(0.6)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.4;
      canvas.drawCircle(center, radius - 5, innerPaint);
    }

    if (level >= 3) {
      final dotCount = 4 + (level - 3) * 2;
      final dotPaint = Paint()..color = color;
      final dotRadius = 1.8 + (level * 0.15);
      for (int i = 0; i < dotCount; i++) {
        final angle = (i / dotCount) * 2 * math.pi;
        final dx = center.dx + radius * math.cos(angle);
        final dy = center.dy + radius * math.sin(angle);
        canvas.drawCircle(Offset(dx, dy), dotRadius, dotPaint);
      }
    }

    if (level >= 4) {
      final dashPaint = Paint()
        ..color = color.withOpacity(0.9)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.2
        ..strokeCap = StrokeCap.round;
      final segments = 8 + (level - 4) * 2;
      const gap = 0.55;
      for (int i = 0; i < segments; i++) {
        final startAngle = (i / segments) * 2 * math.pi;
        final sweepAngle = (2 * math.pi / segments) - gap * 0.4;
        canvas.drawArc(
          Rect.fromCircle(center: center, radius: radius - 3),
          startAngle,
          sweepAngle,
          false,
          dashPaint,
        );
      }
    }

    if (level >= 5) {
      final tickPaint = Paint()
        ..color = color.withOpacity(0.95)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..strokeCap = StrokeCap.round;
      const tickCount = 12;
      for (int i = 0; i < tickCount; i++) {
        final angle = (i / tickCount) * 2 * math.pi;
        final outer = Offset(
          center.dx + (radius + 2) * math.cos(angle),
          center.dy + (radius + 2) * math.sin(angle),
        );
        final inner = Offset(
          center.dx + (radius - 2) * math.cos(angle),
          center.dy + (radius - 2) * math.sin(angle),
        );
        canvas.drawLine(outer, inner, tickPaint);
      }
    }

    if (level >= 6) {
      final outerRing = Paint()
        ..color = color.withOpacity(0.7)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5;
      canvas.drawCircle(center, radius + 3, outerRing);
    }

    if (level >= 7) {
      final crownPaint = Paint()..color = color;
      for (int i = -1; i <= 1; i++) {
        final angle = -math.pi / 2 + (i * 0.35);
        final dx = center.dx + (radius + 4) * math.cos(angle);
        final dy = center.dy + (radius + 4) * math.sin(angle);
        canvas.drawCircle(Offset(dx, dy), 3.5, crownPaint);
        canvas.drawCircle(
            Offset(dx, dy), 1.5, Paint()..color = _MC.white);
      }
    }

    if (level >= 8) {
      final coronaPaint = Paint()
        ..color = color.withOpacity(0.45)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 8
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12);
      canvas.drawCircle(center, radius + 2, coronaPaint);

      const starCount = 8;
      for (int i = 0; i < starCount; i++) {
        final angle = (i / starCount) * 2 * math.pi;
        final dx = center.dx + (radius + 6) * math.cos(angle);
        final dy = center.dy + (radius + 6) * math.sin(angle);
        final starPaint = Paint()
          ..color = _MC.white
          ..style = PaintingStyle.fill;
        _drawStar(canvas, Offset(dx, dy), 4, 2, starPaint);
      }
    }
  }

  void _drawStar(Canvas canvas, Offset center, double outer, double inner,
      Paint paint) {
    final path = Path();
    for (int i = 0; i < 8; i++) {
      final r = i.isEven ? outer : inner;
      final angle = (i / 8) * 2 * math.pi - math.pi / 2;
      final x = center.dx + r * math.cos(angle);
      final y = center.dy + r * math.sin(angle);
      i == 0 ? path.moveTo(x, y) : path.lineTo(x, y);
    }
    path.close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(_RoleRingPainter old) =>
      old.color != color || old.level != level || old.premium != premium;
}