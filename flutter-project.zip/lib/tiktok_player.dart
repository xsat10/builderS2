import 'dart:async';

import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

/// Full-screen TikTok WebView with a native Flutter chrome layer.
///
/// The page stays live inside the WebView; Flutter owns navigation,
/// refresh/loading state, error presentation, and accessibility chrome.
class TikTokPlayerPage extends StatefulWidget {
  final String initialUrl;

  const TikTokPlayerPage({
    super.key,
    this.initialUrl = 'https://www.tiktok.com/',
  });

  @override
  State<TikTokPlayerPage> createState() => _TikTokPlayerPageState();
}

class _TikTokPlayerPageState extends State<TikTokPlayerPage>
    with SingleTickerProviderStateMixin {
  late final WebViewController _controller;
  late final AnimationController _pulseController;

  int _progress = 0;
  bool _isLoading = true;
  bool _hasError = false;
  String? _errorMessage;
  Timer? _refreshDebounce;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    )..repeat(reverse: true);

    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF07030D))
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (value) {
            if (!mounted) return;
            setState(() => _progress = value.clamp(0, 100));
          },
          onPageStarted: (_) {
            if (!mounted) return;
            setState(() {
              _isLoading = true;
              _hasError = false;
              _errorMessage = null;
              _progress = 5;
            });
          },
          onPageFinished: (_) {
            if (!mounted) return;
            setState(() {
              _isLoading = false;
              _progress = 100;
            });
          },
          onWebResourceError: (error) {
            if (!error.isForMainFrame || !mounted) return;
            setState(() {
              _isLoading = false;
              _hasError = true;
              _errorMessage = error.description;
            });
          },
        ),
      )
      ..loadRequest(Uri.parse(widget.initialUrl));
  }

  @override
  void dispose() {
    _refreshDebounce?.cancel();
    _pulseController.dispose();
    super.dispose();
  }

  Future<void> _reload() async {
    _refreshDebounce?.cancel();
    _refreshDebounce = Timer(const Duration(milliseconds: 150), () {
      _controller.reload();
    });
  }

  Future<void> _goBack() async {
    if (await _controller.canGoBack()) {
      await _controller.goBack();
    } else if (mounted) {
      Navigator.of(context).maybePop();
    }
  }

  Future<void> _goForward() async {
    if (await _controller.canGoForward()) {
      await _controller.goForward();
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      backgroundColor: const Color(0xFF07030D),
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            _TopBar(
              isLoading: _isLoading,
              pulse: _pulseController,
              onBack: _goBack,
              onReload: _reload,
              onForward: _goForward,
            ),
            AnimatedContainer(
              duration: const Duration(milliseconds: 220),
              height: _isLoading ? 2 : 0,
              width: double.infinity,
              alignment: Alignment.centerLeft,
              child: FractionallySizedBox(
                widthFactor: _progress / 100,
                child: const DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Color(0xFF25F4EE), Color(0xFFFF0050)],
                    ),
                  ),
                ),
              ),
            ),
            Expanded(
              child: Stack(
                fit: StackFit.expand,
                children: [
                  WebViewWidget(controller: _controller),
                  if (_hasError) _ErrorOverlay(message: _errorMessage, onRetry: _reload),
                ],
              ),
            ),
            _BottomBar(
              onBack: _goBack,
              onForward: _goForward,
              onReload: _reload,
              theme: theme,
            ),
          ],
        ),
      ),
    );
  }
}

class _TopBar extends StatelessWidget {
  final bool isLoading;
  final Animation<double> pulse;
  final VoidCallback onBack;
  final VoidCallback onReload;
  final VoidCallback onForward;

  const _TopBar({
    required this.isLoading,
    required this.pulse,
    required this.onBack,
    required this.onReload,
    required this.onForward,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 68,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: const BoxDecoration(
        color: Color(0xFF0D0817),
        border: Border(bottom: BorderSide(color: Color(0x221FFFFFF))),
      ),
      child: Row(
        children: [
          _ChromeButton(icon: Icons.arrow_back_rounded, onTap: onBack),
          const SizedBox(width: 10),
          Expanded(
            child: Container(
              height: 46,
              padding: const EdgeInsets.symmetric(horizontal: 14),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                color: const Color(0xFF171022),
                border: Border.all(color: const Color(0x22FFFFFF)),
              ),
              child: Row(
                children: [
                  AnimatedBuilder(
                    animation: pulse,
                    builder: (_, __) => Transform.scale(
                      scale: 0.92 + pulse.value * 0.08,
                      child: const Icon(Icons.bolt_rounded,
                          color: Color(0xFF25F4EE), size: 19),
                    ),
                  ),
                  const SizedBox(width: 9),
                  const Expanded(
                    child: Text(
                      'TikTok LIVE WEB',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w800,
                        letterSpacing: .2,
                      ),
                    ),
                  ),
                  if (isLoading)
                    const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 10),
          _ChromeButton(icon: Icons.refresh_rounded, onTap: onReload),
          const SizedBox(width: 6),
          _ChromeButton(icon: Icons.arrow_forward_rounded, onTap: onForward),
        ],
      ),
    );
  }
}

class _BottomBar extends StatelessWidget {
  final VoidCallback onBack;
  final VoidCallback onForward;
  final VoidCallback onReload;
  final ThemeData theme;

  const _BottomBar({
    required this.onBack,
    required this.onForward,
    required this.onReload,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(18, 10, 18, 18),
      decoration: const BoxDecoration(
        color: Color(0xFF0D0817),
        border: Border(top: BorderSide(color: Color(0x221FFFFFF))),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _BottomAction(icon: Icons.arrow_back_ios_new_rounded, label: 'Back', onTap: onBack),
          _BottomAction(icon: Icons.refresh_rounded, label: 'Refresh', onTap: onReload),
          _BottomAction(icon: Icons.arrow_forward_ios_rounded, label: 'Next', onTap: onForward),
        ],
      ),
    );
  }
}

class _BottomAction extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _BottomAction({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: label,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 9),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: Colors.white70, size: 20),
              const SizedBox(height: 3),
              Text(label, style: const TextStyle(color: Colors.white54, fontSize: 11)),
            ],
          ),
        ),
      ),
    );
  }
}

class _ChromeButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;

  const _ChromeButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      child: Material(
        color: const Color(0xFF171022),
        borderRadius: BorderRadius.circular(14),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(14),
          child: SizedBox(
            width: 46,
            height: 46,
            child: Icon(icon, color: Colors.white, size: 21),
          ),
        ),
      ),
    );
  }
}

class _ErrorOverlay extends StatelessWidget {
  final String? message;
  final VoidCallback onRetry;

  const _ErrorOverlay({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return ColoredBox(
      color: const Color(0xF507030D),
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Container(
            constraints: const BoxConstraints(maxWidth: 420),
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: const Color(0xFF171022),
              borderRadius: BorderRadius.circular(28),
              border: Border.all(color: const Color(0x33FFFFFF)),
              boxShadow: const [BoxShadow(color: Color(0x55000000), blurRadius: 30)],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.cloud_off_rounded, color: Color(0xFFFF4D7D), size: 46),
                const SizedBox(height: 14),
                const Text('WebView gagal memuat',
                    style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800)),
                const SizedBox(height: 8),
                Text(
                  message ?? 'Koneksi atau halaman tujuan sedang bermasalah.',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white60, height: 1.4),
                ),
                const SizedBox(height: 20),
                FilledButton.icon(
                  onPressed: onRetry,
                  icon: const Icon(Icons.refresh_rounded),
                  label: const Text('Muat ulang'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
