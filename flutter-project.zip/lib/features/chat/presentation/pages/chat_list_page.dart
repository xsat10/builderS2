import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../../core/theme/theme_provider.dart';
import '../../../auth/presentation/providers/auth_provider.dart';
import '../../../settings/presentation/pages/settings_page.dart';
import 'chat_room_page.dart';

/// Halaman utama daftar percakapan (setara sidebar + list di web app)
class ChatListPage extends StatefulWidget {
  const ChatListPage({super.key});

  @override
  State<ChatListPage> createState() => _ChatListPageState();
}

class _ChatListPageState extends State<ChatListPage> {
  // Dummy data — ganti dengan data dari WebSocket / REST
  final List<Map<String, dynamic>> _chats = [
    {
      'id': 'dm_1',
      'name': 'Alice',
      'lastMessage': 'Hai, sudah coba fitur E2EE?',
      'time': '10:42',
      'unread': 2,
      'online': true,
      'type': 'dm',
    },
    {
      'id': 'group_1',
      'name': 'Xyzora Team',
      'lastMessage': 'Meeting jam 3 ya',
      'time': '09:15',
      'unread': 0,
      'online': false,
      'type': 'group',
    },
    {
      'id': 'channel_1',
      'name': 'Pengumuman',
      'lastMessage': 'Update v1.1.0 sudah live',
      'time': 'Kemarin',
      'unread': 5,
      'online': false,
      'type': 'channel',
    },
  ];

  String _filter = 'all';

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>().theme;
    final auth = context.watch<AuthProvider>();
    final username = auth.user?['username'] ?? auth.user?['displayName'] ?? 'User';

    final filtered = _filter == 'all'
        ? _chats
        : _chats.where((c) => c['type'] == _filter).toList();

    return Scaffold(
      backgroundColor: theme.cream,
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Container(
              padding: const EdgeInsets.fromLTRB(20, 16, 12, 12),
              decoration: BoxDecoration(
                color: theme.isGlass ? theme.white.withOpacity(0.4) : theme.cream,
                border: Border(
                  bottom: BorderSide(color: theme.black.withOpacity(0.1), width: 1),
                ),
              ),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 22,
                    backgroundColor: theme.purple,
                    child: Text(
                      username.toString().substring(0, 1).toUpperCase(),
                      style: TextStyle(
                        color: theme.white,
                        fontWeight: FontWeight.w800,
                        fontSize: 18,
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text.rich(
                          TextSpan(
                            children: [
                              TextSpan(
                                text: 'Xyzora',
                                style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.w900,
                                  color: theme.black,
                                ),
                              ),
                              TextSpan(
                                text: ' Chat',
                                style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.w900,
                                  color: theme.pink,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Text(
                          '@$username',
                          style: TextStyle(
                            fontSize: 13,
                            color: theme.black.withOpacity(0.55),
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: Icon(Icons.settings_outlined, color: theme.black),
                    onPressed: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => const SettingsPage()),
                      );
                    },
                  ),
                ],
              ),
            ),

            // Filter tabs
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              child: Row(
                children: [
                  _FilterChip(
                    label: 'Semua',
                    selected: _filter == 'all',
                    onTap: () => setState(() => _filter = 'all'),
                    theme: theme,
                  ),
                  const SizedBox(width: 8),
                  _FilterChip(
                    label: 'DM',
                    selected: _filter == 'dm',
                    onTap: () => setState(() => _filter = 'dm'),
                    theme: theme,
                  ),
                  const SizedBox(width: 8),
                  _FilterChip(
                    label: 'Grup',
                    selected: _filter == 'group',
                    onTap: () => setState(() => _filter = 'group'),
                    theme: theme,
                  ),
                  const SizedBox(width: 8),
                  _FilterChip(
                    label: 'Channel',
                    selected: _filter == 'channel',
                    onTap: () => setState(() => _filter = 'channel'),
                    theme: theme,
                  ),
                ],
              ),
            ),

            // Chat list
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.only(bottom: 80),
                itemCount: filtered.length,
                itemBuilder: (ctx, i) {
                  final c = filtered[i];
                  return _ChatItem(
                    chat: c,
                    theme: theme,
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (_) => ChatRoomPage(
                            chatId: c['id'] as String,
                            chatName: c['name'] as String,
                            isOnline: c['online'] as bool,
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // TODO: new chat / new group
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Fitur chat baru — hubungkan ke API')),
          );
        },
        backgroundColor: theme.purple,
        foregroundColor: theme.white,
        elevation: theme.shadowOffLg,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(theme.radiusSm),
          side: BorderSide(color: theme.black, width: theme.borderW),
        ),
        child: const Icon(Icons.edit_outlined),
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  final dynamic theme;

  const _FilterChip({
    required this.label,
    required this.selected,
    required this.onTap,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
        decoration: BoxDecoration(
          color: selected ? theme.purple : theme.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: theme.black, width: theme.borderW),
          boxShadow: selected
              ? [
                  BoxShadow(
                    color: theme.black.withOpacity(0.2),
                    offset: Offset(theme.shadowOff, theme.shadowOff),
                  ),
                ]
              : null,
        ),
        child: Text(
          label,
          style: TextStyle(
            color: selected ? theme.white : theme.black,
            fontWeight: FontWeight.w700,
            fontSize: 13,
          ),
        ),
      ),
    );
  }
}

class _ChatItem extends StatelessWidget {
  final Map<String, dynamic> chat;
  final dynamic theme;
  final VoidCallback onTap;

  const _ChatItem({
    required this.chat,
    required this.theme,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final unread = chat['unread'] as int;
    return InkWell(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: theme.isGlass ? theme.white.withOpacity(0.45) : theme.white,
          borderRadius: BorderRadius.circular(theme.radius),
          border: Border.all(color: theme.black.withOpacity(0.12), width: 1),
        ),
        child: Row(
          children: [
            Stack(
              children: [
                CircleAvatar(
                  radius: 26,
                  backgroundColor: theme.purple.withOpacity(0.2),
                  child: Text(
                    (chat['name'] as String).substring(0, 1).toUpperCase(),
                    style: TextStyle(
                      color: theme.purple,
                      fontWeight: FontWeight.w800,
                      fontSize: 18,
                    ),
                  ),
                ),
                if (chat['online'] == true)
                  Positioned(
                    right: 0,
                    bottom: 0,
                    child: Container(
                      width: 14,
                      height: 14,
                      decoration: BoxDecoration(
                        color: theme.green,
                        shape: BoxShape.circle,
                        border: Border.all(color: theme.white, width: 2),
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          chat['name'] as String,
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 15,
                            color: theme.black,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      Text(
                        chat['time'] as String,
                        style: TextStyle(
                          fontSize: 12,
                          color: theme.black.withOpacity(0.45),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 3),
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          chat['lastMessage'] as String,
                          style: TextStyle(
                            fontSize: 13,
                            color: theme.black.withOpacity(0.55),
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      if (unread > 0)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                          decoration: BoxDecoration(
                            color: theme.purple,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Text(
                            '$unread',
                            style: TextStyle(
                              color: theme.white,
                              fontSize: 11,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
