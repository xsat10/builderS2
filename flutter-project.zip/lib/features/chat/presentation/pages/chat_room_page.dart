import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../../core/theme/theme_provider.dart';
import '../../../../core/network/websocket_client.dart';
import '../widgets/chat_bubble.dart';

class ChatRoomPage extends StatefulWidget {
  final String chatId;
  final String chatName;
  final bool isOnline;

  const ChatRoomPage({
    super.key,
    required this.chatId,
    required this.chatName,
    this.isOnline = false,
  });

  @override
  State<ChatRoomPage> createState() => _ChatRoomPageState();
}

class _ChatRoomPageState extends State<ChatRoomPage> {
  final _inputCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();
  final List<Map<String, dynamic>> _messages = [];
  bool _isTyping = false;
  String? _replyToId;
  String? _replyToText;

  @override
  void initState() {
    super.initState();
    // Dummy messages
    _messages.addAll([
      {
        'id': '1',
        'text': 'Halo! Selamat datang di Xyzora Chat 🔐',
        'isMe': false,
        'time': '10:30',
        'status': 'read',
      },
      {
        'id': '2',
        'text': 'Pesan ini dienkripsi end-to-end.',
        'isMe': false,
        'time': '10:31',
        'status': 'read',
      },
      {
        'id': '3',
        'text': 'Mantap! Sudah coba voice call?',
        'isMe': true,
        'time': '10:35',
        'status': 'read',
      },
    ]);
    WebSocketClient.instance.joinChat(widget.chatId);
  }

  @override
  void dispose() {
    WebSocketClient.instance.leaveChat(widget.chatId);
    _inputCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  void _send() {
    final text = _inputCtrl.text.trim();
    if (text.isEmpty) return;

    final msg = {
      'id': DateTime.now().millisecondsSinceEpoch.toString(),
      'text': text,
      'isMe': true,
      'time': TimeOfDay.now().format(context),
      'status': 'sent',
      if (_replyToId != null) 'replyTo': _replyToId,
      if (_replyToText != null) 'replyText': _replyToText,
    };

    setState(() {
      _messages.add(msg);
      _replyToId = null;
      _replyToText = null;
    });
    _inputCtrl.clear();

    // Kirim via WebSocket (E2EE encrypt di production)
    WebSocketClient.instance.sendMessage({
      'chatId': widget.chatId,
      'text': text,
      'type': 'text',
      if (_replyToId != null) 'replyTo': _replyToId,
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _onTyping(String _) {
    if (!_isTyping) {
      _isTyping = true;
      WebSocketClient.instance.sendTyping(widget.chatId, true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>().theme;

    return Scaffold(
      backgroundColor: theme.cream,
      appBar: AppBar(
        backgroundColor: theme.isGlass ? theme.white.withOpacity(0.5) : theme.cream,
        foregroundColor: theme.black,
        elevation: 0,
        titleSpacing: 0,
        title: Row(
          children: [
            CircleAvatar(
              radius: 18,
              backgroundColor: theme.purple.withOpacity(0.2),
              child: Text(
                widget.chatName.substring(0, 1).toUpperCase(),
                style: TextStyle(
                  color: theme.purple,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.chatName,
                  style: TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: 16,
                    color: theme.black,
                  ),
                ),
                Text(
                  widget.isOnline ? 'Online' : 'Offline',
                  style: TextStyle(
                    fontSize: 12,
                    color: widget.isOnline ? theme.green : theme.black.withOpacity(0.45),
                  ),
                ),
              ],
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.call_outlined, color: theme.black),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Voice call — integrasikan flutter_webrtc')),
              );
            },
          ),
          IconButton(
            icon: Icon(Icons.videocam_outlined, color: theme.black),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Video call — integrasikan flutter_webrtc')),
              );
            },
          ),
          IconButton(
            icon: Icon(Icons.more_vert, color: theme.black),
            onPressed: () {},
          ),
        ],
      ),
      body: Column(
        children: [
          // Messages
          Expanded(
            child: ListView.builder(
              controller: _scrollCtrl,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              itemCount: _messages.length,
              itemBuilder: (ctx, i) {
                final m = _messages[i];
                return ChatBubble(
                  text: m['text'] as String,
                  isMe: m['isMe'] as bool,
                  time: m['time'] as String,
                  status: m['status'] as String? ?? 'sent',
                  replyText: m['replyText'] as String?,
                  theme: theme,
                  onReply: () {
                    setState(() {
                      _replyToId = m['id'] as String;
                      _replyToText = m['text'] as String;
                    });
                  },
                );
              },
            ),
          ),

          // Reply preview
          if (_replyToText != null)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              color: theme.yellow.withOpacity(0.4),
              child: Row(
                children: [
                  Icon(Icons.reply, size: 18, color: theme.purple),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      _replyToText!,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: theme.black, fontSize: 13),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, size: 18),
                    onPressed: () => setState(() {
                      _replyToId = null;
                      _replyToText = null;
                    }),
                  ),
                ],
              ),
            ),

          // Input bar
          Container(
            padding: const EdgeInsets.fromLTRB(10, 8, 10, 12),
            decoration: BoxDecoration(
              color: theme.isGlass ? theme.white.withOpacity(0.5) : theme.white,
              border: Border(
                top: BorderSide(color: theme.black.withOpacity(0.1)),
              ),
            ),
            child: SafeArea(
              top: false,
              child: Row(
                children: [
                  IconButton(
                    icon: Icon(Icons.attach_file, color: theme.purple),
                    onPressed: () {
                      // TODO: image_picker / file_picker
                    },
                  ),
                  Expanded(
                    child: TextField(
                      controller: _inputCtrl,
                      onChanged: _onTyping,
                      decoration: InputDecoration(
                        hintText: 'Ketik pesan...',
                        filled: true,
                        fillColor: theme.cream,
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 10,
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(24),
                          borderSide: BorderSide.none,
                        ),
                      ),
                      textInputAction: TextInputAction.send,
                      onSubmitted: (_) => _send(),
                    ),
                  ),
                  const SizedBox(width: 6),
                  Container(
                    decoration: BoxDecoration(
                      color: theme.purple,
                      shape: BoxShape.circle,
                      border: Border.all(color: theme.black, width: theme.borderW),
                      boxShadow: [
                        BoxShadow(
                          color: theme.black.withOpacity(0.2),
                          offset: Offset(theme.shadowOff, theme.shadowOff),
                        ),
                      ],
                    ),
                    child: IconButton(
                      icon: Icon(Icons.send_rounded, color: theme.white, size: 22),
                      onPressed: _send,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
