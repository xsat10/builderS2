import 'package:flutter/material.dart';
import '../../../../core/constants/themes_data.dart';

class ChatBubble extends StatelessWidget {
  final String text;
  final bool isMe;
  final String time;
  final String status; // sent, delivered, read
  final String? replyText;
  final XyzoraThemeData theme;
  final VoidCallback? onReply;

  const ChatBubble({
    super.key,
    required this.text,
    required this.isMe,
    required this.time,
    required this.theme,
    this.status = 'sent',
    this.replyText,
    this.onReply,
  });

  @override
  Widget build(BuildContext context) {
    final bg = isMe ? theme.bubbleMe : theme.bubbleOther;
    final align = isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Column(
        crossAxisAlignment: align,
        children: [
          GestureDetector(
            onLongPress: onReply,
            child: Container(
              constraints: BoxConstraints(
                maxWidth: MediaQuery.of(context).size.width * 0.75,
              ),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: bg,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(theme.radius),
                  topRight: Radius.circular(theme.radius),
                  bottomLeft: Radius.circular(isMe ? theme.radius : 4),
                  bottomRight: Radius.circular(isMe ? 4 : theme.radius),
                ),
                border: Border.all(
                  color: theme.black.withOpacity(0.12),
                  width: theme.borderW > 1.5 ? 1.5 : theme.borderW,
                ),
                boxShadow: theme.shadowOff > 0
                    ? [
                        BoxShadow(
                          color: theme.black.withOpacity(0.1),
                          offset: Offset(theme.shadowOff * 0.6, theme.shadowOff * 0.6),
                        ),
                      ]
                    : null,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (replyText != null) ...[
                    Container(
                      padding: const EdgeInsets.all(8),
                      margin: const EdgeInsets.only(bottom: 6),
                      decoration: BoxDecoration(
                        color: theme.black.withOpacity(0.06),
                        borderRadius: BorderRadius.circular(8),
                        border: Border(
                          left: BorderSide(color: theme.purple, width: 3),
                        ),
                      ),
                      child: Text(
                        replyText!,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 12,
                          color: theme.black.withOpacity(0.65),
                        ),
                      ),
                    ),
                  ],
                  Text(
                    text,
                    style: TextStyle(
                      fontSize: 15,
                      color: theme.black,
                      height: 1.35,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        time,
                        style: TextStyle(
                          fontSize: 11,
                          color: theme.black.withOpacity(0.4),
                        ),
                      ),
                      if (isMe) ...[
                        const SizedBox(width: 4),
                        Icon(
                          status == 'read'
                              ? Icons.done_all
                              : status == 'delivered'
                                  ? Icons.done_all
                                  : Icons.done,
                          size: 14,
                          color: status == 'read'
                              ? theme.blue
                              : theme.black.withOpacity(0.35),
                        ),
                      ],
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
