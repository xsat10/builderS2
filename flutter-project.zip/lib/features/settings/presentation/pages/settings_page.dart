import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../../core/constants/themes_data.dart';
import '../../../../core/security/e2ee_helper.dart';
import '../../../../core/theme/theme_provider.dart';
import '../../../auth/presentation/providers/auth_provider.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>().theme;
    final themeProv = context.watch<ThemeProvider>();
    final auth = context.watch<AuthProvider>();
    final e2ee = E2eeHelper.instance;
    final username = auth.user?['username'] ?? 'User';
    final displayName = auth.user?['displayName'] ?? username;

    return Scaffold(
      backgroundColor: theme.cream,
      appBar: AppBar(
        title: const Text('Pengaturan'),
        backgroundColor: theme.cream,
        foregroundColor: theme.black,
        elevation: 0,
      ),
      body: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        children: [
          // Profile card
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: theme.white,
              borderRadius: BorderRadius.circular(theme.radius),
              border: Border.all(color: theme.black, width: theme.borderW),
              boxShadow: [
                BoxShadow(
                  color: theme.black.withOpacity(0.12),
                  offset: Offset(theme.shadowOff, theme.shadowOff),
                ),
              ],
            ),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 32,
                  backgroundColor: theme.purple,
                  child: Text(
                    displayName.toString().substring(0, 1).toUpperCase(),
                    style: TextStyle(
                      color: theme.white,
                      fontSize: 26,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        displayName.toString(),
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                          color: theme.black,
                        ),
                      ),
                      Text(
                        '@$username',
                        style: TextStyle(
                          color: theme.black.withOpacity(0.5),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),

          // E2EE section
          _SectionTitle(title: 'End-to-End Encryption', theme: theme),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: theme.white,
              borderRadius: BorderRadius.circular(theme.radiusSm),
              border: Border.all(color: theme.black.withOpacity(0.12)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.lock, color: theme.green, size: 20),
                    const SizedBox(width: 8),
                    Text(
                      e2ee.isReady ? 'E2EE Aktif' : 'E2EE Belum siap',
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        color: theme.black,
                      ),
                    ),
                  ],
                ),
                if (e2ee.fingerprint != null) ...[
                  const SizedBox(height: 8),
                  Text(
                    'Fingerprint: ${e2ee.fingerprint}',
                    style: TextStyle(
                      fontSize: 12,
                      fontFamily: 'monospace',
                      color: theme.black.withOpacity(0.55),
                    ),
                  ),
                ],
                const SizedBox(height: 8),
                Text(
                  'Pesan dienkripsi di perangkat. Server tidak pernah melihat isi pesan.',
                  style: TextStyle(
                    fontSize: 13,
                    color: theme.black.withOpacity(0.6),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),

          // Theme switcher
          _SectionTitle(title: 'Tema', theme: theme),
          const SizedBox(height: 8),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: themeProv.availableThemes.map((t) {
              final selected = t.id == theme.id;
              return GestureDetector(
                onTap: () => themeProv.setTheme(t.id),
                child: Container(
                  width: 100,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: t.cream,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: selected ? t.purple : t.black.withOpacity(0.2),
                      width: selected ? 2.5 : 1,
                    ),
                    boxShadow: selected
                        ? [
                            BoxShadow(
                              color: t.purple.withOpacity(0.3),
                              blurRadius: 8,
                              offset: const Offset(0, 3),
                            ),
                          ]
                        : null,
                  ),
                  child: Column(
                    children: [
                      Container(
                        width: 28,
                        height: 28,
                        decoration: BoxDecoration(
                          color: t.purple,
                          shape: BoxShape.circle,
                          border: Border.all(color: t.black, width: 1.5),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        t.name,
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: t.black,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 32),

          // Logout
          SizedBox(
            height: 50,
            child: OutlinedButton.icon(
              onPressed: () async {
                await auth.logout();
                if (context.mounted) {
                  Navigator.of(context).popUntil((r) => r.isFirst);
                }
              },
              icon: Icon(Icons.logout, color: theme.red),
              label: Text(
                'Keluar',
                style: TextStyle(
                  color: theme.red,
                  fontWeight: FontWeight.w800,
                ),
              ),
              style: OutlinedButton.styleFrom(
                side: BorderSide(color: theme.red, width: 2),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(theme.radiusSm),
                ),
              ),
            ),
          ),
          const SizedBox(height: 40),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  final XyzoraThemeData theme;
  const _SectionTitle({required this.title, required this.theme});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10, left: 4),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w800,
          color: theme.black.withOpacity(0.55),
          letterSpacing: 0.5,
        ),
      ),
    );
  }
}
