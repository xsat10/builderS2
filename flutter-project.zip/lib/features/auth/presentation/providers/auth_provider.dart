import 'package:flutter/foundation.dart';
import '../../../../core/network/api_service.dart';
import '../../../../core/network/websocket_client.dart';
import '../../../../core/security/e2ee_helper.dart';
import '../../../../core/security/storage_helper.dart';

enum AuthStatus { unknown, authenticated, unauthenticated }

class AuthProvider extends ChangeNotifier {
  final _api = ApiService.instance;
  final _ws = WebSocketClient.instance;
  final _storage = StorageHelper.instance;
  final _e2ee = E2eeHelper.instance;

  AuthStatus _status = AuthStatus.unknown;
  Map<String, dynamic>? _user;
  String? _error;
  bool _loading = false;

  AuthStatus get status => _status;
  Map<String, dynamic>? get user => _user;
  String? get error => _error;
  bool get loading => _loading;
  bool get isLoggedIn => _status == AuthStatus.authenticated;

  Future<void> init() async {
    _loading = true;
    notifyListeners();
    try {
      final has = await _storage.hasSession();
      if (has) {
        _user = await _storage.getUser();
        await _e2ee.init();
        await _ws.connect();
        _status = AuthStatus.authenticated;
      } else {
        _status = AuthStatus.unauthenticated;
      }
    } catch (e) {
      _status = AuthStatus.unauthenticated;
      _error = e.toString();
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  Future<bool> login(String username, String password) async {
    _loading = true;
    _error = null;
    notifyListeners();
    try {
      final res = await _api.login(username: username, password: password);
      _user = res['user'] as Map<String, dynamic>?;
      await _e2ee.init();
      await _ws.connect();
      _status = AuthStatus.authenticated;
      return true;
    } on ApiException catch (e) {
      _error = e.message;
      return false;
    } catch (e) {
      _error = e.toString();
      return false;
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  Future<bool> register({
    required String username,
    required String password,
    required String displayName,
    required String birthDate,
    String? guardianContact,
  }) async {
    _loading = true;
    _error = null;
    notifyListeners();
    try {
      final res = await _api.register(
        username: username,
        password: password,
        displayName: displayName,
        birthDate: birthDate,
        guardianContact: guardianContact,
      );
      if (res['token'] != null) {
        _user = res['user'] as Map<String, dynamic>?;
        await _e2ee.init();
        await _ws.connect();
        _status = AuthStatus.authenticated;
      } else {
        // perlu login manual setelah register
        _status = AuthStatus.unauthenticated;
      }
      return true;
    } on ApiException catch (e) {
      _error = e.message;
      return false;
    } catch (e) {
      _error = e.toString();
      return false;
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  Future<void> logout() async {
    _ws.disconnect();
    await _api.logout();
    _user = null;
    _status = AuthStatus.unauthenticated;
    notifyListeners();
  }
}
