import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../../core/theme/theme_provider.dart';
import '../providers/auth_provider.dart';
import 'register_page.dart';

/// Login screen — neobrutalism style matching web index.html / style.css
class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _formKey = GlobalKey<FormState>();
  final _usernameCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();
  bool _obscure = true;

  @override
  void dispose() {
    _usernameCtrl.dispose();
    _passwordCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    final auth = context.read<AuthProvider>();
    final ok = await auth.login(
      _usernameCtrl.text.trim(),
      _passwordCtrl.text,
    );
    if (!ok && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(auth.error ?? 'Login gagal'),
          backgroundColor: const Color(0xFFFF4545),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>().theme;
    final auth = context.watch<AuthProvider>();

    return Scaffold(
      backgroundColor: theme.cream,
      body: Stack(
        children: [
          // Dot pattern background (sama seperti web)
          Positioned.fill(
            child: CustomPaint(
              painter: _DotPatternPainter(color: theme.black.withOpacity(0.06)),
            ),
          ),
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 400),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // Logo resmi Xyzora
                        Transform.rotate(
                          angle: -0.07,
                          child: Container(
                            width: 88,
                            height: 88,
                            decoration: BoxDecoration(
                              color: theme.yellow,
                              borderRadius: BorderRadius.circular(18),
                              border: Border.all(
                                color: theme.black,
                                width: theme.borderWLg,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: theme.black,
                                  offset: Offset(theme.shadowOff, theme.shadowOff),
                                ),
                              ],
                            ),
                            clipBehavior: Clip.antiAlias,
                            child: Image.asset(
                              'assets/images/xyzora_logo.jpg',
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => Center(
                                child: Text(
                                  'X',
                                  style: TextStyle(
                                    fontSize: 40,
                                    fontWeight: FontWeight.w900,
                                    color: theme.black,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 18),
                        Text.rich(
                          TextSpan(
                            children: [
                              TextSpan(
                                text: 'Xyzora',
                                style: TextStyle(
                                  fontSize: 30,
                                  fontWeight: FontWeight.w900,
                                  color: theme.black,
                                  letterSpacing: -0.5,
                                ),
                              ),
                              TextSpan(
                                text: ' Chat',
                                style: TextStyle(
                                  fontSize: 30,
                                  fontWeight: FontWeight.w900,
                                  color: theme.pink,
                                  letterSpacing: -0.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          'Ngobrol tanpa batas, aman & cepat.',
                          style: TextStyle(
                            color: theme.black.withOpacity(0.55),
                            fontWeight: FontWeight.w600,
                            fontSize: 13,
                          ),
                        ),
                        const SizedBox(height: 28),

                        // Auth card (brutal)
                        Container(
                          padding: const EdgeInsets.fromLTRB(24, 28, 24, 24),
                          decoration: BoxDecoration(
                            color: theme.white,
                            borderRadius: BorderRadius.circular(theme.radius),
                            border: Border.all(
                              color: theme.black,
                              width: theme.borderWLg,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: theme.black,
                                offset: Offset(theme.shadowOffLg, theme.shadowOffLg),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Text(
                                'Masuk',
                                style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.w900,
                                  color: theme.black,
                                ),
                              ),
                              const SizedBox(height: 18),
                              _BrutalField(
                                controller: _usernameCtrl,
                                label: 'Username',
                                icon: Icons.person_outline_rounded,
                                theme: theme,
                                textInputAction: TextInputAction.next,
                                validator: (v) =>
                                    (v == null || v.trim().isEmpty)
                                        ? 'Username wajib'
                                        : null,
                              ),
                              const SizedBox(height: 12),
                              _BrutalField(
                                controller: _passwordCtrl,
                                label: 'Password',
                                icon: Icons.lock_outline_rounded,
                                theme: theme,
                                obscure: _obscure,
                                textInputAction: TextInputAction.done,
                                onSubmitted: (_) => _submit(),
                                suffix: IconButton(
                                  icon: Icon(
                                    _obscure
                                        ? Icons.visibility_off_rounded
                                        : Icons.visibility_rounded,
                                    color: theme.black.withOpacity(0.45),
                                    size: 20,
                                  ),
                                  onPressed: () =>
                                      setState(() => _obscure = !_obscure),
                                ),
                                validator: (v) =>
                                    (v == null || v.isEmpty)
                                        ? 'Password wajib'
                                        : null,
                              ),
                              const SizedBox(height: 22),
                              _BrutalButton(
                                label: 'MASUK',
                                loading: auth.loading,
                                onPressed: auth.loading ? null : _submit,
                                bg: theme.pink,
                                theme: theme,
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 20),
                        TextButton(
                          onPressed: () {
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (_) => const RegisterPage(),
                              ),
                            );
                          },
                          child: Text.rich(
                            TextSpan(
                              style: TextStyle(
                                fontWeight: FontWeight.w700,
                                fontSize: 14,
                                color: theme.black.withOpacity(0.7),
                              ),
                              children: [
                                const TextSpan(text: 'Belum punya akun? '),
                                TextSpan(
                                  text: 'Daftar',
                                  style: TextStyle(
                                    color: theme.pink,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _BrutalField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final IconData icon;
  final dynamic theme;
  final bool obscure;
  final Widget? suffix;
  final TextInputAction? textInputAction;
  final ValueChanged<String>? onSubmitted;
  final String? Function(String?)? validator;

  const _BrutalField({
    required this.controller,
    required this.label,
    required this.icon,
    required this.theme,
    this.obscure = false,
    this.suffix,
    this.textInputAction,
    this.onSubmitted,
    this.validator,
  });

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller,
      obscureText: obscure,
      textInputAction: textInputAction,
      onFieldSubmitted: onSubmitted,
      validator: validator,
      style: TextStyle(
        fontWeight: FontWeight.w600,
        color: theme.black,
        fontSize: 14,
      ),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: TextStyle(
          fontWeight: FontWeight.w600,
          color: theme.black.withOpacity(0.5),
        ),
        prefixIcon: Icon(icon, color: theme.purple, size: 22),
        suffixIcon: suffix,
        filled: true,
        fillColor: theme.white,
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: theme.black, width: theme.borderW),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: theme.black, width: theme.borderW),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: theme.black, width: theme.borderWLg),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: theme.red, width: theme.borderW),
        ),
      ),
    );
  }
}

class _BrutalButton extends StatelessWidget {
  final String label;
  final bool loading;
  final VoidCallback? onPressed;
  final Color bg;
  final dynamic theme;

  const _BrutalButton({
    required this.label,
    required this.loading,
    required this.onPressed,
    required this.bg,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onPressed,
        borderRadius: BorderRadius.circular(10),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 80),
          height: 50,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: bg,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: theme.black, width: theme.borderW),
            boxShadow: [
              BoxShadow(
                color: theme.black,
                offset: Offset(theme.shadowOff - 1, theme.shadowOff - 1),
              ),
            ],
          ),
          child: loading
              ? SizedBox(
                  width: 22,
                  height: 22,
                  child: CircularProgressIndicator(
                    strokeWidth: 2.5,
                    color: theme.black,
                  ),
                )
              : Text(
                  label,
                  style: TextStyle(
                    fontWeight: FontWeight.w900,
                    fontSize: 14,
                    letterSpacing: 0.6,
                    color: theme.black,
                  ),
                ),
        ),
      ),
    );
  }
}

class _DotPatternPainter extends CustomPainter {
  final Color color;
  _DotPatternPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = color;
    const step = 22.0;
    for (var y = 0.0; y < size.height; y += step) {
      for (var x = 0.0; x < size.width; x += step) {
        canvas.drawCircle(Offset(x, y), 1.4, paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
