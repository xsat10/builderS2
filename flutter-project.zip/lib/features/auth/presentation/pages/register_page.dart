import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../../core/theme/theme_provider.dart';
import '../providers/auth_provider.dart';

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final _formKey = GlobalKey<FormState>();
  final _usernameCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();
  final _displayCtrl = TextEditingController();
  final _birthCtrl = TextEditingController();
  final _guardianCtrl = TextEditingController();
  bool _obscure = true;
  bool _showGuardian = false;

  @override
  void dispose() {
    _usernameCtrl.dispose();
    _passwordCtrl.dispose();
    _displayCtrl.dispose();
    _birthCtrl.dispose();
    _guardianCtrl.dispose();
    super.dispose();
  }

  void _checkAge(String date) {
    try {
      final d = DateTime.parse(date);
      final age = DateTime.now().difference(d).inDays ~/ 365;
      setState(() => _showGuardian = age < 18);
    } catch (_) {
      setState(() => _showGuardian = false);
    }
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    final auth = context.read<AuthProvider>();
    final ok = await auth.register(
      username: _usernameCtrl.text.trim(),
      password: _passwordCtrl.text,
      displayName: _displayCtrl.text.trim(),
      birthDate: _birthCtrl.text.trim(),
      guardianContact: _showGuardian ? _guardianCtrl.text.trim() : null,
    );
    if (!mounted) return;
    if (ok) {
      if (auth.isLoggedIn) {
        Navigator.of(context).popUntil((r) => r.isFirst);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Registrasi berhasil. Silakan login.')),
        );
        Navigator.of(context).pop();
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(auth.error ?? 'Registrasi gagal'),
          backgroundColor: const Color(0xFFFF4545),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>().theme;
    final auth = context.watch<AuthProvider>();

    return Scaffold(
      backgroundColor: theme.cream,
      appBar: AppBar(
        title: const Text('Daftar', style: TextStyle(fontWeight: FontWeight.w900)),
        backgroundColor: theme.cream,
        foregroundColor: theme.black,
        elevation: 0,
      ),
      body: Stack(
        children: [
          Positioned.fill(
            child: CustomPaint(
              painter: _DotPainter(color: theme.black.withOpacity(0.05)),
            ),
          ),
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              child: Form(
                key: _formKey,
                child: Container(
                  padding: const EdgeInsets.all(22),
                  decoration: BoxDecoration(
                    color: theme.white,
                    borderRadius: BorderRadius.circular(theme.radius),
                    border: Border.all(color: theme.black, width: theme.borderWLg),
                    boxShadow: [
                      BoxShadow(
                        color: theme.black,
                        offset: Offset(theme.shadowOff, theme.shadowOff),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      _field(_displayCtrl, 'Nama tampilan', Icons.badge_outlined, theme),
                      const SizedBox(height: 12),
                      _field(_usernameCtrl, 'Username', Icons.person_outline, theme,
                          validator: (v) {
                        if (v == null || v.trim().isEmpty) return 'Wajib diisi';
                        if (v.length < 3) return 'Minimal 3 karakter';
                        return null;
                      }),
                      const SizedBox(height: 12),
                      _field(_passwordCtrl, 'Password (min 8, huruf+angka)', Icons.lock_outline, theme,
                          obscure: _obscure,
                          suffix: IconButton(
                            icon: Icon(_obscure ? Icons.visibility_off : Icons.visibility,
                                color: theme.black.withOpacity(0.45), size: 20),
                            onPressed: () => setState(() => _obscure = !_obscure),
                          ),
                          validator: (v) {
                        if (v == null || v.length < 8) return 'Minimal 8 karakter';
                        if (!RegExp(r'[A-Za-z]').hasMatch(v) || !RegExp(r'[0-9]').hasMatch(v)) {
                          return 'Harus mengandung huruf dan angka';
                        }
                        return null;
                      }),
                      const SizedBox(height: 12),
                      _field(_birthCtrl, 'Tanggal lahir (YYYY-MM-DD)', Icons.cake_outlined, theme,
                          onChanged: _checkAge,
                          validator: (v) {
                        if (v == null || v.isEmpty) return 'Wajib diisi';
                        if (!RegExp(r'^\d{4}-\d{2}-\d{2}$').hasMatch(v)) return 'Format YYYY-MM-DD';
                        return null;
                      }),
                      if (_showGuardian) ...[
                        const SizedBox(height: 12),
                        _field(_guardianCtrl, 'Kontak wali/orang tua', Icons.family_restroom, theme,
                            validator: (v) =>
                                _showGuardian && (v == null || v.trim().isEmpty) ? 'Wajib diisi' : null),
                        Padding(
                          padding: const EdgeInsets.only(top: 6),
                          child: Text(
                            'Karena usia kamu di bawah 18 tahun, kontak wali wajib diisi.',
                            style: TextStyle(fontSize: 12, color: theme.black.withOpacity(0.55)),
                          ),
                        ),
                      ],
                      const SizedBox(height: 24),
                      SizedBox(
                        height: 50,
                        child: ElevatedButton(
                          onPressed: auth.loading ? null : _submit,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: theme.pink,
                            foregroundColor: theme.black,
                            elevation: 0,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                              side: BorderSide(color: theme.black, width: theme.borderW),
                            ),
                            shadowColor: theme.black,
                          ),
                          child: auth.loading
                              ? SizedBox(
                                  width: 22,
                                  height: 22,
                                  child: CircularProgressIndicator(strokeWidth: 2.5, color: theme.black),
                                )
                              : const Text('DAFTAR',
                                  style: TextStyle(fontWeight: FontWeight.w900, fontSize: 14, letterSpacing: 0.5)),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _field(
    TextEditingController c,
    String label,
    IconData icon,
    dynamic theme, {
    bool obscure = false,
    Widget? suffix,
    ValueChanged<String>? onChanged,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: c,
      obscureText: obscure,
      onChanged: onChanged,
      validator: validator ?? (v) => (v == null || v.trim().isEmpty) ? 'Wajib diisi' : null,
      style: TextStyle(fontWeight: FontWeight.w600, color: theme.black, fontSize: 14),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: TextStyle(fontWeight: FontWeight.w600, color: theme.black.withOpacity(0.5)),
        prefixIcon: Icon(icon, color: theme.purple, size: 22),
        suffixIcon: suffix,
        filled: true,
        fillColor: theme.white,
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: theme.black, width: theme.borderW),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: theme.black, width: theme.borderW),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: theme.black, width: theme.borderWLg),
        ),
      ),
    );
  }
}

class _DotPainter extends CustomPainter {
  final Color color;
  _DotPainter({required this.color});
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = color;
    const step = 22.0;
    for (var y = 0.0; y < size.height; y += step) {
      for (var x = 0.0; x < size.width; x += step) {
        canvas.drawCircle(Offset(x, y), 1.3, paint);
      }
    }
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
