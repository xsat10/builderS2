import 'package:flutter/material.dart';

/// Stub halaman panggilan Voice/Video.
/// Port logika dari public/js/live.js menggunakan flutter_webrtc.
/// Signaling lewat event Socket.IO 'call' & 'call-signal'.
class CallPage extends StatelessWidget {
  final String chatId;
  final String peerName;
  final bool isVideo;

  const CallPage({
    super.key,
    required this.chatId,
    required this.peerName,
    this.isVideo = false,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.call, size: 64, color: Colors.white70),
              const SizedBox(height: 16),
              Text(
                isVideo ? 'Video Call' : 'Voice Call',
                style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              Text(peerName, style: const TextStyle(color: Colors.white70, fontSize: 16)),
              const SizedBox(height: 12),
              const Text(
                'Integrasikan flutter_webrtc + signaling dari live.js',
                style: TextStyle(color: Colors.white38, fontSize: 13),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 40),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  FloatingActionButton(
                    heroTag: 'hangup',
                    backgroundColor: Colors.red,
                    onPressed: () => Navigator.pop(context),
                    child: const Icon(Icons.call_end),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
