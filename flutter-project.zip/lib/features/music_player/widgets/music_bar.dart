import 'package:flutter/material.dart';

/// Stub music player bar untuk fitur Music Sharing.
/// Port logika dari public/js/music.js menggunakan just_audio.
class MusicBar extends StatelessWidget {
  final String? title;
  final String? artist;
  final bool isPlaying;
  final VoidCallback? onPlayPause;
  final VoidCallback? onClose;

  const MusicBar({
    super.key,
    this.title,
    this.artist,
    this.isPlaying = false,
    this.onPlayPause,
    this.onClose,
  });

  @override
  Widget build(BuildContext context) {
    if (title == null) return const SizedBox.shrink();
    return Container(
      height: 56,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      color: Colors.black87,
      child: Row(
        children: [
          IconButton(
            icon: Icon(isPlaying ? Icons.pause : Icons.play_arrow, color: Colors.white),
            onPressed: onPlayPause,
          ),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title!, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 13), overflow: TextOverflow.ellipsis),
                if (artist != null)
                  Text(artist!, style: const TextStyle(color: Colors.white54, fontSize: 11), overflow: TextOverflow.ellipsis),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.close, color: Colors.white54, size: 20),
            onPressed: onClose,
          ),
        ],
      ),
    );
  }
}
