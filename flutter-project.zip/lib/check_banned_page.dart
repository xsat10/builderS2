import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

// ============ PALET WARNA MERAH ============
const Color _bgDeep = Color(0xFF0A0A0A);
const Color _bgCard = Color(0xFF1A1A1A);
const Color _bgSurface = Color(0xFF2A2A2A);
const Color _bgInput = Color(0xFF3D3D3D);
const Color _accentColor = Color(0xFFE53935); // Merah utama
const Color _accentGlow = Color(0xFFFF5252);  // Merah terang / glow
const Color _textLight = Color(0xFFFFFFFF);
const Color _textSub = Color(0xFFB0B0B0);
const Color _textMuted = Color(0xFF808080);
const Color _successGreen = Color(0xFF4CAF50);
const Color _dangerRed = Color(0xFFF44336);
const Color _warningYellow = Color(0xFFFFC107);
// =================================================

class CheckBannedPage extends StatefulWidget {
  final String sessionKey;

  const CheckBannedPage({
    super.key,
    required this.sessionKey,
  });

  @override
  State<CheckBannedPage> createState() => _CheckBannedPageState();
}

class _CheckBannedPageState extends State<CheckBannedPage>
    with SingleTickerProviderStateMixin {
  final TextEditingController _phoneController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool _isLoading = false;
  bool _hasResult = false;
  bool _isBanned = false;
  String _statusMessage = '';
  String _phoneNumber = '';
  String _bannedReason = '';

  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  List<Map<String, dynamic>> _history = [];

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
    _pulseAnimation = CurvedAnimation(
      parent: _pulseController,
      curve: Curves.easeInOut,
    );
    _loadHistory();
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  Future<void> _loadHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final String? historyJson = prefs.getString('check_banned_history');
    if (historyJson != null) {
      try {
        final List<dynamic> data = jsonDecode(historyJson);
        setState(() {
          _history = data.map((e) => Map<String, dynamic>.from(e)).toList();
        });
      } catch (_) {}
    }
  }

  Future<void> _saveHistory(Map<String, dynamic> data) async {
    final prefs = await SharedPreferences.getInstance();
    _history.insert(0, data);
    if (_history.length > 20) {
      _history.removeLast();
    }
    await prefs.setString('check_banned_history', jsonEncode(_history));
  }

  String _formatPhoneNumber(String input) {
    String cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+')) {
      if (cleaned.startsWith('0')) {
        cleaned = '+62${cleaned.substring(1)}';
      } else if (cleaned.startsWith('62')) {
        cleaned = '+$cleaned';
      } else {
        cleaned = '+62$cleaned';
      }
    }
    return cleaned;
  }

  bool _isValidPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+')) return false;
    if (cleaned.length < 10 || cleaned.length > 15) return false;
    return true;
  }

  Future<void> _checkBanned() async {
    if (!_formKey.currentState!.validate()) return;

    final rawInput = _phoneController.text.trim();
    final phoneNumber = _formatPhoneNumber(rawInput);

    if (!_isValidPhoneNumber(phoneNumber)) {
      _showSnackbar('Nomor tidak valid. Gunakan format +62xxx', Colors.red);
      return;
    }

    setState(() {
      _isLoading = true;
      _hasResult = false;
      _phoneNumber = phoneNumber;
    });

    try {
      final result = await _simulateCheck(phoneNumber);

      setState(() {
        _isLoading = false;
        _hasResult = true;
        _isBanned = result['isBanned'];
        _statusMessage = result['message'];
        _bannedReason = result['reason'] ?? '';

        _saveHistory({
          'phone': phoneNumber,
          'isBanned': _isBanned,
          'message': _statusMessage,
          'reason': _bannedReason,
          'timestamp': DateTime.now().toIso8601String(),
        });
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
        _hasResult = true;
        _isBanned = false;
        _statusMessage = 'Terjadi kesalahan. Coba lagi nanti.';
      });
      _showSnackbar('Error: ${e.toString()}', Colors.red);
    }
  }

  Future<Map<String, dynamic>> _simulateCheck(String phoneNumber) async {
    await Future.delayed(const Duration(seconds: 2));

    final lastDigit = int.tryParse(phoneNumber.substring(phoneNumber.length - 1)) ?? 0;

    bool isBanned = lastDigit % 3 == 0;

    if (phoneNumber.contains('1111') || phoneNumber.contains('9999')) {
      isBanned = true;
    } else if (phoneNumber.contains('8888') || phoneNumber.contains('7777')) {
      isBanned = false;
    }

    String message;
    String reason = '';

    if (isBanned) {
      final reasons = [
        'Melanggar kebijakan WhatsApp',
        'Laporan spam dari pengguna lain',
        'Aktivitas mencurigakan terdeteksi',
        'Penggunaan aplikasi tidak resmi',
        'Broadcasting berlebihan',
      ];
      reason = reasons[lastDigit % reasons.length];
      message = '⚠️ Nomor ini TERBANED!';
    } else {
      final safeMessages = [
        '✅ Nomor AMAN!',
        '✅ Status Normal',
        '✅ Tidak terdeteksi banned',
        '✅ Bebas dari pembatasan',
      ];
      message = safeMessages[lastDigit % safeMessages.length];
    }

    return {
      'isBanned': isBanned,
      'message': message,
      'reason': reason,
    };
  }

  void _showSnackbar(String message, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: const TextStyle(color: Colors.white),
        ),
        backgroundColor: color.withOpacity(0.8),
        duration: const Duration(seconds: 3),
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(16),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bgDeep,
      appBar: _buildAppBar(),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _buildHeader(),
            const SizedBox(height: 20),
            _buildInputForm(),
            const SizedBox(height: 20),
            if (_isLoading) _buildLoadingWidget(),
            if (_hasResult && !_isLoading) _buildResultWidget(),
            if (_history.isNotEmpty) ...[
              const SizedBox(height: 20),
              _buildHistoryWidget(),
            ],
            const SizedBox(height: 20),
            _buildFooter(),
          ],
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: _bgCard,
      elevation: 0,
      leading: IconButton(
        icon: const Icon(Icons.arrow_back, color: _textLight),
        onPressed: () => Navigator.pop(context),
      ),
      title: Text(
        'CEK BANNED WA',
        style: TextStyle(
          color: _accentColor,
          fontWeight: FontWeight.bold,
          fontSize: 16,
          letterSpacing: 2,
          fontFamily: 'Orbitron',
          shadows: [
            Shadow(
              color: _accentGlow.withOpacity(0.3),
              blurRadius: 10,
            ),
          ],
        ),
      ),
      centerTitle: true,
      actions: [
        IconButton(
          icon: const Icon(Icons.history, color: _textSub),
          onPressed: () {
            setState(() {});
          },
        ),
      ],
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            _accentColor.withOpacity(0.1),
            _accentColor.withOpacity(0.05),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _accentColor.withOpacity(0.2)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: _accentColor.withOpacity(0.15),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _accentColor.withOpacity(0.2)),
            ),
            child: Icon(
              Icons.shield_outlined,
              color: _accentColor,
              size: 28,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Cek Status WhatsApp',
                  style: const TextStyle(
                    color: _textLight,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Cek apakah nomor WhatsApp Anda aman atau terkena banned',
                  style: TextStyle(
                    color: _textSub,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInputForm() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: _bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _accentColor.withOpacity(0.2)),
        boxShadow: [
          BoxShadow(
            color: _accentColor.withOpacity(0.05),
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
                  decoration: BoxDecoration(
                    color: _bgInput,
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(12),
                      bottomLeft: Radius.circular(12),
                    ),
                    border: Border.all(color: _accentColor.withOpacity(0.2)),
                  ),
                  child: Text(
                    '+62',
                    style: TextStyle(
                      color: _accentColor,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                ),
                Expanded(
                  child: TextFormField(
                    controller: _phoneController,
                    style: const TextStyle(color: _textLight, fontSize: 16),
                    cursorColor: _accentColor,
                    keyboardType: TextInputType.phone,
                    decoration: const InputDecoration(
                      hintText: '81234567890',
                      hintStyle: TextStyle(color: _textMuted, fontSize: 14),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.only(
                          topRight: Radius.circular(12),
                          bottomRight: Radius.circular(12),
                        ),
                        borderSide: BorderSide.none,
                      ),
                      filled: true,
                      fillColor: _bgInput,
                      contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                      prefixIcon: Icon(
                        Icons.phone_android_rounded,
                        color: _textMuted,
                        size: 20,
                      ),
                    ),
                    validator: (value) {
                      if (value == null || value.trim().isEmpty) {
                        return 'Masukkan nomor WhatsApp';
                      }
                      final cleaned = value.replaceAll(RegExp(r'[^\d]'), '');
                      if (cleaned.length < 8) {
                        return 'Nomor terlalu pendek';
                      }
                      return null;
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            SizedBox(
              height: 52,
              child: ElevatedButton(
                onPressed: _isLoading ? null : _checkBanned,
                style: ElevatedButton.styleFrom(
                  backgroundColor: _accentColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  elevation: 0,
                  side: BorderSide(
                    color: _accentGlow,
                    width: 1.5,
                  ),
                ),
                child: _isLoading
                    ? SizedBox(
                        width: 24,
                        height: 24,
                        child: CircularProgressIndicator(
                          strokeWidth: 2.5,
                          valueColor: AlwaysStoppedAnimation<Color>(_textLight),
                        ),
                      )
                    : Text(
                        'CEK BANNED',
                        style: TextStyle(
                          color: _textLight,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                          letterSpacing: 2,
                          shadows: [
                            Shadow(
                              color: Colors.black.withOpacity(0.3),
                              blurRadius: 5,
                            ),
                          ],
                        ),
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLoadingWidget() {
    return AnimatedBuilder(
      animation: _pulseAnimation,
      builder: (context, child) {
        return Container(
          padding: const EdgeInsets.all(30),
          decoration: BoxDecoration(
            color: _bgCard,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: _accentColor.withOpacity(0.2 + (_pulseAnimation.value * 0.3)),
            ),
            boxShadow: [
              BoxShadow(
                color: _accentGlow.withOpacity(0.1 * _pulseAnimation.value),
                blurRadius: 30,
                spreadRadius: 5,
              ),
            ],
          ),
          child: Column(
            children: [
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [
                      _accentColor.withOpacity(0.3),
                      _accentGlow.withOpacity(0.1),
                    ],
                  ),
                  border: Border.all(
                    color: _accentColor.withOpacity(0.3 + (_pulseAnimation.value * 0.3)),
                    width: 2 + (_pulseAnimation.value * 2),
                  ),
                ),
                child: Center(
                  child: Icon(
                    Icons.hourglass_top,
                    color: _accentColor.withOpacity(0.5 + (_pulseAnimation.value * 0.5)),
                    size: 30,
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Text(
                'Memeriksa Status...',
                style: TextStyle(
                  color: _textLight,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                'Mengecek nomor $_phoneNumber',
                style: TextStyle(
                  color: _textSub,
                  fontSize: 12,
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildResultWidget() {
    final isBanned = _isBanned;
    final icon = isBanned ? Icons.cancel_rounded : Icons.check_circle_rounded;
    final color = isBanned ? _dangerRed : _successGreen;
    final title = isBanned ? 'TERBANED!' : 'AMAN!';
    final subtitle = isBanned ? '❌ WhatsApp Anda Terbaned' : '✅ WhatsApp Anda Aman';

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: _bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: color.withOpacity(0.4),
          width: 2,
        ),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.15),
            blurRadius: 30,
            spreadRadius: 5,
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  shape: BoxShape.circle,
                  border: Border.all(color: color.withOpacity(0.3)),
                ),
                child: Icon(
                  icon,
                  color: color,
                  size: 40,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        color: color,
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: TextStyle(
                        color: _textSub,
                        fontSize: 13,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: _bgSurface,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: color.withOpacity(0.1)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.phone,
                      color: _textMuted,
                      size: 16,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      'Nomor: $_phoneNumber',
                      style: TextStyle(
                        color: _textLight,
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Icon(
                      isBanned ? Icons.warning : Icons.info,
                      color: color,
                      size: 16,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        _statusMessage,
                        style: TextStyle(
                          color: isBanned ? _dangerRed : _successGreen,
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
                if (isBanned && _bannedReason.isNotEmpty) ...[
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Icon(
                        Icons.description,
                        color: _textMuted,
                        size: 16,
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'Alasan: $_bannedReason',
                          style: TextStyle(
                            color: _textSub,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
                const SizedBox(height: 4),
                Row(
                  children: [
                    Icon(
                      Icons.access_time,
                      color: _textMuted,
                      size: 16,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      'Diperiksa: ${DateTime.now().toString().substring(0, 16)}',
                      style: TextStyle(
                        color: _textMuted,
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          if (isBanned) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _warningYellow.withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _warningYellow.withOpacity(0.2)),
              ),
              child: Row(
                children: [
                  Icon(
                    Icons.lightbulb_outline,
                    color: _warningYellow,
                    size: 20,
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      '💡 Tips: Hindari broadcast ke banyak kontak dan gunakan WhatsApp resmi untuk menghindari banned.',
                      style: TextStyle(
                        color: _textSub,
                        fontSize: 12,
                        height: 1.4,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildHistoryWidget() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _accentColor.withOpacity(0.1)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.history,
                color: _accentColor,
                size: 20,
              ),
              const SizedBox(width: 10),
              Text(
                'RIWAYAT PENCARIAN',
                style: TextStyle(
                  color: _textLight,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1,
                ),
              ),
              const Spacer(),
              TextButton(
                onPressed: () async {
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.remove('check_banned_history');
                  setState(() {
                    _history.clear();
                  });
                  _showSnackbar('Riwayat dihapus', _accentColor);
                },
                child: Text(
                  'Hapus',
                  style: TextStyle(
                    color: _dangerRed,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: _history.length > 5 ? 5 : _history.length,
            itemBuilder: (context, index) {
              final item = _history[index];
              final isBanned = item['isBanned'] ?? false;
              return Container(
                margin: const EdgeInsets.only(bottom: 4),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: _bgSurface,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: isBanned ? _dangerRed.withOpacity(0.2) : _successGreen.withOpacity(0.2),
                  ),
                ),
                child: Row(
                  children: [
                    Icon(
                      isBanned ? Icons.cancel : Icons.check_circle,
                      color: isBanned ? _dangerRed : _successGreen,
                      size: 16,
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        item['phone'] ?? '',
                        style: TextStyle(
                          color: _textLight,
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    Text(
                      isBanned ? 'Banned' : 'Aman',
                      style: TextStyle(
                        color: isBanned ? _dangerRed : _successGreen,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      item['timestamp']?.toString().substring(0, 10) ?? '',
                      style: TextStyle(
                        color: _textMuted,
                        fontSize: 10,
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
          if (_history.length > 5)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(
                '${_history.length - 5} lainnya...',
                style: TextStyle(
                  color: _textMuted,
                  fontSize: 10,
                  fontStyle: FontStyle.italic,
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildFooter() {
    return Center(
      child: Text(
        'Hasil pengecekan bersifat simulasi untuk keperluan demo.',
        style: TextStyle(
          color: _textMuted,
          fontSize: 10,
          fontStyle: FontStyle.italic,
        ),
        textAlign: TextAlign.center,
      ),
    );
  }
}