import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:intl/intl.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart'; // Import package share baru

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'iPhone Quote Chat',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF090D16),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF111827),
          elevation: 0,
        ),
      ),
      home: const IQCScreen(),
    );
  }
}

class IQCScreen extends StatefulWidget {
  const IQCScreen({super.key});

  @override
  State<IQCScreen> createState() => _IQCScreenState();
}

class _IQCScreenState extends State<IQCScreen> {
  final TextEditingController _textController = TextEditingController();
  final TextEditingController _chatTimeController = TextEditingController();
  final TextEditingController _statusBarTimeController = TextEditingController();
  
  Uint8List? _generatedImage;
  bool _isGenerating = false;
  bool _isSaving = false;
  String? _errorMessage;
  
  @override
  void initState() {
    super.initState();
    final timeFormat = DateFormat('HH:mm');
    final now = DateTime.now();
    _chatTimeController.text = timeFormat.format(now);
    _statusBarTimeController.text = timeFormat.format(now);
    _textController.text = 'sky ganteng';
  }

  bool _isValidTime(String time) {
    final dynamicRegex = RegExp(r'^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$');
    return dynamicRegex.hasMatch(time);
  }

  Future<void> _generateIQCImage() async {
    if (_textController.text.isEmpty) {
      _showError('Masukkan teks chat terlebih dahulu');
      return;
    }

    if (_chatTimeController.text.isEmpty || _statusBarTimeController.text.isEmpty) {
      _showError('Masukkan waktu chat dan status bar');
      return;
    }

    if (!_isValidTime(_chatTimeController.text)) {
      _showError('Format waktu chat salah (gunakan HH:mm)');
      return;
    }

    if (!_isValidTime(_statusBarTimeController.text)) {
      _showError('Format waktu status bar salah (gunakan HH:mm)');
      return;
    }

    setState(() {
      _isGenerating = true;
      _errorMessage = null;
      _generatedImage = null;
    });

    try {
      final text = Uri.encodeComponent(_textController.text);
      final chatTime = Uri.encodeComponent(_chatTimeController.text);
      final statusBarTime = Uri.encodeComponent(_statusBarTimeController.text);
      
      // API Tetap berjalan di background tanpa di-spill ke UI
      final apiUrl = 'https://api.deline.web.id/maker/iqc?text=$text&chatTime=$chatTime&statusBarTime=$statusBarTime';
      
      final response = await http.get(
        Uri.parse(apiUrl),
        headers: {
          'User-Agent': 'IQC-Screenshot-Maker/1.0',
        },
      ).timeout(const Duration(seconds: 30));
      
      if (response.statusCode == 200) {
        if (response.bodyBytes.isNotEmpty) {
          setState(() {
            _generatedImage = response.bodyBytes;
          });
          _showSuccess('Gambar berhasil dihasilkan');
        } else {
          throw Exception('API mengembalikan data kosong');
        }
      } else {
        throw Exception('API Error: ${response.statusCode}');
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Gagal menghubungi server pembuat gambar';
      });
      _showError(_errorMessage!);
    } finally {
      setState(() {
        _isGenerating = false;
      });
    }
  }

  // Fungsi share image langsung tanpa wajib simpan internal storage duluan
  Future<void> _shareImage() async {
    if (_generatedImage == null) {
      _showError('Tidak ada gambar untuk dibagikan');
      return;
    }

    try {
      final tempDir = await getTemporaryDirectory();
      final timestamp = DateFormat('yyyyMMdd_HHmmss').format(DateTime.now());
      final file = await File('${tempDir.path}/iqc_share_$timestamp.png').create();
      await file.writeAsBytes(_generatedImage!);

      // Memanggil fungsi share bawaan sistem hp lo
      await Share.shareXFiles([XFile(file.path)], text: 'Hasil IQC Screenshot Maker');
    } catch (e) {
      _showError('Gagal membagikan gambar: $e');
    }
  }

  Future<void> _saveImage() async {
    if (_generatedImage == null) {
      _showError('Tidak ada gambar untuk disimpan');
      return;
    }

    setState(() {
      _isSaving = true;
    });

    try {
      final status = await Permission.storage.request();
      if (!status.isGranted) {
        throw Exception('Izin penyimpanan dibutuhkan');
      }

      final directory = await getExternalStorageDirectory();
      final downloadPath = '${directory!.path}/Download';
      final downloadDir = Directory(downloadPath);
      
      if (!downloadDir.existsSync()) {
        downloadDir.createSync(recursive: true);
      }

      final timestamp = DateFormat('yyyyMMdd_HHmmss').format(DateTime.now());
      final fileName = 'iqc_${_textController.text.replaceAll(' ', '_')}_$timestamp.png';
      final filePath = '$downloadPath/$fileName';
      final file = File(filePath);
      
      await file.writeAsBytes(_generatedImage!);

      _showSuccess('Gambar disimpan di: Download/$fileName');
      _showSaveSuccessDialog(filePath, fileName);
      
    } catch (e) {
      // JIKA GAGAL SIMPAN LANGSUNG OTOMATIS DI-ALIHKAN KE SISTEM SHARE JALUR AMAN
      _showError('Gagal simpan langsung. Mengalihkan ke menu Share...');
      _shareImage();
    } finally {
      setState(() {
        _isSaving = false;
      });
    }
  }

  void _showSuccess(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w500)),
        backgroundColor: const Color(0xFF059669),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w500)),
        backgroundColor: const Color(0xFFDC2626),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  void _showSaveSuccessDialog(String filePath, String fileName) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF111827),
        title: const Text(
          'Gambar Disimpan!',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Gambar berhasil disimpan di:',
              style: TextStyle(color: Colors.white70),
            ),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFF090D16),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                'Download/$fileName',
                style: const TextStyle(
                  color: Color(0xFF38BDF8),
                  fontFamily: 'monospace',
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _shareImage(); // Sediakan juga tombol share cepat di dalam pop-up sukses
            },
            child: const Text('SHARE GAMBAR', style: TextStyle(color: Color(0xFF38BDF8))),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK', style: TextStyle(color: Colors.white70)),
          ),
        ],
      ),
    );
  }

  Widget _buildInputField({
    required String label,
    required TextEditingController controller,
    String hint = '',
    bool isTime = false,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            color: Colors.white70,
            fontSize: 14,
            fontWeight: FontWeight.w600,
            letterSpacing: 0.5,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: const Color(0xFF111827),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: const Color(0xFF1F2937),
              width: 1.5,
            ),
          ),
          child: TextField(
            controller: controller,
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: const TextStyle(color: Colors.white38),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 14,
              ),
              suffixIcon: isTime
                  ? IconButton(
                      onPressed: () {
                        final timeFormat = DateFormat('HH:mm');
                        final now = DateTime.now();
                        controller.text = timeFormat.format(now);
                      },
                      icon: const Icon(Icons.access_time_filled, color: Color(0xFF2563EB)),
                      tooltip: 'Gunakan waktu sekarang',
                    )
                  : null,
            ),
            style: const TextStyle(color: Colors.white, fontSize: 16),
            maxLines: isTime ? 1 : 3,
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'iPhone Quote Chat', 
          style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 0.8)
        ),
        centerTitle: true,
        actions: [
          if (_generatedImage != null) ...[
            // TOMBOL SHARE DI APP BAR
            IconButton(
              onPressed: _shareImage,
              icon: const Icon(Icons.share_rounded, color: Colors.white),
              tooltip: 'Bagikan Gambar',
            ),
            // TOMBOL SIMPAN DI APP BAR
            IconButton(
              onPressed: _isSaving ? null : _saveImage,
              icon: _isSaving 
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white,
                      ),
                    )
                  : const Icon(Icons.download_rounded, color: Colors.white),
              tooltip: 'Simpan Gambar',
            ),
          ],
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: const Color(0xFF111827),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFF1F2937), width: 1),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.4),
                    blurRadius: 12,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: Column(
                children: [
                  _buildInputField(
                    label: 'Teks Chat',
                    controller: _textController,
                    hint: 'Masukkan teks chat...',
                  ),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(
                        child: _buildInputField(
                          label: 'Waktu Chat',
                          controller: _chatTimeController,
                          hint: 'HH:mm',
                          isTime: true,
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: _buildInputField(
                          label: 'Waktu Status Bar',
                          controller: _statusBarTimeController,
                          hint: 'HH:mm',
                          isTime: true,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: const [
                      Icon(Icons.info_rounded, size: 14, color: Color(0xFF6B7280)),
                      const SizedBox(width: 6),
                      Text(
                        'Format waktu: HH:mm (contoh: 22:11)',
                        style: TextStyle(
                          color: Color(0xFF6B7280),
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),
                  SizedBox(
                    width: double.infinity,
                    height: 56,
                    child: ElevatedButton.icon(
                      onPressed: _isGenerating ? null : _generateIQCImage,
                      icon: _isGenerating 
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            )
                          : const Icon(Icons.auto_awesome_rounded),
                      label: Text(
                        _isGenerating ? 'SEDANG MEMBUAT...' : 'BUAT SCREENSHOT',
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1,
                        ),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF2563EB),
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        elevation: 4,
                      ),
                    ),
                  ),
                  if (_errorMessage != null) ...[
                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: const Color(0xFFDC2626).withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: const Color(0xFFDC2626).withOpacity(0.5)),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.error_outline_rounded, color: Color(0xFFEF4444)),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              _errorMessage!,
                              style: const TextStyle(color: Colors.white70, fontSize: 13),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ],
              ),
            ),
            
            // NOTE: BAGIAN KOTAK API ENDPOINT KINI SUDAH DIHAPUS SEPENUHNYA DARI SINI
            
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: const Color(0xFF111827),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFF1F2937)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.4),
                    blurRadius: 12,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(
                    children: [
                      Icon(Icons.remove_red_eye_rounded, color: Color(0xFF2563EB)),
                      SizedBox(width: 8),
                      Text(
                        'Hasil Screenshot',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  if (_generatedImage != null)
                    Container(
                      width: double.infinity,
                      constraints: const BoxConstraints(
                        maxHeight: 600,
                      ),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.5),
                            blurRadius: 20,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: Image.memory(
                          _generatedImage!,
                          fit: BoxFit.contain,
                          errorBuilder: (context, error, stackTrace) {
                            return Container(
                              height: 300,
                              decoration: BoxDecoration(
                                color: const Color(0xFF090D16),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: const Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.broken_image_rounded,
                                    size: 64,
                                    color: Color(0xFFDC2626),
                                  ),
                                  SizedBox(height: 16),
                                  Text(
                                    'Gagal memuat gambar',
                                    style: TextStyle(
                                      color: Colors.white60,
                                    ),
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                      ),
                    )
                  else
                    Container(
                      height: 300,
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: const Color(0xFF090D16),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: const Color(0xFF1F2937),
                          width: 2,
                        ),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const [
                          Icon(
                            Icons.screenshot_rounded,
                            size: 80,
                            color: Color(0xFF1F2937),
                          ),
                          SizedBox(height: 20),
                          Text(
                            'Belum ada screenshot',
                            style: TextStyle(
                              color: Colors.white54,
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          SizedBox(height: 8),
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 20),
                            child: Text(
                              'Masukkan teks dan waktu, lalu klik "Buat Screenshot"',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: Colors.white38,
                                fontSize: 14,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  if (_generatedImage != null) ...[
                    const SizedBox(height: 20),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Ukuran: ${(_generatedImage!.lengthInBytes / 1024).toStringAsFixed(1)} KB',
                          style: const TextStyle(
                            color: Colors.white38,
                            fontSize: 12,
                          ),
                        ),
                        Text(
                          'Dibuat: ${DateFormat('HH:mm:ss').format(DateTime.now())}',
                          style: const TextStyle(
                            color: Colors.white38,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
            ),
            
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: const Color(0xFF111827),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFF1F2937)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Contoh Cepat:',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      _buildExampleChip('Ganteng bet gw', '20:00', '20:05'),
                      _buildExampleChip('Besok ketemuan dimana?', '15:30', '15:45'),
                      _buildExampleChip('Lagi apa?', '21:15', '21:20'),
                      _buildExampleChip('Udah makan belum?', '12:00', '12:10'),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Widget _buildExampleChip(String text, String chatTime, String statusBarTime) {
    return GestureDetector(
      onTap: () {
        setState(() {
          _textController.text = text;
          _chatTimeController.text = chatTime;
          _statusBarTimeController.text = statusBarTime;
        });
        _showSuccess('Contoh diterapkan');
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: const Color(0xFF1F2937),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFF374151)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              text.length > 20 ? '${text.substring(0, 20)}...' : text,
              style: const TextStyle(
                color: Color(0xFFEEEEEE),
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              '$chatTime | $statusBarTime',
              style: const TextStyle(
                color: Colors.white38,
                fontSize: 10,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
