import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

void main() {
  runApp(const KalkulatorApp());
}

class KalkulatorApp extends StatelessWidget {
  const KalkulatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'kalkulator',
      theme: ThemeData.dark().copyWith(
        primaryColor: const Color(0xFF06070D),
        scaffoldBackgroundColor: const Color(0xFF06070D), // Ultra Dark Obsidian
      ),
      debugShowCheckedModeBanner: false,
      home: const KalkulatorPage(),
    );
  }
}

class KalkulatorPage extends StatefulWidget {
  const KalkulatorPage({super.key});

  @override
  State<KalkulatorPage> createState() => _KalkulatorPageState();
}

class _KalkulatorPageState extends State<KalkulatorPage> {
  String _display = "0";
  String _expression = "";
  String _lastResult = "";
  bool _isNewCalculation = true;
  
  final List<Map<String, dynamic>> _history = [];
  final ScrollController _scrollController = ScrollController();
  
  bool _isTyping = false;
  String _currentTypingResult = "";
  Timer? _typingTimer;
  int _typingIndex = 0;
  
  // UI Palette Baru: Cyber-Cyber Neon Premium
  final Color primaryDark = const Color(0xFF06070D);      // Hitam Ruang Angkasa
  final Color cardDark = const Color(0xFF0F111A);         // Deep Navy Charcoal
  final Color buttonNormal = const Color(0xFF151926);     // Tombol Angka (Glossy Dark)
  final Color neonCyan = const Color(0xFF00F2FE);         // Neon Cyan Utama
  final Color neonPurple = const Color(0xFF4FACFE);       // Electric Blue Utama
  final Color neonRed = const Color(0xFFFF0844);          // Neon Red untuk Hapus

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  void _loadHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final historyJson = prefs.getStringList('kalkulator_history');
    if (historyJson != null) {
      setState(() {
        _history.clear();
        for (var json in historyJson) {
          try {
            _history.add(jsonDecode(json));
          } catch (e) {}
        }
      });
    }
  }

  void _saveHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final historyJson = _history.map((item) => jsonEncode(item)).toList();
    await prefs.setStringList('kalkulator_history', historyJson);
  }

  void _addToHistory(String expression, String result) {
    setState(() {
      _history.insert(0, {
        'expression': expression,
        'result': result,
        'timestamp': DateTime.now().toIso8601String(),
      });
      if (_history.length > 50) _history.removeLast();
    });
    _saveHistory();
  }

  void _buttonPressed(String value) {
    setState(() {
      if (_isTyping) {
        _typingTimer?.cancel();
        _isTyping = false;
      }
      
      if (_isNewCalculation && _isNumber(value)) {
        _display = value;
        _expression = value;
        _isNewCalculation = false;
      } else if (value == "C") {
        _clear();
      } else if (value == "⌫") {
        _backspace();
      } else if (value == "=") {
        _calculate();
      } else if (value == "±") {
        _toggleSign();
      } else if (value == "%") {
        _percentage();
      } else {
        _addToExpression(value);
      }
    });
  }

  bool _isNumber(String value) {
    return RegExp(r'^[0-9.]$').hasMatch(value);
  }

  void _clear() {
    _display = "0";
    _expression = "";
    _isNewCalculation = true;
    _lastResult = "";
  }

  void _backspace() {
    if (_expression.isNotEmpty) {
      _expression = _expression.substring(0, _expression.length - 1);
      _display = _expression.isEmpty ? "0" : _expression;
      _isNewCalculation = false;
    } else if (_display != "0") {
      _display = "0";
      _isNewCalculation = true;
    }
  }

  void _toggleSign() {
    double current = double.parse(_display);
    current = -current;
    if (current == current.toInt()) {
      _display = current.toInt().toString();
    } else {
      _display = current.toString();
    }
    _expression = _display;
    _isNewCalculation = false;
  }

  void _percentage() {
    double current = double.parse(_display);
    current = current / 100;
    if (current == current.toInt()) {
      _display = current.toInt().toString();
    } else {
      _display = current.toString();
    }
    _expression = _display;
    _isNewCalculation = false;
  }

  void _addToExpression(String value) {
    if (_expression.isEmpty && (value == "×" || value == "÷" || value == "+" || value == "-")) {
      return;
    }
    
    _expression += _convertOperator(value);
    _display = _expression;
    _isNewCalculation = false;
  }

  String _convertOperator(String op) {
    switch(op) {
      case "×": return "*";
      case "÷": return "/";
      default: return op;
    }
  }

  void _calculate() {
    if (_expression.isEmpty) return;
    
    try {
      String expr = _expression.replaceAll("×", "*").replaceAll("÷", "/");
      
      double result = _evaluateExpression(expr);
      
      String resultStr;
      if (result == result.toInt()) {
        resultStr = result.toInt().toString();
      } else {
        resultStr = result.toStringAsFixed(8).replaceAll(RegExp(r'0+$'), '').replaceAll(RegExp(r'\.$'), '');
      }
      
      _startTypingAnimation(resultStr);
      _addToHistory(_expression, resultStr);
      
      _lastResult = resultStr;
      _expression = resultStr;
      
    } catch (e) {
      _display = "Error";
      _expression = "";
      _isNewCalculation = true;
      
      Future.delayed(const Duration(seconds: 1), () {
        if (mounted) {
          setState(() {
            _display = "0";
          });
        }
      });
    }
  }

  double _evaluateExpression(String expression) {
    List<String> tokens = _tokenize(expression);
    List<double> numbers = [];
    List<String> operators = [];
    
    for (var token in tokens) {
      if (token == "+" || token == "-" || token == "*" || token == "/") {
        operators.add(token);
      } else {
        numbers.add(double.parse(token));
      }
    }
    
    for (int i = 0; i < operators.length; i++) {
      if (operators[i] == "*" || operators[i] == "/") {
        double result;
        if (operators[i] == "*") {
          result = numbers[i] * numbers[i + 1];
        } else {
          if (numbers[i + 1] == 0) throw Exception("Division by zero");
          result = numbers[i] / numbers[i + 1];
        }
        numbers[i] = result;
        numbers.removeAt(i + 1);
        operators.removeAt(i);
        i--;
      }
    }
    
    double result = numbers[0];
    for (int i = 0; i < operators.length; i++) {
      if (operators[i] == "+") {
        result += numbers[i + 1];
      } else if (operators[i] == "-") {
        result -= numbers[i + 1];
      }
    }
    
    return result;
  }

  List<String> _tokenize(String expression) {
    List<String> tokens = [];
    String currentNumber = "";
    
    for (int i = 0; i < expression.length; i++) {
      String char = expression[i];
      if (char == "+" || char == "-" || char == "*" || char == "/") {
        if (currentNumber.isNotEmpty) {
          tokens.add(currentNumber);
          currentNumber = "";
        }
        tokens.add(char);
      } else {
        currentNumber += char;
      }
    }
    
    if (currentNumber.isNotEmpty) {
      tokens.add(currentNumber);
    }
    
    return tokens;
  }

  void _startTypingAnimation(String result) {
    setState(() {
      _isTyping = true;
      _currentTypingResult = "";
      _typingIndex = 0;
    });
    
    _typingTimer?.cancel();
    _typingTimer = Timer.periodic(const Duration(milliseconds: 30), (timer) {
      if (_typingIndex < result.length) {
        setState(() {
          _currentTypingResult = result.substring(0, _typingIndex + 1);
          _display = _currentTypingResult;
          _typingIndex++;
        });
      } else {
        timer.cancel();
        setState(() {
          _isTyping = false;
          _display = result;
          _expression = result;
          _isNewCalculation = true;
        });
      }
    });
  }

  void _clearHistory() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardDark,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: const Text('Clear History', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        content: const Text('Apakah Anda yakin ingin menghapus semua riwayat perhitungan?', style: TextStyle(color: Colors.white70)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal', style: TextStyle(color: Colors.white38)),
          ),
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              setState(() {
                _history.clear();
              });
              final prefs = await SharedPreferences.getInstance();
              await prefs.remove('kalkulator_history');
            },
            child: Text('Clear', style: TextStyle(color: neonCyan, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _typingTimer?.cancel();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryDark,
      appBar: AppBar(
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [neonPurple, neonCyan]),
                borderRadius: BorderRadius.circular(14),
                boxShadow: [
                  BoxShadow(color: neonCyan.withOpacity(0.3), blurRadius: 10, spreadRadius: 1)
                ],
              ),
              child: const Icon(Icons.blur_on_rounded, color: Colors.white, size: 20),
            ),
            const SizedBox(width: 14),
            const Text(
              'KALKULATOR',
              style: TextStyle(fontWeight: FontWeight.w900, color: Colors.white, letterSpacing: 1.5, fontSize: 14),
            ),
          ],
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          if (_history.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.auto_delete_outlined, color: Colors.white60),
              onPressed: _clearHistory,
            ),
        ],
      ),
      body: Column(
        children: [
          // Screen Utama: Efek Glassmorphic Mengkilap + Neon Outline Border
          Container(
            margin: const EdgeInsets.all(20),
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 26),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [cardDark.withOpacity(0.8), primaryDark],
              ),
              borderRadius: BorderRadius.circular(32),
              border: Border.all(color: neonCyan.withOpacity(0.25), width: 1.5),
              boxShadow: [
                BoxShadow(
                  color: neonCyan.withOpacity(0.06),
                  blurRadius: 30,
                  spreadRadius: 2,
                  offset: const Offset(0, 10),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                if (_expression.isNotEmpty && !_isNewCalculation)
                  Text(
                    _expression.replaceAll("*", "×").replaceAll("/", "÷"),
                    style: const TextStyle(
                      fontSize: 20,
                      color: Colors.white30,
                      fontWeight: FontWeight.w400,
                      letterSpacing: 1.0,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                const SizedBox(height: 14),
                ShaderMask(
                  shaderCallback: (bounds) => LinearGradient(
                    colors: [Colors.white, neonPurple.withOpacity(0.8)],
                  ).createShader(bounds),
                  child: Text(
                    _display,
                    style: TextStyle(
                      fontSize: _display.length > 10 ? 36 : 56,
                      fontWeight: FontWeight.w800,
                      color: Colors.white,
                      letterSpacing: 1.0,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ),
          
          // Panel Riwayat Horizontal Minimalis
          if (_history.isNotEmpty)
            Container(
              height: 100,
              margin: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'HISTORY LOG',
                    style: TextStyle(color: Colors.white24, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 2.0),
                  ),
                  const SizedBox(height: 10),
                  Expanded(
                    child: ListView.builder(
                      controller: _scrollController,
                      scrollDirection: Axis.horizontal,
                      itemCount: _history.length,
                      itemBuilder: (context, index) {
                        final item = _history[index];
                        return Container(
                          margin: const EdgeInsets.only(right: 12, bottom: 10),
                          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                          decoration: BoxDecoration(
                            color: cardDark.withOpacity(0.5),
                            borderRadius: BorderRadius.circular(18),
                            border: Border.all(color: Colors.white.withOpacity(0.03)),
                          ),
                          child: Row(
                            children: [
                              Text(
                                item['expression'].replaceAll("*", "×").replaceAll("/", "÷"),
                                style: const TextStyle(color: Colors.white38, fontSize: 13),
                              ),
                              const SizedBox(width: 8),
                              Text(
                                "= ${item['result']}",
                                style: TextStyle(
                                  color: neonCyan,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 14,
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          
          const SizedBox(height: 4),
          
          // Grid Tombol-Tombol Bulat Bergaya Modern Cyberpunk
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14),
              child: Column(
                children: [
                  _buildButtonRow(["C", "⌫", "%", "÷"]),
                  _buildButtonRow(["7", "8", "9", "×"]),
                  _buildButtonRow(["4", "5", "6", "-"]),
                  _buildButtonRow(["1", "2", "3", "+"]),
                  _buildButtonRow(["±", "0", ".", "="]),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
        ],
      ),
    );
  }

  Widget _buildButtonRow(List<String> values) {
    return Expanded(
      child: Row(
        children: values.map((value) {
          return _buildButton(value);
        }).toList(),
      ),
    );
  }

  Widget _buildButton(String text) {
    bool isOperator = text == "+" || text == "-" || text == "×" || text == "÷";
    bool isEqual = text == "=";
    bool isClear = text == "C" || text == "⌫";
    bool isSpecial = text == "%" || text == "±";
    
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: () => _buttonPressed(text),
            borderRadius: BorderRadius.circular(100),
            splashColor: neonCyan.withOpacity(0.2),
            highlightColor: neonPurple.withOpacity(0.1),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 150),
              decoration: BoxDecoration(
                gradient: isEqual
                    ? LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [neonPurple, neonCyan],
                      )
                    : null,
                color: isEqual ? null : buttonNormal,
                shape: BoxShape.circle,
                border: Border.all(
                  color: isEqual 
                      ? Colors.transparent 
                      : isOperator || isSpecial 
                          ? neonCyan.withOpacity(0.15) 
                          : Colors.white.withOpacity(0.02),
                  width: 1.5,
                ),
                boxShadow: [
                  if (isEqual)
                    BoxShadow(
                      color: neonCyan.withOpacity(0.35),
                      blurRadius: 18,
                      offset: const Offset(0, 5),
                    ),
                ],
              ),
              child: Center(
                child: Text(
                  text,
                  style: TextStyle(
                    fontSize: isOperator || isEqual ? 24 : 22,
                    fontWeight: FontWeight.w700,
                    color: isEqual
                        ? Colors.black
                        : isOperator || isSpecial
                            ? neonCyan
                            : isClear
                                ? neonRed
                                : Colors.white.withOpacity(0.9),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
