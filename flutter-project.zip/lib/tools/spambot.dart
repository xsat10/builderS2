import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'dart:ui';
import 'package:video_player/video_player.dart';

class SpamBotPage extends StatefulWidget {
  final String sessionKey;
  const SpamBotPage({super.key, required this.sessionKey});

  @override
  State<SpamBotPage> createState() => _SpamBotPageState();
}

class _SpamBotPageState extends State<SpamBotPage>
    with SingleTickerProviderStateMixin {
  final TextEditingController _tokenController = TextEditingController();
  final TextEditingController _idController = TextEditingController();
  final TextEditingController _msgController = TextEditingController();
  final TextEditingController _delayController = TextEditingController(text: "1000");
  final TextEditingController _countController = TextEditingController(text: "10");
  bool _isSpamming = false;

  // Video Player
  late VideoPlayerController _videoController;
  bool _isVideoInitialized = false;

  // Animations
  late AnimationController _slideController;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _scaleAnimation;

  // Colors
  final Color primaryBlue = const Color(0xFF1A73E8);
  final Color darkBlue = const Color(0xFF0D2A4A);
  final Color lightBlue = const Color(0xFF42A5F5);
  final Color silver = const Color(0xFFB8C6D9);
  final Color deepBlack = const Color(0xFF0A0E1A);

  late AnimationController _pulseController;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);

    _videoController = VideoPlayerController.asset('assets/videos/banner.mp4');
    _videoController.initialize().then((_) {
      setState(() {
        _videoController.setVolume(1);
        _videoController.setLooping(true);
        _videoController.play();
        _isVideoInitialized = true;
      });
    }).catchError((error) {
      print("Video init error: $error");
      setState(() {
        _isVideoInitialized = false;
      });
    });

    _slideController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..forward();

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _slideController,
      curve: Curves.easeOutCubic,
    ));

    _scaleAnimation = Tween<double>(begin: 0.95, end: 1.0).animate(
      CurvedAnimation(
        parent: _slideController,
        curve: Curves.easeOutCubic,
      ),
    );
  }

  @override
  void dispose() {
    _tokenController.dispose();
    _idController.dispose();
    _msgController.dispose();
    _delayController.dispose();
    _countController.dispose();
    _pulseController.dispose();
    _videoController.dispose();
    _slideController.dispose();
    super.dispose();
  }

  void _showPremiumDialog(String title, String message, {bool isError = true}) {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (_) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: AlertDialog(
          backgroundColor: Colors.transparent,
          elevation: 0,
          contentPadding: EdgeInsets.zero,
          content: Container(
            width: MediaQuery.of(context).size.width * 0.85,
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  darkBlue.withOpacity(0.95),
                  deepBlack.withOpacity(0.98),
                ],
              ),
              borderRadius: BorderRadius.circular(24),
              border: Border.all(
                color: isError ? Colors.redAccent.withOpacity(0.4) : lightBlue.withOpacity(0.4),
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: isError ? Colors.red.withOpacity(0.2) : primaryBlue.withOpacity(0.25),
                  blurRadius: 40,
                  spreadRadius: 5,
                ),
                BoxShadow(
                  color: Colors.black.withOpacity(0.6),
                  blurRadius: 30,
                  offset: const Offset(0, 10),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: isError
                          ? [Colors.red.shade700, Colors.red.shade900]
                          : [primaryBlue, lightBlue],
                    ),
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: (isError ? Colors.red : primaryBlue).withOpacity(0.5),
                        blurRadius: 20,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: Icon(
                    isError ? Icons.warning_amber_rounded : Icons.check_circle_rounded,
                    color: Colors.white,
                    size: 32,
                  ),
                ),
                const SizedBox(height: 20),
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: isError ? Colors.redAccent : lightBlue,
                    letterSpacing: 1.2,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 12),
                Text(
                  message,
                  style: TextStyle(
                    fontSize: 14,
                    color: silver.withOpacity(0.8),
                    height: 1.5,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 24),
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: isError
                            ? [Colors.red.shade700, Colors.red.shade900]
                            : [primaryBlue, darkBlue],
                      ),
                      borderRadius: BorderRadius.circular(14),
                      boxShadow: [
                        BoxShadow(
                          color: (isError ? Colors.red : primaryBlue).withOpacity(0.3),
                          blurRadius: 15,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: Center(
                      child: Text(
                        "MENGERTI",
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                          letterSpacing: 2,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showWarning(String message) {
    _showPremiumDialog("⚠️ PERINGATAN", message, isError: true);
  }

  void _showSuccess(String message) {
    _showPremiumDialog("✅ SUKSES", message, isError: false);
  }

  Future<void> _startSpam() async {
    if (_tokenController.text.trim().isEmpty ||
        _idController.text.trim().isEmpty ||
        _msgController.text.trim().isEmpty ||
        _delayController.text.trim().isEmpty ||
        _countController.text.trim().isEmpty) {
      _showWarning("Semua kolom harus diisi! Jangan ada yang kosong.");
      return;
    }

    if (!_tokenController.text.contains(':') || _tokenController.text.length < 15) {
      _showWarning("Format Bot Token salah! Pastikan token valid dari BotFather.");
      return;
    }

    final int? idCheck = int.tryParse(_idController.text.trim());
    final int? delay = int.tryParse(_delayController.text.trim());
    final int? count = int.tryParse(_countController.text.trim());

    if (idCheck == null) {
      _showWarning("Target ID harus berupa angka!");
      return;
    }
    if (delay == null || delay < 100) {
      _showWarning("Delay harus berupa angka dan minimal 100ms!");
      return;
    }
    if (count == null || count <= 0) {
      _showWarning("Count (Jumlah) harus berupa angka lebih dari 0!");
      return;
    }

    setState(() => _isSpamming = true);

    for (int i = 0; i < count; i++) {
      if (!_isSpamming) break;
      try {
        await http.post(
          Uri.parse("https://api.telegram.org/bot${_tokenController.text.trim()}/sendMessage"),
          body: {"chat_id": _idController.text.trim(), "text": _msgController.text},
        );
      } catch (e) {
        debugPrint("Error: $e");
      }
      await Future.delayed(Duration(milliseconds: delay));
    }

    if (mounted) {
      setState(() => _isSpamming = false);
      _showSuccess("Spam selesai! $count pesan terkirim.");
    }
  }

  void _stopSpam() {
    setState(() => _isSpamming = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        title: ShaderMask(
          shaderCallback: (bounds) => LinearGradient(
            colors: [lightBlue, primaryBlue],
          ).createShader(bounds),
          child: const Text(
            "SPAM BOT TELE",
            style: TextStyle(
              fontFamily: "Orbitron",
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.white,
              letterSpacing: 2,
            ),
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                darkBlue.withOpacity(0.3),
                Colors.transparent,
              ],
            ),
          ),
        ),
      ),
      body: Stack(
        children: [
          // Video Background
          if (_isVideoInitialized)
            Positioned.fill(
              child: Opacity(
                opacity: 0.25,
                child: FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: _videoController.value.size.width,
                    height: _videoController.value.size.height,
                    child: VideoPlayer(_videoController),
                  ),
                ),
              ),
            )
          else
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [const Color(0xFF0D1B2A), deepBlack],
                  ),
                ),
              ),
            ),

          // Overlay gelap
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withOpacity(0.6),
                    Colors.black.withOpacity(0.8),
                  ],
                ),
              ),
            ),
          ),

          // Konten utama - gaya NGL
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  // Header sederhana
                  SlideTransition(
                    position: _slideAnimation,
                    child: ScaleTransition(
                      scale: _scaleAnimation,
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        child: Column(
                          children: [
                            Text(
                              "AUTO SPAM BOT",
                              style: TextStyle(
                                fontSize: 14,
                                fontFamily: "Orbitron",
                                color: silver,
                                letterSpacing: 1.5,
                              ),
                            ),
                            Text(
                              "Telegram Mass Messaging",
                              style: TextStyle(
                                fontSize: 11,
                                color: silver.withOpacity(0.6),
                                letterSpacing: 1,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 16),

                  // Input fields
                  Expanded(
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          // Input Token
                          SlideTransition(
                            position: _slideAnimation,
                            child: ScaleTransition(
                              scale: _scaleAnimation,
                              child: _buildTextField(
                                icon: FontAwesomeIcons.robot,
                                label: "Bot Token",
                                controller: _tokenController,
                                hint: "123456:ABC-DEF...",
                              ),
                            ),
                          ),
                          const SizedBox(height: 12),

                          // Input ID
                          SlideTransition(
                            position: _slideAnimation,
                            child: ScaleTransition(
                              scale: _scaleAnimation,
                              child: _buildTextField(
                                icon: FontAwesomeIcons.idBadge,
                                label: "Target ID",
                                controller: _idController,
                                hint: "987654321",
                              ),
                            ),
                          ),
                          const SizedBox(height: 12),

                          // Input Message
                          SlideTransition(
                            position: _slideAnimation,
                            child: ScaleTransition(
                              scale: _scaleAnimation,
                              child: _buildTextField(
                                icon: FontAwesomeIcons.commentDots,
                                label: "Message",
                                controller: _msgController,
                                hint: "Ghost Crasher...",
                                maxLines: 3,
                              ),
                            ),
                          ),
                          const SizedBox(height: 12),

                          // Row Delay & Count
                          SlideTransition(
                            position: _slideAnimation,
                            child: ScaleTransition(
                              scale: _scaleAnimation,
                              child: Row(
                                children: [
                                  Expanded(
                                    child: _buildTextField(
                                      icon: Icons.timer,
                                      label: "Delay (ms)",
                                      controller: _delayController,
                                      hint: "1000",
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: _buildTextField(
                                      icon: Icons.numbers,
                                      label: "Count",
                                      controller: _countController,
                                      hint: "10",
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(height: 24),

                          // Tombol Start/Stop
                          SlideTransition(
                            position: _slideAnimation,
                            child: ScaleTransition(
                              scale: _scaleAnimation,
                              child: AnimatedBuilder(
                                animation: _pulseController,
                                builder: (context, child) {
                                  return Container(
                                    width: double.infinity,
                                    height: 50,
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                        colors: _isSpamming
                                            ? [Colors.red.shade700, Colors.red.shade900]
                                            : [primaryBlue, darkBlue],
                                        begin: Alignment.topLeft,
                                        end: Alignment.bottomRight,
                                      ),
                                      borderRadius: BorderRadius.circular(12),
                                      boxShadow: [
                                        BoxShadow(
                                          color: _isSpamming
                                              ? Colors.red.withOpacity(0.35 + (_pulseController.value * 0.3))
                                              : primaryBlue.withOpacity(0.25 + (_pulseController.value * 0.15)),
                                          blurRadius: _isSpamming ? 30 + (_pulseController.value * 15) : 20,
                                          spreadRadius: _isSpamming ? 2 + (_pulseController.value * 3) : 0,
                                          offset: const Offset(0, 4),
                                        ),
                                      ],
                                    ),
                                    child: ElevatedButton(
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: Colors.transparent,
                                        shadowColor: Colors.transparent,
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(12),
                                        ),
                                        elevation: 0,
                                      ),
                                      onPressed: _isSpamming ? _stopSpam : _startSpam,
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Icon(
                                            _isSpamming ? Icons.stop_circle : FontAwesomeIcons.play,
                                            color: Colors.white,
                                            size: 20,
                                          ),
                                          const SizedBox(width: 10),
                                          Text(
                                            _isSpamming ? "STOP SPAM" : "START SPAM",
                                            style: const TextStyle(
                                              fontFamily: "Orbitron",
                                              color: Colors.white,
                                              fontSize: 14,
                                              fontWeight: FontWeight.w600,
                                              letterSpacing: 1.5,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ),
                          ),

                          const SizedBox(height: 24),

                          // Status Log
                          SlideTransition(
                            position: _slideAnimation,
                            child: ScaleTransition(
                              scale: _scaleAnimation,
                              child: Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: Colors.black.withOpacity(0.3),
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(
                                    color: lightBlue.withOpacity(0.1),
                                    width: 1,
                                  ),
                                ),
                                child: Row(
                                  children: [
                                    Icon(
                                      _isSpamming ? Icons.send : Icons.info_outline,
                                      color: _isSpamming ? lightBlue : silver.withOpacity(0.5),
                                      size: 16,
                                    ),
                                    const SizedBox(width: 10),
                                    Text(
                                      _isSpamming ? "Mengirim pesan..." : "Siap menjalankan spam",
                                      style: TextStyle(
                                        color: _isSpamming ? lightBlue : silver.withOpacity(0.5),
                                        fontSize: 12,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),

                          const SizedBox(height: 16),

                          // Guide sederhana
                          SlideTransition(
                            position: _slideAnimation,
                            child: ScaleTransition(
                              scale: _scaleAnimation,
                              child: Container(
                                padding: const EdgeInsets.all(14),
                                decoration: BoxDecoration(
                                  color: Colors.black.withOpacity(0.2),
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(
                                    color: lightBlue.withOpacity(0.05),
                                    width: 1,
                                  ),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "📌 PETUNJUK",
                                      style: TextStyle(
                                        color: silver.withOpacity(0.4),
                                        fontSize: 10,
                                        fontFamily: "Orbitron",
                                        letterSpacing: 1,
                                      ),
                                    ),
                                    const SizedBox(height: 6),
                                    _buildGuideSimple("Token dari @BotFather"),
                                    _buildGuideSimple("Target ID dari @userinfobot"),
                                    _buildGuideSimple("Bot harus di-start target"),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField({
    required IconData icon,
    required String label,
    required TextEditingController controller,
    required String hint,
    int maxLines = 1,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.3),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: lightBlue.withOpacity(0.1),
          width: 1,
        ),
      ),
      child: TextField(
        controller: controller,
        maxLines: maxLines,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 14,
        ),
        decoration: InputDecoration(
          prefixIcon: Icon(icon, color: lightBlue.withOpacity(0.6), size: 18),
          labelText: label,
          labelStyle: TextStyle(
            color: silver.withOpacity(0.4),
            fontSize: 12,
            fontFamily: "Orbitron",
            letterSpacing: 0.5,
          ),
          hintText: hint,
          hintStyle: TextStyle(
            color: Colors.grey.shade700,
            fontSize: 13,
          ),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(vertical: 12, horizontal: 4),
        ),
      ),
    );
  }

  Widget _buildGuideSimple(String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        children: [
          Icon(Icons.circle, color: lightBlue.withOpacity(0.2), size: 6),
          const SizedBox(width: 8),
          Text(
            text,
            style: TextStyle(
              color: silver.withOpacity(0.4),
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }
}