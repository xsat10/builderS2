import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'ai.dart';
import 'nik.dart';
import 'mbuh.dart';
import 'domain.dart';
import 'youtube_player_page.dart';
import 'ig.dart';
import 'tiktok.dart';
import 'spam_ngl.dart';
import 'iqc.dart';
import 'kalkulator.dart';
import 'spambot.dart';
import 'email_osint.dart';
import 'port_scanner.dart';

class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;
  final String username;

  const ToolsPage({
    super.key,
    required this.username,
    required this.sessionKey,
    required this.userRole,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> with TickerProviderStateMixin {
  // ============ BMW GARAGE PALETTE ============
  final Color primaryDark = const Color(0xFF05070A);   // garage black
  final Color cardDark = const Color(0xFF0E1319);      // carbon panel
  final Color cardDarker = const Color(0xFF0A0F16);    // deeper carbon

  final Color goldColor = const Color(0xFF1C69D4);     // BMW M blue (accent utama)
  final Color blueColor = const Color(0xFF6FB2FF);     // BMW light blue (aksen sekunder)

  final Color bmwRed = const Color(0xFFE7222E);        // BMW M red
  final Color bmwChrome = const Color(0xFFD6DCE5);     // platinum chrome
  final Color bmwSilver = const Color(0xFF9AA5B1);     // silver

  late AnimationController _headerController;
  late AnimationController _listController;
  late Animation<double> _headerAnimation;
  late List<Animation<double>> _itemAnimations;

  // ============ TOOLS LIST ============
  late final List<Map<String, dynamic>> tools;

  @override
  void initState() {
    super.initState();

    // Build tools list TANPA QR Generator dan WiFi Killer
    final baseTools = [
      {'icon': FontAwesomeIcons.youtube, 'label': 'Youtube Downloader', 'description': 'Nonton YouTube'},
      {'icon': FontAwesomeIcons.paperPlane, 'label': 'Spam NGL', 'description': 'Spam pesan ke NGL'},
      {'icon': FontAwesomeIcons.bolt, 'label': 'Spam Bot Telegram', 'description': 'Spam pesan via Bot Telegram'},
      {'icon': Icons.chat_bubble_rounded, 'label': 'Chat AI', 'description': 'AI Private'},
      {'icon': Icons.badge_rounded, 'label': 'NIK Check', 'description': 'Check ID'},
      {'icon': Icons.phone_android_rounded, 'label': 'Phone Lookup', 'description': 'Lookup number'},
      {'icon': Icons.language_rounded, 'label': 'Subdomain', 'description': 'subdomains'},
      {'icon': FontAwesomeIcons.instagram, 'label': 'IG Downloader', 'description': 'Download reels'},
      {'icon': FontAwesomeIcons.tiktok, 'label': 'TikTok Downloader', 'description': 'Download video'},
      {'icon': Icons.verified_rounded, 'label': 'IQC Screenshot Maker', 'description': 'Buat Quotes WhatsApp Iphone'},
      {'icon': Icons.calculate_rounded, 'label': 'Kalkulator', 'description': 'Ghost Kalkulator'},
      {'icon': Icons.email_rounded, 'label': 'Email OSINT', 'description': 'Cek email & domain'},
      {'icon': Icons.dns_rounded, 'label': 'Port Scanner', 'description': 'Scan port server'},
    ];

    tools = baseTools;

    _headerController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    _listController = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    );

    _headerAnimation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _headerController, curve: Curves.easeOutBack),
    );

    _itemAnimations = List.generate(
      tools.length,
      (index) => Tween<double>(begin: 0, end: 1).animate(
        CurvedAnimation(
          parent: _listController,
          curve: Interval(index * 0.07, 1, curve: Curves.easeOut),
        ),
      ),
    );

    _headerController.forward();
    Future.delayed(const Duration(milliseconds: 200), () {
      if (mounted) _listController.forward();
    });
  }

  @override
  void dispose() {
    _headerController.dispose();
    _listController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final safeOpacity = _headerAnimation.value.clamp(0.0, 1.0);

    return Scaffold(
      backgroundColor: primaryDark,
      appBar: AppBar(
        backgroundColor: primaryDark,
        elevation: 0,
        leading: const BackButton(color: Colors.white),
        title: const Text(
          "BMW Garage",
          style: TextStyle(
            color: Colors.white,
            fontFamily: 'Orbitron',
            letterSpacing: 2,
            fontWeight: FontWeight.w700,
          ),
        ),
        centerTitle: true,
      ),
      body: Stack(
        children: [
          // Background base
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0xFF05070A),
                  Color(0xFF0A0F16),
                  Color(0xFF05070A),
                ],
              ),
            ),
          ),

          // Grid pattern (subtle garage floor)
          Positioned.fill(
            child: AnimatedBuilder(
              animation: _headerController,
              builder: (_, __) => Opacity(
                opacity: safeOpacity * 0.05,
                child: CustomPaint(
                  painter: GridPatternPainter(color: goldColor),
                ),
              ),
            ),
          ),

          // Ambient glow — M blue (atas)
          Positioned(
            top: -120,
            right: -120,
            child: Container(
              width: 260,
              height: 260,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: goldColor.withOpacity(0.10),
                boxShadow: [
                  BoxShadow(
                    color: goldColor.withOpacity(0.20),
                    blurRadius: 100,
                    spreadRadius: 30,
                  ),
                ],
              ),
            ),
          ),

          // Ambient glow — M red (bawah)
          Positioned(
            bottom: -140,
            left: -120,
            child: Container(
              width: 260,
              height: 260,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: bmwRed.withOpacity(0.08),
                boxShadow: [
                  BoxShadow(
                    color: bmwRed.withOpacity(0.15),
                    blurRadius: 100,
                    spreadRadius: 30,
                  ),
                ],
              ),
            ),
          ),

          SafeArea(
            child: Column(
              children: [
                _buildHeader(),
                const SizedBox(height: 20),
                Expanded(child: _buildList()),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return AnimatedBuilder(
      animation: _headerAnimation,
      builder: (_, __) {
        final v = _headerAnimation.value.clamp(0.0, 1.0);

        return Transform.translate(
          offset: Offset(0, (1 - v) * 30),
          child: Opacity(
            opacity: v,
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(25),
                color: cardDarker,
                border: Border.all(color: bmwChrome.withOpacity(.18)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.55),
                    blurRadius: 24,
                    offset: const Offset(0, 10),
                  ),
                  BoxShadow(
                    color: goldColor.withOpacity(0.12),
                    blurRadius: 30,
                    offset: const Offset(0, -6),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(25),
                child: Stack(
                  children: [
                    // M-stripe di atas
                    Positioned(
                      top: 0,
                      left: 0,
                      child: Row(
                        children: [
                          Container(width: 40, height: 3, color: goldColor),
                          Container(width: 40, height: 3, color: blueColor),
                          Container(width: 40, height: 3, color: bmwRed),
                        ],
                      ),
                    ),
                    // Watermark shield
                    Positioned(
                      bottom: -30,
                      right: -20,
                      child: Opacity(
                        opacity: 0.06,
                        child: Icon(
                          Icons.shield_rounded,
                          size: 160,
                          color: bmwChrome,
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                padding: const EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  color: goldColor.withOpacity(.12),
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: goldColor.withOpacity(.45),
                                    width: 1.2,
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: goldColor.withOpacity(0.25),
                                      blurRadius: 14,
                                      offset: const Offset(0, 4),
                                    ),
                                  ],
                                ),
                                child: Icon(Icons.grid_view_rounded,
                                    color: bmwChrome),
                              ),
                              const SizedBox(width: 12),
                              const Text(
                                "BMW Garage",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 22,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Orbitron',
                                  letterSpacing: 1.5,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 6),
                          Text(
                            "Select a tool to begin",
                            style: TextStyle(
                              color: bmwSilver.withOpacity(.85),
                              letterSpacing: 0.8,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildList() {
    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      itemCount: tools.length,
      itemBuilder: (context, i) {
        final tool = tools[i];

        return _buildItem(
          icon: tool['icon'],
          label: tool['label'],
          description: tool['description'],
          animation: _itemAnimations[i],
          onTap: () => _navigate(tool['label']),
        );
      },
    );
  }

  Widget _buildItem({
    required IconData icon,
    required String label,
    required String description,
    required Animation<double> animation,
    required VoidCallback onTap,
  }) {
    return AnimatedBuilder(
      animation: animation,
      builder: (_, __) {
        final v = animation.value.clamp(0.0, 1.0);

        return Transform.translate(
          offset: Offset((1 - v) * 40, 0),
          child: Opacity(
            opacity: v,
            child: Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: _InteractiveToolItem(
                icon: icon,
                label: label,
                description: description,
                onTap: onTap,
                primaryColor: goldColor,
                cardColor: cardDark,
              ),
            ),
          ),
        );
      },
    );
  }

  // ==================== NAVIGASI ====================
  void _navigate(String name) {
    Widget page;

    switch (name) {
      case 'Youtube Downloader':
        page = const YoutubePlayerPage();
        break;
      case 'Spam NGL':
        page = const NglPage();
        break;
      case 'Spam Bot Telegram':
        page = SpamBotPage(sessionKey: widget.sessionKey);
        break;
      case 'Chat AI':
        page = AIPage(username: widget.username, sessionKey: widget.sessionKey);
        break;
      case 'NIK Check':
        page = const NIKCheckPage();
        break;
      case 'Phone Lookup':
        page = const PhoneLookupPage();
        break;
      case 'Subdomain':
        page = const SubdomainPage();
        break;
      case 'IG Downloader':
        page = const InstagramDownloaderPage();
        break;
      case 'TikTok Downloader':
        page = const TiktokDownloaderPage();
        break;
      case 'IQC Screenshot Maker':
        page = const IQCScreen();
        break;
      case 'Kalkulator':
        page = const KalkulatorPage();
        break;
      case 'Email OSINT':
        page = const EmailOsintPage();
        break;
      case 'Port Scanner':
        page = const PortScannerPage();
        break;
      default:
        return;
    }

    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }
}

class _InteractiveToolItem extends StatefulWidget {
  final IconData icon;
  final String label;
  final String description;
  final VoidCallback onTap;
  final Color primaryColor;
  final Color cardColor;

  const _InteractiveToolItem({
    required this.icon,
    required this.label,
    required this.description,
    required this.onTap,
    required this.primaryColor,
    required this.cardColor,
  });

  @override
  State<_InteractiveToolItem> createState() => _InteractiveToolItemState();
}

class _InteractiveToolItemState extends State<_InteractiveToolItem>
    with SingleTickerProviderStateMixin {
  late AnimationController controller;
  late Animation<double> scale;
  bool pressed = false;

  // BMW accent — M stripe
  final Color bmwRed = const Color(0xFFE7222E);
  final Color bmwLightBlue = const Color(0xFF6FB2FF);
  final Color bmwChrome = const Color(0xFFD6DCE5);

  @override
  void initState() {
    super.initState();
    controller = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 150));
    scale = Tween(begin: 1.0, end: .96).animate(controller);
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) {
        pressed = true;
        controller.forward();
        setState(() {});
      },
      onTapUp: (_) {
        pressed = false;
        controller.reverse();
        widget.onTap();
        setState(() {});
      },
      onTapCancel: () {
        pressed = false;
        controller.reverse();
        setState(() {});
      },
      child: AnimatedBuilder(
        animation: controller,
        builder: (_, __) => Transform.scale(
          scale: scale.value,
          child: Container(
            decoration: BoxDecoration(
              color: widget.cardColor,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: widget.primaryColor.withOpacity(pressed ? .65 : .20),
                width: pressed ? 1.4 : 1.0,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.45),
                  blurRadius: 14,
                  offset: const Offset(0, 6),
                ),
                if (pressed)
                  BoxShadow(
                    color: widget.primaryColor.withOpacity(0.35),
                    blurRadius: 18,
                    offset: const Offset(0, 0),
                  ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: Stack(
                children: [
                  // M-stripe aksen kiri
                  Positioned(
                    left: 0,
                    top: 14,
                    bottom: 14,
                    child: Container(
                      width: 3,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            widget.primaryColor,
                            bmwLightBlue,
                            bmwRed,
                          ],
                        ),
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: widget.primaryColor.withOpacity(.12),
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(
                              color: widget.primaryColor.withOpacity(.35),
                              width: 1,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: widget.primaryColor.withOpacity(0.18),
                                blurRadius: 10,
                                offset: const Offset(0, 3),
                              ),
                            ],
                          ),
                          child: Icon(widget.icon, color: bmwChrome),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                widget.label,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 0.4,
                                ),
                              ),
                              Text(
                                widget.description,
                                style: TextStyle(
                                  color: bmwChrome.withOpacity(0.55),
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Icon(
                          Icons.chevron_right,
                          color: widget.primaryColor.withOpacity(.6),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class GridPatternPainter extends CustomPainter {
  final Color color;

  GridPatternPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = .5;

    const gap = 30.0;

    for (double x = 0; x < size.width; x += gap) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), p);
    }
    for (double y = 0; y < size.height; y += gap) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), p);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}