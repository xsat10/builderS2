// ============================================================
// 🎨 AMBIL LINK GB PAGE — Modern Smooth 3D Edition
// File: ambil_link_gb_page.dart
// v4 — Redesigned (Smooth, Modern, Animated)
// ============================================================
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

class _MC {
  static const red          = Color(0xFF8B0000);
  static const redDeep      = Color(0xFF1A0A0A);
  static const redDark      = Color(0xFF4A0000);
  static const redSoft      = Color(0xFF2A0E0E);
  static const brightRed    = Color(0xFFFF3B3B);
  static const buttonYellow = Color(0xFFB8860B);
  static const buttonDark   = Color(0xFF1A1A1A);
  static const comicBlack   = Color(0xFF000000);
  static const white        = Color(0xFFFFF5F5);
  static const textGrey     = Color(0xFFC9A0A0);
  static const textLight    = Color(0xFF8A6060);
  static const green        = Color(0xFF22C55E);
  static const greenLite    = Color(0xFF4ADE80);
  static const amber        = Color(0xFFFBBF24);
}

class AmbilLinkGBPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  const AmbilLinkGBPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<AmbilLinkGBPage> createState() => _AmbilLinkGBPageState();
}

class _AmbilLinkGBPageState extends State<AmbilLinkGBPage>
    with TickerProviderStateMixin {
  bool _linkCopied = false;
  bool _loading = true;
  bool _showRules = true;
  int? _claimTimestamp;

  static const String GROUP_LINK = "https://t.me/+JZmknrzcOuYyOTM9";

  late final AnimationController _entryCtrl;
  late final AnimationController _pulseCtrl;
  late final Animation<double> _fade;
  late final Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();

    _entryCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 750),
    );
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    )..repeat(reverse: true);

    _fade = CurvedAnimation(parent: _entryCtrl, curve: Curves.easeOutCubic);
    _slide = Tween<Offset>(
      begin: const Offset(0, 0.08),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _entryCtrl, curve: Curves.easeOutCubic));

    _loadStatus();
  }

  @override
  void dispose() {
    _entryCtrl.dispose();
    _pulseCtrl.dispose();
    super.dispose();
  }

  // ════════════════════════════════════════════════════════════
  // 🔍 CEK STATUS DARI LOCAL STORAGE
  // ════════════════════════════════════════════════════════════
  Future<void> _loadStatus() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final key = 'gb_link_copied_${widget.username}';
      final copied = prefs.getBool(key) ?? false;
      final ts = prefs.getInt('${key}_timestamp');

      if (mounted) {
        setState(() {
          _linkCopied = copied;
          _claimTimestamp = ts;
          _showRules = !copied; // rules hilang kalau sudah copy
          _loading = false;
        });
        _entryCtrl.forward();
      }
    } catch (_) {
      if (mounted) {
        setState(() => _loading = false);
        _entryCtrl.forward();
      }
    }
  }

  // ════════════════════════════════════════════════════════════
  // 📋 COPY LINK — HANYA 1X SAJA
  // ════════════════════════════════════════════════════════════
  Future<void> _copyLink() async {
    if (_linkCopied) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          backgroundColor: _MC.redDeep,
          behavior: SnackBarBehavior.floating,
          content: Text(
            '❌ Link sudah pernah di-copy! Tidak bisa lagi.',
            style: TextStyle(
                color: _MC.white, fontWeight: FontWeight.w800),
          ),
        ),
      );
      return;
    }

    try {
      await Clipboard.setData(const ClipboardData(text: GROUP_LINK));

      final prefs = await SharedPreferences.getInstance();
      final key = 'gb_link_copied_${widget.username}';
      await prefs.setBool(key, true);
      await prefs.setInt(
          '${key}_timestamp', DateTime.now().millisecondsSinceEpoch);

      if (mounted) {
        setState(() {
          _linkCopied = true;
          _showRules = false;
          _claimTimestamp = DateTime.now().millisecondsSinceEpoch;
        });
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            backgroundColor: _MC.green,
            behavior: SnackBarBehavior.floating,
            content: Row(
              children: [
                Icon(Icons.check_circle_rounded,
                    color: _MC.comicBlack, size: 20),
                SizedBox(width: 8),
                Text(
                  '✅ Link berhasil di-copy! (1x saja)',
                  style: TextStyle(
                      color: _MC.comicBlack,
                      fontWeight: FontWeight.w800),
                ),
              ],
            ),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            backgroundColor: _MC.red,
            behavior: SnackBarBehavior.floating,
            content: Text(
              '❌ Gagal copy: $e',
              style: const TextStyle(
                  color: _MC.white, fontWeight: FontWeight.w800),
            ),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _MC.redDeep,
      extendBodyBehindAppBar: true,
      appBar: _buildAppBar(),
      body: Stack(
        children: [
          // Background gradient + glow
          Positioned.fill(
            child: DecoratedBox(
              decoration: const BoxDecoration(
                gradient: RadialGradient(
                  center: Alignment.topCenter,
                  radius: 1.4,
                  colors: [
                    Color(0xFF3A0808),
                    _MC.redDeep,
                    Color(0xFF0A0303),
                  ],
                  stops: [0.0, 0.55, 1.0],
                ),
              ),
            ),
          ),
          // Orbs
          Positioned(
            top: -80,
            right: -60,
            child: _glowOrb(180, _MC.brightRed.withOpacity(0.18)),
          ),
          Positioned(
            bottom: -100,
            left: -80,
            child: _glowOrb(220, _MC.buttonYellow.withOpacity(0.10)),
          ),

          SafeArea(
            child: _loading
                ? const Center(
                    child: CircularProgressIndicator(color: _MC.brightRed))
                : FadeTransition(
                    opacity: _fade,
                    child: SlideTransition(
                      position: _slide,
                      child: SingleChildScrollView(
                        physics: const BouncingScrollPhysics(),
                        padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            _buildHeaderCard(),
                            const SizedBox(height: 18),
                            _buildLinkCard(),
                            if (_linkCopied) ...[
                              const SizedBox(height: 18),
                              _buildDetectedInfo(),
                            ],
                            if (_showRules) ...[
                              const SizedBox(height: 22),
                              _buildRulesCard(),
                            ],
                            const SizedBox(height: 30),
                          ],
                        ),
                      ),
                    ),
                  ),
          ),
        ],
      ),
    );
  }

  Widget _glowOrb(double size, Color color) {
    return IgnorePointer(
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            colors: [color, color.withOpacity(0.0)],
          ),
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      centerTitle: true,
      leadingWidth: 60,
      leading: Padding(
        padding: const EdgeInsets.only(left: 12),
        child: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            margin: const EdgeInsets.symmetric(vertical: 8),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF2A2A2A), _MC.buttonDark],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _MC.comicBlack, width: 2.2),
              boxShadow: [
                BoxShadow(
                  color: _MC.brightRed.withOpacity(0.25),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: const Icon(Icons.arrow_back_ios_new_rounded,
                color: _MC.white, size: 16),
          ),
        ),
      ),
      title: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [_MC.redDark, _MC.red],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _MC.comicBlack, width: 2.2),
          boxShadow: [
            BoxShadow(
              color: _MC.brightRed.withOpacity(0.35),
              blurRadius: 14,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: const Text(
          'AMBIL LINK GB',
          style: TextStyle(
            color: _MC.white,
            fontWeight: FontWeight.w900,
            fontSize: 13,
            letterSpacing: 2,
            fontFamily: 'Astral',
          ),
        ),
      ),
    );
  }

  Widget _buildHeaderCard() {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF2E0E0E), Color(0xFF1A0707)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: _MC.comicBlack, width: 2.5),
        boxShadow: [
          BoxShadow(
            color: _MC.brightRed.withOpacity(0.20),
            blurRadius: 22,
            offset: const Offset(0, 8),
          ),
          const BoxShadow(
            color: _MC.comicBlack,
            offset: Offset(4, 4),
            blurRadius: 0,
          ),
        ],
      ),
      child: Column(
        children: [
          AnimatedBuilder(
            animation: _pulseCtrl,
            builder: (context, child) {
              final t = _pulseCtrl.value;
              return Container(
                width: 74,
                height: 74,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(
                    colors: [_MC.brightRed, _MC.red],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  border:
                      Border.all(color: _MC.comicBlack, width: 2.5),
                  boxShadow: [
                    BoxShadow(
                      color: _MC.brightRed
                          .withOpacity(0.35 + (0.25 * t)),
                      blurRadius: 18 + (10 * t),
                      spreadRadius: 1 + (2 * t),
                    ),
                  ],
                ),
                child: const Icon(Icons.group_add_rounded,
                    color: _MC.white, size: 34),
              );
            },
          ),
          const SizedBox(height: 16),
          ShaderMask(
            shaderCallback: (rect) => const LinearGradient(
              colors: [_MC.white, _MC.textGrey],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ).createShader(rect),
            child: const Text(
              'AMBIL LINK GROUP',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: _MC.white,
                fontWeight: FontWeight.w900,
                fontSize: 18,
                letterSpacing: 2,
                fontFamily: 'Astral',
              ),
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Klik tombol di bawah untuk copy link group eksklusif. Link hanya bisa di-copy 1x saja per akun.',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: _MC.textGrey,
              fontSize: 12,
              height: 1.6,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLinkCard() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF2E0E0E), Color(0xFF1A0707)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: _MC.comicBlack, width: 2.5),
        boxShadow: [
          BoxShadow(
            color: _MC.brightRed.withOpacity(0.18),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
          const BoxShadow(
            color: _MC.comicBlack,
            offset: Offset(4, 4),
            blurRadius: 0,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(
                    colors: [_MC.brightRed, _MC.red],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  border:
                      Border.all(color: _MC.comicBlack, width: 2),
                ),
                child: const Icon(Icons.link_rounded,
                    color: _MC.white, size: 17),
              ),
              const SizedBox(width: 10),
              const Expanded(
                child: Text(
                  'LINK GROUP ANDA',
                  style: TextStyle(
                    color: _MC.white,
                    fontWeight: FontWeight.w900,
                    fontSize: 12,
                    letterSpacing: 1.5,
                    fontFamily: 'Astral',
                  ),
                ),
              ),
              AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                padding: const EdgeInsets.symmetric(
                    horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: _linkCopied
                        ? [_MC.red, _MC.redDark]
                        : [_MC.green, const Color(0xFF15803D)],
                  ),
                  borderRadius: BorderRadius.circular(10),
                  border:
                      Border.all(color: _MC.comicBlack, width: 1.8),
                ),
                child: Text(
                  _linkCopied ? 'USED' : 'FRESH',
                  style: const TextStyle(
                    color: _MC.white,
                    fontSize: 9,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(15),
            decoration: BoxDecoration(
              color: _MC.comicBlack.withOpacity(0.55),
              borderRadius: BorderRadius.circular(14),
              border:
                  Border.all(color: _MC.comicBlack, width: 2),
            ),
            child: Text(
              GROUP_LINK,
              style: TextStyle(
                color:
                    _linkCopied ? _MC.textLight : _MC.greenLite,
                fontSize: 12.5,
                fontWeight: FontWeight.w700,
                fontFamily: 'monospace',
              ),
            ),
          ),
          const SizedBox(height: 14),
          GestureDetector(
            onTap: _linkCopied ? null : _copyLink,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              height: 58,
              decoration: BoxDecoration(
                gradient: _linkCopied
                    ? const LinearGradient(
                        colors: [_MC.buttonDark, Color(0xFF0A0A0A)],
                      )
                    : const LinearGradient(
                        colors: [
                          Color(0xFFD4A017),
                          _MC.buttonYellow,
                          Color(0xFF8B6508),
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                borderRadius: BorderRadius.circular(16),
                border:
                    Border.all(color: _MC.comicBlack, width: 2.5),
                boxShadow: _linkCopied
                    ? null
                    : [
                        BoxShadow(
                          color:
                              _MC.buttonYellow.withOpacity(0.35),
                          blurRadius: 18,
                          offset: const Offset(0, 6),
                        ),
                        const BoxShadow(
                          color: _MC.comicBlack,
                          offset: Offset(3, 3),
                          blurRadius: 0,
                        ),
                      ],
              ),
              child: Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      _linkCopied
                          ? Icons.lock_rounded
                          : Icons.copy_rounded,
                      color: _linkCopied
                          ? _MC.textLight
                          : _MC.comicBlack,
                      size: 22,
                    ),
                    const SizedBox(width: 10),
                    Text(
                      _linkCopied
                          ? 'LINK SUDAH DI-COPY'
                          : 'COPY LINK GB',
                      style: TextStyle(
                        color: _linkCopied
                            ? _MC.textLight
                            : _MC.comicBlack,
                        fontWeight: FontWeight.w900,
                        fontSize: 15,
                        letterSpacing: 1.5,
                        fontFamily: 'Astral',
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          if (_linkCopied) ...[
            const SizedBox(height: 12),
            const Center(
              child: Text(
                '⚠️ Link hanya dapat di-copy 1x saja',
                style: TextStyle(
                  color: _MC.brightRed,
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildDetectedInfo() {
    final dt = _claimTimestamp != null
        ? DateTime.fromMillisecondsSinceEpoch(_claimTimestamp!)
        : null;
    final dateStr = dt != null
        ? '${dt.day}/${dt.month}/${dt.year} ${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}'
        : '-';

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF1F1F1F), Color(0xFF0F0F0F)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _MC.comicBlack, width: 2.5),
        boxShadow: [
          BoxShadow(
            color: _MC.brightRed.withOpacity(0.15),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
          const BoxShadow(
            color: _MC.comicBlack,
            offset: Offset(3, 3),
            blurRadius: 0,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.fingerprint_rounded,
                  color: _MC.brightRed, size: 16),
              SizedBox(width: 8),
              Text(
                'INFO COPY',
                style: TextStyle(
                  color: _MC.white,
                  fontWeight: FontWeight.w900,
                  fontSize: 11,
                  letterSpacing: 1.5,
                  fontFamily: 'Astral',
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          _infoRow('Username', widget.username),
          _infoRow('Waktu Copy', dateStr),
          _infoRow(
              'Status',
              _linkCopied
                  ? 'Sudah di-copy'
                  : 'Belum di-copy'),
        ],
      ),
    );
  }

  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          Expanded(
            flex: 4,
            child: Text(
              label,
              style: const TextStyle(
                color: _MC.textGrey,
                fontSize: 11.5,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          Expanded(
            flex: 6,
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: const TextStyle(
                color: _MC.white,
                fontSize: 11.5,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRulesCard() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF1F1F1F), Color(0xFF0F0F0F)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: _MC.comicBlack, width: 2.5),
        boxShadow: [
          BoxShadow(
            color: _MC.amber.withOpacity(0.12),
            blurRadius: 18,
            offset: const Offset(0, 6),
          ),
          const BoxShadow(
            color: _MC.comicBlack,
            offset: Offset(3, 3),
            blurRadius: 0,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: const [
          Row(
            children: [
              Icon(Icons.rule_folder_rounded,
                  color: _MC.amber, size: 20),
              SizedBox(width: 8),
              Text(
                'RULES / PERATURAN',
                style: TextStyle(
                  color: _MC.white,
                  fontWeight: FontWeight.w900,
                  fontSize: 13,
                  letterSpacing: 1.5,
                  fontFamily: 'Astral',
                ),
              ),
            ],
          ),
          SizedBox(height: 14),
          _RuleItem(
              num: '1',
              text:
                  'Link group hanya bisa di-copy 1x saja, tidak bisa diulang.'),
          _RuleItem(
              num: '2',
              text: 'Dilarang share link ke pihak lain di luar grup.'),
          _RuleItem(
              num: '3',
              text:
                  'Satu akun hanya boleh klaim 1 link group. Tidak bisa di-reset.'),
          _RuleItem(
              num: '4',
              text:
                  'Simpan link di tempat aman sebelum keluar dari halaman ini.'),
          _RuleItem(
              num: '5',
              text:
                  'Pelanggaran akan berakibat banned permanent tanpa refund.'),
          _RuleItem(
              num: '6',
              text:
                  'Dengan copy link ini, Anda setuju dengan semua aturan di atas.'),
        ],
      ),
    );
  }
}

class _RuleItem extends StatelessWidget {
  final String num;
  final String text;
  const _RuleItem({required this.num, required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 24,
            height: 24,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [_MC.brightRed, _MC.red],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              border:
                  Border.all(color: _MC.comicBlack, width: 1.8),
              boxShadow: [
                BoxShadow(
                  color: _MC.brightRed.withOpacity(0.30),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Center(
              child: Text(
                num,
                style: const TextStyle(
                  color: _MC.white,
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(
                color: _MC.textGrey,
                fontSize: 11.5,
                height: 1.55,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}