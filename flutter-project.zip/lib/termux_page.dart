import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
// Catatan: jika project ini belum punya package http, jalankan:
//   flutter pub add http
// (kemungkinan besar sudah terpasang karena tools lain di gateway ini
// juga melakukan pemanggilan API ke Panel milikmu)

// ─── Role yang diizinkan mengakses Termux Mclaren ────────────────────────────
// Dipakai juga oleh tools_gateway.dart untuk menyembunyikan menu bagi role
// yang tidak termasuk daftar ini — satu sumber kebenaran, tidak perlu diubah
// di dua tempat.
const Set<String> kTermuxAllowedRoles = {
  'owner_utama',
  'owner',
  'staff',
  'executorius',
  'forius_utama',
  'moderator',
  'ceo_utama',
  'tangan_kanan',
  'tangan_kiri',
  'admin',
  'tukang_bubur',
  'reseller',
};

// ─── PENTING: ganti dengan base URL Panel API kamu sendiri ───────────────────
// Endpoint yang dipanggil:
//   POST  $_panelBaseUrl/api/termux/install
//   POST  $_panelBaseUrl/api/termux/run-bot
//   POST  $_panelBaseUrl/api/termux/run-api
//   GET   $_panelBaseUrl/api/termux/status   (cek koneksi panel)
const String _panelBaseUrl = 'http://fizz.keselekbijiwowo.web.id:2421';

// ─── Theme & Palette Terminal Hijau Khas Termux ──────────────────────────────
class _TC {
  static const bg        = Color(0xFF070C09);
  static const card      = Color(0xFF0D140F);
  static const cardInner = Color(0xFF121D15);
  static const border    = Color(0xFF1C2C20);
  static const borderLit = Color(0xFF2E8B3D);

  static const consoleBg = Color(0xFF000000);
  static const green     = Color(0xFF4AF626); // warna teks utama ala Termux
  static const greenDim  = Color(0xFF2E8B3D);
  static const white     = Color(0xFFF1F5F1);
  static const textSub   = Color(0xFF7E9B84);
  static const red       = Color(0xFFFF5C5C);
  static const amber     = Color(0xFFFFC24A);
}

// ─── Mode aksi ────────────────────────────────────────────────────────────────
enum _TermuxMode { install, bot, api }

class _ModeConfig {
  final String label;
  final IconData icon;
  final String endpointPath;
  final String hint;
  final String promptPrefix;

  const _ModeConfig({
    required this.label,
    required this.icon,
    required this.endpointPath,
    required this.hint,
    required this.promptPrefix,
  });
}

const Map<_TermuxMode, _ModeConfig> _modeConfigs = {
  _TermuxMode.install: _ModeConfig(
    label: 'Install',
    icon: Icons.download_for_offline_rounded,
    endpointPath: '/api/termux/install',
    hint: 'Nama package / script (mis: python, nodejs)',
    promptPrefix: 'pkg install',
  ),
  _TermuxMode.bot: _ModeConfig(
    label: 'Run Bot',
    icon: Icons.smart_toy_rounded,
    endpointPath: '/api/termux/run-bot',
    hint: 'Nama file bot (mis: bot.js / main.py)',
    promptPrefix: 'node',
  ),
  _TermuxMode.api: _ModeConfig(
    label: 'Run API',
    icon: Icons.api_rounded,
    endpointPath: '/api/termux/run-api',
    hint: 'Nama service / endpoint API',
    promptPrefix: 'curl',
  ),
};

enum _LogType { input, output, error, info }

class _LogLine {
  final _LogType type;
  final String text;
  _LogLine(this.type, this.text);
}

enum _ConnStatus { checking, online, offline }

const int kMaxTermuxAttempts = 4;

// ─── Termux Mclaren Page ──────────────────────────────────────────────────────
class TermuxPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;

  const TermuxPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
  });

  @override
  State<TermuxPage> createState() => _TermuxPageState();
}

class _TermuxPageState extends State<TermuxPage> {
  _TermuxMode _mode = _TermuxMode.install;
  final TextEditingController _inputCtrl = TextEditingController();
  final ScrollController _scrollCtrl = ScrollController();
  final List<_LogLine> _logs = [];

  int _attempts = 0;
  bool _loading = false;
  _ConnStatus _connStatus = _ConnStatus.checking;

  bool get _allowed => kTermuxAllowedRoles.contains(widget.userRole);

  @override
  void initState() {
    super.initState();
    if (_allowed) {
      _pingPanel();
      _addLog(_LogType.info, 'Termux Mclaren siap. Pilih mode lalu jalankan perintah.');
    }
  }

  @override
  void dispose() {
    _inputCtrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  Future<void> _pingPanel() async {
    try {
      final uri = Uri.parse('$_panelBaseUrl/api/termux/status');
      final res = await http.get(
        uri,
        headers: {'Authorization': 'Bearer ${widget.sessionKey}'},
      ).timeout(const Duration(seconds: 8));
      if (!mounted) return;
      setState(() {
        _connStatus = res.statusCode == 200 ? _ConnStatus.online : _ConnStatus.offline;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() => _connStatus = _ConnStatus.offline);
    }
  }

  void _addLog(_LogType type, String text) {
    setState(() => _logs.add(_LogLine(type, text)));
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scrollCtrl.hasClients) return;
      _scrollCtrl.animateTo(
        _scrollCtrl.position.maxScrollExtent,
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeOut,
      );
    });
  }

  void _showSnack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: const TextStyle(color: _TC.white)),
        backgroundColor: _TC.cardInner,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  Future<void> _execute() async {
    if (_loading) return;

    if (_attempts >= kMaxTermuxAttempts) {
      _showSnack('Batas $kMaxTermuxAttempts kali percobaan sudah tercapai untuk sesi ini.');
      return;
    }

    final input = _inputCtrl.text.trim();
    if (input.isEmpty) {
      _showSnack('Isi dulu perintah / nama package-nya.');
      return;
    }

    final cfg = _modeConfigs[_mode]!;
    setState(() {
      _loading = true;
      _attempts++;
    });
    _addLog(_LogType.input, '${cfg.promptPrefix} $input');

    try {
      final uri = Uri.parse('$_panelBaseUrl${cfg.endpointPath}');
      final response = await http.post(
        uri,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ${widget.sessionKey}',
        },
        body: jsonEncode({
          'key': widget.sessionKey,
          'role': widget.userRole,
          'mode': _mode.name,
          'command': input,
        }),
      ).timeout(const Duration(seconds: 25));

      if (response.statusCode == 200) {
        String message = response.body;
        try {
          final decoded = jsonDecode(response.body);
          if (decoded is Map && decoded['message'] != null) {
            message = decoded['message'].toString();
          }
        } catch (_) {
          // biarkan pakai body mentah kalau bukan JSON
        }
        _addLog(
          _LogType.output,
          message.trim().isEmpty ? 'Selesai tanpa output.' : message,
        );
      } else {
        _addLog(
          _LogType.error,
          'Gagal (kode ${response.statusCode}): ${response.body}',
        );
      }
    } on TimeoutException {
      _addLog(_LogType.error, 'Waktu tunggu habis. Panel API tidak merespons.');
    } catch (e) {
      _addLog(_LogType.error, 'Terjadi kesalahan koneksi: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_allowed) {
      return _buildAccessDenied();
    }

    final cfg = _modeConfigs[_mode]!;
    final attemptsLeft = kMaxTermuxAttempts - _attempts;

    return Scaffold(
      backgroundColor: _TC.bg,
      appBar: AppBar(
        backgroundColor: _TC.bg,
        elevation: 0,
        iconTheme: const IconThemeData(color: _TC.green),
        title: Row(
          children: [
            const Icon(Icons.terminal_rounded, color: _TC.green, size: 20),
            const SizedBox(width: 8),
            const Text(
              'TERMUX MCLAREN',
              style: TextStyle(
                color: _TC.green,
                fontWeight: FontWeight.bold,
                letterSpacing: 1,
                fontFamily: 'monospace',
                fontSize: 15,
              ),
            ),
          ],
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            _buildStatusBar(),
            const SizedBox(height: 4),
            _buildModeSelector(),
            const SizedBox(height: 12),
            _buildAttemptsBar(attemptsLeft),
            const SizedBox(height: 10),
            _buildInputField(cfg),
            const SizedBox(height: 10),
            _buildExecuteButton(attemptsLeft),
            const SizedBox(height: 14),
            Expanded(child: _buildConsole()),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }

  // ── Access Denied Screen ──
  Widget _buildAccessDenied() {
    return Scaffold(
      backgroundColor: _TC.bg,
      appBar: AppBar(
        backgroundColor: _TC.bg,
        elevation: 0,
        iconTheme: const IconThemeData(color: _TC.green),
        title: const Text(
          'TERMUX MCLAREN',
          style: TextStyle(
            color: _TC.green,
            fontWeight: FontWeight.bold,
            letterSpacing: 1,
            fontFamily: 'monospace',
            fontSize: 15,
          ),
        ),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 72,
                height: 72,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _TC.red.withOpacity(0.1),
                  border: Border.all(color: _TC.red.withOpacity(0.4), width: 1.4),
                ),
                child: const Icon(Icons.lock_rounded, color: _TC.red, size: 32),
              ),
              const SizedBox(height: 18),
              const Text(
                'Akses Ditolak',
                style: TextStyle(
                  color: _TC.white,
                  fontSize: 17,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Role "${widget.userRole}" tidak memiliki izin untuk mengakses Termux Mclaren.',
                textAlign: TextAlign.center,
                style: const TextStyle(color: _TC.textSub, fontSize: 12.5, height: 1.5),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── Status koneksi Panel API ──
  Widget _buildStatusBar() {
    late final Color dotColor;
    late final String label;
    switch (_connStatus) {
      case _ConnStatus.checking:
        dotColor = _TC.amber;
        label = 'Mengecek koneksi Panel API...';
        break;
      case _ConnStatus.online:
        dotColor = _TC.green;
        label = 'Terhubung ke Panel API';
        break;
      case _ConnStatus.offline:
        dotColor = _TC.red;
        label = 'Panel API tidak terhubung';
        break;
    }
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(shape: BoxShape.circle, color: dotColor),
          ),
          const SizedBox(width: 8),
          Text(
            label,
            style: const TextStyle(color: _TC.textSub, fontSize: 11.5),
          ),
          const Spacer(),
          Text(
            'Role: ${widget.userRole}',
            style: const TextStyle(color: _TC.textSub, fontSize: 11),
          ),
        ],
      ),
    );
  }

  // ── Pemilih Mode: Install / Run Bot / Run API ──
  Widget _buildModeSelector() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: _TermuxMode.values.map((m) {
          final cfg = _modeConfigs[m]!;
          final selected = _mode == m;
          return Expanded(
            child: Padding(
              padding: EdgeInsets.only(right: m == _TermuxMode.api ? 0 : 8),
              child: GestureDetector(
                onTap: () => setState(() => _mode = m),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 150),
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  decoration: BoxDecoration(
                    color: selected ? _TC.green.withOpacity(0.1) : _TC.card,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: selected ? _TC.green : _TC.border,
                      width: selected ? 1.4 : 1,
                    ),
                  ),
                  child: Column(
                    children: [
                      Icon(
                        cfg.icon,
                        size: 18,
                        color: selected ? _TC.green : _TC.textSub,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        cfg.label,
                        style: TextStyle(
                          color: selected ? _TC.green : _TC.textSub,
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  // ── Indikator sisa percobaan (maks 4x) ──
  Widget _buildAttemptsBar(int attemptsLeft) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          const Icon(Icons.replay_circle_filled_rounded, color: _TC.greenDim, size: 15),
          const SizedBox(width: 6),
          Text(
            'Percobaan: $_attempts/$kMaxTermuxAttempts'
            '${attemptsLeft <= 0 ? " — batas tercapai" : ""}',
            style: TextStyle(
              color: attemptsLeft <= 0 ? _TC.red : _TC.textSub,
              fontSize: 11.5,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  // ── Input command / package ──
  Widget _buildInputField(_ModeConfig cfg) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        decoration: BoxDecoration(
          color: _TC.card,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _TC.border, width: 1),
        ),
        child: TextField(
          controller: _inputCtrl,
          style: const TextStyle(
            color: _TC.green,
            fontFamily: 'monospace',
            fontSize: 13,
          ),
          cursorColor: _TC.green,
          decoration: InputDecoration(
            prefixText: r'$ ',
            prefixStyle: const TextStyle(
              color: _TC.greenDim,
              fontFamily: 'monospace',
              fontWeight: FontWeight.bold,
            ),
            hintText: cfg.hint,
            hintStyle: const TextStyle(color: _TC.textSub, fontSize: 12),
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          ),
        ),
      ),
    );
  }

  // ── Tombol Jalankan ──
  Widget _buildExecuteButton(int attemptsLeft) {
    final disabled = _loading || attemptsLeft <= 0;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: GestureDetector(
        onTap: disabled ? null : _execute,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          width: double.infinity,
          height: 48,
          decoration: BoxDecoration(
            color: disabled ? _TC.cardInner : _TC.green.withOpacity(0.12),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: disabled ? _TC.border : _TC.green,
              width: 1.2,
            ),
          ),
          child: Center(
            child: _loading
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: _TC.green,
                    ),
                  )
                : Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.play_arrow_rounded,
                        color: disabled ? _TC.textSub : _TC.green,
                        size: 18,
                      ),
                      const SizedBox(width: 6),
                      Text(
                        attemptsLeft <= 0
                            ? 'BATAS PERCOBAAN TERCAPAI'
                            : 'JALANKAN ($attemptsLeft tersisa)',
                        style: TextStyle(
                          color: disabled ? _TC.textSub : _TC.green,
                          fontWeight: FontWeight.bold,
                          fontSize: 12.5,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ],
                  ),
          ),
        ),
      ),
    );
  }

  // ── Console Output ──
  Widget _buildConsole() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          color: _TC.consoleBg,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _TC.borderLit.withOpacity(0.4), width: 1),
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              child: Row(
                children: [
                  const Icon(Icons.terminal_rounded, color: _TC.greenDim, size: 14),
                  const SizedBox(width: 6),
                  const Text(
                    'Console Output',
                    style: TextStyle(
                      color: _TC.greenDim,
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const Spacer(),
                  GestureDetector(
                    onTap: () => setState(() => _logs.clear()),
                    child: const Icon(Icons.delete_outline_rounded, color: _TC.textSub, size: 16),
                  ),
                ],
              ),
            ),
            const Divider(height: 1, color: _TC.border),
            Expanded(
              child: _logs.isEmpty
                  ? const Center(
                      child: Text(
                        'Belum ada aktivitas.\nPilih mode lalu tekan JALANKAN.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: _TC.textSub, fontSize: 11.5, height: 1.5),
                      ),
                    )
                  : ListView.builder(
                      controller: _scrollCtrl,
                      padding: const EdgeInsets.all(12),
                      itemCount: _logs.length,
                      itemBuilder: (_, i) => _buildLogLine(_logs[i]),
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLogLine(_LogLine log) {
    late final Color color;
    late final String prefix;
    switch (log.type) {
      case _LogType.input:
        color = _TC.green;
        prefix = r'$ ';
        break;
      case _LogType.output:
        color = _TC.white;
        prefix = '  ';
        break;
      case _LogType.error:
        color = _TC.red;
        prefix = '! ';
        break;
      case _LogType.info:
        color = _TC.textSub;
        prefix = '# ';
        break;
    }
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Text(
        '$prefix${log.text}',
        style: TextStyle(
          color: color,
          fontFamily: 'monospace',
          fontSize: 12,
          height: 1.4,
          fontWeight: log.type == _LogType.input ? FontWeight.bold : FontWeight.normal,
        ),
      ),
    );
  }
}
