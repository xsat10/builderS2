import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'theme_provider.dart';
import 'login_page.dart';
import 'dashboard_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'landing.dart';
import 'pintu_page.dart';

// ─────────────────────────────────────────────
//  COLOR SYSTEM — DEFAULT (fallback)
// ─────────────────────────────────────────────
class _C {
  static const bg        = Color(0xFF06131A);
  static const surface   = Color(0xFF0C1D26);
  static const card      = Color(0xFF122833);
  static const border    = Color(0xFF2B5D6A);
  static const borderLit = Color(0xFF3A7685);

  static const steel     = Color(0xFF2FA9B8);
  static const blueMid   = Color(0xFF39C7D9);
  static const blueLight = Color(0xFF5EEFFF);
  static const chrome    = Color(0xFF67DDE2);
  static const frost     = Color(0xFFB7FFF7);

  static const green     = Color(0xFF55D6C2);
  static const amber     = Color(0xFF79E6E6);
  static const red       = Color(0xFF4CD4D8);

  static const text      = Color(0xFFEFFFFF);
  static const textSub   = Color(0xFFA8D7DF);
  static const textDim   = Color(0xFF6F95A0);

  static const LinearGradient metalGrad = LinearGradient(
    colors: [Color(0xFF1A4A55), Color(0xFF39C7D9), Color(0xFF7CF7ED)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient surfaceGrad = LinearGradient(
    colors: [Color(0xFF0C1D26), Color(0xFF122833)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient bgGrad = LinearGradient(
    colors: [Color(0xFF06131A), Color(0xFF0C1D26)],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );
}

// ─────────────────────────────────────────────
//  THEME BUILDER (Dinamis dari ThemeProvider)
// ─────────────────────────────────────────────
class _AppTheme {
  static const _font = 'ShareTechMono';

  static ThemeData build(ThemeProvider theme) {
    // Ambil warna dari provider
    final Color accent = theme.accentColor;
    final Color bg = theme.bgColor;
    final Color surface = theme.surfaceColor;
    final Color card = theme.cardColor;
    final Color border = theme.borderColor;
    final Color borderLit = theme.borderLitColor;
    final Color text = theme.textColor;
    final Color textSub = theme.textSubColor;
    final Color textDim = theme.textDimColor;
    final bool isDark = theme.isDarkMode;

    final Color accentLight = Color.lerp(accent, Colors.white, 0.3)!;
    final Color accentDark = Color.lerp(accent, Colors.black, 0.3)!;

    return ThemeData(
      useMaterial3: true,
      brightness: isDark ? Brightness.dark : Brightness.light,
      fontFamily: _font,
      scaffoldBackgroundColor: bg,

      // ── Color Scheme ──────────────────────────
      colorScheme: ColorScheme(
        brightness: isDark ? Brightness.dark : Brightness.light,
        primary: accent,
        onPrimary: isDark ? bg : Colors.white,
        primaryContainer: accentDark,
        onPrimaryContainer: text,
        secondary: accentLight,
        onSecondary: bg,
        secondaryContainer: borderLit,
        onSecondaryContainer: text,
        tertiary: accent,
        onTertiary: bg,
        error: const Color(0xFFEF5350),
        onError: text,
        surface: surface,
        onSurface: text,
        surfaceContainerHighest: card,
        outline: border,
        outlineVariant: borderLit,
        shadow: Colors.black,
        scrim: Colors.black87,
        inverseSurface: text,
        onInverseSurface: bg,
        inversePrimary: accentDark,
      ),

      // ── AppBar ────────────────────────────────
      appBarTheme: AppBarTheme(
        backgroundColor: surface,
        foregroundColor: text,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: false,
        titleTextStyle: TextStyle(
          fontFamily: _font,
          fontSize: 18,
          fontWeight: FontWeight.w600,
          color: text,
          letterSpacing: 0.4,
        ),
        iconTheme: IconThemeData(color: accent, size: 22),
        actionsIconTheme: IconThemeData(color: textSub, size: 20),
        systemOverlayStyle: SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness:
              isDark ? Brightness.light : Brightness.dark,
          statusBarBrightness: isDark ? Brightness.dark : Brightness.light,
          systemNavigationBarColor: bg,
          systemNavigationBarIconBrightness:
              isDark ? Brightness.light : Brightness.dark,
        ),
      ),

      // ── Card ──────────────────────────────────
      cardTheme: CardThemeData(
        color: card,
        elevation: 0,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: border, width: 1),
        ),
        clipBehavior: Clip.antiAlias,
      ),

      // ── Elevated Button ───────────────────────
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ButtonStyle(
          backgroundColor: WidgetStateProperty.resolveWith((s) {
            if (s.contains(WidgetState.disabled)) return border;
            if (s.contains(WidgetState.pressed)) return accentDark;
            return accent;
          }),
          foregroundColor: WidgetStateProperty.resolveWith((s) {
            if (s.contains(WidgetState.disabled)) return textDim;
            return text;
          }),
          overlayColor: WidgetStateProperty.all(accentLight.withValues(alpha: 0.1)),
          elevation: WidgetStateProperty.all(0),
          shadowColor: WidgetStateProperty.all(Colors.transparent),
          padding: WidgetStateProperty.all(
            const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          ),
          shape: WidgetStateProperty.all(
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
          textStyle: WidgetStateProperty.all(
            const TextStyle(
                fontFamily: _font,
                fontSize: 14,
                fontWeight: FontWeight.w600,
                letterSpacing: 0.8),
          ),
          animationDuration: const Duration(milliseconds: 180),
        ),
      ),

      // ── Outlined Button ───────────────────────
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: ButtonStyle(
          foregroundColor: WidgetStateProperty.resolveWith((s) {
            if (s.contains(WidgetState.pressed)) return accentLight;
            return accent;
          }),
          side: WidgetStateProperty.resolveWith((s) {
            if (s.contains(WidgetState.pressed)) {
              return BorderSide(color: accent, width: 1.5);
            }
            if (s.contains(WidgetState.focused)) {
              return BorderSide(color: accentLight, width: 1.5);
            }
            return BorderSide(color: borderLit, width: 1);
          }),
          backgroundColor: WidgetStateProperty.resolveWith((s) {
            if (s.contains(WidgetState.pressed)) {
              return accent.withValues(alpha: 0.08);
            }
            return Colors.transparent;
          }),
          overlayColor:
              WidgetStateProperty.all(accent.withValues(alpha: 0.06)),
          padding: WidgetStateProperty.all(
            const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          ),
          shape: WidgetStateProperty.all(
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
          textStyle: WidgetStateProperty.all(
            const TextStyle(
                fontFamily: _font,
                fontSize: 14,
                fontWeight: FontWeight.w500,
                letterSpacing: 0.6),
          ),
        ),
      ),

      // ── Text Button ───────────────────────────
      textButtonTheme: TextButtonThemeData(
        style: ButtonStyle(
          foregroundColor: WidgetStateProperty.resolveWith((s) {
            if (s.contains(WidgetState.pressed)) return accentLight;
            return accent;
          }),
          overlayColor:
              WidgetStateProperty.all(accent.withValues(alpha: 0.08)),
          padding: WidgetStateProperty.all(
            const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          ),
          shape: WidgetStateProperty.all(
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          ),
          textStyle: WidgetStateProperty.all(
            const TextStyle(
                fontFamily: _font,
                fontSize: 13,
                fontWeight: FontWeight.w500,
                letterSpacing: 0.4),
          ),
        ),
      ),

      // ── Input / TextField ─────────────────────
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: surface,
        hoverColor: card,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: border, width: 1),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: border, width: 1),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: accent, width: 1.5),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFFEF5350), width: 1),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFFEF5350), width: 1.5),
        ),
        disabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: textDim, width: 1),
        ),
        labelStyle: TextStyle(color: textSub, fontSize: 13),
        hintStyle: TextStyle(color: textDim, fontSize: 13),
        errorStyle: const TextStyle(color: Color(0xFFEF5350), fontSize: 11),
        prefixIconColor: textSub,
        suffixIconColor: textSub,
        floatingLabelStyle: TextStyle(color: accent, fontSize: 12),
      ),

      // ── Chip ──────────────────────────────────
      chipTheme: ChipThemeData(
        backgroundColor: surface,
        selectedColor: accentDark,
        disabledColor: border,
        deleteIconColor: textSub,
        labelStyle: TextStyle(color: text, fontSize: 12, fontFamily: _font),
        secondaryLabelStyle:
            TextStyle(color: text, fontSize: 12, fontFamily: _font),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
          side: BorderSide(color: border),
        ),
        side: BorderSide(color: border),
        elevation: 0,
        pressElevation: 0,
        showCheckmark: false,
      ),

      // ── Bottom Navigation Bar ─────────────────
      bottomNavigationBarTheme: BottomNavigationBarThemeData(
        backgroundColor: surface,
        selectedItemColor: accent,
        unselectedItemColor: textDim,
        elevation: 0,
        type: BottomNavigationBarType.fixed,
        selectedLabelStyle: const TextStyle(
            fontSize: 10, fontFamily: _font, fontWeight: FontWeight.w600),
        unselectedLabelStyle:
            const TextStyle(fontSize: 10, fontFamily: _font),
      ),

      // ── Navigation Bar ────────────────────────
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: surface,
        indicatorColor: accentDark.withValues(alpha: 0.45),
        iconTheme: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.selected)) {
            return IconThemeData(color: accent, size: 22);
          }
          return IconThemeData(color: textDim, size: 22);
        }),
        labelTextStyle: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.selected)) {
            return TextStyle(
                color: accent,
                fontSize: 11,
                fontFamily: _font,
                fontWeight: FontWeight.w600);
          }
          return TextStyle(color: textDim, fontSize: 11, fontFamily: _font);
        }),
        elevation: 0,
        overlayColor: WidgetStateProperty.all(accent.withValues(alpha: 0.06)),
        labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
      ),

      // ── Drawer ────────────────────────────────
      drawerTheme: DrawerThemeData(
        backgroundColor: surface,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
            topRight: Radius.circular(24),
            bottomRight: Radius.circular(24),
          ),
        ),
      ),

      // ── Dialog ────────────────────────────────
      dialogTheme: DialogThemeData(
        backgroundColor: card,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: borderLit, width: 1),
        ),
        titleTextStyle: TextStyle(
          fontFamily: _font,
          fontSize: 18,
          fontWeight: FontWeight.w700,
          color: text,
          letterSpacing: 0.2,
        ),
        contentTextStyle: TextStyle(
          fontFamily: _font,
          fontSize: 14,
          color: textSub,
          height: 1.6,
        ),
      ),

      // ── Bottom Sheet ──────────────────────────
      bottomSheetTheme: BottomSheetThemeData(
        backgroundColor: surface,
        modalBackgroundColor: surface,
        elevation: 0,
        modalElevation: 0,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        showDragHandle: true,
        dragHandleColor: borderLit,
        dragHandleSize: const Size(40, 4),
        clipBehavior: Clip.antiAlias,
      ),

      // ── Snack Bar ─────────────────────────────
      snackBarTheme: SnackBarThemeData(
        backgroundColor: card,
        contentTextStyle:
            TextStyle(color: text, fontFamily: _font, fontSize: 13),
        actionTextColor: accent,
        behavior: SnackBarBehavior.floating,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: borderLit, width: 1),
        ),
      ),

      // ── Tab Bar ───────────────────────────────
      tabBarTheme: TabBarThemeData(
        labelColor: accent,
        unselectedLabelColor: textDim,
        indicatorColor: accent,
        indicatorSize: TabBarIndicatorSize.label,
        labelStyle: const TextStyle(
            fontFamily: _font, fontSize: 13, fontWeight: FontWeight.w600),
        unselectedLabelStyle:
            const TextStyle(fontFamily: _font, fontSize: 13),
        overlayColor: WidgetStateProperty.all(accent.withValues(alpha: 0.06)),
        dividerColor: border,
      ),

      // ── List Tile ─────────────────────────────
      listTileTheme: ListTileThemeData(
        tileColor: Colors.transparent,
        selectedTileColor: accent.withValues(alpha: 0.1),
        iconColor: textSub,
        selectedColor: accent,
        textColor: text,
        subtitleTextStyle: TextStyle(color: textSub, fontSize: 12),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
      ),

      // ── Divider ───────────────────────────────
      dividerTheme: DividerThemeData(
        color: border,
        thickness: 1,
        space: 1,
      ),

      // ── Switch ────────────────────────────────
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.selected)) return accent;
          return textDim;
        }),
        trackColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.selected)) {
            return accentDark.withValues(alpha: 0.5);
          }
          return border;
        }),
        trackOutlineColor: WidgetStateProperty.all(Colors.transparent),
        overlayColor: WidgetStateProperty.all(accent.withValues(alpha: 0.08)),
      ),

      // ── Checkbox ──────────────────────────────
      checkboxTheme: CheckboxThemeData(
        fillColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.selected)) return accent;
          return Colors.transparent;
        }),
        checkColor: WidgetStateProperty.all(text),
        side: BorderSide(color: borderLit, width: 1.5),
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
        overlayColor: WidgetStateProperty.all(accent.withValues(alpha: 0.08)),
      ),

      // ── Radio ─────────────────────────────────
      radioTheme: RadioThemeData(
        fillColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.selected)) return accent;
          return textDim;
        }),
        overlayColor: WidgetStateProperty.all(accent.withValues(alpha: 0.08)),
      ),

      // ── Slider ────────────────────────────────
      sliderTheme: SliderThemeData(
        activeTrackColor: accent,
        inactiveTrackColor: border,
        thumbColor: accent,
        overlayColor: accent.withValues(alpha: 0.12),
        valueIndicatorColor: accentDark,
        valueIndicatorTextStyle: TextStyle(
            color: text, fontSize: 12, fontFamily: _font),
        trackHeight: 3,
        thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 7),
      ),

      // ── Progress Indicator ────────────────────
      progressIndicatorTheme: ProgressIndicatorThemeData(
        color: accent,
        linearTrackColor: border,
        circularTrackColor: border,
        linearMinHeight: 3,
      ),

      // ── FAB ───────────────────────────────────
      floatingActionButtonTheme: FloatingActionButtonThemeData(
        backgroundColor: accent,
        foregroundColor: text,
        elevation: 0,
        focusElevation: 0,
        hoverElevation: 0,
        highlightElevation: 0,
        splashColor: accentLight.withValues(alpha: 0.2),
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),

      // ── Icons ─────────────────────────────────
      iconTheme: IconThemeData(color: accent, size: 22),
      primaryIconTheme: IconThemeData(color: accent, size: 22),

      // ── Popup Menu ────────────────────────────
      popupMenuTheme: PopupMenuThemeData(
        color: card,
        elevation: 0,
        shadowColor: Colors.transparent,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: borderLit, width: 1),
        ),
        textStyle: TextStyle(color: text, fontFamily: _font, fontSize: 13),
        labelTextStyle: WidgetStateProperty.all(
          TextStyle(color: text, fontFamily: _font, fontSize: 13),
        ),
        iconColor: textSub,
      ),

      // ── Tooltip ───────────────────────────────
      tooltipTheme: TooltipThemeData(
        decoration: BoxDecoration(
          color: surface,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: borderLit),
        ),
        textStyle:
            TextStyle(color: text, fontSize: 11, fontFamily: _font),
        padding:
            const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      ),

      // ── Scrollbar ─────────────────────────────
      scrollbarTheme: ScrollbarThemeData(
        thumbColor: WidgetStateProperty.all(borderLit),
        trackColor: WidgetStateProperty.all(surface),
        radius: const Radius.circular(4),
        thickness: WidgetStateProperty.all(3),
        crossAxisMargin: 2,
      ),

      // ── Page Transitions ──────────────────────
      pageTransitionsTheme: const PageTransitionsTheme(
        builders: {
          TargetPlatform.android: _ScarletTransitionBuilder(),
          TargetPlatform.iOS: _ScarletTransitionBuilder(),
          TargetPlatform.windows: _ScarletTransitionBuilder(),
          TargetPlatform.macOS: _ScarletTransitionBuilder(),
          TargetPlatform.linux: _ScarletTransitionBuilder(),
        },
      ),

      // ── Text Theme ────────────────────────────
      textTheme: TextTheme(
        displayLarge: TextStyle(
            fontFamily: _font,
            fontSize: 57,
            fontWeight: FontWeight.w800,
            color: text,
            letterSpacing: -1.5),
        displayMedium: TextStyle(
            fontFamily: _font,
            fontSize: 45,
            fontWeight: FontWeight.w700,
            color: text,
            letterSpacing: -1.0),
        displaySmall: TextStyle(
            fontFamily: _font,
            fontSize: 36,
            fontWeight: FontWeight.w700,
            color: text,
            letterSpacing: -0.5),
        headlineLarge: TextStyle(
            fontFamily: _font,
            fontSize: 32,
            fontWeight: FontWeight.w700,
            color: text,
            letterSpacing: -0.3),
        headlineMedium: TextStyle(
            fontFamily: _font,
            fontSize: 26,
            fontWeight: FontWeight.w600,
            color: text,
            letterSpacing: -0.2),
        headlineSmall: TextStyle(
            fontFamily: _font,
            fontSize: 22,
            fontWeight: FontWeight.w600,
            color: text),
        titleLarge: TextStyle(
            fontFamily: _font,
            fontSize: 18,
            fontWeight: FontWeight.w600,
            color: text,
            letterSpacing: 0.2),
        titleMedium: TextStyle(
            fontFamily: _font,
            fontSize: 15,
            fontWeight: FontWeight.w500,
            color: text,
            letterSpacing: 0.1),
        titleSmall: TextStyle(
            fontFamily: _font,
            fontSize: 13,
            fontWeight: FontWeight.w500,
            color: textSub),
        bodyLarge: TextStyle(
            fontFamily: _font,
            fontSize: 16,
            fontWeight: FontWeight.w400,
            color: text,
            height: 1.6),
        bodyMedium: TextStyle(
            fontFamily: _font,
            fontSize: 14,
            fontWeight: FontWeight.w400,
            color: text,
            height: 1.6),
        bodySmall: TextStyle(
            fontFamily: _font,
            fontSize: 12,
            fontWeight: FontWeight.w400,
            color: textSub,
            height: 1.5),
        labelLarge: TextStyle(
            fontFamily: _font,
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: text,
            letterSpacing: 0.5),
        labelMedium: TextStyle(
            fontFamily: _font,
            fontSize: 12,
            fontWeight: FontWeight.w500,
            color: textSub,
            letterSpacing: 0.4),
        labelSmall: TextStyle(
            fontFamily: _font,
            fontSize: 10,
            fontWeight: FontWeight.w500,
            color: textDim,
            letterSpacing: 0.6),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  CUSTOM PAGE TRANSITION
// ─────────────────────────────────────────────
class _ScarletTransitionBuilder extends PageTransitionsBuilder {
  const _ScarletTransitionBuilder();

  @override
  Widget buildTransitions<T>(
    PageRoute<T> route,
    BuildContext context,
    Animation<double> animation,
    Animation<double> secondaryAnimation,
    Widget child,
  ) {
    final inCurve =
        CurvedAnimation(parent: animation, curve: Curves.easeOutCubic);
    final outCurve = CurvedAnimation(
        parent: secondaryAnimation, curve: Curves.easeInCubic);

    return FadeTransition(
      opacity: inCurve,
      child: SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(0, 0.035),
          end: Offset.zero,
        ).animate(inCurve),
        child: FadeTransition(
          opacity: Tween<double>(begin: 1.0, end: 0.82).animate(outCurve),
          child: ScaleTransition(
            scale: Tween<double>(begin: 1.0, end: 0.97).animate(outCurve),
            child: child,
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  ROUTE BUILDER
// ─────────────────────────────────────────────
Route<dynamic>? _generateRoute(RouteSettings settings) {
  final args = settings.arguments as Map<String, dynamic>?;

  Widget page;

  switch (settings.name) {
    case '/':
      page = const PintuPage();
      break;

    case '/landing':
      page = const LandingPage();
      break;

    case '/login':
      page = const LoginPage();
      break;

    case '/dashboard':
      page = DashboardPage(
        username: args!['username'] as String,
        password: args['password'] as String,
        role: args['role'] as String,
        sessionKey: args['key'] as String,
        expiredDate: args['expiredDate'] as String,
        listBug: List<Map<String, dynamic>>.from(args['listBug'] ?? []),
        listDoos: List<Map<String, dynamic>>.from(args['listDoos'] ?? []),
        news: List<Map<String, dynamic>>.from(args['news'] ?? []),
      );
      break;

    case '/home':
      page = HomePage(
        username: args!['username'] as String,
        password: args['password'] as String,
        role: args['role'] as String,
        expiredDate: args['expiredDate'] as String,
        sessionKey: args['sessionKey'] as String,
        listBug: List<Map<String, dynamic>>.from(args['listBug'] ?? []),
      );
      break;

    case '/seller':
      page = SellerPage(keyToken: args!['keyToken'] as String);
      break;

    case '/admin':
      page = AdminPage(sessionKey: args!['sessionKey'] as String);
      break;

    case '/owner':
      page = OwnerPage(
        sessionKey: args!['sessionKey'] as String,
        username: args['username'] as String,
      );
      break;

    default:
      page = _NotFoundPage(routeName: settings.name ?? 'unknown');
  }

  return PageRouteBuilder<dynamic>(
    settings: settings,
    transitionDuration: const Duration(milliseconds: 320),
    reverseTransitionDuration: const Duration(milliseconds: 260),
    pageBuilder: (_, __, ___) => page,
    transitionsBuilder: (_, animation, secondaryAnimation, child) {
      final inCurve =
          CurvedAnimation(parent: animation, curve: Curves.easeOutCubic);
      final outCurve = CurvedAnimation(
          parent: secondaryAnimation, curve: Curves.easeInCubic);

      return FadeTransition(
        opacity: inCurve,
        child: SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(0, 0.035),
            end: Offset.zero,
          ).animate(inCurve),
          child: FadeTransition(
            opacity: Tween<double>(begin: 1.0, end: 0.82).animate(outCurve),
            child: ScaleTransition(
              scale: Tween<double>(begin: 1.0, end: 0.97).animate(outCurve),
              child: child,
            ),
          ),
        ),
      );
    },
  );
}

// ─────────────────────────────────────────────
//  404 PAGE
// ─────────────────────────────────────────────
class _NotFoundPage extends StatefulWidget {
  const _NotFoundPage({required this.routeName});
  final String routeName;

  @override
  State<_NotFoundPage> createState() => _NotFoundPageState();
}

class _NotFoundPageState extends State<_NotFoundPage>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _fade;
  late final Animation<Offset> _slide;
  late final Animation<double> _glow;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 800))
      ..forward();

    _fade = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _slide = Tween<Offset>(begin: const Offset(0, 0.08), end: Offset.zero)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic));
    _glow = Tween<double>(begin: 0, end: 1).animate(CurvedAnimation(
        parent: _ctrl,
        curve: const Interval(0.5, 1, curve: Curves.easeOut)));
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return Scaffold(
      backgroundColor: theme.bgColor,
      body: Center(
        child: FadeTransition(
          opacity: _fade,
          child: SlideTransition(
            position: _slide,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 32),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  AnimatedBuilder(
                    animation: _glow,
                    builder: (_, child) => Container(
                      width: 88,
                      height: 88,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: theme.surfaceColor,
                        border: Border.all(
                            color: theme.borderLitColor, width: 1.5),
                        boxShadow: [
                          BoxShadow(
                            color: theme.accentColor.withValues(
                                alpha: 0.25 * _glow.value),
                            blurRadius: 40,
                            spreadRadius: 6,
                          ),
                        ],
                      ),
                      child: child,
                    ),
                    child: Icon(Icons.explore_off_rounded,
                        color: theme.textSubColor, size: 34),
                  ),
                  const SizedBox(height: 28),
                  ShaderMask(
                    shaderCallback: (bounds) => LinearGradient(
                      colors: [
                        theme.textDimColor,
                        theme.borderLitColor,
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ).createShader(bounds),
                    child: const Text(
                      '404',
                      style: TextStyle(
                        fontFamily: 'ShareTechMono',
                        fontSize: 72,
                        fontWeight: FontWeight.w800,
                        color: Colors.white,
                        height: 1,
                        letterSpacing: -3,
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    'Route not found',
                    style: TextStyle(
                      fontFamily: 'ShareTechMono',
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: theme.textSubColor,
                      letterSpacing: 0.3,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 5),
                    decoration: BoxDecoration(
                      color: theme.surfaceColor,
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(color: theme.borderColor),
                    ),
                    child: Text(
                      '"${widget.routeName}"',
                      style: TextStyle(
                        fontFamily: 'ShareTechMono',
                        fontSize: 12,
                        color: theme.textDimColor,
                        letterSpacing: 0.2,
                      ),
                    ),
                  ),
                  const SizedBox(height: 36),
                  OutlinedButton.icon(
                    onPressed: () => Navigator.of(context)
                        .pushNamedAndRemoveUntil('/', (_) => false),
                    icon: const Icon(Icons.arrow_back_rounded, size: 16),
                    label: const Text('Back to Home'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
//  ENTRY POINT
// ─────────────────────────────────────────────
void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Init theme provider & load saved theme
  final themeProvider = ThemeProvider();
  await themeProvider.loadTheme();

  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    statusBarBrightness: Brightness.dark,
    systemNavigationBarColor: _C.bg,
    systemNavigationBarDividerColor: Colors.transparent,
    systemNavigationBarIconBrightness: Brightness.light,
  ));

  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  runApp(
    ChangeNotifierProvider.value(
      value: themeProvider,
      child: const _OrcaApp(),
    ),
  );
}

// ─────────────────────────────────────────────
//  ROOT APP WIDGET
// ─────────────────────────────────────────────
class _OrcaApp extends StatelessWidget {
  const _OrcaApp();

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Syam',
      theme: _AppTheme.build(theme),
      initialRoute: '/',
      onGenerateRoute: _generateRoute,

      builder: (context, child) {
        final mq = MediaQuery.of(context);
        return MediaQuery(
          data: mq.copyWith(
            textScaler: TextScaler.linear(
              mq.textScaleFactor.clamp(0.85, 1.2),
            ),
          ),
          child: child ?? const SizedBox.shrink(),
        );
      },
    );
  }
}