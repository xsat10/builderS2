import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:permission_handler/permission_handler.dart';
import 'login_page.dart';
import 'dashboard_page.dart';
import 'bugs/home_page.dart';
import 'manager/admin_page.dart';
import 'landing.dart';
import 'servers.dart';
import 'package:firebase_core/firebase_core.dart';
import 'push_notification_service.dart';

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    final config = await Servers.loadConfig();
    final firebaseOptions = Servers.firebaseOptionsFrom(config);
    if (firebaseOptions != null) {
      await Firebase.initializeApp(options: firebaseOptions);
    } else {
      await Firebase.initializeApp();
    }
  } catch (_) {
    // The bundled google-services.json provides the native Firebase
    // configuration when the remote Config.json has no Firebase block.
    try {
      await Firebase.initializeApp();
    } catch (_) {
      // Firebase is optional during startup.
    }
  }
  runApp(const MyApp());
}

class NotificationGatePage extends StatefulWidget {
  const NotificationGatePage({super.key});

  @override
  State<NotificationGatePage> createState() => _NotificationGatePageState();
}

class _NotificationGatePageState extends State<NotificationGatePage> {
  bool _working = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _startPermissionFlow());
  }

  Future<void> _startPermissionFlow() async {
    if (_working || !mounted) return;
    _working = true;

    // Android 13+ membutuhkan izin POST_NOTIFICATIONS sebelum aplikasi dapat
    // menerima pemberitahuan. Pada Android versi lama izin ini sudah otomatis.
    final current = await Permission.notification.status;
    if (current.isGranted || current.isLimited) {
      await _continueToApp();
      return;
    }

    final shouldRequest = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (context) => PopScope(
        canPop: false,
        child: AlertDialog(
          title: const Text('BERIKAN IZIN NOTIFIKASI'),
          content: const Text(
            'BERIKAN IZIN NOTIFIKASI UNTUK MENERIMA PEMBERITAHUAN DARI SISTEM APABILA ADA PEMBERITAHUAN DARI DEVELOPER',
          ),
          actions: [
            FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: const Color(0xFFE30613),
                foregroundColor: Colors.white,
              ),
              onPressed: () => Navigator.of(context).pop(true),
              child: const Text('BERIKAN IZIN'),
            ),
          ],
        ),
      ),
    );

    if (shouldRequest != true || !mounted) {
      SystemNavigator.pop();
      return;
    }

    final result = await Permission.notification.request();
    if (result.isGranted || result.isLimited) {
      await _continueToApp();
    } else {
      // Tanpa izin notifikasi aplikasi tidak dapat digunakan.
      SystemNavigator.pop();
    }
  }

  Future<void> _continueToApp() async {
    try {
      if (Firebase.apps.isNotEmpty) {
        await PushNotificationService.initialize();
        await PushNotificationService.requestPermissionAndSubscribe();
      }
    } catch (_) {}

    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => LandingPage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: CircularProgressIndicator(),
      ),
    );
  }
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      navigatorKey: navigatorKey,
      title: 'GHOST CRASHER',
      theme: ThemeData(
        brightness: Brightness.dark,
        fontFamily: 'Orbitron',
        scaffoldBackgroundColor: Colors.black,
        colorScheme: ColorScheme.dark().copyWith(
          secondary: Colors.purple,
        ),
      ),
      initialRoute: '/',
      onGenerateRoute: (settings) {
        switch (settings.name) {
          case '/':
            return MaterialPageRoute(builder: (_) => const NotificationGatePage());

          case '/login':
            return MaterialPageRoute(builder: (_) => const LoginPage());

          case '/dashboard':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => DashboardPage(
                username: args['username'],
                password: args['password'],
                role: args['role'],
                expiredDate: args['expiredDate'],
                // ⬇️ TAMBAHKAN INI
                sessionKey: args['sessionKey'] ?? '',
                // ⬆️
                listBug:
                    List<Map<String, dynamic>>.from(args['listBug'] ?? []),
                listDoos:
                    List<Map<String, dynamic>>.from(args['listDoos'] ?? []),
                news: List<Map<String, dynamic>>.from(args['news'] ?? []),
              ),
            );

          case '/home':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => HomePage(
                username: args['username'],
                password: args['password'],
                listBug:
                    List<Map<String, dynamic>>.from(args['listBug'] ?? []),
                role: args['role'],
                expiredDate: args['expiredDate'],
                sessionKey: args['sessionKey'],
              ),
            );

          case '/admin':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => AdminPage(
                sessionKey: args['sessionKey'],
                currentUserRole: args['role'],
              ),
            );

          default:
            return MaterialPageRoute(
              builder: (_) => const Scaffold(
                body: Center(child: Text("404 - Not Found")),
              ),
            );
        }
      },
    );
  }
}