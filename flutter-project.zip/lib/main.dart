import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'screens/add_session_screen.dart';
import 'screens/dashboard_screen.dart';
import 'screens/login_screen.dart';
import 'screens/send_message_screen.dart';
import 'services/api_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Color(0xFF000000),
    ),
  );
  final loggedIn = await ApiService.instance.hasToken();
  runApp(LanzApp(loggedIn: loggedIn));
}

class LanzApp extends StatelessWidget {
  const LanzApp({super.key, required this.loggedIn});

  final bool loggedIn;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Lanz MD Tools',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF000000),
        fontFamily: 'Roboto',
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFFFF0000),
          surface: Color(0xFF000000),
          onPrimary: Color(0xFFFFFFFF),
          onSurface: Color(0xFFF4F4F5),
        ),
        snackBarTheme: const SnackBarThemeData(
          behavior: SnackBarBehavior.floating,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFF141414),
          labelStyle: const TextStyle(color: Color(0xFF8B8B90)),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: Color(0xFF242428)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: Color(0xFFFF0000)),
          ),
        ),
      ),
      initialRoute: loggedIn ? '/dashboard' : '/login',
      routes: {
        '/login': (_) => const LoginScreen(),
        '/dashboard': (_) => const DashboardScreen(),
        '/add-session': (_) => const AddSessionScreen(),
        '/send-message': (_) => const SendMessageScreen(),
      },
    );
  }
}
