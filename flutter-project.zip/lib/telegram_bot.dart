// telegram_bot.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'login_page.dart';

class TelegramBot {
  // 🔥 TOKEN & OWNER IDS (MULTIPLE OWNERS)
  final String token = "8859693895:AAGAHP810zs2eJWQxConUQf3CqWXi5tbxh4";
  final List<String> ownerIds = ["8405047604"];

  // State variables
  bool _isMaintenance = false;
  String _maintenanceMessage = "⏳ Sistem sedang dalam perbaikan. Kembali lagi nanti.";

  final GlobalKey<NavigatorState> navigatorKey;
  bool _isRunning = false;

  TelegramBot(this.navigatorKey) {
    _loadMaintenanceStatus();
    _startBot();
  }

  // ─── LOAD / SAVE ───────────────────────────────────────────────

  Future<void> _loadMaintenanceStatus() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      _isMaintenance = prefs.getBool('maintenance_mode') ?? false;
      _maintenanceMessage = prefs.getString('maintenance_message') ?? 
          "⏳ Sistem sedang dalam perbaikan. Kembali lagi nanti.";
      print('📌 Maintenance loaded: $_isMaintenance');
    } catch (e) {
      print('❌ Error loading maintenance: $e');
    }
  }

  Future<void> _saveMaintenanceStatus() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('maintenance_mode', _isMaintenance);
      await prefs.setString('maintenance_message', _maintenanceMessage);
      print('💾 Maintenance saved: $_isMaintenance');
    } catch (e) {
      print('❌ Error saving maintenance: $e');
    }
  }

  // ─── BOT CORE ──────────────────────────────────────────────────

  void _startBot() {
    if (!_isRunning) {
      _isRunning = true;
      start();
    }
  }

  Future<void> start() async {
    print('🚀 Bot starting...');
    var offset = 0;
    
    // Test koneksi
    await _testConnection();
    
    while (_isRunning) {
      try {
        final res = await http.get(
          Uri.parse(
            "https://api.telegram.org/bot$token/getUpdates?offset=$offset&timeout=30"
          ),
        );
        
        if (res.statusCode == 200) {
          final data = jsonDecode(res.body);
          if (data['ok'] == true) {
            if (data['result'].isNotEmpty) {
              print('📨 Received ${data['result'].length} updates');
            }
            for (var update in data['result']) {
              offset = update['update_id'] + 1;
              await _handleUpdate(update);
            }
          }
        }
      } catch (e) {
        print("❌ Bot error: $e");
      }
      await Future.delayed(const Duration(seconds: 1));
    }
  }

  Future<void> _testConnection() async {
    try {
      final response = await http.get(
        Uri.parse("https://api.telegram.org/bot$token/getMe"),
      );
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['ok'] == true) {
          print('✅ Bot connected: @${data['result']['username']}');
          // Kirim notifikasi ke owner
          _sendMessage(ownerIds.first, "✅ Bot started successfully!");
        } else {
          print('❌ Bot error: ${data['description']}');
        }
      }
    } catch (e) {
      print('❌ Connection error: $e');
    }
  }

  Future<void> _handleUpdate(Map update) async {
    final msg = update['message'];
    final callback = update['callback_query'];

    // ─── HANDLE CALLBACK QUERY ──────────────────────────────────
    if (callback != null) {
      final chatId = callback['message']['chat']['id'].toString();
      final data = callback['data'];
      final isOwner = ownerIds.contains(chatId);

      if (!isOwner) {
        await _answerCallback(callback['id'], "Akses ditolak.");
        return;
      }

      await _answerCallback(callback['id'], "✅");
      await _handleMenuCommand(data, chatId, callback['message']['message_id']);
      return;
    }

    if (msg == null) return;

    final chatId = msg['chat']['id'].toString();
    final text = msg['text'] ?? "";
    final isOwner = ownerIds.contains(chatId);

    // ─── CEK OWNER ──────────────────────────────────────────────
    if (!isOwner) {
      _sendMessage(chatId, "❌ Akses ditolak. Anda tidak memiliki izin.");
      return;
    }

    // ─── HANDLE /start ──────────────────────────────────────────
    if (text == "/start") {
      await _showMainMenu(chatId);
      return;
    }

    // ─── UNKNOWN COMMAND ────────────────────────────────────────
    _sendMessage(
      chatId,
      "❌ Perintah tidak dikenali.\n\nKetik /start untuk menu utama."
    );
  }

  // ─── HANDLE MENU COMMAND ──────────────────────────────────────

  Future<void> _handleMenuCommand(String command, String chatId, int messageId) async {
    Map<String, dynamic> content;
    
    switch (command) {
      case 'menu_main':
        content = await _buildMainMenu();
        break;
      case 'menu_maintenance':
        content = await _buildMaintenanceMenu();
        break;
      case 'maintenance_on':
        content = await _buildMaintenanceOn();
        break;
      case 'maintenance_off':
        content = await _buildMaintenanceOff();
        break;
      default:
        content = await _buildMainMenu();
    }
    
    await _editMessage(chatId, messageId, content);
  }

  // ─── MENU BUILDERS ────────────────────────────────────────────

  Future<Map<String, dynamic>> _buildMainMenu() async {
    String currentDomain = await ApiConfig.getBaseUrl();
    String status = _isMaintenance ? "🚧 MAINTENANCE" : "🟢 ONLINE";
    
    String text = 
      "🤖 **MAINTENANCE BOT**\n\n"
      "━━━━━━━━━━━━━━━━━━━━━━━━━\n"
      "📡 **Domain:**\n"
      "`$currentDomain`\n\n"
      "🛠 **Status:** $status\n"
      "━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
      "📌 Pilih menu di bawah:";

    Map<String, dynamic> keyboard = {
      "inline_keyboard": [
        [
          {"text": "🔧 Maintenance", "callback_data": "menu_maintenance"}
        ]
      ]
    };

    return {
      "text": text,
      "reply_markup": keyboard,
    };
  }

  Future<Map<String, dynamic>> _buildMaintenanceMenu() async {
    String status = _isMaintenance ? "🚧 AKTIF" : "🟢 NONAKTIF";
    
    String text = 
      "🔧 **MAINTENANCE CONTROL**\n\n"
      "━━━━━━━━━━━━━━━━━━━━━━━━━\n"
      "📌 **Status:** $status\n"
      "📝 **Pesan:**\n"
      "`$_maintenanceMessage`\n"
      "━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
      "📌 Pilih tindakan:";

    Map<String, dynamic> keyboard = {
      "inline_keyboard": [
        [
          {"text": "🟢 AKTIFKAN", "callback_data": "maintenance_on"},
          {"text": "🔴 NONAKTIFKAN", "callback_data": "maintenance_off"}
        ],
        [
          {"text": "🏠 Kembali", "callback_data": "menu_main"}
        ]
      ]
    };

    return {
      "text": text,
      "reply_markup": keyboard,
    };
  }

  // ─── MAINTENANCE ACTIONS ─────────────────────────────────────

  Future<Map<String, dynamic>> _buildMaintenanceOn() async {
    _isMaintenance = true;
    _maintenanceMessage = "⏳ Sistem sedang dalam perbaikan. Kembali lagi nanti.";
    await _saveMaintenanceStatus();

    String text = 
      "🔧 **MAINTENANCE AKTIF!**\n\n"
      "━━━━━━━━━━━━━━━━━━━━━━━━━\n"
      "✅ Mode maintenance telah diaktifkan.\n\n"
      "📝 **Pesan:**\n"
      "`$_maintenanceMessage`\n"
      "━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
      "⚠️ **SEMUA PENGGUNA AKAN LOGOUT OTOMATIS!**\n"
      "⏳ Logout dalam 3 detik...";

    // Auto logout semua pengguna setelah 3 detik
    Future.delayed(const Duration(seconds: 3), () {
      navigatorKey.currentState?.pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const LoginPage()),
        (route) => false,
      );
    });

    Map<String, dynamic> keyboard = {
      "inline_keyboard": [
        [
          {"text": "🔧 Maintenance Menu", "callback_data": "menu_maintenance"},
          {"text": "🏠 Home", "callback_data": "menu_main"}
        ]
      ]
    };

    return {
      "text": text,
      "reply_markup": keyboard,
    };
  }

  Future<Map<String, dynamic>> _buildMaintenanceOff() async {
    _isMaintenance = false;
    await _saveMaintenanceStatus();

    String text = 
      "🔧 **MAINTENANCE NONAKTIF**\n\n"
      "━━━━━━━━━━━━━━━━━━━━━━━━━\n"
      "✅ Mode maintenance telah dinonaktifkan.\n\n"
      "🟢 Sistem kembali normal.\n"
      "Semua pengguna dapat login kembali.\n"
      "━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
      "🔄 Silakan restart aplikasi untuk update.";

    Map<String, dynamic> keyboard = {
      "inline_keyboard": [
        [
          {"text": "🔧 Maintenance Menu", "callback_data": "menu_maintenance"},
          {"text": "🏠 Home", "callback_data": "menu_main"}
        ]
      ]
    };

    return {
      "text": text,
      "reply_markup": keyboard,
    };
  }

  // ─── HELPERS ──────────────────────────────────────────────────

  Future<void> _showMainMenu(String chatId) async {
    var menu = await _buildMainMenu();
    _sendMessage(chatId, menu['text'] as String, replyMarkup: menu['reply_markup'] as Map<String, dynamic>?);
  }

  Future<void> _editMessage(String chatId, int messageId, Map<String, dynamic> content) async {
    try {
      Map<String, dynamic> payload = {
        "chat_id": chatId,
        "message_id": messageId,
        "text": content['text'] as String,
        "parse_mode": "Markdown",
      };
      
      if (content.containsKey('reply_markup') && content['reply_markup'] != null) {
        payload["reply_markup"] = jsonEncode(content['reply_markup']);
      }
      
      final response = await http.post(
        Uri.parse("https://api.telegram.org/bot$token/editMessageText"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode(payload),
      );
      
      if (response.statusCode != 200) {
        print('❌ Edit message error: ${response.body}');
      }
    } catch (e) {
      print('❌ Edit message exception: $e');
    }
  }

  Future<void> _answerCallback(String callbackId, String text) async {
    try {
      await http.post(
        Uri.parse("https://api.telegram.org/bot$token/answerCallbackQuery"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "callback_query_id": callbackId,
          "text": text,
          "show_alert": false,
        }),
      );
    } catch (e) {
      print('❌ Answer callback exception: $e');
    }
  }

  void _sendMessage(String chatId, String text, {Map<String, dynamic>? replyMarkup}) {
    try {
      Map<String, dynamic> payload = {
        "chat_id": chatId,
        "text": text,
        "parse_mode": "Markdown",
      };
      
      if (replyMarkup != null) {
        payload["reply_markup"] = jsonEncode(replyMarkup);
      }
      
      http.post(
        Uri.parse("https://api.telegram.org/bot$token/sendMessage"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode(payload),
      ).then((response) {
        if (response.statusCode != 200) {
          print('❌ Send message error: ${response.body}');
        }
      });
    } catch (e) {
      print('❌ Send message exception: $e');
    }
  }

  // ─── STOP BOT ──────────────────────────────────────────────────

  void stop() {
    _isRunning = false;
    print('🛑 Bot stopped');
  }
}