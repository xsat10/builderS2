import 'package:flutter/material.dart';
import 'device_dashboard.dart'; // ✅ IMPORT HALAMAN TUJUAN

// ══════════════════════════════════════════════════════════════════════════════
//  COLORS
// ══════════════════════════════════════════════════════════════════════════════
const Color _bgCream    = Color(0xFFFDF6E3);
const Color _blueAccent = Color(0xFF2E75B6);
const Color _blueDark   = Color(0xFF1E5A96);
const Color _textDark   = Color(0xFF1A1A1A);
const Color _textGray   = Color(0xFF888888);
const Color _borderBlue = Color(0xFF2E75B6);

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: 'Roboto',
        scaffoldBackgroundColor: _bgCream,
      ),
      // ⚠️ GANTI dengan sessionKey asli dari login/pairing kamu
      home: const SellectPage2(sessionKey: 'ISI_SESSION_KEY_DISINI'),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
//  SELLECT PAGE 2
// ══════════════════════════════════════════════════════════════════════════════
class SellectPage2 extends StatefulWidget {
  // ✅ TAMBAH: sessionKey wajib diterima
  final String sessionKey;

  const SellectPage2({super.key, required this.sessionKey});

  @override
  State<SellectPage2> createState() => _SellectPage2State();
}

class _SellectPage2State extends State<SellectPage2> {
  late PageController _pageController;
  int _currentPage = 0;

  final List<Map<String, dynamic>> menus = [
    {
      'title': 'Auto Modifikasi',
      'desc': 'Builder APK · auto modifikasi aplikasi',
      'color': _blueAccent,
      'icon': Icons.android_rounded,
      'badge': 'BUILD',
      'isActive': true,
    },
    {
      'title': 'SYAM EXPLOIT',
      'desc': 'Nuke WA · crash system · auto send',
      'color': const Color(0xFFE53935),
      'icon': Icons.warning_amber_rounded,
      'badge': 'BUG',
      'isActive': true,
    },
    {
      'title': 'SYAM RAT',
      'desc': 'Remote access trojan · stealth mode',
      'color': const Color(0xFF7C4DFF),
      'icon': Icons.security_rounded,
      'badge': 'RAT',
      'isActive': true,
    },
    {
      'title': 'SYAM TOOLS',
      'desc': 'Kumpulan tools premium · utility',
      'color': const Color(0xFF43A047),
      'icon': Icons.build_circle_rounded,
      'badge': 'TOOLS',
      'isActive': true,
    },
  ];

  @override
  void initState() {
    super.initState();
    _pageController = PageController(viewportFraction: 0.82, initialPage: 0);
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bgCream,
      body: Stack(
        children: [
          // ── Background asset background.jpg ──────────────────
          Positioned.fill(
            child: Image.asset(
              'assets/images/background.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(color: _bgCream),
            ),
          ),

          // ── Overlay putih 30% biar card & text kebaca ────────
          Positioned.fill(
            child: Container(
              color: Colors.white.withValues(alpha: 0.3),
            ),
          ),

          // ── Konten ─────────────────────────────────────────────
          SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ── Header ──────────────────────────────────────
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 14, 20, 0),
                  child: Stack(
                    clipBehavior: Clip.none,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Badge SYAM RAT
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 6),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              border:
                                  Border.all(color: _textDark, width: 2),
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: const [
                                BoxShadow(
                                    color: Colors.black,
                                    offset: Offset(2, 2),
                                    blurRadius: 0),
                              ],
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Container(
                                  width: 8,
                                  height: 8,
                                  decoration: const BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: Color(0xFF43A047),
                                  ),
                                ),
                                const SizedBox(width: 8),
                                const Text(
                                  'SYAM RAT',
                                  style: TextStyle(
                                    color: _textDark,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 1,
                                  ),
                                ),
                              ],
                            ),
                          ),

                          // Badge Tutorial
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 6),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              border:
                                  Border.all(color: _textDark, width: 2),
                              borderRadius: BorderRadius.circular(8),
                              boxShadow: const [
                                BoxShadow(
                                    color: Colors.black,
                                    offset: Offset(2, 2),
                                    blurRadius: 0),
                              ],
                            ),
                            child: const Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.play_circle_fill_rounded,
                                    color: Color(0xFFE53935), size: 16),
                                SizedBox(width: 4),
                                Text(
                                  'Tutorial',
                                  style: TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w900,
                                    color: _textDark,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),

                      // Gantungan
                      Positioned(
                        right: 20,
                        top: -10,
                        child: Image.asset(
                          'assets/images/gantungan.png',
                          width: 75,
                          height: 75,
                          fit: BoxFit.contain,
                          errorBuilder: (_, __, ___) =>
                              const SizedBox.shrink(),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 24),

                // ── Judul "Pilih RAT" ────────────────────────────
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Stack(
                        children: [
                          Positioned(
                            left: 3,
                            top: 3,
                            child: Text(
                              'Pilih RAT',
                              style: TextStyle(
                                fontSize: 38,
                                fontWeight: FontWeight.w900,
                                fontStyle: FontStyle.italic,
                                color:
                                    Colors.black.withValues(alpha: 0.12),
                                letterSpacing: -1,
                              ),
                            ),
                          ),
                          const Text(
                            'Pilih RAT',
                            style: TextStyle(
                              fontSize: 38,
                              fontWeight: FontWeight.w900,
                              fontStyle: FontStyle.italic,
                              color: _textDark,
                              letterSpacing: -1,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 3),
                        decoration: BoxDecoration(
                          color: _textDark,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          '${menus.length} menu',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 24),

                // ── PageView Card ────────────────────────────────
                Expanded(
                  child: PageView.builder(
                    controller: _pageController,
                    onPageChanged: (i) =>
                        setState(() => _currentPage = i),
                    itemCount: menus.length,
                    itemBuilder: (context, i) =>
                        _buildMenuCard(menus[i], i),
                  ),
                ),

                const SizedBox(height: 16),

                // ── Dot Indicator ────────────────────────────────
                Center(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(menus.length, (i) {
                      final active = _currentPage == i;
                      return AnimatedContainer(
                        duration: const Duration(milliseconds: 300),
                        margin: const EdgeInsets.symmetric(horizontal: 4),
                        width: active ? 24 : 8,
                        height: 8,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(4),
                          color: active
                              ? _blueAccent
                              : Colors.grey.withValues(alpha: 0.4),
                        ),
                      );
                    }),
                  ),
                ),

                const SizedBox(height: 20),

                // ── Info Card Bawah ──────────────────────────────
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: _buildBottomInfoCard(menus[_currentPage]),
                ),

                const SizedBox(height: 14),

                // ── Tombol Besar ─────────────────────────────────
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
                  child: GestureDetector(
                    onTap: () => _onMenuTap(menus[_currentPage]),
                    child: Container(
                      height: 58,
                      decoration: BoxDecoration(
                        color: _blueAccent,
                        borderRadius: BorderRadius.circular(14),
                        boxShadow: [
                          BoxShadow(
                            color: _blueAccent.withValues(alpha: 0.4),
                            blurRadius: 15,
                            offset: const Offset(0, 6),
                          ),
                        ],
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            'Buka ${menus[_currentPage]['title']}',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 0.5,
                            ),
                          ),
                          const SizedBox(width: 8),
                          const Icon(Icons.arrow_forward_rounded,
                              color: Colors.white, size: 20),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════════════
  //  CARD MENU
  // ═════════════════════════════════════════════════════════════════════
  Widget _buildMenuCard(Map<String, dynamic> menu, int index) {
    final bool isActive = _currentPage == index;
    final Color accent = menu['color'];
    final IconData icon = menu['icon'];
    final String title = menu['title'];
    final String desc = menu['desc'];
    final String badge = menu['badge'];

    return AnimatedScale(
      duration: const Duration(milliseconds: 350),
      curve: Curves.easeOutCubic,
      scale: isActive ? 1.0 : 0.92,
      child: AnimatedOpacity(
        duration: const Duration(milliseconds: 350),
        opacity: isActive ? 1.0 : 0.5,
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 8),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(28),
            border: Border.all(
              color: _borderBlue.withValues(alpha: 0.55),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.08),
                blurRadius: 20,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Icon + Badge
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    width: 66,
                    height: 66,
                    decoration: BoxDecoration(
                      color: accent.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(
                        color: accent.withValues(alpha: 0.3),
                        width: 1.2,
                      ),
                    ),
                    child: Icon(icon, color: accent, size: 32),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 6),
                    decoration: BoxDecoration(
                      color: accent.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: accent.withValues(alpha: 0.4),
                        width: 1.2,
                      ),
                    ),
                    child: Text(
                      badge,
                      style: TextStyle(
                        color: accent,
                        fontSize: 11,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ),
                ],
              ),

              const Spacer(),

              // Judul
              Text(
                title,
                style: const TextStyle(
                  color: _textDark,
                  fontSize: 26,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -0.5,
                ),
              ),

              const SizedBox(height: 8),

              // Subtitle
              Text(
                desc,
                style: const TextStyle(
                  color: _textGray,
                  fontSize: 13,
                  height: 1.4,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),

              const SizedBox(height: 22),

              // Tombol Buka menu
              GestureDetector(
                onTap: () => _onMenuTap(menu),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 22, vertical: 12),
                  decoration: BoxDecoration(
                    color: accent,
                    borderRadius: BorderRadius.circular(30),
                    boxShadow: [
                      BoxShadow(
                        color: accent.withValues(alpha: 0.35),
                        blurRadius: 12,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        'Buka menu',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 0.3,
                        ),
                      ),
                      SizedBox(width: 8),
                      Icon(Icons.arrow_forward_rounded,
                          color: Colors.white, size: 16),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════════════
  //  INFO CARD BAWAH
  // ═════════════════════════════════════════════════════════════════════
  Widget _buildBottomInfoCard(Map<String, dynamic> menu) {
    final Color accent = menu['color'];
    final IconData icon = menu['icon'];

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Colors.black.withValues(alpha: 0.08),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: accent.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: accent.withValues(alpha: 0.3),
                width: 1,
              ),
            ),
            child: Icon(icon, color: accent, size: 22),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  menu['title'],
                  style: const TextStyle(
                    color: _textDark,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  menu['desc'],
                  style: const TextStyle(
                    color: _textGray,
                    fontSize: 11,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          Icon(
            Icons.arrow_forward_ios_rounded,
            color: Colors.grey.withValues(alpha: 0.5),
            size: 14,
          ),
        ],
      ),
    );
  }

  // ═════════════════════════════════════════════════════════════════════
  //  HANDLE TAP — kirim sessionKey ke DeviceDashboardPage
  // ═════════════════════════════════════════════════════════════════════
  void _onMenuTap(Map<String, dynamic> menu) {
    if (!mounted) return;

    // ✅ KIRIM sessionKey — WAJIB karena DeviceDashboardPage butuh
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => DeviceDashboardPage(
          sessionKey: widget.sessionKey,
        ),
      ),
    );
  }
}