import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'api_config.dart';

// ═══════════════════════════════════════════════════════════════════════════
// MODERATOR PAGE — Tema "Neon Violet Scanner"
// UI: Kartu neon dengan garis scan bergerak vertikal, sudut bracket khas
// panel security/CCTV, aksen ungu-violet menyala.
// ═══════════════════════════════════════════════════════════════════════════

const String _apiBase = 'http://shinoa-cpanelpanel.xtxintax.my.id:2003';

class ModeratorPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const ModeratorPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<ModeratorPage> createState() => _ModeratorPageState();
}

class _ModeratorPageState extends State<ModeratorPage> with SingleTickerProviderStateMixin {
  late String sessionKey;
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];

  final List<String> roleOptions = [
  'moderator',
  'ceo_utama',
  'tangan_kanan',
  'tangan_kiri',
  'developers',
  'partner_pribadi',
  'partner',
  'admin',
  'reseller',
  'tukang_bubur',
  'vip',
  'member',
];
  String selectedRole = 'member';

  int currentPage = 1;
  int itemsPerPage = 25;

  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  final deleteController = TextEditingController();
  final editUsernameController = TextEditingController();
  final editDayController = TextEditingController();

  String newUserRole = 'member';
  bool isLoading = false;

  late AnimationController _scanCtrl;

  // ── TEMA VIOLET NEON ──
  final Color bgDark = const Color(0xFF0B0714);
  final Color primaryViolet = const Color(0xFF8B5CF6);
  final Color accentNeon = const Color(0xFFC084FC);
  final Color primaryWhite = Colors.white;
  final Color textGrey = Colors.grey.shade400;
  final Color cardDark = const Color(0xFF15101F);
  final Color borderGlass = const Color(0xFF8B5CF6).withOpacity(0.22);

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    _scanCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat();
    _fetchUsers();
  }

  @override
  void dispose() {
    _scanCtrl.dispose();
    super.dispose();
  }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse('$_apiBase/listUsers?key=$sessionKey'));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _alert("Info", data['message'] ?? 'Gagal memuat user.');
      }
    } catch (_) {
      _alert("Error", "Gagal terhubung ke server.");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList = fullUserList.where((u) => u['role'] == selectedRole).toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = (start + itemsPerPage);
    return filteredList.sublist(start, end > filteredList.length ? filteredList.length : end);
  }

  int get totalPages => (filteredList.length / itemsPerPage).ceil().clamp(1, 9999);

  Future<void> _deleteUser() async {
    final username = deleteController.text.trim();
    if (username.isEmpty) {
      _alert("Peringatan", "Masukkan username yang ingin dihapus.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse('$_apiBase/deleteUser?key=$sessionKey&username=$username'));
      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        _alert("Sukses", "User berhasil dihapus.");
        deleteController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal menghapus user.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _createAccount() async {
    final u = createUsernameController.text.trim();
    final p = createPasswordController.text.trim();
    final d = createDayController.text.trim();
    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final url = Uri.parse('$_apiBase/userAdd?key=$sessionKey&username=$u&password=$p&day=$d&role=$newUserRole');
      final res = await http.get(url);
      final data = jsonDecode(res.body);
      if (data['created'] == true) {
        _alert("Sukses", "Akun berhasil dibuat sebagai ${newUserRole.toUpperCase()}.");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        newUserRole = 'member';
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal membuat akun.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _editUser() async {
    final u = editUsernameController.text.trim();
    final d = editDayController.text.trim();
    if (u.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final url = Uri.parse('$_apiBase/editUser?key=$sessionKey&username=$u&addDays=$d');
      final res = await http.get(url);
      final data = jsonDecode(res.body);
      if (data['edited'] == true) {
        _alert("Sukses", "Durasi berhasil diperbarui.");
        editUsernameController.clear();
        editDayController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal mengubah durasi.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  void _alert(String title, String message) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: cardDark,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: BorderSide(color: borderGlass)),
        title: Row(children: [Icon(FontAwesomeIcons.shieldHalved, color: accentNeon, size: 18), const SizedBox(width: 10), Text(title, style: TextStyle(color: primaryWhite))]),
        content: Text(message, style: TextStyle(color: textGrey)),
        actions: [
          Center(
            child: Container(
              decoration: BoxDecoration(gradient: LinearGradient(colors: [primaryViolet, accentNeon]), borderRadius: BorderRadius.circular(12)),
              child: TextButton(onPressed: () => Navigator.pop(context), child: Text("OK", style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold))),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInput({required String label, required TextEditingController controller, required IconData icon, TextInputType type = TextInputType.text}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextField(
        controller: controller,
        keyboardType: type,
        style: TextStyle(color: primaryWhite),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: accentNeon),
          prefixIcon: Icon(icon, color: accentNeon, size: 18),
          filled: true,
          fillColor: Colors.black.withOpacity(0.25),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: borderGlass)),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: borderGlass)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: accentNeon, width: 1.6)),
        ),
      ),
    );
  }

  // Kartu bergaya "security panel" dengan sudut bracket & scan line
  Widget _buildScanCard({required String title, required IconData icon, required List<Widget> children}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 22),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: cardDark,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: borderGlass),
        boxShadow: [BoxShadow(color: primaryViolet.withOpacity(0.12), blurRadius: 20, offset: const Offset(0, 8))],
      ),
      child: Stack(
        children: [
          // Corner brackets
          ..._buildCorners(),
          Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Icon(icon, color: accentNeon, size: 17),
                  const SizedBox(width: 10),
                  Text(title, style: TextStyle(color: primaryWhite, fontSize: 14, fontWeight: FontWeight.bold, letterSpacing: 1.4)),
                  const Spacer(),
                  AnimatedBuilder(
                    animation: _scanCtrl,
                    builder: (context, _) => Container(
                      width: 6, height: 6,
                      decoration: BoxDecoration(shape: BoxShape.circle, color: accentNeon.withOpacity(0.4 + 0.6 * _scanCtrl.value)),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 18),
              ...children,
            ],
          ),
        ],
      ),
    );
  }

  List<Widget> _buildCorners() {
    final c = accentNeon.withOpacity(0.7);
    Widget corner(Alignment align, bool top, bool left) => Positioned(
          top: top ? 0 : null, bottom: !top ? 0 : null,
          left: left ? 0 : null, right: !left ? 0 : null,
          child: Container(
            width: 16, height: 16,
            decoration: BoxDecoration(
              border: Border(
                top: top ? BorderSide(color: c, width: 2) : BorderSide.none,
                bottom: !top ? BorderSide(color: c, width: 2) : BorderSide.none,
                left: left ? BorderSide(color: c, width: 2) : BorderSide.none,
                right: !left ? BorderSide(color: c, width: 2) : BorderSide.none,
              ),
            ),
          ),
        );
    return [
      corner(Alignment.topLeft, true, true),
      corner(Alignment.topRight, true, false),
      corner(Alignment.bottomLeft, false, true),
      corner(Alignment.bottomRight, false, false),
    ];
  }

  Widget _buildUserItem(Map user) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(color: Colors.black.withOpacity(0.25), borderRadius: BorderRadius.circular(12), border: Border.all(color: borderGlass)),
      child: Row(
        children: [
          Container(
            width: 34, height: 34,
            decoration: BoxDecoration(color: primaryViolet.withOpacity(0.18), shape: BoxShape.circle, border: Border.all(color: accentNeon.withOpacity(0.4))),
            child: Icon(FontAwesomeIcons.userShield, color: accentNeon, size: 14),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(user['username'] ?? '-', style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold, fontSize: 14)),
                const SizedBox(height: 3),
                Text("ROLE: ${(user['role'] ?? '-').toString().toUpperCase()} | EXP: ${user['expiredDate'] ?? '-'}", style: TextStyle(color: textGrey, fontSize: 11.5)),
              ],
            ),
          ),
          IconButton(
            icon: Icon(FontAwesomeIcons.trashCan, color: accentNeon.withOpacity(0.8), size: 16),
            onPressed: () async {
              final confirm = await showDialog<bool>(
                context: context,
                builder: (_) => AlertDialog(
                  backgroundColor: cardDark,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: borderGlass)),
                  title: Text("Konfirmasi", style: TextStyle(color: primaryWhite)),
                  content: Text("Hapus user ini?", style: TextStyle(color: textGrey)),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context, false), child: Text("Batal", style: TextStyle(color: textGrey))),
                    TextButton(onPressed: () => Navigator.pop(context, true), child: Text("Hapus", style: TextStyle(color: accentNeon))),
                  ],
                ),
              );
              if (confirm == true) {
                deleteController.text = user['username'];
                _deleteUser();
              }
            },
          ),
        ],
      ),
    );
  }

  Widget _buildPagination() {
    return Wrap(
      spacing: 8, runSpacing: 8,
      children: List.generate(totalPages, (index) {
        final page = index + 1;
        final active = currentPage == page;
        return GestureDetector(
          onTap: () => setState(() => currentPage = page),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              color: active ? primaryViolet.withOpacity(0.3) : Colors.transparent,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: active ? accentNeon : borderGlass),
            ),
            child: Text("$page", style: TextStyle(color: active ? accentNeon : textGrey, fontSize: 12)),
          ),
        );
      }),
    );
  }

  Widget _buildActionButton({required String label, required IconData icon, required VoidCallback? onPressed}) {
    return Container(
      height: 50,
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [primaryViolet, accentNeon]),
        borderRadius: BorderRadius.circular(10),
        boxShadow: [BoxShadow(color: primaryViolet.withOpacity(0.4), blurRadius: 14, offset: const Offset(0, 5))],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(10),
          onTap: onPressed,
          child: Center(
            child: isLoading
                ? SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: primaryWhite))
                : Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [Icon(icon, size: 16, color: primaryWhite), const SizedBox(width: 8), Text(label, style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold, letterSpacing: 1))],
                  ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter, end: Alignment.bottomCenter,
            colors: [bgDark, primaryViolet.withOpacity(0.08), bgDark],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 20),
            child: Column(
              children: [
                Row(children: [
                  IconButton(icon: Icon(Icons.arrow_back_ios_new_rounded, color: accentNeon, size: 18), onPressed: () => Navigator.pop(context)),
                ]),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: accentNeon.withOpacity(0.5), width: 2),
                    boxShadow: [BoxShadow(color: primaryViolet.withOpacity(0.4), blurRadius: 22, spreadRadius: 2)],
                  ),
                  child: Icon(FontAwesomeIcons.userShield, color: accentNeon, size: 32),
                ),
                const SizedBox(height: 14),
                Text(
                  "MODERATOR PANEL",
                  style: TextStyle(color: primaryWhite, fontSize: 21, fontWeight: FontWeight.w900, letterSpacing: 2, shadows: [Shadow(color: primaryViolet.withOpacity(0.9), blurRadius: 14)]),
                ),
                const SizedBox(height: 4),
                Text("Kontrol keamanan & moderasi akun", style: TextStyle(color: textGrey, fontSize: 12.5)),
                const SizedBox(height: 30),

                _buildScanCard(
                  title: "DELETE USER",
                  icon: FontAwesomeIcons.userSlash,
                  children: [
                    _buildInput(label: "Username Target", controller: deleteController, icon: FontAwesomeIcons.user),
                    const SizedBox(height: 6),
                    _buildActionButton(label: "DELETE ACCOUNT", icon: FontAwesomeIcons.trashCan, onPressed: isLoading ? null : _deleteUser),
                  ],
                ),

                _buildScanCard(
                  title: "CREATE ACCOUNT",
                  icon: FontAwesomeIcons.userPlus,
                  children: [
                    _buildInput(label: "Username", controller: createUsernameController, icon: FontAwesomeIcons.user),
                    _buildInput(label: "Password", controller: createPasswordController, icon: FontAwesomeIcons.lock),
                    _buildInput(label: "Durasi (Hari)", controller: createDayController, icon: FontAwesomeIcons.calendarDay, type: TextInputType.number),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                      decoration: BoxDecoration(color: Colors.black.withOpacity(0.25), borderRadius: BorderRadius.circular(10), border: Border.all(color: borderGlass)),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                          value: newUserRole,
                          dropdownColor: cardDark,
                          isExpanded: true,
                          style: TextStyle(color: primaryWhite),
                          items: roleOptions.map((role) => DropdownMenuItem(value: role, child: Text(role.toUpperCase()))).toList(),
                          onChanged: (val) => setState(() => newUserRole = val ?? 'member'),
                        ),
                      ),
                    ),
                    const SizedBox(height: 18),
                    _buildActionButton(label: "CREATE ACCOUNT", icon: FontAwesomeIcons.userPlus, onPressed: isLoading ? null : _createAccount),
                  ],
                ),

                _buildScanCard(
                  title: "EXTEND DURATION",
                  icon: FontAwesomeIcons.clock,
                  children: [
                    _buildInput(label: "Username Target", controller: editUsernameController, icon: FontAwesomeIcons.userPen),
                    _buildInput(label: "Tambah Hari", controller: editDayController, icon: FontAwesomeIcons.calendarPlus, type: TextInputType.number),
                    const SizedBox(height: 6),
                    _buildActionButton(label: "ADD DAYS", icon: FontAwesomeIcons.calendarPlus, onPressed: isLoading ? null : _editUser),
                  ],
                ),

                _buildScanCard(
                  title: "USER LIST",
                  icon: FontAwesomeIcons.users,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                      decoration: BoxDecoration(color: Colors.black.withOpacity(0.25), borderRadius: BorderRadius.circular(10), border: Border.all(color: borderGlass)),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                          value: selectedRole,
                          dropdownColor: cardDark,
                          isExpanded: true,
                          style: TextStyle(color: primaryWhite),
                          items: roleOptions.map((role) => DropdownMenuItem(value: role, child: Text(role.toUpperCase()))).toList(),
                          onChanged: (val) {
                            if (val != null) {
                              selectedRole = val;
                              _filterAndPaginate();
                            }
                          },
                        ),
                      ),
                    ),
                    const SizedBox(height: 18),
                    isLoading
                        ? Padding(padding: const EdgeInsets.all(20), child: Center(child: CircularProgressIndicator(color: accentNeon)))
                        : filteredList.isEmpty
                            ? Padding(padding: const EdgeInsets.symmetric(vertical: 30), child: Center(child: Text("Tidak ada user pada role ini", style: TextStyle(color: textGrey))))
                            : Column(children: [..._getCurrentPageData().map((u) => _buildUserItem(u)).toList(), const SizedBox(height: 16), _buildPagination()]),
                  ],
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
