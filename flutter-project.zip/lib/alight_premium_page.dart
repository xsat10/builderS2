import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class AlightPremiumPage extends StatefulWidget {
  const AlightPremiumPage({Key? key}) : super(key: key);

  @override
  State<AlightPremiumPage> createState() => _AlightPremiumPageState();
}

class _AlightPremiumPageState extends State<AlightPremiumPage>
    with SingleTickerProviderStateMixin {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _magicLinkController = TextEditingController();

  final String baseUrl = "http://shinoa-cpanelpanel.xtxintax.my.id:2003";

  bool isLoading = false;
  bool isVerifying = false;
  String progressText = "";
  double progressValue = 0.0;
  bool showSuccessOverlay = false;
  String userRole = "RESELLER";

  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _fadeAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    );
    _animationController.forward();
  }

  @override
  void dispose() {
    _emailController.dispose();
    _magicLinkController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  Future<void> simulateProgress(String taskName) async {
    setState(() {
      progressText = "MEMULAI $taskName...";
      progressValue = 0.0;
    });

    for (int i = 1; i <= 100; i++) {
      await Future.delayed(const Duration(milliseconds: 25));
      if (!mounted) return;

      String status = "";
      if (i < 20) status = "CEK KONEKSI SERVER";
      else if (i < 40) status = "VALIDASI EMAIL TARGET";
      else if (i < 60) status = "GENERATING MAGIC TOKEN";
      else if (i < 80) status = "MENGIRIM KE MAILBOX";
      else status = "FINALIZING PROCESS";

      setState(() {
        progressValue = i / 100;
        progressText = "$i% - $status";
      });
    }
  }

  Future<void> sendMagicLink() async {
    if (_emailController.text.isEmpty) {
      _showSnackbar("Masukkan email target terlebih dahulu!", Colors.red);
      return;
    }

    if (userRole != "RESELLER" && userRole != "ADMIN" && userRole != "OWNER_UTAMA") {
      _showSnackbar("AKSES DITOLAK! HANYA ROLE RESELLER KE ATAS YANG BISA CLAIM.", Colors.orange);
      return;
    }

    setState(() => isLoading = true);

    try {
      await simulateProgress("MENGIRIM MAGIC LINK");

      setState(() {
        isLoading = false;
        showSuccessOverlay = true;
      });

      await Future.delayed(const Duration(seconds: 2));
      if (!mounted) return;
      setState(() => showSuccessOverlay = false);
      await pickAndUploadProof();
    } catch (e) {
      setState(() => isLoading = false);
      _showSnackbar("Error Server: ${e.toString()}", Colors.red);
    }
  }

  Future<void> pickAndUploadProof() async {
    final ImagePicker picker = ImagePicker();
    final XFile? image = await picker.pickImage(source: ImageSource.gallery);

    if (image != null) {
      _showSnackbar("Foto berhasil dipilih! Mengunggah ke server...", Colors.teal);
    }
  }

  Future<void> verifyMagicLink() async {
    if (_magicLinkController.text.isEmpty) {
      _showSnackbar("Tempelkan Magic Link dari email Anda!", Colors.red);
      return;
    }

    setState(() => isVerifying = true);
    await simulateProgress("VERIFIKASI & AKTIVASI");

    setState(() => isVerifying = false);
    _showSnackbar("ALIGHT MOTION PREMIUM BERHASIL DIAKTIFKAN!", Colors.green);
  }

  void _showSnackbar(String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: const TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          "ALIGHT CLAIM MCLAREN",
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w900,
            letterSpacing: 1.2,
            shadows: [Shadow(color: Colors.teal, blurRadius: 10)],
          ),
        ),
        centerTitle: true,
      ),
      body: Stack(
        children: [
          FadeTransition(
            opacity: _fadeAnimation,
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(vertical: 30, horizontal: 16),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFF1A1A1A), Color(0xFF2D2D2D)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(24),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.teal.withOpacity(0.3),
                          blurRadius: 20,
                          offset: const Offset(0, 10),
                        ),
                        const BoxShadow(
                          color: Colors.black45,
                          blurRadius: 10,
                          offset: Offset(0, 5),
                        )
                      ],
                      border: Border.all(color: Colors.teal.withOpacity(0.5), width: 1.5),
                    ),
                    child: Column(
                      children: [
                        Container(
                          width: 80,
                          height: 80,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(color: Colors.teal.withOpacity(0.6), blurRadius: 15)
                            ],
                          ),
                          child: ClipOval(
                            child: Image.asset(
                              'assets/images/am.png',
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) =>
                                  const Icon(Icons.bolt_rounded, size: 40, color: Colors.teal),
                            ),
                          ),
                        ),
                        const SizedBox(height: 15),
                        const Text(
                          "ALIGHT UNLOCK",
                          style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
                        ),
                        const Text(
                          "Aktifkan premium lewat magic link",
                          style: TextStyle(color: Colors.grey, fontSize: 12),
                        ),
                        const SizedBox(height: 15),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                          decoration: BoxDecoration(
                            color: Colors.black,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: Colors.orange, width: 1),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Container(
                                width: 8,
                                height: 8,
                                decoration: const BoxDecoration(color: Colors.orange, shape: BoxShape.circle),
                              ),
                              const SizedBox(width: 8),
                              const Text("BELUM AKTIF",
                                  style: TextStyle(color: Colors.orange, fontWeight: FontWeight.bold, fontSize: 10))
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                  const SizedBox(height: 25),
                  _build3DCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildLabel("EMAIL TARGET"),
                        TextField(
                          controller: _emailController,
                          style: const TextStyle(color: Colors.white),
                          decoration: InputDecoration(
                            hintText: "Masukkan email kamu",
                            hintStyle: const TextStyle(color: Colors.grey),
                            prefixIcon: const Icon(Icons.email_outlined, color: Colors.teal),
                            filled: true,
                            fillColor: const Color(0xFF1E1E1E),
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Colors.teal)),
                          ),
                        ),
                        const SizedBox(height: 15),
                        if (isLoading || isVerifying) ...[
                          LinearProgressIndicator(
                            value: progressValue,
                            backgroundColor: Colors.grey[800],
                            color: Colors.teal,
                            minHeight: 6,
                            borderRadius: BorderRadius.circular(3),
                          ),
                          const SizedBox(height: 8),
                          Text(progressText, style: const TextStyle(color: Colors.teal, fontSize: 11, fontFamily: 'Astral')),
                          const SizedBox(height: 15),
                        ],
                        SizedBox(
                          width: double.infinity,
                          height: 50,
                          child: ElevatedButton(
                            onPressed: isLoading ? null : sendMagicLink,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.teal,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                              elevation: 5,
                              shadowColor: Colors.teal.withOpacity(0.5),
                            ),
                            child: isLoading
                                ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                                : const Text("KIRIM MAGIC LINK", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                          ),
                        ),
                        const Divider(color: Colors.grey, height: 30),
                        _buildLabel("MAGIC LINK"),
                        TextField(
                          controller: _magicLinkController,
                          style: const TextStyle(color: Colors.white),
                          decoration: InputDecoration(
                            hintText: "Tempel link dari email",
                            hintStyle: const TextStyle(color: Colors.grey),
                            prefixIcon: const Icon(Icons.link, color: Colors.teal),
                            suffixIcon: IconButton(icon: const Icon(Icons.paste, color: Colors.grey), onPressed: () {}),
                            filled: true,
                            fillColor: const Color(0xFF1E1E1E),
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                          ),
                        ),
                        const SizedBox(height: 15),
                        SizedBox(
                          width: double.infinity,
                          height: 50,
                          child: OutlinedButton(
                            onPressed: isVerifying ? null : verifyMagicLink,
                            style: OutlinedButton.styleFrom(
                              side: const BorderSide(color: Colors.teal),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            ),
                            child: isVerifying
                                ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.teal, strokeWidth: 2))
                                : const Text("VERIFIKASI & AKTIFKAN", style: TextStyle(color: Colors.teal, fontWeight: FontWeight.bold)),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 25),
                  _build3DCard(
                    color: const Color(0xFF111111),
                    borderColor: Colors.grey.withOpacity(0.3),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(Icons.lightbulb_outline, color: Colors.yellow[700]),
                            const SizedBox(width: 8),
                            const Text("CARA PAKAI", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold))
                          ],
                        ),
                        const SizedBox(height: 15),
                        _buildStep(1, "Masukkan email yang terdaftar"),
                        _buildStep(2, "Tekan Kirim Magic Link"),
                        _buildStep(3, "Cek email (termasuk folder spam)"),
                        _buildStep(4, "Salin link lalu tempel di bawah"),
                        _buildStep(5, "Tekan Verifikasi & Aktifkan"),
                        const SizedBox(height: 15),
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: Colors.teal.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: Colors.teal.withOpacity(0.3)),
                          ),
                          child: Row(
                            children: const [
                              Icon(Icons.info_outline, color: Colors.teal, size: 16),
                              SizedBox(width: 8),
                              Text("Magic link hanya berlaku 15 menit", style: TextStyle(color: Colors.teal, fontSize: 11))
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                  const SizedBox(height: 30),
                  const Text("v6.6.0 | 𝖋𝖊𝖒𝖕𝖎𝖗𝖹𝖺𝗇𝖷✧ᬊ", style: TextStyle(color: Colors.grey, fontSize: 10)),
                ],
              ),
            ),
          ),
          if (showSuccessOverlay)
            Positioned.fill(
              child: Container(
                color: Colors.black87,
                child: Center(
                  child: Container(
                    padding: const EdgeInsets.all(30),
                    margin: const EdgeInsets.all(30),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1A1A1A),
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(color: Colors.green, width: 2),
                      boxShadow: [BoxShadow(color: Colors.green.withOpacity(0.4), blurRadius: 30)],
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: const [
                        Icon(Icons.check_circle_outline, color: Colors.green, size: 60),
                        SizedBox(height: 20),
                        Text(
                          "SUCCES MENGIRIM\nMAGIC LINK!",
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
                        ),
                        SizedBox(height: 10),
                        Text("Silakan cek email Anda sekarang.", style: TextStyle(color: Colors.grey)),
                      ],
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _build3DCard({required Widget child, Color color = const Color(0xFF1A1A1A), Color borderColor = const Color(0xFF333333)}) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 15, offset: const Offset(0, 8)),
          BoxShadow(color: borderColor.withOpacity(0.2), blurRadius: 5, offset: const Offset(0, 2))
        ],
        border: Border.all(color: borderColor, width: 1),
      ),
      child: child,
    );
  }

  Widget _buildLabel(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(text, style: const TextStyle(color: Colors.grey, fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: 1)),
    );
  }

  Widget _buildStep(int num, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          Container(
            width: 24,
            height: 24,
            decoration: const BoxDecoration(color: Colors.teal, shape: BoxShape.circle),
            child: Center(child: Text("$num", style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold))),
          ),
          const SizedBox(width: 12),
          Expanded(child: Text(text, style: const TextStyle(color: Colors.white70, fontSize: 13))),
        ],
      ),
    );
  }
}
