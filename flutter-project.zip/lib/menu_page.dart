import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'tools_gateway.dart';
import 'home_page.dart';
import 'chat_room_page.dart';
import 'device_dashboard.dart';
import 'bug_sender.dart';
import 'spam_pairing.dart';
import 'main_trading_page.dart'; // ✅ Tambahkan impor untuk Trading

// ─── PALETTE (ELEGANT DARK) ─────────────────────────────────────────────
class _MenuColors {
  static const bg      = Color(0xFF0A0A14);
  static const card    = Color(0xFF18182A);
  static const cardHover= Color(0xFF222244);
  static const border  = Color(0xFF2A2A44);
  static const white   = Colors.white;
  static const grey    = Color(0xFFB0B0C8);
  static const greyDim = Color(0xFF6B6B82);
  static const shadow  = Color(0x40000000);
  static const glow    = Color(0x1AFFFFFF);
}

// ─── MENU ITEM DATA ─────────────────────────────────────────────────────
class _MenuItemData {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;
  const _MenuItemData({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.onTap,
  });
}

// ─── SLIDE TRANSITION ────────────────────────────────────────────────────
PageRoute _menuSlideRoute(Widget page) => PageRouteBuilder(
      pageBuilder: (_, __, ___) => page,
      transitionDuration: const Duration(milliseconds: 400),
      transitionsBuilder: (_, anim, __, child) => SlideTransition(
        position: Tween<Offset>(begin: const Offset(0.8, 0), end: Offset.zero)
            .animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
        child: FadeTransition(opacity: anim, child: child),
      ),
    );

// ─── MAIN MENU PAGE ─────────────────────────────────────────────────────
class MenuPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;

  const MenuPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
  });

  @override
  State<MenuPage> createState() => _MenuPageState();
}

class _MenuPageState extends State<MenuPage> with SingleTickerProviderStateMixin {
  late final PageController _pageCtrl;
  double _page = 0;
  late final List<_MenuItemData> _items;
  late AnimationController _animController;

  @override
  void initState() {
    super.initState();
    _pageCtrl = PageController(viewportFraction: 0.74, initialPage: 0)
      ..addListener(() {
        if (!mounted) return;
        setState(() => _page = _pageCtrl.page ?? _page);
      });
    _items = _buildItems();
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _animController.forward();
  }

  List<_MenuItemData> _buildItems() => [
        _MenuItemData(
          icon: Icons.work_rounded,
          title: 'Tools X-SPYDER',
          subtitle: 'All-in-One Utilities',
          color: const Color(0xFFFF3B30),
          onTap: () => Navigator.push(
            context,
            _menuSlideRoute(ToolsPage(
              sessionKey: widget.sessionKey,
              userRole: widget.role,
              listDoos: widget.listDoos,
            )),
          ),
        ),
        _MenuItemData(
          icon: FontAwesomeIcons.whatsapp,
          title: 'WhatsApp',
          subtitle: 'Kirim Bug & Pesan',
          color: const Color(0xFF25D366),
          onTap: () => Navigator.push(
            context,
            _menuSlideRoute(HomePage(
              username: widget.username,
              password: widget.password,
              listBug: widget.listBug,
              role: widget.role,
              expiredDate: widget.expiredDate,
              sessionKey: widget.sessionKey,
            )),
          ),
        ),
        _MenuItemData(
          icon: Icons.dashboard_customize_rounded,
          title: 'Flat',
          subtitle: 'Device Dashboard',
          color: const Color(0xFF1565C0),
          onTap: () => _showComingSoon('Flat'),
        ),
        _MenuItemData(
          icon: Icons.forum_rounded,
          title: 'Public Chat',
          subtitle: 'Ruang Obrolan Publik',
          color: const Color(0xFF14FFEC),
          onTap: () => Navigator.push(
            context,
            _menuSlideRoute(ChatRoomPage(username: widget.username)),
          ),
        ),
        // ─── SPAM PAIRING ──────────────────────────────────────────────
        _MenuItemData(
          icon: Icons.phone_android_rounded,
          title: 'SPAM PAIRING',
          subtitle: 'Pairing Code & OTP Spam',
          color: const Color(0xFFFF6B35),
          onTap: () => Navigator.push(
            context,
            _menuSlideRoute(SpamPairPage(
              sessionKey: widget.sessionKey,
              username: widget.username,
              role: widget.role,
            )),
          ),
        ),
        // ─── TRADING (NEW) ──────────────────────────────────────────────
        _MenuItemData(
          icon: Icons.trending_up_rounded,
          title: 'Trading',
          subtitle: 'Market & Crypto Trading',
          color: const Color(0xFF00E676),
          onTap: () => Navigator.push(
            context,
            _menuSlideRoute(MainTradingPage(
              sessionKey: widget.sessionKey,
              role: widget.role,
            )),
          ),
        ),
        _MenuItemData(
          icon: Icons.manage_accounts_rounded,
          title: 'Manage',
          subtitle: 'Kelola Sender Aktif',
          color: const Color(0xFF9B59B6),
          onTap: () => _showComingSoon('Manage'),
        ),
      ];

  void _showComingSoon(String name) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('$name belum terhubung ke halamannya.'),
      backgroundColor: _MenuColors.card,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: const EdgeInsets.all(14),
    ));
  }

  int get _activeIndex {
    final idx = _page.round();
    if (idx < 0) return 0;
    if (idx > _items.length - 1) return _items.length - 1;
    return idx;
  }

  void _goTo(int index) {
    _pageCtrl.animateToPage(index,
        duration: const Duration(milliseconds: 450), curve: Curves.easeInOutCubic);
  }

  @override
  void dispose() {
    _pageCtrl.dispose();
    _animController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final active = _items[_activeIndex];
    return Scaffold(
      backgroundColor: _MenuColors.bg,
      body: Stack(
        children: [
          // ─── Background Image ────────────────────────────────────────
          Positioned.fill(
            child: Image.asset(
              'assets/images/menu_xx.png', // ← Background baru
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    center: Alignment.center,
                    radius: 1.2,
                    colors: [
                      _MenuColors.bg,
                      _MenuColors.bg.withBlue(10).withRed(5),
                    ],
                  ),
                ),
              ),
            ),
          ),
          // ─── Overlay Glass ────────────────────────────────────────────
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  stops: const [0.0, 0.3, 0.7, 1.0],
                  colors: [
                    _MenuColors.bg.withOpacity(0.10),
                    _MenuColors.bg.withOpacity(0.30),
                    _MenuColors.bg.withOpacity(0.60),
                    _MenuColors.bg.withOpacity(0.90),
                  ],
                ),
              ),
            ),
          ),
          SafeArea(
            child: FadeTransition(
              opacity: _animController,
              child: Column(
                children: [
                  _buildHeader(active),
                  const SizedBox(height: 4),
                  Expanded(child: _buildCarousel()),
                  _buildActiveInfo(active),
                  const SizedBox(height: 14),
                  _buildDots(active),
                  const SizedBox(height: 10),
                  const Text(
                    'Tap card or button below to open menu',
                    style: TextStyle(color: _MenuColors.greyDim, fontSize: 11.5),
                  ),
                  const SizedBox(height: 18),
                  _buildBottomControls(active),
                  const SizedBox(height: 16),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── HEADER ────────────────────────────────────────────────────────────
  Widget _buildHeader(_MenuItemData active) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.maybePop(context),
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _MenuColors.card.withOpacity(0.7),
                border: Border.all(color: _MenuColors.border),
                boxShadow: [
                  BoxShadow(
                    color: _MenuColors.shadow,
                    blurRadius: 8,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: const Icon(Icons.arrow_back_ios_new_rounded,
                  color: _MenuColors.white, size: 16),
            ),
          ),
          const SizedBox(width: 12),
          AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                colors: [active.color, active.color.withOpacity(0.6)],
              ),
              boxShadow: [
                BoxShadow(
                  color: active.color.withOpacity(0.5),
                  blurRadius: 20,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: ClipOval(
              child: Image.asset(
                'assets/images/menu.png',
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  color: _MenuColors.card,
                  child: Icon(Icons.apps_rounded, color: active.color, size: 24),
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                AnimatedDefaultTextStyle(
                  duration: const Duration(milliseconds: 250),
                  style: TextStyle(
                    color: active.color,
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.8,
                  ),
                  child: const Text('QUICK MENU'),
                ),
                const SizedBox(height: 2),
                const Text(
                  'Card Carousel',
                  style: TextStyle(color: _MenuColors.white, fontSize: 20, fontWeight: FontWeight.w800),
                ),
              ],
            ),
          ),
          AnimatedContainer(
            duration: const Duration(milliseconds: 280),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              color: active.color.withOpacity(0.12),
              border: Border.all(color: active.color.withOpacity(0.5)),
              boxShadow: [
                BoxShadow(
                  color: active.color.withOpacity(0.1),
                  blurRadius: 8,
                ),
              ],
            ),
            child: Text(
              'MENU',
              style: TextStyle(
                color: active.color,
                fontSize: 11,
                fontWeight: FontWeight.w800,
                letterSpacing: 1,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── CAROUSEL (Coverflow + Glassmorphism) ──────────────────────────────
  Widget _buildCarousel() {
    return PageView.builder(
      controller: _pageCtrl,
      itemCount: _items.length,
      itemBuilder: (context, index) {
        final double delta = index - _page;
        final double t = delta < -1.0 ? -1.0 : (delta > 1.0 ? 1.0 : delta);
        final double scale = 1 - (t.abs() * 0.12);
        final double angle = t * -0.4;
        final double translateY = t.abs() * 18;
        final double opacity = 1 - (t.abs() * 0.45) < 0.4 ? 0.4 : 1 - (t.abs() * 0.45);

        return Transform(
          alignment: Alignment.center,
          transform: Matrix4.identity()
            ..setEntry(3, 2, 0.0012)
            ..rotateY(angle)
            ..translate(0.0, translateY)
            ..scale(scale),
          child: Opacity(
            opacity: opacity,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              child: _MenuCard(item: _items[index], isActive: index == _activeIndex),
            ),
          ),
        );
      },
    );
  }

  // ── ACTIVE INFO ───────────────────────────────────────────────────────
  Widget _buildActiveInfo(_MenuItemData active) {
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 260),
      child: Column(
        key: ValueKey(active.title),
        children: [
          Text(active.title,
              style: TextStyle(color: active.color, fontSize: 22, fontWeight: FontWeight.w900)),
          const SizedBox(height: 4),
          Text(active.subtitle, style: const TextStyle(color: _MenuColors.grey, fontSize: 12.5)),
        ],
      ),
    );
  }

  // ── DOTS ──────────────────────────────────────────────────────────────
  Widget _buildDots(_MenuItemData active) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(_items.length, (i) {
        final bool isActive = i == _activeIndex;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 220),
          margin: const EdgeInsets.symmetric(horizontal: 3),
          width: isActive ? 24 : 6,
          height: 6,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(4),
            color: isActive ? active.color : Colors.white24,
            boxShadow: isActive
                ? [
                    BoxShadow(
                      color: active.color.withOpacity(0.5),
                      blurRadius: 6,
                      spreadRadius: 1,
                    ),
                  ]
                : [],
          ),
        );
      }),
    );
  }

  // ── BOTTOM CONTROLS ──────────────────────────────────────────────────
  Widget _buildBottomControls(_MenuItemData active) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        children: [
          _circleNavButton(
            icon: Icons.chevron_left_rounded,
            onTap: _activeIndex > 0 ? () => _goTo(_activeIndex - 1) : null,
          ),
          const SizedBox(width: 14),
          Expanded(
            child: GestureDetector(
              onTap: active.onTap,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 280),
                height: 54,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(28),
                  gradient: LinearGradient(
                    colors: [active.color, active.color.withOpacity(0.7)],
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: active.color.withOpacity(0.5),
                      blurRadius: 20,
                      offset: const Offset(0, 8),
                    ),
                  ],
                ),
                child: Text(
                  'OPEN ${active.title.toUpperCase()}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                    fontSize: 14,
                    letterSpacing: 0.8,
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(width: 14),
          _circleNavButton(
            icon: Icons.chevron_right_rounded,
            onTap: _activeIndex < _items.length - 1 ? () => _goTo(_activeIndex + 1) : null,
          ),
        ],
      ),
    );
  }

  Widget _circleNavButton({required IconData icon, VoidCallback? onTap}) {
    final bool enabled = onTap != null;
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: 48,
        height: 48,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: _MenuColors.card.withOpacity(enabled ? 0.9 : 0.4),
          border: Border.all(color: _MenuColors.border),
          boxShadow: enabled
              ? [
                  BoxShadow(
                    color: _MenuColors.shadow,
                    blurRadius: 10,
                  ),
                ]
              : [],
        ),
        child: Icon(icon, color: enabled ? _MenuColors.white : _MenuColors.greyDim, size: 26),
      ),
    );
  }
}

// ─── MENU CARD (Glassmorphism) ──────────────────────────────────────────
class _MenuCard extends StatelessWidget {
  final _MenuItemData item;
  final bool isActive;
  const _MenuCard({required this.item, required this.isActive});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: item.onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          color: isActive
              ? _MenuColors.card.withOpacity(0.9)
              : _MenuColors.card.withOpacity(0.6),
          borderRadius: BorderRadius.circular(28),
          border: Border.all(
            color: isActive ? item.color.withOpacity(0.9) : _MenuColors.border,
            width: isActive ? 2 : 1,
          ),
          boxShadow: isActive
              ? [
                  BoxShadow(
                    color: item.color.withOpacity(0.3),
                    blurRadius: 30,
                    spreadRadius: 2,
                  ),
                ]
              : [
                  BoxShadow(
                    color: _MenuColors.shadow,
                    blurRadius: 12,
                  ),
                ],
          gradient: isActive
              ? LinearGradient(
                  colors: [
                    _MenuColors.card.withOpacity(0.9),
                    _MenuColors.card.withOpacity(0.6),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : null,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 56,
              height: 56,
              decoration: BoxDecoration(
                color: item.color.withOpacity(0.16),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: item.color.withOpacity(0.4)),
                boxShadow: [
                  BoxShadow(
                    color: item.color.withOpacity(0.1),
                    blurRadius: 10,
                  ),
                ],
              ),
              child: Icon(item.icon, color: item.color, size: 26),
            ),
            const Spacer(),
            Text(item.title,
                style: TextStyle(
                  color: isActive ? Colors.white : _MenuColors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                )),
            const SizedBox(height: 4),
            Text(
              item.subtitle,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: isActive ? _MenuColors.grey : _MenuColors.greyDim,
                fontSize: 12,
              ),
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: item.color.withOpacity(0.6)),
                color: item.color.withOpacity(0.05),
              ),
              child: Text(
                'OPEN',
                style: TextStyle(
                  color: item.color,
                  fontSize: 11,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}