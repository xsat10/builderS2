import 'servers.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class RiwayatPage extends StatefulWidget {
  final String sessionKey;
  final String role;

  const RiwayatPage({
    super.key,
    required this.sessionKey,
    required this.role,
  });

  @override
  State<RiwayatPage> createState() => _RiwayatPageState();
}

class _RiwayatPageState extends State<RiwayatPage> {
  // ============ BMW GARAGE PALETTE ============
  final Color bgDark = const Color(0xFF05070A);        // garage black
  final Color cardDark = const Color(0xFF0E1319);      // carbon panel
  final Color cardDarker = const Color(0xFF0A0F16);    // deeper carbon
  final Color bmwBlue = const Color(0xFF1C69D4);       // BMW M blue
  final Color bmwLightBlue = const Color(0xFF6FB2FF);  // BMW light blue
  final Color bmwRed = const Color(0xFFE7222E);        // BMW M red
  final Color bmwChrome = const Color(0xFFD6DCE5);     // platinum chrome
  final Color bmwSilver = const Color(0xFF9AA5B1);     // silver

  final Color primaryWhite = Colors.white;
  final Color accentGreyText = const Color(0xFF9AA5B1);
  final Color cardGlass = Colors.white.withOpacity(0.04);
  final Color borderGlass = Colors.white.withOpacity(0.10);

  List<ActivityModel> activities = [];
  bool isLoading = true;

  String baseUrl = "";

  @override
  void initState() {
    super.initState();
    _loadConfigAndActivities();
  }

  Future<void> _loadConfig() async {
    final response = await http.get(Uri.parse(
        Servers.configUrl));
    final data = jsonDecode(response.body);
    baseUrl = data['base_url'];
  }

  Future<void> _loadConfigAndActivities() async {
    await _loadConfig();
    await _loadActivities();
  }

  Future<void> _loadActivities() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/getMyActivity?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid']) {
          List<dynamic> rawList = data['activities'];

          setState(() {
            activities = rawList.map((item) {
              return ActivityModel(
                type: item['type'] ?? 'system',
                title: item['title'] ?? 'Aktivitas',
                description: item['description'] ?? '-',
                timestamp: DateTime.fromMillisecondsSinceEpoch(
                    item['timestamp'] ?? DateTime.now().millisecondsSinceEpoch
                ),
              );
            }).toList();
            isLoading = false;
          });
        } else {
          setState(() => isLoading = false);
        }
      } else {
        setState(() => isLoading = false);
      }
    } catch (e) {
      setState(() => isLoading = false);
    }
  }

  String _formatDate(DateTime date) {
    return DateFormat('dd MMM yyyy, HH:mm').format(date);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      appBar: AppBar(
        title: Text(
          "Riwayat Aktivitas",
          style: TextStyle(
            color: primaryWhite,
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.bold,
            letterSpacing: 1.5,
            shadows: [
              Shadow(
                color: bmwBlue.withOpacity(0.5),
                blurRadius: 12,
              ),
            ],
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Stack(
        children: [
          // Base gradient
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0xFF05070A),
                  Color(0xFF0A0F16),
                  Color(0xFF05070A),
                ],
              ),
            ),
          ),

          // Ambient glow — M blue (kanan atas)
          Positioned(
            top: -140,
            right: -120,
            child: Container(
              width: 260,
              height: 260,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: bmwBlue.withOpacity(0.10),
                boxShadow: [
                  BoxShadow(
                    color: bmwBlue.withOpacity(0.20),
                    blurRadius: 110,
                    spreadRadius: 30,
                  ),
                ],
              ),
            ),
          ),

          // Ambient glow — M red (kiri bawah)
          Positioned(
            bottom: -140,
            left: -120,
            child: Container(
              width: 260,
              height: 260,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: bmwRed.withOpacity(0.08),
                boxShadow: [
                  BoxShadow(
                    color: bmwRed.withOpacity(0.15),
                    blurRadius: 110,
                    spreadRadius: 30,
                  ),
                ],
              ),
            ),
          ),

          // Content
          isLoading
              ? Center(
            child: CircularProgressIndicator(
              color: bmwLightBlue,
              strokeWidth: 2.5,
            ),
          )
              : activities.isEmpty
              ? Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: cardDark,
                    border: Border.all(
                      color: bmwChrome.withOpacity(0.25),
                      width: 1,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: bmwBlue.withOpacity(0.15),
                        blurRadius: 20,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                  child: Icon(
                    Icons.history_toggle_off,
                    size: 40,
                    color: bmwChrome,
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  "Belum ada aktivitas",
                  style: TextStyle(
                    color: bmwChrome.withOpacity(0.9),
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.6,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  "Pastikan server aktif",
                  style: TextStyle(
                    color: bmwSilver.withOpacity(0.6),
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          )
              : RefreshIndicator(
            onRefresh: _loadConfigAndActivities,
            color: bmwLightBlue,
            backgroundColor: cardDark,
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: activities.length,
              itemBuilder: (context, index) {
                final activity = activities[index];
                return _buildActivityCard(activity);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActivityCard(ActivityModel activity) {
    Color iconColor;
    IconData iconData;
    String typeLabel;

    switch (activity.type) {
      case 'login':
        iconColor = const Color(0xFF00E676); // premium green
        iconData = Icons.login_rounded;
        typeLabel = "LOGIN";
        break;
      case 'bug':
        iconColor = bmwRed; // M red — attack
        iconData = Icons.bug_report_outlined;
        typeLabel = "ATTACK";
        break;
      case 'create':
        iconColor = bmwLightBlue; // BMW light blue — account
        iconData = Icons.person_add_alt_1_rounded;
        typeLabel = "ACCOUNT";
        break;
      default:
        iconColor = bmwChrome; // chrome — system
        iconData = Icons.info_outline;
        typeLabel = "SYSTEM";
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: cardGlass,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: bmwChrome.withOpacity(0.15),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.45),
            blurRadius: 14,
            offset: const Offset(0, 6),
          ),
          BoxShadow(
            color: iconColor.withOpacity(0.08),
            blurRadius: 18,
            offset: const Offset(0, -3),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Stack(
          children: [
            // M-stripe aksen kiri
            Positioned(
              left: 0,
              top: 14,
              bottom: 14,
              child: Container(
                width: 3,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      iconColor,
                      bmwLightBlue,
                      bmwRed,
                    ],
                  ),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: iconColor.withOpacity(0.12),
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: iconColor.withOpacity(0.40),
                        width: 1.2,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: iconColor.withOpacity(0.25),
                          blurRadius: 12,
                          offset: const Offset(0, 3),
                        ),
                      ],
                    ),
                    child: Icon(iconData, color: iconColor, size: 24),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Text(
                                activity.title,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 0.3,
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color: cardDarker,
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(
                                  color: iconColor.withOpacity(0.45),
                                  width: 1,
                                ),
                              ),
                              child: Text(
                                typeLabel,
                                style: TextStyle(
                                  color: iconColor,
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 1.2,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Text(
                          activity.description,
                          style: TextStyle(
                            color: bmwSilver.withOpacity(0.85),
                            fontSize: 13,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            Icon(
                              Icons.access_time,
                              size: 12,
                              color: bmwSilver.withOpacity(0.6),
                            ),
                            const SizedBox(width: 4),
                            Text(
                              _formatDate(activity.timestamp),
                              style: TextStyle(
                                color: bmwSilver.withOpacity(0.65),
                                fontSize: 11,
                                fontFamily: 'ShareTechMono',
                                letterSpacing: 0.5,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ActivityModel {
  final String type;
  final String title;
  final String description;
  final DateTime timestamp;

  ActivityModel({
    required this.type,
    required this.title,
    required this.description,
    required this.timestamp,
  });
}