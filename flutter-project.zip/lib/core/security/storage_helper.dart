import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Secure storage untuk JWT, userId, username, E2EE keys, dll.
class StorageHelper {
  StorageHelper._();
  static final StorageHelper instance = StorageHelper._();

  final FlutterSecureStorage _storage = const FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
    iOptions: IOSOptions(accessibility: KeychainAccessibility.first_unlock),
  );

  static const _kToken = 'xyzora_jwt';
  static const _kUserId = 'xyzora_user_id';
  static const _kUsername = 'xyzora_username';
  static const _kUserJson = 'xyzora_user_json';
  static const _kE2eePrivate = 'xyzora_e2ee_priv';
  static const _kE2eePublic = 'xyzora_e2ee_pub';
  static const _kE2eeFp = 'xyzora_e2ee_fp';
  static const _kTheme = 'xyzora_theme_id';

  Future<void> saveSession({
    required String token,
    required String userId,
    required String username,
    Map<String, dynamic>? user,
  }) async {
    await Future.wait([
      _storage.write(key: _kToken, value: token),
      _storage.write(key: _kUserId, value: userId),
      _storage.write(key: _kUsername, value: username),
      if (user != null)
        _storage.write(key: _kUserJson, value: jsonEncode(user)),
    ]);
  }

  Future<String?> getToken() => _storage.read(key: _kToken);
  Future<String?> getUserId() => _storage.read(key: _kUserId);
  Future<String?> getUsername() => _storage.read(key: _kUsername);

  Future<Map<String, dynamic>?> getUser() async {
    final raw = await _storage.read(key: _kUserJson);
    if (raw == null) return null;
    try {
      return jsonDecode(raw) as Map<String, dynamic>;
    } catch (_) {
      return null;
    }
  }

  Future<bool> hasSession() async {
    final t = await getToken();
    return t != null && t.isNotEmpty;
  }

  Future<void> clearSession() async {
    await Future.wait([
      _storage.delete(key: _kToken),
      _storage.delete(key: _kUserId),
      _storage.delete(key: _kUsername),
      _storage.delete(key: _kUserJson),
    ]);
  }

  // E2EE key storage (device-local)
  Future<void> saveE2eeKeys({
    required String privateJwk,
    required String publicJwk,
    required String fingerprint,
  }) async {
    await Future.wait([
      _storage.write(key: _kE2eePrivate, value: privateJwk),
      _storage.write(key: _kE2eePublic, value: publicJwk),
      _storage.write(key: _kE2eeFp, value: fingerprint),
    ]);
  }

  Future<String?> getE2eePrivate() => _storage.read(key: _kE2eePrivate);
  Future<String?> getE2eePublic() => _storage.read(key: _kE2eePublic);
  Future<String?> getE2eeFingerprint() => _storage.read(key: _kE2eeFp);

  Future<void> clearE2eeKeys() async {
    await Future.wait([
      _storage.delete(key: _kE2eePrivate),
      _storage.delete(key: _kE2eePublic),
      _storage.delete(key: _kE2eeFp),
    ]);
  }

  Future<void> saveTheme(String id) => _storage.write(key: _kTheme, value: id);
  Future<String?> getTheme() => _storage.read(key: _kTheme);
}
