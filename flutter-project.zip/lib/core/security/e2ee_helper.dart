import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';
import 'package:crypto/crypto.dart';
import 'package:pointycastle/export.dart';
import 'package:convert/convert.dart';
import 'storage_helper.dart';

/// End-to-End Encryption helper — setara dengan public/js/e2ee.js
/// Skema:
/// - ECDH P-256 (secp256r1) key pair per user
/// - Private key disimpan lokal (secure storage)
/// - Private chat: AES-256-GCM dari ECDH shared secret + HKDF
/// - Group: AES-256-GCM dengan group key (versi)
/// Server tidak pernah memegang plaintext / private key.
class E2eeHelper {
  E2eeHelper._();
  static final E2eeHelper instance = E2eeHelper._();

  final _storage = StorageHelper.instance;
  AsymmetricKeyPair<PublicKey, PrivateKey>? _keyPair;
  String? _fingerprint;
  final Map<String, Uint8List> _dmKeys = {}; // chatId -> AES key
  final Map<String, Map<int, Uint8List>> _groupKeys = {}; // chatId -> ver -> key

  bool get isReady => _keyPair != null;

  /// Generate or load ECDH P-256 key pair
  Future<void> init() async {
    final privJwk = await _storage.getE2eePrivate();
    final pubJwk = await _storage.getE2eePublic();
    final fp = await _storage.getE2eeFingerprint();

    if (privJwk != null && pubJwk != null && fp != null) {
      try {
        _keyPair = _importKeyPair(privJwk, pubJwk);
        _fingerprint = fp;
        return;
      } catch (_) {}
    }
    await generateAndSaveKeys();
  }

  Future<void> generateAndSaveKeys() async {
    final keyGen = ECKeyGenerator();
    final secureRandom = FortunaRandom();
    final seed = Uint8List.fromList(
      List.generate(32, (_) => Random.secure().nextInt(256)),
    );
    secureRandom.seed(KeyParameter(seed));

    keyGen.init(ParametersWithRandom(
      ECKeyGeneratorParameters(ECCurve_secp256r1()),
      secureRandom,
    ));
    _keyPair = keyGen.generateKeyPair();
    _fingerprint = await _computeFingerprint(_keyPair!.publicKey as ECPublicKey);

    final privJwk = _exportPrivateJwk(_keyPair!.privateKey as ECPrivateKey);
    final pubJwk = _exportPublicJwk(_keyPair!.publicKey as ECPublicKey);

    await _storage.saveE2eeKeys(
      privateJwk: privJwk,
      publicJwk: pubJwk,
      fingerprint: _fingerprint!,
    );
  }

  String? get fingerprint => _fingerprint;
  String? get publicJwk {
    if (_keyPair == null) return null;
    return _exportPublicJwk(_keyPair!.publicKey as ECPublicKey);
  }

  /// Derive AES-256 key for 1:1 chat via ECDH + HKDF
  Future<Uint8List> deriveDmKey(String chatId, String peerPublicJwk) async {
    if (_dmKeys.containsKey(chatId)) return _dmKeys[chatId]!;

    final peerPub = _importPublicKey(peerPublicJwk);
    final agreement = ECDHBasicAgreement();
    agreement.init(_keyPair!.privateKey as ECPrivateKey);
    final shared = agreement.calculateAgreement(peerPub);

    // HKDF-SHA256 extract+expand -> 32 bytes AES key
    final sharedBytes = _bigIntToBytes(shared);
    final salt = utf8.encode('xyzora-dm-v1');
    final info = utf8.encode(chatId);
    final key = _hkdf(sharedBytes, salt, info, 32);
    _dmKeys[chatId] = key;
    return key;
  }

  /// Encrypt plaintext for DM
  Future<Map<String, String>> encryptDm({
    required String chatId,
    required String peerPublicJwk,
    required String plaintext,
  }) async {
    final key = await deriveDmKey(chatId, peerPublicJwk);
    return _aesGcmEncrypt(key, plaintext);
  }

  /// Decrypt ciphertext for DM
  Future<String> decryptDm({
    required String chatId,
    required String peerPublicJwk,
    required String ciphertextB64,
    required String ivB64,
    required String tagB64,
  }) async {
    final key = await deriveDmKey(chatId, peerPublicJwk);
    return _aesGcmDecrypt(key, ciphertextB64, ivB64, tagB64);
  }

  /// Encrypt for group (with versioned key)
  Future<Map<String, String>> encryptGroup({
    required String chatId,
    required int keyVersion,
    required Uint8List groupKey,
    required String plaintext,
  }) async {
    _groupKeys.putIfAbsent(chatId, () => {});
    _groupKeys[chatId]![keyVersion] = groupKey;
    final result = _aesGcmEncrypt(groupKey, plaintext);
    result['v'] = keyVersion.toString();
    return result;
  }

  Future<String> decryptGroup({
    required String chatId,
    required int keyVersion,
    required Uint8List groupKey,
    required String ciphertextB64,
    required String ivB64,
    required String tagB64,
  }) async {
    return _aesGcmDecrypt(groupKey, ciphertextB64, ivB64, tagB64);
  }

  // ---------- AES-GCM ----------
  Map<String, String> _aesGcmEncrypt(Uint8List key, String plaintext) {
    final iv = Uint8List.fromList(
      List.generate(12, (_) => Random.secure().nextInt(256)),
    );
    final cipher = GCMBlockCipher(AESEngine())
      ..init(
        true,
        AEADParameters(KeyParameter(key), 128, iv, Uint8List(0)),
      );
    final input = Uint8List.fromList(utf8.encode(plaintext));
    final out = cipher.process(input);
    // out = ciphertext || tag (16 bytes)
    final ct = out.sublist(0, out.length - 16);
    final tag = out.sublist(out.length - 16);
    return {
      'ct': base64Encode(ct),
      'iv': base64Encode(iv),
      'tag': base64Encode(tag),
    };
  }

  String _aesGcmDecrypt(
    Uint8List key,
    String ciphertextB64,
    String ivB64,
    String tagB64,
  ) {
    final iv = base64Decode(ivB64);
    final ct = base64Decode(ciphertextB64);
    final tag = base64Decode(tagB64);
    final input = Uint8List.fromList([...ct, ...tag]);
    final cipher = GCMBlockCipher(AESEngine())
      ..init(
        false,
        AEADParameters(KeyParameter(key), 128, iv, Uint8List(0)),
      );
    final out = cipher.process(input);
    return utf8.decode(out);
  }

  // ---------- HKDF ----------
  Uint8List _hkdf(Uint8List ikm, List<int> salt, List<int> info, int length) {
    final hmac = Hmac(sha256, salt);
    final prk = hmac.convert(ikm).bytes;
    final hmac2 = Hmac(sha256, prk);
    final t = <int>[];
    var prev = <int>[];
    var counter = 1;
    while (t.length < length) {
      final input = [...prev, ...info, counter];
      prev = hmac2.convert(input).bytes;
      t.addAll(prev);
      counter++;
    }
    return Uint8List.fromList(t.sublist(0, length));
  }

  // ---------- Key import/export (simplified JWK-like) ----------
  String _exportPublicJwk(ECPublicKey pub) {
    final x = _bigIntToBytes(pub.Q!.x!.toBigInteger()!);
    final y = _bigIntToBytes(pub.Q!.y!.toBigInteger()!);
    return jsonEncode({
      'kty': 'EC',
      'crv': 'P-256',
      'x': base64UrlEncode(x).replaceAll('=', ''),
      'y': base64UrlEncode(y).replaceAll('=', ''),
    });
  }

  String _exportPrivateJwk(ECPrivateKey priv) {
    final d = _bigIntToBytes(priv.d!);
    final pub = _keyPair!.publicKey as ECPublicKey;
    final x = _bigIntToBytes(pub.Q!.x!.toBigInteger()!);
    final y = _bigIntToBytes(pub.Q!.y!.toBigInteger()!);
    return jsonEncode({
      'kty': 'EC',
      'crv': 'P-256',
      'd': base64UrlEncode(d).replaceAll('=', ''),
      'x': base64UrlEncode(x).replaceAll('=', ''),
      'y': base64UrlEncode(y).replaceAll('=', ''),
    });
  }

  ECPublicKey _importPublicKey(String jwkStr) {
    final jwk = jsonDecode(jwkStr) as Map<String, dynamic>;
    final x = _base64UrlDecode(jwk['x'] as String);
    final y = _base64UrlDecode(jwk['y'] as String);
    final curve = ECCurve_secp256r1();
    final q = curve.curve.createPoint(
      _bytesToBigInt(x),
      _bytesToBigInt(y),
    );
    return ECPublicKey(q, curve);
  }

  AsymmetricKeyPair<PublicKey, PrivateKey> _importKeyPair(
    String privJwk,
    String pubJwk,
  ) {
    final priv = jsonDecode(privJwk) as Map<String, dynamic>;
    final d = _bytesToBigInt(_base64UrlDecode(priv['d'] as String));
    final curve = ECCurve_secp256r1();
    final privateKey = ECPrivateKey(d, curve);
    final publicKey = _importPublicKey(pubJwk);
    return AsymmetricKeyPair(publicKey, privateKey);
  }

  Future<String> _computeFingerprint(ECPublicKey pub) async {
    final x = _bigIntToBytes(pub.Q!.x!.toBigInteger()!);
    final y = _bigIntToBytes(pub.Q!.y!.toBigInteger()!);
    final hash = sha256.convert([...x, ...y]);
    return hex.encode(hash.bytes).substring(0, 16);
  }

  Uint8List _bigIntToBytes(BigInt n) {
    var hexStr = n.toRadixString(16);
    if (hexStr.length % 2 != 0) hexStr = '0$hexStr';
    return Uint8List.fromList(hex.decode(hexStr));
  }

  BigInt _bytesToBigInt(Uint8List bytes) {
    return BigInt.parse(hex.encode(bytes), radix: 16);
  }

  Uint8List _base64UrlDecode(String s) {
    var str = s.replaceAll('-', '+').replaceAll('_', '/');
    while (str.length % 4 != 0) {
      str += '=';
    }
    return base64Decode(str);
  }
}
