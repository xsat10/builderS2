import 'dart:async';
import 'dart:convert';
import 'package:socket_io_client/socket_io_client.dart' as io;
import '../constants/api_endpoints.dart';
import '../security/storage_helper.dart';

typedef MessageHandler = void Function(Map<String, dynamic> data);
typedef PresenceHandler = void Function(String userId, bool online);
typedef TypingHandler = void Function(String chatId, String userId, bool isTyping);

/// Socket.IO client dengan auto-reconnect, auth JWT, presence, typing, read receipt.
class WebSocketClient {
  WebSocketClient._();
  static final WebSocketClient instance = WebSocketClient._();

  io.Socket? _socket;
  final _storage = StorageHelper.instance;
  bool _intentionalDisconnect = false;

  final _messageControllers = <String, StreamController<Map<String, dynamic>>>{};
  final _presenceController = StreamController<Map<String, bool>>.broadcast();
  final _typingController = StreamController<Map<String, dynamic>>.broadcast();
  final _connectionController = StreamController<bool>.broadcast();

  Stream<bool> get connectionStream => _connectionController.stream;
  Stream<Map<String, bool>> get presenceStream => _presenceController.stream;
  Stream<Map<String, dynamic>> get typingStream => _typingController.stream;

  bool get isConnected => _socket?.connected ?? false;

  Future<void> connect() async {
    if (_socket != null && _socket!.connected) return;

    final token = await _storage.getToken();
    if (token == null) throw Exception('No auth token');

    _intentionalDisconnect = false;

    _socket = io.io(
      ApiEndpoints.baseUrl,
      io.OptionBuilder()
          .setTransports(['websocket'])
          .enableAutoConnect()
          .enableReconnection()
          .setReconnectionAttempts(999)
          .setReconnectionDelay(2000)
          .setAuth({'token': token})
          .setExtraHeaders({'Authorization': 'Bearer $token'})
          .build(),
    );

    _socket!
      ..onConnect((_) {
        _connectionController.add(true);
        _socket!.emit('auth', {'token': token});
      })
      ..onDisconnect((_) {
        _connectionController.add(false);
        if (!_intentionalDisconnect) {
          // auto-reconnect handled by socket_io_client
        }
      })
      ..onConnectError((e) {
        _connectionController.add(false);
      })
      ..on('message', (data) {
        final map = _toMap(data);
        final chatId = map['chatId']?.toString() ?? map['room']?.toString() ?? '';
        _messageControllers[chatId]?.add(map);
        _messageControllers['*']?.add(map);
      })
      ..on('typing', (data) {
        _typingController.add(_toMap(data));
      })
      ..on('presence', (data) {
        final map = _toMap(data);
        final uid = map['userId']?.toString() ?? '';
        final online = map['online'] == true || map['status'] == 'online';
        if (uid.isNotEmpty) {
          _presenceController.add({uid: online});
        }
      })
      ..on('read', (data) {
        final map = _toMap(data);
        _messageControllers['*']?.add({...map, '_type': 'read'});
      })
      ..on('call', (data) {
        _messageControllers['call']?.add(_toMap(data));
      })
      ..on('call-signal', (data) {
        _messageControllers['call']?.add({..._toMap(data), '_type': 'signal'});
      })
      ..on('music', (data) {
        _messageControllers['music']?.add(_toMap(data));
      });
  }

  void disconnect() {
    _intentionalDisconnect = true;
    _socket?.disconnect();
    _socket?.dispose();
    _socket = null;
    _connectionController.add(false);
  }

  Stream<Map<String, dynamic>> messagesFor(String chatId) {
    _messageControllers.putIfAbsent(
      chatId,
      () => StreamController<Map<String, dynamic>>.broadcast(),
    );
    return _messageControllers[chatId]!.stream;
  }

  Stream<Map<String, dynamic>> get allMessages {
    _messageControllers.putIfAbsent(
      '*',
      () => StreamController<Map<String, dynamic>>.broadcast(),
    );
    return _messageControllers['*']!.stream;
  }

  void joinChat(String chatId) {
    _socket?.emit('join', {'chatId': chatId});
  }

  void leaveChat(String chatId) {
    _socket?.emit('leave', {'chatId': chatId});
  }

  void sendMessage(Map<String, dynamic> payload) {
    _socket?.emit('message', payload);
  }

  void sendTyping(String chatId, bool isTyping) {
    _socket?.emit('typing', {'chatId': chatId, 'typing': isTyping});
  }

  void sendRead(String chatId, String messageId) {
    _socket?.emit('read', {'chatId': chatId, 'messageId': messageId});
  }

  void sendCallSignal(Map<String, dynamic> signal) {
    _socket?.emit('call-signal', signal);
  }

  void sendMusicEvent(Map<String, dynamic> event) {
    _socket?.emit('music', event);
  }

  Map<String, dynamic> _toMap(dynamic data) {
    if (data is Map) return Map<String, dynamic>.from(data);
    if (data is String) {
      try {
        return jsonDecode(data) as Map<String, dynamic>;
      } catch (_) {}
    }
    return {};
  }

  void dispose() {
    disconnect();
    for (final c in _messageControllers.values) {
      c.close();
    }
    _messageControllers.clear();
    _presenceController.close();
    _typingController.close();
    _connectionController.close();
  }
}
