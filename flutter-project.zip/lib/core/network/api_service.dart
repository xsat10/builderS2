import 'dart:convert';
import 'package:http/http.dart' as http;
import '../constants/api_endpoints.dart';
import '../security/storage_helper.dart';

class ApiService {
  ApiService._();
  static final ApiService instance = ApiService._();

  final _storage = StorageHelper.instance;
  String? _pageToken; // token halaman dari /api/challenge (anti-bot)

  Future<Map<String, String>> _headers({bool auth = false}) async {
    final h = <String, String>{
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };
    if (_pageToken != null) {
      h['X-Page-Token'] = _pageToken!;
    }
    if (auth) {
      final token = await _storage.getToken();
      if (token != null) h['Authorization'] = 'Bearer $token';
    }
    return h;
  }

  /// Ambil page token (challenge) sebelum register/login
  Future<void> fetchChallenge() async {
    try {
      final res = await http.get(
        Uri.parse('${ApiEndpoints.baseUrl}${ApiEndpoints.challenge}'),
        headers: await _headers(),
      );
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body) as Map<String, dynamic>;
        _pageToken = data['token'] as String? ?? data['pageToken'] as String?;
      }
    } catch (_) {}
  }

  Future<Map<String, dynamic>> login({
    required String username,
    required String password,
  }) async {
    await fetchChallenge();
    final res = await http.post(
      Uri.parse('${ApiEndpoints.baseUrl}${ApiEndpoints.login}'),
      headers: await _headers(),
      body: jsonEncode({'username': username, 'password': password}),
    );
    final body = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode != 200) {
      throw ApiException(body['error']?.toString() ?? 'Login gagal', res.statusCode);
    }
    final token = body['token'] as String;
    final user = body['user'] as Map<String, dynamic>;
    await _storage.saveSession(
      token: token,
      userId: user['id']?.toString() ?? user['_id']?.toString() ?? '',
      username: user['username']?.toString() ?? username,
      user: user,
    );
    return body;
  }

  Future<Map<String, dynamic>> register({
    required String username,
    required String password,
    required String displayName,
    required String birthDate, // YYYY-MM-DD
    String? guardianContact,
  }) async {
    await fetchChallenge();
    final payload = <String, dynamic>{
      'username': username,
      'password': password,
      'displayName': displayName,
      'birthDate': birthDate,
    };
    if (guardianContact != null && guardianContact.isNotEmpty) {
      payload['guardianContact'] = guardianContact;
    }
    final res = await http.post(
      Uri.parse('${ApiEndpoints.baseUrl}${ApiEndpoints.register}'),
      headers: await _headers(),
      body: jsonEncode(payload),
    );
    final body = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode != 200 && res.statusCode != 201) {
      throw ApiException(body['error']?.toString() ?? 'Registrasi gagal', res.statusCode);
    }
    // beberapa backend langsung return token
    if (body['token'] != null) {
      final user = body['user'] as Map<String, dynamic>? ?? {};
      await _storage.saveSession(
        token: body['token'] as String,
        userId: user['id']?.toString() ?? '',
        username: user['username']?.toString() ?? username,
        user: user,
      );
    }
    return body;
  }

  Future<Map<String, dynamic>> getMe() async {
    final res = await http.get(
      Uri.parse('${ApiEndpoints.baseUrl}${ApiEndpoints.me}'),
      headers: await _headers(auth: true),
    );
    final body = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode != 200) {
      throw ApiException(body['error']?.toString() ?? 'Gagal ambil profil', res.statusCode);
    }
    return body;
  }

  Future<Map<String, dynamic>> updateSettings(Map<String, dynamic> settings) async {
    final res = await http.put(
      Uri.parse('${ApiEndpoints.baseUrl}${ApiEndpoints.meSettings}'),
      headers: await _headers(auth: true),
      body: jsonEncode(settings),
    );
    final body = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode != 200) {
      throw ApiException(body['error']?.toString() ?? 'Gagal update settings', res.statusCode);
    }
    return body;
  }

  Future<void> logout() async {
    await _storage.clearSession();
  }
}

class ApiException implements Exception {
  final String message;
  final int statusCode;
  ApiException(this.message, this.statusCode);
  @override
  String toString() => 'ApiException($statusCode): $message';
}
