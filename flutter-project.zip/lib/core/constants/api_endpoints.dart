/// API & WebSocket endpoints for Xyzora Chat backend.
/// Ganti [baseUrl] sesuai server production / development.
class ApiEndpoints {
  ApiEndpoints._();

  /// Production backend Xyzora Chat
  static const String baseUrl = 'https://xyzorachat.exyzogamepoint.xyz';
  // Local testing: 'http://10.0.2.2:3000' (Android emulator) / 'http://localhost:3000'

  static String get apiBase => '$baseUrl/api';
  static String get wsUrl => baseUrl.replaceFirst('https', 'wss').replaceFirst('http', 'ws');

  // Auth
  static const String challenge = '/api/challenge';
  static const String register = '/api/register';
  static const String login = '/api/login';
  static const String me = '/api/me';
  static const String meSettings = '/api/me/settings';
  static const String mePassword = '/api/me/password';
  static const String meAvatar = '/api/me/avatar';
  static const String splash = '/api/splash';
  static const String deviceStatus = '/api/device/status';
  static const String deviceRequest = '/api/device/request';

  // Pro / Premium
  static const String proStatus = '/api/pro/status';
  static const String proTrial = '/api/pro/trial';
  static const String proCreatePayment = '/api/pro/create-payment';

  // Chat / Messages (REST fallback + upload)
  static const String upload = '/api/upload';
  static const String messages = '/api/messages';
  static const String chats = '/api/chats';
  static const String users = '/api/users';
  static const String groups = '/api/groups';
  static const String channels = '/api/channels';

  // E2EE keys
  static const String e2eePublicKey = '/api/e2ee/public-key';
  static const String e2eeBackup = '/api/e2ee/backup';

  // Socket.IO events (client -> server)
  static const String socketConnect = 'connect';
  static const String socketAuth = 'auth';
  static const String socketJoin = 'join';
  static const String socketLeave = 'leave';
  static const String socketMessage = 'message';
  static const String socketTyping = 'typing';
  static const String socketRead = 'read';
  static const String socketPresence = 'presence';
  static const String socketCall = 'call';
  static const String socketCallSignal = 'call-signal';
  static const String socketMusic = 'music';
}
