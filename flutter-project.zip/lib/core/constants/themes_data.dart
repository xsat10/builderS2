import 'package:flutter/material.dart';

/// Palette warna & desain yang diambil langsung dari public/css/themes.css
/// Theme IDs: neo (default), dark, ocean, sakura, mint, minimal, glass
class XyzoraThemeData {
  final String id;
  final String name;
  final String description;
  final Color black;
  final Color white;
  final Color cream;
  final Color yellow;
  final Color purple;
  final Color pink;
  final Color blue;
  final Color cyan;
  final Color orange;
  final Color green;
  final Color red;
  final Color bubbleMe;
  final Color bubbleOther;
  final double borderW;
  final double borderWLg;
  final double shadowOff;
  final double shadowOffLg;
  final double radius;
  final double radiusSm;
  final bool isDark;
  final bool isGlass;
  final LinearGradient? backgroundGradient;

  const XyzoraThemeData({
    required this.id,
    required this.name,
    required this.description,
    required this.black,
    required this.white,
    required this.cream,
    required this.yellow,
    required this.purple,
    required this.pink,
    required this.blue,
    required this.cyan,
    required this.orange,
    required this.green,
    required this.red,
    required this.bubbleMe,
    required this.bubbleOther,
    this.borderW = 3.0,
    this.borderWLg = 4.0,
    this.shadowOff = 5.0,
    this.shadowOffLg = 7.0,
    this.radius = 14.0,
    this.radiusSm = 10.0,
    this.isDark = false,
    this.isGlass = false,
    this.backgroundGradient,
  });

  /// Default "neo" — Neobrutalism asli dari :root style.css
  static const XyzoraThemeData neo = XyzoraThemeData(
    id: 'neo',
    name: 'Neo',
    description: 'Neobrutalism klasik Xyzora',
    black: Color(0xFF0A0A0A),
    white: Color(0xFFFFFFFF),
    cream: Color(0xFFFFF8E7),
    yellow: Color(0xFFFFD93D),
    purple: Color(0xFF9B5DE5),
    pink: Color(0xFFFF5DA2),
    blue: Color(0xFF4D96FF),
    cyan: Color(0xFF3DDBD9),
    orange: Color(0xFFFF8C42),
    green: Color(0xFF6BCB77),
    red: Color(0xFFFF4545),
    bubbleMe: Color(0xFFFFD93D),
    bubbleOther: Color(0xFFFFFFFF),
  );

  static const XyzoraThemeData dark = XyzoraThemeData(
    id: 'dark',
    name: 'Dark',
    description: 'Mode gelap elegan',
    black: Color(0xFFE8E8F0),
    white: Color(0xFF1A1A2E),
    cream: Color(0xFF12121F),
    yellow: Color(0xFF2A2A40),
    purple: Color(0xFFB78BFF),
    pink: Color(0xFFFF7DB5),
    blue: Color(0xFF7B9CFF),
    cyan: Color(0xFF5FE0DC),
    orange: Color(0xFFFFA15C),
    green: Color(0xFF5FD08B),
    red: Color(0xFFFF5A6E),
    bubbleMe: Color(0xFF3A2A50),
    bubbleOther: Color(0xFF252538),
    isDark: true,
  );

  static const XyzoraThemeData ocean = XyzoraThemeData(
    id: 'ocean',
    name: 'Ocean',
    description: 'Biru laut tenang',
    black: Color(0xFF0D1B2A),
    white: Color(0xFFFFFFFF),
    cream: Color(0xFFE8F4FC),
    yellow: Color(0xFFA8D8F0),
    purple: Color(0xFF1B6CA8),
    pink: Color(0xFF4A9FD8),
    blue: Color(0xFF0E4D7B),
    cyan: Color(0xFF5BC0BE),
    orange: Color(0xFFFF9B7A),
    green: Color(0xFF3FCB7D),
    red: Color(0xFFE5484D),
    bubbleMe: Color(0xFFA8D8F0),
    bubbleOther: Color(0xFFFFFFFF),
  );

  static const XyzoraThemeData sakura = XyzoraThemeData(
    id: 'sakura',
    name: 'Sakura',
    description: 'Pink lembut Jepang',
    black: Color(0xFF2D1B2E),
    white: Color(0xFFFFFFFF),
    cream: Color(0xFFFFF0F5),
    yellow: Color(0xFFFFD6E7),
    purple: Color(0xFFE85A8C),
    pink: Color(0xFFFF8FB8),
    blue: Color(0xFFC98BFF),
    cyan: Color(0xFF8FE3D6),
    orange: Color(0xFFFF9B7A),
    green: Color(0xFF7AD9A0),
    red: Color(0xFFFF5A6E),
    bubbleMe: Color(0xFFFFD6E7),
    bubbleOther: Color(0xFFFFFFFF),
  );

  static const XyzoraThemeData mint = XyzoraThemeData(
    id: 'mint',
    name: 'Mint',
    description: 'Hijau segar',
    black: Color(0xFF1A2E1F),
    white: Color(0xFFFFFFFF),
    cream: Color(0xFFEFFBF3),
    yellow: Color(0xFFB8F0C8),
    purple: Color(0xFF1FA971),
    pink: Color(0xFFF59E7C),
    blue: Color(0xFF3DB8C9),
    cyan: Color(0xFF5EDCC6),
    orange: Color(0xFFF2A65A),
    green: Color(0xFF3FCB7D),
    red: Color(0xFFE5484D),
    bubbleMe: Color(0xFFB8F0C8),
    bubbleOther: Color(0xFFFFFFFF),
  );

  static const XyzoraThemeData minimal = XyzoraThemeData(
    id: 'minimal',
    name: 'Minimal',
    description: 'Bersih, garis tipis',
    black: Color(0xFF1D1F2B),
    white: Color(0xFFFFFFFF),
    cream: Color(0xFFF5F6FA),
    yellow: Color(0xFFE9ECFF),
    purple: Color(0xFF5B6CFF),
    pink: Color(0xFF8B93FF),
    blue: Color(0xFF5B6CFF),
    cyan: Color(0xFFDDE3FF),
    orange: Color(0xFF7C86FF),
    green: Color(0xFF3BB58A),
    red: Color(0xFFE5484D),
    bubbleMe: Color(0xFFE3E7FF),
    bubbleOther: Color(0xFFFFFFFF),
    borderW: 1.0,
    borderWLg: 1.0,
    shadowOff: 0.0,
    shadowOffLg: 0.0,
    radius: 16.0,
    radiusSm: 12.0,
  );

  static const XyzoraThemeData glass = XyzoraThemeData(
    id: 'glass',
    name: 'Liquid Glass',
    description: 'Kaca transparan + blur',
    black: Color(0xFF1B1B33),
    white: Color(0x75FFFFFF),
    cream: Color(0x4DFFFFFF),
    yellow: Color(0xB3FFE28C),
    purple: Color(0xFF7C5CFF),
    pink: Color(0xFFFF7EB6),
    blue: Color(0xFF5B9BFF),
    cyan: Color(0xFF5FE0DC),
    orange: Color(0xFFFFA15C),
    green: Color(0xFF5FD08B),
    red: Color(0xFFFF5A6E),
    bubbleMe: Color(0xBF8CAAFF),
    bubbleOther: Color(0xBFFFFFFF),
    borderW: 1.0,
    borderWLg: 1.0,
    shadowOff: 0.0,
    shadowOffLg: 0.0,
    radius: 22.0,
    radiusSm: 16.0,
    isGlass: true,
    backgroundGradient: LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [Color(0xFFB9C6FF), Color(0xFFE8D5FF), Color(0xFFFFD6E8)],
    ),
  );

  static const List<XyzoraThemeData> all = [
    neo,
    dark,
    ocean,
    sakura,
    mint,
    minimal,
    glass,
  ];

  static XyzoraThemeData byId(String id) {
    return all.firstWhere((t) => t.id == id, orElse: () => neo);
  }

  ThemeData toThemeData() {
    final brightness = isDark ? Brightness.dark : Brightness.light;
    return ThemeData(
      useMaterial3: true,
      brightness: brightness,
      scaffoldBackgroundColor: cream,
      primaryColor: purple,
      colorScheme: ColorScheme(
        brightness: brightness,
        primary: purple,
        onPrimary: isDark ? black : white,
        secondary: pink,
        onSecondary: white,
        error: red,
        onError: white,
        surface: isDark ? white : cream,
        onSurface: black,
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: isGlass ? Colors.transparent : cream,
        foregroundColor: black,
        elevation: 0,
      ),
      cardTheme: CardTheme(
        color: white,
        elevation: shadowOff,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(radius),
          side: BorderSide(color: black.withOpacity(0.15), width: borderW),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: purple,
          foregroundColor: white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(radiusSm),
            side: BorderSide(color: black, width: borderW),
          ),
          elevation: shadowOff,
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(radiusSm),
          borderSide: BorderSide(color: black, width: borderW),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(radiusSm),
          borderSide: BorderSide(color: black.withOpacity(0.3), width: borderW),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(radiusSm),
          borderSide: BorderSide(color: purple, width: borderWLg),
        ),
      ),
    );
  }
}
