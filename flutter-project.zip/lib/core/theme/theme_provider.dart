import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../constants/themes_data.dart';

class ThemeProvider extends ChangeNotifier {
  static const _storageKey = 'xyzora_theme_id';
  final FlutterSecureStorage _storage = const FlutterSecureStorage();

  XyzoraThemeData _theme = XyzoraThemeData.neo;

  XyzoraThemeData get theme => _theme;
  ThemeData get themeData => _theme.toThemeData();
  String get themeId => _theme.id;
  List<XyzoraThemeData> get availableThemes => XyzoraThemeData.all;

  ThemeProvider() {
    _load();
  }

  Future<void> _load() async {
    try {
      final id = await _storage.read(key: _storageKey);
      if (id != null) {
        _theme = XyzoraThemeData.byId(id);
        notifyListeners();
      }
    } catch (_) {}
  }

  Future<void> setTheme(String id) async {
    _theme = XyzoraThemeData.byId(id);
    notifyListeners();
    try {
      await _storage.write(key: _storageKey, value: id);
    } catch (_) {}
  }

  Future<void> setThemeData(XyzoraThemeData t) async {
    await setTheme(t.id);
  }
}
