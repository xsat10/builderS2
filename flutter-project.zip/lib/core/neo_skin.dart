import 'package:flutter/material.dart';

class NeoSkinId {
  NeoSkinId._();
  static const String midnight = 'midnight';
}

class NeoPalette {
  final String id;
  final String label;
  final Color primary;
  final Color secondary;
  final Color accent;
  final Color background;
  final Color surface;
  final Color onBackground1;

  const NeoPalette({
    required this.id,
    required this.label,
    required this.primary,
    required this.secondary,
    required this.accent,
    required this.background,
    required this.surface,
    required this.onBackground1,
  });
}

class NeoSkin {
  NeoSkin._();

  static const Map<String, NeoPalette> byId = <String, NeoPalette>{
    NeoSkinId.midnight: NeoPalette(
      id: NeoSkinId.midnight,
      label: 'MIDNIGHT',
      primary: Color(0xFF9B6BFF),
      secondary: Color(0xFFFFB84D),
      accent: Color(0xFF36C5F0),
      background: Color(0xFF0B0D1F),
      surface: Color(0xFF14142A),
      onBackground1: Color(0xFFFFFFFF),
    ),
  };

  static NeoPalette of(String id) =>
      byId[id] ?? byId[NeoSkinId.midnight]!;
}
