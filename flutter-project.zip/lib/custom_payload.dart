import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';

class CustomPayloadPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;
  final List<Map<String, dynamic>> listBug;
  final String? password;      // 🔥 DITAMBAHKAN (opsional)
  final String? expiredDate;   // 🔥 DITAMBAHKAN (opsional)

  const CustomPayloadPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
    required this.listBug,
    this.password,
    this.expiredDate,
  });

  @override
  State<CustomPayloadPage> createState() => _CustomPayloadPageState();
}

class _CustomPayloadPageState extends State<CustomPayloadPage>
    with TickerProviderStateMixin {
  // ─── Controllers ──────────────────────────────────────────────
  final TextEditingController _targetController = TextEditingController();
  final TextEditingController _delayController = TextEditingController(text: "1000");
  final TextEditingController _countController = TextEditingController(text: "1");

  // ─── State ────────────────────────────────────────────────────
  final List<Map<String, dynamic>> _selectedBugs = [];
  bool _isSending = false;
  bool _isLoading = false;
  double _progress = 0.0;
  String _statusText = 'Siap mengirim payload';
  final List<Map<String, dynamic>> _history = [];
  bool _showHistory = false;

  late VideoPlayerController _videoController;
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  // ─── Colors ────────────────────────────────────────────────────
  static const Color _primaryColor = Color(0xFF050810);
  static const Color _accentColor = Color(0xFF00D4FF);
  static const Color _accentSoft = Color(0xFF0099CC);
  static const Color _successColor = Color(0xFF00E5A0);
  static const Color _warningColor = Color(0xFFFFB547);
  static const Color _dangerColor = Color(0xFFFF4D6A);
  static const Color _textPrimary = Color(0xFFEEF2FF);
  static const Color _textSecondary = Color(0xFF8B9BBE);
  static const Color _cardBorder = Color(0xFF1E2D4A);
  static const Color _cardColor = Color(0xFF0E1628);

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);
    _pulseAnimation = Tween<double>(begin: 0.96, end: 1.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
    _initVideoPlayer();
    _loadHistory();
  }

  void _initVideoPlayer() {
    _videoController = VideoPlayerController.asset('assets/videos/background.mp4');
    _videoController.initialize().then((_) {
      if (mounted) {
        setState(() {
          _videoController.setLooping(true);
          _videoController.setVolume(0.0);
          _videoController.play();
        });
      }
    }).catchError((_) {});
  }

  @override
  void dispose() {
    _targetController.dispose();
    _delayController.dispose();
    _countController.dispose();
    _pulseController.dispose();
    _videoController.dispose();
    super.dispose();
  }

  // ─── History ──────────────────────────────────────────────────
  Future<void> _loadHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString('custom_payload_history');
    if (data != null) {
      try {
        final list = jsonDecode(data) as List;
        setState(() {
          _history.clear();
          _history.addAll(list.cast<Map<String, dynamic>>());
        });
      } catch (_) {}
    }
  }

  Future<void> _saveHistory(Map<String, dynamic> entry) async {
    final prefs = await SharedPreferences.getInstance();
    _history.insert(0, entry);
    if (_history.length > 50) _history.removeLast();
    await prefs.setString('custom_payload_history', jsonEncode(_history));
  }

  Future<void> _clearHistory() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() => _history.clear());
    await prefs.remove('custom_payload_history');
  }

  // ─── Helpers ──────────────────────────────────────────────────
  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^0-9+]'), '');
    if (cleaned.isEmpty) return null;
    return cleaned.startsWith('+') ? cleaned.substring(1) : cleaned;
  }

  List<Color> _bugGradient(int index) {
    const palettes = [
      [Color(0xFF00D4FF), Color(0xFF00E5A0)],
      [Color(0xFFFF6B6B), Color(0xFFFF8E53)],
      [Color(0xFF8E54E9), Color(0xFF4776E6)],
      [Color(0xFFFFD166), Color(0xFFFFB347)],
      [Color(0xFF06D6A0), Color(0xFF4CC9F0)],
    ];
    return palettes[index % palettes.length];
  }

  void _toast(String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
      backgroundColor: color,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      duration: const Duration(seconds: 3),
      margin: const EdgeInsets.all(16),
    ));
  }

  // ─── Sender Check ─────────────────────────────────────────────
  Future<bool> _hasSender() async {
    try {
      final res = await http.get(
        Uri.parse("http://shinoa-cpanelpanel.xtxintax.my.id:2003/mySender?key=${widget.sessionKey}"),
      ).timeout(const Duration(seconds: 5));
      if (res.statusCode != 200) return false;
      final data = jsonDecode(res.body);
      return data["valid"] == true &&
          data["connections"] != null &&
          (data["connections"] as List).isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  // ─── Send Payload ─────────────────────────────────────────────
  Future<void> _sendPayload() async {
    final hasSender = await _hasSender();
    if (!hasSender) {
      _toast('Tidak ada sender aktif! Tambahkan sender dulu.', _warningColor);
      return;
    }

    final target = formatPhoneNumber(_targetController.text.trim());
    if (target == null || target.length < 10) {
      _toast('Nomor tidak valid. Minimal 10 digit.', _warningColor);
      return;
    }
    if (_selectedBugs.isEmpty) {
      _toast('Pilih minimal 1 bug.', _warningColor);
      return;
    }
    final delay = int.tryParse(_delayController.text) ?? 1000;
    if (delay < 0 || delay > 60000) {
      _toast('Delay 0-60000 ms', _warningColor);
      return;
    }
    final count = int.tryParse(_countController.text) ?? 1;
    if (count < 1 || count > 100) {
      _toast('Count 1-100', _warningColor);
      return;
    }

    setState(() {
      _isSending = true;
      _isLoading = true;
      _progress = 0.0;
      _statusText = 'Mempersiapkan payload...';
    });

    final payload = {
      'key': widget.sessionKey,
      'target': target,
      'delay': delay,
      'count': count,
      'bugs': _selectedBugs.map((b) => b['bug_id']).toList(),
      'mode': 'sequential',
      'sequence_order': _selectedBugs.map((b) => b['bug_id']).toList(),
    };

    // Simulasi progress
    Timer.periodic(const Duration(milliseconds: 150), (timer) {
      if (!mounted) { timer.cancel(); return; }
      setState(() {
        _progress += 0.02;
        if (_progress >= 0.95) {
          _progress = 0.95;
          timer.cancel();
        }
        _statusText = 'Mengirim payload... ${(_progress * 100).toInt()}%';
      });
    });

    try {
      final response = await http.post(
        Uri.parse("http://shinoa-cpanelpanel.xtxintax.my.id:2003/api/custom-payload"),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(payload),
      ).timeout(const Duration(seconds: 45));

      setState(() {
        _progress = 1.0;
        _statusText = '✅ Selesai!';
        _isLoading = false;
      });

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) {
          final entry = {
            'target': target,
            'bugs': _selectedBugs.map((b) => b['bug_name']).toList(),
            'count': count,
            'delay': delay,
            'status': 'Berhasil',
            'time': DateTime.now().toIso8601String(),
          };
          await _saveHistory(entry);
          _targetController.clear();
          final bugCount = _selectedBugs.length;
          setState(() => _selectedBugs.clear());
          _showSuccessDialog(target, count, delay, bugCount);
        } else {
          _toast(data['message'] ?? 'Gagal mengirim', _dangerColor);
        }
      } else {
        _toast('Server error ${response.statusCode}', _dangerColor);
      }
    } catch (e) {
      setState(() => _isLoading = false);
      _toast('Koneksi error: $e', _dangerColor);
    } finally {
      setState(() => _isSending = false);
    }
  }

  void _showSuccessDialog(String target, int count, int delay, int bugCount) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.7),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(28),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [_cardColor, _primaryColor],
            ),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: _successColor.withOpacity(0.3)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 72,
                height: 72,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(
                    colors: [_successColor, _accentColor],
                  ),
                ),
                child: const Icon(Icons.check_rounded, color: Colors.white, size: 36),
              ),
              const SizedBox(height: 16),
              const Text('✅ PAYLOAD TERKIRIM',
                  style: TextStyle(
                    fontFamily: 'Astral',
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                  )),
              const SizedBox(height: 8),
              Text('Target: $target  •  $bugCount bug  •  ${count}x  •  ${delay}ms',
                  style: TextStyle(color: _textSecondary, fontSize: 13)),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _successColor,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                  child: const Text('OK', style: TextStyle(color: Colors.white)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── Bug Picker ───────────────────────────────────────────────
  void _openBugPicker() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => StatefulBuilder(
        builder: (ctx, setSheetState) => Container(
          constraints: BoxConstraints(
            maxHeight: MediaQuery.of(context).size.height * 0.55,
          ),
          margin: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: _cardColor,
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: _accentColor.withOpacity(0.2)),
          ),
          child: Column(
            children: [
              Container(
                margin: const EdgeInsets.only(top: 12),
                width: 36,
                height: 4,
                decoration: BoxDecoration(
                  color: _cardBorder,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 8),
                child: Row(
                  children: [
                    Icon(Icons.bug_report_rounded, color: _accentColor),
                    const SizedBox(width: 10),
                    const Text('PILIH PAYLOAD',
                        style: TextStyle(
                          fontFamily: 'Astral',
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                        )),
                    const Spacer(),
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Icon(Icons.close_rounded, color: _textSecondary),
                    ),
                  ],
                ),
              ),
              const Divider(color: _cardBorder),
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: widget.listBug.length,
                  itemBuilder: (ctx, i) {
                    final bug = widget.listBug[i];
                    final isSelected = _selectedBugs.any((s) => s['bug_id'] == bug['bug_id']);
                    final colors = _bugGradient(i);
                    return GestureDetector(
                      onTap: () {
                        if (isSelected) {
                          setState(() => _selectedBugs.removeWhere((s) => s['bug_id'] == bug['bug_id']));
                          setSheetState(() {});
                        } else {
                          setState(() {
                            _selectedBugs.add({
                              'bug_id': bug['bug_id'],
                              'bug_name': bug['bug_name'],
                              'colorIndex': i,
                            });
                          });
                          setSheetState(() {});
                        }
                      },
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                        decoration: BoxDecoration(
                          color: isSelected ? colors[0].withOpacity(0.15) : Colors.white.withOpacity(0.03),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: isSelected ? colors[0].withOpacity(0.5) : _cardBorder,
                          ),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 32,
                              height: 32,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: LinearGradient(colors: colors),
                              ),
                              child: Icon(Icons.shield_rounded, color: Colors.white, size: 14),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(bug['bug_name'] ?? 'Bug',
                                      style: TextStyle(
                                        color: isSelected ? Colors.white : _textSecondary,
                                        fontWeight: FontWeight.w600,
                                      )),
                                  Text(bug['bug_id'] ?? '',
                                      style: TextStyle(color: _textSecondary.withOpacity(0.5), fontSize: 10)),
                                ],
                              ),
                            ),
                            Icon(
                              isSelected ? Icons.check_circle_rounded : Icons.add_circle_outline_rounded,
                              color: isSelected ? _successColor : _textSecondary,
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── Build ────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _primaryColor,
      body: Stack(
        children: [
          // ─── Video Background ──────────────────────────────────
          Positioned.fill(
            child: _videoController.value.isInitialized
                ? VideoPlayer(_videoController)
                : Container(color: _primaryColor),
          ),
          // Overlay
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withOpacity(0.55),
                    Colors.black.withOpacity(0.85),
                  ],
                ),
              ),
            ),
          ),
          // ─── Content ───────────────────────────────────────────
          SafeArea(
            child: Column(
              children: [
                _buildHeader(),
                Expanded(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(18, 10, 18, 20),
                    child: Column(
                      children: [
                        _buildTargetCard(),
                        const SizedBox(height: 12),
                        _buildBugQueueCard(),
                        const SizedBox(height: 12),
                        _buildConfigRow(),
                        const SizedBox(height: 12),
                        _buildProgressBar(),
                        const SizedBox(height: 12),
                        _buildSendButton(),
                        const SizedBox(height: 12),
                        _buildHistoryToggle(),
                        if (_showHistory) _buildHistoryList(),
                        const SizedBox(height: 12),
                        _buildExitButton(),
                        const SizedBox(height: 20),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── Header ───────────────────────────────────────────────────
  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.3),
        border: Border(bottom: BorderSide(color: _cardBorder.withOpacity(0.5))),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _accentColor.withOpacity(0.1),
              ),
              child: const Icon(Icons.arrow_back_ios_new_rounded, color: _accentColor, size: 18),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ShaderMask(
                  shaderCallback: (b) => const LinearGradient(
                    colors: [Colors.white, Color(0xFF00D4FF)],
                  ).createShader(b),
                  child: const Text('CUSTOM PAYLOAD',
                      style: TextStyle(
                        fontFamily: 'Astral',
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 1,
                      )),
                ),
                Text('${_selectedBugs.length} bug terpilih',
                    style: TextStyle(color: _textSecondary, fontSize: 11)),
              ],
            ),
          ),
          // ─── Tombol Lapor ke Telegram ─────────────────────────
          GestureDetector(
            onTap: () => _launchTelegram(),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _dangerColor.withOpacity(0.15),
                border: Border.all(color: _dangerColor.withOpacity(0.3)),
              ),
              child: Icon(Icons.report_problem_rounded, color: _dangerColor, size: 22),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _launchTelegram() async {
    const url = 'https://t.me/Mclareninfo';
    if (await canLaunchUrl(Uri.parse(url))) {
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } else {
      _toast('Tidak bisa membuka Telegram', _warningColor);
    }
  }

  // ─── Target Card ──────────────────────────────────────────────
  Widget _buildTargetCard() {
    return _glassCard(
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(colors: [_accentColor, _accentSoft]),
            ),
            child: const Icon(Icons.phone_android_rounded, color: Colors.white, size: 20),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('NOMOR TARGET',
                    style: TextStyle(color: _textSecondary, fontSize: 10, letterSpacing: 1.2)),
                TextField(
                  controller: _targetController,
                  keyboardType: TextInputType.phone,
                  style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w600),
                  cursorColor: _accentColor,
                  decoration: InputDecoration(
                    hintText: '62xxxxxxxxxx',
                    hintStyle: TextStyle(color: _textSecondary.withOpacity(0.4), fontSize: 15),
                    border: InputBorder.none,
                    isDense: true,
                    contentPadding: const EdgeInsets.only(top: 4),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── Bug Queue ────────────────────────────────────────────────
  Widget _buildBugQueueCard() {
    return _glassCard(
      child: Column(
        children: [
          Row(
            children: [
              Icon(Icons.bug_report_rounded, color: _dangerColor, size: 18),
              const SizedBox(width: 10),
              Text('ANTRIAN PAYLOAD',
                  style: TextStyle(
                    fontFamily: 'Astral',
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                  )),
              const Spacer(),
              if (_selectedBugs.isNotEmpty)
                GestureDetector(
                  onTap: () => setState(() => _selectedBugs.clear()),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: _dangerColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: _dangerColor.withOpacity(0.2)),
                    ),
                    child: Text('Reset', style: TextStyle(color: _dangerColor, fontSize: 11)),
                  ),
                ),
            ],
          ),
          if (_selectedBugs.isNotEmpty) ...[
            const SizedBox(height: 10),
            SizedBox(
              height: 50,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: _selectedBugs.length,
                itemBuilder: (ctx, i) {
                  final bug = _selectedBugs[i];
                  final colors = _bugGradient(bug['colorIndex'] ?? i);
                  return Container(
                    margin: EdgeInsets.only(right: 8),
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(colors: [
                        colors[0].withOpacity(0.2),
                        colors[1].withOpacity(0.1),
                      ]),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: colors[0].withOpacity(0.4)),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 20,
                          height: 20,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: LinearGradient(colors: colors),
                          ),
                          child: Center(
                            child: Text('${i + 1}',
                                style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.bold)),
                          ),
                        ),
                        const SizedBox(width: 6),
                        Text(bug['bug_name'] ?? 'Bug',
                            style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600)),
                        const SizedBox(width: 4),
                        GestureDetector(
                          onTap: () => setState(() => _selectedBugs.removeAt(i)),
                          child: Icon(Icons.close, color: _textSecondary, size: 14),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 4),
            Text('Geser untuk ubah urutan',
                style: TextStyle(color: _textSecondary.withOpacity(0.4), fontSize: 9)),
          ],
          const SizedBox(height: 12),
          GestureDetector(
            onTap: _openBugPicker,
            child: Container(
              height: 44,
              decoration: BoxDecoration(
                color: _accentColor.withOpacity(0.05),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _accentColor.withOpacity(0.2)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.add_circle_outline_rounded, color: _accentColor, size: 18),
                  const SizedBox(width: 8),
                  Text('TAMBAH PAYLOAD',
                      style: TextStyle(
                        fontFamily: 'Astral',
                        color: _accentColor,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      )),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── Config Row ───────────────────────────────────────────────
  Widget _buildConfigRow() {
    return Row(
      children: [
        Expanded(
          child: _buildConfigTile(
            label: 'DELAY',
            sub: 'Interval (ms)',
            controller: _delayController,
            colors: const [Color(0xFFFF6B6B), Color(0xFFFF8E53)],
            icon: Icons.timer_outlined,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _buildConfigTile(
            label: 'COUNT',
            sub: 'Pengulangan',
            controller: _countController,
            colors: const [Color(0xFF06D6A0), Color(0xFF4CC9F0)],
            icon: Icons.repeat_rounded,
          ),
        ),
      ],
    );
  }

  Widget _buildConfigTile({
    required String label,
    required String sub,
    required TextEditingController controller,
    required List<Color> colors,
    required IconData icon,
  }) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(18),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                colors[0].withOpacity(0.14),
                colors[1].withOpacity(0.04),
              ],
            ),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: colors[0].withOpacity(0.22)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                Icon(icon, color: colors[0], size: 14),
                const SizedBox(width: 6),
                Text(label,
                    style: TextStyle(
                      fontFamily: 'Astral',
                      color: colors[0],
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 0.8,
                    )),
              ]),
              Text(sub, style: TextStyle(color: _textSecondary, fontSize: 9)),
              const SizedBox(height: 4),
              TextField(
                controller: controller,
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                style: TextStyle(color: colors[0], fontSize: 22, fontWeight: FontWeight.w800),
                cursorColor: colors[0],
                decoration: const InputDecoration(
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.zero,
                  isDense: true,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── Progress Bar ─────────────────────────────────────────────
  Widget _buildProgressBar() {
    if (!_isLoading && _progress == 0.0) return const SizedBox.shrink();
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.3),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _accentColor.withOpacity(0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(_statusText,
                    style: TextStyle(color: _textSecondary, fontSize: 12, fontWeight: FontWeight.w600)),
              ),
              Text('${(_progress * 100).toInt()}%',
                  style: TextStyle(color: _accentColor, fontSize: 13, fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 6),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: _progress.clamp(0.0, 1.0),
              backgroundColor: Colors.white.withOpacity(0.1),
              valueColor: AlwaysStoppedAnimation<Color>(
                _progress >= 1.0 ? _successColor : _accentColor,
              ),
              minHeight: 6,
            ),
          ),
        ],
      ),
    );
  }

  // ─── Send Button with Chibi ──────────────────────────────────
  Widget _buildSendButton() {
    return GestureDetector(
      onTap: _isSending ? null : _sendPayload,
      child: AnimatedBuilder(
        animation: _pulseController,
        builder: (_, __) => Transform.scale(
          scale: _isSending ? 1.0 : _pulseAnimation.value,
          child: Stack(
            alignment: Alignment.center,
            children: [
              Container(
                height: 64,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: _isSending
                        ? [_accentColor.withOpacity(0.3), _accentSoft.withOpacity(0.3)]
                        : [_accentColor, _accentSoft],
                  ),
                  borderRadius: BorderRadius.circular(18),
                  boxShadow: _isSending
                      ? []
                      : [
                          BoxShadow(
                            color: _accentColor.withOpacity(0.4),
                            blurRadius: 22,
                            offset: const Offset(0, 6),
                          ),
                        ],
                ),
                child: Center(
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 300),
                    child: _isSending
                        ? const Row(
                            key: ValueKey('loading'),
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                              ),
                              SizedBox(width: 12),
                              Text('MENGIRIM...',
                                  style: TextStyle(
                                    fontFamily: 'Astral',
                                    color: Colors.white,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: 1.2,
                                  )),
                            ],
                          )
                        : const Row(
                            key: ValueKey('idle'),
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.rocket_launch_rounded, color: Colors.white, size: 20),
                              SizedBox(width: 12),
                              Text('KIRIM PAYLOAD',
                                  style: TextStyle(
                                    fontFamily: 'Astral',
                                    color: Colors.white,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: 1.5,
                                  )),
                            ],
                          ),
                  ),
                ),
              ),
              // ─── Chibi di pojok kanan bawah button ────────────
              Positioned(
                right: 4,
                bottom: 4,
                child: Image.asset(
                  'assets/images/chibi.png',
                  width: 48,
                  height: 48,
                  fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) => const SizedBox.shrink(),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── History Toggle ───────────────────────────────────────────
  Widget _buildHistoryToggle() {
    return GestureDetector(
      onTap: () => setState(() => _showHistory = !_showHistory),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.03),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _cardBorder.withOpacity(0.5)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(_showHistory ? Icons.history_outlined : Icons.history,
                color: _textSecondary, size: 18),
            const SizedBox(width: 8),
            Text(_showHistory ? 'TUTUP RIWAYAT' : 'RIWAYAT PAYLOAD',
                style: TextStyle(
                  fontFamily: 'Astral',
                  color: _textSecondary,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 1,
                )),
          ],
        ),
      ),
    );
  }

  Widget _buildHistoryList() {
    if (_history.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(20),
        alignment: Alignment.center,
        child: Text('Belum ada riwayat',
            style: TextStyle(color: _textSecondary.withOpacity(0.5), fontSize: 13)),
      );
    }
    return Container(
      constraints: const BoxConstraints(maxHeight: 200),
      child: ListView.builder(
        shrinkWrap: true,
        physics: const BouncingScrollPhysics(),
        itemCount: _history.length,
        itemBuilder: (ctx, i) {
          final item = _history[i];
          final time = DateTime.tryParse(item['time'] ?? '')?.toLocal() ?? DateTime.now();
          final formatted = '${time.day}/${time.month} ${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}';
          final statusColor = item['status'] == 'Berhasil' ? _successColor : _dangerColor;
          return Container(
            margin: const EdgeInsets.only(bottom: 6),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.03),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _cardBorder.withOpacity(0.3)),
            ),
            child: Row(
              children: [
                Container(
                  width: 6,
                  height: 6,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: statusColor,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('${item['target'] ?? ''}  •  ${item['bugs']?.join(', ') ?? ''}',
                          style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis),
                      Text('${item['count'] ?? 0}x  •  ${item['delay'] ?? 0}ms  •  $formatted',
                          style: TextStyle(color: _textSecondary, fontSize: 10)),
                    ],
                  ),
                ),
                Text(item['status'] ?? '',
                    style: TextStyle(color: statusColor, fontSize: 11, fontWeight: FontWeight.bold)),
              ],
            ),
          );
        },
      ),
    );
  }

  // ─── Exit Button ──────────────────────────────────────────────
  Widget _buildExitButton() {
    return GestureDetector(
      onTap: () => Navigator.pop(context),
      child: Container(
        height: 48,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [_dangerColor.withOpacity(0.15), _dangerColor.withOpacity(0.05)],
          ),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _dangerColor.withOpacity(0.2)),
        ),
        child: const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.exit_to_app_rounded, color: Color(0xFFFF4D6A), size: 18),
            SizedBox(width: 10),
            Text('EXIT',
                style: TextStyle(
                  fontFamily: 'Astral',
                  color: Color(0xFFFF4D6A),
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1.2,
                )),
          ],
        ),
      ),
    );
  }

  // ─── Glass Helper ─────────────────────────────────────────────
  Widget _glassCard({required Widget child}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.05),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _cardBorder),
          ),
          child: child,
        ),
      ),
    );
  }
}