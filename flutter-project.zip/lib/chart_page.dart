import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';

import 'trading_models.dart';

// ─── CHART PAGE ──────────────────────────────────────────────────────────
class ChartPage extends StatefulWidget {
  final String sessionKey;
  final String role;
  final VoidCallback? onTradePressed;
  final VoidCallback? onQuotePressed;
  final VoidCallback? onHistoryPressed;

  const ChartPage({
    Key? key,
    required this.sessionKey,
    required this.role,
    this.onTradePressed,
    this.onQuotePressed,
    this.onHistoryPressed,
  }) : super(key: key);

  @override
  State<ChartPage> createState() => _ChartPageState();
}

class _ChartPageState extends State<ChartPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _animController;
  late Timer _updateTimer;

  String selectedSymbol = 'ADAUSD';
  List<CandleData> candleData = [];
  double currentPrice = 0.2130;
  double priceChange = -0.0020;
  double percentChange = -0.93;
  double buyPrice = 0.2022;
  double sellPrice = 0.2027;

  final Map<String, Map<String, double>> symbolData = {
    'ADAUSD': {
      'price': 0.2130,
      'change': -0.0020,
      'percent': -0.93,
      'buy': 0.2022,
      'sell': 0.2027,
      'low': 0.2020,
      'high': 0.2171,
    },
    'AUDCHF': {
      'price': 0.5819,
      'change': 0.0181,
      'percent': 0.31,
      'buy': 0.5795,
      'sell': 0.5820,
      'low': 0.5790,
      'high': 0.5823,
    },
    'AUDJPY': {
      'price': 114.64,
      'change': 0.0000,
      'percent': -0.02,
      'buy': 114.50,
      'sell': 114.65,
      'low': 114.50,
      'high': 114.96,
    },
    'AUDNZD': {
      'price': 1.2110,
      'change': 0.0232,
      'percent': 0.19,
      'buy': 1.2100,
      'sell': 1.2113,
      'low': 1.2072,
      'high': 1.2120,
    },
    'BTCUSD': {
      'price': 77670.00,
      'change': 31900,
      'percent': 0.41,
      'buy': 77500.00,
      'sell': 77697.00,
      'low': 77200.00,
      'high': 77800.00,
    },
  };

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..forward();

    _generateCandleData();
    _startPriceUpdate();
  }

  void _generateCandleData() {
    candleData.clear();
    final basePrice = currentPrice;
    final random = math.Random();

    for (int i = 47; i >= 0; i--) {
      final variation = (random.nextDouble() - 0.5) * 0.002;
      final open = basePrice + (variation * i / 20);
      final close = open + (random.nextDouble() - 0.5) * 0.001;
      final high = math.max(open, close) + random.nextDouble() * 0.0008;
      final low = math.min(open, close) - random.nextDouble() * 0.0008;

      candleData.add(
        CandleData(
          open: open,
          close: close,
          high: high,
          low: low,
          time: DateTime.now().subtract(Duration(minutes: i)),
          volume: random.nextInt(1000000) + 500000,
        ),
      );
    }
  }

  void _startPriceUpdate() {
    _updateTimer = Timer.periodic(Duration(seconds: 2), (_) {
      if (!mounted) return;

      final random = math.Random();
      final variation = (random.nextDouble() - 0.5) * 0.0015;
      setState(() {
        currentPrice = currentPrice + variation;
        priceChange = currentPrice - symbolData[selectedSymbol]!['price']!;
        percentChange = (priceChange / symbolData[selectedSymbol]!['price']!) * 100;

        _animController.forward(from: 0.0);
      });
    });
  }

  void _selectSymbol(String symbol) {
    setState(() {
      selectedSymbol = symbol;
      final data = symbolData[symbol]!;
      currentPrice = data['price']!;
      priceChange = data['change']!;
      percentChange = data['percent']!;
      buyPrice = data['buy']!;
      sellPrice = data['sell']!;
      _generateCandleData();
    });
  }

  @override
  void dispose() {
    _updateTimer.cancel();
    _animController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: TradingTheme.bg,
      body: Column(
        children: [
          // ─── HEADER ───────────────────────────────────
          _buildHeader(),

          // ─── PRICE & CONTROLS ─────────────────────────
          _buildPriceBar(),

          // ─── CANDLESTICK CHART ────────────────────────
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              child: _buildCandleChart(),
            ),
          ),

          // ─── BOTTOM NAV ────────────────────────────────
          _buildBottomNav(),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: TradingTheme.card,
        border: Border(
          bottom: BorderSide(color: TradingTheme.accent.withOpacity(0.25)),
        ),
        boxShadow: [
          BoxShadow(
            color: TradingTheme.accent.withOpacity(0.08),
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: GestureDetector(
              onTap: _showSymbolPicker,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        selectedSymbol,
                        style: const TextStyle(
                          color: TradingTheme.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Astral',
                        ),
                      ),
                      const SizedBox(width: 4),
                      const Icon(Icons.keyboard_arrow_down_rounded,
                          color: TradingTheme.grey, size: 20),
                    ],
                  ),
                  Text(
                    '$selectedSymbol vs Market Price',
                    style: TextStyle(
                      color: TradingTheme.grey,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
          ),
          ScaleTransition(
            scale: Tween<double>(begin: 0.8, end: 1.0).animate(
              CurvedAnimation(parent: _animController, curve: Curves.easeOutBack),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  formatPrice(currentPrice),
                  style: const TextStyle(
                    color: TradingTheme.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'Astral',
                  ),
                ),
                Text(
                  '${percentChange > 0 ? '+' : ''}${percentChange.toStringAsFixed(2)}%',
                  style: TextStyle(
                    color: percentChange > 0 ? TradingTheme.success : TradingTheme.primary,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPriceBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Row(
        children: [
          Expanded(
            child: _buildPriceButton(
              label: 'SELL',
              price: sellPrice,
              color: TradingTheme.primary,
              onTap: () => _showOrderDialog('SELL'),
            ),
          ),
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 8),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: TradingTheme.card,
              border: Border.all(color: TradingTheme.border.withOpacity(0.3)),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Column(
              children: [
                Text(
                  '0.9',
                  style: const TextStyle(
                    color: TradingTheme.grey,
                    fontSize: 12,
                  ),
                ),
                const SizedBox(height: 2),
                const Icon(Icons.unfold_more_rounded, color: TradingTheme.grey, size: 16),
              ],
            ),
          ),
          Expanded(
            child: _buildPriceButton(
              label: 'BUY',
              price: buyPrice,
              color: const Color(0xFF00E676),
              onTap: () => _showOrderDialog('BUY'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPriceButton({
    required String label,
    required double price,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: color.withOpacity(0.15),
          border: Border.all(color: color.withOpacity(0.4)),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Column(
          children: [
            Text(
              label,
              style: TextStyle(
                color: color,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              formatPrice(price),
              style: TextStyle(
                color: color,
                fontSize: 14,
                fontWeight: FontWeight.bold,
                fontFamily: 'Astral',
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCandleChart() {
    return Container(
      decoration: BoxDecoration(
        color: TradingTheme.cardAlt,
        border: Border.all(color: TradingTheme.accent.withOpacity(0.22)),
        borderRadius: BorderRadius.circular(16),
        boxShadow: TradingTheme.neonGlow(TradingTheme.accentDeep),
      ),
      child: Stack(
        children: [
          // Grid background
          CustomPaint(
            painter: _GridPainter(),
            size: Size.infinite,
          ),

          // Candles
          Padding(
            padding: const EdgeInsets.all(16),
            child: CustomPaint(
              painter: _CandleChartPainter(
                candleData,
                animController: _animController,
              ),
              size: Size.infinite,
            ),
          ),

          // Time labels
          Positioned(
            bottom: 8,
            left: 0,
            right: 0,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('21:00', style: TextStyle(color: TradingTheme.grey, fontSize: 10)),
                  Text('28 Aug 07:00', style: TextStyle(color: TradingTheme.grey, fontSize: 10)),
                  Text('28 Aug 16:00', style: TextStyle(color: TradingTheme.grey, fontSize: 10)),
                  Text('29 Aug 00:00', style: TextStyle(color: TradingTheme.grey, fontSize: 10)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomNav() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        color: TradingTheme.card,
        border: Border(
          top: BorderSide(color: TradingTheme.accent.withOpacity(0.2)),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _buildNavButton(
            icon: Icons.compare_arrows_rounded,
            label: 'Trade',
            onTap: widget.onTradePressed ?? () {},
          ),
          _buildNavButton(
            icon: Icons.show_chart_rounded,
            label: 'Chart',
            onTap: () {},
          ),
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                '-${priceChange.abs().toStringAsFixed(2)}',
                style: TextStyle(
                  color: percentChange > 0 ? TradingTheme.success : TradingTheme.primary,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
              Text(
                'USD',
                style: TextStyle(color: TradingTheme.grey, fontSize: 10),
              ),
            ],
          ),
          _buildNavButton(
            icon: Icons.access_time_rounded,
            label: 'Riwayat',
            onTap: widget.onHistoryPressed ?? () {},
          ),
          Stack(
            clipBehavior: Clip.none,
            children: [
              _buildNavButton(
                icon: Icons.notifications_active_rounded,
                label: 'Pesan',
                onTap: () {},
              ),
              Positioned(
                top: -4,
                right: -4,
                child: Container(
                  width: 16,
                  height: 16,
                  decoration: BoxDecoration(
                    color: TradingTheme.primary,
                    shape: BoxShape.circle,
                  ),
                  child: const Center(
                    child: Text(
                      '1',
                      style: TextStyle(
                        color: TradingTheme.white,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildNavButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: TradingTheme.white54, size: 20),
          const SizedBox(height: 2),
          Text(
            label,
            style: TextStyle(color: TradingTheme.grey, fontSize: 10),
          ),
        ],
      ),
    );
  }

  void _showSymbolPicker() {
    showModalBottomSheet(
      context: context,
      backgroundColor: TradingTheme.card,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) => Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        constraints: const BoxConstraints(maxHeight: 400),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              margin: const EdgeInsets.only(bottom: 12),
              decoration: BoxDecoration(
                color: TradingTheme.border,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            Flexible(
              child: ListView(
                shrinkWrap: true,
                children: symbolData.keys.map((symbol) {
                  return ListTile(
                    title: Text(
                      symbol,
                      style: TextStyle(
                        color: symbol == selectedSymbol
                            ? TradingTheme.primary
                            : TradingTheme.white,
                        fontWeight: symbol == selectedSymbol
                            ? FontWeight.bold
                            : FontWeight.normal,
                        fontFamily: 'Astral',
                      ),
                    ),
                    trailing: symbol == selectedSymbol
                        ? const Icon(Icons.check_rounded,
                            color: TradingTheme.primary, size: 18)
                        : null,
                    onTap: () {
                      _selectSymbol(symbol);
                      Navigator.pop(context);
                    },
                  );
                }).toList(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showOrderDialog(String type) {
    showModalBottomSheet(
      context: context,
      backgroundColor: TradingTheme.card,
      builder: (_) => Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Order $type',
              style: const TextStyle(
                color: TradingTheme.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
                fontFamily: 'Astral',
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'Symbol: $selectedSymbol',
              style: const TextStyle(color: TradingTheme.white54),
            ),
            Text(
              'Price: ${formatPrice(type == 'BUY' ? buyPrice : sellPrice)}',
              style: const TextStyle(color: TradingTheme.white54),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              style: ElevatedButton.styleFrom(
                backgroundColor: type == 'BUY' ? const Color(0xFF00E676) : TradingTheme.primary,
              ),
              child: Text('Confirm $type'),
            ),
          ],
        ),
      ),
    );
  }

  String formatPrice(double price) {
    if (price > 1000) {
      return price.toStringAsFixed(2);
    }
    return price.toStringAsFixed(4);
  }
}

// ─── GRID PAINTER ─────────────────────────────────────────────────────
class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = TradingTheme.accent.withOpacity(0.08)
      ..strokeWidth = 0.5;

    // Vertical lines
    final spacing = size.width / 6;
    for (double x = spacing; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }

    // Horizontal lines
    final hSpacing = size.height / 5;
    for (double y = hSpacing; y < size.height; y += hSpacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(_) => false;
}

// ─── CANDLE CHART PAINTER ────────────────────────────────────────────
class _CandleChartPainter extends CustomPainter {
  final List<CandleData> data;
  final AnimationController animController;

  _CandleChartPainter(this.data, {required this.animController}) : super(repaint: animController);

  @override
  void paint(Canvas canvas, Size size) {
    if (data.isEmpty) return;

    final double minPrice = data.map((e) => e.low).reduce(math.min);
    final double maxPrice = data.map((e) => e.high).reduce(math.max);
    final double range = maxPrice - minPrice;

    final candleWidth = (size.width - 20) / data.length;
    final progress = animController.value;

    for (int i = 0; i < data.length; i++) {
      final candle = data[i];
      final x = 10 + i * candleWidth + candleWidth / 2;

      // Normalize prices
      final openY = size.height - ((candle.open - minPrice) / range) * size.height;
      final closeY = size.height - ((candle.close - minPrice) / range) * size.height;
      final highY = size.height - ((candle.high - minPrice) / range) * size.height;
      final lowY = size.height - ((candle.low - minPrice) / range) * size.height;

      // Animate with delay
      final candleProgress = (progress * data.length - i).clamp(0.0, 1.0);

      // Wick
      final wickPaint = Paint()
        ..color = candle.isBullish ? const Color(0xFF00E676) : TradingTheme.primary
        ..strokeWidth = 1;

      canvas.drawLine(Offset(x, highY), Offset(x, lowY), wickPaint);

      // Body
      final bodyPaint = Paint()
        ..color = candle.isBullish ? const Color(0xFF00E676) : TradingTheme.primary;

      final bodyTop = math.min(openY, closeY);
      final bodyHeight = (openY - closeY).abs() * candleProgress;

      if (bodyHeight > 0) {
        canvas.drawRect(
          Rect.fromLTWH(
            x - candleWidth * 0.35,
            bodyTop,
            candleWidth * 0.7,
            bodyHeight,
          ),
          bodyPaint,
        );
      }
    }
  }

  @override
  bool shouldRepaint(_CandleChartPainter old) => true;
}
