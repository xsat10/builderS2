import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class NeoColors {
  NeoColors._();

  // --- Background transparent gelap (untuk glassmorphism romawi) ---
  static const Color background = Color(0xFF0B0D1F);
  static const Color surface = Color(0x1FFFFFFF);
  static const Color surfaceElevated = Color(0xFF1E1E2E);
  static const Color primaryText = Color(0xFFFFFFFF);
  static const Color secondaryText = Color(0xFFB8B8CF);
  static const Color border = Color(0x33FFFFFF);
  static const Color line = Color(0x44FFD98A);

  static const Color cream = Color(0xFFFFF9E8);
  static const Color black = Color(0xFF111111);
  static const Color yellow = Color(0xFFFFD900);
  static const Color pink = Color(0xFFFF5C8A);
  static const Color blue = Color(0xFF5B8CFF);
  static const Color green = Color(0xFF55E878);
  static const Color orange = Color(0xFFFF9F43);
  static const Color purple = Color(0xFF9B6BFF);
  static const Color white = Color(0xFFFFFFFF);
  static const Color grey = Color(0xFF888888);
  static const Color darkBg = Color(0xFF0B0D1F);
  static const Color darkCard = Color(0x22FFFFFF);

  // --- Warna aksen Romawi Kuno ---
  static const Color gold = Color(0xFFFFD98A);
  static const Color goldBright = Color(0xFFF3D98A);
  static const Color goldDeep = Color(0xFFC6A15B);
  static const Color marble = Color(0xFFF2F0E6);
  static const Color royalPurple = Color(0xFF5B3E96);
  static const Color burgundy = Color(0xFF6B1F2A);

  static const Color developer = Color(0xFF9B6BFF);
  static const Color partner = Color(0xFFFF9F43);
  static const Color reseller = Color(0xFF36C5F0);
  static const Color member = Color(0xFFFF6B8A);
  static const Color vip = Color(0xFFFFD700);
  static const Color moderator = Color(0xFF3DD3A5);

  static Color roleColor(String role) {
    switch (role) {
      case 'developer':
        return developer;
      case 'partner':
        return partner;
      case 'reseller':
        return reseller;
      case 'member':
        return member;
      case 'vip':
        return vip;
      case 'moderator':
        return moderator;
      default:
        return grey;
    }
  }

  static const Map<String, IconData> roleIcon = {
    'developer': Icons.code,
    'partner': Icons.handshake,
    'reseller': Icons.storefront,
    'member': Icons.person,
    'vip': Icons.workspace_premium,
    'moderator': Icons.verified_user,
  };

  static const Map<String, String> roleTitle = {
    'developer': 'SUPER ADMIN',
    'partner': 'MERCHANT',
    'reseller': 'AGENT',
    'member': 'USER',
    'vip': 'VIP',
    'moderator': 'MODERATOR',
  };
}

class NeoGlass {
  NeoGlass._();

  static const Color surfaceTint = Color(0x0AFFFFFF);
  static const Color surfaceLight = Color(0x14FFFFFF);
  static const Color surfaceMedium = Color(0x1FFFFFFF);
  static const Color borderSubtle = Color(0x1AFFFFFF);
  static const Color borderGold = Color(0x44FFD98A);
  static const Color borderGoldStrong = Color(0x66FFD98A);
  static const Color highlightTop = Color(0x22FFFFFF);
  static const Color highlightLeft = Color(0x0DFFFFFF);
  static const Color scrim = Color(0x73000000);

  static const double blurSigma = 18;
  static const double blurSigmaHeavy = 28;
  static const double borderWidth = 1.0;
  static const double borderWidthStrong = 1.2;

  static const double radiusSm = 12;
  static const double radiusMd = 16;
  static const double radiusLg = 20;
  static const double radiusXl = 28;

  static ImageFilter get blur =>
      ImageFilter.blur(sigmaX: blurSigma, sigmaY: blurSigma);
  static ImageFilter get blurHeavy =>
      ImageFilter.blur(sigmaX: blurSigmaHeavy, sigmaY: blurSigmaHeavy);

  static BoxDecoration surface({
    BorderRadius? borderRadius,
    Color? tint,
    double? opacity,
  }) {
    return BoxDecoration(
      color: (tint ?? Colors.white).withValues(alpha: opacity ?? 0.06),
      borderRadius: borderRadius ?? BorderRadius.circular(radiusMd),
      border: Border.all(color: borderGold, width: borderWidth),
      boxShadow: const [
        BoxShadow(
          color: Color(0x33000000),
          blurRadius: 24,
          offset: Offset(0, 8),
          spreadRadius: -6,
        ),
      ],
    );
  }

  static BoxDecoration card({BorderRadius? borderRadius}) {
    return BoxDecoration(
      color: surfaceLight,
      borderRadius: borderRadius ?? BorderRadius.circular(radiusMd),
      border: Border.all(color: borderGold, width: borderWidthStrong),
      boxShadow: const [
        BoxShadow(
          color: Color(0x3D000000),
          blurRadius: 28,
          offset: Offset(0, 12),
          spreadRadius: -6,
        ),
      ],
    );
  }

  static BoxDecoration input({bool focused = false}) {
    return BoxDecoration(
      color: surfaceTint,
      borderRadius: BorderRadius.circular(radiusSm),
      border: Border.all(
        color: focused ? NeoColors.gold : borderSubtle,
        width: focused ? borderWidthStrong : borderWidth,
      ),
    );
  }
}

class NeoSpacing {
  NeoSpacing._();
  static const double xs = 4;
  static const double sm = 8;
  static const double md = 12;
  static const double lg = 16;
  static const double xl = 20;
  static const double xxl = 24;
  static const double xxxl = 32;
}

class NeoRadius {
  NeoRadius._();
  static const double sm = 6;
  static const double md = 8;
  static const double lg = 10;
  static const double xl = 12;
  static Border get border => Border.all(color: NeoColors.border, width: 1.2);
  static Border borderColor(Color c) => Border.all(color: c, width: 1.2);
  static Border borderThin(Color c) => Border.all(color: c, width: 1);
}

class NeoShadows {
  NeoShadows._();
  static const List<BoxShadow> sm = [
    BoxShadow(
      color: Color(0x33000000),
      offset: Offset(0, 4),
      blurRadius: 14,
      spreadRadius: -4,
    ),
  ];
  static const List<BoxShadow> md = [
    BoxShadow(
      color: Color(0x3D000000),
      offset: Offset(0, 8),
      blurRadius: 24,
      spreadRadius: -6,
    ),
  ];
  static const List<BoxShadow> lg = [
    BoxShadow(
      color: Color(0x49000000),
      offset: Offset(0, 16),
      blurRadius: 40,
      spreadRadius: -8,
    ),
  ];

  static List<BoxShadow> smD(bool dark) => [
    BoxShadow(
      color: dark ? const Color(0x29000000) : const Color(0x33000000),
      offset: const Offset(0, 4),
      blurRadius: 14,
      spreadRadius: -4,
    ),
  ];
  static List<BoxShadow> mdD(bool dark) => [
    BoxShadow(
      color: dark ? const Color(0x30000000) : const Color(0x3D000000),
      offset: const Offset(0, 8),
      blurRadius: 24,
      spreadRadius: -6,
    ),
  ];
  static List<BoxShadow> lgD(bool dark) => [
    BoxShadow(
      color: dark ? const Color(0x36000000) : const Color(0x49000000),
      offset: const Offset(0, 16),
      blurRadius: 40,
      spreadRadius: -8,
    ),
  ];
}

extension NeoShadowX on List<BoxShadow> {
  List<BoxShadow> forDark(bool dark) => dark ? this : this;
}

class NeoTheme {
  static const double borderWidth = 1.2;
  static const Offset shadowOffset = Offset(0, 8);

  static Border border() =>
      Border.all(color: NeoColors.border, width: borderWidth);
  static Border borderColor(Color c) =>
      Border.all(color: c, width: borderWidth);

  static BoxDecoration cardDecoration({Color bg = NeoColors.white}) {
    return BoxDecoration(
      color: bg.withValues(alpha: 0.15),
      border: Border.all(color: const Color(0x66FFD98A), width: 1.2),
      borderRadius: BorderRadius.circular(xl),
      boxShadow: const [
        BoxShadow(
          color: Color(0x3D000000),
          offset: Offset(0, 12),
          blurRadius: 28,
          spreadRadius: -6,
        ),
      ],
    );
  }

  static BoxDecoration cardDecorationDark({Color bg = NeoColors.darkCard}) {
    return BoxDecoration(
      color: bg,
      border: Border.all(color: const Color(0x44FFD98A), width: 1.2),
      borderRadius: BorderRadius.circular(xl),
      boxShadow: const [
        BoxShadow(
          color: Color(0x3D000000),
          offset: Offset(0, 12),
          blurRadius: 28,
          spreadRadius: -6,
        ),
      ],
    );
  }

  static const double xl = 16;
  static const EdgeInsets screenPadding = EdgeInsets.all(NeoSpacing.lg);

  static ThemeData darkTheme = ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: NeoColors.background,
    colorScheme: const ColorScheme.dark(
      primary: NeoColors.primaryText,
      secondary: NeoColors.gold,
      surface: Color(0xFF14142A),
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      contentTextStyle: const TextStyle(
        fontFamily: 'serif',
        fontSize: 13,
        color: Colors.white,
      ),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ),
    textTheme: GoogleFonts.spaceGroteskTextTheme(ThemeData.dark().textTheme)
        .copyWith(
          displayLarge: const TextStyle(
            fontSize: 36,
            fontWeight: FontWeight.w800,
            color: NeoColors.primaryText,
          ),
          displayMedium: const TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.w800,
            color: NeoColors.primaryText,
          ),
          headlineLarge: const TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.w700,
            color: NeoColors.primaryText,
          ),
          headlineMedium: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w700,
            color: NeoColors.primaryText,
          ),
          bodyLarge: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w500,
            color: NeoColors.primaryText,
          ),
          bodyMedium: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w500,
            color: NeoColors.primaryText,
          ),
          labelLarge: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w700,
            color: NeoColors.primaryText,
          ),
          titleMedium: const TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w700,
            color: NeoColors.secondaryText,
          ),
        ),
  );

  static ThemeData lightTheme = ThemeData(
    useMaterial3: true,
    brightness: Brightness.light,
    scaffoldBackgroundColor: NeoColors.cream,
    colorScheme: const ColorScheme.light(
      primary: NeoColors.black,
      secondary: NeoColors.goldDeep,
      surface: NeoColors.cream,
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      contentTextStyle: const TextStyle(
        fontFamily: 'serif',
        fontSize: 13,
        color: Colors.white,
      ),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ),
    textTheme: GoogleFonts.spaceGroteskTextTheme().copyWith(
      displayLarge: const TextStyle(
        fontSize: 36,
        fontWeight: FontWeight.w800,
        color: NeoColors.black,
      ),
      displayMedium: const TextStyle(
        fontSize: 28,
        fontWeight: FontWeight.w800,
        color: NeoColors.black,
      ),
      headlineLarge: const TextStyle(
        fontSize: 22,
        fontWeight: FontWeight.w700,
        color: NeoColors.black,
      ),
      headlineMedium: const TextStyle(
        fontSize: 18,
        fontWeight: FontWeight.w700,
        color: NeoColors.black,
      ),
      bodyLarge: const TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w500,
        color: NeoColors.black,
      ),
      bodyMedium: const TextStyle(
        fontSize: 14,
        fontWeight: FontWeight.w500,
        color: NeoColors.black,
      ),
      labelLarge: const TextStyle(
        fontSize: 14,
        fontWeight: FontWeight.w700,
        color: NeoColors.black,
      ),
      titleMedium: const TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.w700,
        color: NeoColors.grey,
      ),
    ),
  );
}
