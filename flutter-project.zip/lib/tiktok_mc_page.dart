import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

/// Full TikTok WebView.
///
/// TikTok is more sensitive to embedded-browser fingerprints than ordinary
/// websites, so this page owns its WebView configuration instead of relying
/// on the generic shell.
class TikTokMcPage extends StatefulWidget {
  const TikTokMcPage({super.key});

  @override
  State<TikTokMcPage> createState() => _TikTokMcPageState();
}

class _TikTokMcPageState extends State<TikTokMcPage>
    with SingleTickerProviderStateMixin {
  static const _accent = Color(0xFF25F4EE);
  static const _accentPink = Color(0xFFFE2C55);
  static const _background = Color(0xFF050507);

  // A current desktop Chrome UA avoids the generic Android WebView UA that
  // some large sites serve a reduced/blocked experience to.
  static const _chromeUserAgent =
      'Mozilla/5.0 (Linux; Android 13; Pixel 7) '
      'AppleWebKit/537.36 (KHTML, like Gecko) '
      'Chrome/140.0.0.0 Mobile Safari/537.36';

  late final WebViewController _controller;
  late final AnimationController _pulseController;

  int _progress = 0;
  bool _pageError = false;
  bool _loading = true;
  bool _canGoBack = false;
  bool _canGoForward = false;
  String _url = 'https://www.tiktok.com/';

  @override
  void initState() {
    super.initState();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setUserAgent(_chromeUserAgent)
      ..setBackgroundColor(_background)
      ..enableZoom(false)
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (progress) {
            if (!mounted) return;
            setState(() {
              _progress = progress.clamp(0, 100);
              if (progress > 5) _loading = true;
            });
          },
          onPageStarted: (url) {
            if (!mounted) return;
            setState(() {
              _url = url;
              _progress = 5;
              _loading = true;
              _pageError = false;
            });
          },
          onPageFinished: (url) async {
            final back = await _controller.canGoBack();
            final forward = await _controller.canGoForward();
            if (!mounted) return;

            setState(() {
              _url = url;
              _progress = 100;
              _loading = false;
              _pageError = false;
              _canGoBack = back;
              _canGoForward = forward;
            });
          },
          onNavigationRequest: (request) {
            final uri = Uri.tryParse(request.url);
            if (uri == null) return NavigationDecision.prevent;

            // Keep normal web navigation inside the TikTok WebView. External
            // schemes are not allowed to crash the embedded browser.
            if (uri.scheme == 'http' || uri.scheme == 'https') {
              return NavigationDecision.navigate;
            }
            return NavigationDecision.prevent;
          },
          onWebResourceError: (error) {
            // TikTok loads many auxiliary resources. Only a main-frame
            // failure means that the actual document failed.
            if (error.isForMainFrame != true || !mounted) return;
            setState(() {
              _pageError = true;
              _loading = false;
            });
          },
        ),
      )
      ..loadRequest(Uri.parse(_url));
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  Future<void> _refresh() async {
    if (!mounted) return;
    setState(() {
      _pageError = false;
      _loading = true;
      _progress = 5;
    });
    await _controller.reload();
  }

  Future<void> _home() async {
    if (!mounted) return;
    setState(() {
      _pageError = false;
      _loading = true;
      _progress = 5;
      _url = 'https://www.tiktok.com/';
    });
    await _controller.loadRequest(Uri.parse(_url));
  }

  Future<void> _back() async {
    if (await _controller.canGoBack()) {
      await _controller.goBack();
    }
  }

  Future<void> _forward() async {
    if (await _controller.canGoForward()) {
      await _controller.goForward();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _background,
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            _buildProgress(),
            Expanded(
              child: ClipRRect(
                borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(24),
                ),
                child: _pageError
                    ? _buildError()
                    : WebViewWidget(controller: _controller),
              ),
            ),
            _buildToolbar(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      height: 70,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: const Color(0xFF0D0D12),
        border: Border(
          bottom: BorderSide(color: Colors.white.withOpacity(.07)),
        ),
      ),
      child: Row(
        children: [
          Semantics(
            button: true,
            label: 'Kembali ke tools',
            child: IconButton(
              tooltip: 'Kembali',
              onPressed: () => Navigator.of(context).maybePop(),
              icon: const Icon(Icons.arrow_back_ios_new_rounded),
              color: Colors.white,
            ),
          ),
          const SizedBox(width: 4),
          _buildAnimatedLogo(),
          const SizedBox(width: 11),
          const Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'TikTokMc',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                SizedBox(height: 2),
                Text(
                  'REAL-TIME WEB • FULL VIEW',
                  style: TextStyle(
                    color: Colors.white54,
                    fontSize: 9,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.1,
                  ),
                ),
              ],
            ),
          ),
          _buildLivePill(),
        ],
      ),
    );
  }

  Widget _buildAnimatedLogo() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (context, child) {
        final intensity = .18 + (_pulseController.value * .16);
        return Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _accent.withOpacity(.10),
            border: Border.all(color: _accent.withOpacity(.52)),
            boxShadow: [
              BoxShadow(
                color: _accent.withOpacity(intensity),
                blurRadius: 18,
                spreadRadius: 2,
              ),
              BoxShadow(
                color: _accentPink.withOpacity(intensity * .65),
                blurRadius: 16,
              ),
            ],
          ),
          child: const Icon(
            Icons.music_note_rounded,
            color: Colors.white,
            size: 23,
          ),
        );
      },
    );
  }

  Widget _buildLivePill() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (context, child) {
        final opacity = .65 + (_pulseController.value * .35);
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
          decoration: BoxDecoration(
            color: Colors.greenAccent.withOpacity(.08),
            borderRadius: BorderRadius.circular(999),
            border: Border.all(
              color: Colors.greenAccent.withOpacity(.20),
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Opacity(
                opacity: opacity,
                child: const Icon(
                  Icons.circle,
                  size: 7,
                  color: Colors.greenAccent,
                ),
              ),
              const SizedBox(width: 5),
              const Text(
                'LIVE',
                style: TextStyle(
                  color: Colors.greenAccent,
                  fontSize: 9,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildProgress() {
    if (!_loading || _progress >= 100) {
      return const SizedBox(height: 2);
    }

    return LinearProgressIndicator(
      minHeight: 2,
      value: _progress <= 0 ? null : _progress / 100,
      backgroundColor: Colors.transparent,
      valueColor: const AlwaysStoppedAnimation(_accent),
    );
  }

  Widget _buildToolbar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(8, 7, 8, 9),
      decoration: BoxDecoration(
        color: const Color(0xFF0D0D12),
        border: Border(
          top: BorderSide(color: Colors.white.withOpacity(.07)),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _toolButton(
            icon: Icons.chevron_left_rounded,
            label: 'Back',
            enabled: _canGoBack,
            onTap: _back,
          ),
          _toolButton(
            icon: Icons.chevron_right_rounded,
            label: 'Next',
            enabled: _canGoForward,
            onTap: _forward,
          ),
          _toolButton(
            icon: Icons.home_rounded,
            label: 'Home',
            enabled: true,
            onTap: _home,
          ),
          _toolButton(
            icon: Icons.refresh_rounded,
            label: 'Refresh',
            enabled: true,
            onTap: _refresh,
          ),
        ],
      ),
    );
  }

  Widget _toolButton({
    required IconData icon,
    required String label,
    required bool enabled,
    required Future<void> Function() onTap,
  }) {
    return Semantics(
      button: true,
      enabled: enabled,
      label: label,
      child: IconButton(
        tooltip: label,
        onPressed: enabled ? onTap : null,
        icon: Icon(icon),
        color: enabled ? Colors.white : Colors.white24,
      ),
    );
  }

  Widget _buildError() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF161018),
            Color(0xFF08080D),
            Color(0xFF050507),
          ],
        ),
      ),
      child: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 86,
                height: 86,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _accent.withOpacity(.08),
                  border: Border.all(color: _accent.withOpacity(.28)),
                  boxShadow: [
                    BoxShadow(
                      color: _accent.withOpacity(.14),
                      blurRadius: 30,
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.wifi_tethering_error_rounded,
                  size: 42,
                  color: _accent,
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'TikTok belum merespons',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 22,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 9),
              Text(
                'Halaman utama gagal dimuat. '
                'WebView akan mencoba koneksi ulang tanpa menutup TikTokMc.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white.withOpacity(.58),
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 22),
              FilledButton.icon(
                onPressed: _refresh,
                icon: const Icon(Icons.refresh_rounded),
                label: const Text('Coba lagi'),
                style: FilledButton.styleFrom(
                  backgroundColor: _accentPink,
                  foregroundColor: Colors.white,
                  minimumSize: const Size(155, 50),
                ),
              ),
              const SizedBox(height: 10),
              OutlinedButton.icon(
                onPressed: _home,
                icon: const Icon(Icons.home_rounded),
                label: const Text('Buka TikTok Home'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.white,
                  side: BorderSide(color: Colors.white.withOpacity(.16)),
                  minimumSize: const Size(155, 50),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
