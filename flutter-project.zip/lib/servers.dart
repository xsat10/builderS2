import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:firebase_core/firebase_core.dart';

class Servers {
  Servers._();

  static const String configUrl =
      'https://raw.githubusercontent.com/KairoOfficialkuu1/Voltra/main/Config.json';

  static Map<String, dynamic>? _config;

  static Future<Map<String, dynamic>> loadConfig() async {
    final response = await http.get(Uri.parse(configUrl)).timeout(
      const Duration(seconds: 15),
    );
    if (response.statusCode != 200) {
      throw Exception('Config server HTTP ${response.statusCode}');
    }
    final body = jsonDecode(response.body);
    if (body is! Map<String, dynamic>) {
      throw Exception('Format Config.json tidak valid');
    }
    final baseUrl = body['base_url'];
    if (baseUrl is! String || baseUrl.trim().isEmpty) {
      throw Exception('base_url tidak ditemukan di Config.json');
    }
    _config = body;
    return body;
  }

  static Future<String> loadBaseUrl() async {
    final data = await loadConfig();
    return (data['base_url'] as String).trim().replaceFirst(RegExp(r'/$'), '');
  }

  static FirebaseOptions? firebaseOptionsFrom(Map<String, dynamic> data) {
    final raw = data['firebase'];
    if (raw is! Map) return null;

    String value(String key) => (raw[key] ?? '').toString().trim();
    final apiKey = value('apiKey');
    final appId = value('appId');
    final senderId = value('messagingSenderId');
    final projectId = value('projectId');
    if ([apiKey, appId, senderId, projectId].any((v) => v.isEmpty)) {
      return null;
    }

    final storageBucket = value('storageBucket');
    return FirebaseOptions(
      apiKey: apiKey,
      appId: appId,
      messagingSenderId: senderId,
      projectId: projectId,
      storageBucket: storageBucket.isEmpty ? null : storageBucket,
    );
  }
}
