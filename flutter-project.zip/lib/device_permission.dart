import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// ─── BASE URL ──────────────────────────────────────────────────────────────
const String _kBase = 'http://shinoa-cpanelpanel.xtxintax.my.id:2003';

// ─── THEME ──────────────────────────────────────────────────────────────────
class _Theme {
  static const bgStart = Color(0xFF080A1A);
  static const bgEnd = Color(0xFF121828);
  static const card = Color(0xFF1A2038);
  static const cardLight = Color(0xFF252D4A);
  static const border = Color(0xFF2A3355);
  static const glass = Color(0x1AFFFFFF);
  static const shadow = Color(0x40000000);

  static const primary = Color(0xFF6C63FF);
  static const primaryLight = Color(0xFF8B83FF);
  static const secondary = Color(0xFF00D4FF);
  static const success = Color(0xFF00E676);
  static const warning = Color(0xFFFFC107);
  static const error = Color(0xFFFF5252);
  static const purple = Color(0xFFB388FF);
  static const cyan = Color(0xFF00E5FF);
  static const orange = Color(0xFFFF6D00);

  static const text = Color(0xFFF0F0F5);
  static const textSub = Color(0xFF8A92B5);
  static const textDim = Color(0xFF50587A);
}

// ─── PERMISSION STORE ──────────────────────────────────────────────────────
class DevicePermissionStore {
  static Future<PermissionResult> getFor(String username, String sessionKey) async {
    if (username.toLowerCase() == 'owner') {
      return PermissionResult(approved: true, allDevices: true, devices: []);
    }
    try {
      final res = await http.get(
        Uri.parse('$_kBase/devicePerms?key=$sessionKey&username=${Uri.encodeComponent(username)}'),
      ).timeout(const Duration(seconds: 8));
      if (res.statusCode == 200) {
        final d = jsonDecode(res.body);
        if (d['valid'] == true) {
          return PermissionResult(
            approved: d['approved'] == true,
            allDevices: d['allDevices'] == true,
            devices: List<String>.from(d['devices'] ?? []),
          );
        }
      }
    } catch (e) {
      debugPrint('[DevicePerm] getFor error: $e');
    }
    return PermissionResult(approved: false, allDevices: false, devices: []);
  }

  static Future<bool> setPerm(String ownerKey, String username,
      {required bool approved, required bool allDevices, required List<String> devices}) async {
    try {
      final res = await http.post(
        Uri.parse('$_kBase/setDevicePerm?key=$ownerKey'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'username': username,
          'approved': approved,
          'allDevices': allDevices,
          'devices': devices,
        }),
      ).timeout(const Duration(seconds: 8));
      final d = jsonDecode(res.body);
      return d['valid'] == true;
    } catch (e) {
      debugPrint('[DevicePerm] setPerm error: $e');
      return false;
    }
  }

  static Future<bool> removePerm(String ownerKey, String username) async {
    return setPerm(ownerKey, username,
        approved: false, allDevices: false, devices: []);
  }

  static Future<Map<String, dynamic>> getAll(String ownerKey) async {
    try {
      final res = await http.get(
        Uri.parse('$_kBase/listDevicePerms?key=$ownerKey'),
      ).timeout(const Duration(seconds: 8));
      if (res.statusCode == 200) {
        final d = jsonDecode(res.body);
        if (d['valid'] == true) return Map<String, dynamic>.from(d['perms'] ?? {});
      }
    } catch (e) {
      debugPrint('[DevicePerm] getAll error: $e');
    }
    return {};
  }
}

class PermissionResult {
  final bool approved, allDevices;
  final List<String> devices;
  PermissionResult({required this.approved, required this.allDevices, required this.devices});
  bool canSee(String? deviceId) {
    if (!approved) return false;
    if (allDevices) return true;
    return deviceId != null && devices.contains(deviceId);
  }
}

// ─── PERMISSION MANAGER PAGE ─────────────────────────────────────────────
class DevicePermissionManagerPage extends StatefulWidget {
  final String sessionKey;
  final List<dynamic> allDevices;
  const DevicePermissionManagerPage({
    super.key,
    required this.sessionKey,
    required this.allDevices,
  });
  @override
  State<DevicePermissionManagerPage> createState() => _DPMState();
}

class _DPMState extends State<DevicePermissionManagerPage>
    with SingleTickerProviderStateMixin {
  Map<String, dynamic> _perms = {};
  String _selectedUser = '';
  final _inputCtrl = TextEditingController();
  String _inputVal = '';
  bool _loading = true;
  bool _saving = false;
  late AnimationController _animController;

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _animController.forward();
    _load();
  }

  @override
  void dispose() {
    _inputCtrl.dispose();
    _animController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final data = await DevicePermissionStore.getAll(widget.sessionKey);
    if (mounted) {
      setState(() {
        _perms = data;
        _loading = false;
      });
      _animController.reset();
      _animController.forward();
    }
  }

  List<String> get _users => _perms.keys.toList();
  bool _approved(String u) => _perms[u]?['approved'] == true;
  bool _hasAll(String u) => _perms[u]?['allDevices'] == true;
  List<String> _devices(String u) => List<String>.from(_perms[u]?['devices'] ?? []);

  Future<void> _addUser(String username) async {
    if (username.trim().isEmpty) return;
    final key = username.trim().toLowerCase();
    final ok = await DevicePermissionStore.setPerm(
      widget.sessionKey, key,
      approved: true, allDevices: true, devices: [],
    );
    if (ok) {
      await _load();
      setState(() {
        _selectedUser = key;
        _inputVal = '';
        _inputCtrl.clear();
      });
    }
  }

  Future<void> _update(String u,
      {bool? approved, bool? allDevices, List<String>? devices}) async {
    setState(() => _saving = true);
    final ok = await DevicePermissionStore.setPerm(
      widget.sessionKey, u,
      approved: approved ?? _approved(u),
      allDevices: allDevices ?? _hasAll(u),
      devices: devices ?? _devices(u),
    );
    if (ok) await _load();
    setState(() => _saving = false);
  }

  void _showSnackBar(String msg, Color color, {IconData icon = Icons.info}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(icon, color: Colors.white, size: 18),
            const SizedBox(width: 10),
            Expanded(child: Text(msg, style: const TextStyle(color: Colors.white))),
          ],
        ),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  // ─── BUILD ────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _Theme.bgStart,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [_Theme.bgStart, _Theme.bgEnd],
          ),
        ),
        child: SafeArea(
          child: FadeTransition(
            opacity: _animController,
            child: Column(
              children: [
                _buildAppBar(),
                _buildAddUserRow(),
                Expanded(
                  child: _loading
                      ? _buildLoadingState()
                      : _users.isEmpty
                          ? _buildEmptyState()
                          : _buildContent(),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ─── APP BAR ──────────────────────────────────────────────────────────────
  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
      decoration: BoxDecoration(
        color: _Theme.card.withOpacity(0.8),
        border: Border(bottom: BorderSide(color: _Theme.border, width: 0.5)),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: _Theme.cardLight.withOpacity(0.3),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(Icons.arrow_back_ios_new_rounded,
                  color: _Theme.text, size: 18),
            ),
          ),
          const SizedBox(width: 12),
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [_Theme.primary, _Theme.secondary],
              ),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(Icons.manage_accounts_rounded,
                color: Colors.white, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'ACCESS MANAGEMENT',
                  style: TextStyle(
                    color: _Theme.text,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.8,
                  ),
                ),
                Text(
                  '${_users.length} users have access',
                  style: const TextStyle(color: _Theme.textSub, fontSize: 11),
                ),
              ],
            ),
          ),
          if (_saving)
            const SizedBox(
              width: 20,
              height: 20,
              child: CircularProgressIndicator(
                color: _Theme.primary,
                strokeWidth: 2,
              ),
            ),
        ],
      ),
    );
  }

  // ─── ADD USER ROW ────────────────────────────────────────────────────────
  Widget _buildAddUserRow() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: _Theme.card.withOpacity(0.6),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: _Theme.border, width: 0.5),
              ),
              child: TextField(
                controller: _inputCtrl,
                onChanged: (v) => setState(() => _inputVal = v),
                style: const TextStyle(color: _Theme.text, fontSize: 14),
                decoration: InputDecoration(
                  hintText: 'Enter username...',
                  hintStyle: const TextStyle(color: _Theme.textDim, fontSize: 13),
                  prefixIcon: const Icon(Icons.person_add_rounded,
                      color: _Theme.primary, size: 20),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(vertical: 12),
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          GestureDetector(
            onTap: () => _addUser(_inputVal),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [_Theme.primary, _Theme.primaryLight],
                ),
                borderRadius: BorderRadius.circular(14),
                boxShadow: [
                  BoxShadow(
                    color: _Theme.primary.withOpacity(0.3),
                    blurRadius: 12,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: Row(
                children: const [
                  Icon(Icons.add_rounded, color: Colors.white, size: 18),
                  SizedBox(width: 4),
                  Text(
                    'Add',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── LOADING ──────────────────────────────────────────────────────────────
  Widget _buildLoadingState() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: 36,
            height: 36,
            child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation(_Theme.primary),
              strokeWidth: 2.5,
            ),
          ),
          const SizedBox(height: 14),
          Text(
            'Loading permissions...',
            style: TextStyle(color: _Theme.textDim, fontSize: 12),
          ),
        ],
      ),
    );
  }

  // ─── EMPTY STATE ──────────────────────────────────────────────────────────
  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: _Theme.card.withOpacity(0.3),
              shape: BoxShape.circle,
              border: Border.all(color: _Theme.border),
            ),
            child: const Icon(Icons.group_off_rounded,
                color: _Theme.textDim, size: 48),
          ),
          const SizedBox(height: 20),
          const Text(
            'No Users Added',
            style: TextStyle(
              color: _Theme.text,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 6),
          const Text(
            'Type a username above to grant access',
            style: TextStyle(color: _Theme.textSub, fontSize: 12),
          ),
        ],
      ),
    );
  }

  // ─── CONTENT ──────────────────────────────────────────────────────────────
  Widget _buildContent() {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'SELECT USER',
            style: TextStyle(
              color: _Theme.textDim,
              fontSize: 10,
              fontWeight: FontWeight.bold,
              letterSpacing: 1.2,
            ),
          ),
          const SizedBox(height: 8),
          _buildUserChips(),
          const SizedBox(height: 16),
          if (_selectedUser.isNotEmpty) _buildUserDetail(),
        ],
      ),
    );
  }

  // ─── USER CHIPS ──────────────────────────────────────────────────────────
  Widget _buildUserChips() {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: _users.map((u) {
        final active = u == _selectedUser;
        final appr = _approved(u);
        return GestureDetector(
          onTap: () => setState(() => _selectedUser = u),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              color: active ? _Theme.primary : _Theme.card,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: active
                    ? _Theme.primaryLight
                    : (appr ? _Theme.success.withOpacity(0.2) : _Theme.border),
                width: active ? 1.5 : 0.8,
              ),
              boxShadow: active
                  ? [BoxShadow(color: _Theme.primary.withOpacity(0.2), blurRadius: 8)]
                  : null,
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 6,
                  height: 6,
                  decoration: BoxDecoration(
                    color: appr ? _Theme.success : _Theme.error,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  u,
                  style: TextStyle(
                    color: active ? Colors.white : _Theme.text,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }

  // ─── USER DETAIL ─────────────────────────────────────────────────────────
  Widget _buildUserDetail() {
    final u = _selectedUser;
    final approved = _approved(u);
    final hasAll = _hasAll(u);
    final deviceList = _devices(u);

    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _Theme.card.withOpacity(0.6),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _Theme.border, width: 0.5),
        boxShadow: [
          BoxShadow(
            color: _Theme.shadow,
            blurRadius: 12,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: _Theme.primary.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(
                  Icons.person_rounded,
                  color: _Theme.primaryLight,
                  size: 18,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  u,
                  style: const TextStyle(
                    color: _Theme.text,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              GestureDetector(
                onTap: () async {
                  await DevicePermissionStore.removePerm(widget.sessionKey, u);
                  setState(() => _selectedUser = '');
                  await _load();
                  _showSnackBar('User removed', _Theme.error, icon: Icons.delete);
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: _Theme.error.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _Theme.error.withOpacity(0.2)),
                  ),
                  child: Row(
                    children: const [
                      Icon(Icons.delete_outline, color: _Theme.error, size: 14),
                      SizedBox(width: 4),
                      Text(
                        'Remove',
                        style: TextStyle(color: _Theme.error, fontSize: 11),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const Divider(color: _Theme.border, height: 24),
          // Toggle Access
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Access Permission',
                    style: TextStyle(color: _Theme.text, fontSize: 14, fontWeight: FontWeight.w600),
                  ),
                  Text(
                    approved ? 'User can access devices' : 'Access denied',
                    style: TextStyle(
                      color: approved ? _Theme.success : _Theme.error,
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
              Switch(
                value: approved,
                activeColor: _Theme.success,
                inactiveTrackColor: _Theme.border,
                onChanged: (v) => _update(u, approved: v),
              ),
            ],
          ),
          if (approved) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _Theme.cardLight.withOpacity(0.3),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _Theme.border, width: 0.3),
              ),
              child: Row(
                children: [
                  Icon(
                    hasAll ? Icons.check_circle : Icons.list_alt,
                    color: hasAll ? _Theme.success : _Theme.primary,
                    size: 18,
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      hasAll
                          ? 'All devices are accessible'
                          : 'Select specific devices below',
                      style: TextStyle(
                        color: hasAll ? _Theme.success : _Theme.textSub,
                        fontSize: 12,
                      ),
                    ),
                  ),
                  Switch(
                    value: hasAll,
                    activeColor: _Theme.primary,
                    inactiveTrackColor: _Theme.border,
                    onChanged: (v) => _update(u, allDevices: v),
                  ),
                ],
              ),
            ),
            if (!hasAll) ...[
              const SizedBox(height: 16),
              const Text(
                'SELECT DEVICES',
                style: TextStyle(
                  color: _Theme.textDim,
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.2,
                ),
              ),
              const SizedBox(height: 8),
              if (widget.allDevices.isEmpty)
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: _Theme.cardLight.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Center(
                    child: Text(
                      'No devices available',
                      style: TextStyle(color: _Theme.textDim, fontSize: 12),
                    ),
                  ),
                )
              else
                ...widget.allDevices.map((d) {
                  final id = d['id']?.toString() ?? '';
                  final model = d['model']?.toString() ?? 'Unknown';
                  final ip = d['ip']?.toString() ?? '-';
                  final allowed = deviceList.contains(id);
                  return Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                    decoration: BoxDecoration(
                      color: allowed ? _Theme.primary.withOpacity(0.05) : _Theme.cardLight.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: allowed ? _Theme.primary.withOpacity(0.3) : _Theme.border,
                        width: 0.5,
                      ),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          Icons.phone_android_rounded,
                          color: allowed ? _Theme.primaryLight : _Theme.textDim,
                          size: 16,
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                model,
                                style: TextStyle(
                                  color: allowed ? _Theme.text : _Theme.textSub,
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              Text(
                                'ID: $id  •  IP: $ip',
                                style: const TextStyle(
                                  color: _Theme.textDim,
                                  fontSize: 10,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Checkbox(
                          value: allowed,
                          activeColor: _Theme.primary,
                          checkColor: Colors.white,
                          side: const BorderSide(color: _Theme.border),
                          onChanged: (v) async {
                            final cur = List<String>.from(deviceList);
                            if (v == true) {
                              if (!cur.contains(id)) cur.add(id);
                            } else {
                              cur.remove(id);
                            }
                            await _update(u, devices: cur);
                          },
                        ),
                      ],
                    ),
                  );
                }).toList(),
            ],
          ],
        ],
      ),
    );
  }
}