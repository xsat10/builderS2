import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:http/http.dart' as http;

// ───────────────────────────────────────────────────────────────────────────
// Global audio player — satu instance dipakai di seluruh app supaya musik
// tetap jalan walau user pindah halaman. Sengaja TIDAK di-dispose saat
// MusicPage ditutup, biar mini player bisa persist.
// ───────────────────────────────────────────────────────────────────────────
class GlobalMusicPlayer {
  static final AudioPlayer player = AudioPlayer();
  static Map<String, dynamic>? currentTrack;
  static bool isPlaying = false;
  static String? currentAudioUrl;
}

// ───────────────────────────────────────────────────────────────────────────
// "Library" lokal: favorit + profil ringan, disimpan in-memory selama
// sesi app berjalan. Kalau nanti mau tetap tersimpan setelah app ditutup
// total, tinggal sambungkan ke shared_preferences.
// ───────────────────────────────────────────────────────────────────────────
class MusicLibrary {
  static final List<Map<String, dynamic>> favorites = [];
  static String profileName = 'Music Lover';
  static int avatarColorIndex = 0;
  static int totalPlayed = 0;

  static String _key(Map<String, dynamic> track) =>
      (track['url'] ?? track['title'] ?? '').toString();

  static bool isFavorite(Map<String, dynamic> track) {
    final key = _key(track);
    if (key.isEmpty) return false;
    return favorites.any((t) => _key(t) == key);
  }

  static void toggleFavorite(Map<String, dynamic> track) {
    final key = _key(track);
    if (key.isEmpty) return;
    final idx = favorites.indexWhere((t) => _key(t) == key);
    if (idx >= 0) {
      favorites.removeAt(idx);
    } else {
      favorites.insert(0, Map<String, dynamic>.from(track));
    }
  }
}

// ─── Palette: Music Bmw (dasar hitam ala Spotify + aksen M-stripe) ─────────
class _Bmw {
  static const bg      = Color(0xFF0A0A0A);
  static const surface = Color(0xFF141414);
  static const card    = Color(0xFF1C1C1C);
  static const cardAlt = Color(0xFF212121);
  static const border  = Color(0xFF2A2A2A);

  static const white   = Color(0xFFFFFFFF);
  static const grey    = Color(0xFFB3B3B3);
  static const greyDim = Color(0xFF6B6B6B);

  static const green   = Color(0xFF1ED760); // aksen utama ala Spotify

  // trio garis khas BMW M — dipakai tipis-tipis sebagai aksen
  static const mBlue   = Color(0xFF1C69D4);
  static const mPurple = Color(0xFF9336B4);
  static const mRed    = Color(0xFFE4002B);

  static const List<Color> avatarColors = [green, mBlue, mPurple, mRed];
}

// ─── Background kotak-kotak hitam putih (halus, ala checkered flag) ────────
class _CheckerBackground extends StatelessWidget {
  const _CheckerBackground();

  @override
  Widget build(BuildContext context) {
    return const Positioned.fill(
      child: RepaintBoundary(child: CustomPaint(painter: _CheckerPainter())),
    );
  }
}

class _CheckerPainter extends CustomPainter {
  const _CheckerPainter();

  @override
  void paint(Canvas canvas, Size size) {
    const cell = 26.0;
    final square = Paint()..color = Colors.white.withOpacity(0.035);
    final cols = (size.width / cell).ceil();
    final rows = (size.height / cell).ceil();
    for (int r = 0; r < rows; r++) {
      for (int c = 0; c < cols; c++) {
        if ((r + c).isEven) {
          canvas.drawRect(
            Rect.fromLTWH(c * cell, r * cell, cell, cell),
            square,
          );
        }
      }
    }
    final fade = Paint()
      ..shader = LinearGradient(
        colors: [
          _Bmw.bg.withOpacity(0.0),
          _Bmw.bg.withOpacity(0.85),
          _Bmw.bg,
        ],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), fade);
  }

  @override
  bool shouldRepaint(covariant _CheckerPainter oldDelegate) => false;
}

// ─── Nav item helper (biar nggak pakai record, aman untuk SDK lama) ────────
class _NavItem {
  final IconData icon;
  final String label;
  const _NavItem(this.icon, this.label);
}

const _navItems = [
  _NavItem(Icons.search_rounded, 'Search'),
  _NavItem(Icons.favorite_rounded, 'Favorites'),
  _NavItem(Icons.person_rounded, 'Profile'),
];

// ═════════════════════════════════════════════════════════════════════════
// MUSIC PAGE
// ═════════════════════════════════════════════════════════════════════════
class MusicPage extends StatefulWidget {
  const MusicPage({super.key});
  @override
  State<MusicPage> createState() => _MusicPageState();
}

class _MusicPageState extends State<MusicPage> {
  final TextEditingController _queryController = TextEditingController();
  bool _isLoading = false;
  String? _error;
  List<Map<String, dynamic>> _searchResults = [];
  Duration _duration = Duration.zero;
  Duration _position = Duration.zero;

  int _tabIndex = 0; // 0 = Search, 1 = Favorites, 2 = Profile
  final Set<String> _downloadingKeys = {};

  List<Map<String, dynamic>> _activeList = [];
  int _activeIndex = -1;

  @override
  void initState() {
    super.initState();
    _initAudioPlayer();
  }

  void _initAudioPlayer() {
    GlobalMusicPlayer.player.positionStream.listen((p) {
      if (mounted) setState(() => _position = p);
    });
    GlobalMusicPlayer.player.durationStream.listen((d) {
      if (mounted) setState(() => _duration = d ?? Duration.zero);
    });
    GlobalMusicPlayer.player.playerStateStream.listen((state) {
      if (mounted) setState(() => GlobalMusicPlayer.isPlaying = state.playing);
    });
  }

  // ── Networking (logika sama seperti sebelumnya, tetap dipertahankan) ──
  Future<List<Map<String, dynamic>>> searchYouTube(String query) async {
    try {
      final res = await http.get(Uri.parse(
          "https://api.nekolabs.web.id/discovery/youtube/search?q=$query"));
      if (res.statusCode != 200) return [];
      final body = jsonDecode(res.body);
      final List list = body["result"] ?? [];
      return list
          .map<Map<String, dynamic>>((e) => {
                "title": e["title"] ?? "Unknown Title",
                "url": e["url"] ?? "",
                "channel": e["channel"] ?? "Unknown Channel",
                "thumbnail": e["thumbnail"] ??
                    "https://img.youtube.com/vi/${_extractVideoId(e["url"] ?? "")}/0.jpg"
              })
          .toList();
    } catch (e) {
      return [];
    }
  }

  String? _extractVideoId(String url) {
    final regExp = RegExp(
        r'(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]{11})');
    final match = regExp.firstMatch(url);
    return match?.group(1);
  }

  Future<Map<String, dynamic>> _getMusicInfo(String query) async {
    try {
      final encodedQuery = Uri.encodeComponent(query);
      final api =
          "https://api.nekolabs.web.id/downloader/youtube/play/v1?q=$encodedQuery";
      final res = await http
          .get(Uri.parse(api))
          .timeout(const Duration(seconds: 15));
      if (res.statusCode != 200) {
        throw Exception("API request failed with status ${res.statusCode}");
      }
      final body = jsonDecode(res.body);
      if (body["success"] != true) {
        throw Exception("API returned unsuccessful response");
      }
      final result = body["result"];
      if (result == null) throw Exception("No result in API response");
      final metadata = result["metadata"] ?? {};
      final downloadUrl = result["downloadUrl"] ?? "";
      if (downloadUrl.isEmpty) {
        throw Exception("No download URL found in response");
      }
      return {
        "title": metadata["title"] ?? "Unknown Title",
        "channel": metadata["channel"] ?? "Unknown Channel",
        "duration": metadata["duration"] ?? "0:00",
        "cover": metadata["cover"] ?? "",
        "url": metadata["url"] ?? "",
        "downloadUrl": downloadUrl,
      };
    } catch (e) {
      throw Exception("Failed to get music info: ${e.toString()}");
    }
  }

  Future<void> _fetchMusic() async {
    final q = _queryController.text.trim();
    if (q.isEmpty) return;

    setState(() {
      _isLoading = true;
      _error = null;
      _searchResults = [];
    });

    try {
      if (q.startsWith("http")) {
        final videoId = _extractVideoId(q);
        if (videoId != null) {
          try {
            final musicInfo = await _getMusicInfo(q);
            _searchResults = [
              {
                "title": musicInfo["title"],
                "url": musicInfo["url"],
                "channel": musicInfo["channel"],
                "thumbnail": musicInfo["cover"],
                "duration": musicInfo["duration"],
                "downloadUrl": musicInfo["downloadUrl"],
              }
            ];
          } catch (_) {
            _searchResults = await searchYouTube(q);
          }
        } else {
          _searchResults = await searchYouTube(q);
        }
      } else {
        try {
          final musicInfo = await _getMusicInfo(q);
          _searchResults = [
            {
              "title": musicInfo["title"],
              "url": musicInfo["url"],
              "channel": musicInfo["channel"],
              "thumbnail": musicInfo["cover"],
              "duration": musicInfo["duration"],
              "downloadUrl": musicInfo["downloadUrl"],
            }
          ];
        } catch (_) {
          _searchResults = await searchYouTube(q);
        }
      }

      if (_searchResults.isEmpty) _error = "No results found";
    } catch (e) {
      _error = "Search failed: ${e.toString()}";
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _playMusic(
    Map<String, dynamic> track, {
    List<Map<String, dynamic>>? fromList,
    int? indexInList,
  }) async {
    try {
      setState(() {
        _isLoading = true;
        _error = null;
      });

      String audioUrl;
      if (track['downloadUrl'] != null &&
          track['downloadUrl'].toString().isNotEmpty) {
        audioUrl = track['downloadUrl'].toString();
      } else {
        final musicInfo = await _getMusicInfo(track['title'].toString());
        audioUrl = musicInfo['downloadUrl'].toString();
        track['downloadUrl'] = audioUrl;
      }

      await GlobalMusicPlayer.player.stop();
      await GlobalMusicPlayer.player
          .setAudioSource(ProgressiveAudioSource(Uri.parse(audioUrl)));
      GlobalMusicPlayer.currentTrack = track;
      GlobalMusicPlayer.currentAudioUrl = audioUrl;
      await GlobalMusicPlayer.player.play();
      MusicLibrary.totalPlayed++;

      if (fromList != null) {
        _activeList = fromList;
        _activeIndex = indexInList ?? fromList.indexOf(track);
      }

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("Now playing: ${track['title']}"),
        backgroundColor: _Bmw.cardAlt,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
      ));
    } catch (e) {
      setState(() => _error = "Playback failed: ${e.toString()}");
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _playNext() async {
    if (_activeList.isEmpty || _activeIndex < 0) return;
    final next = _activeIndex + 1;
    if (next < _activeList.length) {
      await _playMusic(_activeList[next], fromList: _activeList, indexInList: next);
    }
  }

  Future<void> _playPrevious() async {
    if (_activeList.isEmpty || _activeIndex < 0) return;
    final prev = _activeIndex - 1;
    if (prev >= 0) {
      await _playMusic(_activeList[prev], fromList: _activeList, indexInList: prev);
    }
  }

  Future<void> _togglePlayPause() async {
    if (GlobalMusicPlayer.isPlaying) {
      await GlobalMusicPlayer.player.pause();
    } else if (GlobalMusicPlayer.currentTrack != null) {
      await GlobalMusicPlayer.player.play();
    }
  }

  Future<void> _downloadMusic(Map<String, dynamic> track) async {
    final key = (track['url'] ?? track['title'] ?? '').toString();
    setState(() => _downloadingKeys.add(key));
    try {
      String audioUrl;
      if (track['downloadUrl'] != null &&
          track['downloadUrl'].toString().isNotEmpty) {
        audioUrl = track['downloadUrl'].toString();
      } else {
        final musicInfo = await _getMusicInfo(track['title'].toString());
        audioUrl = musicInfo['downloadUrl'].toString();
      }

      final response = await http.get(Uri.parse(audioUrl));
      if (response.statusCode != 200) throw "Download failed";

      final dir = await getExternalStorageDirectory();
      final name =
          "${track['title']?.toString().replaceAll(RegExp(r'[\\/:*?"<>|]'), '_') ?? 'track'}.mp3";
      final file = File("${dir!.path}/$name");
      await file.writeAsBytes(response.bodyBytes);

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("Downloaded: $name"),
        backgroundColor: _Bmw.green,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 3),
      ));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("Download failed: ${e.toString()}"),
        backgroundColor: _Bmw.mRed,
        behavior: SnackBarBehavior.floating,
      ));
    } finally {
      if (mounted) setState(() => _downloadingKeys.remove(key));
    }
  }

  void _renameProfile() {
    final ctrl = TextEditingController(text: MusicLibrary.profileName);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: _Bmw.card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Edit Name', style: TextStyle(color: _Bmw.white)),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          style: const TextStyle(color: _Bmw.white),
          decoration: InputDecoration(
            filled: true,
            fillColor: _Bmw.surface,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide.none,
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel', style: TextStyle(color: _Bmw.grey)),
          ),
          TextButton(
            onPressed: () {
              setState(() {
                MusicLibrary.profileName =
                    ctrl.text.trim().isEmpty ? 'Music Lover' : ctrl.text.trim();
              });
              Navigator.pop(ctx);
            },
            child: const Text('Save', style: TextStyle(color: _Bmw.green)),
          ),
        ],
      ),
    );
  }

  void _openFullPlayer() {
    if (GlobalMusicPlayer.currentTrack == null) return;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _FullPlayerSheet(
        onFavoriteToggle: () {
          setState(() => MusicLibrary.toggleFavorite(GlobalMusicPlayer.currentTrack!));
        },
        onDownload: () => _downloadMusic(GlobalMusicPlayer.currentTrack!),
        onNext: _playNext,
        onPrevious: _playPrevious,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _Bmw.bg,
      body: Stack(
        children: [
          const _CheckerBackground(),
          SafeArea(
            child: Column(
              children: [
                _buildHeader(),
                if (_error != null) _buildErrorBanner(),
                Expanded(child: _buildBody()),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: _buildBottomArea(),
    );
  }

  Widget _buildHeader() {
    const titles = ['Music Bmw', 'Favorites', 'Profile'];
    final subtitles = [
      'Search & stream musik favoritmu',
      '${MusicLibrary.favorites.length} lagu tersimpan',
      'Akun & pengaturan kamu',
    ];
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 8),
      child: Row(
        children: [
          Container(
            width: 4,
            height: 32,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [_Bmw.mBlue, _Bmw.mPurple, _Bmw.mRed],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
              borderRadius: BorderRadius.circular(3),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(titles[_tabIndex],
                    style: const TextStyle(
                        color: _Bmw.white, fontSize: 22, fontWeight: FontWeight.w800)),
                Text(subtitles[_tabIndex],
                    style: const TextStyle(color: _Bmw.grey, fontSize: 12)),
              ],
            ),
          ),
          Icon(Icons.graphic_eq_rounded, color: _Bmw.green.withOpacity(0.8), size: 26),
        ],
      ),
    );
  }

  Widget _buildErrorBanner() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 4, 16, 0),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _Bmw.mRed.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _Bmw.mRed.withOpacity(0.4)),
      ),
      child: Row(children: [
        const Icon(Icons.error_outline_rounded, color: _Bmw.mRed, size: 18),
        const SizedBox(width: 10),
        Expanded(
          child: Text(_error ?? '', style: const TextStyle(color: _Bmw.white, fontSize: 12.5)),
        ),
        IconButton(
          icon: const Icon(Icons.close_rounded, color: _Bmw.grey, size: 16),
          onPressed: () => setState(() => _error = null),
          padding: EdgeInsets.zero,
          constraints: const BoxConstraints(),
        ),
      ]),
    );
  }

  Widget _buildBody() {
    switch (_tabIndex) {
      case 1:
        return _buildFavoritesTab();
      case 2:
        return _buildProfileTab();
      default:
        return _buildSearchTab();
    }
  }

  Widget _buildSearchTab() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
          child: Container(
            decoration: BoxDecoration(
              color: _Bmw.card,
              borderRadius: BorderRadius.circular(26),
              border: Border.all(color: _Bmw.border),
            ),
            child: Row(children: [
              const SizedBox(width: 10),
              const Icon(Icons.search_rounded, color: _Bmw.grey, size: 20),
              Expanded(
                child: TextField(
                  controller: _queryController,
                  style: const TextStyle(color: _Bmw.white, fontSize: 14.5),
                  decoration: const InputDecoration(
                    hintText: 'Cari lagu, artis, atau tempel link YouTube...',
                    hintStyle: TextStyle(color: _Bmw.greyDim, fontSize: 13),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 14),
                  ),
                  onSubmitted: (_) => _fetchMusic(),
                ),
              ),
              Container(
                margin: const EdgeInsets.all(5),
                decoration: const BoxDecoration(color: _Bmw.green, shape: BoxShape.circle),
                child: IconButton(
                  icon: _isLoading
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black),
                        )
                      : const Icon(Icons.arrow_forward_rounded, color: Colors.black, size: 18),
                  onPressed: _fetchMusic,
                ),
              ),
            ]),
          ),
        ),
        Expanded(
          child: _isLoading && _searchResults.isEmpty
              ? const Center(child: CircularProgressIndicator(color: _Bmw.green))
              : _searchResults.isEmpty
                  ? _buildEmptyState(
                      Icons.graphic_eq_rounded,
                      'Cari musik favoritmu',
                      'Ketik judul lagu, nama artis, atau tempel link YouTube',
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.only(top: 8, bottom: 110),
                      itemCount: _searchResults.length,
                      itemBuilder: (ctx, i) {
                        final track = _searchResults[i];
                        final key = (track['url'] ?? track['title'] ?? '').toString();
                        final activeKey = (GlobalMusicPlayer.currentTrack?['url'] ??
                                GlobalMusicPlayer.currentTrack?['title'] ??
                                '')
                            .toString();
                        return _TrackTile(
                          track: track,
                          isDownloading: _downloadingKeys.contains(key),
                          isFavorite: MusicLibrary.isFavorite(track),
                          isActive: key.isNotEmpty && key == activeKey,
                          onTap: () =>
                              _playMusic(track, fromList: _searchResults, indexInList: i),
                          onFavorite: () => setState(() => MusicLibrary.toggleFavorite(track)),
                          onDownload: () => _downloadMusic(track),
                        );
                      },
                    ),
        ),
      ],
    );
  }

  Widget _buildFavoritesTab() {
    if (MusicLibrary.favorites.isEmpty) {
      return _buildEmptyState(
        Icons.favorite_border_rounded,
        'Belum ada favorit',
        'Tap ikon hati pada sebuah lagu untuk menyimpannya di sini',
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.only(top: 8, bottom: 110),
      itemCount: MusicLibrary.favorites.length,
      itemBuilder: (ctx, i) {
        final track = MusicLibrary.favorites[i];
        final key = (track['url'] ?? track['title'] ?? '').toString();
        final activeKey = (GlobalMusicPlayer.currentTrack?['url'] ??
                GlobalMusicPlayer.currentTrack?['title'] ??
                '')
            .toString();
        return _TrackTile(
          track: track,
          isDownloading: _downloadingKeys.contains(key),
          isFavorite: true,
          isActive: key.isNotEmpty && key == activeKey,
          onTap: () => _playMusic(track, fromList: MusicLibrary.favorites, indexInList: i),
          onFavorite: () => setState(() => MusicLibrary.toggleFavorite(track)),
          onDownload: () => _downloadMusic(track),
        );
      },
    );
  }

  Widget _buildProfileTab() {
    final favCount = MusicLibrary.favorites.length;
    final avatarColor =
        _Bmw.avatarColors[MusicLibrary.avatarColorIndex % _Bmw.avatarColors.length];
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 110),
      children: [
        Center(
          child: Column(
            children: [
              GestureDetector(
                onTap: () => setState(() {
                  MusicLibrary.avatarColorIndex =
                      (MusicLibrary.avatarColorIndex + 1) % _Bmw.avatarColors.length;
                }),
                child: Container(
                  width: 88,
                  height: 88,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(colors: [avatarColor, avatarColor.withOpacity(0.5)]),
                    border: Border.all(color: Colors.white.withOpacity(0.1), width: 3),
                  ),
                  child: Center(
                    child: Text(
                      MusicLibrary.profileName.isNotEmpty
                          ? MusicLibrary.profileName[0].toUpperCase()
                          : 'M',
                      style: const TextStyle(
                          color: Colors.white, fontSize: 34, fontWeight: FontWeight.w800),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              GestureDetector(
                onTap: _renameProfile,
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(MusicLibrary.profileName,
                        style: const TextStyle(
                            color: _Bmw.white, fontSize: 18, fontWeight: FontWeight.w800)),
                    const SizedBox(width: 6),
                    const Icon(Icons.edit_rounded, color: _Bmw.grey, size: 15),
                  ],
                ),
              ),
              const SizedBox(height: 2),
              const Text('Music Bmw Member', style: TextStyle(color: _Bmw.grey, fontSize: 12.5)),
            ],
          ),
        ),
        const SizedBox(height: 26),
        Row(
          children: [
            Expanded(
                child: _statCard('Favorites', '$favCount', Icons.favorite_rounded, _Bmw.mRed)),
            const SizedBox(width: 12),
            Expanded(
                child: _statCard('Played', '${MusicLibrary.totalPlayed}',
                    Icons.play_circle_fill_rounded, _Bmw.green)),
          ],
        ),
        const SizedBox(height: 24),
        _profileTile(Icons.palette_rounded, 'Tap avatar di atas untuk ganti warna', _Bmw.mPurple),
        _profileTile(
            Icons.info_outline_rounded, 'Music Bmw \u2022 streaming & download pribadi', _Bmw.mBlue),
        if (favCount > 0)
          _profileTile(Icons.delete_outline_rounded, 'Tap untuk hapus semua favorit', _Bmw.mRed,
              onTap: () => setState(() => MusicLibrary.favorites.clear())),
      ],
    );
  }

  Widget _statCard(String label, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 18),
      decoration: BoxDecoration(
        color: _Bmw.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _Bmw.border),
      ),
      child: Column(children: [
        Icon(icon, color: color, size: 22),
        const SizedBox(height: 8),
        Text(value, style: const TextStyle(color: _Bmw.white, fontSize: 18, fontWeight: FontWeight.w800)),
        const SizedBox(height: 2),
        Text(label, style: const TextStyle(color: _Bmw.grey, fontSize: 11.5)),
      ]),
    );
  }

  Widget _profileTile(IconData icon, String text, Color color, {VoidCallback? onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: _Bmw.card,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _Bmw.border),
        ),
        child: Row(children: [
          Icon(icon, color: color, size: 18),
          const SizedBox(width: 12),
          Expanded(child: Text(text, style: const TextStyle(color: _Bmw.grey, fontSize: 12.5))),
        ]),
      ),
    );
  }

  Widget _buildEmptyState(IconData icon, String title, String subtitle) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 64, color: _Bmw.border),
          const SizedBox(height: 16),
          Text(title,
              style: const TextStyle(color: _Bmw.white, fontSize: 16, fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: Text(subtitle,
                textAlign: TextAlign.center, style: const TextStyle(color: _Bmw.grey, fontSize: 12.5)),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomArea() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (GlobalMusicPlayer.currentTrack != null) _buildMiniPlayer(),
        _buildNavBar(),
      ],
    );
  }

  Widget _buildMiniPlayer() {
    final track = GlobalMusicPlayer.currentTrack!;
    final double progress = _duration.inMilliseconds > 0
        ? (_position.inMilliseconds / _duration.inMilliseconds).clamp(0.0, 1.0).toDouble()
        : 0.0;
    return GestureDetector(
      onTap: _openFullPlayer,
      child: Container(
        height: 64,
        margin: const EdgeInsets.fromLTRB(10, 0, 10, 6),
        decoration: BoxDecoration(
          color: _Bmw.cardAlt,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _Bmw.border),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 12, offset: const Offset(0, 4)),
          ],
        ),
        child: Stack(children: [
          Positioned(
            left: 0,
            right: 0,
            top: 0,
            child: ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(14)),
              child: LinearProgressIndicator(
                value: progress,
                minHeight: 2.5,
                backgroundColor: Colors.transparent,
                valueColor: const AlwaysStoppedAnimation(_Bmw.green),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(8, 6, 8, 0),
            child: Row(children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(9),
                child: Image.network(
                  (track['thumbnail'] ?? track['cover'] ?? '').toString(),
                  width: 42,
                  height: 42,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    width: 42,
                    height: 42,
                    color: _Bmw.surface,
                    child: const Icon(Icons.music_note_rounded, color: _Bmw.green, size: 18),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(track['title']?.toString() ?? 'Unknown',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: _Bmw.white, fontSize: 13, fontWeight: FontWeight.w700)),
                    Text(track['channel']?.toString() ?? 'Unknown Artist',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: _Bmw.grey, fontSize: 11)),
                  ],
                ),
              ),
              IconButton(
                icon: Icon(
                  MusicLibrary.isFavorite(track) ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                  color: MusicLibrary.isFavorite(track) ? _Bmw.mRed : _Bmw.grey,
                  size: 19,
                ),
                onPressed: () => setState(() => MusicLibrary.toggleFavorite(track)),
              ),
              IconButton(
                icon: Icon(
                  GlobalMusicPlayer.isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                  color: _Bmw.white,
                  size: 26,
                ),
                onPressed: _togglePlayPause,
              ),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _buildNavBar() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8),
      decoration: const BoxDecoration(
        color: _Bmw.surface,
        border: Border(top: BorderSide(color: _Bmw.border)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: List.generate(_navItems.length, (i) {
          final selected = _tabIndex == i;
          final item = _navItems[i];
          return GestureDetector(
            onTap: () => setState(() => _tabIndex = i),
            behavior: HitTestBehavior.opaque,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(item.icon, color: selected ? _Bmw.green : _Bmw.grey, size: 23),
                const SizedBox(height: 3),
                Text(item.label,
                    style: TextStyle(
                        color: selected ? _Bmw.green : _Bmw.grey,
                        fontSize: 10.5,
                        fontWeight: FontWeight.w600)),
              ],
            ),
          );
        }),
      ),
    );
  }

  @override
  void dispose() {
    _queryController.dispose();
    super.dispose();
  }
}

// ═════════════════════════════════════════════════════════════════════════
// TRACK TILE — dipakai di tab Search dan Favorites
// ═════════════════════════════════════════════════════════════════════════
class _TrackTile extends StatelessWidget {
  final Map<String, dynamic> track;
  final bool isDownloading;
  final bool isFavorite;
  final bool isActive;
  final VoidCallback onTap;
  final VoidCallback onFavorite;
  final VoidCallback onDownload;

  const _TrackTile({
    required this.track,
    required this.isDownloading,
    required this.isFavorite,
    required this.isActive,
    required this.onTap,
    required this.onFavorite,
    required this.onDownload,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: isActive ? _Bmw.green.withOpacity(0.08) : _Bmw.card,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: isActive ? _Bmw.green.withOpacity(0.4) : _Bmw.border),
          ),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Image.network(
                  (track['thumbnail'] ?? track['cover'] ?? '').toString(),
                  width: 54,
                  height: 54,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    width: 54,
                    height: 54,
                    color: _Bmw.surface,
                    child: const Icon(Icons.music_note_rounded, color: _Bmw.green),
                  ),
                  loadingBuilder: (ctx, child, prog) => prog == null
                      ? child
                      : Container(
                          width: 54,
                          height: 54,
                          color: _Bmw.surface,
                          child: const Center(
                            child: SizedBox(
                              width: 16,
                              height: 16,
                              child: CircularProgressIndicator(strokeWidth: 2, color: _Bmw.green),
                            ),
                          ),
                        ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(track['title']?.toString() ?? 'Unknown Title',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            color: isActive ? _Bmw.green : _Bmw.white,
                            fontSize: 14.5,
                            fontWeight: FontWeight.w700)),
                    const SizedBox(height: 3),
                    Text(track['channel']?.toString() ?? 'Unknown Artist',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: _Bmw.grey, fontSize: 12.5)),
                    if (track['duration'] != null)
                      Padding(
                        padding: const EdgeInsets.only(top: 2),
                        child: Text(track['duration'].toString(),
                            style: const TextStyle(
                                color: _Bmw.green, fontSize: 10.5, fontWeight: FontWeight.w600)),
                      ),
                  ],
                ),
              ),
              IconButton(
                icon: Icon(
                  isFavorite ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                  color: isFavorite ? _Bmw.mRed : _Bmw.grey,
                  size: 21,
                ),
                onPressed: onFavorite,
              ),
              isDownloading
                  ? const SizedBox(
                      width: 38,
                      height: 38,
                      child: Padding(
                        padding: EdgeInsets.all(9.0),
                        child: CircularProgressIndicator(strokeWidth: 2, color: _Bmw.green),
                      ),
                    )
                  : IconButton(
                      icon: const Icon(Icons.download_rounded, color: _Bmw.grey, size: 21),
                      onPressed: onDownload,
                    ),
            ],
          ),
        ),
      ),
    );
  }
}

// ═════════════════════════════════════════════════════════════════════════
// FULL PLAYER SHEET — muncul saat mini player di-tap
// ═════════════════════════════════════════════════════════════════════════
class _FullPlayerSheet extends StatefulWidget {
  final VoidCallback onFavoriteToggle;
  final VoidCallback onDownload;
  final VoidCallback onNext;
  final VoidCallback onPrevious;

  const _FullPlayerSheet({
    required this.onFavoriteToggle,
    required this.onDownload,
    required this.onNext,
    required this.onPrevious,
  });

  @override
  State<_FullPlayerSheet> createState() => _FullPlayerSheetState();
}

class _FullPlayerSheetState extends State<_FullPlayerSheet> {
  String _fmt(Duration d) {
    String two(int n) => n.toString().padLeft(2, '0');
    final h = d.inHours, m = d.inMinutes.remainder(60), s = d.inSeconds.remainder(60);
    return h > 0 ? '${two(h)}:${two(m)}:${two(s)}' : '${two(m)}:${two(s)}';
  }

  @override
  Widget build(BuildContext context) {
    final Map<String, dynamic> track =
        GlobalMusicPlayer.currentTrack ?? <String, dynamic>{};

    return DraggableScrollableSheet(
      initialChildSize: 0.86,
      minChildSize: 0.5,
      maxChildSize: 0.95,
      builder: (ctx, scrollController) {
        return Container(
          decoration: const BoxDecoration(
            color: _Bmw.bg,
            borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
          ),
          clipBehavior: Clip.antiAlias,
          child: Stack(children: [
            const _CheckerBackground(),
            SafeArea(
              top: false,
              child: ListView(
                controller: scrollController,
                padding: const EdgeInsets.fromLTRB(24, 12, 24, 24),
                children: [
                  Center(
                    child: Container(
                      width: 42,
                      height: 4,
                      decoration:
                          BoxDecoration(color: _Bmw.border, borderRadius: BorderRadius.circular(4)),
                    ),
                  ),
                  const SizedBox(height: 26),
                  Center(
                    child: Container(
                      width: 240,
                      height: 240,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(color: _Bmw.green.withOpacity(0.15), blurRadius: 40, spreadRadius: 4),
                        ],
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(20),
                        child: Image.network(
                          (track['thumbnail'] ?? track['cover'] ?? '').toString(),
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Container(
                            color: _Bmw.card,
                            child: const Icon(Icons.music_note_rounded, color: _Bmw.green, size: 60),
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 28),
                  Text(track['title']?.toString() ?? 'Unknown Title',
                      textAlign: TextAlign.center,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: _Bmw.white, fontSize: 20, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 6),
                  Text(track['channel']?.toString() ?? 'Unknown Artist',
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: _Bmw.grey, fontSize: 13.5)),
                  const SizedBox(height: 22),
                  StreamBuilder<Duration>(
                    stream: GlobalMusicPlayer.player.positionStream,
                    builder: (ctx, snap) {
                      final pos = snap.data ?? Duration.zero;
                      final dur = GlobalMusicPlayer.player.duration ?? Duration.zero;
                      final double maxMs =
                          dur.inMilliseconds > 0 ? dur.inMilliseconds.toDouble() : 1.0;
                      final double val =
                          pos.inMilliseconds.toDouble().clamp(0.0, maxMs).toDouble();
                      return Column(children: [
                        SliderTheme(
                          data: SliderTheme.of(context).copyWith(
                            activeTrackColor: _Bmw.green,
                            inactiveTrackColor: _Bmw.border,
                            thumbColor: _Bmw.white,
                            trackHeight: 3,
                            thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6),
                            overlayShape: SliderComponentShape.noOverlay,
                          ),
                          child: Slider(
                            value: val,
                            max: maxMs,
                            onChanged: (v) =>
                                GlobalMusicPlayer.player.seek(Duration(milliseconds: v.toInt())),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 4),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(_fmt(pos), style: const TextStyle(color: _Bmw.grey, fontSize: 11.5)),
                              Text(_fmt(dur), style: const TextStyle(color: _Bmw.grey, fontSize: 11.5)),
                            ],
                          ),
                        ),
                      ]);
                    },
                  ),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      IconButton(
                        icon: Icon(
                          MusicLibrary.isFavorite(track)
                              ? Icons.favorite_rounded
                              : Icons.favorite_border_rounded,
                          color: MusicLibrary.isFavorite(track) ? _Bmw.mRed : _Bmw.grey,
                          size: 24,
                        ),
                        onPressed: () {
                          widget.onFavoriteToggle();
                          setState(() {});
                        },
                      ),
                      IconButton(
                        icon: const Icon(Icons.skip_previous_rounded, color: _Bmw.white, size: 32),
                        onPressed: widget.onPrevious,
                      ),
                      StreamBuilder<PlayerState>(
                        stream: GlobalMusicPlayer.player.playerStateStream,
                        builder: (ctx, snap) {
                          final playing = snap.data?.playing ?? GlobalMusicPlayer.isPlaying;
                          return Container(
                            width: 64,
                            height: 64,
                            decoration: const BoxDecoration(color: _Bmw.green, shape: BoxShape.circle),
                            child: IconButton(
                              icon: Icon(playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
                                  color: Colors.black, size: 32),
                              onPressed: () {
                                if (playing) {
                                  GlobalMusicPlayer.player.pause();
                                } else {
                                  GlobalMusicPlayer.player.play();
                                }
                              },
                            ),
                          );
                        },
                      ),
                      IconButton(
                        icon: const Icon(Icons.skip_next_rounded, color: _Bmw.white, size: 32),
                        onPressed: widget.onNext,
                      ),
                      IconButton(
                        icon: const Icon(Icons.download_rounded, color: _Bmw.grey, size: 24),
                        onPressed: widget.onDownload,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ]),
        );
      },
    );
  }
}
