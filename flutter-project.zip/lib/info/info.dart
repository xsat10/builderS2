import 'dart:io';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../manager/change_password_page.dart';

class MyInfoPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;

  const MyInfoPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
  });

  @override
  State<MyInfoPage> createState() => _MyInfoPageState();
}

class _MyInfoPageState extends State<MyInfoPage> {
  // ─── 🏁 BMW M GARAGE PALETTE ──────────────────────────────
  static const Color garageBlack   = Color(0xFF0A0A0A);
  static const Color carbonDark    = Color(0xFF121212);
  static const Color cardColor     = Color(0xFF1A1A1A);
  static const Color surfaceColor  = Color(0xFF202020);
  static const Color chromeSilver  = Color(0xFFC8C8C8);
  static const Color bmwLightBlue  = Color(0xFF0066B1);
  static const Color bmwDarkBlue   = Color(0xFF0F3D77);
  static const Color bmwRed        = Color(0xFFE32119);
  static const Color bmwBlueGlow   = Color(0xFF1C69D4);
  static const Color textPrimary   = Color(0xFFF5F5F5);
  static const Color textSecondary = Color(0xFF9E9E9E);

  File? _profileImage;
  bool showPassword = false;
  bool showSessionKey = false;
  String _pairingId = '';

  final ImagePicker _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    _loadProfileImage();
    _loadPairingId();
  }

  Future<void> _pickImage() async {
    final XFile? image =
        await _picker.pickImage(source: ImageSource.gallery, imageQuality: 80);

    if (image != null) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('profile_image_${widget.username}', image.path);

      setState(() {
        _profileImage = File(image.path);
      });
      Navigator.pop(context, image.path);
    }
  }

  Future<void> _loadPairingId() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _pairingId = prefs.getString('pairing_id_${widget.username}') ?? '';
    });
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final path = prefs.getString('profile_image_${widget.username}');

    if (path != null && File(path).existsSync()) {
      setState(() {
        _profileImage = File(path);
      });
    }
  }

  String _mask(String text, {int show = 2}) {
    if (text.length <= show) return "*" * text.length;
    return text.substring(0, show) + "•" * (text.length - show);
  }

  // 🏁 M-Stripe Widget
  Widget _mStripe({double height = 3, double width = 40}) {
    return Container(
      height: height,
      width: width,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(2),
        gradient: const LinearGradient(
          colors: [bmwLightBlue, bmwDarkBlue, bmwRed],
          stops: [0.0, 0.5, 1.0],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: garageBlack,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: carbonDark.withOpacity(0.85),
        elevation: 0,
        leading: IconButton(
          icon: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: cardColor.withOpacity(0.6),
              shape: BoxShape.circle,
              border: Border.all(
                color: chromeSilver.withOpacity(0.25),
                width: 1,
              ),
            ),
            child: const Icon(
              Icons.arrow_back_ios_new,
              color: chromeSilver,
              size: 14,
            ),
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: Column(
          children: [
            const Text(
              "DRIVER PROFILE",
              style: TextStyle(
                color: textPrimary,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold,
                fontSize: 15,
                letterSpacing: 3,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              "/// M IDENTIFICATION CARD",
              style: TextStyle(
                color: chromeSilver.withOpacity(0.6),
                fontSize: 9,
                letterSpacing: 2.5,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ],
        ),
        centerTitle: true,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(3),
          child: _mStripe(height: 3, width: double.infinity),
        ),
      ),
      body: Stack(
        children: [
          // ─── CARBON BACKGROUND ───
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [carbonDark, garageBlack, Color(0xFF050505)],
                ),
              ),
            ),
          ),

          // ─── BLUE HEADLIGHT GLOW ───
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: const Alignment(-0.8, -0.7),
                  radius: 1.4,
                  colors: [
                    bmwBlueGlow.withOpacity(0.12),
                    Colors.transparent,
                  ],
                  stops: const [0.0, 1.0],
                ),
              ),
            ),
          ),

          // ─── RED TAIL-LIGHT GLOW ───
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: const Alignment(1.0, 1.0),
                  radius: 1.2,
                  colors: [
                    bmwRed.withOpacity(0.08),
                    Colors.transparent,
                  ],
                  stops: const [0.0, 1.0],
                ),
              ),
            ),
          ),

          // ─── CARBON GRID ───
          Positioned.fill(
            child: CustomPaint(painter: _GridPatternPainter()),
          ),

          // ─── CONTENT ───
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 32),
              child: Column(
                children: [
                  // ─── TOP TELEMETRY BADGE ───
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 7),
                    decoration: BoxDecoration(
                      color: cardColor.withOpacity(0.7),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: chromeSilver.withOpacity(0.2),
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 7,
                          height: 7,
                          decoration: BoxDecoration(
                            color: bmwBlueGlow,
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: bmwBlueGlow.withOpacity(0.8),
                                blurRadius: 8,
                                spreadRadius: 1,
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          "AUTHENTICATED DRIVER · M REGISTRY",
                          style: TextStyle(
                            color: chromeSilver.withOpacity(0.8),
                            fontSize: 9,
                            letterSpacing: 2,
                            fontFamily: 'ShareTechMono',
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 24),

                  // ─── AVATAR (ROUNDEL STYLE) ───
                  Stack(
                    alignment: Alignment.bottomRight,
                    children: [
                      Container(
                        width: 130,
                        height: 130,
                        padding: const EdgeInsets.all(3),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: const LinearGradient(
                            colors: [bmwLightBlue, bmwDarkBlue, bmwRed],
                            stops: [0.0, 0.5, 1.0],
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: bmwBlueGlow.withOpacity(0.5),
                              blurRadius: 25,
                              spreadRadius: 3,
                            ),
                            BoxShadow(
                              color: bmwRed.withOpacity(0.2),
                              blurRadius: 35,
                              spreadRadius: 2,
                            ),
                          ],
                        ),
                        child: Container(
                          padding: const EdgeInsets.all(3),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: garageBlack,
                            border: Border.all(
                              color: chromeSilver.withOpacity(0.4),
                              width: 1,
                            ),
                          ),
                          child: Hero(
                            tag: 'profile-avatar',
                            child: CircleAvatar(
                              radius: 55,
                              backgroundColor: surfaceColor,
                              backgroundImage: _profileImage != null
                                  ? FileImage(_profileImage!)
                                  : null,
                              child: _profileImage == null
                                  ? const Icon(
                                      FontAwesomeIcons.userNinja,
                                      size: 44,
                                      color: chromeSilver,
                                    )
                                  : null,
                            ),
                          ),
                        ),
                      ),
                      // Camera button
                      GestureDetector(
                        onTap: _pickImage,
                        child: Container(
                          width: 40,
                          height: 40,
                          padding: const EdgeInsets.all(2),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: const LinearGradient(
                              colors: [bmwLightBlue, bmwDarkBlue],
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: bmwBlueGlow.withOpacity(0.6),
                                blurRadius: 15,
                                spreadRadius: 1,
                              ),
                            ],
                          ),
                          child: Container(
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: garageBlack,
                              border: Border.all(
                                color: chromeSilver.withOpacity(0.4),
                                width: 1,
                              ),
                            ),
                            child: const Icon(
                              Icons.camera_alt,
                              color: chromeSilver,
                              size: 16,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 20),

                  // ─── USERNAME (Chrome Gradient) ───
                  ShaderMask(
                    shaderCallback: (bounds) => const LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Color(0xFFFFFFFF),
                        Color(0xFFC8C8C8),
                        Color(0xFF7A7A7A),
                      ],
                      stops: [0.0, 0.5, 1.0],
                    ).createShader(bounds),
                    child: Text(
                      widget.username.toUpperCase(),
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron',
                        letterSpacing: 2.5,
                      ),
                    ),
                  ),

                  const SizedBox(height: 10),

                  // ─── ROLE BADGE ───
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 6),
                    decoration: BoxDecoration(
                      color: cardColor.withOpacity(0.7),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: bmwBlueGlow.withOpacity(0.4),
                        width: 1,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: bmwBlueGlow.withOpacity(0.2),
                          blurRadius: 10,
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          Icons.workspace_premium_rounded,
                          color: bmwBlueGlow,
                          size: 13,
                        ),
                        const SizedBox(width: 6),
                        Text(
                          widget.role.toUpperCase(),
                          style: const TextStyle(
                            color: textPrimary,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 2.5,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 24),
                  _mStripe(height: 3, width: 100),
                  const SizedBox(height: 24),

                  // ─── INFO TILES ───
                  _staticTile(
                    "Username",
                    widget.username,
                    Icons.person,
                    bmwBlueGlow,
                  ),
                  _infoTile(
                    label: "Password",
                    value: showPassword
                        ? widget.password
                        : "•" * widget.password.length,
                    toggle: () =>
                        setState(() => showPassword = !showPassword),
                    icon: Icons.lock,
                    isVisible: showPassword,
                  ),
                  _staticTile(
                    "Role",
                    widget.role.toUpperCase(),
                    Icons.badge,
                    bmwBlueGlow,
                  ),
                  _staticTile(
                    "Expired Date",
                    widget.expiredDate,
                    Icons.calendar_today,
                    bmwBlueGlow,
                  ),
                  _infoTile(
                    label: "Session Key",
                    value: showSessionKey
                        ? widget.sessionKey
                        : _mask(widget.sessionKey, show: 6),
                    toggle: () =>
                        setState(() => showSessionKey = !showSessionKey),
                    icon: Icons.vpn_key,
                    isVisible: showSessionKey,
                  ),
                  _staticTile(
                    "Pairing ID",
                    _pairingId.isEmpty ? "BELUM DIATUR" : _pairingId,
                    Icons.link,
                    bmwBlueGlow,
                  ),

                  const SizedBox(height: 24),

                  // ─── CHANGE PASSWORD BUTTON (M-GRADIENT) ───
                  Material(
                    color: Colors.transparent,
                    borderRadius: BorderRadius.circular(12),
                    child: InkWell(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => ChangePasswordPage(
                              username: widget.username,
                              sessionKey: widget.sessionKey,
                            ),
                          ),
                        );
                      },
                      borderRadius: BorderRadius.circular(12),
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(vertical: 15),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [bmwLightBlue, bmwDarkBlue, bmwRed],
                            stops: [0.0, 0.5, 1.0],
                            begin: Alignment.centerLeft,
                            end: Alignment.centerRight,
                          ),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: chromeSilver.withOpacity(0.35),
                            width: 1,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: bmwBlueGlow.withOpacity(0.4),
                              blurRadius: 18,
                              spreadRadius: 1,
                            ),
                            BoxShadow(
                              color: bmwRed.withOpacity(0.2),
                              blurRadius: 18,
                              offset: const Offset(6, 0),
                            ),
                          ],
                        ),
                        child: const Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.lock_reset,
                                color: Colors.white, size: 18),
                            SizedBox(width: 10),
                            Text(
                              "CHANGE PASSWORD",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 2.5,
                                fontFamily: 'Orbitron',
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),

                  // ─── FOOTER ───
                  _mStripe(height: 2, width: 140),
                  const SizedBox(height: 14),
                  Text(
                    "© 2026 GHOSTCRASHER · ///M DIVISION",
                    style: TextStyle(
                      color: textSecondary.withOpacity(0.7),
                      fontSize: 10,
                      letterSpacing: 1.5,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                  const SizedBox(height: 12),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── STATIC TILE (FIXED - no duplicate value) ───
  Widget _staticTile(
    String label,
    String value,
    IconData icon,
    Color accent,
  ) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            cardColor.withOpacity(0.85),
            carbonDark.withOpacity(0.95),
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: chromeSilver.withOpacity(0.15),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Stack(
        children: [
          // Left M-stripe accent
          Positioned(
            left: 0,
            top: 0,
            bottom: 0,
            child: Container(
              width: 3,
              decoration: const BoxDecoration(
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(12),
                  bottomLeft: Radius.circular(12),
                ),
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [bmwLightBlue, bmwDarkBlue, bmwRed],
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 14, 16, 14),
            child: Row(
              children: [
                // Icon circle
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: garageBlack,
                    border: Border.all(
                      color: accent.withOpacity(0.4),
                      width: 1.2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: accent.withOpacity(0.3),
                        blurRadius: 10,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                  child: Icon(
                    icon,
                    color: accent,
                    size: 18,
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        label.toUpperCase(),
                        style: TextStyle(
                          color: chromeSilver.withOpacity(0.6),
                          fontSize: 9,
                          letterSpacing: 2,
                          fontFamily: 'ShareTechMono',
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        value,
                        style: const TextStyle(
                          color: textPrimary,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                          fontFamily: 'ShareTechMono',
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── INFO TILE (with visibility toggle) ───
  Widget _infoTile({
    required String label,
    required String value,
    required VoidCallback toggle,
    required IconData icon,
    required bool isVisible,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            cardColor.withOpacity(0.85),
            carbonDark.withOpacity(0.95),
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isVisible
              ? bmwBlueGlow.withOpacity(0.4)
              : chromeSilver.withOpacity(0.15),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
          if (isVisible)
            BoxShadow(
              color: bmwBlueGlow.withOpacity(0.15),
              blurRadius: 15,
              spreadRadius: 1,
            ),
        ],
      ),
      child: Stack(
        children: [
          // Left M-stripe accent
          Positioned(
            left: 0,
            top: 0,
            bottom: 0,
            child: Container(
              width: 3,
              decoration: BoxDecoration(
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(12),
                  bottomLeft: Radius.circular(12),
                ),
                gradient: isVisible
                    ? const LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [bmwLightBlue, bmwDarkBlue, bmwRed],
                      )
                    : LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          chromeSilver.withOpacity(0.4),
                          chromeSilver.withOpacity(0.2),
                        ],
                      ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 14, 8, 14),
            child: Row(
              children: [
                // Icon circle - blue if visible, chrome if hidden
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: garageBlack,
                    border: Border.all(
                      color: (isVisible ? bmwBlueGlow : chromeSilver)
                          .withOpacity(0.4),
                      width: 1.2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: (isVisible ? bmwBlueGlow : chromeSilver)
                            .withOpacity(0.25),
                        blurRadius: 10,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                  child: Icon(
                    icon,
                    color: isVisible ? bmwBlueGlow : chromeSilver,
                    size: 18,
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            label.toUpperCase(),
                            style: TextStyle(
                              color: chromeSilver.withOpacity(0.6),
                              fontSize: 9,
                              letterSpacing: 2,
                              fontFamily: 'ShareTechMono',
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(width: 6),
                          // Status LED
                          Container(
                            width: 5,
                            height: 5,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: isVisible
                                  ? bmwBlueGlow
                                  : chromeSilver.withOpacity(0.4),
                              boxShadow: isVisible
                                  ? [
                                      BoxShadow(
                                        color: bmwBlueGlow.withOpacity(0.8),
                                        blurRadius: 5,
                                      ),
                                    ]
                                  : null,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(
                        value,
                        style: const TextStyle(
                          color: textPrimary,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                          fontFamily: 'ShareTechMono',
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
                IconButton(
                  icon: Icon(
                    isVisible
                        ? Icons.visibility_rounded
                        : Icons.visibility_off_rounded,
                    color: isVisible ? bmwBlueGlow : chromeSilver,
                    size: 20,
                  ),
                  onPressed: toggle,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─── CARBON GRID PAINTER ───────────────────────────────────────────────────
class _GridPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF1C69D4).withOpacity(0.04)
      ..strokeWidth = 0.5
      ..style = PaintingStyle.stroke;

    const double spacing = 50;
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}