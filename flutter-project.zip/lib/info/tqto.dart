import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class ThanksToPage extends StatefulWidget {
  const ThanksToPage({Key? key}) : super(key: key);

  @override
  _ThanksToPageState createState() => _ThanksToPageState();
}

class _ThanksToPageState extends State<ThanksToPage>
    with SingleTickerProviderStateMixin {
  // DATA STATIS - TANPA AMBIL DARI GITHUB
  final List<Map<String, dynamic>> thanksToList = [
    {
      'name': 'Skylinne',
      'status': 'Developer & Creators Apps',
      'contac': 'Skylinnereal',
      'ppAsset': 'assets/images/sky.png', // Gambar dari asset
    },
    {
      'name': 'Danz',
      'status': 'Support & Friend',
      'contac': 'dnxxxz',
      'ppAsset': 'assets/images/danz.jpg',
    },
    {
      'name': 'JesterNovaZ',
      'status': 'Support & Friend',
      'contac': 'yt1mLu',
      'ppAsset': 'assets/images/jess.jpg',
    },
  ];

  bool isLoading = false;
  bool hasError = false;
  int currentIndex = 0;
  late PageController _pageController;
  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;

  // ============ BMW GARAGE PALETTE ============
  final Color primaryDark = const Color(0xFF05070A);   // garage black
  final Color cardDark = const Color(0xFF0E1319);      // carbon panel
  final Color cardDarker = const Color(0xFF0A0F16);    // deeper carbon

  final Color bmwBlue = const Color(0xFF1C69D4);       // BMW M blue
  final Color bmwLightBlue = const Color(0xFF6FB2FF);  // BMW light blue
  final Color bmwRed = const Color(0xFFE7222E);        // BMW M red
  final Color bmwChrome = const Color(0xFFD6DCE5);     // platinum chrome
  final Color bmwSilver = const Color(0xFF9AA5B1);     // silver

  // Legacy aliases agar kode di bawah tidak perlu diubah banyak
  final Color primaryGrey = const Color(0xFFD6DCE5);
  final Color accentGrey = const Color(0xFF9AA5B1);

  @override
  void initState() {
    super.initState();
    _pageController = PageController(viewportFraction: 0.8);
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    _scaleAnimation = Tween<double>(begin: 0.95, end: 1.0).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeOut,
      ),
    );

    // Langsung animate karena data sudah ada
    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted) {
        _animationController.forward();
      }
    });
  }

  @override
  void dispose() {
    _pageController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  Future<void> launchContact(String username) async {
    String url = 'https://t.me/$username';

    if (await canLaunch(url)) {
      await launch(url);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Cannot open: $url'),
          backgroundColor: bmwBlue,
        ),
      );
    }
  }

  Widget _buildProfileCard(Map<String, dynamic> person, int index) {
    final bool isCenter = index == currentIndex;

    return GestureDetector(
      onTap: () {
        _pageController.animateToPage(
          index,
          duration: const Duration(milliseconds: 500),
          curve: Curves.easeInOut,
        );
      },
      child: AnimatedBuilder(
        animation: _pageController,
        builder: (context, child) {
          double value = 1.0;
          if (_pageController.position.haveDimensions) {
            value = _pageController.page! - index;
            value = (1 - (value.abs() * 0.3)).clamp(0.0, 1.0);
          }

          return Transform.scale(
            scale: isCenter ? 1.0 : 0.9 * value,
            child: Opacity(
              opacity: isCenter ? 1.0 : 0.7,
              child: child,
            ),
          );
        },
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            color: cardDark,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.55),
                blurRadius: isCenter ? 30 : 18,
                spreadRadius: isCenter ? 2 : 1,
                offset: const Offset(0, 10),
              ),
              if (isCenter)
                BoxShadow(
                  color: bmwBlue.withOpacity(0.30),
                  blurRadius: 30,
                  spreadRadius: 1,
                  offset: const Offset(0, -6),
                ),
            ],
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: isCenter
                  ? [cardDark, const Color(0xFF121A24)]
                  : [cardDarker, cardDark],
            ),
            border: Border.all(
              color: isCenter
                  ? bmwChrome.withOpacity(0.45)
                  : Colors.white.withOpacity(0.10),
              width: isCenter ? 1.5 : 1.0,
            ),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(24),
            child: Stack(
              children: [
                // M-stripe atas
                Positioned(
                  top: 0,
                  left: 0,
                  child: Row(
                    children: [
                      Container(width: 40, height: 3, color: bmwBlue),
                      Container(width: 40, height: 3, color: bmwLightBlue),
                      Container(width: 40, height: 3, color: bmwRed),
                    ],
                  ),
                ),
                // Watermark shield
                Positioned(
                  bottom: -30,
                  right: -25,
                  child: Opacity(
                    opacity: 0.05,
                    child: Icon(
                      Icons.shield_rounded,
                      size: 150,
                      color: bmwChrome,
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // ===== AVATAR =====
                      Container(
                        width: 160,
                        height: 160,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: isCenter
                                ? bmwChrome.withOpacity(0.9)
                                : bmwSilver.withOpacity(0.4),
                            width: isCenter ? 3 : 2,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: isCenter
                                  ? bmwBlue.withOpacity(0.35)
                                  : Colors.black.withOpacity(0.4),
                              blurRadius: 24,
                              spreadRadius: 2,
                              offset: const Offset(0, 6),
                            ),
                          ],
                        ),
                        child: ClipOval(
                          child: person['ppAsset'] != null &&
                                  person['ppAsset'].toString().isNotEmpty
                              ? Image.asset(
                                  person['ppAsset'].toString(),
                                  fit: BoxFit.cover,
                                  errorBuilder: (context, error, stackTrace) =>
                                      _buildAvatarFallback(),
                                )
                              : _buildAvatarFallback(),
                        ),
                      ),
                      const SizedBox(height: 24),
                      // ===== NAME =====
                      Text(
                        person['name']?.toString() ?? 'Unknown',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: isCenter ? 22 : 20,
                          fontWeight:
                              isCenter ? FontWeight.bold : FontWeight.w600,
                          letterSpacing: 0.8,
                          fontFamily: 'Orbitron',
                          shadows: [
                            Shadow(
                              color: Colors.black.withOpacity(0.8),
                              blurRadius: 8,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        textAlign: TextAlign.center,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 10),
                      // ===== STATUS BADGE =====
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: bmwBlue.withOpacity(0.10),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: bmwChrome.withOpacity(0.35),
                            width: 1,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: bmwBlue.withOpacity(0.15),
                              blurRadius: 10,
                              offset: const Offset(0, 3),
                            ),
                          ],
                        ),
                        child: Text(
                          person['status']?.toString() ?? 'No Status',
                          style: TextStyle(
                            color: bmwChrome,
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            letterSpacing: 0.5,
                          ),
                          textAlign: TextAlign.center,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      const SizedBox(height: 20),
                      // ===== CONTACT BUTTON =====
                      if (person['contac'] != null &&
                          person['contac'].toString().isNotEmpty &&
                          isCenter)
                        Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            gradient: const LinearGradient(
                              colors: [Color(0xFF1C69D4), Color(0xFF6FB2FF)],
                              begin: Alignment.centerLeft,
                              end: Alignment.centerRight,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: bmwBlue.withOpacity(0.45),
                                blurRadius: 14,
                                offset: const Offset(0, 5),
                              ),
                              BoxShadow(
                                color: bmwRed.withOpacity(0.12),
                                blurRadius: 18,
                                offset: const Offset(0, -3),
                              ),
                            ],
                          ),
                          child: ElevatedButton(
                            onPressed: () =>
                                launchContact(person['contac'].toString()),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.transparent,
                              foregroundColor: Colors.white,
                              shadowColor: Colors.transparent,
                              elevation: 0,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                              padding: const EdgeInsets.symmetric(
                                horizontal: 24,
                                vertical: 12,
                              ),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: const [
                                Icon(
                                  FontAwesomeIcons.telegram,
                                  size: 18,
                                  color: Colors.white,
                                ),
                                SizedBox(width: 10),
                                Text(
                                  'Contact on Telegram',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w700,
                                    fontSize: 14,
                                    letterSpacing: 0.8,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildAvatarFallback() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            bmwBlue.withOpacity(0.15),
            bmwChrome.withOpacity(0.08),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Center(
        child: Icon(
          Icons.person,
          color: bmwChrome.withOpacity(0.6),
          size: 50,
        ),
      ),
    );
  }

  Widget _buildIndicator() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(
        thanksToList.length,
        (index) {
          final isActive = currentIndex == index;
          return AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            width: isActive ? 24 : 8,
            height: 8,
            margin: const EdgeInsets.symmetric(horizontal: 4),
            decoration: BoxDecoration(
              gradient: isActive
                  ? const LinearGradient(
                      colors: [Color(0xFF1C69D4), Color(0xFF6FB2FF)],
                    )
                  : null,
              color: isActive ? null : Colors.white.withOpacity(0.25),
              borderRadius: BorderRadius.circular(4),
              boxShadow: isActive
                  ? [
                      BoxShadow(
                        color: bmwBlue.withOpacity(0.55),
                        blurRadius: 10,
                        spreadRadius: 1,
                      ),
                    ]
                  : null,
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryDark,
      body: Stack(
        children: [
          // Base gradient
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0xFF05070A),
                  Color(0xFF0A0F16),
                  Color(0xFF05070A),
                ],
              ),
            ),
          ),

          // Ambient glow — M blue (kanan atas)
          Positioned(
            top: -140,
            right: -120,
            child: Container(
              width: 260,
              height: 260,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: bmwBlue.withOpacity(0.10),
                boxShadow: [
                  BoxShadow(
                    color: bmwBlue.withOpacity(0.20),
                    blurRadius: 110,
                    spreadRadius: 30,
                  ),
                ],
              ),
            ),
          ),

          // Ambient glow — M red (kiri bawah)
          Positioned(
            bottom: -140,
            left: -120,
            child: Container(
              width: 260,
              height: 260,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: bmwRed.withOpacity(0.08),
                boxShadow: [
                  BoxShadow(
                    color: bmwRed.withOpacity(0.15),
                    blurRadius: 110,
                    spreadRadius: 30,
                  ),
                ],
              ),
            ),
          ),

          SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ===== TOP BAR =====
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                  child: Row(
                    children: [
                      GestureDetector(
                        onTap: () => Navigator.pop(context),
                        child: Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: cardDarker,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: bmwChrome.withOpacity(0.35),
                              width: 1,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: bmwBlue.withOpacity(0.15),
                                blurRadius: 12,
                                offset: const Offset(0, 3),
                              ),
                            ],
                          ),
                          child: Icon(
                            Icons.arrow_back_ios_new_rounded,
                            color: bmwChrome,
                            size: 18,
                          ),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Text(
                        "Thanks To",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1.5,
                          shadows: [
                            Shadow(
                              color: bmwBlue.withOpacity(0.5),
                              blurRadius: 12,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                Expanded(
                  child: isLoading
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              CircularProgressIndicator(
                                valueColor: AlwaysStoppedAnimation<Color>(
                                    bmwLightBlue),
                                strokeWidth: 2,
                              ),
                              const SizedBox(height: 16),
                              Text(
                                "Loading Profiles...",
                                style: TextStyle(
                                  color: bmwSilver.withOpacity(0.85),
                                  fontSize: 16,
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ],
                          ),
                        )
                      : hasError
                          ? Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Container(
                                    width: 80,
                                    height: 80,
                                    decoration: BoxDecoration(
                                      color: bmwRed.withOpacity(0.10),
                                      shape: BoxShape.circle,
                                      border: Border.all(
                                        color: bmwRed.withOpacity(0.4),
                                        width: 1.2,
                                      ),
                                      boxShadow: [
                                        BoxShadow(
                                          color: bmwRed.withOpacity(0.2),
                                          blurRadius: 20,
                                          offset: const Offset(0, 6),
                                        ),
                                      ],
                                    ),
                                    child: Icon(
                                      Icons.error_outline,
                                      color: bmwRed,
                                      size: 40,
                                    ),
                                  ),
                                  const SizedBox(height: 20),
                                  Text(
                                    "Failed to load data",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 18,
                                      fontWeight: FontWeight.w600,
                                      letterSpacing: 0.5,
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  Text(
                                    "Please check your connection",
                                    style: TextStyle(
                                      color: bmwSilver.withOpacity(0.7),
                                      fontSize: 14,
                                    ),
                                  ),
                                  const SizedBox(height: 24),
                                  Container(
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(12),
                                      gradient: const LinearGradient(
                                        colors: [
                                          Color(0xFF1C69D4),
                                          Color(0xFF6FB2FF)
                                        ],
                                      ),
                                      boxShadow: [
                                        BoxShadow(
                                          color: bmwBlue.withOpacity(0.4),
                                          blurRadius: 14,
                                          offset: const Offset(0, 5),
                                        ),
                                      ],
                                    ),
                                    child: ElevatedButton(
                                      onPressed: () {
                                        setState(() {
                                          hasError = false;
                                          isLoading = false;
                                        });
                                      },
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: Colors.transparent,
                                        foregroundColor: Colors.white,
                                        shadowColor: Colors.transparent,
                                        elevation: 0,
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(12),
                                        ),
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 32,
                                          vertical: 14,
                                        ),
                                      ),
                                      child: const Text(
                                        "Retry",
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.w700,
                                          letterSpacing: 1.0,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            )
                          : thanksToList.isEmpty
                              ? Center(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Container(
                                        width: 120,
                                        height: 120,
                                        decoration: BoxDecoration(
                                          color: cardDark,
                                          shape: BoxShape.circle,
                                          border: Border.all(
                                            color: bmwChrome.withOpacity(0.25),
                                          ),
                                        ),
                                        child: Icon(
                                          Icons.group,
                                          color: bmwChrome.withOpacity(0.6),
                                          size: 50,
                                        ),
                                      ),
                                      const SizedBox(height: 20),
                                      Text(
                                        "No profiles available",
                                        style: TextStyle(
                                          color: bmwSilver.withOpacity(0.75),
                                          fontSize: 16,
                                        ),
                                      ),
                                    ],
                                  ),
                                )
                              : Column(
                                  children: [
                                    Expanded(
                                      child: AnimatedBuilder(
                                        animation: _animationController,
                                        builder: (context, child) {
                                          return Transform.scale(
                                            scale: _scaleAnimation.value,
                                            child: child,
                                          );
                                        },
                                        child: PageView.builder(
                                          controller: _pageController,
                                          itemCount: thanksToList.length,
                                          onPageChanged: (index) {
                                            setState(() {
                                              currentIndex = index;
                                            });
                                          },
                                          itemBuilder: (context, index) {
                                            return _buildProfileCard(
                                                thanksToList[index], index);
                                          },
                                        ),
                                      ),
                                    ),
                                    const SizedBox(height: 16),
                                    _buildIndicator(),
                                    const SizedBox(height: 20),
                                  ],
                                ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}