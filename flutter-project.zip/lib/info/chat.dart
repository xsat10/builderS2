import '../servers.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'dart:convert';
import 'dart:async';
import 'dart:ui' as ui;

class ChatMessage {
  final String id;
  final String userId;
  final String username;
  final String role;
  final String? message;
  final String? imageUrl;
  final String timestamp;
  final String avatarUrl;
  final bool isDeleted;

  ChatMessage({
    required this.id,
    required this.userId,
    required this.username,
    required this.role,
    this.message,
    this.imageUrl,
    required this.timestamp,
    required this.avatarUrl,
    required this.isDeleted,
  });

  factory ChatMessage.fromJson(Map<String, dynamic> json) {
    return ChatMessage(
      id: json['id'] ?? '',
      userId: json['userId'] ?? '',
      username: json['username'] ?? '',
      role: json['role'] ?? 'Member',
      message: json['message'],
      imageUrl: json['imageUrl'],
      timestamp: json['timestamp'] ?? '',
      avatarUrl: json['avatarUrl'] ?? 'assets/images/logo.jpg',
      isDeleted: json['isDeleted'] ?? false,
    );
  }
}

class CommunityPage extends StatefulWidget {
  final String username;
  final String role;

  const CommunityPage({super.key, required this.username, required this.role});

  @override
  State<CommunityPage> createState() => _CommunityPageState();
}

class _CommunityPageState extends State<CommunityPage> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final ImagePicker _picker = ImagePicker();
  final FocusNode _focusNode = FocusNode();

  List<ChatMessage> _messages = [];
  bool _isLoading = true;
  bool _isSending = false;
  Timer? _refreshTimer;
  bool _showScrollButton = false;
  bool _isAtBottom = true;

  String baseUrl = "http://digital.mypanelku.web.id:2018";

  // ═══════════════════════════════════════════════════════════════
  // BMW COLOR PALETTE
  // ═══════════════════════════════════════════════════════════════
  static const Color bmwBlue = Color(0xFF0066B1);
  static const Color bmwLightBlue = Color(0xFF1C69D4);
  static const Color bmwYellow = Color(0xFFFFD700);
  static const Color bmwRed = Color(0xFFE30613);
  static const Color bmwSilver = Color(0xFFB0B0B0);
  static const Color bmwChrome = Color(0xFFE0E0E0);
  static const Color carbonBlack = Color(0xFF0A0A0A);
  static const Color carbonDark = Color(0xFF121212);
  static const Color carbonMid = Color(0xFF1A1A1A);
  static const Color carbonLight = Color(0xFF2D2D2D);

  // ===== PATH BACKGROUND IMAGE =====
  static const String backgroundImagePath = 'assets/images/room.jpg';
  static const String carImagePath = 'assets/images/car.jpg';
  static const String bmwImagePath = 'assets/images/bmw.jpg';

  // ===== TEXT SHADOW =====
  static const List<Shadow> _textShadows = [
    Shadow(color: Colors.black, blurRadius: 6, offset: Offset(0, 1)),
    Shadow(color: Colors.black87, blurRadius: 12, offset: Offset(0, 2)),
  ];

  @override
  void initState() {
    super.initState();
    _loadConfigAndMessages();
    _startAutoRefresh();
    _scrollController.addListener(_scrollListener);
  }

  Future<void> _loadConfig() async {
    final response = await http.get(Uri.parse(
        Servers.configUrl));
    final data = jsonDecode(response.body);
    baseUrl = data['base_url'];
  }

  Future<void> _loadConfigAndMessages() async {
    await _loadConfig();
    await _loadMessages();
  }

  // ═══════════════════════════════════════════════════════════════
  // BMW MOTORSPORT STRIPE (Biru → Light Blue → Merah)
  // ═══════════════════════════════════════════════════════════════
  Widget _buildBmwStripe({double height = 3, double width = 66}) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(width: width / 3, height: height, color: bmwBlue),
        Container(width: width / 3, height: height, color: bmwLightBlue),
        Container(width: width / 3, height: height, color: bmwRed),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // BACKGROUND: BMW GARAGE
  // ═══════════════════════════════════════════════════════════════
  Widget _buildBackground() {
    return Positioned.fill(
      child: Stack(
        children: [
          // Foto background utama
          Positioned.fill(
            child: ImageFiltered(
              imageFilter: ui.ImageFilter.blur(sigmaX: 2.5, sigmaY: 2.5),
              child: Image.asset(
                backgroundImagePath,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) {
                  return Container(color: carbonBlack);
                },
              ),
            ),
          ),
          // Layer kedua: BMW car image dengan opacity rendah (untuk vibe garasi)
          Positioned.fill(
            child: Opacity(
              opacity: 0.12,
              child: Image.asset(
                carImagePath,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) => const SizedBox(),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // OVERLAY: DARK CARBON GRADIENT
  // ═══════════════════════════════════════════════════════════════
  Widget _buildBackgroundOverlay() {
    return Positioned.fill(
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              carbonBlack.withOpacity(0.92),
              carbonDark.withOpacity(0.85),
              carbonBlack.withOpacity(0.92),
            ],
            stops: const [0.0, 0.5, 1.0],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // TOP BMW STRIPE
  // ═══════════════════════════════════════════════════════════════
  Widget _buildTopStripe() {
    return Positioned(
      top: 0,
      left: 0,
      right: 0,
      height: 4,
      child: Row(
        children: [
          Expanded(
            flex: 1,
            child: Container(color: bmwBlue.withOpacity(0.95)),
          ),
          Expanded(
            flex: 1,
            child: Container(color: bmwLightBlue.withOpacity(0.95)),
          ),
          Expanded(
            flex: 1,
            child: Container(color: bmwRed.withOpacity(0.95)),
          ),
        ],
      ),
    );
  }

  void _scrollListener() {
    if (_scrollController.hasClients) {
      final isAtBottom = _scrollController.position.pixels >=
          _scrollController.position.maxScrollExtent - 100;

      setState(() {
        _showScrollButton = !isAtBottom;
        _isAtBottom = isAtBottom;
      });
    }
  }

  void _startAutoRefresh() {
    _refreshTimer = Timer.periodic(const Duration(seconds: 3), (timer) {
      _loadMessages();
    });
  }

  Future<void> _loadMessages() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/chat/messages'),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);

        setState(() {
          _messages = data.map((msg) => ChatMessage.fromJson(msg)).toList();
          _isLoading = false;
        });

        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (_isAtBottom) {
            _scrollToBottom(smooth: false);
          }
        });
      }
    } catch (e) {
      print('Error loading messages: $e');
      if (_messages.isEmpty) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _sendMessage() async {
    final message = _messageController.text.trim();
    if (message.isEmpty || _isSending) return;

    setState(() {
      _isSending = true;
    });

    try {
      final messageData = {
        'userId': widget.username,
        'username': widget.username,
        'role': widget.role,
        'message': message,
        'timestamp': DateTime.now().toIso8601String(),
      };

      final response = await http.post(
        Uri.parse('$baseUrl/chat/send'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(messageData),
      );

      if (response.statusCode == 200) {
        _messageController.clear();
        _loadMessages();
        _scrollToBottom();
        _focusNode.unfocus();
      }
    } catch (e) {
      print('Error sending message: $e');
    } finally {
      setState(() {
        _isSending = false;
      });
    }
  }

  Future<void> _sendImage() async {
    try {
      final XFile? imageFile =
          await _picker.pickImage(source: ImageSource.gallery);
      if (imageFile == null) return;

      setState(() {
        _isSending = true;
      });

      var request = http.MultipartRequest(
        'POST',
        Uri.parse('$baseUrl/chat/upload-image'),
      );

      request.files.add(await http.MultipartFile.fromPath(
        'image',
        imageFile.path,
      ));
      request.fields['userId'] = widget.username;
      request.fields['username'] = widget.username;
      request.fields['role'] = widget.role;

      final streamedResponse = await request.send();
      final response = await http.Response.fromStream(streamedResponse);

      if (response.statusCode == 200) {
        _loadMessages();
      }
    } catch (e) {
      print('Error sending image: $e');
    } finally {
      setState(() {
        _isSending = false;
      });
    }
  }

  void _scrollToBottom({bool smooth = true}) {
    if (_scrollController.hasClients) {
      if (smooth) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      } else {
        _scrollController.jumpTo(_scrollController.position.maxScrollExtent);
      }
    }
  }

  String _formatTime(String timestamp) {
    try {
      final utcDate = DateTime.parse(timestamp).toUtc();
      final wibDate = utcDate.add(const Duration(hours: 7));
      final hour = wibDate.hour.toString().padLeft(2, '0');
      final minute = wibDate.minute.toString().padLeft(2, '0');
      return '$hour:$minute WIB';
    } catch (e) {
      return timestamp;
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // ROLE BADGE: BMW STYLE
  // ═══════════════════════════════════════════════════════════════
  Widget _buildRoleBadge(String role) {
    Color color;
    switch (role.toLowerCase()) {
      case 'owner':
        color = bmwYellow;
        break;
      case 'reseller':
        color = const Color(0xFFFFA500);
        break;
      case 'admin':
        color = bmwRed;
        break;
      case 'developer':
        color = const Color(0xFF00FF00);
        break;
      case 'moderator':
        color = const Color(0xFF00FFFF);
        break;
      default:
        color = bmwLightBlue;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
      decoration: BoxDecoration(
        color: carbonBlack.withOpacity(0.8),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: color.withOpacity(0.9), width: 1.2),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.3),
            blurRadius: 6,
          ),
        ],
      ),
      child: Text(
        role.toUpperCase(),
        style: TextStyle(
          color: color,
          fontSize: 9,
          fontWeight: FontWeight.w900,
          letterSpacing: 1.0,
          shadows: const [
            Shadow(color: Colors.black, blurRadius: 3),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // MESSAGE BUBBLE: BMW STYLE
  // ═══════════════════════════════════════════════════════════════
  Widget _buildMessageBubble(ChatMessage message) {
    final isMe = message.userId == widget.username;
    final isDeleted = message.isDeleted;

    if (isDeleted) {
      return Container(
        margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 12),
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: carbonMid.withOpacity(0.85),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: bmwSilver.withOpacity(0.3), width: 1),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: carbonLight,
                  shape: BoxShape.circle,
                  border: Border.all(color: bmwSilver.withOpacity(0.5)),
                ),
                child: Icon(Icons.delete_outline,
                    color: bmwSilver.withOpacity(0.8), size: 14),
              ),
              const SizedBox(width: 10),
              Text(
                'Pesan ini telah dihapus',
                style: TextStyle(
                  color: bmwSilver.withOpacity(0.7),
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                  fontStyle: FontStyle.italic,
                ),
              ),
            ],
          ),
        ),
      );
    }

    final isSameSender = _messages.indexOf(message) > 0 &&
        _messages[_messages.indexOf(message) - 1].userId == message.userId;

    return Container(
      margin: EdgeInsets.only(
        top: isSameSender ? 2 : 8,
        bottom: 4,
        left: isMe ? 60 : 12,
        right: isMe ? 12 : 60,
      ),
      child: Column(
        crossAxisAlignment:
            isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: [
          if (!isMe && !isSameSender)
            Padding(
              padding: const EdgeInsets.only(left: 4, bottom: 6),
              child: Row(
                children: [
                  // Avatar dengan ring BMW stripe
                  Container(
                    width: 36,
                    height: 36,
                    padding: const EdgeInsets.all(2),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const LinearGradient(
                        colors: [bmwBlue, bmwLightBlue, bmwRed],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: bmwBlue.withOpacity(0.35),
                          blurRadius: 8,
                          spreadRadius: 1,
                        ),
                        BoxShadow(
                          color: Colors.black.withOpacity(0.5),
                          blurRadius: 6,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Container(
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: carbonBlack,
                      ),
                      padding: const EdgeInsets.all(1.5),
                      child: ClipOval(
                        child: Image.asset(
                          message.avatarUrl,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) {
                            return Container(
                              decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                color: carbonLight,
                              ),
                              child: const Icon(Icons.person,
                                  color: bmwSilver, size: 14),
                            );
                          },
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            message.username,
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w800,
                              fontSize: 13,
                              letterSpacing: 0.3,
                              shadows: _textShadows,
                            ),
                          ),
                          const SizedBox(width: 6),
                          _buildRoleBadge(message.role),
                        ],
                      ),
                      const SizedBox(height: 3),
                      Text(
                        _formatTime(message.timestamp),
                        style: TextStyle(
                          color: bmwSilver.withOpacity(0.85),
                          fontSize: 10,
                          fontWeight: FontWeight.w500,
                          letterSpacing: 0.3,
                          shadows: const [
                            Shadow(color: Colors.black, blurRadius: 4),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          MouseRegion(
            cursor: SystemMouseCursors.basic,
            child: Material(
              color: Colors.transparent,
              child: Container(
                constraints: BoxConstraints(
                  maxWidth: MediaQuery.of(context).size.width * 0.65,
                ),
                child: Column(
                  crossAxisAlignment:
                      isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                  children: [
                    if (message.imageUrl != null)
                      Container(
                        margin: const EdgeInsets.only(bottom: 4),
                        child: MouseRegion(
                          cursor: SystemMouseCursors.click,
                          child: GestureDetector(
                            onTap: () {
                              showDialog(
                                context: context,
                                builder: (context) => Dialog(
                                  backgroundColor: Colors.transparent,
                                  child: InteractiveViewer(
                                    child: Image.network(
                                      message.imageUrl!,
                                      fit: BoxFit.contain,
                                    ),
                                  ),
                                ),
                              );
                            },
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: bmwYellow.withOpacity(0.5),
                                  width: 1.2,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: bmwYellow.withOpacity(0.15),
                                    blurRadius: 10,
                                  ),
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.5),
                                    blurRadius: 8,
                                    offset: const Offset(0, 2),
                                  ),
                                ],
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(11),
                                child: Image.network(
                                  message.imageUrl!,
                                  width: 240,
                                  height: 150,
                                  fit: BoxFit.cover,
                                  loadingBuilder:
                                      (context, child, loadingProgress) {
                                    if (loadingProgress == null) return child;
                                    return Container(
                                      width: 240,
                                      height: 150,
                                      color: carbonMid,
                                      child: Center(
                                        child: CircularProgressIndicator(
                                          color: bmwYellow,
                                          value: loadingProgress
                                                      .expectedTotalBytes !=
                                                  null
                                              ? loadingProgress
                                                      .cumulativeBytesLoaded /
                                                  loadingProgress
                                                      .expectedTotalBytes!
                                              : null,
                                        ),
                                      ),
                                    );
                                  },
                                  errorBuilder:
                                      (context, error, stackTrace) {
                                    return Container(
                                      width: 240,
                                      height: 150,
                                      color: carbonMid,
                                      child: const Center(
                                        child: Icon(
                                            Icons.broken_image_rounded,
                                            color: bmwSilver,
                                            size: 32),
                                      ),
                                    );
                                  },
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    // Bubble dengan aksen BMW
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(14),
                        gradient: isMe
                            ? LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [
                                  bmwBlue.withOpacity(0.95),
                                  const Color(0xFF003D6B).withOpacity(0.95),
                                ],
                              )
                            : LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [
                                  carbonMid.withOpacity(0.95),
                                  carbonDark.withOpacity(0.95),
                                ],
                              ),
                        border: Border.all(
                          color: isMe
                              ? bmwYellow.withOpacity(0.55)
                              : bmwSilver.withOpacity(0.2),
                          width: 1.2,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: isMe
                                ? bmwBlue.withOpacity(0.3)
                                : Colors.black.withOpacity(0.5),
                            blurRadius: 12,
                            spreadRadius: 1,
                            offset: const Offset(0, 3),
                          ),
                          if (isMe)
                            BoxShadow(
                              color: bmwYellow.withOpacity(0.1),
                              blurRadius: 16,
                            ),
                        ],
                      ),
                      child: Stack(
                        children: [
                          // Aksen BMW stripe di bubble "aku"
                          if (isMe)
                            Positioned(
                              top: 0,
                              left: 0,
                              bottom: 0,
                              width: 3,
                              child: Container(
                                decoration: const BoxDecoration(
                                  gradient: LinearGradient(
                                    begin: Alignment.topCenter,
                                    end: Alignment.bottomCenter,
                                    colors: [bmwBlue, bmwLightBlue, bmwRed],
                                  ),
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(14),
                                    bottomLeft: Radius.circular(14),
                                  ),
                                ),
                              ),
                            ),
                          Padding(
                            padding: const EdgeInsets.all(12),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                if (message.message != null &&
                                    message.message!.isNotEmpty)
                                  Container(
                                    constraints: BoxConstraints(
                                      maxWidth:
                                          MediaQuery.of(context).size.width *
                                              0.5,
                                    ),
                                    child: SelectableText(
                                      message.message!,
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 14,
                                        fontWeight: FontWeight.w500,
                                        height: 1.45,
                                        shadows: [
                                          Shadow(
                                            color: Colors.black87,
                                            blurRadius: 3,
                                            offset: Offset(0, 1),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                const SizedBox(height: 4),
                                Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text(
                                      _formatTime(message.timestamp),
                                      style: TextStyle(
                                        color:
                                            Colors.white.withOpacity(0.85),
                                        fontSize: 10,
                                        fontWeight: FontWeight.w600,
                                        letterSpacing: 0.2,
                                      ),
                                    ),
                                    if (isMe) ...[
                                      const SizedBox(width: 6),
                                      Container(
                                        padding: const EdgeInsets.all(1.5),
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          color:
                                              bmwYellow.withOpacity(0.15),
                                          border: Border.all(
                                            color: bmwYellow
                                                .withOpacity(0.6),
                                            width: 1,
                                          ),
                                        ),
                                        child: const Icon(
                                          Icons.check_rounded,
                                          color: bmwYellow,
                                          size: 9,
                                        ),
                                      ),
                                    ],
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // HEADER: BMW GARAGE STYLE
  // ═══════════════════════════════════════════════════════════════
  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            carbonMid.withOpacity(0.95),
            carbonBlack.withOpacity(0.85),
          ],
        ),
        border: Border(
          bottom: BorderSide(color: bmwYellow.withOpacity(0.3), width: 1),
        ),
        boxShadow: [
          BoxShadow(
            color: bmwBlue.withOpacity(0.15),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
          BoxShadow(
            color: Colors.black.withOpacity(0.6),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Row(
              children: [
                // Avatar dengan BMW ring
                Container(
                  width: 42,
                  height: 42,
                  padding: const EdgeInsets.all(2),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const LinearGradient(
                      colors: [bmwBlue, bmwLightBlue, bmwRed],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: bmwBlue.withOpacity(0.4),
                        blurRadius: 10,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                  child: Container(
                    padding: const EdgeInsets.all(2),
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      color: carbonBlack,
                    ),
                    child: ClipOval(
                      child: Image.asset(
                        'assets/images/logo.jpg',
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) {
                          return Container(
                            decoration: const BoxDecoration(
                              shape: BoxShape.circle,
                              color: carbonLight,
                            ),
                            child: const Icon(Icons.group_rounded,
                                color: bmwSilver, size: 18),
                          );
                        },
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            'BMW GARAGE ROOM',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w900,
                              color: Colors.white,
                              letterSpacing: 1.2,
                              shadows: _textShadows,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 3),
                      Row(
                        children: [
                          // Dot online
                          Container(
                            width: 6,
                            height: 6,
                            decoration: BoxDecoration(
                              color: bmwYellow,
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: bmwYellow.withOpacity(0.7),
                                  blurRadius: 6,
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 6),
                          Text(
                            '${_messages.map((m) => m.userId).toSet().length} DRIVER ONLINE',
                            style: TextStyle(
                              color: bmwSilver.withOpacity(0.9),
                              fontSize: 10,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 1.2,
                              shadows: const [
                                Shadow(color: Colors.black, blurRadius: 4),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                // Tombol refresh ala BMW
                MouseRegion(
                  cursor: SystemMouseCursors.click,
                  child: GestureDetector(
                    onTap: _loadMessages,
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [carbonLight, carbonMid],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: bmwYellow.withOpacity(0.5),
                          width: 1.2,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: bmwYellow.withOpacity(0.15),
                            blurRadius: 8,
                          ),
                        ],
                      ),
                      child: const Icon(Icons.refresh_rounded,
                          color: bmwYellow, size: 20),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            // BMW Stripe bawah header
            _buildBmwStripe(height: 2, width: double.infinity),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // MESSAGE INPUT: BMW PIT BAY STYLE
  // ═══════════════════════════════════════════════════════════════
  Widget _buildMessageInput() {
    return Container(
      margin: const EdgeInsets.all(12),
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              carbonMid.withOpacity(0.95),
              carbonBlack.withOpacity(0.95),
            ],
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: bmwYellow.withOpacity(0.35),
            width: 1.2,
          ),
          boxShadow: [
            BoxShadow(
              color: bmwBlue.withOpacity(0.15),
              blurRadius: 12,
              offset: const Offset(0, 2),
            ),
            BoxShadow(
              color: Colors.black.withOpacity(0.6),
              blurRadius: 12,
              spreadRadius: 1,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            MouseRegion(
              cursor: SystemMouseCursors.click,
              child: GestureDetector(
                onTap: _isSending ? null : _sendImage,
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [carbonLight, carbonMid],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: bmwSilver.withOpacity(0.4),
                      width: 1.2,
                    ),
                  ),
                  child: Icon(
                    Icons.image_rounded,
                    color: _isSending ? bmwSilver : bmwChrome,
                    size: 20,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  color: carbonBlack.withOpacity(0.7),
                  border: Border.all(
                    color: bmwBlue.withOpacity(0.3),
                    width: 1,
                  ),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _messageController,
                        focusNode: _focusNode,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                        ),
                        decoration: InputDecoration(
                          hintText: 'Tulis pesan di pit bay...',
                          hintStyle: TextStyle(
                            color: bmwSilver.withOpacity(0.6),
                            fontSize: 13,
                            letterSpacing: 0.2,
                          ),
                          border: InputBorder.none,
                          contentPadding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 14),
                        ),
                        onSubmitted: (_) => _sendMessage(),
                        maxLines: 2,
                        minLines: 1,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: _isSending
                          ? Container(
                              padding: const EdgeInsets.all(6),
                              child: const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: bmwYellow,
                                ),
                              ),
                            )
                          : MouseRegion(
                              cursor: SystemMouseCursors.click,
                              child: GestureDetector(
                                onTap: _sendMessage,
                                child: Container(
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    gradient: const LinearGradient(
                                      colors: [bmwBlue, bmwLightBlue],
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                    ),
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                      color: bmwYellow.withOpacity(0.7),
                                      width: 1.2,
                                    ),
                                    boxShadow: [
                                      BoxShadow(
                                        color: bmwBlue.withOpacity(0.5),
                                        blurRadius: 10,
                                        spreadRadius: 1,
                                      ),
                                      BoxShadow(
                                        color: bmwYellow.withOpacity(0.2),
                                        blurRadius: 12,
                                      ),
                                    ],
                                  ),
                                  child: const Icon(
                                    Icons.send_rounded,
                                    color: Colors.white,
                                    size: 18,
                                  ),
                                ),
                              ),
                            ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // EMPTY STATE: BMW STYLE
  // ═══════════════════════════════════════════════════════════════
  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 90,
            height: 90,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [carbonMid, carbonBlack],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              border: Border.all(
                color: bmwYellow.withOpacity(0.6),
                width: 2,
              ),
              boxShadow: [
                BoxShadow(
                  color: bmwBlue.withOpacity(0.3),
                  blurRadius: 20,
                  spreadRadius: 3,
                ),
                BoxShadow(
                  color: bmwYellow.withOpacity(0.15),
                  blurRadius: 15,
                ),
              ],
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  width: 62,
                  height: 62,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: bmwBlue.withOpacity(0.6),
                      width: 2,
                    ),
                  ),
                ),
                const Icon(
                  Icons.chat_bubble_outline_rounded,
                  color: bmwYellow,
                  size: 36,
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            'PIT BAY MASIH KOSONG',
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.5,
              shadows: _textShadows,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Mulai percakapan pertama di garasi!',
            style: TextStyle(
              color: bmwSilver.withOpacity(0.9),
              fontSize: 12.5,
              fontWeight: FontWeight.w500,
              letterSpacing: 0.3,
              shadows: const [
                Shadow(color: Colors.black, blurRadius: 4),
              ],
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 16),
          _buildBmwStripe(height: 3, width: 90),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // LOADING STATE: BMW STYLE
  // ═══════════════════════════════════════════════════════════════
  Widget _buildLoadingState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: 70,
            height: 70,
            child: Stack(
              alignment: Alignment.center,
              children: [
                const SizedBox(
                  width: 70,
                  height: 70,
                  child: CircularProgressIndicator(
                    strokeWidth: 3,
                    color: bmwYellow,
                    backgroundColor: Colors.white12,
                  ),
                ),
                Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: bmwBlue.withOpacity(0.7),
                      width: 2,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            'MEMANASKAN MESIN...',
            style: TextStyle(
              color: Colors.white,
              fontSize: 13,
              fontWeight: FontWeight.w900,
              letterSpacing: 2,
              shadows: _textShadows,
            ),
          ),
          const SizedBox(height: 8),
          _buildBmwStripe(height: 2.5, width: 80),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    _scrollController.removeListener(_scrollListener);
    _scrollController.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: carbonBlack,
      body: SafeArea(
        child: Stack(
          children: [
            // ===== BACKGROUND + OVERLAY =====
            _buildBackground(),
            _buildBackgroundOverlay(),

            // ===== BMW TOP STRIPE =====
            _buildTopStripe(),

            // ===== KONTEN UTAMA =====
            Column(
              children: [
                _buildHeader(),
                Expanded(
                  child: Stack(
                    children: [
                      _isLoading
                          ? _buildLoadingState()
                          : _messages.isEmpty
                              ? _buildEmptyState()
                              : ListView.builder(
                                  controller: _scrollController,
                                  padding: const EdgeInsets.only(
                                      top: 12, bottom: 80),
                                  itemCount: _messages.length,
                                  itemBuilder: (context, index) {
                                    return _buildMessageBubble(
                                        _messages[index]);
                                  },
                                ),
                      if (_showScrollButton)
                        Positioned(
                          right: 16,
                          bottom: 80,
                          child: MouseRegion(
                            cursor: SystemMouseCursors.click,
                            child: GestureDetector(
                              onTap: () => _scrollToBottom(),
                              child: Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  gradient: const LinearGradient(
                                    colors: [bmwBlue, bmwLightBlue],
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                  ),
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: bmwYellow.withOpacity(0.7),
                                    width: 1.5,
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: bmwBlue.withOpacity(0.5),
                                      blurRadius: 12,
                                      spreadRadius: 1,
                                    ),
                                    BoxShadow(
                                      color: bmwYellow.withOpacity(0.2),
                                      blurRadius: 14,
                                    ),
                                  ],
                                ),
                                child: const Icon(
                                  Icons.arrow_downward_rounded,
                                  color: Colors.white,
                                  size: 20,
                                ),
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
                _buildMessageInput(),
              ],
            ),
          ],
        ),
      ),
    );
  }
}