// ============================================================
// 🎬 SPLASH SCREEN — Modern Dark Red Comic 3D Edition
// File: splash.dart
// v3 — Revamped: Smooth • Modern • Cinematic
// ============================================================
import 'dart:async';
import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

import 'dashboard_page.dart';

// ═════════════════════════════════════════════════════════════
// 🎨 DARK RED COMIC PALETTE — MODERN
// ═════════════════════════════════════════════════════════════
class _MC {
  static const red          = Color(0xFF8B0000);
  static const redDeep      = Color(0xFF1A0A0A);
  static const redDark      = Color(0xFF4A0000);
  static const redSoft      = Color(0xFF2A0E0E);
  static const redLight     = Color(0xFF3D1414);
  static const accentRed    = Color(0xFFD32F2F);
  static const brightRed    = Color(0xFFFF3B3B);
  static const buttonYellow = Color(0xFFB8860B);
  static const buttonDark   = Color(0xFF1A1A1A);
  static const comicBlack   = Color(0xFF000000);
  static const white        = Color(0xFFFFF5F5);
  static const textGrey     = Color(0xFFC9A0A0);
  static const textLight    = Color(0xFF8A6060);
  static const green        = Color(0xFF22C55E);
  static const greenLite    = Color(0xFF4ADE80);
  static const amber        = Color(0xFFFBBF24);
  static const gold         = Color(0xFFFDE68A);
  static const cream        = Color(0xFF0F0505);

  // ═══ MODERN ADDITIONS ═══
  static const neonRed      = Color(0xFFFF1744);
  static const glassWhite   = Color(0x1AFFFFFF);
  static const glassBorder  = Color(0x33FFFFFF);
  static const deepShadow   = Color(0xCC000000);
}

class SplashScreen extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const SplashScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  VideoPlayerController? _videoCtrl;

  bool _videoReady = false;
  bool _hasNavigated = false;
  bool _videoFinished = false;

  double _videoProgress = 0.0;

  Timer? _fallbackTimer;

  // ═══ CONTROLLERS ═══
  late final AnimationController _entryController;
  late final AnimationController _pulseController;
  late final AnimationController _cosmicController;
  late final AnimationController _logoController;
  late final AnimationController _badgeController;
  late final AnimationController _shimmerController;
  late final AnimationController _orbitController;

  late Animation<double> _badgeSwing;

  late final Animation<double> _fadeAnimation;
  late final Animation<double> _scaleAnimation;
  late final Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();

    // ═══ ENTRY — smoother curve, longer duration ═══
    _entryController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    );

    // ═══ PULSE — softer breathing ═══
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    // ═══ COSMIC — slower drift for elegance ═══
    _cosmicController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 16),
    )..repeat();

    // ═══ LOGO — floating shimmer ═══
    _logoController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2600),
    )..repeat(reverse: true);

    // ═══ SHIMMER — new modern sweep effect ═══
    _shimmerController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2800),
    )..repeat();

    // ═══ ORBIT — new rotating ring accent ═══
    _orbitController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    )..repeat();

    // ═══ SKIP BADGE SWING — subtle modern tilt ═══
    _badgeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2400),
    )..repeat(reverse: true);
    _badgeSwing = Tween<double>(begin: -0.06, end: 0.06).animate(
      CurvedAnimation(parent: _badgeController, curve: Curves.easeInOutSine),
    );

    // ═══ FADE — smoother stagger ═══
    _fadeAnimation = CurvedAnimation(
      parent: _entryController,
      curve: const Interval(
        0.0,
        0.70,
        curve: Curves.easeOutCubic,
      ),
    );

    // ═══ SCALE — subtle pop ═══
    _scaleAnimation = Tween<double>(
      begin: 0.88,
      end: 1.0,
    ).animate(
      CurvedAnimation(
        parent: _entryController,
        curve: const Interval(
          0.0,
          0.85,
          curve: Curves.easeOutBack,
        ),
      ),
    );

    // ═══ SLIDE — gentle float ═══
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.14),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(
        parent: _entryController,
        curve: const Interval(
          0.10,
          0.90,
          curve: Curves.easeOutCubic,
        ),
      ),
    );

    _entryController.forward();

    _initVideo();
  }

  Future<void> _initVideo() async {
    VideoPlayerController? controller;

    try {
      controller = VideoPlayerController.asset(
        'assets/videos/splash.mp4',
      );

      _videoCtrl = controller;

      await controller.initialize();

      if (!mounted || _videoCtrl != controller) {
        controller.dispose();
        return;
      }

      controller.setLooping(false);
      controller.addListener(_onVideoProgress);

      setState(() {
        _videoReady = true;
        _videoProgress = 0.0;
      });

      await controller.play();

      _fallbackTimer = Timer(
        const Duration(seconds: 15),
        () {
          if (mounted && !_hasNavigated) {
            _navigate();
          }
        },
      );
    } catch (_) {
      if (!mounted) return;

      setState(() {
        _videoReady = false;
      });

      _fallbackTimer?.cancel();

      _fallbackTimer = Timer(
        const Duration(seconds: 4),
        () {
          if (mounted && !_hasNavigated) {
            _navigate();
          }
        },
      );
    }
  }

  void _onVideoProgress() {
    final controller = _videoCtrl;

    if (!mounted ||
        controller == null ||
        !controller.value.isInitialized) {
      return;
    }

    final value = controller.value;
    final duration = value.duration;
    final position = value.position;

    if (duration.inMilliseconds > 0) {
      final progress =
          position.inMilliseconds / duration.inMilliseconds;

      if (mounted) {
        setState(() {
          _videoProgress = progress.clamp(0.0, 1.0);
        });
      }

      if (position >= duration &&
          !_videoFinished &&
          !_hasNavigated) {
        _videoFinished = true;
        _navigate();
      }
    }
  }

  void _navigate() {
    if (!mounted || _hasNavigated) return;

    _hasNavigated = true;

    _fallbackTimer?.cancel();

    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 800),
        reverseTransitionDuration:
            const Duration(milliseconds: 450),
        pageBuilder: (_, animation, __) {
          return DashboardPage(
            username: widget.username,
            password: widget.password,
            role: widget.role,
            expiredDate: widget.expiredDate,
            sessionKey: widget.sessionKey,
            listBug: widget.listBug,
            listDoos: widget.listDoos,
            news: widget.news,
          );
        },
        transitionsBuilder: (_, animation, __, child) {
          final curved = CurvedAnimation(
            parent: animation,
            curve: Curves.easeOutCubic,
          );

          return FadeTransition(
            opacity: curved,
            child: ScaleTransition(
              scale: Tween<double>(
                begin: 0.94,
                end: 1.0,
              ).animate(curved),
              child: child,
            ),
          );
        },
      ),
    );
  }

  @override
  void dispose() {
    _fallbackTimer?.cancel();

    final controller = _videoCtrl;

    if (controller != null) {
      controller.removeListener(_onVideoProgress);
      controller.dispose();
    }

    _entryController.dispose();
    _pulseController.dispose();
    _cosmicController.dispose();
    _logoController.dispose();
    _badgeController.dispose();
    _shimmerController.dispose();
    _orbitController.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _MC.cream,
      body: Stack(
        fit: StackFit.expand,
        children: [
          _buildVideoBackground(),
          _buildRedOverlay(),
          _buildCosmicBackground(),
          _buildMainContent(),
          _buildBottomProgress(),
          _buildSkipBadge(),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // VIDEO BACKGROUND
  // ═══════════════════════════════════════════════════════════
  Widget _buildVideoBackground() {
    final controller = _videoCtrl;

    if (!_videoReady ||
        controller == null ||
        !controller.value.isInitialized) {
      return Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.center,
            radius: 1.15,
            colors: [
              _MC.red,
              _MC.redDark,
              _MC.cream,
            ],
          ),
        ),
      );
    }

    return Positioned.fill(
      child: FittedBox(
        fit: BoxFit.cover,
        child: SizedBox(
          width: controller.value.size.width,
          height: controller.value.size.height,
          child: VideoPlayer(controller),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // RED OVERLAY — modern vignette
  // ═══════════════════════════════════════════════════════════
  Widget _buildRedOverlay() {
    return Positioned.fill(
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              _MC.redDeep.withOpacity(0.30),
              _MC.red.withOpacity(0.28),
              _MC.redDeep.withOpacity(0.62),
              _MC.cream.withOpacity(0.96),
            ],
            stops: const [0.0, 0.35, 0.68, 1.0],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // COSMIC PARTICLES — modern layered
  // ═══════════════════════════════════════════════════════════
  Widget _buildCosmicBackground() {
    return Positioned.fill(
      child: IgnorePointer(
        child: AnimatedBuilder(
          animation: Listenable.merge([
            _cosmicController,
            _orbitController,
          ]),
          builder: (_, __) {
            return CustomPaint(
              painter: _CosmicPainter(
                progress: _cosmicController.value,
                orbit: _orbitController.value,
              ),
            );
          },
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // MAIN CONTENT
  // ═══════════════════════════════════════════════════════════
  Widget _buildMainContent() {
    return SafeArea(
      child: Center(
        child: AnimatedBuilder(
          animation: Listenable.merge([
            _entryController,
            _logoController,
            _shimmerController,
          ]),
          builder: (context, child) {
            return FadeTransition(
              opacity: _fadeAnimation,
              child: SlideTransition(
                position: _slideAnimation,
                child: ScaleTransition(
                  scale: _scaleAnimation,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _buildLogo(),
                        const SizedBox(height: 26),
                        _buildTitle(),
                        const SizedBox(height: 12),
                        _buildQuote(),
                        const SizedBox(height: 24),
                        _buildStatusCard(),
                      ],
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // LOGO — modern comic + orbit ring + shimmer
  // ═══════════════════════════════════════════════════════════
  Widget _buildLogo() {
    return AnimatedBuilder(
      animation: Listenable.merge([
        _pulseController,
        _logoController,
        _orbitController,
      ]),
      builder: (_, __) {
        final pulse = 1.0 + (_pulseController.value * 0.04);
        final float = math.sin(_logoController.value * math.pi * 2) * 3.0;
        final orbitAngle = _orbitController.value * math.pi * 2;

        return Transform.translate(
          offset: Offset(0, float),
          child: Transform.scale(
            scale: pulse,
            child: SizedBox(
              width: 150,
              height: 150,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  // ═══ ORBIT RING — modern accent ═══
                  Transform.rotate(
                    angle: orbitAngle,
                    child: CustomPaint(
                      size: const Size(150, 150),
                      painter: _OrbitRingPainter(),
                    ),
                  ),
                  // ═══ MAIN LOGO CIRCLE ═══
                  Container(
                    width: 120,
                    height: 120,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          _MC.accentRed,
                          _MC.red,
                          _MC.redDark,
                        ],
                      ),
                      border: Border.all(
                        color: _MC.comicBlack,
                        width: 4.5,
                      ),
                      boxShadow: [
                        const BoxShadow(
                          color: _MC.comicBlack,
                          offset: Offset(6, 7),
                          blurRadius: 0,
                        ),
                        BoxShadow(
                          color: _MC.neonRed.withOpacity(0.35),
                          offset: const Offset(0, 0),
                          blurRadius: 24,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: Container(
                      margin: const EdgeInsets.all(7),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _MC.redDeep,
                        border: Border.all(
                          color: _MC.comicBlack,
                          width: 3,
                        ),
                      ),
                      child: const Icon(
                        Icons.auto_awesome_rounded,
                        color: _MC.white,
                        size: 48,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════
  // TITLE — comic panel with shimmer sweep
  // ═══════════════════════════════════════════════════════════
  Widget _buildTitle() {
    return Column(
      children: [
        AnimatedBuilder(
          animation: _shimmerController,
          builder: (_, __) {
            final shimmerPos =
                (_shimmerController.value * 3.0) - 1.0;

            return Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 22,
                vertical: 12,
              ),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: const [
                    _MC.accentRed,
                    _MC.red,
                    _MC.redDark,
                  ],
                  stops: const [0.0, 0.5, 1.0],
                ),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: _MC.comicBlack,
                  width: 3.5,
                ),
                boxShadow: [
                  const BoxShadow(
                    color: _MC.comicBlack,
                    offset: Offset(5, 6),
                    blurRadius: 0,
                  ),
                  BoxShadow(
                    color: _MC.brightRed.withOpacity(0.25),
                    offset: const Offset(0, 0),
                    blurRadius: 20,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: Stack(
                children: [
                  // ═══ SHIMMER SWEEP ═══
                  Positioned.fill(
                    child: IgnorePointer(
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(13),
                        child: Transform.translate(
                          offset: Offset(shimmerPos * 220, 0),
                          child: Container(
                            width: 60,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Colors.transparent,
                                  _MC.white.withOpacity(0.25),
                                  Colors.transparent,
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  const Text(
                    'X-SPYDER PROJECT',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: _MC.white,
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2,
                      fontFamily: 'ARABOLIC',
                      shadows: [
                        Shadow(
                          color: _MC.comicBlack,
                          offset: Offset(2, 2),
                          blurRadius: 0,
                        ),
                        Shadow(
                          color: _MC.neonRed,
                          offset: Offset(0, 0),
                          blurRadius: 12,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
        const SizedBox(height: 14),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 24,
              height: 1.5,
              color: _MC.brightRed.withOpacity(0.6),
            ),
            const SizedBox(width: 10),
            const Text(
              'NEXT GENERATION DASHBOARD',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: _MC.textGrey,
                fontSize: 10,
                fontWeight: FontWeight.w800,
                letterSpacing: 3.0,
              ),
            ),
            const SizedBox(width: 10),
            Container(
              width: 24,
              height: 1.5,
              color: _MC.brightRed.withOpacity(0.6),
            ),
          ],
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════
  // QUOTE — glassy modern panel
  // ═══════════════════════════════════════════════════════════
  Widget _buildQuote() {
    return Column(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
            child: Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 12,
              ),
              decoration: BoxDecoration(
                color: _MC.glassWhite,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: _MC.glassBorder,
                  width: 1.5,
                ),
                boxShadow: const [
                  BoxShadow(
                    color: _MC.deepShadow,
                    offset: Offset(0, 6),
                    blurRadius: 18,
                  ),
                ],
              ),
              child: const Text(
                '“Setiap perjalanan dimulai dari satu langkah.”',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: _MC.white,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  fontStyle: FontStyle.italic,
                  height: 1.4,
                  shadows: [
                    Shadow(
                      color: _MC.comicBlack,
                      offset: Offset(1, 1),
                      blurRadius: 2,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 12),
        const Text(
          'Powered By @Oxypengenfemes',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: _MC.amber,
            fontSize: 9,
            fontWeight: FontWeight.w900,
            letterSpacing: 1.4,
          ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════
  // STATUS CARD — modern comic + glass
  // ═══════════════════════════════════════════════════════════
  Widget _buildStatusCard() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 14,
          ),
          decoration: BoxDecoration(
            color: _MC.redSoft.withOpacity(0.55),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: _MC.comicBlack,
              width: 3.5,
            ),
            boxShadow: [
              const BoxShadow(
                color: _MC.comicBlack,
                offset: Offset(5, 6),
                blurRadius: 0,
              ),
              BoxShadow(
                color: _MC.brightRed.withOpacity(0.15),
                offset: const Offset(0, 0),
                blurRadius: 22,
                spreadRadius: 1,
              ),
            ],
          ),
          child: Row(
            children: [
              _buildStatusIcon(),
              const SizedBox(width: 13),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _videoReady
                          ? 'SYSTEM READY'
                          : 'INITIALIZING SYSTEM',
                      style: const TextStyle(
                        color: _MC.white,
                        fontSize: 11,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.1,
                        fontFamily: 'Astral',
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      _videoReady
                          ? 'Preparing your dashboard...'
                          : 'Loading splash experience...',
                      style: const TextStyle(
                        color: _MC.textGrey,
                        fontSize: 9.5,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              AnimatedBuilder(
                animation: _pulseController,
                builder: (_, __) {
                  return Opacity(
                    opacity: 0.45 + (_pulseController.value * 0.55),
                    child: Container(
                      width: 34,
                      height: 34,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: const RadialGradient(
                          colors: [
                            _MC.brightRed,
                            _MC.red,
                          ],
                        ),
                        border: Border.all(
                          color: _MC.comicBlack,
                          width: 2,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: _MC.neonRed.withOpacity(0.4),
                            offset: const Offset(0, 0),
                            blurRadius: 12,
                            spreadRadius: 1,
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.wifi_tethering_rounded,
                        color: _MC.white,
                        size: 18,
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatusIcon() {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 350),
      curve: Curves.easeOutCubic,
      width: 42,
      height: 42,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: _videoReady
              ? const [_MC.greenLite, _MC.green]
              : const [_MC.gold, _MC.amber],
        ),
        border: Border.all(
          color: _MC.comicBlack,
          width: 2.5,
        ),
        boxShadow: const [
          BoxShadow(
            color: _MC.comicBlack,
            offset: Offset(2, 2),
            blurRadius: 0,
          ),
        ],
      ),
      child: Icon(
        _videoReady ? Icons.check_rounded : Icons.bolt_rounded,
        color: _MC.white,
        size: 21,
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // VIDEO PROGRESS — modern glass bar
  // ═══════════════════════════════════════════════════════════
  Widget _buildBottomProgress() {
    return Positioned(
      left: 28,
      right: 28,
      bottom: 60,
      child: AnimatedOpacity(
        duration: const Duration(milliseconds: 600),
        curve: Curves.easeOutCubic,
        opacity: _videoReady ? 1.0 : 0.35,
        child: Column(
          children: [
            Row(
              children: [
                Text(
                  _videoReady
                      ? '${(_videoProgress * 100).round()}%'
                      : 'LOADING',
                  style: const TextStyle(
                    color: _MC.textGrey,
                    fontSize: 9,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1,
                  ),
                ),
                const Spacer(),
                const Text(
                  'X-SPYDER',
                  style: TextStyle(
                    color: _MC.textGrey,
                    fontSize: 9,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 6, sigmaY: 6),
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: _MC.comicBlack,
                      width: 2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: _MC.neonRed.withOpacity(0.2),
                        offset: const Offset(0, 0),
                        blurRadius: 10,
                        spreadRadius: 0,
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(18),
                    child: Container(
                      height: 8,
                      color: _MC.buttonDark.withOpacity(0.85),
                      child: FractionallySizedBox(
                        alignment: Alignment.centerLeft,
                        widthFactor: _videoReady ? _videoProgress : 0.18,
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 350),
                          curve: Curves.easeOutCubic,
                          decoration: const BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                _MC.brightRed,
                                _MC.neonRed,
                                _MC.accentRed,
                              ],
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: _MC.neonRed,
                                offset: Offset(0, 0),
                                blurRadius: 8,
                                spreadRadius: 0,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // 🟡 SKIP BUTTON — modern 3D comic (Kanana Atas)
  // ═══════════════════════════════════════════════════════════
  Widget _buildSkipBadge() {
    return Positioned(
      top: 20,
      right: 20,
      child: SafeArea(
        child: AnimatedBuilder(
          animation: _badgeSwing,
          builder: (_, __) {
            return Transform.rotate(
              angle: _badgeSwing.value,
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: _navigate,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 10,
                  ),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        _MC.gold,
                        _MC.buttonYellow,
                        _MC.amber,
                      ],
                    ),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: _MC.comicBlack,
                      width: 3.5,
                    ),
                    boxShadow: [
                      const BoxShadow(
                        color: _MC.comicBlack,
                        offset: Offset(4, 5),
                        blurRadius: 0,
                      ),
                      BoxShadow(
                        color: _MC.amber.withOpacity(0.35),
                        offset: const Offset(0, 0),
                        blurRadius: 16,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.skip_next_rounded,
                        color: _MC.comicBlack,
                        size: 18,
                      ),
                      SizedBox(width: 6),
                      Text(
                        'SKIP INTRO',
                        style: TextStyle(
                          color: _MC.comicBlack,
                          fontSize: 12,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 2,
                          fontFamily: 'Astral',
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

// ═════════════════════════════════════════════════════════════
// 🎨 ORBIT RING PAINTER — modern accent
// ═════════════════════════════════════════════════════════════
class _OrbitRingPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width * 0.48;

    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5
      ..strokeCap = StrokeCap.round;

    // ═══ DASHED ORBIT ═══
    const dashCount = 24;
    for (int i = 0; i < dashCount; i++) {
      final angle = (i / dashCount) * math.pi * 2;
      final startAngle = angle;
      final sweepAngle = (math.pi * 2) / dashCount * 0.5;

      paint.color = i % 2 == 0
          ? _MC.brightRed.withOpacity(0.55)
          : _MC.amber.withOpacity(0.25);

      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        startAngle,
        sweepAngle,
        false,
        paint,
      );
    }

    // ═══ ACCENT DOT ═══
    final dotAngle = -math.pi / 2;
    final dotPos = Offset(
      center.dx + radius * math.cos(dotAngle),
      center.dy + radius * math.sin(dotAngle),
    );

    final dotPaint = Paint()
      ..color = _MC.brightRed
      ..style = PaintingStyle.fill;

    canvas.drawCircle(dotPos, 3.5, dotPaint);

    final dotGlow = Paint()
      ..color = _MC.neonRed.withOpacity(0.5)
      ..style = PaintingStyle.fill
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6);

    canvas.drawCircle(dotPos, 6, dotGlow);
  }

  @override
  bool shouldRepaint(covariant _OrbitRingPainter oldDelegate) => false;
}

// ═════════════════════════════════════════════════════════════
// 🎨 COSMIC PAINTER — modern layered (Dark Red)
// ═════════════════════════════════════════════════════════════
class _CosmicPainter extends CustomPainter {
  final double progress;
  final double orbit;

  _CosmicPainter({
    required this.progress,
    required this.orbit,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final random = math.Random(2026);

    final particlePaint = Paint()..style = PaintingStyle.fill;

    // ═══ LAYER 1: Distant stars ═══
    for (int i = 0; i < 50; i++) {
      final x = random.nextDouble() * size.width;
      final baseY = random.nextDouble() * size.height;

      final movement =
          math.sin((progress * math.pi * 2) + i) * 6;

      final y = baseY + movement;

      final radius = 0.4 + random.nextDouble() * 1.2;

      final opacity = 0.12 +
          0.28 *
              (0.5 +
                  0.5 *
                      math.sin(
                        (progress * math.pi * 2) + i,
                      ));

      particlePaint.color = _MC.white.withOpacity(
        opacity.clamp(0.05, 0.45),
      );

      canvas.drawCircle(Offset(x, y), radius, particlePaint);
    }

    // ═══ LAYER 2: Bright foreground particles (red glow) ═══
    for (int i = 0; i < 25; i++) {
      final x = random.nextDouble() * size.width;
      final baseY = random.nextDouble() * size.height;

      final movement =
          math.cos((progress * math.pi * 2) + i * 1.3) * 10;

      final y = baseY + movement;

      final radius = 0.8 + random.nextDouble() * 2.0;

      final opacity = 0.15 +
          0.35 *
              (0.5 +
                  0.5 *
                      math.cos(
                        (progress * math.pi * 2) + i * 1.3,
                      ));

      particlePaint.color = _MC.brightRed.withOpacity(
        opacity.clamp(0.05, 0.50),
      );

      canvas.drawCircle(Offset(x, y), radius, particlePaint);
    }

    // ═══ LAYER 3: Orbital rings ═══
    final center = Offset(
      size.width * 0.5,
      size.height * 0.42,
    );

    final ringPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5
      ..color = _MC.brightRed.withOpacity(0.18);

    final rotation = progress * math.pi * 2;
    final orbitRotation = orbit * math.pi * 2;

    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.rotate(rotation);

    canvas.drawOval(
      Rect.fromCenter(
        center: Offset.zero,
        width: size.width * 0.85,
        height: size.width * 0.28,
      ),
      ringPaint,
    );

    canvas.rotate(math.pi / 3);

    canvas.drawOval(
      Rect.fromCenter(
        center: Offset.zero,
        width: size.width * 0.72,
        height: size.width * 0.22,
      ),
      ringPaint,
    );

    canvas.restore();

    // ═══ LAYER 4: Counter-rotating outer ring ═══
    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.rotate(-orbitRotation * 0.5);

    final outerRingPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0
      ..color = _MC.amber.withOpacity(0.12);

    canvas.drawOval(
      Rect.fromCenter(
        center: Offset.zero,
        width: size.width * 0.95,
        height: size.width * 0.35,
      ),
      outerRingPaint,
    );

    canvas.restore();

    // ═══ LAYER 5: Central glow ═══
    final glowPaint = Paint()
      ..shader = RadialGradient(
        colors: [
          _MC.red.withOpacity(0.15),
          _MC.red.withOpacity(0.0),
        ],
      ).createShader(
        Rect.fromCircle(
          center: center,
          radius: size.width * 0.45,
        ),
      );

    canvas.drawCircle(
      center,
      size.width * 0.45,
      glowPaint,
    );

    // ═══ LAYER 6: Neon pulse at center ═══
    final pulseRadius =
        size.width * (0.08 + 0.02 * math.sin(progress * math.pi * 4));

    final pulsePaint = Paint()
      ..color = _MC.neonRed.withOpacity(0.08)
      ..style = PaintingStyle.fill
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 30);

    canvas.drawCircle(center, pulseRadius, pulsePaint);
  }

  @override
  bool shouldRepaint(
    covariant _CosmicPainter oldDelegate,
  ) {
    return oldDelegate.progress != progress ||
        oldDelegate.orbit != orbit;
  }
}