import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'dashboard_page.dart';

class SplashScreen extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String sessionKey;
  final String expiredDate;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const SplashScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.sessionKey,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late VideoPlayerController _videoController;
  late AnimationController _fadeController;
  late AnimationController _shimmerController;

  bool _fadeOutStarted = false;
  double _progress = 0.0;

  // ─── 🏁 BMW M GARAGE PALETTE ──────────────────────────────
  static const Color garageBlack   = Color(0xFF0A0A0A);
  static const Color carbonDark    = Color(0xFF121212);
  static const Color cardColor     = Color(0xFF1A1A1A);
  static const Color chromeSilver  = Color(0xFFC8C8C8);
  static const Color bmwLightBlue  = Color(0xFF0066B1);
  static const Color bmwDarkBlue   = Color(0xFF0F3D77);
  static const Color bmwRed        = Color(0xFFE32119);
  static const Color bmwBlueGlow   = Color(0xFF1C69D4);
  static const Color textPrimary   = Color(0xFFF5F5F5);
  static const Color textSecondary = Color(0xFF9E9E9E);

  @override
  void initState() {
    super.initState();

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1),
    );

    _shimmerController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat();

    _videoController = VideoPlayerController.asset(
      "assets/videos/splash.mp4",
    )..initialize().then((_) {
        setState(() {});
        _videoController
          ..setLooping(false)
          ..play();

        _videoController.addListener(_videoListener);
      });
  }

  void _videoListener() {
    final position = _videoController.value.position;
    final duration = _videoController.value.duration;

    if (duration.inMilliseconds > 0) {
      setState(() {
        _progress = position.inMilliseconds / duration.inMilliseconds;
        _progress = _progress.clamp(0.0, 1.0);
      });

      if (position >= duration - const Duration(seconds: 1) &&
          !_fadeOutStarted) {
        _fadeOutStarted = true;
        _fadeController.forward();
      }

      if (position >= duration) {
        _navigateToDashboard();
      }
    }
  }

  void _navigateToDashboard() {
    _videoController.removeListener(_videoListener);

    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => DashboardPage(
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          listDoos: widget.listDoos,
          news: widget.news,
        ),
      ),
    );
  }

  @override
  void dispose() {
    _videoController.dispose();
    _fadeController.dispose();
    _shimmerController.dispose();
    super.dispose();
  }

  // 🏁 M-Stripe Widget
  Widget _mStripe({double height = 3, double width = 40}) {
    return Container(
      height: height,
      width: width,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(2),
        gradient: const LinearGradient(
          colors: [bmwLightBlue, bmwDarkBlue, bmwRed],
          stops: [0.0, 0.5, 1.0],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: garageBlack,
      body: Stack(
        alignment: Alignment.center,
        children: [
          // ─── CARBON BACKGROUND ───
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [carbonDark, garageBlack, Color(0xFF050505)],
                ),
              ),
            ),
          ),

          // ─── BLUE HEADLIGHT GLOW (TOP-LEFT) ───
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: const Alignment(-0.8, -0.7),
                  radius: 1.4,
                  colors: [
                    bmwBlueGlow.withOpacity(0.12),
                    Colors.transparent,
                  ],
                  stops: const [0.0, 1.0],
                ),
              ),
            ),
          ),

          // ─── RED TAIL-LIGHT GLOW (BOTTOM-RIGHT) ───
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: const Alignment(1.0, 1.0),
                  radius: 1.2,
                  colors: [
                    bmwRed.withOpacity(0.08),
                    Colors.transparent,
                  ],
                  stops: const [0.0, 1.0],
                ),
              ),
            ),
          ),

          // ─── CARBON GRID ───
          Positioned.fill(
              child: CustomPaint(painter: _GridPatternPainter())),

          /// ─── VIDEO FRAME (CHROME + M-GRADIENT BORDER) ───
          if (_videoController.value.isInitialized)
            Center(
              child: Stack(
                alignment: Alignment.center,
                children: [
                  // Outer glow
                  Container(
                    width: MediaQuery.of(context).size.width * 0.8 + 20,
                    height: (MediaQuery.of(context).size.width * 0.8) /
                            _videoController.value.aspectRatio +
                        20,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(32),
                      boxShadow: [
                        BoxShadow(
                          color: bmwBlueGlow.withOpacity(0.35),
                          blurRadius: 40,
                          spreadRadius: 5,
                        ),
                        BoxShadow(
                          color: bmwRed.withOpacity(0.15),
                          blurRadius: 50,
                          spreadRadius: 3,
                        ),
                      ],
                    ),
                  ),
                  // Chrome frame
                  ClipRRect(
                    borderRadius: BorderRadius.circular(30),
                    child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
                      child: Container(
                        width: MediaQuery.of(context).size.width * 0.8,
                        padding: const EdgeInsets.all(3),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [
                              bmwLightBlue,
                              chromeSilver,
                              bmwRed,
                            ],
                            stops: [0.0, 0.5, 1.0],
                          ),
                          borderRadius: BorderRadius.circular(30),
                        ),
                        child: Container(
                          decoration: BoxDecoration(
                            color: garageBlack,
                            borderRadius: BorderRadius.circular(28),
                            border: Border.all(
                              color: chromeSilver.withOpacity(0.3),
                              width: 0.5,
                            ),
                          ),
                          padding: const EdgeInsets.all(2),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(26),
                            child: AspectRatio(
                              aspectRatio:
                                  _videoController.value.aspectRatio,
                              child: VideoPlayer(_videoController),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  // Top M-stripe accent
                  Positioned(
                    top: 6,
                    left: 40,
                    right: 40,
                    child: _mStripe(
                        height: 3, width: double.infinity),
                  ),
                ],
              ),
            )
          else
            Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(
                    width: 50,
                    height: 50,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      valueColor: const AlwaysStoppedAnimation<Color>(
                          bmwBlueGlow),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    "IGNITION STARTING...",
                    style: TextStyle(
                      color: chromeSilver.withOpacity(0.7),
                      fontSize: 11,
                      letterSpacing: 3,
                      fontFamily: 'ShareTechMono',
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),

          /// ─── SKIP BUTTON (PIT STOP STYLE) ───
          Positioned(
            top: 50,
            right: 20,
            child: AnimatedOpacity(
              opacity: _progress < 1 ? 1.0 : 0.0,
              duration: const Duration(milliseconds: 300),
              child: GestureDetector(
                onTap: () {
                  _videoController.removeListener(_videoListener);
                  _videoController.pause();
                  _navigateToDashboard();
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 9,
                  ),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        cardColor.withOpacity(0.85),
                        carbonDark.withOpacity(0.9),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: chromeSilver.withOpacity(0.3),
                      width: 1,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.4),
                        blurRadius: 10,
                      ),
                    ],
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 6,
                        height: 6,
                        decoration: BoxDecoration(
                          color: bmwRed,
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: bmwRed.withOpacity(0.8),
                              blurRadius: 6,
                              spreadRadius: 1,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      const Text(
                        "SKIP INTRO",
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 2,
                          fontSize: 11,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),

          /// ─── TEXT & TELEMETRY PROGRESS ───
          Positioned(
            bottom: 60,
            left: 40,
            right: 40,
            child: Column(
              children: [
                // ── TOP TELEMETRY BADGE ──
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: cardColor.withOpacity(0.7),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: chromeSilver.withOpacity(0.2),
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 6,
                        height: 6,
                        decoration: BoxDecoration(
                          color: bmwBlueGlow,
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: bmwBlueGlow.withOpacity(0.8),
                              blurRadius: 8,
                              spreadRadius: 1,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        "ENGINE WARMING UP  ///M SYSTEM",
                        style: TextStyle(
                          color: chromeSilver.withOpacity(0.85),
                          fontSize: 9,
                          letterSpacing: 2,
                          fontFamily: 'ShareTechMono',
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 20),

                // ── TITLE "GHOST CRASHER" WITH CHROME GRADIENT ──
                ShaderMask(
                  shaderCallback: (bounds) => const LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Color(0xFFFFFFFF),
                      Color(0xFFC8C8C8),
                      Color(0xFF7A7A7A),
                    ],
                    stops: [0.0, 0.5, 1.0],
                  ).createShader(bounds),
                  child: const Text(
                    "GHOSTCRASHER",
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      letterSpacing: 6,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                ),
                const SizedBox(height: 12),

                // ── M-STRIPE DIVIDER ──
                _mStripe(height: 3, width: 100),

                const SizedBox(height: 12),

                // ── DEVELOPER TAG ──
                Text(
                  "/// POWERED BY · @Skylinnereal",
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    color: chromeSilver.withOpacity(0.7),
                    letterSpacing: 2.5,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
                const SizedBox(height: 32),

                // ── TELEMETRY PROGRESS BAR ──
                Row(
                  children: [
                    Text(
                      "LOADING",
                      style: TextStyle(
                        color: chromeSilver.withOpacity(0.6),
                        fontSize: 9,
                        letterSpacing: 2,
                        fontFamily: 'ShareTechMono',
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Container(
                        height: 5,
                        decoration: BoxDecoration(
                          color: garageBlack,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            color: chromeSilver.withOpacity(0.15),
                            width: 0.5,
                          ),
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: FractionallySizedBox(
                            widthFactor: _progress,
                            child: Container(
                              decoration: const BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    bmwLightBlue,
                                    bmwDarkBlue,
                                    bmwRed,
                                  ],
                                  stops: [0.0, 0.5, 1.0],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Text(
                      "${(_progress * 100).toStringAsFixed(0)}%",
                      style: const TextStyle(
                        color: textPrimary,
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'ShareTechMono',
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 14),

                // ── STATUS TEXT ──
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(
                      width: 10,
                      height: 10,
                      child: CircularProgressIndicator(
                        strokeWidth: 1.5,
                        valueColor: AlwaysStoppedAnimation<Color>(
                          chromeSilver.withOpacity(0.6),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Text(
                      _progress < 1.0
                          ? "Initializing system modules..."
                          : "System ready",
                      style: TextStyle(
                        color: textSecondary,
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                        letterSpacing: 1.5,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          // ─── FADE OUT OVERLAY ───
          if (_fadeOutStarted)
            FadeTransition(
              opacity: _fadeController,
              child: Container(color: garageBlack),
            ),
        ],
      ),
    );
  }
}

// ─── CARBON GRID PAINTER ───────────────────────────────────────────────────
class _GridPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF1C69D4).withOpacity(0.04)
      ..strokeWidth = 0.5
      ..style = PaintingStyle.stroke;

    const double spacing = 50;
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}