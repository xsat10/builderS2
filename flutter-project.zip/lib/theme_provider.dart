import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ThemeProvider extends ChangeNotifier {
  // ── Default colors (dari _C kamu) ────────────────────────────
  static const Color defaultBg = Color(0xFF06131A);
  static const Color defaultSurface = Color(0xFF0C1D26);
  static const Color defaultCard = Color(0xFF122833);
  static const Color defaultBorder = Color(0xFF2B5D6A);
  static const Color defaultBorderLit = Color(0xFF3A7685);

  static const Color defaultSteel = Color(0xFF2FA9B8);
  static const Color defaultBlueMid = Color(0xFF39C7D9);
  static const Color defaultBlueLight = Color(0xFF5EEFFF);
  static const Color defaultChrome = Color(0xFF67DDE2);
  static const Color defaultFrost = Color(0xFFB7FFF7);

  static const Color defaultGreen = Color(0xFF55D6C2);
  static const Color defaultAmber = Color(0xFF79E6E6);
  static const Color defaultRed = Color(0xFF4CD4D8);

  static const Color defaultText = Color(0xFFEFFFFF);
  static const Color defaultTextSub = Color(0xFFA8D7DF);
  static const Color defaultTextDim = Color(0xFF6F95A0);

  // ── Keys ────────────────────────────────────────────────────
  static const String _kAccent = 'theme_accent_color';
  static const String _kBg = 'theme_bg_color';
  static const String _kDark = 'theme_dark_mode';

  // ── Current colors ──────────────────────────────────────────
  Color _accentColor = defaultBlueLight;
  Color _bgColor = defaultBg;
  bool _isDarkMode = true;

  Color get accentColor => _accentColor;
  Color get bgColor => _bgColor;
  bool get isDarkMode => _isDarkMode;

  // ── Derived colors ──────────────────────────────────────────
  Color get surfaceColor => Color.lerp(_bgColor, Colors.white, 0.06)!;
  Color get cardColor => Color.lerp(_bgColor, Colors.white, 0.10)!;
  Color get borderColor => Color.lerp(_bgColor, Colors.white, 0.20)!;
  Color get borderLitColor => Color.lerp(_bgColor, Colors.white, 0.28)!;

  Color get textColor =>
      _isDarkMode ? const Color(0xFFEFFFFF) : const Color(0xFF1A1A1A);
  Color get textSubColor =>
      _isDarkMode ? const Color(0xFFA8D7DF) : const Color(0xFF555555);
  Color get textDimColor =>
      _isDarkMode ? const Color(0xFF6F95A0) : const Color(0xFF888888);

  // ── Load from prefs ─────────────────────────────────────────
  Future<void> loadTheme() async {
    final prefs = await SharedPreferences.getInstance();
    final accent = prefs.getInt(_kAccent);
    final bg = prefs.getInt(_kBg);
    final dark = prefs.getBool(_kDark);

    if (accent != null) _accentColor = Color(accent);
    if (bg != null) _bgColor = Color(bg);
    if (dark != null) _isDarkMode = dark;

    notifyListeners();
  }

  // ── Set accent ──────────────────────────────────────────────
  Future<void> setAccentColor(Color color) async {
    _accentColor = color;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_kAccent, color.toARGB32());
    notifyListeners();
  }

  // ── Set background ──────────────────────────────────────────
  Future<void> setBgColor(Color color) async {
    _bgColor = color;
    _isDarkMode = color.computeLuminance() < 0.3;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_kBg, color.toARGB32());
    await prefs.setBool(_kDark, _isDarkMode);
    notifyListeners();
  }

  // ── Reset ───────────────────────────────────────────────────
  Future<void> resetTheme() async {
    _accentColor = defaultBlueLight;
    _bgColor = defaultBg;
    _isDarkMode = true;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_kAccent);
    await prefs.remove(_kBg);
    await prefs.remove(_kDark);
    notifyListeners();
  }
}