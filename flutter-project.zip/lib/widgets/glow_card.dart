import 'package:flutter/material.dart';

class GlowCard extends StatelessWidget {
  const GlowCard({
    super.key,
    required this.child,
    this.glow = false,
    this.padding = const EdgeInsets.all(20),
  });

  final Widget child;
  final bool glow;
  final EdgeInsets padding;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: padding,
      decoration: BoxDecoration(
        color: const Color(0xFF0C0C0C),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: glow ? const Color(0x59FF0000) : const Color(0xFF242428),
        ),
        boxShadow: glow
            ? const [
                BoxShadow(
                  color: Color(0x33FF0000),
                  blurRadius: 20,
                ),
              ]
            : null,
      ),
      child: child,
    );
  }
}
