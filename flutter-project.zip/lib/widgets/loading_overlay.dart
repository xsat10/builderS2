import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';

class LoadingOverlay extends StatelessWidget {
  const LoadingOverlay({
    super.key,
    required this.child,
    required this.loading,
  });

  final Widget child;
  final bool loading;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        child,
        if (loading)
          Positioned.fill(
            child: ColoredBox(
              color: const Color(0x99000000),
              child: const Center(
                child: SpinKitFadingCircle(
                  color: Color(0xFFFF0000),
                  size: 42,
                ),
              ),
            ),
          ),
      ],
    );
  }
}
