import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';
import '../theme.dart';
import 'neo_royal_frame.dart';

/// NeoCard — kartu Liquid Glass seragam untuk semua halaman.
/// Translucent gradient + bingkai kerajaan emas (tanpa blur agar scroll ringan).
class NeoCard extends StatelessWidget {
  final Widget child;
  final Color bgColor;
  final EdgeInsetsGeometry padding;
  final double? width;
  final EdgeInsetsGeometry? margin;

  const NeoCard({
    super.key,
    required this.child,
    this.bgColor = NeoColors.white,
    this.padding = const EdgeInsets.all(NeoSpacing.lg),
    this.width,
    this.margin,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final skin = context.watch<NeoThemeProvider>();
    final palette = skin.palette;
    return Container(
      width: width,
      margin: margin,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
            colors: isDark
              ? [Colors.white.withValues(alpha: 0.09), Colors.white.withValues(alpha: 0.03)]
              : [bgColor.withValues(alpha: 0.9), bgColor.withValues(alpha: 0.75)],
        ),
        borderRadius: BorderRadius.circular(NeoRadius.xl),
        boxShadow: const [
          BoxShadow(color: Color(0x3D000000), offset: Offset(0, 12), blurRadius: 28, spreadRadius: -6),
        ],
      ),
      child: RoyalFrame(
        radius: NeoRadius.xl,
        lineColor: const Color(0x8CE5C365),
        cornerColor: const Color(0xE6E5C365),
        child: Padding(
          padding: padding,
          child: child,
        ),
      ),
    );
  }
}
