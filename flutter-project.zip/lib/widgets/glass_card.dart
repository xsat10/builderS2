import 'package:flutter/material.dart';
import '../theme.dart';

/// GlassCard — transparan polos ala iOS/iPadOS (tanpa blur).
/// Background semi-transparan, border gradient gold (laurel),
/// dan soft shadow melayang.
class GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color tint;
  final double opacity;
  final Gradient? borderGradient;
  final Color borderLightColor;
  final BorderRadius? borderRadius;
  final double borderWidth;
  final List<BoxShadow>? boxShadow;
  final VoidCallback? onTap;
  final bool showLaurel; // aksen romawi dekoratif (bukan emoji, border gradient)

  const GlassCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(NeoSpacing.lg),
    this.tint = Colors.white,
    this.opacity = 0.03,
    this.borderGradient,
    this.borderLightColor = const Color(0x66FFD98A),
    this.borderRadius,
    this.borderWidth = 1.2,
    this.boxShadow,
    this.onTap,
    this.showLaurel = true,
  });

  @override
  Widget build(BuildContext context) {
    final radius = borderRadius ?? BorderRadius.circular(NeoRadius.xl);
    final gradient = borderGradient ??
        const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0x66FFD98A),
            Color(0x33FFFFFF),
            Color(0x33C6A15B),
          ],
        );
    final shadow = boxShadow ??
        [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.35),
            blurRadius: 24,
            offset: const Offset(0, 12),
            spreadRadius: -6,
          ),
        ];

    Widget content = Container(
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        borderRadius: radius,
        gradient: gradient,
      ),
      child: Container(
        padding: const EdgeInsets.all(1.2),
        decoration: BoxDecoration(
          borderRadius: radius,
          color: Colors.transparent,
          boxShadow: const [
            BoxShadow(
              color: Colors.white,
              blurRadius: 2,
              spreadRadius: 0,
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(radius.topLeft.x - 1.2),
          child: Container(
            padding: padding,
            decoration: BoxDecoration(
              color: tint.withValues(alpha: opacity),
              borderRadius: BorderRadius.circular(radius.topLeft.x - 1.2),
              border: Border(
                top: BorderSide(color: borderLightColor, width: 1),
                left: BorderSide(color: borderLightColor, width: 0.6),
              ),
            ),
            child: child,
          ),
        ),
      ),
    );

    if (onTap != null) {
      return Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: radius,
          child: Container(
            decoration: BoxDecoration(
              borderRadius: radius,
              boxShadow: shadow,
            ),
            child: content,
          ),
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        borderRadius: radius,
        boxShadow: shadow,
      ),
      child: content,
    );
  }
}

/// GlassCard dengan aksen laurel di atas (dekorasi romawi ringan).
class GlassCardWithHeader extends StatelessWidget {
  final String title;
  final IconData icon;
  final Widget child;
  final EdgeInsetsGeometry padding;

  const GlassCardWithHeader({
    super.key,
    required this.title,
    required this.icon,
    required this.child,
    this.padding = const EdgeInsets.all(NeoSpacing.lg),
  });

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      padding: EdgeInsets.zero,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(NeoSpacing.lg, NeoSpacing.md, NeoSpacing.lg, NeoSpacing.md),
            child: Row(
              children: [
                Container(
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFFFFD98A), Color(0xFFC6A15B)],
                    ),
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFFFFD98A).withValues(alpha: 0.4),
                        blurRadius: 12,
                      ),
                    ],
                  ),
                  child: Icon(icon, size: 18, color: NeoColors.darkCard),
                ),
                const SizedBox(width: NeoSpacing.md),
                Text(
                  title,
                  style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                        color: NeoColors.primaryText,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 1.2,
                      ),
                ),
              ],
            ),
          ),
          const Divider(height: 1, color: Color(0x33FFFFFF)),
          Padding(
            padding: padding,
            child: child,
          ),
        ],
      ),
    );
  }
}
