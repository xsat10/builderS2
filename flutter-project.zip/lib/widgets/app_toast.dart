import 'package:flutter/material.dart';

void showAppToast(BuildContext context, String message, {bool error = false}) {
  final messenger = ScaffoldMessenger.of(context);
  messenger.hideCurrentSnackBar();
  messenger.showSnackBar(
    SnackBar(
      content: Text(
        message,
        style: const TextStyle(color: Color(0xFFF4F4F5)),
      ),
      behavior: SnackBarBehavior.floating,
      backgroundColor:
          error ? const Color(0xFF4A0000) : const Color(0xFF141414),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ),
  );
}
