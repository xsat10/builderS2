import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'api_config.dart';

class OwnerPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const OwnerPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<OwnerPage> createState() => _OwnerPageState();
}

class _OwnerPageState extends State<OwnerPage>
    with TickerProviderStateMixin {
  late String sessionKey;
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];

  // ═══════════════════════════════════════════════════
  //  ROLE OPTIONS — cuma ini yang bisa dibuat
  // ═══════════════════════════════════════════════════
  final List<String> roleOptions = [
    'owner',
    'admin',
    'vip',
    'reseller',
    'member',
  ];

  String selectedRole = 'member';
  String newUserRole = 'member';

  int currentPage = 1;
  int itemsPerPage = 25;

  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  final deleteController = TextEditingController();
  final editUsernameController = TextEditingController();
  final editDayController = TextEditingController();

  bool isLoading = false;

  // ═══════════════════════════════════════════════════
  //  TITAN COLOR PALETTE
  // ═══════════════════════════════════════════════════
  final Color bgDeep = const Color(0xFF050810);
  final Color bgDark = const Color(0xFF0A1220);
  final Color bgCard = const Color(0xFF0E1A2E);
  final Color gold = const Color(0xFFD4AF37);
  final Color goldLight = const Color(0xFFFFD970);
  final Color goldDark = const Color(0xFF8B7420);
  final Color silver = const Color(0xFFC0C0C0);
  final Color cyan = const Color(0xFF00B8D4);
  final Color white = Colors.white;
  final Color textGrey = const Color(0xFF8A95A5);

  // ═══════════════════════════════════════════════════
  //  ANIMASI
  // ═══════════════════════════════════════════════════
  late AnimationController _shineCtrl;
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;

    // Shine sweep controller
    _shineCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat();

    // Pulse glow
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.4, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );

    _fetchUsers();
  }

  @override
  void dispose() {
    _shineCtrl.dispose();
    _pulseCtrl.dispose();
    createUsernameController.dispose();
    createPasswordController.dispose();
    createDayController.dispose();
    deleteController.dispose();
    editUsernameController.dispose();
    editDayController.dispose();
    super.dispose();
  }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse(
            'http://deylegal-panel.pterodactylxcz.my.id:2151/listUsers?key=$sessionKey'),
      );
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _alert("Info", data['message'] ?? 'Gagal memuat user.');
      }
    } catch (_) {
      _alert("Error", "Gagal terhubung ke server.");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList =
          fullUserList.where((u) => u['role'] == selectedRole).toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = (start + itemsPerPage);
    return filteredList.sublist(
      start,
      end > filteredList.length ? filteredList.length : end,
    );
  }

  int get totalPages => (filteredList.length / itemsPerPage).ceil();

  Future<void> _deleteUser() async {
    final username = deleteController.text.trim();
    if (username.isEmpty) {
      _alert("Peringatan", "Masukkan username yang ingin dihapus.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse(
            'http://deylegal-panel.pterodactylxcz.my.id:2151/deleteUser?key=$sessionKey&username=$username'),
      );
      final data = jsonDecode(res.body);

      if (data['deleted'] == true) {
        _alert("Sukses", "User berhasil dihapus.");
        deleteController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal menghapus user.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _createAccount() async {
    final u = createUsernameController.text.trim();
    final p = createPasswordController.text.trim();
    final d = createDayController.text.trim();

    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
        'http://deylegal-panel.pterodactylxcz.my.id:2151/userAdd?key=$sessionKey&username=$u&password=$p&day=$d&role=$newUserRole',
      );
      final res = await http.get(url);
      final data = jsonDecode(res.body);

      if (data['created'] == true) {
        _alert("Sukses",
            "Akun berhasil dibuat sebagai ${newUserRole.toUpperCase()}.");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        newUserRole = 'member';
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal membuat akun.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _editUser() async {
    final u = editUsernameController.text.trim();
    final d = editDayController.text.trim();

    if (u.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
        'http://deylegal-panel.pterodactylxcz.my.id:2151/editUser?key=$sessionKey&username=$u&addDays=$d',
      );
      final res = await http.get(url);
      final data = jsonDecode(res.body);

      if (data['edited'] == true) {
        _alert("Sukses", "Durasi berhasil diperbarui.");
        editUsernameController.clear();
        editDayController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal mengubah durasi.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  // ═══════════════════════════════════════════════════
  //  ALERT DIALOG — TITAN STYLE
  // ═══════════════════════════════════════════════════
  void _alert(String title, String message) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [bgCard, bgDark],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: gold.withOpacity(0.4), width: 1.5),
            boxShadow: [
              BoxShadow(
                color: gold.withOpacity(0.3),
                blurRadius: 30,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      gold.withOpacity(0.3),
                      gold.withOpacity(0.05),
                    ],
                  ),
                  border: Border.all(color: gold.withOpacity(0.5)),
                ),
                child: Icon(
                  title == "Sukses"
                      ? Icons.check_circle
                      : title == "Error"
                          ? Icons.error
                          : Icons.info_outline,
                  color: gold,
                  size: 32,
                ),
              ),
              const SizedBox(height: 16),
              Text(
                title.toUpperCase(),
                style: TextStyle(
                  color: gold,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                message,
                textAlign: TextAlign.center,
                style: TextStyle(color: textGrey, fontSize: 13, height: 1.5),
              ),
              const SizedBox(height: 24),
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 32, vertical: 12),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [gold, goldLight],
                    ),
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: gold.withOpacity(0.4),
                        blurRadius: 15,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: const Text(
                    "OK",
                    style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════
  //  INPUT FIELD — TITAN STYLE
  // ═══════════════════════════════════════════════════
  Widget _buildInput({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    TextInputType type = TextInputType.text,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 18),
      child: TextField(
        controller: controller,
        keyboardType: type,
        style: TextStyle(color: white),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: gold.withOpacity(0.8), fontSize: 13),
          prefixIcon: Icon(icon, color: gold, size: 18),
          filled: true,
          fillColor: bgDeep.withOpacity(0.5),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: gold.withOpacity(0.2)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: gold.withOpacity(0.2)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: gold, width: 1.5),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════
  //  DROPDOWN ROLE — TITAN STYLE
  // ═══════════════════════════════════════════════════
  Widget _buildRoleDropdown({
    required String value,
    required ValueChanged<String?> onChanged,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      decoration: BoxDecoration(
        color: bgDeep.withOpacity(0.5),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: gold.withOpacity(0.2)),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: value,
          isExpanded: true,
          dropdownColor: bgCard,
          icon: Icon(Icons.keyboard_arrow_down, color: gold),
          style: TextStyle(color: white, fontSize: 13),
          items: roleOptions.map((role) {
            return DropdownMenuItem(
              value: role,
              child: Row(
                children: [
                  Container(
                    width: 6,
                    height: 6,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _roleColor(role),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Text(role.toUpperCase(),
                      style: TextStyle(color: white, letterSpacing: 0.5)),
                ],
              ),
            );
          }).toList(),
          onChanged: onChanged,
        ),
      ),
    );
  }

  Color _roleColor(String role) {
    switch (role.toLowerCase()) {
      case 'owner':
        return gold;
      case 'admin':
        return const Color(0xFFEF4444);
      case 'vip':
        return const Color(0xFF9C27B0);
      case 'reseller':
        return const Color(0xFF22C55E);
      default:
        return silver;
    }
  }

  // ═══════════════════════════════════════════════════
  //  GLASS CARD — TITAN STYLE (with shine + glow)
  // ═══════════════════════════════════════════════════
  Widget _buildGlassCard({
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [bgCard.withOpacity(0.9), bgDark.withOpacity(0.7)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: gold.withOpacity(0.25), width: 1.2),
        boxShadow: [
          BoxShadow(
            color: gold.withOpacity(0.08),
            blurRadius: 20,
            spreadRadius: 1,
          ),
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 10,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(22),
        child: Stack(
          children: [
            // Shine sweep effect
            Positioned.fill(
              child: AnimatedBuilder(
                animation: _shineCtrl,
                builder: (context, _) {
                  return Transform.translate(
                    offset: Offset(
                      (_shineCtrl.value * 2 - 1) * 400,
                      0,
                    ),
                    child: Transform.rotate(
                      angle: 0.3,
                      child: Container(
                        width: 60,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Colors.transparent,
                              gold.withOpacity(0.06),
                              Colors.transparent,
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
            // Content
            Padding(
              padding: const EdgeInsets.all(22),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    children: [
                      // Icon badge
                      AnimatedBuilder(
                        animation: _pulseAnim,
                        builder: (context, _) {
                          return Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  gold.withOpacity(0.3),
                                  gold.withOpacity(0.1),
                                ],
                              ),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: gold
                                    .withOpacity(0.5 * _pulseAnim.value),
                                width: 1.2,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: gold.withOpacity(
                                      0.25 * _pulseAnim.value),
                                  blurRadius: 12,
                                  spreadRadius: 1,
                                ),
                              ],
                            ),
                            child: Icon(icon, color: goldLight, size: 18),
                          );
                        },
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              title,
                              style: TextStyle(
                                color: white,
                                fontSize: 15,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Orbitron',
                                letterSpacing: 1.5,
                              ),
                            ),
                            const SizedBox(height: 3),
                            Container(
                              width: 30,
                              height: 2,
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [gold, goldLight],
                                ),
                                borderRadius: BorderRadius.circular(1),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 22),
                  ...children,
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════
  //  USER ITEM — TITAN STYLE
  // ═══════════════════════════════════════════════════
  Widget _buildUserItem(Map user) {
    final role = user['role']?.toString() ?? 'member';
    final roleColor = _roleColor(role);

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            bgDeep.withOpacity(0.7),
            bgCard.withOpacity(0.4),
          ],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: roleColor.withOpacity(0.3), width: 1),
        boxShadow: [
          BoxShadow(
            color: roleColor.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        children: [
          // Avatar
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              gradient: RadialGradient(
                colors: [
                  roleColor.withOpacity(0.3),
                  roleColor.withOpacity(0.05),
                ],
              ),
              shape: BoxShape.circle,
              border: Border.all(color: roleColor.withOpacity(0.5)),
            ),
            child: Icon(Icons.person, color: roleColor, size: 18),
          ),
          const SizedBox(width: 14),
          // Info
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Flexible(
                      child: Text(
                        user['username'] ?? '?',
                        style: TextStyle(
                          color: white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                          letterSpacing: 0.3,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: roleColor.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(
                            color: roleColor.withOpacity(0.4)),
                      ),
                      child: Text(
                        role.toUpperCase(),
                        style: TextStyle(
                          color: roleColor,
                          fontSize: 9,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Orbitron',
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Icon(Icons.calendar_today,
                        color: textGrey, size: 10),
                    const SizedBox(width: 4),
                    Text(
                      user['expiredDate'] ?? '-',
                      style: TextStyle(color: textGrey, fontSize: 11),
                    ),
                  ],
                ),
              ],
            ),
          ),
          // Delete button
          GestureDetector(
            onTap: () async {
              final confirm = await showDialog<bool>(
                context: context,
                builder: (_) => Dialog(
                  backgroundColor: Colors.transparent,
                  child: Container(
                    padding: const EdgeInsets.all(22),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [bgCard, bgDark],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                          color: Colors.redAccent.withOpacity(0.4)),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.red.withOpacity(0.2),
                          blurRadius: 25,
                        ),
                      ],
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.warning_amber_rounded,
                            color: Colors.redAccent, size: 40),
                        const SizedBox(height: 12),
                        Text(
                          "HAPUS USER?",
                          style: TextStyle(
                            color: white,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron',
                            fontSize: 14,
                            letterSpacing: 1.5,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          user['username'] ?? '',
                          style: TextStyle(color: goldLight, fontSize: 13),
                        ),
                        const SizedBox(height: 20),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            GestureDetector(
                              onTap: () => Navigator.pop(context, false),
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 24, vertical: 10),
                                decoration: BoxDecoration(
                                  color: bgDeep,
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(
                                      color: silver.withOpacity(0.3)),
                                ),
                                child: Text("BATAL",
                                    style: TextStyle(
                                        color: silver,
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold)),
                              ),
                            ),
                            GestureDetector(
                              onTap: () => Navigator.pop(context, true),
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 24, vertical: 10),
                                decoration: BoxDecoration(
                                  gradient: const LinearGradient(
                                    colors: [
                                      Color(0xFFB91C1C),
                                      Color(0xFFDC2626)
                                    ],
                                  ),
                                  borderRadius: BorderRadius.circular(10),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.red.withOpacity(0.4),
                                      blurRadius: 12,
                                    ),
                                  ],
                                ),
                                child: const Text("HAPUS",
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold)),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              );
              if (confirm == true) {
                deleteController.text = user['username'];
                _deleteUser();
              }
            },
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.redAccent.withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
                border:
                    Border.all(color: Colors.redAccent.withOpacity(0.3)),
              ),
              child: Icon(Icons.delete_outline,
                  color: Colors.redAccent, size: 16),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════
  //  PAGINATION — TITAN STYLE
  // ═══════════════════════════════════════════════════
  Widget _buildPagination() {
    if (totalPages <= 1) return const SizedBox.shrink();

    return Wrap(
      spacing: 6,
      runSpacing: 6,
      children: List.generate(totalPages, (index) {
        final page = index + 1;
        final isActive = currentPage == page;
        return GestureDetector(
          onTap: () => setState(() => currentPage = page),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              gradient: isActive
                  ? LinearGradient(colors: [gold, goldLight])
                  : null,
              color: isActive ? null : bgDeep.withOpacity(0.5),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: isActive ? gold : gold.withOpacity(0.2),
                width: 1,
              ),
              boxShadow: isActive
                  ? [
                      BoxShadow(
                        color: gold.withOpacity(0.4),
                        blurRadius: 12,
                        spreadRadius: 1,
                      ),
                    ]
                  : [],
            ),
            child: Center(
              child: Text(
                "$page",
                style: TextStyle(
                  color: isActive ? Colors.black : textGrey,
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                ),
              ),
            ),
          ),
        );
      }),
    );
  }

  // ═══════════════════════════════════════════════════
  //  TOMBOL AKSI — TITAN GRADIENT
  // ═══════════════════════════════════════════════════
  Widget _buildActionButton({
    required String label,
    required IconData icon,
    required VoidCallback? onPressed,
    required List<Color> gradientColors,
    required Color glowColor,
  }) {
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        height: 52,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: gradientColors,
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: glowColor.withOpacity(0.4),
              blurRadius: 18,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Center(
          child: isLoading
              ? const SizedBox(
                  width: 22,
                  height: 22,
                  child: CircularProgressIndicator(
                    strokeWidth: 2.5,
                    color: Colors.white,
                  ),
                )
              : Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(icon, color: Colors.white, size: 18),
                    const SizedBox(width: 10),
                    Text(
                      label,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 13,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════
  //  BUILD
  // ═══════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDeep,
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.topCenter,
            radius: 1.5,
            colors: [
              gold.withOpacity(0.08),
              bgDark,
              bgDeep,
            ],
            stops: const [0.0, 0.5, 1.0],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // ── HEADER ──
                _buildHeader(),
                const SizedBox(height: 28),

                // ── DELETE USER ──
                _buildGlassCard(
                  title: "DELETE USER",
                  icon: FontAwesomeIcons.userSlash,
                  children: [
                    _buildInput(
                      label: "Username Target",
                      controller: deleteController,
                      icon: FontAwesomeIcons.user,
                    ),
                    _buildActionButton(
                      label: "DELETE ACCOUNT",
                      icon: Icons.delete_forever,
                      onPressed: isLoading ? null : _deleteUser,
                      gradientColors: const [
                        Color(0xFFB91C1C),
                        Color(0xFFDC2626),
                      ],
                      glowColor: Colors.red,
                    ),
                  ],
                ),

                // ── CREATE ACCOUNT ──
                _buildGlassCard(
                  title: "CREATE ACCOUNT",
                  icon: FontAwesomeIcons.userPlus,
                  children: [
                    _buildInput(
                      label: "Username",
                      controller: createUsernameController,
                      icon: FontAwesomeIcons.user,
                    ),
                    _buildInput(
                      label: "Password",
                      controller: createPasswordController,
                      icon: FontAwesomeIcons.lock,
                    ),
                    _buildInput(
                      label: "Durasi (Hari)",
                      controller: createDayController,
                      icon: FontAwesomeIcons.calendarDay,
                      type: TextInputType.number,
                    ),
                    const SizedBox(height: 4),
                    _buildRoleDropdown(
                      value: newUserRole,
                      onChanged: (val) =>
                          setState(() => newUserRole = val ?? 'member'),
                    ),
                    const SizedBox(height: 20),
                    _buildActionButton(
                      label: "CREATE ACCOUNT",
                      icon: Icons.add_circle_outline,
                      onPressed: isLoading ? null : _createAccount,
                      gradientColors: [goldDark, gold, goldLight],
                      glowColor: gold,
                    ),
                  ],
                ),

                // ── EXTEND DURATION ──
                _buildGlassCard(
                  title: "EXTEND DURATION",
                  icon: FontAwesomeIcons.clock,
                  children: [
                    _buildInput(
                      label: "Username Target",
                      controller: editUsernameController,
                      icon: FontAwesomeIcons.userEdit,
                    ),
                    _buildInput(
                      label: "Tambah Hari",
                      controller: editDayController,
                      icon: FontAwesomeIcons.calendarPlus,
                      type: TextInputType.number,
                    ),
                    _buildActionButton(
                      label: "ADD DAYS",
                      icon: Icons.update,
                      onPressed: isLoading ? null : _editUser,
                      gradientColors: [cyan, const Color(0xFF00ACC1)],
                      glowColor: cyan,
                    ),
                  ],
                ),

                // ── USER LIST ──
                _buildGlassCard(
                  title: "USER LIST",
                  icon: FontAwesomeIcons.users,
                  children: [
                    _buildRoleDropdown(
                      value: selectedRole,
                      onChanged: (val) {
                        if (val != null) {
                          selectedRole = val;
                          _filterAndPaginate();
                        }
                      },
                    ),
                    const SizedBox(height: 18),
                    if (isLoading)
                      Center(
                        child: Padding(
                          padding: const EdgeInsets.all(20),
                          child: CircularProgressIndicator(
                            color: gold,
                            strokeWidth: 2.5,
                          ),
                        ),
                      )
                    else if (filteredList.isEmpty)
                      Container(
                        padding: const EdgeInsets.all(30),
                        child: Column(
                          children: [
                            Icon(Icons.inbox_outlined,
                                color: textGrey, size: 40),
                            const SizedBox(height: 10),
                            Text(
                              "Tidak ada user dengan role ini",
                              style: TextStyle(color: textGrey, fontSize: 12),
                            ),
                          ],
                        ),
                      )
                    else ...[
                      ..._getCurrentPageData()
                          .map((u) => _buildUserItem(u))
                          .toList(),
                      const SizedBox(height: 18),
                      _buildPagination(),
                    ],
                  ],
                ),

                const SizedBox(height: 20),

                // ── FOOTER ──
                Center(
                  child: Text(
                    "© 2026 SYAM · TITAN EDITION",
                    style: TextStyle(
                      color: textGrey.withOpacity(0.5),
                      fontSize: 10,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1.5,
                    ),
                  ),
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════
  //  HEADER — TITAN STYLE
  // ═══════════════════════════════════════════════════
  Widget _buildHeader() {
    return Column(
      children: [
        // Icon crown dengan glow
        AnimatedBuilder(
          animation: _pulseAnim,
          builder: (context, _) {
            return Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    gold.withOpacity(0.3 * _pulseAnim.value),
                    gold.withOpacity(0.05),
                  ],
                ),
                border: Border.all(
                  color: gold.withOpacity(0.5 * _pulseAnim.value),
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: gold.withOpacity(0.4 * _pulseAnim.value),
                    blurRadius: 25,
                    spreadRadius: 3,
                  ),
                ],
              ),
              child: const Icon(
                FontAwesomeIcons.crown,
                color: Color(0xFFD4AF37),
                size: 32,
              ),
            );
          },
        ),
        const SizedBox(height: 16),
        // Title
        Text(
          "OWNER DASHBOARD",
          style: TextStyle(
            color: white,
            fontSize: 22,
            fontWeight: FontWeight.bold,
            fontFamily: 'Orbitron',
            letterSpacing: 3,
            shadows: [
              Shadow(
                color: gold.withOpacity(0.8),
                blurRadius: 15,
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        // Subtitle
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 30,
              height: 1,
              color: gold.withOpacity(0.5),
            ),
            const SizedBox(width: 10),
            Text(
              "TITAN PANEL",
              style: TextStyle(
                color: gold,
                fontSize: 10,
                fontFamily: 'Orbitron',
                letterSpacing: 3,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(width: 10),
            Container(
              width: 30,
              height: 1,
              color: gold.withOpacity(0.5),
            ),
          ],
        ),
      ],
    );
  }
}