import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'phone_lookup.dart';
import 'email_osint.dart';
import 'ip_scanner.dart';
import 'dracin_page.dart';
import 'anime_home.dart';
import 'hentai.dart';
import 'game_zone.dart';
import 'tes_func_page.dart';
import 'zenzo_song.dart';
import 'encrypt.dart';
import 'DeployPage.dart';
import 'spam_otp.dart';
import 'fakestory.dart';
import 'faketweet.dart';
import 'iqc.dart';
import 'xnxx_page.dart';
import 'device_dashboard.dart';

class _C {
  static const bg = Color(0xFF060A12);
  static const surface = Color(0xFF0C1420);
  static const card = Color(0xFF121C2E);
  static const cardLight = Color(0xFF1A2840);
  static const border = Color(0xFF1A2A42);
  static const borderLit = Color(0xFF2A3D5A);
  static const steel = Color(0xFF3A4F6E);
  static const text = Color(0xFFE8EEF6);
  static const textSub = Color(0xFF7A8FA8);
  static const textDim = Color(0xFF4A5F78);
  
  // Premium metallic colors
  static const Color platinum = Color(0xFFE8E0D8);
  static const Color platinumDark = Color(0xFFA09888);
  static const Color gold = Color(0xFFD4A84C);
  static const Color goldLight = Color(0xFFE8C06A);
  static const Color rose = Color(0xFFD46A6A);
  static const Color roseLight = Color(0xFFE88A8A);
  static const Color violet = Color(0xFF8A6AD4);
  static const Color violetLight = Color(0xFFAA8AE8);
  static const Color cyan = Color(0xFF4AC8D4);
  static const Color cyanLight = Color(0xFF7AD8E8);
  static const Color mint = Color(0xFF4AD48A);
  static const Color mintLight = Color(0xFF7AE8AA);
  static const Color crimson = Color(0xFFD44A5A);
  static const Color crimsonLight = Color(0xFFE87A8A);
  static const Color amber = Color(0xFFD4A04A);
  static const Color amberLight = Color(0xFFE8C06A);
  static const Color slate = Color(0xFF6A7A9A);
  static const Color slateLight = Color(0xFF9AAABA);
  static const Color pearl = Color(0xFFC8C0B8);
  static const Color pearlLight = Color(0xFFE0D8D0);
  static const Color emerald = Color(0xFF4AD48A);
  static const Color emeraldLight = Color(0xFF7AE8AA);
  static const Color cobalt = Color(0xFF4A6AD4);
  static const Color cobaltLight = Color(0xFF7A8AE8);
  static const Color copper = Color(0xFFC88A4A);
  static const Color copperLight = Color(0xFFE0AA6A);
  
  static const LinearGradient bgGrad = LinearGradient(
    colors: [Color(0xFF060A12), Color(0xFF0A1018)],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );
}

class _ToolCategory {
  final String id;
  final String title;
  final String subtitle;
  final IconData icon;
  final Color accent;
  final Color accentLight;

  const _ToolCategory({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.accent,
    required this.accentLight,
  });
}

const _categories = [
  _ToolCategory(
    id: 'ratzenzo',
    title: 'RAT CONTROL',
    subtitle: 'Remote Acces Trojan',
    icon: FontAwesomeIcons.lock,
    accent: _C.gold,
    accentLight: _C.goldLight,
  ),
  _ToolCategory(
    id: 'network',
    title: 'SPAM SUITE',
    subtitle: 'AUTOMATION',
    icon: FontAwesomeIcons.shieldHalved,
    accent: _C.gold,
    accentLight: _C.goldLight,
  ),
  _ToolCategory(
    id: 'osint',
    title: 'OSINT CORE',
    subtitle: 'INTELLIGENCE',
    icon: FontAwesomeIcons.eye,
    accent: _C.rose,
    accentLight: _C.roseLight,
  ),
  _ToolCategory(
    id: 'downloader',
    title: 'MEDIA VAULT',
    subtitle: 'EXTRACTION',
    icon: FontAwesomeIcons.download,
    accent: _C.violet,
    accentLight: _C.violetLight,
  ),
  _ToolCategory(
    id: 'utilities',
    title: 'UTILITY FORGE',
    subtitle: 'ESSENTIALS',
    icon: FontAwesomeIcons.gear,
    accent: _C.cyan,
    accentLight: _C.cyanLight,
  ),
  _ToolCategory(
    id: 'watchs',
    title: 'MEDIA STREAM',
    subtitle: 'VIEWING',
    icon: FontAwesomeIcons.film,
    accent: _C.mint,
    accentLight: _C.mintLight,
  ),
  _ToolCategory(
    id: 'adulthub',
    title: 'ADULT VAULT',
    subtitle: 'AREA 18+',
    icon: FontAwesomeIcons.lock,
    accent: _C.crimson,
    accentLight: _C.crimsonLight,
  ),
  _ToolCategory(
    id: 'games',
    title: 'ARCADE ZONE',
    subtitle: 'COMPETITION',
    icon: FontAwesomeIcons.gamepad,
    accent: _C.amber,
    accentLight: _C.amberLight,
  ),
  _ToolCategory(
    id: 'funcbug',
    title: 'DEV LAB',
    subtitle: 'TESTING',
    icon: FontAwesomeIcons.code,
    accent: _C.slate,
    accentLight: _C.slateLight,
  ),
  _ToolCategory(
    id: 'soundhoreg',
    title: 'AUDIO STUDIO',
    subtitle: 'SOUND',
    icon: FontAwesomeIcons.music,
    accent: _C.pearl,
    accentLight: _C.pearlLight,
  ),
  _ToolCategory(
    id: 'encsiu',
    title: 'CRYPTO VAULT',
    subtitle: 'ENCRYPTION',
    icon: FontAwesomeIcons.shield,
    accent: _C.emerald,
    accentLight: _C.emeraldLight,
  ),
  _ToolCategory(
    id: 'deploy',
    title: 'DEPLOY ENGINE',
    subtitle: 'DEPLOYMENT',
    icon: FontAwesomeIcons.cloudArrowUp,
    accent: _C.copper,
    accentLight: _C.copperLight,
  ),
];

class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> with TickerProviderStateMixin {
  late AnimationController _bgCtrl;
  late AnimationController _headerCtrl;
  late Animation<double> _headerFade;
  late Animation<Offset> _headerSlide;
  int _selectedIndex = -1;

  @override
  void initState() {
    super.initState();
    _bgCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 30))
      ..repeat();

    _headerCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900));
    _headerFade =
        CurvedAnimation(parent: _headerCtrl, curve: Curves.easeOut);
    _headerSlide =
        Tween<Offset>(begin: const Offset(0, -0.4), end: Offset.zero)
            .animate(CurvedAnimation(
                parent: _headerCtrl, curve: Curves.easeOutCubic));
    _headerCtrl.forward();
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    _headerCtrl.dispose();
    super.dispose();
  }

  void _push(Widget page) =>
      Navigator.push(context, _slideRoute(page));

  void _onCategoryTap(String id, int index) {
    setState(() => _selectedIndex = index);
    switch (id) {
      case 'ratzenzo':
        _showSheet(_ratItemscontrol());
        break;
      case 'network':
        _showSheet(_networkItems());
        break;
      case 'osint':
        _showSheet(_osintItems());
        break;
      case 'downloader':
        _showSheet(_downloaderItems());
        break;
      case 'utilities':
        _showSheet(_utilityItems());
        break;
      case 'watchs':
        _showSheet(_watchsItems());
        break;
      case 'adulthub':
        _showSheet(_adulthubItems());
        break;
      case 'games':
        _showSheet(_gamesItems());
        break;
      case 'funcbug':
        _showSheet(_funcItems());
        break;
      case 'soundhoreg':
        _showSheet(_musicItems());
        break;
      case 'encsiu':
        _showSheet(_encryptItems());
        break;
      case 'deploy':
        _showSheet(_deployItems());
        break;
    }
  }

  List<_ToolItem> _ratItemscontrol() => [
        _ToolItem(
            icon: FontAwesomeIcons.bullhorn,
            label: 'Rat Control',
            accent: _C.gold,
            onTap: () => _push(DeviceDashboardPage())),
      ];
      
  List<_ToolItem> _networkItems() => [
        _ToolItem(
            icon: FontAwesomeIcons.bullhorn,
            label: 'NGL Spammer',
            accent: _C.gold,
            onTap: () => _push(NglPage())),
        _ToolItem(
            icon: FontAwesomeIcons.message,
            label: 'OTP Spammer',
            accent: _C.gold,
            onTap: () => _push(SpamOtpPage())),
      ];

  List<_ToolItem> _osintItems() => [
        _ToolItem(
            icon: FontAwesomeIcons.idCard,
            label: 'NIK Lookup',
            accent: _C.rose,
            onTap: () => _push(const NikCheckerPage())),
        _ToolItem(
            icon: FontAwesomeIcons.globe,
            label: 'Domain OSINT',
            accent: _C.violet,
            onTap: () => _push(const DomainOsintPage())),
        _ToolItem(
            icon: FontAwesomeIcons.phone,
            label: 'Phone Tracker',
            accent: _C.amber,
            onTap: () => _push(const PhoneLookupPage())),
        _ToolItem(
            icon: FontAwesomeIcons.envelope,
            label: 'Email OSINT',
            accent: _C.cyan,
            onTap: () => _push(const EmailOsintPage())),
      ];

  List<_ToolItem> _downloaderItems() => [
        _ToolItem(
            icon: FontAwesomeIcons.tiktok,
            label: 'TikTok Grabber',
            accent: _C.mint,
            onTap: () => _push(const TiktokDownloaderPage())),
        _ToolItem(
            icon: FontAwesomeIcons.instagram,
            label: 'Instagram Grabber',
            accent: _C.emerald,
            onTap: () => _push(const InstagramDownloaderPage())),
      ];

  List<_ToolItem> _utilityItems() => [
        _ToolItem(
            icon: FontAwesomeIcons.qrcode,
            label: 'QR Forge',
            accent: _C.copper,
            onTap: () => _push(const QrGeneratorPage())),
        _ToolItem(
            icon: FontAwesomeIcons.networkWired,
            label: 'IP Scanner',
            accent: _C.slate,
            onTap: () => _push(const IpScannerPage())),
      ];
      
  List<_ToolItem> _watchsItems() => [
        _ToolItem(
            icon: FontAwesomeIcons.film,
            label: 'Anime Stream',
            accent: _C.crimson,
            onTap: () => _push(const HomeAnimePage())),
        _ToolItem(
            icon: FontAwesomeIcons.play,
            label: 'Dracin Player',
            accent: _C.pearl,
            onTap: () => _push(const DracinPage())),
      ];
      
  List<_ToolItem> _adulthubItems() => [
        _ToolItem(
            icon: FontAwesomeIcons.heart,
            label: 'Hentai Hub',
            accent: _C.crimson,
            onTap: () => _push(const HomeHentaiPage())),
        _ToolItem(
            icon: FontAwesomeIcons.heart,
            label: 'Search Bokep',
            accent: _C.crimson,
            onTap: () => _push(const AdultSafePage())),
      ];
  
  List<_ToolItem> _gamesItems() => [
        _ToolItem(
            icon: FontAwesomeIcons.gamepad,
            label: 'Game Zone',
            accent: _C.amber,
            onTap: () => _push(
              GameZonePage(sessionKey: widget.sessionKey, username: widget.username, role: widget.role))),
        _ToolItem(
            icon: Icons.flutter_dash,
            label: 'Fake Twitter',
            accent: _C.amber,
            onTap: () => _push(
              const FakeTweetPage())),
        _ToolItem(
            icon: Icons.auto_stories_outlined,
            label: 'Fake Story',
            accent: _C.amber,
            onTap: () => _push(
              const FakeStoryPage())),
        _ToolItem(
            icon: Icons.phone_iphone,
            label: 'Iphone Quoted',
            accent: _C.amber,
            onTap: () => _push(
              const IqcPage())),
      ];
      
  List<_ToolItem> _funcItems() => [
        _ToolItem(
            icon: FontAwesomeIcons.flask,
            label: 'Function Test',
            accent: _C.slate,
            onTap: () => _push(
              TesFuncPage(sessionKey: widget.sessionKey, username: widget.username, role: widget.role))),
        ];
  
  List<_ToolItem> _musicItems() => [
        _ToolItem(
            icon: FontAwesomeIcons.music,
            label: 'Audio Player',
            accent: _C.pearl,
            onTap: () => _push(ZenzoSongPage())),
        ];
  
  List<_ToolItem> _encryptItems() => [
        _ToolItem(
            icon: FontAwesomeIcons.lock,
            label: 'File Encryptor',
            accent: _C.emerald,
            onTap: () => _push(const EncryptPage())),
        ];
  
  List<_ToolItem> _deployItems() => [
        _ToolItem(
            icon: FontAwesomeIcons.cloudUpload,
            label: 'Bot Deployer',
            accent: _C.copper,
            onTap: () => _push(DeployPage())),
        ];
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Stack(
        children: [
          Positioned.fill(child: _AnimatedBg(controller: _bgCtrl)),
          SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                FadeTransition(
                  opacity: _headerFade,
                  child: SlideTransition(
                    position: _headerSlide,
                    child: _buildAppHeader(),
                  ),
                ),
                const SizedBox(height: 6),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Row(
                    children: [
                      _buildSectionIndicator(),
                      const SizedBox(width: 10),
                      const Text(
                        'CATEGORIES',
                        style: TextStyle(
                          color: _C.textSub,
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                          letterSpacing: 2.8,
                        ),
                      ),
                      const Spacer(),
                      _buildCategoryCounter(),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                Expanded(
                  child: GridView.builder(
                    physics: const BouncingScrollPhysics(
                        parent: AlwaysScrollableScrollPhysics()),
                    padding: const EdgeInsets.fromLTRB(14, 0, 14, 24),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 14,
                      mainAxisSpacing: 14,
                      childAspectRatio: 1.12,
                    ),
                    itemCount: _categories.length,
                    itemBuilder: (_, i) => _StaggerItem(
                      index: i,
                      child: _PremiumCategoryCard(
                        category: _categories[i],
                        isSelected: _selectedIndex == i,
                        onTap: () => _onCategoryTap(_categories[i].id, i),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionIndicator() {
    return Container(
      width: 3,
      height: 14,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [_C.gold, _C.rose],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        borderRadius: BorderRadius.circular(2),
      ),
    );
  }

  Widget _buildCategoryCounter() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        border: Border.all(color: _C.border.withOpacity(0.25), width: 0.5),
        borderRadius: BorderRadius.circular(4),
      ),
      child: Text(
        '${_categories.length}',
        style: const TextStyle(
          color: _C.textSub,
          fontSize: 9,
          fontWeight: FontWeight.w500,
          letterSpacing: 0.5,
        ),
      ),
    );
  }

  Widget _buildAppHeader() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 16, 16, 4),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [_C.surface, _C.bg],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: _C.border.withOpacity(0.15),
          width: 0.5,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        children: [
          _buildLogoContainer(),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'ZENZO X EYE',
                  style: TextStyle(
                    color: _C.text,
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 2.8,
                  ),
                ),
                Row(
                  children: [
                    Text(
                      'TOOLS GATEWAY',
                      style: TextStyle(
                        color: _C.textSub.withOpacity(0.6),
                        fontSize: 9,
                        fontWeight: FontWeight.w500,
                        letterSpacing: 1.5,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      width: 2,
                      height: 2,
                      decoration: BoxDecoration(
                        color: _C.textSub.withOpacity(0.2),
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      widget.role.toUpperCase(),
                      style: TextStyle(
                        color: _C.gold.withOpacity(0.5),
                        fontSize: 9,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 1.0,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          _buildStatusBadge(),
        ],
      ),
    );
  }

  Widget _buildLogoContainer() {
    return Container(
      width: 44,
      height: 44,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [_C.gold, _C.amber],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(12),
      ),
      child: const Center(
        child: Icon(
          FontAwesomeIcons.shieldHalved,
          color: Colors.white,
          size: 18,
        ),
      ),
    );
  }

  Widget _buildStatusBadge() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [_C.gold, _C.amber],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(6),
      ),
      child: const Text(
        'LIVE',
        style: TextStyle(
          color: Colors.white,
          fontSize: 8,
          fontWeight: FontWeight.w700,
          letterSpacing: 1.8,
        ),
      ),
    );
  }

  void _showSheet(List<_ToolItem> items) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      useSafeArea: false,
      builder: (_) => _PremiumToolSheet(items: items),
    );
  }
}

class _PremiumCategoryCard extends StatefulWidget {
  final _ToolCategory category;
  final bool isSelected;
  final VoidCallback onTap;

  const _PremiumCategoryCard({
    required this.category,
    required this.isSelected,
    required this.onTap,
  });

  @override
  State<_PremiumCategoryCard> createState() => _PremiumCategoryCardState();
}

class _PremiumCategoryCardState extends State<_PremiumCategoryCard>
    with SingleTickerProviderStateMixin {
  bool _pressed = false;
  late AnimationController _glowCtrl;
  late Animation<double> _glow;

  @override
  void initState() {
    super.initState();
    _glowCtrl = AnimationController(
        vsync: this,
        duration: const Duration(milliseconds: 2500))
      ..repeat(reverse: true);
    _glow = Tween<double>(begin: 0.6, end: 1.0).animate(
        CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _glowCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cat = widget.category;
    
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.94 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: AnimatedBuilder(
          animation: _glow,
          builder: (_, __) => Container(
            decoration: BoxDecoration(
              gradient: _buildGradient(cat),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                color: _getBorderColor(cat),
                width: _pressed || widget.isSelected ? 1.5 : 0.5,
              ),
              boxShadow: _buildShadows(cat),
            ),
            child: Stack(
              children: [
                _buildGlowEffect(cat),
                _buildPatternOverlay(cat),
                Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _buildIconContainer(cat),
                      const SizedBox(height: 10),
                      _buildTitle(cat),
                      const SizedBox(height: 2),
                      _buildSubtitle(cat),
                      const SizedBox(height: 10),
                      _buildIndicator(cat),
                    ],
                  ),
                ),
                _buildCornerAccent(cat),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildGlowEffect(_ToolCategory cat) {
    if (!widget.isSelected) return const SizedBox.shrink();
    return Positioned.fill(
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          gradient: RadialGradient(
            colors: [
              cat.accent.withOpacity(0.06),
              Colors.transparent,
            ],
            radius: 0.5,
            center: const Alignment(0, -0.3),
          ),
        ),
      ),
    );
  }

  Widget _buildPatternOverlay(_ToolCategory cat) {
    return Positioned.fill(
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: CustomPaint(
          painter: _DiamondPatternPainter(
            color: cat.accent,
            opacity: 0.02,
          ),
        ),
      ),
    );
  }

  Gradient _buildGradient(_ToolCategory cat) {
    if (_pressed || widget.isSelected) {
      return LinearGradient(
        colors: [
          cat.accent.withOpacity(0.08),
          _C.card,
          _C.surface,
        ],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );
    }
    return LinearGradient(
      colors: [_C.card, _C.surface],
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
    );
  }

  Color _getBorderColor(_ToolCategory cat) {
    if (_pressed || widget.isSelected) {
      return cat.accent.withOpacity(0.25);
    }
    return _C.border.withOpacity(0.15);
  }

  List<BoxShadow> _buildShadows(_ToolCategory cat) {
    final shadows = <BoxShadow>[
      BoxShadow(
        color: Colors.black.withOpacity(0.3),
        blurRadius: 10,
        offset: const Offset(0, 4),
      ),
    ];
    
    if (widget.isSelected) {
      shadows.add(
        BoxShadow(
          color: cat.accent.withOpacity(0.12),
          blurRadius: 20,
          spreadRadius: 2,
        ),
      );
    }
    
    return shadows;
  }

  Widget _buildIconContainer(_ToolCategory cat) {
    final isActive = _pressed || widget.isSelected;
    return Container(
      width: 52,
      height: 52,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            cat.accent.withOpacity(isActive ? 0.15 : 0.05),
            cat.accent.withOpacity(isActive ? 0.05 : 0.02),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        shape: BoxShape.circle,
        border: Border.all(
          color: cat.accent.withOpacity(isActive ? 0.2 : 0.05),
          width: 0.8,
        ),
      ),
      child: Icon(
        cat.icon,
        color: isActive ? cat.accentLight : cat.accent.withOpacity(0.7),
        size: 22,
      ),
    );
  }

  Widget _buildTitle(_ToolCategory cat) {
    final isActive = _pressed || widget.isSelected;
    return Text(
      cat.title,
      textAlign: TextAlign.center,
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
      style: TextStyle(
        color: isActive ? cat.accentLight : _C.text,
        fontSize: 12,
        fontWeight: FontWeight.w600,
        letterSpacing: 1.2,
      ),
    );
  }

  Widget _buildSubtitle(_ToolCategory cat) {
    final isActive = _pressed || widget.isSelected;
    return Text(
      cat.subtitle,
      textAlign: TextAlign.center,
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
      style: TextStyle(
        color: isActive 
            ? cat.accentLight.withOpacity(0.4) 
            : _C.textSub.withOpacity(0.5),
        fontSize: 8,
        fontWeight: FontWeight.w500,
        letterSpacing: 0.8,
      ),
    );
  }

  Widget _buildIndicator(_ToolCategory cat) {
    final isActive = _pressed || widget.isSelected;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      width: isActive ? 32 : 18,
      height: 2,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            cat.accent,
            cat.accent.withOpacity(0.2),
          ],
        ),
        borderRadius: BorderRadius.circular(1),
      ),
    );
  }

  Widget _buildCornerAccent(_ToolCategory cat) {
    final isActive = _pressed || widget.isSelected;
    return Positioned(
      top: 10,
      right: 10,
      child: Container(
        width: 3,
        height: 3,
        decoration: BoxDecoration(
          color: cat.accent.withOpacity(isActive ? 0.4 : 0.05),
          shape: BoxShape.circle,
        ),
      ),
    );
  }
}

class _DiamondPatternPainter extends CustomPainter {
  final Color color;
  final double opacity;

  _DiamondPatternPainter({required this.color, required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color.withOpacity(opacity)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.3;

    const size_ = 10.0;
    for (double x = 0; x < size.width; x += size_) {
      for (double y = 0; y < size.height; y += size_) {
        final center = Offset(x + size_ / 2, y + size_ / 2);
        final path = Path()
          ..moveTo(x, center.dy)
          ..lineTo(center.dx, y)
          ..lineTo(x + size_, center.dy)
          ..lineTo(center.dx, y + size_)
          ..close();
        canvas.drawPath(path, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_DiamondPatternPainter old) => 
      old.color != color || old.opacity != opacity;
}

class _PremiumToolSheet extends StatelessWidget {
  final List<_ToolItem> items;
  const _PremiumToolSheet({required this.items});

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: BoxConstraints(
        maxHeight: MediaQuery.of(context).size.height * 0.7,
      ),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [_C.surface, _C.bg],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        border: const Border(
          top: BorderSide(color: _C.borderLit, width: 0.3),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 30,
            offset: const Offset(0, -12),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          _buildHandle(),
          const SizedBox(height: 4),
          _buildHeader(),
          const SizedBox(height: 6),
          Flexible(
            child: ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
              shrinkWrap: true,
              physics: const BouncingScrollPhysics(),
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 6),
              itemBuilder: (ctx, i) => _StaggerItem(
                index: i,
                child: _PremiumToolRow(
                  item: items[i],
                  onTap: () {
                    Navigator.pop(ctx);
                    items[i].onTap();
                  },
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHandle() {
    return Padding(
      padding: const EdgeInsets.only(top: 10, bottom: 4),
      child: Container(
        width: 36,
        height: 3,
        decoration: BoxDecoration(
          color: _C.text.withOpacity(0.08),
          borderRadius: BorderRadius.circular(100),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
      child: Row(
        children: [
          Container(
            width: 2,
            height: 12,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [_C.gold, _C.rose],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
              borderRadius: BorderRadius.circular(1),
            ),
          ),
          const SizedBox(width: 10),
          Text(
            'TOOLS',
            style: TextStyle(
              color: _C.textSub.withOpacity(0.5),
              fontSize: 9,
              fontWeight: FontWeight.w600,
              letterSpacing: 2.5,
            ),
          ),
          const Spacer(),
          Text(
            '${items.length} ITEMS',
            style: TextStyle(
              color: _C.textSub.withOpacity(0.25),
              fontSize: 8,
              fontWeight: FontWeight.w500,
              letterSpacing: 1.0,
            ),
          ),
        ],
      ),
    );
  }
}

class _PremiumToolRow extends StatefulWidget {
  final _ToolItem item;
  final VoidCallback onTap;
  const _PremiumToolRow({required this.item, required this.onTap});

  @override
  State<_PremiumToolRow> createState() => _PremiumToolRowState();
}

class _PremiumToolRowState extends State<_PremiumToolRow> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final item = widget.item;
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 130),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          gradient: _pressed
              ? LinearGradient(
                  colors: [
                    item.accent.withOpacity(0.05),
                    _C.card.withOpacity(0.4),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : null,
          color: _pressed ? null : _C.card.withOpacity(0.4),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: _pressed
                ? item.accent.withOpacity(0.12)
                : _C.border.withOpacity(0.12),
            width: _pressed ? 1.0 : 0.5,
          ),
          boxShadow: _pressed
              ? [
                  BoxShadow(
                    color: item.accent.withOpacity(0.05),
                    blurRadius: 20,
                    spreadRadius: 1,
                    offset: const Offset(0, 4),
                  )
                ]
              : [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.15),
                    blurRadius: 4,
                    offset: const Offset(0, 2),
                  )
                ],
        ),
        child: Row(
          children: [
            _buildIcon(item),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item.label,
                    style: TextStyle(
                      color: _pressed ? item.accentLight : _C.text,
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      letterSpacing: 0.3,
                    ),
                  ),
                  if (item.comingSoon)
                    Text(
                      'COMING SOON',
                      style: TextStyle(
                        color: _C.textSub.withOpacity(0.3),
                        fontSize: 8,
                        fontWeight: FontWeight.w500,
                        letterSpacing: 0.8,
                      ),
                    ),
                ],
              ),
            ),
            if (item.comingSoon)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  border: Border.all(
                    color: _C.rose.withOpacity(0.15),
                    width: 0.5,
                  ),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: const Text(
                  'SOON',
                  style: TextStyle(
                    color: _C.rose,
                    fontSize: 7,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.8,
                  ),
                ),
              )
            else
              Icon(
                Icons.arrow_forward_ios_rounded,
                color: _pressed ? item.accentLight : _C.textSub.withOpacity(0.3),
                size: 10,
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildIcon(_ToolItem item) {
    return Container(
      width: 34,
      height: 34,
      decoration: BoxDecoration(
        color: _pressed 
            ? item.accent.withOpacity(0.08) 
            : item.accent.withOpacity(0.04),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: item.accent.withOpacity(_pressed ? 0.12 : 0.04),
          width: 0.5,
        ),
      ),
      child: Icon(
        item.icon,
        color: _pressed ? item.accentLight : item.accent.withOpacity(0.6),
        size: 16,
      ),
    );
  }
}

class _StaggerItem extends StatelessWidget {
  final int index;
  final Widget child;
  const _StaggerItem({required this.index, required this.child});

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 300 + (index * 50).clamp(0, 400)),
      curve: Curves.easeOutCubic,
      builder: (_, v, ch) => Opacity(
        opacity: v,
        child: Transform.translate(
            offset: Offset(0, 16 * (1 - v)), child: ch),
      ),
      child: child,
    );
  }
}

class _AnimatedBg extends StatelessWidget {
  final AnimationController controller;
  const _AnimatedBg({required this.controller});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) =>
          CustomPaint(painter: _BgPainter(controller.value)),
    );
  }
}

class _BgPainter extends CustomPainter {
  final double t;
  _BgPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()
      ..color = _C.border.withOpacity(0.03)
      ..strokeWidth = 0.3;
    const step = 30.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }

    final glow1 = Paint()
      ..shader = RadialGradient(colors: [
        _C.text.withOpacity(0.01 + math.sin(t * math.pi * 2) * 0.004),
        Colors.transparent,
      ], radius: 0.8).createShader(Rect.fromCircle(
          center: Offset(size.width * 0.2, size.height * 0.1),
          radius: size.width * 0.5));
    canvas.drawCircle(
        Offset(size.width * 0.2, size.height * 0.1),
        size.width * 0.5, glow1);

    final glow2 = Paint()
      ..shader = RadialGradient(colors: [
        _C.text.withOpacity(0.008 + math.cos(t * math.pi * 2) * 0.004),
        Colors.transparent,
      ], radius: 0.6).createShader(Rect.fromCircle(
          center: Offset(size.width * 0.85, size.height * 0.75),
          radius: size.width * 0.4));
    canvas.drawCircle(
        Offset(size.width * 0.85, size.height * 0.75),
        size.width * 0.4, glow2);
  }

  @override
  bool shouldRepaint(_BgPainter old) => old.t != t;
}

PageRoute _slideRoute(Widget page) => PageRouteBuilder(
      pageBuilder: (_, __, ___) => page,
      transitionDuration: const Duration(milliseconds: 400),
      transitionsBuilder: (_, anim, __, child) =>
          SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(1, 0),
          end: Offset.zero,
        ).animate(CurvedAnimation(
            parent: anim, curve: Curves.easeOutCubic)),
        child: FadeTransition(opacity: anim, child: child),
      ),
    );

class _ToolItem {
  final IconData icon;
  final String label;
  final Color accent;
  final Color accentLight;
  final VoidCallback onTap;
  final bool comingSoon;

  _ToolItem({
    required this.icon,
    required this.label,
    required this.accent,
    required this.onTap,
    this.comingSoon = false,
  }) : accentLight = accent.withAlpha(200);
}