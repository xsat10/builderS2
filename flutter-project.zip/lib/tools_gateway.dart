import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'phone_lookup.dart';
import 'email_osint.dart';
import 'ip_scanner.dart';
import 'port_scanner.dart';
import 'dracin_page.dart';
import 'device_dashboard.dart';
import 'anime_home.dart';
import 'hentai.dart';

// ─── Palette: Clean Modern ────────────────────────────────────────────────────
class _C {
  static const bg         = Color(0xFFF5F6FA);
  static const surface    = Color(0xFFFFFFFF);
  static const card       = Color(0xFFFFFFFF);
  static const cardInner  = Color(0xFFF8F9FC);

  static const border     = Color(0xFFE5E8F0);
  static const borderLit  = Color(0xFFD0D5E0);

  static const text       = Color(0xFF1A1A2E);
  static const textSub    = Color(0xFF6B7280);
  static const textDim    = Color(0xFF9CA3AF);

  static const blue       = Color(0xFF2E75B6);
  static const blueLight  = Color(0xFF5B9BD5);
  static const blueSoft   = Color(0xFFE8F1FA);
  static const teal       = Color(0xFF26A69A);
  static const tealSoft   = Color(0xFFE0F2F1);
  static const green      = Color(0xFF43A047);
  static const greenSoft  = Color(0xFFE8F5E9);
  static const orange     = Color(0xFFFF9800);
  static const orangeSoft = Color(0xFFFFF3E0);
  static const purple     = Color(0xFF7C4DFF);
  static const purpleSoft = Color(0xFFEDE7F6);
  static const red        = Color(0xFFE53935);
  static const redSoft    = Color(0xFFFEEBEE);
  static const pink       = Color(0xFFEC407A);
  static const pinkSoft   = Color(0xFFFCE4EC);
  static const amber      = Color(0xFFFBC02D);
  static const amberSoft  = Color(0xFFFFF8E1);
}

// ─── Tool Category Data ───────────────────────────────────────────────────────
class _ToolCategory {
  final String id;
  final String title;
  final String subtitle;
  final String badge;
  final IconData icon;
  final Color accent;
  final Color accentSoft;

  const _ToolCategory({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.badge,
    required this.icon,
    required this.accent,
    required this.accentSoft,
  });
}

// 13 Kategori
const _categories = [
  _ToolCategory(
    id: 'panel',
    title: 'Manage Server',
    subtitle: 'Hosting · VPS · Server',
    badge: 'Hosting',
    icon: Icons.dns_rounded,
    accent: _C.blue,
    accentSoft: _C.blueSoft,
  ),
  _ToolCategory(
    id: 'ddos',
    title: 'Attack Panel',
    subtitle: 'DDoS · Stress Test',
    badge: 'Panel',
    icon: Icons.bolt_rounded,
    accent: _C.red,
    accentSoft: _C.redSoft,
  ),
  _ToolCategory(
    id: 'spamngl',
    title: 'Spam NGL',
    subtitle: 'Anonymous Message',
    badge: 'Social',
    icon: Icons.newspaper_outlined,
    accent: _C.amber,
    accentSoft: _C.amberSoft,
  ),
  _ToolCategory(
    id: 'wifi',
    title: 'WiFi Killer',
    subtitle: 'Internal · External',
    badge: 'Network',
    icon: Icons.wifi_off_rounded,
    accent: _C.teal,
    accentSoft: _C.tealSoft,
  ),
  _ToolCategory(
    id: 'osint',
    title: 'OSINT Tools',
    subtitle: 'NIK · Domain · Phone',
    badge: 'Deep Search',
    icon: Icons.search_rounded,
    accent: _C.blue,
    accentSoft: _C.blueSoft,
  ),
  _ToolCategory(
    id: 'email',
    title: 'Email OSINT',
    subtitle: 'Email Intelligence',
    badge: 'OSINT',
    icon: Icons.alternate_email_rounded,
    accent: _C.purple,
    accentSoft: _C.purpleSoft,
  ),
  _ToolCategory(
    id: 'downloader',
    title: 'Downloader',
    subtitle: 'TikTok · Instagram',
    badge: 'Income',
    icon: Icons.download_rounded,
    accent: _C.orange,
    accentSoft: _C.orangeSoft,
  ),
  _ToolCategory(
    id: 'qr',
    title: 'QR Generator',
    subtitle: 'Generate QR Code',
    badge: 'Utility',
    icon: Icons.qr_code_2_rounded,
    accent: _C.green,
    accentSoft: _C.greenSoft,
  ),
  _ToolCategory(
    id: 'scanner',
    title: 'IP & Port Scanner',
    subtitle: 'Network Scanner',
    badge: 'Network',
    icon: Icons.network_check_rounded,
    accent: _C.teal,
    accentSoft: _C.tealSoft,
  ),
  _ToolCategory(
    id: 'watchs',
    title: 'Watch Video',
    subtitle: 'Anime · Dracin',
    badge: 'Video',
    icon: Icons.play_circle_rounded,
    accent: _C.blue,
    accentSoft: _C.blueSoft,
  ),
  _ToolCategory(
    id: 'ratcontrol',
    title: 'RAT Control',
    subtitle: 'Remote Access',
    badge: 'RAT',
    icon: Icons.devices_rounded,
    accent: _C.red,
    accentSoft: _C.redSoft,
  ),
  _ToolCategory(
    id: 'adulthub',
    title: 'Adult Hub',
    subtitle: '18+ Only',
    badge: 'Adult',
    icon: Icons.lock_rounded,
    accent: _C.pink,
    accentSoft: _C.pinkSoft,
  ),
  _ToolCategory(
    id: 'about',
    title: 'About & Info',
    subtitle: 'Tentang aplikasi',
    badge: 'Info',
    icon: Icons.info_outline_rounded,
    accent: _C.blueLight,
    accentSoft: _C.blueSoft,
  ),
];

// ─── Page ─────────────────────────────────────────────────────────────────────
class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> with TickerProviderStateMixin {
  late AnimationController _headerCtrl;
  late Animation<double> _headerFade;
  late Animation<Offset> _headerSlide;

  @override
  void initState() {
    super.initState();
    _headerCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 700));
    _headerFade = CurvedAnimation(parent: _headerCtrl, curve: Curves.easeOut);
    _headerSlide = Tween<Offset>(begin: const Offset(0, -0.2), end: Offset.zero)
        .animate(
            CurvedAnimation(parent: _headerCtrl, curve: Curves.easeOutCubic));
    _headerCtrl.forward();
  }

  @override
  void dispose() {
    _headerCtrl.dispose();
    super.dispose();
  }

  void _push(Widget page) => Navigator.push(context, _slideRoute(page));

  void _onCategoryTap(String id) {
    switch (id) {
      case 'panel':
        _push(ManageServerPage(keyToken: widget.sessionKey));
        break;
      case 'ddos':
        _push(AttackPanel(
            sessionKey: widget.sessionKey, listDoos: widget.listDoos));
        break;
      case 'spamngl':
        _push(NglPage());
        break;
      case 'wifi':
        _showSheet(_wifiItems());
        break;
      case 'osint':
        _showSheet(_osintItems());
        break;
      case 'email':
        _push(const EmailOsintPage());
        break;
      case 'downloader':
        _showSheet(_downloaderItems());
        break;
      case 'qr':
        _push(const QrGeneratorPage());
        break;
      case 'scanner':
        _showSheet(_scannerItems());
        break;
      case 'watchs':
        _showSheet(_watchsItems());
        break;
      case 'ratcontrol':
        // ✅ PERBAIKAN: kirim sessionKey (tidak pakai const lagi)
        _push(DeviceDashboardPage(sessionKey: widget.sessionKey));
        break;
      case 'adulthub':
        _push(const HomeHentaiPage());
        break;
      case 'about':
        _showAboutDialog();
        break;
    }
  }

  void _showAboutDialog() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _C.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        title: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: _C.blueSoft,
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(Icons.info_outline_rounded,
                  color: _C.blue, size: 20),
            ),
            const SizedBox(width: 12),
            const Text('Tentang',
                style: TextStyle(
                    color: _C.text,
                    fontSize: 18,
                    fontWeight: FontWeight.w900)),
          ],
        ),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('SYAM TOOLS v2.0',
                style: TextStyle(
                    color: _C.text,
                    fontSize: 14,
                    fontWeight: FontWeight.w700)),
            SizedBox(height: 8),
            Text(
                'Kumpulan tools premium untuk kebutuhan Anda. Terus berkembang dengan tools baru.',
                style: TextStyle(
                    color: _C.textSub, fontSize: 12, height: 1.5)),
            SizedBox(height: 12),
            Text('© 2026 SYAM TEAM',
                style: TextStyle(
                    color: _C.textDim,
                    fontSize: 11,
                    fontWeight: FontWeight.w500)),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK',
                style: TextStyle(
                    color: _C.blue, fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );
  }

  List<_ToolItem> _wifiItems() => [
        _ToolItem(
            icon: Icons.wifi_off_rounded,
            label: 'WiFi Killer (Internal)',
            accent: _C.teal,
            onTap: () => _push(WifiKillerPage())),
        if ([
          'vip',
          'owner',
          'high_owner',
          'founder',
          'developer'
        ].contains(widget.userRole))
          _ToolItem(
              icon: Icons.router_rounded,
              label: 'WiFi Killer (External)',
              accent: _C.teal,
              onTap: () =>
                  _push(WifiInternalPage(sessionKey: widget.sessionKey))),
      ];

  List<_ToolItem> _osintItems() => [
        _ToolItem(
            icon: Icons.badge_outlined,
            label: 'NIK Detail',
            accent: _C.blue,
            onTap: () => _push(const NikCheckerPage())),
        _ToolItem(
            icon: Icons.travel_explore_rounded,
            label: 'Domain OSINT',
            accent: _C.blue,
            onTap: () => _push(const DomainOsintPage())),
        _ToolItem(
            icon: Icons.person_search_rounded,
            label: 'Phone Lookup',
            accent: _C.blue,
            onTap: () => _push(const PhoneLookupPage())),
      ];

  List<_ToolItem> _downloaderItems() => [
        _ToolItem(
            icon: Icons.video_library_rounded,
            label: 'TikTok Downloader',
            accent: _C.orange,
            onTap: () => _push(const TiktokDownloaderPage())),
        _ToolItem(
            icon: Icons.camera_alt_rounded,
            label: 'Instagram Downloader',
            accent: _C.orange,
            onTap: () => _push(const InstagramDownloaderPage())),
      ];

  List<_ToolItem> _scannerItems() => [
        _ToolItem(
            icon: Icons.security_rounded,
            label: 'IP Scanner',
            accent: _C.teal,
            onTap: () => _push(const IpScannerPage())),
        _ToolItem(
            icon: Icons.network_check_rounded,
            label: 'Port Scanner',
            accent: _C.teal,
            onTap: () => _push(const PortScannerPage())),
      ];

  List<_ToolItem> _watchsItems() => [
        _ToolItem(
            icon: Icons.animation_rounded,
            label: 'Anime',
            accent: _C.blue,
            onTap: () => _push(const HomeAnimePage())),
        _ToolItem(
            icon: Icons.play_circle_rounded,
            label: 'Dracin',
            accent: _C.blue,
            onTap: () => _push(const DracinPage())),
      ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Stack(
        children: [
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Color(0xFFEAF0F8),
                    Color(0xFFF5F6FA),
                    Color(0xFFFFFFFF),
                  ],
                ),
              ),
            ),
          ),

          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.only(bottom: 100),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  FadeTransition(
                    opacity: _headerFade,
                    child: SlideTransition(
                      position: _headerSlide,
                      child: _buildBanner(),
                    ),
                  ),
                  const SizedBox(height: 20),
                  _buildDividerLabel(),
                  const SizedBox(height: 20),
                  _buildInfoBox(),
                  const SizedBox(height: 28),

                  // ── Header Kategori ──
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'KATEGORI MENU',
                              style: TextStyle(
                                color: _C.text,
                                fontSize: 20,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 1.2,
                              ),
                            ),
                            SizedBox(height: 6),
                            Text(
                              'Pilih kategori menu yang Anda butuhkan.',
                              style: TextStyle(
                                  color: _C.textSub, fontSize: 12),
                            ),
                          ],
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 14, vertical: 8),
                          decoration: BoxDecoration(
                            color: _C.blueSoft,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            '${_categories.length} Modules',
                            style: const TextStyle(
                                color: _C.blue,
                                fontSize: 11,
                                fontWeight: FontWeight.w800),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),

                  // ── Grid 2 Kolom ──
                  GridView.builder(
                    physics: const NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 14,
                      mainAxisSpacing: 14,
                      childAspectRatio: 0.9,
                    ),
                    itemCount: _categories.length,
                    itemBuilder: (_, i) => _StaggerItem(
                      index: i,
                      child: _CategoryCard(
                        category: _categories[i],
                        onTap: () => _onCategoryTap(_categories[i].id),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Karakter Anime kanan bawah
          Positioned(
            bottom: 80,
            right: -10,
            child: IgnorePointer(
              child: Image.asset(
                'assets/images/kontol.jpg',
                width: 130,
                height: 130,
                fit: BoxFit.contain,
                errorBuilder: (_, __, ___) => const SizedBox.shrink(),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBanner() {
    return Container(
      margin: const EdgeInsets.fromLTRB(20, 16, 20, 0),
      height: 220,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        boxShadow: [
          BoxShadow(
            color: _C.blue.withValues(alpha: 0.15),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(22),
        child: Stack(
          children: [
            Positioned.fill(
              child: Image.asset(
                'assets/images/tools.jpg',
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  color: _C.blueSoft,
                ),
              ),
            ),
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.bottomLeft,
                    end: Alignment.topRight,
                    colors: [
                      Colors.black.withValues(alpha: 0.6),
                      Colors.black.withValues(alpha: 0.15),
                      Colors.transparent,
                    ],
                    stops: const [0.0, 0.5, 1.0],
                  ),
                ),
              ),
            ),
            Positioned(
              top: 14,
              left: 14,
              child: Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white, width: 2.5),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.25),
                      blurRadius: 10,
                      offset: const Offset(0, 3),
                    ),
                  ],
                  image: const DecorationImage(
                    image: AssetImage('assets/images/logo.jpg'),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Positioned(
              bottom: 18,
              left: 18,
              right: 18,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'SYAM TOOLS',
                    style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.85),
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 3,
                    ),
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    'Tools Gateway',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 26,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 0.5,
                      height: 1.1,
                      shadows: [
                        Shadow(
                          color: Colors.black45,
                          blurRadius: 10,
                          offset: Offset(0, 2),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'Tools Unik · Hosting · AI · OSINT & lainnya',
                    style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.85),
                      fontSize: 11,
                      letterSpacing: 0.3,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDividerLabel() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 40),
      child: Row(
        children: [
          Expanded(
              child: Container(
                  height: 1, color: _C.borderLit.withValues(alpha: 0.5))),
          const SizedBox(width: 12),
          const Icon(Icons.settings_rounded, color: _C.textDim, size: 12),
          const SizedBox(width: 8),
          Text(
            'TOOLS GATEWAY',
            style: TextStyle(
              color: _C.textSub,
              fontSize: 10,
              fontWeight: FontWeight.w700,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(width: 8),
          const Icon(Icons.settings_rounded, color: _C.textDim, size: 12),
          const SizedBox(width: 12),
          Expanded(
              child: Container(
                  height: 1, color: _C.borderLit.withValues(alpha: 0.5))),
        ],
      ),
    );
  }

  Widget _buildInfoBox() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 20),
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _C.border, width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _buildInfoItem('ROLE', widget.userRole.toUpperCase()),
          Container(
              height: 34,
              width: 1,
              color: _C.border.withValues(alpha: 0.6)),
          _buildInfoItem('JUMLAH MENU', '${_categories.length} TOOLS'),
          Container(
              height: 34,
              width: 1,
              color: _C.border.withValues(alpha: 0.6)),
          _buildInfoItem('SESSION', 'READY', isActive: true),
        ],
      ),
    );
  }

  Widget _buildInfoItem(String label, String value, {bool isActive = false}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text(
          label,
          style: const TextStyle(
            color: _C.textDim,
            fontSize: 9,
            fontWeight: FontWeight.w700,
            letterSpacing: 1.2,
          ),
        ),
        const SizedBox(height: 6),
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              value,
              style: TextStyle(
                color: isActive ? _C.blue : _C.text,
                fontSize: 12,
                fontWeight: FontWeight.w900,
                letterSpacing: 0.5,
              ),
            ),
            if (isActive) ...[
              const SizedBox(width: 6),
              Container(
                width: 8,
                height: 8,
                decoration: const BoxDecoration(
                  color: Color(0xFF22C55E),
                  shape: BoxShape.circle,
                ),
              ),
            ]
          ],
        ),
      ],
    );
  }

  void _showSheet(List<_ToolItem> items) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => _ToolSheet(items: items),
    );
  }
}

// ─── Category Card — dengan garis warna di atas ──────────────────────────────
class _CategoryCard extends StatefulWidget {
  final _ToolCategory category;
  final VoidCallback onTap;

  const _CategoryCard({required this.category, required this.onTap});

  @override
  State<_CategoryCard> createState() => _CategoryCardState();
}

class _CategoryCardState extends State<_CategoryCard> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final cat = widget.category;

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.96 : 1.0,
        duration: const Duration(milliseconds: 120),
        child: Container(
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _C.border, width: 1),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.04),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // ── Garis warna di atas ──
                Container(
                  height: 4,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        cat.accent,
                        cat.accent.withValues(alpha: 0.5),
                      ],
                    ),
                  ),
                ),

                // ── Konten ──
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              width: 50,
                              height: 50,
                              decoration: BoxDecoration(
                                color: cat.accentSoft,
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(
                                    color:
                                        cat.accent.withValues(alpha: 0.15),
                                    width: 1),
                              ),
                              child: Icon(cat.icon,
                                  color: cat.accent, size: 26),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 5),
                              decoration: BoxDecoration(
                                color: cat.accentSoft,
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Text(
                                cat.badge,
                                style: TextStyle(
                                  color: cat.accent,
                                  fontSize: 9,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 0.3,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const Spacer(),
                        Text(
                          cat.title,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: _C.text,
                            fontSize: 14,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 0.2,
                            height: 1.2,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          cat.subtitle,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: _C.textSub,
                            fontSize: 10,
                            height: 1.3,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─── Tool Sheet ──────────────────────────────────────────────────────────────
class _ToolSheet extends StatelessWidget {
  final List<_ToolItem> items;
  const _ToolSheet({required this.items});

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: BoxConstraints(
        maxHeight: MediaQuery.of(context).size.height * 0.72,
      ),
      decoration: const BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 12, bottom: 8),
            child: Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: _C.borderLit,
                borderRadius: BorderRadius.circular(100),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Flexible(
            child: ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
              shrinkWrap: true,
              physics: const BouncingScrollPhysics(),
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (ctx, i) => _StaggerItem(
                index: i,
                child: _ToolRow(
                  item: items[i],
                  onTap: () {
                    Navigator.pop(ctx);
                    items[i].onTap();
                  },
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Tool Row ────────────────────────────────────────────────────────────────
class _ToolRow extends StatefulWidget {
  final _ToolItem item;
  final VoidCallback onTap;
  const _ToolRow({required this.item, required this.onTap});

  @override
  State<_ToolRow> createState() => _ToolRowState();
}

class _ToolRowState extends State<_ToolRow> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final item = widget.item;
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 100),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        decoration: BoxDecoration(
          color: _pressed ? _C.cardInner : _C.card,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _C.border, width: 1),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.03),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: item.accent.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(item.icon, color: item.accent, size: 20),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(item.label,
                    style: const TextStyle(
                        color: _C.text,
                        fontSize: 14,
                        fontWeight: FontWeight.w700)),
                if (item.comingSoon)
                  const Text('Coming Soon',
                      style: TextStyle(
                          color: _C.textDim,
                          fontSize: 10,
                          fontWeight: FontWeight.w500)),
              ],
            ),
          ),
          item.comingSoon
              ? Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: _C.amberSoft,
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: const Text('SOON',
                      style: TextStyle(
                          color: _C.amber,
                          fontSize: 9,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.5)),
                )
              : Container(
                  width: 30,
                  height: 30,
                  decoration: BoxDecoration(
                    color: _C.blueSoft,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(Icons.arrow_forward_ios_rounded,
                      color: _C.blue, size: 12),
                ),
        ]),
      ),
    );
  }
}

// ─── Stagger Item ────────────────────────────────────────────────────────────
class _StaggerItem extends StatelessWidget {
  final int index;
  final Widget child;
  const _StaggerItem({required this.index, required this.child});

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 350 + (index * 60).clamp(0, 450)),
      curve: Curves.easeOutCubic,
      builder: (_, v, ch) => Opacity(
        opacity: v,
        child:
            Transform.translate(offset: Offset(0, 18 * (1 - v)), child: ch),
      ),
      child: child,
    );
  }
}

// ─── Page transition ─────────────────────────────────────────────────────────
PageRoute _slideRoute(Widget page) => PageRouteBuilder(
      pageBuilder: (_, __, ___) => page,
      transitionDuration: const Duration(milliseconds: 350),
      transitionsBuilder: (_, anim, __, child) => SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(1, 0),
          end: Offset.zero,
        ).animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
        child: FadeTransition(opacity: anim, child: child),
      ),
    );

// ─── Data model ──────────────────────────────────────────────────────────────
class _ToolItem {
  final IconData icon;
  final String label;
  final Color accent;
  final VoidCallback onTap;
  final bool comingSoon;

  const _ToolItem({
    required this.icon,
    required this.label,
    required this.accent,
    required this.onTap,
    this.comingSoon = false,
  });
}