// ============================================================
// 🧰 TOOLS GATEWAY — Dark Red Comic 3D Edition
// File: tools_gateway.dart
// v6 — + DANA Wallet + Check Banned
// ============================================================
import 'dart:ui';
import 'dart:math' as math;
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// Import Alight Premium Page
import 'alight_premium_page.dart';

// ── NEW PAGES ────────────────────────────────────
import 'youtube_player_page.dart';
import 'kalkulator.dart';
import 'iqc_page.dart';
import 'dana_page.dart';            // ═══ DANA WALLET ═══
import 'check_banned_page.dart';    // ═══ CHECK BANNED ═══

// Existing imports
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'phone_lookup.dart';
import 'email_osint.dart';
import 'ip_scanner.dart';
import 'port_scanner.dart';
import 'dracin_page.dart';
import 'device_dashboard.dart';
import 'anime_home.dart';
import 'hentai.dart';
import 'sliding_puzzle.dart';
import 'pacman.dart';
import 'quiz_page.dart';
import 'tictactoe.dart';
import 'remi_poker.dart';
import 'gemini_ai.dart';
import 'music_page.dart';
import 'termux_page.dart';
import 'main_trading_page.dart';
import 'webview_tool_shell.dart';
import 'mchub_page.dart';
import 'tiktok_mc_page.dart';
import 'netfly_app_page.dart';
import 'chroom_page.dart';
import 'pintesert_page.dart';
import 'telegram_player_page.dart';

// ═════════════════════════════════════════════════════════════
// 🎨 DARK RED COMIC PALETTE
// ═════════════════════════════════════════════════════════════
class _MC {
  static const red          = Color(0xFF8B0000);
  static const redDeep      = Color(0xFF1A0A0A);
  static const redDark      = Color(0xFF4A0000);
  static const redSoft      = Color(0xFF2A0E0E);
  static const redLight     = Color(0xFF3D1414);
  static const accentRed    = Color(0xFFD32F2F);
  static const brightRed    = Color(0xFFFF3B3B);
  static const white        = Color(0xFFFFF5F5);
  static const cream        = Color(0xFF0F0505);
  static const textDark     = Color(0xFFFFF5F5);
  static const textGrey     = Color(0xFFC9A0A0);
  static const textLight    = Color(0xFF8A6060);
  // ═══ COMIC OUTLINE ═══
  static const comicBlack   = Color(0xFF000000);
  static const comicOutline = Color(0xFF1A0000);
  static const buttonYellow = Color(0xFFB8860B);
  static const buttonDark   = Color(0xFF1A1A1A);
  // ═══ ACCENT COLORS ═══
  static const green        = Color(0xFF22C55E);
  static const greenLite    = Color(0xFF4ADE80);
  static const amber        = Color(0xFFFBBF24);
  static const gold         = Color(0xFFFDE68A);
  static const blueCheck    = Color(0xFF60A5FA);
  static const danaBlue     = Color(0xFF0B6EF5);
}

// ═════════════════════════════════════════════════════════════
// 🎭 ROLE HELPERS
// ═════════════════════════════════════════════════════════════
Color _roleColor(String role) {
  switch (role.toLowerCase()) {
    case 'owner_utama': return const Color(0xFFFF3B3B);
    case 'owner': return const Color(0xFFFFB300);
    case 'staff': return const Color(0xFFE53935);
    case 'executorius': return const Color(0xFFFF6B00);
    case 'forius_utama': return const Color(0xFFFF8F00);
    case 'moderator': return const Color(0xFF7E57C2);
    case 'ceo_utama': return const Color(0xFF5C6BC0);
    case 'tangan_kanan': return const Color(0xFF26C6DA);
    case 'tangan_kiri': return const Color(0xFF4DD0E1);
    case 'developers': return const Color(0xFF29B6F6);
    case 'partner_pribadi': return const Color(0xFF66BB6A);
    case 'partner': return const Color(0xFF43A047);
    case 'admin': return const Color(0xFF26A69A);
    case 'tukang_bubur': return const Color(0xFFFFCA28);
    case 'reseller': return const Color(0xFF9CCC65);
    case 'vip': return const Color(0xFFFFD54F);
    default: return _MC.brightRed;
  }
}

int _roleRingLevel(String role) {
  switch (role.toLowerCase()) {
    case 'member': return 1;
    case 'vip':
    case 'reseller':
    case 'tukang_bubur': return 2;
    case 'admin':
    case 'partner':
    case 'partner_pribadi': return 3;
    case 'tangan_kiri':
    case 'tangan_kanan':
    case 'developers':
    case 'ceo_utama':
    case 'moderator': return 4;
    case 'forius_utama':
    case 'executorius':
    case 'staff': return 5;
    case 'owner':
    case 'owner_utama': return 6;
    default: return 1;
  }
}

bool _isVerifiedRole(String role) {
  return [
    'executorius', 'forius_utama', 'staff',
    'owner', 'owner_utama', 'moderator', 'ceo_utama',
  ].contains(role.toLowerCase());
}

String? _roleBadgeEmoji(String role) {
  switch (role.toLowerCase()) {
    case 'vip': return '⭐️';
    case 'reseller': return '🏪';
    case 'tukang_bubur': return '🍜';
    case 'admin': return '🔧';
    case 'partner': return '🤝';
    case 'partner_pribadi': return '💼';
    default: return null;
  }
}

// ═════════════════════════════════════════════════════════════
// 📋 TOOLS PAGE
// ═════════════════════════════════════════════════════════════
class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage>
    with TickerProviderStateMixin {
  int _themeIndex = 1;
  String _searchQuery = '';
  String _selectedCategory = 'ALL';
  bool _isReorderMode = false;
  bool _onlyFavorites = false;

  // Info stats
  int _totalOnlineUsers = 0;
  int _totalUsers = 0;
  bool _statsLoading = true;

  final TextEditingController _searchController = TextEditingController();
  final Set<String> _favoriteTools = {
    'Alight Premium Claim',
    'Asisten AI Gemini',
    'Kalkulator',
    'Quote Chat',
  };

  late List<_ToolItemData> _masterToolsList;

  late AnimationController _ringCtrl;
  late AnimationController _catCtrl;
  late AnimationController _badgeController;
  late Animation<double> _badgeSwing;

  @override
  void initState() {
    super.initState();
    _initTools();
    _ringCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    )..repeat();
    _catCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 320),
      value: 1.0,
    );
    // ═══ BADGE SWING ANIMATION ═══
    _badgeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2400),
    )..repeat(reverse: true);
    _badgeSwing = Tween<double>(begin: -0.05, end: 0.05).animate(
      CurvedAnimation(parent: _badgeController, curve: Curves.easeInOut),
    );
    _fetchStats();
  }

  Future<void> _fetchStats() async {
    try {
      final res = await http
          .get(Uri.parse(
              'http://shinoa-cpanelpanel.xtxintax.my.id:2003/api/stats?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (mounted) {
          setState(() {
            _totalOnlineUsers = data['onlineUsers'] ?? 0;
            _totalUsers = data['totalUsers'] ?? 0;
            _statsLoading = false;
          });
        }
      } else {
        if (mounted) setState(() => _statsLoading = false);
      }
    } catch (_) {
      if (mounted) setState(() => _statsLoading = false);
    }
  }

  @override
  void dispose() {
    _searchController.dispose();
    _ringCtrl.dispose();
    _catCtrl.dispose();
    _badgeController.dispose();
    super.dispose();
  }

  void _initTools() {
    _masterToolsList = [
       // ═══ CHECK BANNED (BARU) ═══
      _ToolItemData(
        id: 'check_banned',
        name: 'Check Banned',
        subtitle: 'Cek status banned akun & device',
        icon: Icons.gpp_bad_rounded,
        category: 'OSINT',
        onTap: () => _push(CheckBannedPage(sessionKey: widget.sessionKey)),
      ),
        // ═══ DANA WALLET ═══
      _ToolItemData(
        id: 'dana',
        name: 'DANA Wallet',
        subtitle: 'Dompet digital • saldo • top up',
        icon: Icons.account_balance_wallet_rounded,
        category: 'ALL IN ONE',
        onTap: () => _push(DanaPage(username: widget.sessionKey)),
      ),
      _ToolItemData(
        id: 'youtube_player',
        name: 'Youtube Player',
        subtitle: 'Untuk menonton video YouTube',
        icon: Icons.play_circle_fill_rounded,
        category: 'ENTERTAINMENT',
        onTap: () => _push(const YoutubePlayerPage()),
      ),
      _ToolItemData(
        id: 'mchub',
        name: 'McHub',
        subtitle: 'GitHub WebView real-time',
        icon: Icons.code_rounded,
        category: 'WEBVIEW',
        onTap: () => _push(const McHubPage()),
      ),
      _ToolItemData(
        id: 'tiktok_mc',
        name: 'TikTokMc',
        subtitle: 'TikTok WebView real-time',
        icon: Icons.music_note_rounded,
        category: 'WEBVIEW',
        onTap: () => _push(const TikTokMcPage()),
      ),
      _ToolItemData(
        id: 'netfly_app',
        name: 'NetflyApp',
        subtitle: 'Netflix WebView real-time',
        icon: Icons.movie_filter_rounded,
        category: 'WEBVIEW',
        onTap: () => _push(const NetflyAppPage()),
      ),
      _ToolItemData(
        id: 'chroom',
        name: 'Chroom',
        subtitle: 'Browser WebView real-time',
        icon: Icons.language_rounded,
        category: 'WEBVIEW',
        onTap: () => _push(const ChroomPage()),
      ),
      _ToolItemData(
        id: 'X-SPYDER_gram',
        name: 'X-SPYDERGram',
        subtitle: 'Telegram Web real-time',
        icon: Icons.send_rounded,
        category: 'WEBVIEW',
        onTap: () => _push(const TelegramPlayerPage()),
      ),
      _ToolItemData(
        id: 'pintesert',
        name: 'Pintesert',
        subtitle: 'Pinterest WebView real-time',
        icon: Icons.push_pin_rounded,
        category: 'WEBVIEW',
        onTap: () => _push(const PintesertPage()),
      ),
      _ToolItemData(
        id: 'kalkulator',
        name: 'Kalkulator',
        subtitle: 'Kalkulator scientific cepat',
        icon: Icons.calculate_rounded,
        category: 'UTILITIES',
        onTap: () => _push(KalkulatorPage()),
      ),
      _ToolItemData(
        id: 'iqc',
        name: 'Quote Chat',
        subtitle: 'Buat quote chat iPhone keren',
        icon: Icons.phone_iphone_rounded,
        category: 'EXTRA',
        onTap: () => _push(IQCPage(
          sessionKey: widget.sessionKey,
        )),
      ),
      _ToolItemData(
        id: 'alight_premium',
        name: 'Alight Premium Claim',
        subtitle: 'Claim unlock & activation',
        icon: Icons.bolt_rounded,
        category: 'ALL IN ONE',
        onTap: () => _push(const AlightPremiumPage()),
      ),
      _ToolItemData(
        id: 'gemini_ai',
        name: 'Asisten AI Gemini',
        subtitle: 'Kecerdasan buatan serbaguna',
        icon: Icons.auto_awesome_rounded,
        category: 'ALL IN ONE',
        onTap: () => _push(GeminiAIPage(sessionKey: widget.sessionKey)),
      ),
      _ToolItemData(
        id: 'anime',
        name: 'Anime Hub',
        subtitle: 'Streaming & koleksi anime',
        icon: Icons.tv_rounded,
        category: 'ENTERTAINMENT',
        onTap: () => _push(HomeAnimePage()),
      ),
      _ToolItemData(
        id: 'dracin',
        name: 'Dracin Hub',
        subtitle: 'Nonton drama China terpopuler',
        icon: Icons.play_circle_fill_rounded,
        category: 'ENTERTAINMENT',
        onTap: () => _push(const DracinPage()),
      ),
      _ToolItemData(
        id: 'tiktok_dl',
        name: 'TikTok Downloader',
        subtitle: 'Unduh video TikTok tanpa watermark',
        icon: Icons.video_library_rounded,
        category: 'UTILITIES',
        onTap: () => _push(const TiktokDownloaderPage()),
      ),
      _ToolItemData(
        id: 'ig_dl',
        name: 'Instagram Downloader',
        subtitle: 'Download foto, video & reels',
        icon: Icons.camera_alt_rounded,
        category: 'UTILITIES',
        onTap: () => _push(const InstagramDownloaderPage()),
      ),
      _ToolItemData(
        id: 'music_bmw',
        name: 'Music BMW Player',
        subtitle: 'Pemutar musik visual keren',
        icon: Icons.graphic_eq_rounded,
        category: 'ENTERTAINMENT',
        onTap: () => _push(const MusicPage()),
      ),
      _ToolItemData(
        id: 'spam_ngl',
        name: 'Spam NGL',
        subtitle: 'Kirim pesan NGL massal',
        icon: Icons.mail_outline_rounded,
        category: 'NETWORK',
        onTap: () => _push(NglPage()),
      ),
      _ToolItemData(
        id: 'wifi_internal',
        name: 'WiFi Internal',
        subtitle: 'Manajemen jaringan lokal',
        icon: Icons.wifi_off_rounded,
        category: 'NETWORK',
        onTap: () => _push(WifiKillerPage()),
      ),
      if (widget.userRole == 'vip' || widget.userRole == 'owner')
        _ToolItemData(
          id: 'wifi_external',
          name: 'WiFi External',
          subtitle: 'Penguji penetrasi jaringan luar',
          icon: Icons.router_rounded,
          category: 'NETWORK',
          onTap: () => _push(WifiInternalPage(sessionKey: widget.sessionKey)),
        ),
      _ToolItemData(
        id: 'nik_check',
        name: 'NIK Detail Check',
        subtitle: 'Cek data kependudukan NIK',
        icon: Icons.badge_outlined,
        category: 'OSINT',
        onTap: () => _push(const NikCheckerPage()),
      ),
      _ToolItemData(
        id: 'domain_osint',
        name: 'Domain OSINT',
        subtitle: 'Analisis DNS, Whois & Server',
        icon: Icons.language_rounded,
        category: 'OSINT',
        onTap: () => _push(const DomainOsintPage()),
      ),
      _ToolItemData(
        id: 'phone_lookup',
        name: 'Phone Lookup',
        subtitle: 'Lacak identitas nomor HP',
        icon: Icons.person_search_rounded,
        category: 'OSINT',
        onTap: () => _push(const PhoneLookupPage()),
      ),
      _ToolItemData(
        id: 'email_osint',
        name: 'Email OSINT',
        subtitle: 'Pemeriksaan kebocoran email',
        icon: Icons.alternate_email_rounded,
        category: 'OSINT',
        onTap: () => _push(const EmailOsintPage()),
      ),
      _ToolItemData(
        id: 'qr_gen',
        name: 'QR Code Generator',
        subtitle: 'Buat kode QR kustom 3D',
        icon: Icons.qr_code_2_rounded,
        category: 'UTILITIES',
        onTap: () => _push(const QrGeneratorPage()),
      ),
      _ToolItemData(
        id: 'ip_scanner',
        name: 'IP Scanner',
        subtitle: 'Pindai perangkat aktif',
        icon: Icons.security_rounded,
        category: 'NETWORK',
        onTap: () => _push(const IpScannerPage()),
      ),
      _ToolItemData(
        id: 'port_scanner',
        name: 'Port Scanner',
        subtitle: 'Analisis port terbuka',
        icon: Icons.network_check_rounded,
        category: 'NETWORK',
        onTap: () => _push(const PortScannerPage()),
      ),
      _ToolItemData(
        id: 'manage_server',
        name: 'Manage Server',
        subtitle: 'Kontrol & monitoring VPS',
        icon: Icons.dns_rounded,
        category: 'UTILITIES',
        onTap: () => _push(ManageServerPage(keyToken: widget.sessionKey)),
      ),
      _ToolItemData(
        id: 'adult_hub',
        name: 'Adult Hub (18+)',
        subtitle: 'Koleksi hiburan dewasa',
        icon: Icons.lock_rounded,
        category: 'ENTERTAINMENT',
        onTap: () => _push(const HomeHentaiPage()),
      ),
      _ToolItemData(
        id: 'sliding_puzzle',
        name: 'Sliding Puzzle 3D',
        subtitle: 'Game asah otak geser angka',
        icon: Icons.grid_view_rounded,
        category: 'GAMES',
        onTap: () => _push(const SlidingPuzzle()),
      ),
      _ToolItemData(
        id: 'tictactoe',
        name: 'Tic Tac Toe',
        subtitle: 'Game silang & lingkaran klasik',
        icon: Icons.close_rounded,
        category: 'GAMES',
        onTap: () => _push(const TicTacToeGame()),
      ),
      _ToolItemData(
        id: 'pacman',
        name: 'Pacman Retro',
        subtitle: 'Game petualangan makan titik',
        icon: Icons.videogame_asset_rounded,
        category: 'GAMES',
        onTap: () => _push(const PacmanGame()),
      ),
      _ToolItemData(
        id: 'poker',
        name: 'Remi Poker Card',
        subtitle: 'Permainan kartu strategi poker',
        icon: Icons.casino_rounded,
        category: 'GAMES',
        onTap: () => _push(const PokerGamePage()),
      ),
      _ToolItemData(
        id: 'quiz_game',
        name: 'Quiz Challenge',
        subtitle: 'Uji wawasan & pengetahuan',
        icon: Icons.quiz_rounded,
        category: 'GAMES',
        onTap: () => _push(const QuizPage()),
      ),
      _ToolItemData(
        id: 'device_dashboard',
        name: 'Device Dashboard',
        subtitle: 'Informasi hardware & spesifikasi',
        icon: Icons.devices_rounded,
        category: 'EXTRA',
        onTap: () => _push(const DeviceDashboardPage()),
      ),
      _ToolItemData(
        id: 'trading_view',
        name: 'Trading View Pro',
        subtitle: 'Analisis chart crypto & saham',
        icon: Icons.trending_up_rounded,
        category: 'EXTRA',
        onTap: () => _push(MainTradingPage(
            sessionKey: widget.sessionKey, role: widget.userRole)),
      ),
      _ToolItemData(
        id: 'termux',
        name: 'Termux Console',
        subtitle: 'Terminal CLI & eksekusi script',
        icon: Icons.terminal_rounded,
        category: 'EXTRA',
        onTap: () => _push(TermuxPage(
            sessionKey: widget.sessionKey, userRole: widget.userRole)),
      ),
    ];
  }

  void _push(Widget page) {
    Navigator.of(context).push(
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => page,
        transitionDuration: const Duration(milliseconds: 400),
        reverseTransitionDuration: const Duration(milliseconds: 300),
        transitionsBuilder: (_, animation, __, child) {
          final curved = CurvedAnimation(
            parent: animation,
            curve: Curves.easeOutCubic,
          );
          return SlideTransition(
            position: Tween<Offset>(
              begin: const Offset(0.0, 0.08),
              end: Offset.zero,
            ).animate(curved),
            child: FadeTransition(opacity: curved, child: child),
          );
        },
      ),
    );
  }

  void _toggleFavorite(String name) {
    setState(() {
      if (_favoriteTools.contains(name)) {
        _favoriteTools.remove(name);
        _showNotification(
          title: 'Dihapus dari favorit',
          message: name,
          icon: Icons.star_border_rounded,
          color: _MC.textGrey,
        );
      } else {
        _favoriteTools.add(name);
        _showNotification(
          title: 'Ditambahkan ke favorit',
          message: name,
          icon: Icons.star_rounded,
          color: _MC.amber,
        );
      }
    });
  }

  List<_ToolItemData> get _filteredTools {
    return _masterToolsList.where((tool) {
      final matchesSearch = tool.name
              .toLowerCase()
              .contains(_searchQuery.toLowerCase()) ||
          tool.subtitle.toLowerCase().contains(_searchQuery.toLowerCase());
      final matchesCategory = _selectedCategory == 'ALL' ||
          tool.category == _selectedCategory;
      final matchesFav = !_onlyFavorites || _favoriteTools.contains(tool.name);

      return matchesSearch && matchesCategory && matchesFav;
    }).toList();
  }

  void _showNotification({
    required String title,
    required String message,
    required IconData icon,
    required Color color,
  }) {
    final overlay = Overlay.of(context);
    late OverlayEntry entry;

    entry = OverlayEntry(
      builder: (_) => _ToastNotification(
        title: title,
        message: message,
        icon: icon,
        color: color,
        onDismiss: () => entry.remove(),
      ),
    );
    overlay.insert(entry);
  }

  @override
  Widget build(BuildContext context) {
    final categories = [
      'ALL',
      'ALL IN ONE',
      'NETWORK',
      'OSINT',
      'UTILITIES',
      'ENTERTAINMENT',
      'GAMES',
      'EXTRA'
    ];
    final displayList = _filteredTools;

    return Scaffold(
      backgroundColor: _MC.cream,
      body: Stack(
        children: [
          Positioned.fill(
            child: CustomPaint(
              painter: _AuroraPainter(animation: _ringCtrl),
            ),
          ),
          SafeArea(
            child: CustomScrollView(
              physics: const BouncingScrollPhysics(),
              slivers: [
                SliverToBoxAdapter(child: _buildTopBar()),
                SliverToBoxAdapter(child: _buildInfoStatsBar()),
                SliverToBoxAdapter(child: _buildBanner()),
                SliverToBoxAdapter(child: _buildProfileCard()),
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 10),
                    child: Row(
                      children: [
                        Expanded(child: _buildSearchBar()),
                        const SizedBox(width: 10),
                        _buildFavButton(),
                      ],
                    ),
                  ),
                ),
                SliverToBoxAdapter(
                  child: _buildBigCategorySlider(categories),
                ),
                if (_isReorderMode)
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: _MC.redSoft,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                              color: _MC.comicBlack, width: 3),
                          boxShadow: const [
                            BoxShadow(
                              color: _MC.comicBlack,
                              offset: Offset(4, 5),
                              blurRadius: 0,
                            ),
                          ],
                        ),
                        child: const Row(
                          children: [
                            Icon(Icons.info_outline,
                                color: _MC.amber, size: 20),
                            SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                "MODE UBAH POSISI: Tekan dan tahan kartu tools untuk menggeser letaknya.",
                                style: TextStyle(
                                  color: _MC.white,
                                  fontSize: 11.5,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                SliverPadding(
                  padding: const EdgeInsets.all(16),
                  sliver: SliverGrid(
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 12,
                      mainAxisSpacing: 12,
                      childAspectRatio: 0.88,
                    ),
                    delegate: SliverChildBuilderDelegate(
                      (context, index) {
                        final tool = displayList[index];
                        return _Tool3DCard(
                          tool: tool,
                          isFavorite: _favoriteTools.contains(tool.name),
                          onFavoriteToggle: () => _toggleFavorite(tool.name),
                          onLongPress: () {
                            _showNotification(
                              title: tool.name,
                              message: tool.subtitle,
                              icon: tool.icon,
                              color: _roleColor(widget.userRole),
                            );
                          },
                        );
                      },
                      childCount: displayList.length,
                    ),
                  ),
                ),
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 24),
                    child: Column(
                      children: [
                        Text(
                          'X-SPYDER TOOLS',
                          style: TextStyle(
                            color: _MC.redDark.withOpacity(0.9),
                            fontWeight: FontWeight.w900,
                            fontSize: 13,
                            letterSpacing: 3,
                            fontFamily: 'Astral',
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '© 2026 • X-SPYDER Tools Gateway',
                          style: TextStyle(
                            color: _MC.textGrey.withOpacity(0.7),
                            fontSize: 10.5,
                          ),
                        ),
                        const SizedBox(height: 24),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // TOP BAR
  // ═══════════════════════════════════════════════════════════
  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 6),
      child: Row(
        children: [
          AnimatedBuilder(
            animation: _badgeSwing,
            builder: (_, __) => Transform.rotate(
              angle: _badgeSwing.value,
              alignment: Alignment.topCenter,
              child: _buildRobotToslBadge(),
            ),
          ),
          const Spacer(),
          AnimatedBuilder(
            animation: _badgeSwing,
            builder: (_, __) => Transform.rotate(
              angle: -_badgeSwing.value,
              alignment: Alignment.topCenter,
              child: _buildRobotToslBadge(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRobotToslBadge() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
      decoration: BoxDecoration(
        color: _MC.red,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _MC.comicBlack, width: 3),
        boxShadow: const [
          BoxShadow(
            color: _MC.comicBlack,
            offset: Offset(4, 5),
            blurRadius: 0,
          ),
        ],
      ),
      child: const Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.smart_toy_rounded, color: _MC.white, size: 14),
          SizedBox(width: 6),
          Text(
            'ROBOT TOSL',
            style: TextStyle(
              color: _MC.white,
              fontSize: 11,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.5,
              fontFamily: 'Astral',
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // INFO STATS BAR
  // ═══════════════════════════════════════════════════════════
  Widget _buildInfoStatsBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      child: Row(
        children: [
          Expanded(
            child: _buildStatPill(
              icon: Icons.apps_rounded,
              label: 'TOOLS',
              value: '${_masterToolsList.length}',
              color: _MC.brightRed,
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: _buildStatPill(
              icon: Icons.shield_rounded,
              label: 'ROLE',
              value: widget.userRole.toUpperCase(),
              color: _roleColor(widget.userRole),
              isRole: true,
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: _buildStatPill(
              icon: Icons.people_alt_rounded,
              label: 'ONLINE',
              value: _statsLoading ? '...' : '$_totalOnlineUsers',
              color: _MC.greenLite,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatPill({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
    bool isRole = false,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      decoration: BoxDecoration(
        color: _MC.buttonDark,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _MC.comicBlack, width: 3),
        boxShadow: const [
          BoxShadow(
            color: _MC.comicBlack,
            offset: Offset(4, 4),
            blurRadius: 0,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Icon(icon, color: color, size: 16),
          const SizedBox(height: 4),
          Text(
            label,
            style: const TextStyle(
              color: _MC.textGrey,
              fontSize: 8,
              fontWeight: FontWeight.w900,
              letterSpacing: 1,
              fontFamily: 'Astral',
            ),
          ),
          const SizedBox(height: 2),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: color,
              fontSize: isRole ? 9 : 14,
              fontWeight: FontWeight.w900,
              letterSpacing: 0.5,
              fontFamily: 'Astral',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBanner() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
      child: _GlassPanel(
        radius: 26,
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            _RobotOrb(size: 60),
            const SizedBox(width: 14),
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('X-SPYDER TOOLS GATEWAY',
                      style: TextStyle(
                          color: _MC.white,
                          fontSize: 16,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.2,
                          fontFamily: 'Astral')),
                  SizedBox(height: 5),
                  Text('Modern • Smooth • Smart tools',
                      style: TextStyle(
                          color: _MC.textGrey,
                          fontSize: 11,
                          fontWeight: FontWeight.w600)),
                ],
              ),
            ),
            _StatusPill(),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileCard() {
    final roleColor = _roleColor(widget.userRole);
    final verified = _isVerifiedRole(widget.userRole);
    final badge = _roleBadgeEmoji(widget.userRole);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: _GlassPanel(
        radius: 24,
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            _buildProfileWithRing(roleColor, verified, badge),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('TOOLS CONTROL CENTER',
                      style: TextStyle(
                          color: _MC.white,
                          fontSize: 13,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.1,
                          fontFamily: 'Astral')),
                  const SizedBox(height: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 9, vertical: 4),
                    decoration: BoxDecoration(
                        color: roleColor.withOpacity(.25),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                            color: _MC.comicBlack, width: 2)),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.shield_rounded,
                            color: roleColor, size: 11),
                        const SizedBox(width: 4),
                        Text(widget.userRole.toUpperCase(),
                            style: TextStyle(
                                color: _MC.white,
                                fontSize: 9.5,
                                fontWeight: FontWeight.w900)),
                      ],
                    ),
                  ),
                  const SizedBox(height: 7),
                  Text(
                      '${_masterToolsList.length} tools • ${_favoriteTools.length} favorit • Tap untuk membuka',
                      style: const TextStyle(
                          color: _MC.textGrey,
                          fontSize: 10.5,
                          fontWeight: FontWeight.w600)),
                ],
              ),
            ),
            _buildMenuButton(),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileWithRing(
      Color roleColor, bool verified, String? badge) {
    return SizedBox(
      width: 82,
      height: 82,
      child: Stack(
        alignment: Alignment.center,
        children: [
          AnimatedBuilder(
            animation: _ringCtrl,
            builder: (_, __) => Transform.rotate(
              angle: _ringCtrl.value * 2 * math.pi,
              child: CustomPaint(
                size: const Size(82, 82),
                painter: _RoleRingPainter(
                  color: roleColor,
                  level: _roleRingLevel(widget.userRole),
                ),
              ),
            ),
          ),
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _MC.white,
              border: Border.all(color: _MC.comicBlack, width: 3.5),
              boxShadow: const [
                BoxShadow(
                    color: _MC.comicBlack,
                    offset: Offset(3, 3),
                    blurRadius: 0),
              ],
            ),
            child: ClipOval(
              child: Padding(
                padding: const EdgeInsets.all(4),
                child: Image.asset(
                  'assets/images/bug.png',
                  fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) => const Icon(
                    Icons.bug_report_rounded,
                    color: _MC.brightRed,
                    size: 26,
                  ),
                ),
              ),
            ),
          ),
          if (verified)
            Positioned(
              bottom: 0,
              right: 0,
              child: Container(
                width: 22,
                height: 22,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _MC.blueCheck,
                  border: Border.all(color: _MC.comicBlack, width: 2.5),
                ),
                child: const Icon(Icons.check_rounded,
                    color: _MC.white, size: 12),
              ),
            )
          else if (badge != null)
            Positioned(
              bottom: 0,
              right: 0,
              child: Container(
                padding: const EdgeInsets.all(3),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _MC.white,
                  border: Border.all(color: _MC.comicBlack, width: 2),
                ),
                child: Text(badge, style: const TextStyle(fontSize: 11)),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildMenuButton() {
    return GestureDetector(
      onTap: () {
        setState(() => _isReorderMode = !_isReorderMode);
        _showNotification(
          title: _isReorderMode
              ? 'Mode Susun Aktif'
              : 'Mode Susun Nonaktif',
          message: _isReorderMode
              ? 'Tekan lama & geser kartu tools'
              : 'Kembali ke tampilan normal',
          icon: _isReorderMode
              ? Icons.swap_vert_rounded
              : Icons.check_circle_rounded,
          color: _isReorderMode
              ? _MC.amber
              : _MC.green,
        );
      },
      child: Container(
        width: 42,
        height: 42,
        decoration: BoxDecoration(
          color: _isReorderMode ? _MC.brightRed : _MC.buttonDark,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _MC.comicBlack, width: 3),
          boxShadow: const [
            BoxShadow(
              color: _MC.comicBlack,
              offset: Offset(3, 3),
              blurRadius: 0,
            ),
          ],
        ),
        child: Icon(
          _isReorderMode
              ? Icons.check_circle_rounded
              : Icons.swap_vert_rounded,
          color: _MC.white,
          size: 20,
        ),
      ),
    );
  }

  Widget _buildSearchBar() {
    return Container(
      decoration: BoxDecoration(
        color: _MC.buttonDark,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _MC.comicBlack, width: 3),
        boxShadow: const [
          BoxShadow(
            color: _MC.comicBlack,
            offset: Offset(4, 4),
            blurRadius: 0,
          ),
        ],
      ),
      child: TextField(
        controller: _searchController,
        style: const TextStyle(
            color: _MC.white,
            fontSize: 13.5,
            fontWeight: FontWeight.w600),
        cursorColor: _MC.brightRed,
        onChanged: (v) => setState(() => _searchQuery = v),
        decoration: InputDecoration(
          hintText: 'Cari tools...',
          hintStyle:
              const TextStyle(color: _MC.textLight, fontSize: 12.5),
          prefixIcon: const Icon(Icons.search_rounded,
              color: _MC.brightRed, size: 20),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
              vertical: 15, horizontal: 8),
          suffixIcon: _searchQuery.isNotEmpty
              ? IconButton(
                  icon: const Icon(Icons.clear_rounded,
                      color: _MC.textGrey),
                  onPressed: () {
                    _searchController.clear();
                    setState(() => _searchQuery = '');
                  })
              : null,
        ),
      ),
    );
  }

  Widget _buildFavButton() {
    return GestureDetector(
      onTap: () {
        setState(() => _onlyFavorites = !_onlyFavorites);
        _showNotification(
            title: _onlyFavorites ? 'Favorit aktif' : 'Semua tools',
            message: _onlyFavorites
                ? 'Menampilkan tools favorit'
                : 'Menampilkan semua tools',
            icon: _onlyFavorites
                ? Icons.star_rounded
                : Icons.apps_rounded,
            color: _MC.brightRed);
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        width: 52,
        height: 52,
        decoration: BoxDecoration(
            color: _onlyFavorites ? _MC.brightRed : _MC.buttonDark,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _MC.comicBlack, width: 3),
            boxShadow: const [
              BoxShadow(
                  color: _MC.comicBlack,
                  offset: Offset(4, 4),
                  blurRadius: 0),
            ]),
        child: Icon(
            _onlyFavorites
                ? Icons.star_rounded
                : Icons.star_border_rounded,
            color: _onlyFavorites ? _MC.white : _MC.gold,
            size: 22),
      ),
    );
  }

  Widget _buildBigCategorySlider(List<String> categories) {
    return SizedBox(
      height: 58,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
        itemCount: categories.length,
        itemBuilder: (context, index) {
          final cat = categories[index];
          final active = _selectedCategory == cat;

          return Padding(
            padding: const EdgeInsets.only(right: 9),
            child: GestureDetector(
              onTap: () {
                setState(() => _selectedCategory = cat);
                _catCtrl.forward(from: 0);
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 260),
                curve: Curves.easeOutBack,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(
                  color: active ? _MC.brightRed : _MC.buttonDark,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: _MC.comicBlack, width: 3),
                  boxShadow: const [
                    BoxShadow(
                      color: _MC.comicBlack,
                      offset: Offset(3, 3),
                      blurRadius: 0,
                    ),
                  ],
                ),
                child: Center(
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        _categoryIcon(cat),
                        color: active ? _MC.white : _MC.gold,
                        size: 14,
                      ),
                      const SizedBox(width: 6),
                      Text(
                        cat,
                        style: TextStyle(
                          color: active ? _MC.white : _MC.textGrey,
                          fontWeight: FontWeight.w900,
                          fontSize: 10.5,
                          letterSpacing: .7,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  IconData _categoryIcon(String cat) {
    switch (cat) {
      case 'ALL IN ONE': return Icons.auto_awesome_rounded;
      case 'NETWORK': return Icons.hub_rounded;
      case 'OSINT': return Icons.manage_search_rounded;
      case 'UTILITIES': return Icons.build_circle_rounded;
      case 'ENTERTAINMENT': return Icons.movie_filter_rounded;
      case 'GAMES': return Icons.sports_esports_rounded;
      case 'EXTRA': return Icons.extension_rounded;
      default: return Icons.grid_view_rounded;
    }
  }
}

// ═════════════════════════════════════════════════════════════
// 🎴 TOOL CARD 3D
// ═════════════════════════════════════════════════════════════
class _Tool3DCard extends StatefulWidget {
  final _ToolItemData tool;
  final bool isFavorite;
  final VoidCallback onFavoriteToggle;
  final VoidCallback onLongPress;
  const _Tool3DCard({
    required this.tool,
    required this.isFavorite,
    required this.onFavoriteToggle,
    required this.onLongPress,
  });
  @override
  State<_Tool3DCard> createState() => _Tool3DCardState();
}

class _Tool3DCardState extends State<_Tool3DCard> {
  bool _pressed = false;
  @override
  Widget build(BuildContext context) {
    final tint = _iconTint(widget.tool.id);
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) => setState(() => _pressed = false),
      onTapCancel: () => setState(() => _pressed = false),
      onTap: widget.tool.onTap,
      onLongPress: widget.onLongPress,
      child: AnimatedScale(
        scale: _pressed ? .96 : 1,
        duration: const Duration(milliseconds: 120),
        curve: Curves.easeOut,
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: _MC.redSoft,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _MC.comicBlack, width: 3.5),
            boxShadow: const [
              BoxShadow(
                color: _MC.comicBlack,
                offset: Offset(4, 5),
                blurRadius: 0,
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _ToolIcon(icon: widget.tool.icon, tint: tint),
                  GestureDetector(
                    onTap: widget.onFavoriteToggle,
                    child: _SmallGlassButton(
                        icon: widget.isFavorite
                            ? Icons.star_rounded
                            : Icons.star_border_rounded,
                        color: widget.isFavorite
                            ? _MC.gold
                            : _MC.textGrey),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Text(widget.tool.name,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      color: _MC.white,
                      fontSize: 12.5,
                      fontWeight: FontWeight.w900,
                      height: 1.15)),
              const SizedBox(height: 5),
              Expanded(
                child: Text(widget.tool.subtitle,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        color: _MC.textGrey,
                        fontSize: 9.5,
                        fontWeight: FontWeight.w600,
                        height: 1.25)),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(child: _CategoryMini(label: widget.tool.category)),
                  Container(
                    width: 26,
                    height: 26,
                    decoration: BoxDecoration(
                      color: _MC.brightRed,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: _MC.comicBlack, width: 2),
                    ),
                    child: Icon(Icons.arrow_forward_rounded,
                        color: _MC.white, size: 14),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

Color _iconTint(String id) {
  const map = <String, Color>{
    // ═══ DANA WALLET ═══
    'dana': Color(0xFF0B6EF5),
    // ═══ CHECK BANNED ═══
    'check_banned': Color(0xFFEF4444),
    'youtube_player': Color(0xFFFF3B3B),
    'kalkulator': Color(0xFF60A5FA),
    'iqc': Color(0xFFA78BFA),
    'alight_premium': Color(0xFFF59E0B),
    'gemini_ai': Color(0xFF60A5FA),
    'anime': Color(0xFFF472B6),
    'dracin': Color(0xFFFB7185),
    'tiktok_dl': Color(0xFF22D3EE),
    'ig_dl': Color(0xFFF97316),
    'music_bmw': Color(0xFF34D399),
    'spam_ngl': Color(0xFFA78BFA),
    'wifi_internal': Color(0xFF38BDF8),
    'wifi_external': Color(0xFF2DD4BF),
    'nik_check': Color(0xFF818CF8),
    'domain_osint': Color(0xFF67E8F9),
    'phone_lookup': Color(0xFF4ADE80),
    'email_osint': Color(0xFFC084FC),
    'qr_gen': Color(0xFFE879F9),
    'ip_scanner': Color(0xFF60A5FA),
    'port_scanner': Color(0xFF2DD4BF),
    'manage_server': Color(0xFF94A3B8),
    'adult_hub': Color(0xFFF87171),
    'sliding_puzzle': Color(0xFFFBBF24),
    'tictactoe': Color(0xFFFB7185),
    'pacman': Color(0xFFFACC15),
    'poker': Color(0xFF4ADE80),
    'quiz_game': Color(0xFFA78BFA),
    'device_dashboard': Color(0xFF38BDF8),
    'trading_view': Color(0xFF22C55E),
    'termux': Color(0xFFCBD5E1),
  };
  return map[id] ?? _MC.brightRed;
}

class _ToolIcon extends StatelessWidget {
  final IconData icon;
  final Color tint;
  const _ToolIcon({required this.icon, required this.tint});
  @override
  Widget build(BuildContext context) => Container(
        width: 46,
        height: 46,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: tint.withOpacity(.22),
          border: Border.all(color: _MC.comicBlack, width: 3),
          boxShadow: const [
            BoxShadow(
                color: _MC.comicBlack,
                offset: Offset(2, 2),
                blurRadius: 0),
          ],
        ),
        child: ClipOval(
          child: Stack(alignment: Alignment.center, children: [
            Positioned.fill(
              child: Image.asset('assets/images/tools.png',
                  fit: BoxFit.cover,
                  opacity: const AlwaysStoppedAnimation(.16),
                  errorBuilder: (_, __, ___) =>
                      const SizedBox.shrink()),
            ),
            Icon(icon, color: tint, size: 22),
          ]),
        ),
      );
}

class _CategoryMini extends StatelessWidget {
  final String label;
  const _CategoryMini({required this.label});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
        decoration: BoxDecoration(
            color: _MC.buttonDark,
            borderRadius: BorderRadius.circular(7),
            border: Border.all(
                color: _MC.comicBlack, width: 1.5)),
        child: Text(label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
                color: _MC.gold,
                fontSize: 7.5,
                fontWeight: FontWeight.w900)),
      );
}

class _SmallGlassButton extends StatelessWidget {
  final IconData icon;
  final Color color;
  const _SmallGlassButton({required this.icon, required this.color});
  @override
  Widget build(BuildContext context) => Container(
        width: 30,
        height: 30,
        decoration: BoxDecoration(
            color: _MC.buttonDark,
            borderRadius: BorderRadius.circular(9),
            border: Border.all(color: _MC.comicBlack, width: 2)),
        child: Icon(icon, color: color, size: 15),
      );
}

class _GlassPanel extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final double radius;
  final Color? glow;
  const _GlassPanel({
    required this.child,
    required this.padding,
    required this.radius,
    this.glow,
  });
  @override
  Widget build(BuildContext context) => Container(
        padding: padding,
        decoration: BoxDecoration(
            color: _MC.redSoft,
            borderRadius: BorderRadius.circular(radius),
            border: Border.all(color: _MC.comicBlack, width: 3.5),
            boxShadow: const [
              BoxShadow(
                  color: _MC.comicBlack,
                  offset: Offset(5, 5),
                  blurRadius: 0),
            ]),
        child: child,
      );
}

class _RobotOrb extends StatelessWidget {
  final double size;
  const _RobotOrb({required this.size});
  @override
  Widget build(BuildContext context) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _MC.brightRed,
            border: Border.all(color: _MC.comicBlack, width: 3.5),
            boxShadow: const [
              BoxShadow(
                  color: _MC.comicBlack,
                  offset: Offset(3, 3),
                  blurRadius: 0),
            ]),
        child: const Icon(Icons.smart_toy_rounded,
            color: _MC.white, size: 30),
      );
}

class _StatusPill extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
        decoration: BoxDecoration(
            color: _MC.green,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _MC.comicBlack, width: 2)),
        child: const Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.circle, color: _MC.white, size: 7),
          SizedBox(width: 5),
          Text('READY',
              style: TextStyle(
                  color: _MC.white,
                  fontSize: 8,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1))
        ]),
      );
}

class _AuroraPainter extends CustomPainter {
  final Animation<double> animation;
  _AuroraPainter({required this.animation})
      : super(repaint: animation);
  @override
  void paint(Canvas c, Size s) {
    c.drawRect(Offset.zero & s, Paint()..color = _MC.cream);
    final t = animation.value * 2 * math.pi;
    final pts = [
      Offset(s.width * .15 + math.sin(t) * 35, s.height * .12),
      Offset(s.width * .88, s.height * .34 + math.cos(t) * 45),
      Offset(s.width * .48, s.height * .9 + math.sin(t) * 25)
    ];
    final colors = [
      _MC.brightRed.withOpacity(.12),
      _MC.red.withOpacity(.10),
      _MC.redDark.withOpacity(.15)
    ];
    for (var i = 0; i < pts.length; i++) {
      final p = Paint()
        ..shader = RadialGradient(
                colors: [colors[i], Colors.transparent])
            .createShader(
                Rect.fromCircle(center: pts[i], radius: 220));
      c.drawCircle(pts[i], 220, p);
    }
  }

  @override
  bool shouldRepaint(covariant _AuroraPainter old) => true;
}

// ═════════════════════════════════════════════════════════════
// 🔔 TOAST NOTIFICATION 3D
// ═════════════════════════════════════════════════════════════
class _ToastNotification extends StatefulWidget {
  final String title;
  final String message;
  final IconData icon;
  final Color color;
  final VoidCallback onDismiss;

  const _ToastNotification({
    required this.title,
    required this.message,
    required this.icon,
    required this.color,
    required this.onDismiss,
  });

  @override
  State<_ToastNotification> createState() =>
      _ToastNotificationState();
}

class _ToastNotificationState extends State<_ToastNotification>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<Offset> _slide;
  late Animation<double> _fade;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 320),
    );
    _slide = Tween<Offset>(
      begin: const Offset(0, -0.4),
      end: Offset.zero,
    ).animate(
        CurvedAnimation(parent: _ctrl, curve: Curves.easeOutBack));
    _fade = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);

    _ctrl.forward();
    Future.delayed(const Duration(milliseconds: 2500), () {
      if (mounted) {
        _ctrl.reverse().then((_) => widget.onDismiss());
      }
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Positioned(
      top: MediaQuery.of(context).padding.top + 20,
      left: 16,
      right: 16,
      child: FadeTransition(
        opacity: _fade,
        child: SlideTransition(
          position: _slide,
          child: Material(
            color: Colors.transparent,
            child: Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: _MC.redSoft,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(
                    color: _MC.comicBlack, width: 3),
                boxShadow: const [
                  BoxShadow(
                      color: _MC.comicBlack,
                      offset: Offset(5, 5),
                      blurRadius: 0),
                ],
              ),
              child: Row(
                children: [
                  Container(
                    width: 42,
                    height: 42,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: widget.color,
                      border: Border.all(
                          color: _MC.comicBlack, width: 2.5),
                    ),
                    child: Icon(widget.icon,
                        color: _MC.white, size: 20),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          widget.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: _MC.white,
                            fontSize: 13,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          widget.message,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: _MC.textGrey,
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      _ctrl
                          .reverse()
                          .then((_) => widget.onDismiss());
                    },
                    child: Container(
                      width: 28,
                      height: 28,
                      decoration: BoxDecoration(
                        color: _MC.buttonDark,
                        shape: BoxShape.circle,
                        border: Border.all(
                            color: _MC.comicBlack, width: 2),
                      ),
                      child: const Icon(Icons.close_rounded,
                          color: _MC.white, size: 14),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ═════════════════════════════════════════════════════════════
// 🎨 ROLE RING PAINTER
// ═════════════════════════════════════════════════════════════
class _RoleRingPainter extends CustomPainter {
  final Color color;
  final int level;
  _RoleRingPainter({required this.color, required this.level});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 3;

    final outlinePaint = Paint()
      ..color = _MC.comicBlack
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;
    canvas.drawCircle(center, radius + 2, outlinePaint);

    final mainPaint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.5 + (level * 0.3)
      ..strokeCap = StrokeCap.round;
    canvas.drawCircle(center, radius, mainPaint);

    if (level >= 2) {
      final innerPaint = Paint()
        ..color = color.withOpacity(0.6)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5;
      canvas.drawCircle(center, radius - 5, innerPaint);
    }

    if (level >= 3) {
      final dotCount = 4 + (level - 3) * 2;
      final dotPaint = Paint()..color = color;
      final dotRadius = 2.0 + (level * 0.15);
      for (int i = 0; i < dotCount; i++) {
        final angle = (i / dotCount) * 2 * math.pi;
        final dx = center.dx + radius * math.cos(angle);
        final dy = center.dy + radius * math.sin(angle);
        canvas.drawCircle(Offset(dx, dy), dotRadius, dotPaint);
      }
    }

    if (level >= 4) {
      final dashPaint = Paint()
        ..color = color.withOpacity(0.9)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.2
        ..strokeCap = StrokeCap.round;
      const segments = 8;
      const gap = 0.6;
      for (int i = 0; i < segments; i++) {
        final startAngle = (i / segments) * 2 * math.pi;
        final sweepAngle = (2 * math.pi / segments) - gap * 0.4;
        canvas.drawArc(
          Rect.fromCircle(center: center, radius: radius - 3),
          startAngle,
          sweepAngle,
          false,
          dashPaint,
        );
      }
    }

    if (level >= 5) {
      final tickPaint = Paint()
        ..color = color.withOpacity(0.9)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..strokeCap = StrokeCap.round;
      const tickCount = 12;
      for (int i = 0; i < tickCount; i++) {
        final angle = (i / tickCount) * 2 * math.pi;
        final outer = Offset(
          center.dx + (radius + 2) * math.cos(angle),
          center.dy + (radius + 2) * math.sin(angle),
        );
        final inner = Offset(
          center.dx + (radius - 2) * math.cos(angle),
          center.dy + (radius - 2) * math.sin(angle),
        );
        canvas.drawLine(outer, inner, tickPaint);
      }
    }

    if (level >= 6) {
      for (int i = 0; i < 8; i++) {
        final angle = (i / 8) * 2 * math.pi;
        final dx = center.dx + (radius + 6) * math.cos(angle);
        final dy = center.dy + (radius + 6) * math.sin(angle);
        _drawStar(canvas, Offset(dx, dy), 3.5, 1.8,
            Paint()..color = _MC.white);
      }
    }
  }

  void _drawStar(Canvas canvas, Offset center, double outer,
      double inner, Paint paint) {
    final path = Path();
    for (int i = 0; i < 8; i++) {
      final r = i.isEven ? outer : inner;
      final angle = (i / 8) * 2 * math.pi - math.pi / 2;
      final x = center.dx + r * math.cos(angle);
      final y = center.dy + r * math.sin(angle);
      i == 0 ? path.moveTo(x, y) : path.lineTo(x, y);
    }
    path.close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(_RoleRingPainter old) =>
      old.color != color || old.level != level;
}

// ═════════════════════════════════════════════════════════════
// 📦 MODELS
// ═════════════════════════════════════════════════════════════
class _ToolItemData {
  final String id;
  final String name;
  final String subtitle;
  final IconData icon;
  final String category;
  final VoidCallback onTap;

  _ToolItemData({
    required this.id,
    required this.name,
    required this.subtitle,
    required this.icon,
    required this.category,
    required this.onTap,
  });
}