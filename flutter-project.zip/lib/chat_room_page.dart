import 'dart:async';
import 'dart:convert';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'package:web_socket_channel/web_socket_channel.dart';

/// Public real-time discussion room.
///
/// Backend endpoints expected:
/// GET  /api/chat/messages?limit=60
/// POST /api/chat/send          {text, username, role}
/// POST /api/chat/upload        multipart field: file
/// POST /api/chat/reaction      {messageId, emoji, username}
/// WS   /ws/chat
///
/// The page also polls every 4 seconds as a fallback when WebSocket is not
/// available. The Authorization and X-Session-Key headers are sent when a
/// session key is provided.
const String kChatBaseUrl =
    'http://shinoa-cpanelpanel.xtxintax.my.id:2003';

class ChatRoomPage extends StatefulWidget {
  final String username;
  final String role;
  final String sessionKey;

  const ChatRoomPage({
    super.key,
    required this.username,
    this.role = 'member',
    this.sessionKey = '',
  });

  @override
  State<ChatRoomPage> createState() => _ChatRoomPageState();
}

class _ChatMessage {
  final String id;
  final String username;
  final String role;
  final String text;
  final String imageUrl;
  final DateTime time;
  final Map<String, List<String>> reactions;
  final bool mine;

  const _ChatMessage({
    required this.id,
    required this.username,
    required this.role,
    required this.text,
    required this.imageUrl,
    required this.time,
    required this.reactions,
    required this.mine,
  });

  factory _ChatMessage.fromJson(
    Map<String, dynamic> j, {
    required String currentUser,
  }) {
    final rawReactions = j['reactions'];
    final reactions = <String, List<String>>{};
    if (rawReactions is Map) {
      rawReactions.forEach((key, value) {
        if (value is List) {
          reactions[key.toString()] = value.map((e) => e.toString()).toList();
        } else if (value is int) {
          reactions[key.toString()] =
              List<String>.filled(value, '', growable: true);
        }
      });
    }

    dynamic rawTime = j['createdAt'] ?? j['timestamp'] ?? j['time'];
    DateTime time = DateTime.now();
    if (rawTime is int) {
      time = DateTime.fromMillisecondsSinceEpoch(
        rawTime < 1000000000000 ? rawTime * 1000 : rawTime,
      ).toLocal();
    } else if (rawTime != null) {
      time = DateTime.tryParse(rawTime.toString())?.toLocal() ?? time;
    }

    final username =
        (j['username'] ?? j['user'] ?? j['sender'] ?? 'User').toString();
    final image = (j['imageUrl'] ??
            j['image_url'] ??
            j['image'] ??
            j['photoUrl'] ??
            '')
        .toString();

    return _ChatMessage(
      id: (j['id'] ?? j['_id'] ?? j['messageId'] ?? time.microsecondsSinceEpoch)
          .toString(),
      username: username,
      role: (j['role'] ?? 'member').toString(),
      text: (j['text'] ?? j['message'] ?? j['content'] ?? '').toString(),
      imageUrl: image,
      time: time,
      reactions: reactions,
      mine: username.toLowerCase() == currentUser.toLowerCase(),
    );
  }
}

class _ChatRoomPageState extends State<ChatRoomPage>
    with TickerProviderStateMixin {
  final _text = TextEditingController();
  final _scroll = ScrollController();
  final _picker = ImagePicker();

  final List<_ChatMessage> _messages = [];
  WebSocketChannel? _socket;
  StreamSubscription? _socketSub;
  Timer? _pollTimer;

  late AnimationController _entryCtrl;
  late AnimationController _pulseCtrl;

  bool _loading = true;
  bool _sending = false;
  bool _uploading = false;
  bool _connected = false;
  bool _showScrollDown = false;

  static const _purple = Color(0xFF8B5CF6);
  static const _purple2 = Color(0xFFA855F7);
  static const _bg = Color(0xFF080612);
  static const _card = Color(0xFF151023);

  final List<String> _emojis = const [
    '❤️', '😂', '😍', '🔥', '👍', '👏', '🎉', '😮',
    '😢', '😡', '🤔', '🙏', '💯', '✨', '🥰', '🤣',
    '😎', '👀', '💜', '🚀', '🙌', '😭', '🤩', '🫶',
  ];

  @override
  void initState() {
    super.initState();
    _entryCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 650),
    )..forward();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat(reverse: true);

    _scroll.addListener(() {
      final show = _scroll.hasClients && _scroll.offset > 260;
      if (show != _showScrollDown && mounted) {
        setState(() => _showScrollDown = show);
      }
    });

    _loadMessages();
    _connectSocket();
    _pollTimer = Timer.periodic(
      const Duration(seconds: 4),
      (_) => _loadMessages(silent: true),
    );
  }

  Map<String, String> get _headers => {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        if (widget.sessionKey.isNotEmpty)
          'Authorization': 'Bearer ${widget.sessionKey}',
        if (widget.sessionKey.isNotEmpty) 'X-Session-Key': widget.sessionKey,
      };

  Uri _api(String path, [Map<String, String>? query]) {
    final base = Uri.parse(kChatBaseUrl);
    return base.replace(
      path: '${base.path}$path',
      queryParameters: query,
    );
  }

  Future<void> _loadMessages({bool silent = false}) async {
    try {
      final response = await http
          .get(
            _api('/api/chat/messages', {'limit': '80'}),
            headers: _headers,
          )
          .timeout(const Duration(seconds: 7));
      if (response.statusCode < 200 || response.statusCode >= 300) return;

      final decoded = jsonDecode(response.body);
      final raw = decoded is List
          ? decoded
          : decoded is Map
              ? (decoded['messages'] ??
                  decoded['data'] ??
                  decoded['items'] ??
                  [])
              : [];
      if (raw is! List) return;

      final incoming = raw
          .whereType<Map>()
          .map((e) => _ChatMessage.fromJson(
                Map<String, dynamic>.from(e),
                currentUser: widget.username,
              ))
          .toList();

      incoming.sort((a, b) => a.time.compareTo(b.time));
      if (!mounted) return;
      setState(() {
        _messages
          ..clear()
          ..addAll(incoming);
        _loading = false;
      });
      if (!silent || _isNearBottom()) {
        WidgetsBinding.instance.addPostFrameCallback((_) => _scrollBottom());
      }
    } catch (_) {
      if (mounted && !silent) setState(() => _loading = false);
    }
  }

  void _connectSocket() {
    try {
      final base = Uri.parse(kChatBaseUrl);
      final scheme = base.scheme == 'https' ? 'wss' : 'ws';
      final socketUri = Uri(
        scheme: scheme,
        host: base.host,
        port: base.hasPort ? base.port : null,
        path: '${base.path}/ws/chat',
        queryParameters: {
          if (widget.sessionKey.isNotEmpty) 'sessionKey': widget.sessionKey,
          'username': widget.username,
        },
      );
      _socket = WebSocketChannel.connect(socketUri);
      _socketSub = _socket!.stream.listen(
        _onSocketData,
        onError: (_) {
          if (mounted) setState(() => _connected = false);
          _reconnectSocket();
        },
        onDone: () {
          if (mounted) setState(() => _connected = false);
          _reconnectSocket();
        },
      );
      if (mounted) setState(() => _connected = true);
    } catch (_) {
      _reconnectSocket();
    }
  }

  void _reconnectSocket() {
    Future.delayed(const Duration(seconds: 5), () {
      if (mounted && _socket == null) _connectSocket();
    });
    _socket = null;
  }

  void _onSocketData(dynamic event) {
    try {
      final decoded = event is String ? jsonDecode(event) : event;
      if (decoded is List) {
        _mergeSocketList(decoded);
        return;
      }
      if (decoded is! Map) return;

      final type = (decoded['type'] ?? '').toString().toLowerCase();
      final payload = decoded['message'] is Map
          ? Map<String, dynamic>.from(decoded['message'])
          : decoded['data'] is Map
              ? Map<String, dynamic>.from(decoded['data'])
              : Map<String, dynamic>.from(decoded);

      if (type == 'delete') {
        final id = (decoded['messageId'] ?? payload['id'] ?? '').toString();
        if (mounted) setState(() => _messages.removeWhere((m) => m.id == id));
        return;
      }

      final message = _ChatMessage.fromJson(
        payload,
        currentUser: widget.username,
      );
      if (message.id.isEmpty) return;

      if (type == 'reaction' || payload['reactions'] != null) {
        _replaceMessage(message);
      } else {
        _replaceOrAdd(message);
      }
    } catch (_) {}
  }

  void _mergeSocketList(List<dynamic> list) {
    for (final item in list.whereType<Map>()) {
      _replaceOrAdd(_ChatMessage.fromJson(
        Map<String, dynamic>.from(item),
        currentUser: widget.username,
      ));
    }
    if (mounted) setState(() {});
  }

  void _replaceOrAdd(_ChatMessage message) {
    if (!mounted) return;
    final i = _messages.indexWhere((m) => m.id == message.id);
    setState(() {
      if (i >= 0) {
        _messages[i] = message;
      } else {
        _messages.add(message);
        _messages.sort((a, b) => a.time.compareTo(b.time));
      }
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_isNearBottom()) _scrollBottom();
    });
  }

  void _replaceMessage(_ChatMessage message) {
    if (!mounted) return;
    final i = _messages.indexWhere((m) => m.id == message.id);
    if (i >= 0) setState(() => _messages[i] = message);
  }

  bool _isNearBottom() {
    if (!_scroll.hasClients) return true;
    return _scroll.position.maxScrollExtent - _scroll.position.pixels < 180;
  }

  void _scrollBottom() {
    if (!_scroll.hasClients) return;
    _scroll.animateTo(
      _scroll.position.maxScrollExtent,
      duration: const Duration(milliseconds: 380),
      curve: Curves.easeOutCubic,
    );
  }

  Future<void> _sendText() async {
    final value = _text.text.trim();
    if (value.isEmpty || _sending) return;

    setState(() => _sending = true);
    _text.clear();

    try {
      final response = await http
          .post(
            _api('/api/chat/send'),
            headers: _headers,
            body: jsonEncode({
              'username': widget.username,
              'role': widget.role,
              'text': value,
              'type': 'text',
            }),
          )
          .timeout(const Duration(seconds: 10));

      if (response.statusCode < 200 || response.statusCode >= 300) {
        _text.text = value;
        _snack('Pesan gagal dikirim (${response.statusCode})');
      } else {
        try {
          final data = jsonDecode(response.body);
          final map = data is Map && data['message'] is Map
              ? Map<String, dynamic>.from(data['message'])
              : data is Map
                  ? Map<String, dynamic>.from(data)
                  : null;
          if (map != null) _replaceOrAdd(_ChatMessage.fromJson(
            map,
            currentUser: widget.username,
          ));
        } catch (_) {}
      }
    } catch (_) {
      _text.text = value;
      _snack('Tidak dapat terhubung ke server chat');
    } finally {
      if (mounted) setState(() => _sending = false);
      _loadMessages(silent: true);
    }
  }

  Future<void> _pickAndSendImage() async {
    if (_uploading) return;
    try {
      final image = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 84,
        maxWidth: 1800,
      );
      if (image == null) return;

      setState(() => _uploading = true);
      final request = http.MultipartRequest(
        'POST',
        _api('/api/chat/upload'),
      );
      request.headers.addAll({
        'Accept': 'application/json',
        if (widget.sessionKey.isNotEmpty)
          'Authorization': 'Bearer ${widget.sessionKey}',
        if (widget.sessionKey.isNotEmpty) 'X-Session-Key': widget.sessionKey,
      });
      request.fields['username'] = widget.username;
      request.fields['role'] = widget.role;
      request.fields['type'] = 'image';
      request.files.add(await http.MultipartFile.fromPath('file', image.path));

      final streamed = await request.send().timeout(const Duration(seconds: 30));
      final body = await streamed.stream.bytesToString();
      if (streamed.statusCode < 200 || streamed.statusCode >= 300) {
        _snack('Upload foto gagal (${streamed.statusCode})');
        return;
      }

      try {
        final data = jsonDecode(body);
        final map = data is Map && data['message'] is Map
            ? Map<String, dynamic>.from(data['message'])
            : data is Map
                ? Map<String, dynamic>.from(data)
                : <String, dynamic>{};
        var url = (map['imageUrl'] ??
                map['url'] ??
                map['image_url'] ??
                map['path'] ??
                '')
            .toString();

        if (url.isEmpty) {
          _snack('Server upload tidak mengembalikan URL foto');
          return;
        }
        if (url.startsWith('/')) url = '$kChatBaseUrl$url';

        final msg = _ChatMessage(
          id: 'local-${DateTime.now().microsecondsSinceEpoch}',
          username: widget.username,
          role: widget.role,
          text: (map['text'] ?? '').toString(),
          imageUrl: url,
          time: DateTime.now(),
          reactions: const {},
          mine: true,
        );
        _replaceOrAdd(msg);
      } catch (_) {
        _snack('Format response upload tidak dikenali');
      }
    } catch (_) {
      _snack('Gagal memilih/mengupload foto');
    } finally {
      if (mounted) setState(() => _uploading = false);
      _loadMessages(silent: true);
    }
  }

  Future<void> _react(_ChatMessage message, String emoji) async {
    // Optimistic UI: update instantly, then synchronize with server.
    final current = Map<String, List<String>>.from(message.reactions);
    final users = List<String>.from(current[emoji] ?? const <String>[]);
    if (users.contains(widget.username)) {
      users.remove(widget.username);
    } else {
      users.add(widget.username);
    }
    if (users.isEmpty) {
      current.remove(emoji);
    } else {
      current[emoji] = users;
    }

    final updated = _ChatMessage(
      id: message.id,
      username: message.username,
      role: message.role,
      text: message.text,
      imageUrl: message.imageUrl,
      time: message.time,
      reactions: current,
      mine: message.mine,
    );
    _replaceMessage(updated);

    try {
      await http
          .post(
            _api('/api/chat/reaction'),
            headers: _headers,
            body: jsonEncode({
              'messageId': message.id,
              'emoji': emoji,
              'username': widget.username,
              'action': 'toggle',
            }),
          )
          .timeout(const Duration(seconds: 8));
    } catch (_) {}
  }

  void _showReactions(_ChatMessage message) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (ctx) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(28),
              child: BackdropFilter(
                filter: ui.ImageFilter.blur(sigmaX: 24, sigmaY: 24),
                child: Container(
                  padding: const EdgeInsets.fromLTRB(18, 16, 18, 20),
                  decoration: BoxDecoration(
                    color: const Color(0xFF110B1D).withOpacity(.94),
                    borderRadius: BorderRadius.circular(28),
                    border: Border.all(color: _purple2.withOpacity(.28)),
                  ),
                  child: Wrap(
                    alignment: WrapAlignment.center,
                    spacing: 8,
                    runSpacing: 8,
                    children: _emojis.map((emoji) {
                      return InkWell(
                        borderRadius: BorderRadius.circular(18),
                        onTap: () {
                          Navigator.pop(ctx);
                          _react(message, emoji);
                        },
                        child: Container(
                          width: 48,
                          height: 44,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(.055),
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color: Colors.white.withOpacity(.07),
                            ),
                          ),
                          child: Text(emoji, style: const TextStyle(fontSize: 25)),
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  void _showMessageActions(_ChatMessage message) {
    _showReactions(message);
  }

  String _time(DateTime d) {
    final h = d.hour.toString().padLeft(2, '0');
    final m = d.minute.toString().padLeft(2, '0');
    return '$h:$m';
  }

  String _dayLabel(DateTime d) {
    final now = DateTime.now();
    final today = now.year == d.year && now.month == d.month && now.day == d.day;
    if (today) return 'Hari ini';
    final yesterday = DateTime(now.year, now.month, now.day)
            .difference(DateTime(d.year, d.month, d.day))
            .inDays ==
        1;
    if (yesterday) return 'Kemarin';
    return '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';
  }

  Color _roleColor(String role) {
    switch (role.toLowerCase()) {
      case 'owner':
      case 'owner_utama':
        return const Color(0xFFFBBF24);
      case 'admin':
      case 'moderator':
        return const Color(0xFF60A5FA);
      case 'vip':
        return const Color(0xFFC084FC);
      case 'staff':
        return const Color(0xFFFB7185);
      default:
        return _purple2;
    }
  }

  void _snack(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(text, style: const TextStyle(fontWeight: FontWeight.w700)),
        behavior: SnackBarBehavior.floating,
        backgroundColor: _card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
    );
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _socketSub?.cancel();
    try {
      _socket?.sink.close();
    } catch (_) {}
    _entryCtrl.dispose();
    _pulseCtrl.dispose();
    _text.dispose();
    _scroll.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      extendBodyBehindAppBar: true,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(74),
        child: _buildHeader(),
      ),
      body: Stack(
        children: [
          const Positioned.fill(child: _GlowBackground()),
          SafeArea(
            child: Column(
              children: [
                _buildRoomInfo(),
                Expanded(child: _buildMessages()),
                _buildComposer(),
              ],
            ),
          ),
          if (_showScrollDown)
            Positioned(
              right: 18,
              bottom: 105,
              child: _GlassIcon(
                icon: Icons.keyboard_arrow_down_rounded,
                onTap: _scrollBottom,
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return ClipRRect(
      child: BackdropFilter(
        filter: ui.ImageFilter.blur(sigmaX: 24, sigmaY: 24),
        child: Container(
          padding: const EdgeInsets.fromLTRB(8, 10, 12, 8),
          decoration: BoxDecoration(
            color: _bg.withOpacity(.72),
            border: Border(
              bottom: BorderSide(color: _purple2.withOpacity(.14)),
            ),
          ),
          child: SafeArea(
            bottom: false,
            child: Row(
              children: [
                IconButton(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.arrow_back_ios_new_rounded,
                      color: Colors.white, size: 20),
                ),
                Container(
                  width: 45,
                  height: 45,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16),
                    gradient: const LinearGradient(
                      colors: [_purple2, _purple],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: _purple.withOpacity(.35),
                        blurRadius: 18,
                      ),
                    ],
                  ),
                  child: const Icon(Icons.forum_rounded,
                      color: Colors.white, size: 23),
                ),
                const SizedBox(width: 11),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('PUBLIC CHAT',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                            fontWeight: FontWeight.w900,
                            letterSpacing: .9,
                          )),
                      SizedBox(height: 2),
                      Text('Diskusi bersama • foto • reaksi',
                          style: TextStyle(
                            color: Colors.white54,
                            fontSize: 10.5,
                            fontWeight: FontWeight.w600,
                          )),
                    ],
                  ),
                ),
                _ConnectionPill(connected: _connected),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildRoomInfo() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 8),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(.035),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Colors.white.withOpacity(.06)),
        ),
        child: Row(
          children: [
            Icon(Icons.public_rounded,
                color: _purple2.withOpacity(.9), size: 18),
            const SizedBox(width: 9),
            const Expanded(
              child: Text(
                'Ruang obrolan publik untuk semua pengguna',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: Colors.white70,
                  fontSize: 10.5,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            if (_messages.isNotEmpty)
              Text('${_messages.length}',
                  style: TextStyle(
                    color: _purple2.withOpacity(.75),
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                  )),
          ],
        ),
      ),
    );
  }

  Widget _buildMessages() {
    if (_loading && _messages.isEmpty) {
      return const Center(
        child: CircularProgressIndicator(strokeWidth: 2, color: _purple2),
      );
    }
    if (_messages.isEmpty) {
      return Center(
        child: FadeTransition(
          opacity: CurvedAnimation(parent: _entryCtrl, curve: Curves.easeOut),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 78,
                height: 78,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _purple.withOpacity(.12),
                  border: Border.all(color: _purple2.withOpacity(.22)),
                ),
                child: const Icon(Icons.forum_outlined,
                    color: _purple2, size: 34),
              ),
              const SizedBox(height: 14),
              const Text('Belum ada obrolan',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                  )),
              const SizedBox(height: 5),
              const Text('Jadilah yang pertama mengirim pesan ✨',
                  style: TextStyle(color: Colors.white38, fontSize: 11)),
            ],
          ),
        ),
      );
    }

    return ListView.builder(
      controller: _scroll,
      padding: const EdgeInsets.fromLTRB(12, 4, 12, 16),
      physics: const BouncingScrollPhysics(),
      itemCount: _messages.length,
      itemBuilder: (context, index) {
        final message = _messages[index];
        final previous = index == 0 ? null : _messages[index - 1];
        final showDay =
            previous == null || _dayLabel(previous.time) != _dayLabel(message.time);

        return Column(
          children: [
            if (showDay)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: _DateChip(label: _dayLabel(message.time)),
              ),
            _MessageBubble(
              message: message,
              time: _time(message.time),
              roleColor: _roleColor(message.role),
              onDoubleTap: () => _showMessageActions(message),
              onLongPress: () => _showMessageActions(message),
              onReactionTap: (emoji) => _react(message, emoji),
            ),
          ],
        );
      },
    );
  }

  Widget _buildComposer() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(10, 5, 10, 9),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(25),
        child: BackdropFilter(
          filter: ui.ImageFilter.blur(sigmaX: 26, sigmaY: 26),
          child: Container(
            padding: const EdgeInsets.fromLTRB(7, 7, 7, 7),
            decoration: BoxDecoration(
              color: const Color(0xFF120C1C).withOpacity(.91),
              borderRadius: BorderRadius.circular(25),
              border: Border.all(color: _purple2.withOpacity(.22)),
              boxShadow: [
                BoxShadow(
                  color: _purple.withOpacity(.12),
                  blurRadius: 28,
                  offset: const Offset(0, -7),
                ),
              ],
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                _GlassIcon(
                  icon: _uploading
                      ? Icons.hourglass_top_rounded
                      : Icons.add_photo_alternate_rounded,
                  onTap: _uploading ? null : _pickAndSendImage,
                ),
                const SizedBox(width: 6),
                Expanded(
                  child: TextField(
                    controller: _text,
                    minLines: 1,
                    maxLines: 5,
                    textCapitalization: TextCapitalization.sentences,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                    cursorColor: _purple2,
                    decoration: InputDecoration(
                      hintText: 'Tulis pesan...',
                      hintStyle: const TextStyle(color: Colors.white30),
                      filled: true,
                      fillColor: Colors.white.withOpacity(.045),
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 15,
                        vertical: 12,
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(19),
                        borderSide: BorderSide.none,
                      ),
                    ),
                    onSubmitted: (_) => _sendText(),
                  ),
                ),
                const SizedBox(width: 7),
                GestureDetector(
                  onTap: _sending ? null : _sendText,
                  child: AnimatedBuilder(
                    animation: _pulseCtrl,
                    builder: (_, __) {
                      final scale = _sending ? .93 : 1 + (_pulseCtrl.value * .025);
                      return Transform.scale(
                        scale: scale,
                        child: Container(
                          width: 48,
                          height: 48,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: const LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [_purple2, _purple],
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: _purple.withOpacity(.38),
                                blurRadius: 17,
                              ),
                            ],
                          ),
                          child: Icon(
                            _sending
                                ? Icons.hourglass_top_rounded
                                : Icons.arrow_upward_rounded,
                            color: Colors.white,
                            size: 22,
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _MessageBubble extends StatelessWidget {
  final _ChatMessage message;
  final String time;
  final Color roleColor;
  final VoidCallback onDoubleTap;
  final VoidCallback onLongPress;
  final void Function(String emoji) onReactionTap;

  const _MessageBubble({
    required this.message,
    required this.time,
    required this.roleColor,
    required this.onDoubleTap,
    required this.onLongPress,
    required this.onReactionTap,
  });

  @override
  Widget build(BuildContext context) {
    final hasImage = message.imageUrl.isNotEmpty;
    final hasText = message.text.trim().isNotEmpty;
    final reactions = message.reactions.entries.toList();

    return Align(
      alignment: message.mine ? Alignment.centerRight : Alignment.centerLeft,
      child: GestureDetector(
        onDoubleTap: onDoubleTap,
        onLongPress: onLongPress,
        child: Container(
          constraints: BoxConstraints(
            maxWidth: MediaQuery.of(context).size.width * .84,
          ),
          margin: const EdgeInsets.only(bottom: 7),
          padding: const EdgeInsets.fromLTRB(5, 5, 7, 6),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: message.mine
                  ? [
                      const Color(0xFF7C3AED).withOpacity(.92),
                      const Color(0xFF9333EA).withOpacity(.78),
                    ]
                  : [
                      const Color(0xFF1A1425).withOpacity(.96),
                      const Color(0xFF211832).withOpacity(.92),
                    ],
            ),
            borderRadius: BorderRadius.only(
              topLeft: const Radius.circular(21),
              topRight: const Radius.circular(21),
              bottomLeft: Radius.circular(message.mine ? 21 : 6),
              bottomRight: Radius.circular(message.mine ? 6 : 21),
            ),
            border: Border.all(
              color: message.mine
                  ? Colors.white.withOpacity(.10)
                  : Colors.white.withOpacity(.065),
            ),
            boxShadow: [
              BoxShadow(
                color: message.mine
                    ? const Color(0xFF7C3AED).withOpacity(.12)
                    : Colors.black.withOpacity(.22),
                blurRadius: 14,
                offset: const Offset(0, 5),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (!message.mine)
                Padding(
                  padding: const EdgeInsets.fromLTRB(8, 4, 8, 4),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Flexible(
                        child: Text(
                          message.username,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: roleColor,
                            fontSize: 10.5,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                      if (message.role != 'member') ...[
                        const SizedBox(width: 5),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 5, vertical: 2),
                          decoration: BoxDecoration(
                            color: roleColor.withOpacity(.13),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            message.role.toUpperCase(),
                            style: TextStyle(
                              color: roleColor,
                              fontSize: 7,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              if (hasImage)
                ClipRRect(
                  borderRadius: BorderRadius.circular(17),
                  child: Hero(
                    tag: 'chat-image-${message.id}',
                    child: Image.network(
                      message.imageUrl,
                      width: 270,
                      height: 220,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(
                        width: 270,
                        height: 120,
                        alignment: Alignment.center,
                        color: Colors.black26,
                        child: const Icon(Icons.broken_image_rounded,
                            color: Colors.white38, size: 30),
                      ),
                      loadingBuilder: (_, child, progress) =>
                          progress == null
                              ? child
                              : Container(
                                  width: 270,
                                  height: 180,
                                  alignment: Alignment.center,
                                  child: const CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: Colors.white54,
                                  ),
                                ),
                    ),
                  ),
                ),
              if (hasImage && hasText) const SizedBox(height: 5),
              if (hasText)
                Padding(
                  padding: const EdgeInsets.fromLTRB(8, 3, 8, 0),
                  child: Text(
                    message.text,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      height: 1.35,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              Padding(
                padding: const EdgeInsets.fromLTRB(8, 4, 0, 0),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      time,
                      style: TextStyle(
                        color: Colors.white.withOpacity(.43),
                        fontSize: 8.5,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    if (message.mine) ...[
                      const SizedBox(width: 4),
                      Icon(Icons.done_all_rounded,
                          color: Colors.white.withOpacity(.48), size: 12),
                    ],
                  ],
                ),
              ),
              if (reactions.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.fromLTRB(5, 5, 0, 0),
                  child: Wrap(
                    spacing: 4,
                    runSpacing: 4,
                    children: reactions.map((entry) {
                      final mine = entry.value.contains(message.username);
                      return GestureDetector(
                        onTap: () => onReactionTap(entry.key),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 7, vertical: 4),
                          decoration: BoxDecoration(
                            color: mine
                                ? Colors.white.withOpacity(.17)
                                : Colors.black.withOpacity(.18),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: mine
                                  ? Colors.white.withOpacity(.22)
                                  : Colors.white.withOpacity(.08),
                            ),
                          ),
                          child: Text(
                            '${entry.key} ${entry.value.length}',
                            style: const TextStyle(fontSize: 11),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _DateChip extends StatelessWidget {
  final String label;
  const _DateChip({required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 5),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.045),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withOpacity(.06)),
      ),
      child: Text(label,
          style: const TextStyle(
            color: Colors.white38,
            fontSize: 8.5,
            fontWeight: FontWeight.w800,
            letterSpacing: .5,
          )),
    );
  }
}

class _GlassIcon extends StatelessWidget {
  final IconData icon;
  final VoidCallback? onTap;
  const _GlassIcon({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 46,
        height: 46,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(.045),
          borderRadius: BorderRadius.circular(17),
          border: Border.all(color: Colors.white.withOpacity(.07)),
        ),
        child: Icon(icon, color: Colors.white70, size: 21),
      ),
    );
  }
}

class _ConnectionPill extends StatelessWidget {
  final bool connected;
  const _ConnectionPill({required this.connected});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 7),
      decoration: BoxDecoration(
        color: (connected ? const Color(0xFF4ADE80) : const Color(0xFFF59E0B))
            .withOpacity(.09),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: (connected ? const Color(0xFF4ADE80) : const Color(0xFFF59E0B))
              .withOpacity(.16),
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: connected
                  ? const Color(0xFF4ADE80)
                  : const Color(0xFFF59E0B),
            ),
          ),
          const SizedBox(width: 5),
          Text(
            connected ? 'LIVE' : 'SYNC',
            style: TextStyle(
              color: connected
                  ? const Color(0xFF86EFAC)
                  : const Color(0xFFFCD34D),
              fontSize: 8,
              fontWeight: FontWeight.w900,
              letterSpacing: .6,
            ),
          ),
        ],
      ),
    );
  }
}

class _GlowBackground extends StatelessWidget {
  const _GlowBackground();

  @override
  Widget build(BuildContext context) {
    return CustomPaint(painter: _GlowPainter());
  }
}

class _GlowPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p1 = Paint()
      ..shader = RadialGradient(
        colors: [
          const Color(0xFF7C3AED).withOpacity(.17),
          Colors.transparent,
        ],
      ).createShader(
        Rect.fromCircle(
          center: Offset(size.width * .15, size.height * .08),
          radius: size.width * .65,
        ),
      );
    canvas.drawCircle(
      Offset(size.width * .15, size.height * .08),
      size.width * .65,
      p1,
    );

    final p2 = Paint()
      ..shader = RadialGradient(
        colors: [
          const Color(0xFFA855F7).withOpacity(.10),
          Colors.transparent,
        ],
      ).createShader(
        Rect.fromCircle(
          center: Offset(size.width * .9, size.height * .75),
          radius: size.width * .65,
        ),
      );
    canvas.drawCircle(
      Offset(size.width * .9, size.height * .75),
      size.width * .65,
      p2,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
