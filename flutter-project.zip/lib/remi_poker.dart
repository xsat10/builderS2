import 'dart:math';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

// Tambahkan enum GameResult
enum GameResult {
  win,
  lose,
  tie,
}

class PokerGamePage extends StatefulWidget {
  const PokerGamePage({super.key});

  @override
  State<PokerGamePage> createState() => _PokerGamePageState();
}

class _PokerGamePageState extends State<PokerGamePage> with TickerProviderStateMixin {
  // ============================================================
  // VARIABLES GAME
  // ============================================================
  
  // Chip & Money
  int _playerChips = 1000;
  int _pot = 0;
  int _ante = 50;
  int _currentBet = 0;
  
  // Game State
  String _gamePhase = 'setup';
  int _currentRound = 1;
  int _currentPlayerTurn = 0;
  
  // Player Data
  List<Map<String, dynamic>> _players = [];
  List<Map<String, dynamic>> _aiPlayers = [];
  
  // Cards
  List<Map<String, dynamic>> _deck = [];
  List<Map<String, dynamic>> _playerHand = [];
  
  // 🆕 FIX: Ubah tipe data menjadi List of List
  List<List<Map<String, dynamic>>> _aiHands = [];
  
  // Settings
  int _selectedPlayerCount = 4;
  int _selectedAnte = 50;
  String _gameMode = '5 Card Draw';
  
  // Animations
  late AnimationController _dealController;
  late Animation<double> _dealAnimation;
  
  @override
  void initState() {
    super.initState();
    _loadChips();
    _dealController = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    _dealAnimation = CurvedAnimation(parent: _dealController, curve: Curves.easeOut);
    _dealController.forward();
  }
  
  @override
  void dispose() {
    _dealController.dispose();
    super.dispose();
  }
  
  Future<void> _loadChips() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _playerChips = prefs.getInt('poker_chips') ?? 1000;
    });
  }
  
  Future<void> _saveChips() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('poker_chips', _playerChips);
  }
  
  // ============================================================
  // DECK & CARD FUNCTIONS
  // ============================================================
  
  void _initializeDeck() {
    _deck = [];
    List<String> suits = ['♥', '♦', '♣', '♠'];
    List<String> ranks = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];
    List<int> values = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14];
    
    for (int i = 0; i < suits.length; i++) {
      for (int j = 0; j < ranks.length; j++) {
        _deck.add({
          'suit': suits[i],
          'rank': ranks[j],
          'value': values[j],
          'color': suits[i] == '♥' || suits[i] == '♦' ? Colors.red : Colors.black,
        });
      }
    }
    _shuffleDeck();
  }
  
  void _shuffleDeck() {
    final random = Random();
    for (int i = _deck.length - 1; i > 0; i--) {
      int j = random.nextInt(i + 1);
      var temp = _deck[i];
      _deck[i] = _deck[j];
      _deck[j] = temp;
    }
  }
  
  List<Map<String, dynamic>> _drawCards(int count) {
    List<Map<String, dynamic>> drawn = [];
    for (int i = 0; i < count; i++) {
      if (_deck.isNotEmpty) {
        drawn.add(_deck.removeLast());
      }
    }
    return drawn;
  }
  
  // ============================================================
  // POKER HAND EVALUATION
  // ============================================================
  
  Map<String, dynamic> _evaluateHand(List<Map<String, dynamic>> hand) {
    if (hand.length != 5) return {'rank': 0, 'name': 'Invalid', 'value': 0};
    
    List<Map<String, dynamic>> sorted = List.from(hand);
    sorted.sort((a, b) => a['value'].compareTo(b['value']));
    
    List<int> values = sorted.map((c) => c['value'] as int).toList();
    List<String> suits = sorted.map((c) => c['suit'] as String).toList();
    
    bool isFlush = suits.toSet().length == 1;
    
    bool isStraight = true;
    for (int i = 0; i < values.length - 1; i++) {
      if (values[i + 1] != values[i] + 1) {
        isStraight = false;
        break;
      }
    }
    
    if (!isStraight && values[0] == 2 && values[1] == 3 && values[2] == 4 && values[3] == 5 && values[4] == 14) {
      isStraight = true;
      values = [1, 2, 3, 4, 5];
    }
    
    Map<int, int> freq = {};
    for (int v in values) {
      freq[v] = (freq[v] ?? 0) + 1;
    }
    List<int> counts = freq.values.toList()..sort((a, b) => b.compareTo(a));
    
    if (isFlush && isStraight && values.contains(10) && values.contains(14)) {
      return {'rank': 10, 'name': 'Royal Flush', 'value': 10000};
    }
    if (isFlush && isStraight) {
      return {'rank': 9, 'name': 'Straight Flush', 'value': 9000 + values.last};
    }
    if (counts[0] == 4) {
      return {'rank': 8, 'name': 'Four of a Kind', 'value': 8000 + freq.keys.firstWhere((k) => freq[k] == 4)};
    }
    if (counts[0] == 3 && counts[1] == 2) {
      return {'rank': 7, 'name': 'Full House', 'value': 7000 + freq.keys.firstWhere((k) => freq[k] == 3)};
    }
    if (isFlush) {
      return {'rank': 6, 'name': 'Flush', 'value': 6000 + values.last};
    }
    if (isStraight) {
      return {'rank': 5, 'name': 'Straight', 'value': 5000 + values.last};
    }
    if (counts[0] == 3) {
      return {'rank': 4, 'name': 'Three of a Kind', 'value': 4000 + freq.keys.firstWhere((k) => freq[k] == 3)};
    }
    if (counts[0] == 2 && counts[1] == 2) {
      return {'rank': 3, 'name': 'Two Pair', 'value': 3000};
    }
    if (counts[0] == 2) {
      return {'rank': 2, 'name': 'One Pair', 'value': 2000 + freq.keys.firstWhere((k) => freq[k] == 2)};
    }
    return {'rank': 1, 'name': 'High Card', 'value': 1000 + values.last};
  }
  
  // ============================================================
  // GAME SETUP
  // ============================================================
  
  void _startGame() {
    setState(() {
      _gamePhase = 'playing';
      _currentRound = 1;
      _pot = 0;
      _currentBet = _selectedAnte;
      
      _players = [
        {'name': 'Anda', 'chips': _playerChips, 'isAI': false, 'action': null, 'bet': 0, 'hand': [], 'folded': false},
      ];
      
      List<String> aiNames = ['Bruno', 'Sakura', 'Viktor', 'Luna', 'Ryo', 'Maya'];
      _aiPlayers = [];
      for (int i = 0; i < _selectedPlayerCount - 1; i++) {
        _aiPlayers.add({
          'name': aiNames[i % aiNames.length],
          'chips': 1000,
          'isAI': true,
          'action': null,
          'bet': 0,
          'hand': [],
          'folded': false,
        });
      }
      
      _players.addAll(_aiPlayers);
      
      for (int i = 0; i < _players.length; i++) {
        int anteAmount = _selectedAnte;
        if (_players[i]['chips'] >= anteAmount) {
          _players[i]['chips'] = _players[i]['chips'] - anteAmount;
          _players[i]['bet'] = anteAmount;
          _pot += anteAmount;
        }
      }
      
      _initializeDeck();
      _playerHand = _drawCards(5);
      
      // 🆕 FIX: Clear dan isi ulang _aiHands dengan benar
      _aiHands.clear();
      for (int i = 0; i < _aiPlayers.length; i++) {
        _aiHands.add(_drawCards(5));
      }
      
      _currentPlayerTurn = 0;
    });
  }
  
  void _playerAction(String action, {int raiseAmount = 0}) {
    setState(() {
      if (action == 'FOLD') {
        _players[0]['action'] = 'FOLD';
        _players[0]['folded'] = true;
        _nextTurn();
      } else if (action == 'CHECK') {
        int callAmount = _currentBet - (_players[0]['bet'] as int);
        if (callAmount > 0 && _players[0]['chips'] >= callAmount) {
          _players[0]['chips'] = _players[0]['chips'] - callAmount;
          _players[0]['bet'] = (_players[0]['bet'] as int) + callAmount;
          _pot += callAmount;
        }
        _players[0]['action'] = 'CHECK';
        _nextTurn();
      } else if (action == 'RAISE') {
        int totalRaise = _currentBet + raiseAmount;
        if (_players[0]['chips'] >= totalRaise) {
          _players[0]['chips'] = _players[0]['chips'] - totalRaise;
          _players[0]['bet'] = (_players[0]['bet'] as int) + totalRaise;
          _pot += totalRaise;
          _currentBet = _players[0]['bet'];
        }
        _players[0]['action'] = 'RAISE';
        _nextTurn();
      }
    });
  }
  
  void _nextTurn() {
    _currentPlayerTurn++;
    
    if (_currentPlayerTurn >= _players.length) {
      _showdown();
    } else if (_players[_currentPlayerTurn]['isAI'] == true) {
      _aiAction(_currentPlayerTurn);
    }
  }
  
  void _aiAction(int playerIndex) {
    Future.delayed(const Duration(milliseconds: 800), () {
      if (!mounted) return;
      
      setState(() {
        var ai = _players[playerIndex];
        Random random = Random();
        
        int randomAction = random.nextInt(10);
        String action;
        int raiseAmount = 0;
        
        if (randomAction < 4) {
          action = 'FOLD';
          ai['folded'] = true;
        } else if (randomAction < 7) {
          action = 'CHECK';
          int callAmount = _currentBet - (ai['bet'] as int);
          if (callAmount > 0 && ai['chips'] >= callAmount) {
            ai['chips'] = ai['chips'] - callAmount;
            ai['bet'] = (ai['bet'] as int) + callAmount;
            _pot += callAmount;
          }
        } else {
          action = 'RAISE';
          raiseAmount = 50 + random.nextInt(150);
          if (ai['chips'] >= _currentBet + raiseAmount) {
            ai['chips'] = ai['chips'] - (_currentBet + raiseAmount);
            ai['bet'] = (ai['bet'] as int) + _currentBet + raiseAmount;
            _pot += _currentBet + raiseAmount;
            _currentBet = ai['bet'];
          } else {
            action = 'CHECK';
          }
        }
        
        ai['action'] = action;
        _nextTurn();
      });
    });
  }
  
  void _showdown() {
    List<Map<String, dynamic>> allHands = [];
    
    allHands.add({
      'player': _players[0],
      'hand': _playerHand,
      'evaluation': _evaluateHand(_playerHand),
      'folded': _players[0]['folded'] ?? false,
    });
    
    for (int i = 0; i < _aiPlayers.length; i++) {
      allHands.add({
        'player': _players[i + 1],
        'hand': _aiHands[i],
        'evaluation': _evaluateHand(_aiHands[i]),
        'folded': _players[i + 1]['folded'] ?? false,
      });
    }
    
    List<Map<String, dynamic>> activePlayers = allHands.where((p) => !p['folded']).toList();
    
    if (activePlayers.isEmpty) {
      _endGame(null);
      return;
    }
    
    activePlayers.sort((a, b) => (b['evaluation']['value'] as int).compareTo(a['evaluation']['value'] as int));
    
    Map<String, dynamic> winner = activePlayers.first;
    int winnerValue = winner['evaluation']['value'];
    
    List<Map<String, dynamic>> winners = activePlayers.where((p) => p['evaluation']['value'] == winnerValue).toList();
    
    if (winners.length > 1) {
      int splitAmount = _pot ~/ winners.length;
      for (var w in winners) {
        w['player']['chips'] = (w['player']['chips'] as int) + splitAmount;
        _showWinnerDialog(w['player']['name'], splitAmount, true);
      }
    } else {
      winner['player']['chips'] = (winner['player']['chips'] as int) + _pot;
      _showWinnerDialog(winner['player']['name'], _pot, false);
    }
    
    _playerChips = _players[0]['chips'];
    _saveChips();
    
    _endGame(null);
  }
  
  void _showWinnerDialog(String winnerName, int amount, bool isSplit) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            const Icon(Icons.emoji_events, color: Colors.amber, size: 28),
            const SizedBox(width: 10),
            const Text("Pemenang!", style: TextStyle(color: Colors.white)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              winnerName,
              style: const TextStyle(
                color: Color(0xFF29B6F6),
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              isSplit ? "Memenangkan $amount chips (Split Pot)" : "Memenangkan $amount chips!",
              style: const TextStyle(color: Colors.white70),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _resetGame();
            },
            child: const Text("LANJUTKAN", style: TextStyle(color: Color(0xFF29B6F6))),
          ),
        ],
      ),
    );
  }
  
  void _endGame(dynamic result) {
    setState(() {
      _gamePhase = 'setup';
    });
  }
  
  void _resetGame() {
    setState(() {
      _gamePhase = 'setup';
      _players = [];
      _playerHand = [];
      _aiHands = [];
      _pot = 0;
      _currentRound = 1;
      _currentBet = 0;
    });
  }
  
  // ============================================================
  // UI BUILD (SISANYA TIDAK BERUBAH)
  // ============================================================
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A4A2A),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1B5E3F),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          "REMI POKER",
          style: TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.bold,
            letterSpacing: 2,
          ),
        ),
        centerTitle: true,
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 16),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.amber.withOpacity(0.3),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.amber),
            ),
            child: Row(
              children: [
                const Icon(Icons.attach_money, color: Colors.amber, size: 16),
                Text(
                  "${_playerChips}K",
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
        ],
      ),
      body: _gamePhase == 'setup' ? _buildSetupScreen() : _buildGameScreen(),
    );
  }
  
  Widget _buildSetupScreen() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [const Color(0xFF0A4A2A), const Color(0xFF06351D)],
        ),
      ),
      child: Column(
        children: [
          Container(
            margin: const EdgeInsets.all(20),
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.3),
              borderRadius: BorderRadius.circular(30),
              border: Border.all(color: Colors.amber.withOpacity(0.5)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.attach_money, color: Colors.amber, size: 24),
                const SizedBox(width: 8),
                Text(
                  "${_playerChips} chips",
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            "PENGATURAN MEJA",
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 30),
          _buildSetupSection(
            title: "Jumlah Pemain",
            children: [
              _buildOptionChip("2 Pemain", 2, _selectedPlayerCount),
              _buildOptionChip("4 Pemain", 4, _selectedPlayerCount),
              _buildOptionChip("6 Pemain", 6, _selectedPlayerCount),
            ],
          ),
          const SizedBox(height: 24),
          _buildSetupSection(
            title: "Ante (Taruhan Awal)",
            children: [
              _buildOptionChip("25", 25, _selectedAnte),
              _buildOptionChip("50", 50, _selectedAnte),
              _buildOptionChip("100", 100, _selectedAnte),
              _buildOptionChip("200", 200, _selectedAnte),
            ],
          ),
          const SizedBox(height: 24),
          _buildSetupSection(
            title: "Mode Game",
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                decoration: BoxDecoration(
                  color: const Color(0xFF29B6F6).withOpacity(0.2),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFF29B6F6)),
                ),
                child: Column(
                  children: [
                    const Text(
                      "5 Card Draw",
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      "Tukar hingga 5 kartu",
                      style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 10),
                    ),
                    Text(
                      "Kombinasi Poker penuh",
                      style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 10),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const Spacer(),
          GestureDetector(
            onTap: _startGame,
            child: Container(
              margin: const EdgeInsets.all(24),
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 16),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF29B6F6), Color(0xFF0288D1)],
                ),
                borderRadius: BorderRadius.circular(30),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF29B6F6).withOpacity(0.4),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: const Center(
                child: Text(
                  "MULAI BERMAIN",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildSetupSection({required String title, required List<Widget> children}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        const SizedBox(height: 10),
        Wrap(
          spacing: 12,
          runSpacing: 12,
          children: children,
        ),
      ],
    );
  }
  
  Widget _buildOptionChip(String label, int value, int currentValue) {
    bool isSelected = currentValue == value;
    return GestureDetector(
      onTap: () {
        setState(() {
          if (label.contains("Pemain")) {
            _selectedPlayerCount = value;
          } else {
            _selectedAnte = value;
          }
        });
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF29B6F6) : Colors.white.withOpacity(0.1),
          borderRadius: BorderRadius.circular(25),
          border: Border.all(
            color: isSelected ? const Color(0xFF29B6F6) : Colors.white.withOpacity(0.3),
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: isSelected ? Colors.white : Colors.white.withOpacity(0.7),
            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
          ),
        ),
      ),
    );
  }
  
  Widget _buildGameScreen() {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.3),
            borderRadius: const BorderRadius.only(
              bottomLeft: Radius.circular(20),
              bottomRight: Radius.circular(20),
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Ronde Taruhan $_currentRound",
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.amber.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.amber),
                ),
                child: Text(
                  "POT: $_pot | Ante: $_selectedAnte",
                  style: const TextStyle(color: Colors.amber, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
        ),
        
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: _aiPlayers.length,
            itemBuilder: (context, index) {
              var player = _players[index + 1];
              String action = player['action'] ?? 'MENUNGGU';
              Color actionColor = action == 'FOLD' ? Colors.red : (action == 'CALL' ? Colors.green : Colors.orange);
              
              return Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.4),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.white.withOpacity(0.1)),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 50,
                      height: 50,
                      decoration: BoxDecoration(
                        color: const Color(0xFF29B6F6).withOpacity(0.3),
                        shape: BoxShape.circle,
                      ),
                      child: Center(
                        child: Text(
                          player['name'][0],
                          style: const TextStyle(color: Colors.white, fontSize: 24),
                        ),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            player['name'],
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            action,
                            style: TextStyle(
                              color: actionColor,
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Text(
                      "${player['chips']}K",
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
        
        Container(
          padding: const EdgeInsets.all(16),
          color: Colors.black.withOpacity(0.5),
          child: Column(
            children: [
              const Text(
                "TANGAN KAMU",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: _playerHand.map((card) {
                  return _buildCard(card);
                }).toList(),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  _buildActionButton("FOLD", Colors.red, () => _playerAction('FOLD')),
                  _buildActionButton("CHECK", Colors.grey, () => _playerAction('CHECK')),
                  _buildActionButton("RAISE", Colors.green, () => _showRaiseDialog()),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                "+$_selectedAnte | +$_selectedAnte | +$_selectedAnte",
                style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 12),
              ),
            ],
          ),
        ),
      ],
    );
  }
  
  Widget _buildCard(Map<String, dynamic> card) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 4),
      width: 55,
      height: 75,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            card['rank'],
            style: TextStyle(
              color: card['color'],
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          Text(
            card['suit'],
            style: TextStyle(
              color: card['color'],
              fontSize: 24,
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildActionButton(String label, Color color, VoidCallback onTap) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 8),
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: color.withOpacity(0.8),
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.4),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Center(
            child: Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ),
    );
  }
  
  void _showRaiseDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A1A),
        title: const Text("RAISE", style: TextStyle(color: Colors.white)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text("Pilih jumlah kenaikan:", style: TextStyle(color: Colors.white70)),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildRaiseOption(50, context),
                _buildRaiseOption(100, context),
                _buildRaiseOption(200, context),
                _buildRaiseOption(500, context),
              ],
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildRaiseOption(int amount, BuildContext dialogContext) {
    return GestureDetector(
      onTap: () {
        Navigator.pop(dialogContext);
        _playerAction('RAISE', raiseAmount: amount);
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          color: const Color(0xFF29B6F6).withOpacity(0.2),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: const Color(0xFF29B6F6)),
        ),
        child: Text(
          "+$amount",
          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}