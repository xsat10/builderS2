import 'dart:math';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

// ==================== WARNA ====================
const Color navyDeep = Color(0xFF0A1929);
const Color navyMedium = Color(0xFF1E2F4A);
const Color navyLight = Color(0xFF2A3F5F);
const Color accentOrange = Color(0xFFFF9F1C);
const Color accentGreen = Color(0xFF10B981);
const Color accentRed = Color(0xFFEF4444);
const Color accentYellow = Color(0xFFF59E0B);
const Color accentPurple = Color(0xFF8B5CF6);
const Color textPrimary = Colors.white;
const Color textSecondary = Color(0xFFB0B8C5);

// ==================== MODEL SOAL ====================
class SoalCakLontong {
  final String soal;
  final String jawaban;
  final String penjelasan;
  final int poin;

  SoalCakLontong({
    required this.soal,
    required this.jawaban,
    required this.penjelasan,
    required this.poin,
  });
}

// ==================== DATA SOAL - GAYA CAK LONTONG ASLI (MELENCENG) ====================
final List<SoalCakLontong> daftarSoal = [
  SoalCakLontong(
    soal: 'Apa bahasa Inggrisnya "saya lapar"?',
    jawaban: 'saya kenyang',
    penjelasan: 'Lha wong ditanya bahasa Inggrisnya "saya lapar", masa jawab "I am hungry"? Ya salah dong. Jawabannya "saya kenyang" biar beda!',
    poin: 10,
  ),
  SoalCakLontong(
    soal: 'Kalau kita makan terburu-buru, namanya makan apa?',
    jawaban: 'makan siang',
    penjelasan: 'Makan terburu-buru kan waktunya siang, karena buru-buru mau siang. Ya makan siang lah!',
    poin: 15,
  ),
  SoalCakLontong(
    soal: 'Siapa nama presiden pertama Indonesia?',
    jawaban: 'Pak RT',
    penjelasan: 'Presiden pertama kan pemimpin, nah pemimpin di kampung ya Pak RT. Jadi presiden pertama adalah Pak RT!',
    poin: 20,
  ),
  SoalCakLontong(
    soal: 'Apa yang naik tapi tidak pernah turun?',
    jawaban: 'tangga',
    penjelasan: 'Tangga kan buat naik, kalau turun ya pakai tangga juga tapi namanya turun tangga. Tapi tangganya sendiri tidak pernah turun!',
    poin: 20,
  ),
  SoalCakLontong(
    soal: 'Kenapa air laut asin?',
    jawaban: 'karena ikannya suka mie ayam',
    penjelasan: 'Ikan di laut suka mie ayam, tapi mie ayamnya tidak pakai garam. Jadi ikannya nangis, air laut jadi asin karena air mata ikan!',
    poin: 15,
  ),
  SoalCakLontong(
    soal: 'Apa bedanya kuda sama kuda nil?',
    jawaban: 'kuda nil punya kulkas',
    penjelasan: 'Kuda nil hidupnya di air, berarti dia butuh pendingin. Ya punya kulkas lah! Kuda biasa di darat pakai AC.',
    poin: 20,
  ),
  SoalCakLontong(
    soal: 'Kenapa telur disebut telur?',
    jawaban: 'karena telo itu singkong',
    penjelasan: 'Coba kalau disebut telo, nanti dikira singkong. Makanya disebut telur biar jelas bedanya sama singkong.',
    poin: 25,
  ),
  SoalCakLontong(
    soal: 'Hewan apa yang paling berjasa di dunia?',
    jawaban: 'ayam',
    penjelasan: 'Ayam kan bangunin kita subuh-subuh, kalau nggak ada ayam kita bangun siang terus. Berjasa banget kan?',
    poin: 15,
  ),
  SoalCakLontong(
    soal: 'Apa yang bisa kamu pegang tapi tidak bisa kamu lihat?',
    jawaban: 'dompet',
    penjelasan: 'Dompet kan bisa dipegang, tapi isinya kalau kosong ya tidak kelihatan. Tapi dompetnya tetap ada, namanya juga dompet!',
    poin: 20,
  ),
  SoalCakLontong(
    soal: 'Kenapa orang Jawa kalau jalan suka membungkuk?',
    jawaban: 'karena bawa kardus',
    penjelasan: 'Orang Jawa kan suka jualan, bawa kardus berisi barang dagangan. Makanya jalannya membungkuk. Bukan karena bawa golok!',
    poin: 25,
  ),
  SoalCakLontong(
    soal: 'Apa yang bisa terbang tanpa sayap?',
    jawaban: 'pesawat',
    penjelasan: 'Pesawat kan bisa terbang, tapi nggak punya sayap. Yang punya sayap itu burung, kalau pesawat punya mesin!',
    poin: 20,
  ),
  SoalCakLontong(
    soal: 'Kenapa kucing suka tidur di atas motor?',
    jawaban: 'karena motor punya bensin',
    penjelasan: 'Kucing suka bau bensin, makanya tidur di atas motor. Kalau di atas mobil juga bisa, tapi mobilnya bau solar beda!',
    poin: 15,
  ),
  SoalCakLontong(
    soal: 'Apa yang lebih besar dari gajah tapi tidak punya berat?',
    jawaban: 'foto gajah',
    penjelasan: 'Foto gajah kan lebih besar dari gajah asli? Nggak juga sih... Tapi yang jelas fotonya nggak punya berat!',
    poin: 30,
  ),
  SoalCakLontong(
    soal: 'Kenapa mie instan dimasak pakai dua telur?',
    jawaban: 'karena telurnya kecil-kecil',
    penjelasan: 'Kalau telurnya kecil, ya pakai dua. Kalau telurnya besar, pakai satu aja cukup. Gitu aja kok repot!',
    poin: 20,
  ),
  SoalCakLontong(
    soal: 'Apa yang selalu ada di depan tapi tidak pernah di belakang?',
    jawaban: 'kaca spion',
    penjelasan: 'Kaca spion kan ada di depan, buat liat belakang. Tapi kacanya sendiri tetap di depan, nggak pernah pindah ke belakang!',
    poin: 25,
  ),
  SoalCakLontong(
    soal: 'Kenapa orang Sunda suka makan pedas?',
    jawaban: 'karena lidahnya kebal',
    penjelasan: 'Lidah orang Sunda udah terbiasa pedas, jadi makan pedas kayak makan kerupuk. Biasa aja!',
    poin: 15,
  ),
  SoalCakLontong(
    soal: 'Apa bedanya soto sama rawon?',
    jawaban: 'soto pakai sendok, rawon pakai tangan',
    penjelasan: 'Soto kan kuahnya bening, makan pakai sendok. Rawon kuahnya hitam, kalau pakai sendok takut hitam, jadi pakai tangan!',
    poin: 20,
  ),
  SoalCakLontong(
    soal: 'Kenapa kita tidak boleh tidur di bawah pohon pisang?',
    jawaban: 'karena pohon pisang bukan pohon beringin',
    penjelasan: 'Kalau mau tidur di bawah pohon, ya di bawah pohon beringin. Pohon pisang untuk makan, bukan untuk tidur!',
    poin: 20,
  ),
  SoalCakLontong(
    soal: 'Apa yang membuat air menjadi panas?',
    jawaban: 'panci',
    penjelasan: 'Air kalau dipanaskan di panci ya jadi panas. Panci yang bikin air panas, bukan api!',
    poin: 10,
  ),
  SoalCakLontong(
    soal: 'Kenapa orang kalau nonton bola suka teriak?',
    jawaban: 'karena pemainnya jauh',
    penjelasan: 'Pemain bolanya jauh di lapangan, kalau nggak teriak nggak kedengeran. Makanya suka teriak biar pemainnya dengar!',
    poin: 15,
  ),
  SoalCakLontong(
    soal: 'Apa bedanya sate sama gulai?',
    jawaban: 'sate pakai tusuk, gulai pakai sendok',
    penjelasan: 'Sate kan makannya pakai tusuk, kalau gulai pakai sendok. Gitu aja kok bingung!',
    poin: 15,
  ),
  SoalCakLontong(
    soal: 'Kenapa motor kalau mogok harus didorong?',
    jawaban: 'karena kalau dikasih makan nggak mau',
    penjelasan: 'Motor kan nggak makan, jadi kalau mogok ya didorong. Kalau dikasih makan malah tambah repot!',
    poin: 20,
  ),
  SoalCakLontong(
    soal: 'Apa yang lebih cepat dari kilat?',
    jawaban: 'orang pingsan',
    penjelasan: 'Kilat kan cuma sekejap, tapi orang pingsan langsung jatuh. Lebih cepat itu!',
    poin: 25,
  ),
  SoalCakLontong(
    soal: 'Kenapa orang minum pakai gelas?',
    jawaban: 'karena kalau pakai ember kebanyakan',
    penjelasan: 'Gelas ukurannya pas, kalau ember kebanyakan nanti kebelet pipis. Makanya pakai gelas!',
    poin: 10,
  ),
  SoalCakLontong(
    soal: 'Apa bedanya mentimun sama timun?',
    jawaban: 'mentimun dimakan mentah, timun dimasak',
    penjelasan: 'Mentimun kan untuk lalapan, timun untuk sayur. Gitu aja!',
    poin: 15,
  ),
  SoalCakLontong(
    soal: 'Kenapa orang kalau kedinginan menggigil?',
    jawaban: 'karena mau ngomong "dingin" tapi nggak bisa',
    penjelasan: 'Lidahnya beku, jadi cuma bisa menggigil. Itu pertanda dia mau bilang dingin!',
    poin: 20,
  ),
  SoalCakLontong(
    soal: 'Apa yang lebih ringan dari kapas?',
    jawaban: 'kapas yang udah dipakai',
    penjelasan: 'Kapas baru berat, kapas bekas lebih ringan karena udah dipakai!',
    poin: 25,
  ),
  SoalCakLontong(
    soal: 'Kenapa durian punya kulit berduri?',
    jawaban: 'biar nggak dipegang sembarangan',
    penjelasan: 'Durian kan mahal, makanya dikasih duri biar orang nggak berani pegang. Nanti kalau keburu dibeli, baru boleh pegang!',
    poin: 20,
  ),
  SoalCakLontong(
    soal: 'Apa bedanya pantai sama laut?',
    jawaban: 'pantai ada pasirnya, laut ada ikannya',
    penjelasan: 'Pantai buat main pasir, laut buat mancing ikan. Jangan sampe salah!',
    poin: 15,
  ),
  SoalCakLontong(
    soal: 'Kenapa kita harus cuci tangan sebelum makan?',
    jawaban: 'biar tangannya kotor',
    penjelasan: 'Soalnya sebelum cuci tangan tangannya bersih, habis cuci tangan jadi bersih lagi. Tapi intinya biar tangannya kotor dulu baru bersih!',
    poin: 20,
  ),
  SoalCakLontong(
    soal: 'Apa bedanya kulkas sama freezer?',
    jawaban: 'kulkas buat sayur, freezer buat es batu',
    penjelasan: 'Kulkas buat nyimpen sayur biar segar, freezer buat bikin es batu. Tapi kalau es batu masuk kulkas ya meleleh!',
    poin: 15,
  ),
  SoalCakLontong(
    soal: 'Kenapa orang kalau malu suka senyum-senyum sendiri?',
    jawaban: 'karena giginya pengen keliatan',
    penjelasan: 'Orang malu kan biasanya nutup muka, tapi kalau senyum berarti giginya pengen eksis!',
    poin: 20,
  ),
  SoalCakLontong(
    soal: 'Apa yang bisa dipotong tapi nggak bisa dipotong?',
    jawaban: 'kue',
    penjelasan: 'Kue kan bisa dipotong, tapi kalau kuenya sudah habis ya nggak bisa dipotong lagi. Jadi tergantung masih ada atau nggak!',
    poin: 20,
  ),
  SoalCakLontong(
    soal: 'Kenapa orang kalau puasa suka ngantuk?',
    jawaban: 'karena perutnya kosong jadi bawaannya tidur',
    penjelasan: 'Kalau perut kosong, pikiran jadi kosong, ya akhirnya tidur. Itu ilmu fisika!',
    poin: 15,
  ),
  SoalCakLontong(
    soal: 'Apa bedanya sumpit sama sendok?',
    jawaban: 'sumpit buat makanan kering, sendok buat makanan basah',
    penjelasan: 'Sumpit kan buat mie atau sate, kalau sendok buat sop atau soto. Jangan sampe salah!',
    poin: 15,
  ),
  SoalCakLontong(
    soal: 'Kenapa orang kalau kesel suka banting pintu?',
    jawaban: 'karena pintunya nggak salah',
    penjelasan: 'Pintunya nggak salah, yang salah orangnya. Tapi emosinya meluap, ya pintu yang kena!',
    poin: 20,
  ),
  SoalCakLontong(
    soal: 'Apa yang lebih tajam dari silet?',
    jawaban: 'omongan orang',
    penjelasan: 'Silet cuma sakit sebentar, omongan orang sakitnya berkepanjangan. Lebih tajam omongan!',
    poin: 25,
  ),
  SoalCakLontong(
    soal: 'Kenapa orang kalau seneng suka joget?',
    jawaban: 'karena kakinya ikut seneng',
    penjelasan: 'Kalau hati seneng, kaki ikutan seneng. Makanya joget!',
    poin: 15,
  ),
  SoalCakLontong(
    soal: 'Apa bedanya kopi sama teh?',
    jawaban: 'kopi buat begadang, teh buat santai',
    penjelasan: 'Kopi bikin melek, teh bikin rileks. Pilih mana? Tergantung kebutuhan!',
    poin: 15,
  ),
  SoalCakLontong(
    soal: 'Kenapa orang kalau sakit gigi suka ngeluh?',
    jawaban: 'karena giginya minta perhatian',
    penjelasan: 'Gigi lagi sakit, minta diperhatiin. Makanya kita ngeluh biar ada yang perhatiin!',
    poin: 20,
  ),
  SoalCakLontong(
    soal: 'Apa yang paling enak di dunia?',
    jawaban: 'makan gratis',
    penjelasan: 'Makan apa aja enak kalau gratisan. Pokoknya gratis, rasanya jadi lebih enak!',
    poin: 25,
  ),
  SoalCakLontong(
    soal: 'Kenapa orang suka foto selfie?',
    jawaban: 'karena nggak ada yang mau motoin',
    penjelasan: 'Kan nggak ada temen, ya selfie sendiri. Gitu aja kok repot!',
    poin: 15,
  ),
  SoalCakLontong(
    soal: 'Apa bedanya buku sama novel?',
    jawaban: 'buku pelajaran, novel hiburan',
    penjelasan: 'Buku buat belajar biar pinter, novel buat hiburan biar nggak stres. Dua-duanya penting!',
    poin: 15,
  ),
  SoalCakLontong(
    soal: 'Kenapa orang kalau tidur suka ngorok?',
    jawaban: 'karena mimpi jadi penyanyi',
    penjelasan: 'Pas tidur, dia mimpi jadi penyanyi terkenal. Makanya ngorok kayak lagi nyanyi!',
    poin: 20,
  ),
  SoalCakLontong(
    soal: 'Apa yang paling berat di dunia?',
    jawaban: 'makanan yang belum dibayar',
    penjelasan: 'Makanan belum bayar berat banget di pikiran. Tapi kalau udah bayar, enteng!',
    poin: 25,
  ),
  SoalCakLontong(
    soal: 'Kenapa orang suka belanja pas diskon?',
    jawaban: 'karena yang mahal jadi murah',
    penjelasan: 'Diskon itu kan potongan harga, jadi yang tadinya mahal jadi murah. Mana tahan?',
    poin: 15,
  ),
  SoalCakLontong(
    soal: 'Apa bedanya hujan sama banjir?',
    jawaban: 'hujan dari langit, banjir dari mana-mana',
    penjelasan: 'Hujan turun dari langit, banjir datang dari mana-mana, bisa dari got, sungai, atau tetangga!',
    poin: 20,
  ),
  SoalCakLontong(
    soal: 'Kenapa orang kalau main game suka emosi?',
    jawaban: 'karena lawannya curang',
    penjelasan: 'Pasti lawannya pake cheat, makanya kita emosi. Padahal kita juga pake cheat, tapi beda!',
    poin: 20,
  ),
  SoalCakLontong(
    soal: 'Apa yang paling dibenci sama anak kos?',
    jawaban: 'tagihan listrik',
    penjelasan: 'Tagihan listrik itu musuh utama anak kos. Makanya hemat listrik biar dompet aman!',
    poin: 20,
  ),
  SoalCakLontong(
    soal: 'Kenapa orang suka makan kerupuk?',
    jawaban: 'karena makan nggak cukup',
    penjelasan: 'Nasinya cuma sedikit, jadi pake kerupuk biar kenyang. Kerupuk penyelamat!',
    poin: 15,
  ),
  SoalCakLontong(
    soal: 'Apa bedanya jomblo sama lajang?',
    jawaban: 'jomblo nggak punya pacar, lajang siap nikah',
    penjelasan: 'Jomblo itu belum punya pacar, lajang itu udah siap nikah tapi belum punya calon!',
    poin: 15,
  ),
  SoalCakLontong(
    soal: 'Kenapa orang kalau hujan suka lari?',
    jawaban: 'karena nggak mau basah',
    penjelasan: 'Hujan kan bikin basah, jadi lari biar nggak kehujanan. Tapi kalau lari, malah keringetan, jadi basah juga!',
    poin: 15,
  ),
  SoalCakLontong(
    soal: 'Apa yang paling ditunggu-tunggu pas lebaran?',
    jawaban: 'uang THR',
    penjelasan: 'THR itu Tunjangan Hari Raya, ditunggu-tunggu biar bisa belanja. Lebaran tanpa THR, hambar!',
    poin: 20,
  ),
  SoalCakLontong(
    soal: 'Kenapa orang suka nonton drakor?',
    jawaban: 'karena aktornya ganteng',
    penjelasan: 'Drakor kan terkenal aktor ganteng dan aktris cantik. Jadi ya suka nonton!',
    poin: 15,
  ),
  SoalCakLontong(
    soal: 'Apa bedanya mie instan sama mie biasa?',
    jawaban: 'mie instan cepet jadi, mie biasa lama',
    penjelasan: 'Mie instan tinggal seduh, mie biasa harus masak lama. Makanya anak kos suka mie instan!',
    poin: 15,
  ),
  SoalCakLontong(
    soal: 'Kenapa orang suka rebahan?',
    jawaban: 'karena rebahan itu nikmat',
    penjelasan: 'Rebahan adalah olahraga favorit semua orang. Nggak pakai biaya, nggak pakai tenaga!',
    poin: 20,
  ),
  SoalCakLontong(
    soal: 'Apa yang paling bikin bahagia?',
    jawaban: 'makan enak',
    penjelasan: 'Makan enak bisa bikin hati senang. Apalagi kalau makannya bareng teman!',
    poin: 20,
  ),
  SoalCakLontong(
    soal: 'Kenapa orang suka beli barang mahal?',
    jawaban: 'karena biar keliatan kaya',
    penjelasan: 'Barang mahal kan buat gaya-gayaan, biar orang ngira kita kaya. Padahal nabung bertahun-tahun!',
    poin: 15,
  ),
  SoalCakLontong(
    soal: 'Apa bedanya liburan sama jalan-jalan?',
    jawaban: 'liburan lama, jalan-jalan sebentar',
    penjelasan: 'Liburan bisa berhari-hari, jalan-jalan cuma sebentar. Tapi dua-duanya bikin happy!',
    poin: 15,
  ),
  SoalCakLontong(
    soal: 'Kenapa orang suka begadang?',
    jawaban: 'karena tidur keburu pagi',
    penjelasan: 'Begadang itu karena nggak bisa tidur, atau memang sengaja. Yang jelas paginya pasti ngantuk!',
    poin: 15,
  ),
];

class CakLontongPage extends StatefulWidget {
  final String sessionKey;

  const CakLontongPage({super.key, required this.sessionKey});

  @override
  State<CakLontongPage> createState() => _CakLontongPageState();
}

class _CakLontongPageState extends State<CakLontongPage>
    with TickerProviderStateMixin {
  List<SoalCakLontong> _soalList = [];
  int _currentIndex = 0;
  int _totalSkor = 0;
  int _totalBenar = 0;
  int _totalSalah = 0;
  bool _showAnswer = false;
  bool _isGameFinished = false;
  String _userAnswer = '';
  final TextEditingController _answerController = TextEditingController();
  final FocusNode _answerFocus = FocusNode();

  late AnimationController _pulseController;
  late AnimationController _shakeController;
  late AnimationController _celebrateController;
  late Animation<double> _pulseAnimation;
  late Animation<double> _shakeAnimation;

  @override
  void initState() {
    super.initState();
    _initGame();
    _initAnimations();
  }

  void _initGame() {
    _soalList = List.from(daftarSoal);
    _soalList.shuffle(Random());
    _currentIndex = 0;
    _totalSkor = 0;
    _totalBenar = 0;
    _totalSalah = 0;
    _showAnswer = false;
    _isGameFinished = false;
    _userAnswer = '';
    _answerController.clear();
  }

  void _initAnimations() {
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..repeat(reverse: true);
    _pulseAnimation = Tween<double>(begin: 0.98, end: 1.02).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _shakeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    _shakeAnimation = Tween<double>(begin: 0, end: 8).animate(
      CurvedAnimation(parent: _shakeController, curve: Curves.elasticIn),
    );

    _celebrateController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
  }

  void _checkAnswer() {
    String answer = _answerController.text.trim().toLowerCase();
    String correctAnswer = _soalList[_currentIndex].jawaban.toLowerCase();

    answer = answer.replaceAll(RegExp(r'\s+'), ' ').trim();
    correctAnswer = correctAnswer.replaceAll(RegExp(r'\s+'), ' ').trim();

    final isCorrect = answer == correctAnswer;

    setState(() {
      _showAnswer = true;
      _userAnswer = _answerController.text.trim();
    });

    if (isCorrect) {
      int poin = _soalList[_currentIndex].poin;
      setState(() {
        _totalSkor += poin;
        _totalBenar++;
      });
      _showNotification('🎉 BENAR! +$poin poin', isSuccess: true);
      _celebrateController.forward().then((_) => _celebrateController.reset());
    } else {
      setState(() {
        _totalSalah++;
      });
      _showNotification('💀 SALAH! Jawaban: ${_soalList[_currentIndex].jawaban}', isError: true);
      _shakeController.forward().then((_) => _shakeController.reset());
    }

    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) _nextQuestion();
    });
  }

  void _nextQuestion() {
    if (_currentIndex + 1 < _soalList.length) {
      setState(() {
        _currentIndex++;
        _showAnswer = false;
        _userAnswer = '';
        _answerController.clear();
      });
      _answerFocus.requestFocus();
    } else {
      setState(() => _isGameFinished = true);
      _showCompletionDialog();
    }
  }

  void _showNotification(String message, {bool isSuccess = false, bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(isSuccess ? Icons.check_circle : (isError ? Icons.error : Icons.info),
                color: Colors.white, size: 20),
            const SizedBox(width: 12),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: isSuccess ? accentGreen : (isError ? accentRed : accentOrange),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _showCompletionDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [navyMedium, navyDeep], begin: Alignment.topLeft, end: Alignment.bottomRight),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: accentYellow.withOpacity(0.5), width: 2),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(color: accentYellow.withOpacity(0.2), shape: BoxShape.circle,
                    border: Border.all(color: accentYellow, width: 2)),
                child: const Icon(Icons.emoji_events, color: Color(0xFFFFD700), size: 50),
              ),
              const SizedBox(height: 20),
              const Text('🏆 SELAMAT! 🏆',
                  style: TextStyle(color: accentYellow, fontSize: 24, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(color: navyLight.withOpacity(0.5), borderRadius: BorderRadius.circular(16)),
                child: Column(
                  children: [
                    _buildResultRow('Total Soal', '${_soalList.length}', accentOrange),
                    const SizedBox(height: 8),
                    _buildResultRow('✅ Benar', '$_totalBenar', accentGreen),
                    const SizedBox(height: 8),
                    _buildResultRow('❌ Salah', '$_totalSalah', accentRed),
                    const SizedBox(height: 8),
                    _buildResultRow('⭐ Total Skor', '$_totalSkor', accentYellow),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () { Navigator.pop(context); _resetGame(); },
                      style: ElevatedButton.styleFrom(backgroundColor: accentGreen, padding: const EdgeInsets.symmetric(vertical: 12),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                      child: const Text('MAIN LAGI', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () { Navigator.pop(context); Navigator.pop(context); },
                      style: OutlinedButton.styleFrom(side: BorderSide(color: accentOrange), padding: const EdgeInsets.symmetric(vertical: 12),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                      child: const Text('KELUAR', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildResultRow(String label, String value, Color color) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: TextStyle(color: textSecondary, fontSize: 14)),
        Text(value, style: TextStyle(color: color, fontSize: 18, fontWeight: FontWeight.bold)),
      ],
    );
  }

  void _resetGame() {
    _initGame();
    setState(() {});
  }

  void _skipQuestion() {
    setState(() {
      _showAnswer = true;
      _userAnswer = '';
      _totalSalah++;
    });
    _showNotification('⏭️ Skip! Jawaban: ${_soalList[_currentIndex].jawaban}', isError: true);
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) _nextQuestion();
    });
  }

  @override
  void dispose() {
    _answerController.dispose();
    _answerFocus.dispose();
    _pulseController.dispose();
    _shakeController.dispose();
    _celebrateController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isGameFinished) return _buildCompletionScreen();

    final currentSoal = _soalList[_currentIndex];
    final progress = ((_currentIndex + 1) / _soalList.length) * 100;

    return Scaffold(
      backgroundColor: navyDeep,
      appBar: _buildAppBar(),
      body: Stack(
        children: [
          Container(decoration: BoxDecoration(gradient: LinearGradient(colors: [navyDeep, navyMedium]))),
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  _buildProgressBar(progress),
                  const SizedBox(height: 20),
                  _buildScoreCard(),
                  const SizedBox(height: 24),
                  AnimatedBuilder(
                    animation: _shakeAnimation,
                    builder: (context, child) => Transform.translate(
                      offset: Offset(_shakeAnimation.value * (Random().nextBool() ? 1 : -1), 0),
                      child: _buildQuestionCard(currentSoal),
                    ),
                  ),
                  const SizedBox(height: 24),
                  if (!_showAnswer) _buildAnswerInput(),
                  if (_showAnswer) _buildResultPanel(currentSoal),
                  const SizedBox(height: 20),
                  if (!_showAnswer) _buildActionButtons(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      leading: Container(
        margin: const EdgeInsets.all(8),
        decoration: BoxDecoration(color: navyLight.withOpacity(0.5), borderRadius: BorderRadius.circular(12)),
        child: IconButton(icon: const Icon(Icons.arrow_back, color: Colors.white), onPressed: () => Navigator.pop(context)),
      ),
      title: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(gradient: LinearGradient(colors: [accentOrange, accentYellow]), borderRadius: BorderRadius.circular(12)),
            child: const Icon(Icons.lightbulb, color: Colors.white, size: 20),
          ),
          const SizedBox(width: 12),
          const Text('CAK LONTONG', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
        ],
      ),
    );
  }

  Widget _buildProgressBar(double progress) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Soal ${_currentIndex + 1}/${_soalList.length}', style: TextStyle(color: textSecondary, fontSize: 12)),
            Text('${progress.toStringAsFixed(0)}%', style: TextStyle(color: accentOrange, fontSize: 12, fontWeight: FontWeight.bold)),
          ],
        ),
        const SizedBox(height: 8),
        ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: LinearProgressIndicator(value: progress / 100, backgroundColor: navyLight,
              valueColor: AlwaysStoppedAnimation<Color>(accentOrange), minHeight: 8),
        ),
      ],
    );
  }

  Widget _buildScoreCard() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      decoration: BoxDecoration(gradient: LinearGradient(colors: [navyLight, navyMedium]), borderRadius: BorderRadius.circular(20),
          border: Border.all(color: accentYellow.withOpacity(0.3), width: 1)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          _buildScoreItem('⭐ SKOR', '$_totalSkor', accentYellow),
          Container(width: 1, height: 30, color: textSecondary.withOpacity(0.2)),
          _buildScoreItem('✅ BENAR', '$_totalBenar', accentGreen),
          Container(width: 1, height: 30, color: textSecondary.withOpacity(0.2)),
          _buildScoreItem('❌ SALAH', '$_totalSalah', accentRed),
        ],
      ),
    );
  }

  Widget _buildScoreItem(String label, String value, Color color) {
    return Column(
      children: [
        Text(label, style: TextStyle(color: textSecondary, fontSize: 10)),
        const SizedBox(height: 4),
        Text(value, style: TextStyle(color: color, fontSize: 18, fontWeight: FontWeight.bold)),
      ],
    );
  }

  Widget _buildQuestionCard(SoalCakLontong soal) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [navyLight, navyMedium]),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: accentOrange.withOpacity(0.3), width: 1.5),
        boxShadow: [BoxShadow(color: accentOrange.withOpacity(0.1), blurRadius: 20)],
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(color: accentOrange.withOpacity(0.2), borderRadius: BorderRadius.circular(20)),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.question_mark, color: accentOrange, size: 14),
                const SizedBox(width: 6),
                Text('SOAL +${soal.poin} POIN', style: TextStyle(color: accentOrange, fontSize: 10, fontWeight: FontWeight.bold)),
              ],
            ),
          ),
          const SizedBox(height: 20),
          Text(soal.soal, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w500, height: 1.4),
              textAlign: TextAlign.center),
        ],
      ),
    );
  }

  Widget _buildAnswerInput() {
    return Column(
      children: [
        Container(
          decoration: BoxDecoration(color: navyLight, borderRadius: BorderRadius.circular(16),
              border: Border.all(color: accentOrange.withOpacity(0.3))),
          child: TextField(
            controller: _answerController,
            focusNode: _answerFocus,
            style: const TextStyle(color: Colors.white, fontSize: 16),
            cursorColor: accentOrange,
            decoration: InputDecoration(
              hintText: 'Ketik jawabanmu di sini...',
              hintStyle: TextStyle(color: textSecondary.withOpacity(0.5)),
              prefixIcon: Container(margin: const EdgeInsets.all(12), child: Icon(Icons.edit, color: accentOrange, size: 20)),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(vertical: 16),
            ),
            onSubmitted: (_) => _checkAnswer(),
          ),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: AnimatedBuilder(
                animation: _pulseAnimation,
                builder: (context, child) => Transform.scale(
                  scale: _pulseAnimation.value,
                  child: Container(
                    height: 50,
                    decoration: BoxDecoration(gradient: LinearGradient(colors: [accentGreen, accentGreen.withOpacity(0.7)]),
                        borderRadius: BorderRadius.circular(12)),
                    child: ElevatedButton(
                      onPressed: _checkAnswer,
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.transparent, shadowColor: Colors.transparent,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                      child: const Text('JAWAB', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Container(
              height: 50, width: 50,
              decoration: BoxDecoration(color: navyLight, borderRadius: BorderRadius.circular(12), border: Border.all(color: accentRed.withOpacity(0.3))),
              child: IconButton(icon: Icon(Icons.skip_next, color: accentRed), onPressed: _skipQuestion),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildResultPanel(SoalCakLontong soal) {
    final isCorrect = _userAnswer.toLowerCase().trim() == soal.jawaban.toLowerCase().trim();
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: isCorrect ? [accentGreen.withOpacity(0.2), Colors.transparent]
            : [accentRed.withOpacity(0.2), Colors.transparent]),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: isCorrect ? accentGreen : accentRed, width: 1.5),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Icon(isCorrect ? Icons.check_circle : Icons.cancel, color: isCorrect ? accentGreen : accentRed, size: 28),
              const SizedBox(width: 12),
              Expanded(child: Text(isCorrect ? '✅ JAWABAN BENAR!' : '❌ JAWABAN SALAH!',
                  style: TextStyle(color: isCorrect ? accentGreen : accentRed, fontSize: 16, fontWeight: FontWeight.bold))),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: navyLight.withOpacity(0.5), borderRadius: BorderRadius.circular(12)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('📝 Jawaban yang benar:', style: TextStyle(color: textSecondary, fontSize: 12)),
                const SizedBox(height: 4),
                Text(soal.jawaban, style: TextStyle(color: accentYellow, fontSize: 16, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                Text('💡 Penjelasan:', style: TextStyle(color: textSecondary, fontSize: 12)),
                const SizedBox(height: 4),
                Text(soal.penjelasan, style: TextStyle(color: Colors.white70, fontSize: 13)),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(color: accentOrange.withOpacity(0.1), borderRadius: BorderRadius.circular(8)),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.star, color: accentOrange, size: 14),
                const SizedBox(width: 4),
                Text('Poin soal ini: +${soal.poin}', style: TextStyle(color: accentOrange, fontSize: 12)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons() {
    return OutlinedButton.icon(
      onPressed: _skipQuestion,
      icon: Icon(Icons.skip_next, color: accentRed, size: 18),
      label: Text('SKIP', style: TextStyle(color: accentRed)),
      style: OutlinedButton.styleFrom(
        side: BorderSide(color: accentRed.withOpacity(0.5)),
        padding: const EdgeInsets.symmetric(vertical: 12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  Widget _buildCompletionScreen() {
    return Scaffold(
      backgroundColor: navyDeep,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.emoji_events, color: accentYellow, size: 80),
            const SizedBox(height: 24),
            const Text('🎉 SELAMAT! 🎉',
                style: TextStyle(color: accentYellow, fontSize: 28, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
            const SizedBox(height: 16),
            Text('Kamu telah menyelesaikan semua ${_soalList.length} soal!', style: TextStyle(color: textSecondary, fontSize: 16)),
            const SizedBox(height: 24),
            Container(
              padding: const EdgeInsets.all(20),
              margin: const EdgeInsets.symmetric(horizontal: 40),
              decoration: BoxDecoration(color: navyLight, borderRadius: BorderRadius.circular(20)),
              child: Column(
                children: [
                  _buildResultRow('Total Soal', '${_soalList.length}', accentOrange),
                  const SizedBox(height: 8),
                  _buildResultRow('✅ Benar', '$_totalBenar', accentGreen),
                  const SizedBox(height: 8),
                  _buildResultRow('❌ Salah', '$_totalSalah', accentRed),
                  const SizedBox(height: 8),
                  _buildResultRow('⭐ Total Skor', '$_totalSkor', accentYellow),
                ],
              ),
            ),
            const SizedBox(height: 32),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton.icon(
                  onPressed: _resetGame,
                  icon: const Icon(Icons.refresh),
                  label: const Text('MAIN LAGI'),
                  style: ElevatedButton.styleFrom(backgroundColor: accentGreen, padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                ),
                const SizedBox(width: 16),
                OutlinedButton.icon(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.close),
                  label: const Text('KELUAR'),
                  style: OutlinedButton.styleFrom(side: BorderSide(color: accentOrange), padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}