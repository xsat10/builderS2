import 'dart:math';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ══════════════════════════════════════════════════════════════════════════════
//  Cloude BOT WIDGET — versi foto-style
//  Desain: badan bulat putih/abu, layar wajah hitam rounded, mata arc cyan,
//          telinga radar bulat, tangan bulat, kaki pendek, jet thruster bawah
//  Perilaku: float, kedip, mata lirik, tangan goyang, kaki goyang, jet flicker
//  Cara pakai: taruh di Stack
//  Contoh: if (_CloudeBot) AiAssistantWidget(onlineUsers: _onlineUsers)
// ══════════════════════════════════════════════════════════════════════════════

enum _BotMood { idle, happy, sad, angry, surprised, sleepy, excited }

class AiAssistantWidget extends StatefulWidget {
  final int onlineUsers;
  final int activeConnections;
  final String apiSource;
  final double initialX;
  final double initialY;
  final bool persistPosition;
  final bool embedded;
  const AiAssistantWidget({
    super.key,
    this.onlineUsers = 0,
    this.activeConnections = 0,
    this.apiSource = '',
    this.initialX = 20,
    this.initialY = 200,
    this.persistPosition = true,
    this.embedded = false,
  });

  @override
  State<AiAssistantWidget> createState() => _AiAssistantWidgetState();
}

class _AiAssistantWidgetState extends State<AiAssistantWidget>
    with TickerProviderStateMixin {

  late double _posX;
  late double _posY;

  _BotMood _mood = _BotMood.idle;
  bool _isMinimized = false;
  bool _showBubble = false;
  String _bubbleText = '';

  late AnimationController _floatCtrl;
  late AnimationController _blinkCtrl;
  late AnimationController _armCtrl;
  late AnimationController _radarCtrl;
  late AnimationController _pulseCtrl;
  late AnimationController _bubbleCtrl;
  late AnimationController _legCtrl;
  late AnimationController _eyeXCtrl;
  late AnimationController _eyeYCtrl;
  late AnimationController _jetCtrl;
  late AnimationController _shakeCtrl;

  late Animation<double> _floatAnim;
  late Animation<double> _blinkAnim;
  late Animation<double> _armAnim;
  late Animation<double> _radarAnim;
  late Animation<double> _pulseAnim;
  late Animation<double> _bubbleScaleAnim;
  late Animation<double> _legAnim;
  late Animation<double> _eyeXAnim;
  late Animation<double> _eyeYAnim;
  late Animation<double> _jetAnim;
  late Animation<double> _shakeAnim;

  final Random _rng = Random();
  bool _isBlinking = false;

  static const Map<_BotMood, List<String>> _moodMessages = {
    _BotMood.idle:      ['Scanning...', 'Cloude siap!', 'Monitoring~', 'Semua aman 👁'],
    _BotMood.happy:     ['Wih rame! 🎉', 'Traffic bagus!', 'Mantap!', 'Gas terus!'],
    _BotMood.sad:       ['Sepi banget...', 'Hiks... 😢', 'Ga ada user?', 'Lagi sepi nih'],
    _BotMood.angry:     ['KENAPA SEPI?! 😤', 'Ada masalah!', 'Investigasi!', 'TRAFFIC TURUN!'],
    _BotMood.surprised: ['BOOM! Spike!! 📈', 'WOH RAME!', 'Traffic naik!', 'Gila rame!'],
    _BotMood.sleepy:    ['Zzz... 💤', 'Ngantuk nih...', '*nguap*', 'Sepi sih...'],
    _BotMood.excited:   ['🔥 GAS GAS!', 'SEMUA ONLINE!', 'MAKSIMAL!', 'Full house!'],
  };

  @override
  void initState() {
    super.initState();
    _posX = widget.initialX;
    _posY = widget.initialY;
    _setupAnimations();
    _startBehaviorLoop();
    _updateMoodFromData();
    _loadPosition();
  }

  Future<void> _loadPosition() async {
    if (!widget.persistPosition) return;
    final prefs = await SharedPreferences.getInstance();
    if (mounted) setState(() {
      _posX = prefs.getDouble('Cloude_pos_x') ?? widget.initialX;
      _posY = prefs.getDouble('Cloude_pos_y') ?? widget.initialY;
    });
  }

  Future<void> _savePosition() async {
    if (!widget.persistPosition) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('Cloude_pos_x', _posX);
    await prefs.setDouble('Cloude_pos_y', _posY);
  }

  void _setupAnimations() {
    // Float naik turun
    _floatCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 2500))
      ..repeat(reverse: true);
    _floatAnim = Tween<double>(begin: 0, end: 7).animate(
        CurvedAnimation(parent: _floatCtrl, curve: Curves.easeInOut));

    // Kedip
    _blinkCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 120));
    _blinkAnim = Tween<double>(begin: 1.0, end: 0.04).animate(
        CurvedAnimation(parent: _blinkCtrl, curve: Curves.easeInOut));

    // Tangan goyang
    _armCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1400))
      ..repeat(reverse: true);
    _armAnim = Tween<double>(begin: -0.22, end: 0.22).animate(
        CurvedAnimation(parent: _armCtrl, curve: Curves.easeInOut));

    // Radar telinga berputar
    _radarCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800))
      ..repeat();
    _radarAnim = Tween<double>(begin: 0, end: 2 * pi).animate(_radarCtrl);

    // Pulse glow
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1100))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.3, end: 1.0).animate(
        CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    // Speech bubble
    _bubbleCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 350));
    _bubbleScaleAnim = CurvedAnimation(parent: _bubbleCtrl, curve: Curves.elasticOut);

    // Kaki goyang bergantian
    _legCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 750))
      ..repeat(reverse: true);
    _legAnim = Tween<double>(begin: -3.5, end: 3.5).animate(
        CurvedAnimation(parent: _legCtrl, curve: Curves.easeInOut));

    // Mata lirik X
    _eyeXCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 2200))
      ..repeat(reverse: true);
    _eyeXAnim = Tween<double>(begin: -3.0, end: 3.0).animate(
        CurvedAnimation(parent: _eyeXCtrl, curve: Curves.easeInOut));

    // Mata lirik Y
    _eyeYCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1900))
      ..repeat(reverse: true);
    _eyeYAnim = Tween<double>(begin: -2.0, end: 2.0).animate(
        CurvedAnimation(parent: _eyeYCtrl, curve: Curves.easeInOut));

    // Jet thruster flicker
    _jetCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 550))
      ..repeat(reverse: true);
    _jetAnim = Tween<double>(begin: 0.6, end: 1.0).animate(
        CurvedAnimation(parent: _jetCtrl, curve: Curves.easeInOut));

    // Shake
    _shakeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 480));
    _shakeAnim = Tween<double>(begin: -4, end: 4).animate(
        CurvedAnimation(parent: _shakeCtrl, curve: Curves.elasticInOut));
  }

  void _startBehaviorLoop() {
    // Kedip acak
    Future.delayed(Duration(milliseconds: 1800 + _rng.nextInt(2500)), () {
      if (!mounted) return;
      _triggerBlink();
      _startBehaviorLoop();
    });
    // Bubble acak
    Future.delayed(Duration(milliseconds: 4500 + _rng.nextInt(5500)), () {
      if (!mounted) return;
      _showRandomBubble();
    });
    // Shake sesekali
    Future.delayed(Duration(milliseconds: 6000 + _rng.nextInt(8000)), () {
      if (!mounted) return;
      _triggerShake();
    });
  }

  void _triggerBlink() async {
    if (_isBlinking || !mounted) return;
    _isBlinking = true;
    await _blinkCtrl.forward();
    await Future.delayed(const Duration(milliseconds: 50));
    await _blinkCtrl.reverse();
    _isBlinking = false;
  }

  void _triggerShake() {
    if (!mounted) return;
    _shakeCtrl.forward(from: 0).then((_) => _shakeCtrl.reverse());
  }

  void _showRandomBubble() {
    if (!mounted) return;
    final msgs = _moodMessages[_mood] ?? _moodMessages[_BotMood.idle]!;
    setState(() {
      _bubbleText = msgs[_rng.nextInt(msgs.length)];
      _showBubble = true;
    });
    _bubbleCtrl.forward(from: 0);
    Future.delayed(const Duration(milliseconds: 3600), () {
      if (!mounted) return;
      _bubbleCtrl.reverse().then((_) {
        if (mounted) setState(() => _showBubble = false);
      });
    });
  }

  void _updateMoodFromData() {
    final u = widget.onlineUsers;
    final newMood = u == 0
        ? _BotMood.sleepy
        : u < 5
            ? _BotMood.sad
            : u < 15
                ? _BotMood.idle
                : u < 30
                    ? _BotMood.happy
                    : u < 60
                        ? _BotMood.excited
                        : _BotMood.surprised;
    if (newMood != _mood && mounted) {
      setState(() => _mood = newMood);
      _showRandomBubble();
      _triggerShake();
    }
  }

  @override
  void didUpdateWidget(AiAssistantWidget old) {
    super.didUpdateWidget(old);
    if (old.onlineUsers != widget.onlineUsers) _updateMoodFromData();
  }

  @override
  void dispose() {
    for (final c in [
      _floatCtrl, _blinkCtrl, _armCtrl, _radarCtrl, _pulseCtrl,
      _bubbleCtrl, _legCtrl, _eyeXCtrl, _eyeYCtrl, _jetCtrl, _shakeCtrl,
    ]) c.dispose();
    super.dispose();
  }

  Color get _moodColor => switch (_mood) {
    _BotMood.idle      => const Color(0xFFB56CFF),
    _BotMood.happy     => const Color(0xFFD28CFF),
    _BotMood.sad       => const Color(0xFF9D7CFF),
    _BotMood.angry     => const Color(0xFFE879F9),
    _BotMood.surprised => const Color(0xFFF0ABFC),
    _BotMood.sleepy    => const Color(0xFFA78BFA),
    _BotMood.excited   => const Color(0xFFC084FC),
  };

  // ══════════════════════════════════════════════════════════════════════════
  //  BUILD
  // ══════════════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    final screen = MediaQuery.of(context).size;
    final child = GestureDetector(
      onPanUpdate: (d) => setState(() {
        _posX = (_posX + d.delta.dx).clamp(0, screen.width - 90);
        _posY = (_posY + d.delta.dy).clamp(0, screen.height - 150);
      }),
      onPanEnd: (_) => _savePosition(),
      onTap: () {
        setState(() => _isMinimized = !_isMinimized);
        if (!_isMinimized) _showRandomBubble();
      },
      onDoubleTap: () {
        _triggerShake();
        _showRandomBubble();
      },
      child: AnimatedBuilder(
        animation: Listenable.merge([_floatCtrl, _shakeCtrl]),
        builder: (_, child) => Transform.translate(
          offset: Offset(_shakeAnim.value, -_floatAnim.value),
          child: child,
        ),
        child: _isMinimized ? _buildMini() : _buildFull(),
      ),
    );

    if (widget.embedded) {
      return Align(alignment: Alignment.centerRight, child: child);
    }
    return Positioned(left: _posX, top: _posY, child: child);
  }

  // ── Mini mode ─────────────────────────────────────────────────────────────
  Widget _buildMini() {
    return AnimatedBuilder(
      animation: Listenable.merge([_blinkCtrl, _pulseCtrl, _eyeXCtrl, _eyeYCtrl]),
      builder: (_, __) => Container(
        width: 42,
        height: 42,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: const Color(0xFF8B5CF6),
          border: Border.all(color: _moodColor, width: 2.0),
          boxShadow: [
            BoxShadow(
              color: _moodColor.withOpacity(_pulseAnim.value * 0.55),
              blurRadius: 14,
              spreadRadius: 3,
            ),
          ],
        ),
        child: ClipOval(
          child: CustomPaint(
            size: const Size(42, 42),
            painter: _MiniFacePainter(
              mood: _mood,
              blinkValue: _blinkAnim.value,
              eyeColor: _moodColor,
              eyeX: _eyeXAnim.value,
              eyeY: _eyeYAnim.value,
            ),
          ),
        ),
      ),
    );
  }

  // ── Full mode ─────────────────────────────────────────────────────────────
  Widget _buildFull() {
    return SizedBox(
      width: 90,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Speech bubble
          if (_showBubble && _bubbleText.isNotEmpty)
            ScaleTransition(
              scale: _bubbleScaleAnim,
              alignment: Alignment.bottomCenter,
              child: Container(
                margin: const EdgeInsets.only(bottom: 6),
                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
                decoration: BoxDecoration(
                  color: const Color(0xFF0B0616),
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(12),
                    topRight: Radius.circular(12),
                    bottomRight: Radius.circular(12),
                    bottomLeft: Radius.circular(3),
                  ),
                  border: Border.all(color: _moodColor.withOpacity(0.6), width: 1.2),
                  boxShadow: [BoxShadow(color: _moodColor.withOpacity(0.3), blurRadius: 10)],
                ),
                child: Text(
                  _bubbleText,
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.92),
                    fontSize: 8.0,
                    fontWeight: FontWeight.w700,
                    height: 1.35,
                    letterSpacing: 0.1,
                  ),
                ),
              ),
            ),

          // Robot
          AnimatedBuilder(
            animation: Listenable.merge([
              _blinkCtrl, _armCtrl, _radarCtrl, _pulseCtrl,
              _legCtrl, _eyeXCtrl, _eyeYCtrl, _jetCtrl,
            ]),
            builder: (_, __) {
              return SizedBox(
                width: 90,
                height: 130,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    // Tangan kiri
                    Positioned(
                      left: 0,
                      top: 44,
                      child: Transform.rotate(
                        angle: -_armAnim.value,
                        alignment: Alignment.topCenter,
                        child: _buildArm(),
                      ),
                    ),
                    // Body utama
                    Positioned(
                      left: 14,
                      top: 0,
                      child: CustomPaint(
                        size: const Size(62, 130),
                        painter: _CloudeBotPainter(
                          mood: _mood,
                          blinkValue: _blinkAnim.value,
                          eyeColor: _moodColor,
                          radarAngle: _radarAnim.value,
                          pulseValue: _pulseAnim.value,
                          legValue: _legAnim.value,
                          eyeX: _eyeXAnim.value,
                          eyeY: _eyeYAnim.value,
                          jetValue: _jetAnim.value,
                        ),
                      ),
                    ),
                    // Tangan kanan
                    Positioned(
                      right: 0,
                      top: 44,
                      child: Transform.rotate(
                        angle: _armAnim.value,
                        alignment: Alignment.topCenter,
                        child: _buildArm(),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildArm() {
    // Tangan: tabung bulat putih/abu seperti foto
    return Container(
      width: 11,
      height: 30,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        gradient: const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFFD8E0E8), Color(0xFF8899A8)],
        ),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.25), blurRadius: 4, offset: const Offset(1, 2)),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          // Jari-jari kecil
          Container(
            width: 11,
            height: 8,
            decoration: BoxDecoration(
              color: const Color(0xFF32145F),
              borderRadius: BorderRadius.circular(4),
            ),
          ),
        ],
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
//  MAIN PAINTER — foto-style Cloude Bot
// ══════════════════════════════════════════════════════════════════════════════
class _CloudeBotPainter extends CustomPainter {
  final _BotMood mood;
  final double blinkValue, radarAngle, pulseValue, legValue, eyeX, eyeY, jetValue;
  final Color eyeColor;

  const _CloudeBotPainter({
    required this.mood,
    required this.blinkValue,
    required this.eyeColor,
    required this.radarAngle,
    required this.pulseValue,
    required this.legValue,
    required this.eyeX,
    required this.eyeY,
    required this.jetValue,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    _drawJet(canvas, w, h);
    _drawLegs(canvas, w, h);
    _drawBody(canvas, w, h);
    _drawNeck(canvas, w, h);
    _drawRadarEars(canvas, w, h);
    _drawHead(canvas, w, h);
    _drawFaceScreen(canvas, w, h);
    _drawEyes(canvas, w, h);
    _drawMouth(canvas, w, h);
  }

  // ── Jet thruster ──────────────────────────────────────────────────────────
  void _drawJet(Canvas canvas, double w, double h) {
    final cx = w * 0.5;
    final cy = h * 0.95;

    // Glow luar biru besar
    canvas.drawOval(
      Rect.fromCenter(center: Offset(cx, cy + 4), width: 28 * jetValue, height: 18 * jetValue),
      Paint()
        ..color = const Color(0xFFA855F7).withOpacity(0.22 * jetValue)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12),
    );
    // Core biru
    canvas.drawOval(
      Rect.fromCenter(center: Offset(cx, cy + 2), width: 16 * jetValue, height: 12 * jetValue),
      Paint()
        ..color = const Color(0xFFD8B4FE).withOpacity(0.65 * jetValue)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4),
    );
    // Center putih
    canvas.drawOval(
      Rect.fromCenter(center: Offset(cx, cy), width: 7 * jetValue, height: 5 * jetValue),
      Paint()..color = Colors.white.withOpacity(0.8 * jetValue),
    );
    // Nozzle
    final nozzleRect = RRect.fromRectAndRadius(
      Rect.fromCenter(center: Offset(cx, h * 0.905), width: 14, height: 8),
      const Radius.circular(3),
    );
    canvas.drawRRect(nozzleRect, Paint()
      ..color = const Color(0xFF24113F));
    canvas.drawRRect(nozzleRect, Paint()
      ..color = const Color(0xFFA855F7).withOpacity(0.5)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0);
  }

  // ── Kaki pendek bulat (foto style) ────────────────────────────────────────
  void _drawLegs(Canvas canvas, double w, double h) {
    // Kaki kiri naik saat kiri, kanan turun
    final leftY  = h * 0.80 + (-legValue * 0.5);
    final rightY = h * 0.80 + (legValue * 0.5);

    for (int side = 0; side < 2; side++) {
      final isLeft = side == 0;
      final cx = isLeft ? w * 0.28 : w * 0.72;
      final cy = isLeft ? leftY : rightY;

      // Betis
      final legRect = RRect.fromRectAndRadius(
        Rect.fromCenter(center: Offset(cx, cy), width: 14, height: 20),
        const Radius.circular(7),
      );
      canvas.drawRRect(legRect, Paint()
        ..shader = LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [const Color(0xFFD8B4FE), const Color(0xFF6D28D9)],
        ).createShader(Rect.fromCenter(center: Offset(cx, cy), width: 14, height: 20)));
      canvas.drawRRect(legRect, Paint()
        ..color = Colors.black.withOpacity(0.2)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.8);

      // Sendi siku di atas betis
      canvas.drawCircle(Offset(cx, cy - 10), 5.0, Paint()
        ..color = const Color(0xFFC4B5FD));
      canvas.drawCircle(Offset(cx, cy - 10), 5.0, Paint()
        ..color = Colors.black.withOpacity(0.18)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.8);

      // Sepatu/kaki bawah hitam gelap (foto style)
      final bootRect = RRect.fromRectAndRadius(
        Rect.fromCenter(center: Offset(cx, cy + 12), width: 18, height: 10),
        const Radius.circular(5),
      );
      canvas.drawRRect(bootRect, Paint()..color = const Color(0xFF24113F));
      canvas.drawRRect(bootRect, Paint()
        ..color = eyeColor.withOpacity(0.4)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.8);
      // Glow kecil di sepatu
      canvas.drawOval(
        Rect.fromCenter(center: Offset(cx, cy + 18), width: 14, height: 4),
        Paint()
          ..color = eyeColor.withOpacity(0.2 * pulseValue)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4),
      );
    }
  }

  // ── Badan bulat oval putih/abu ────────────────────────────────────────────
  void _drawBody(Canvas canvas, double w, double h) {
    final bodyRect = Rect.fromCenter(
      center: Offset(w * 0.5, h * 0.70),
      width: w * 0.82,
      height: h * 0.26,
    );

    // Glow luar
    canvas.drawOval(bodyRect.inflate(4), Paint()
      ..color = eyeColor.withOpacity(0.06 * pulseValue)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10));

    // Fill gradient putih abu (foto style)
    canvas.drawOval(bodyRect, Paint()
      ..shader = RadialGradient(
        center: const Alignment(-0.3, -0.5),
        radius: 1.1,
        colors: [const Color(0xFFD8B4FE), const Color(0xFF6D28D9)],
      ).createShader(bodyRect));

    // Shadow pinggir bawah
    canvas.drawOval(bodyRect, Paint()
      ..color = Colors.black.withOpacity(0.12)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0);

    // Highlight atas kiri (spekuler)
    canvas.drawOval(
      Rect.fromCenter(center: Offset(w * 0.35, h * 0.645), width: w * 0.30, height: h * 0.08),
      Paint()..color = Colors.white.withOpacity(0.28),
    );

    // Panel dada hitam kecil dengan indicator biru (foto)
    final panelRect = RRect.fromRectAndRadius(
      Rect.fromCenter(center: Offset(w * 0.5, h * 0.705), width: w * 0.38, height: h * 0.155),
      const Radius.circular(6),
    );
    canvas.drawRRect(panelRect, Paint()..color = const Color(0xFF18222C));
    canvas.drawRRect(panelRect, Paint()
      ..color = eyeColor.withOpacity(0.35)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0);

    // Indicator vertikal biru di tengah panel (seperti foto)
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(center: Offset(w * 0.5, h * 0.700), width: 4, height: 14),
        const Radius.circular(2),
      ),
      Paint()..color = eyeColor.withOpacity(0.75 * pulseValue),
    );
    // Glow indicator
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(center: Offset(w * 0.5, h * 0.700), width: 6, height: 16),
        const Radius.circular(3),
      ),
      Paint()
        ..color = eyeColor.withOpacity(0.3 * pulseValue)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4),
    );

    // Segmen horizontal kecil (detail badan)
    for (int i = 0; i < 2; i++) {
      canvas.drawLine(
        Offset(w * 0.20, h * 0.672 + i * h * 0.042),
        Offset(w * 0.80, h * 0.672 + i * h * 0.042),
        Paint()
          ..color = Colors.black.withOpacity(0.07)
          ..strokeWidth = 0.8,
      );
    }
  }

  // ── Leher ─────────────────────────────────────────────────────────────────
  void _drawNeck(Canvas canvas, double w, double h) {
    final neckRect = RRect.fromRectAndRadius(
      Rect.fromCenter(center: Offset(w * 0.5, h * 0.555), width: w * 0.22, height: h * 0.048),
      const Radius.circular(4),
    );
    canvas.drawRRect(neckRect, Paint()..color = const Color(0xFF24113F));
    canvas.drawRRect(neckRect, Paint()
      ..color = eyeColor.withOpacity(0.30)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0);
  }

  // ── Telinga radar bulat (foto: bulat besar dengan ring cyan) ──────────────
  void _drawRadarEars(Canvas canvas, double w, double h) {
    for (final side in [-1.0, 1.0]) {
      final cx = side < 0 ? w * 0.04 : w * 0.96;
      final cy = h * 0.185;

      // Body telinga
      canvas.drawCircle(Offset(cx, cy), 10, Paint()
        ..color = const Color(0xFFC4B5FD));
      canvas.drawCircle(Offset(cx, cy), 10, Paint()
        ..color = Colors.black.withOpacity(0.15)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5);

      // Ring luar cyan
      canvas.drawCircle(Offset(cx, cy), 9, Paint()
        ..color = eyeColor.withOpacity(0.4 * pulseValue)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.8);

      // Logo V kecil di telinga kiri (seperti foto)
      if (side < 0) {
        final vPath = Path()
          ..moveTo(cx - 3.5, cy - 3)
          ..lineTo(cx, cy + 3)
          ..lineTo(cx + 3.5, cy - 3);
        canvas.drawPath(vPath, Paint()
          ..color = eyeColor.withOpacity(0.85)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.8
          ..strokeCap = StrokeCap.round
          ..strokeJoin = StrokeJoin.round);
      }

      // Jarum radar di telinga kanan
      if (side > 0) {
        canvas.save();
        canvas.translate(cx, cy);
        canvas.rotate(radarAngle);
        canvas.drawLine(
          Offset.zero,
          const Offset(0, -5.5),
          Paint()
            ..color = eyeColor.withOpacity(0.9)
            ..strokeWidth = 1.8
            ..strokeCap = StrokeCap.round,
        );
        canvas.drawCircle(Offset.zero, 2.0, Paint()..color = eyeColor);
        canvas.restore();
      }
    }
  }

  // ── Kepala bulat besar putih (foto style) ─────────────────────────────────
  void _drawHead(Canvas canvas, double w, double h) {
    final headRect = Rect.fromCenter(
      center: Offset(w * 0.5, h * 0.255),
      width: w * 0.88,
      height: h * 0.38,
    );

    // Glow luar
    canvas.drawOval(headRect.inflate(5), Paint()
      ..color = eyeColor.withOpacity(0.07 * pulseValue)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12));

    // Fill kepala — gradient putih abu bulat
    canvas.drawOval(headRect, Paint()
      ..shader = RadialGradient(
        center: const Alignment(-0.25, -0.45),
        radius: 1.05,
        colors: [const Color(0xFFE9D5FF), const Color(0xFF8B5CF6)],
      ).createShader(headRect));

    // Shadow pinggir
    canvas.drawOval(headRect, Paint()
      ..color = Colors.black.withOpacity(0.10)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0);

    // Highlight atas
    canvas.drawOval(
      Rect.fromCenter(center: Offset(w * 0.38, h * 0.13), width: w * 0.38, height: h * 0.10),
      Paint()..color = Colors.white.withOpacity(0.30),
    );

    // Dua titik kecil dahi atas (persis foto)
    for (final dx in [-0.10, 0.10]) {
      canvas.drawCircle(
        Offset(w * (0.5 + dx), h * 0.095),
        2.2,
        Paint()..color = const Color(0xFF5B21B6),
      );
    }
  }

  // ── Layar wajah hitam rounded rect ────────────────────────────────────────
  void _drawFaceScreen(Canvas canvas, double w, double h) {
    final screenRect = RRect.fromRectAndRadius(
      Rect.fromCenter(
        center: Offset(w * 0.5, h * 0.265),
        width: w * 0.70,
        height: h * 0.295,
      ),
      const Radius.circular(16),
    );
    // Fill hitam
    canvas.drawRRect(screenRect, Paint()..color = const Color(0xFF08101A));
    // Border tipis
    canvas.drawRRect(screenRect, Paint()
      ..color = eyeColor.withOpacity(0.25)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2);
    // Highlight atas layar (glossy)
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(center: Offset(w * 0.44, h * 0.140), width: w * 0.50, height: h * 0.045),
        const Radius.circular(8),
      ),
      Paint()..color = Colors.white.withOpacity(0.07),
    );
  }

  // ── Mata arc cyan (persis foto: setengah lingkaran bawah = senyum) ────────
  void _drawEyes(Canvas canvas, double w, double h) {
    // Posisi mata: seperti foto agak ke bawah tengah layar
    final eyeCenters = [
      Offset(w * 0.335 + eyeX, h * 0.255 + eyeY),
      Offset(w * 0.665 + eyeX, h * 0.255 + eyeY),
    ];

    for (int i = 0; i < 2; i++) {
      final pos = eyeCenters[i];
      final isLeft = i == 0;

      // Glow area
      canvas.drawCircle(pos, 10, Paint()
        ..color = eyeColor.withOpacity(0.20 * pulseValue)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8));

      // Kedip: scale Y
      canvas.save();
      canvas.translate(pos.dx, pos.dy);
      canvas.scale(1.0, blinkValue);

      // Arc mata — bentuk sesuai mood
      _drawEyeArc(canvas, mood, isLeft);

      canvas.restore();
    }
  }

  void _drawEyeArc(Canvas canvas, _BotMood mood, bool isLeft) {
    final paint = Paint()
      ..color = eyeColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.8
      ..strokeCap = StrokeCap.round;

    final fillPaint = Paint()
      ..color = eyeColor.withOpacity(0.15);

    switch (mood) {
      // ── Idle / Happy / Excited: arc bawah = senyum (persis foto default)
      case _BotMood.idle:
      case _BotMood.happy:
      case _BotMood.excited:
        // Arc melengkung ke bawah (U terbalik terisi = ^)
        // Foto: mata seperti U yang tertutup (senyum menghadap bawah)
        final arcRect = Rect.fromCenter(center: Offset.zero, width: 13, height: 11);
        canvas.drawArc(arcRect, pi, pi, false, paint);
        // Isi area arc biar berpendar
        canvas.drawArc(arcRect, pi, pi, true, fillPaint);
        // Titik glow kecil di atas arc (pupil)
        canvas.drawCircle(const Offset(0, -2.5), 2.0, Paint()
          ..color = eyeColor.withOpacity(0.85));
        // Sorot
        canvas.drawCircle(const Offset(-1.5, -3.5), 1.0, Paint()
          ..color = Colors.white.withOpacity(0.9));
        break;

      // ── Sad: arc ke atas (cemberut atas = sedih)
      case _BotMood.sad:
        final arcRect = Rect.fromCenter(center: const Offset(0, 3), width: 13, height: 10);
        canvas.drawArc(arcRect, 0, pi, false, paint);
        canvas.drawArc(arcRect, 0, pi, true, fillPaint);
        canvas.drawCircle(const Offset(0, 0), 1.8, Paint()
          ..color = eyeColor.withOpacity(0.7));
        break;

      // ── Angry: garis diagonal tajam
      case _BotMood.angry:
        final slope = isLeft ? -1.5 : 1.5;
        canvas.drawLine(
          Offset(-6, slope > 0 ? -3 : 3),
          Offset(6, slope > 0 ? 3 : -3),
          paint..strokeWidth = 3.0,
        );
        canvas.drawCircle(Offset.zero, 2.5, Paint()
          ..color = eyeColor.withOpacity(0.85));
        break;

      // ── Surprised: lingkaran penuh besar
      case _BotMood.surprised:
        canvas.drawCircle(Offset.zero, 7, Paint()
          ..color = eyeColor.withOpacity(0.25));
        canvas.drawCircle(Offset.zero, 7, paint..strokeWidth = 2.5);
        canvas.drawCircle(Offset.zero, 3.5, Paint()..color = eyeColor);
        canvas.drawCircle(const Offset(-2, -2), 1.5, Paint()
          ..color = Colors.white.withOpacity(0.9));
        break;

      // ── Sleepy: setengah lingkaran kecil tertutup (mata ngantuk)
      case _BotMood.sleepy:
        final arcRect = Rect.fromCenter(center: Offset.zero, width: 12, height: 7);
        canvas.drawArc(arcRect, pi, pi, false, paint..strokeWidth = 2.5);
        // Garis kelopak bawah
        canvas.drawLine(const Offset(-6, 0), const Offset(6, 0), paint..strokeWidth = 2.0);
        break;
    }
  }

  // ── Mulut ekspresif (di bawah layar) ──────────────────────────────────────
  void _drawMouth(Canvas canvas, double w, double h) {
    final cx = w * 0.5;
    final my = h * 0.360;
    final mp = Paint()
      ..color = eyeColor
      ..strokeWidth = 2.2
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;

    final path = Path();
    switch (mood) {
      case _BotMood.happy:
      case _BotMood.excited:
        // Senyum lebar + 3 gigi
        path.moveTo(cx - 10, my - 2);
        path.quadraticBezierTo(cx, my + 8, cx + 10, my - 2);
        canvas.drawPath(path, mp);
        final gigiPaint = Paint()
          ..color = Colors.white.withOpacity(0.55)
          ..style = PaintingStyle.fill;
        for (int i = 0; i < 3; i++) {
          canvas.drawRRect(
            RRect.fromRectAndRadius(
              Rect.fromLTWH(cx - 7.5 + i * 6.0, my, 4.5, 4.5),
              const Radius.circular(1.5),
            ),
            gigiPaint,
          );
        }
        return;

      case _BotMood.sad:
        path.moveTo(cx - 9, my + 5);
        path.quadraticBezierTo(cx, my - 2, cx + 9, my + 5);
        // Air mata kiri
        canvas.drawOval(
          Rect.fromCenter(center: Offset(cx - 15, my - 8), width: 4, height: 5),
          Paint()..color = const Color(0xFF7ECFFF).withOpacity(0.7),
        );
        break;

      case _BotMood.angry:
        path.moveTo(cx - 9, my + 2);
        path.lineTo(cx + 9, my + 2);
        // Gigi taring
        final fangPaint = Paint()
          ..color = eyeColor.withOpacity(0.75)
          ..style = PaintingStyle.fill;
        for (int i = 0; i < 4; i++) {
          canvas.drawPath(
            Path()
              ..moveTo(cx - 7 + i * 4.8, my + 1)
              ..lineTo(cx - 5 + i * 4.8, my + 5)
              ..lineTo(cx - 3 + i * 4.8, my + 1)
              ..close(),
            fangPaint,
          );
        }
        break;

      case _BotMood.surprised:
        canvas.drawOval(
          Rect.fromCenter(center: Offset(cx, my + 1), width: 13, height: 10),
          mp,
        );
        return;

      case _BotMood.sleepy:
        path.moveTo(cx - 7, my + 1);
        path.lineTo(cx + 7, my + 1);
        // Zzz kecil
        _drawZzz(canvas, Offset(cx + 11, my - 8), eyeColor);
        break;

      default:
        // Idle: senyum kecil
        path.moveTo(cx - 8, my - 1);
        path.quadraticBezierTo(cx, my + 5, cx + 8, my - 1);
    }
    canvas.drawPath(path, mp);
  }

  void _drawZzz(Canvas canvas, Offset start, Color c) {
    final p = Paint()
      ..color = c.withOpacity(0.75)
      ..strokeWidth = 1.4
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    canvas.drawPath(
      Path()
        ..moveTo(start.dx, start.dy)
        ..lineTo(start.dx + 5.5, start.dy)
        ..lineTo(start.dx, start.dy + 4.5)
        ..lineTo(start.dx + 5.5, start.dy + 4.5),
      p,
    );
    final p2 = Paint()
      ..color = c.withOpacity(0.45)
      ..strokeWidth = 1.1
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    canvas.drawPath(
      Path()
        ..moveTo(start.dx + 6, start.dy - 5)
        ..lineTo(start.dx + 10, start.dy - 5)
        ..lineTo(start.dx + 6, start.dy - 1.5)
        ..lineTo(start.dx + 10, start.dy - 1.5),
      p2,
    );
  }

  @override
  bool shouldRepaint(covariant _CloudeBotPainter old) => true;
}

// ══════════════════════════════════════════════════════════════════════════════
//  MINI FACE PAINTER
// ══════════════════════════════════════════════════════════════════════════════
class _MiniFacePainter extends CustomPainter {
  final _BotMood mood;
  final double blinkValue, eyeX, eyeY;
  final Color eyeColor;

  const _MiniFacePainter({
    required this.mood,
    required this.blinkValue,
    required this.eyeColor,
    required this.eyeX,
    required this.eyeY,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width / 2;
    final cy = size.height / 2;

    // Background layar mini
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(center: Offset(cx, cy - 1), width: size.width * 0.72, height: size.height * 0.58),
        const Radius.circular(6),
      ),
      Paint()..color = const Color(0xFF08101A),
    );

    // Mata mini — arc style
    for (final dx in [-5.5, 5.5]) {
      canvas.save();
      canvas.translate(cx + dx + eyeX * 0.2, cy - 3 + eyeY * 0.2);
      canvas.scale(1.0, blinkValue);
      final arcRect = Rect.fromCenter(center: Offset.zero, width: 8, height: 7);
      canvas.drawArc(arcRect, pi, pi, false, Paint()
        ..color = eyeColor
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.0
        ..strokeCap = StrokeCap.round);
      canvas.drawArc(arcRect, pi, pi, true, Paint()
        ..color = eyeColor.withOpacity(0.15));
      canvas.restore();
    }

    // Mulut mini
    final mp = Paint()
      ..color = eyeColor
      ..strokeWidth = 1.6
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;
    final path = Path();
    if (mood == _BotMood.happy || mood == _BotMood.excited) {
      path.moveTo(cx - 5, cy + 4);
      path.quadraticBezierTo(cx, cy + 8, cx + 5, cy + 4);
    } else if (mood == _BotMood.sad || mood == _BotMood.angry) {
      path.moveTo(cx - 5, cy + 7);
      path.quadraticBezierTo(cx, cy + 3, cx + 5, cy + 7);
    } else {
      path.moveTo(cx - 4.5, cy + 5);
      path.lineTo(cx + 4.5, cy + 5);
    }
    canvas.drawPath(path, mp);
  }

  @override
  bool shouldRepaint(covariant _MiniFacePainter old) => true;
}
