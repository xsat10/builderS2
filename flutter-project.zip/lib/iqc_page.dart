import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// Dark Purple Theme Colors
const Color purpleDeep = Color(0xFF0A0618);
const Color purpleDark = Color(0xFF1A0B2E);
const Color purpleMedium = Color(0xFF3D1F6E);
const Color purpleLight = Color(0xFF6B3FA0);
const Color purpleGlow = Color(0xFF8B5CF6);
const Color purpleSoft = Color(0xFFA78BFA);
const Color glowPurple = Color(0xFF7C3AED);
const Color glowPink = Color(0xFFEC4899);
const Color goldPremium = Color(0xFFFBBF24);
const Color goldLight = Color(0xFFFCD34D);
const Color textSecondary = Color(0xFFC4B5FD);
const Color successGreen = Color(0xFF10B981);

class IQCPage extends StatefulWidget {
  final String sessionKey;

  const IQCPage({super.key, required this.sessionKey});

  @override
  State<IQCPage> createState() => _IQCPageState();
}

class _IQCPageState extends State<IQCPage> with TickerProviderStateMixin {
  final TextEditingController _timeController = TextEditingController();
  final TextEditingController _batteryController = TextEditingController();
  final TextEditingController _carrierController = TextEditingController();
  final TextEditingController _messageController = TextEditingController();

  bool _isLoading = false;
  Uint8List? _imageBytes;
  String? _errorMessage;

  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;
  late AnimationController _glowController;
  late Animation<double> _glowAnimation;
  late AnimationController _premiumGlowController;
  late Animation<double> _premiumGlowAnimation;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
    _pulseAnimation = Tween<double>(begin: 0.95, end: 1.05).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2500),
    )..repeat(reverse: true);
    _glowAnimation = Tween<double>(begin: 0.2, end: 0.7).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );

    _premiumGlowController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 3000),
    )..repeat(reverse: true);
    _premiumGlowAnimation = Tween<double>(begin: 0.4, end: 0.9).animate(
      CurvedAnimation(parent: _premiumGlowController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _timeController.dispose();
    _batteryController.dispose();
    _carrierController.dispose();
    _messageController.dispose();
    _pulseController.dispose();
    _glowController.dispose();
    _premiumGlowController.dispose();
    super.dispose();
  }

  Future<void> _generateImage() async {
    final time = _timeController.text.trim();
    final battery = _batteryController.text.trim();
    final carrier = _carrierController.text.trim();
    final message = _messageController.text.trim();

    if (time.isEmpty || battery.isEmpty || carrier.isEmpty || message.isEmpty) {
      setState(() {
        _errorMessage = '⚠️ Semua field harus diisi!';
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _imageBytes = null;
    });

    try {
      final encodedMessage = Uri.encodeComponent(message);
      final url = 'https://brat.siputzx.my.id/iphone-quoted'
          '?time=${Uri.encodeComponent(time)}'
          '&batteryPercentage=$battery'
          '&carrierName=${Uri.encodeComponent(carrier)}'
          '&messageText=$encodedMessage'
          '&emojiStyle=apple';

      final response = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        setState(() {
          _imageBytes = response.bodyBytes;
          _isLoading = false;
        });
      } else {
        throw Exception('API error: ${response.statusCode}');
      }
    } catch (e) {
      setState(() {
        _errorMessage = '❌ Gagal memuat gambar: ${e.toString()}';
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: purpleDeep,
      appBar: _buildPremiumAppBar(),
      body: Stack(
        children: [
          _buildBackgroundGlows(),
          SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildHeaderCard(),
                const SizedBox(height: 24),
                _buildInputForm(),
                const SizedBox(height: 24),
                _buildGenerateButton(),
                if (_errorMessage != null) _buildErrorMessage(),
                if (_imageBytes != null) _buildResultImage(),
                const SizedBox(height: 24),
                _buildPremiumFooter(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildPremiumAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      leading: Container(
        margin: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [purpleMedium.withOpacity(0.3), glowPurple.withOpacity(0.2)],
          ),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: glowPurple.withOpacity(0.3), width: 1.5),
          boxShadow: [
            BoxShadow(
              color: glowPurple.withOpacity(0.15),
              blurRadius: 15,
              spreadRadius: 0,
            ),
          ],
        ),
        child: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 16),
          onPressed: () => Navigator.pop(context),
          padding: EdgeInsets.zero,
        ),
      ),
      title: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [glowPurple, glowPink],
              ),
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: glowPurple.withOpacity(0.4),
                  blurRadius: 20,
                  spreadRadius: 0,
                ),
              ],
            ),
            child: const Icon(Icons.phone_android, color: Colors.white, size: 20),
          ),
          const SizedBox(width: 12),
          ShaderMask(
            shaderCallback: (bounds) => const LinearGradient(
              colors: [glowPurple, glowPink],
            ).createShader(bounds),
            child: Text(
              'IQC MAKER',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
                fontFamily: 'Rajdhani',
                letterSpacing: 1.5,
              ),
            ),
          ),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [goldPremium, goldLight],
              ),
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: goldPremium.withOpacity(0.3),
                  blurRadius: 10,
                  spreadRadius: 0,
                ),
              ],
            ),
            child: Text(
              'PREMIUM',
              style: TextStyle(
                color: Colors.black,
                fontSize: 8,
                fontWeight: FontWeight.bold,
                fontFamily: 'Rajdhani',
                letterSpacing: 0.5,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBackgroundGlows() {
    return Stack(
      children: [
        Positioned(
          top: -150,
          right: -100,
          child: AnimatedBuilder(
            animation: _glowAnimation,
            builder: (context, child) {
              return Container(
                width: 400,
                height: 400,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      glowPurple.withOpacity(_glowAnimation.value),
                      Colors.transparent,
                    ],
                  ),
                ),
              );
            },
          ),
        ),
        Positioned(
          bottom: -100,
          left: -100,
          child: AnimatedBuilder(
            animation: _glowAnimation,
            builder: (context, child) {
              return Container(
                width: 300,
                height: 300,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      glowPink.withOpacity(_glowAnimation.value * 0.4),
                      Colors.transparent,
                    ],
                  ),
                ),
              );
            },
          ),
        ),
        Positioned(
          top: 200,
          left: -80,
          child: AnimatedBuilder(
            animation: _premiumGlowAnimation,
            builder: (context, child) {
              return Container(
                width: 200,
                height: 200,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      goldPremium.withOpacity(_premiumGlowAnimation.value * 0.2),
                      Colors.transparent,
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildHeaderCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            purpleDark.withOpacity(0.8),
            purpleMedium.withOpacity(0.4),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: glowPurple.withOpacity(0.2),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: glowPurple.withOpacity(0.15),
            blurRadius: 30,
            spreadRadius: 0,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              ShaderMask(
                shaderCallback: (bounds) => const LinearGradient(
                  colors: [glowPurple, glowPink],
                ).createShader(bounds),
                child: Text(
                  'iPhone Quote Creator',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Rajdhani',
                  ),
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [goldPremium, goldLight],
                  ),
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: goldPremium.withOpacity(0.3),
                      blurRadius: 15,
                      spreadRadius: 0,
                    ),
                  ],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: const [
                    Icon(Icons.star, color: Colors.black, size: 12),
                    SizedBox(width: 4),
                    Text(
                      'PRO',
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Rajdhani',
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: purpleDeep.withOpacity(0.3),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: glowPurple.withOpacity(0.1),
              ),
            ),
            child: Row(
              children: [
                Icon(Icons.info_outline, color: textSecondary, size: 16),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Buat gambar kutipan aesthetic dengan tampilan iPhone premium',
                    style: TextStyle(
                      color: textSecondary.withOpacity(0.8),
                      fontSize: 13,
                      fontFamily: 'Rajdhani',
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInputForm() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            purpleDark.withOpacity(0.6),
            purpleMedium.withOpacity(0.2),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: glowPurple.withOpacity(0.15),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: glowPurple.withOpacity(0.08),
            blurRadius: 30,
            spreadRadius: 0,
          ),
        ],
      ),
      child: Column(
        children: [
          _buildInputField(
            controller: _timeController,
            label: 'Waktu (Jam)',
            hint: 'Contoh: 18:00',
            icon: Icons.access_time,
            keyboardType: TextInputType.datetime,
          ),
          const SizedBox(height: 16),
          _buildInputField(
            controller: _batteryController,
            label: 'Baterai (%)',
            hint: 'Contoh: 40',
            icon: Icons.battery_std,
            keyboardType: TextInputType.number,
          ),
          const SizedBox(height: 16),
          _buildInputField(
            controller: _carrierController,
            label: 'Nama Operator',
            hint: 'Contoh: Indosat',
            icon: Icons.signal_cellular_alt,
          ),
          const SizedBox(height: 16),
          _buildInputField(
            controller: _messageController,
            label: 'Pesan',
            hint: 'Tulis pesan di sini...',
            icon: Icons.message,
            maxLines: 3,
          ),
        ],
      ),
    );
  }

  Widget _buildInputField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
    TextInputType keyboardType = TextInputType.text,
    int maxLines = 1,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            color: textSecondary.withOpacity(0.9),
            fontSize: 12,
            fontWeight: FontWeight.w600,
            fontFamily: 'Rajdhani',
          ),
        ),
        const SizedBox(height: 6),
        Container(
          decoration: BoxDecoration(
            color: purpleDeep.withOpacity(0.5),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: glowPurple.withOpacity(0.15),
              width: 1,
            ),
          ),
          child: TextField(
            controller: controller,
            keyboardType: keyboardType,
            maxLines: maxLines,
            style: TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontFamily: 'Rajdhani',
            ),
            cursorColor: glowPurple,
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: TextStyle(
                color: textSecondary.withOpacity(0.3),
                fontSize: 13,
                fontFamily: 'Rajdhani',
              ),
              prefixIcon: Container(
                margin: const EdgeInsets.all(12),
                child: Icon(
                  icon,
                  color: glowPurple.withOpacity(0.7),
                  size: 18,
                ),
              ),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 14,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildGenerateButton() {
    return AnimatedBuilder(
      animation: _pulseAnimation,
      builder: (context, child) {
        return Transform.scale(
          scale: _isLoading ? 1.0 : _pulseAnimation.value,
          child: Container(
            width: double.infinity,
            height: 56,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: _isLoading
                    ? [purpleDark, purpleMedium]
                    : [glowPurple, glowPink],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(18),
              boxShadow: [
                BoxShadow(
                  color: glowPurple.withOpacity(0.4),
                  blurRadius: 30,
                  spreadRadius: 0,
                ),
                BoxShadow(
                  color: glowPink.withOpacity(0.2),
                  blurRadius: 20,
                  spreadRadius: 0,
                ),
              ],
            ),
            child: ElevatedButton(
              onPressed: _isLoading ? null : _generateImage,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                shadowColor: Colors.transparent,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(18),
                ),
              ),
              child: _isLoading
                  ? Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SizedBox(
                          width: 22,
                          height: 22,
                          child: CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 2.5,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Text(
                          'MEMPROSES...',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Rajdhani',
                            letterSpacing: 1.5,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    )
                  : Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        Icon(Icons.auto_awesome, color: Colors.white, size: 20),
                        SizedBox(width: 12),
                        Text(
                          'BUAT GAMBAR',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Rajdhani',
                            letterSpacing: 1.5,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildErrorMessage() {
    return Container(
      margin: const EdgeInsets.only(top: 16),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Colors.red.withOpacity(0.15),
            Colors.red.withOpacity(0.05),
          ],
        ),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: Colors.red.withOpacity(0.2),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.red.withOpacity(0.2),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(Icons.error_outline, color: Colors.red, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              _errorMessage!,
              style: TextStyle(
                color: Colors.white70,
                fontSize: 13,
                fontFamily: 'Rajdhani',
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildResultImage() {
    return Container(
      margin: const EdgeInsets.only(top: 24),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            purpleDark.withOpacity(0.7),
            purpleMedium.withOpacity(0.3),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: glowPurple.withOpacity(0.2),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: glowPurple.withOpacity(0.15),
            blurRadius: 40,
            spreadRadius: 0,
          ),
        ],
      ),
      child: Column(
        children: [
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: glowPurple.withOpacity(0.3),
                  blurRadius: 30,
                  spreadRadius: 5,
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: Image.memory(
                _imageBytes!,
                fit: BoxFit.contain,
                width: double.infinity,
              ),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: _buildActionButton(
                  icon: Icons.download,
                  label: 'DOWNLOAD',
                  color: successGreen,
                  onTap: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Row(
                          children: const [
                            Icon(Icons.check_circle, color: Colors.white, size: 20),
                            SizedBox(width: 12),
                            Text('✨ Gambar siap diunduh!'),
                          ],
                        ),
                        backgroundColor: successGreen,
                        behavior: SnackBarBehavior.floating,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        duration: const Duration(seconds: 2),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildActionButton(
                  icon: Icons.share,
                  label: 'SHARE',
                  color: glowPurple,
                  onTap: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Row(
                          children: const [
                            Icon(Icons.share, color: Colors.white, size: 20),
                            SizedBox(width: 12),
                            Text('📤 Fitur share segera hadir!'),
                          ],
                        ),
                        backgroundColor: glowPurple,
                        behavior: SnackBarBehavior.floating,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        duration: const Duration(seconds: 2),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildActionButton(
                  icon: Icons.copy,
                  label: 'COPY',
                  color: goldPremium,
                  onTap: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Row(
                          children: const [
                            Icon(Icons.content_copy, color: Colors.white, size: 20),
                            SizedBox(width: 12),
                            Text('📋 Gambar disalin!'),
                          ],
                        ),
                        backgroundColor: goldPremium,
                        behavior: SnackBarBehavior.floating,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        duration: const Duration(seconds: 2),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildActionButton({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        height: 40,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              color.withOpacity(0.15),
              color.withOpacity(0.05),
            ],
          ),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: color.withOpacity(0.2),
            width: 1,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              color: color,
              size: 16,
            ),
            const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                color: color,
                fontSize: 10,
                fontWeight: FontWeight.bold,
                fontFamily: 'Rajdhani',
                letterSpacing: 0.5,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPremiumFooter() {
    return Center(
      child: AnimatedBuilder(
        animation: _premiumGlowAnimation,
        builder: (context, child) {
          return Column(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      goldPremium.withOpacity(0.1),
                      glowPurple.withOpacity(0.1),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: goldPremium.withOpacity(0.1),
                  ),
                ),
                child: ShaderMask(
                  shaderCallback: (bounds) => LinearGradient(
                    colors: [
                      goldPremium.withOpacity(_premiumGlowAnimation.value),
                      glowPurple.withOpacity(_premiumGlowAnimation.value),
                    ],
                  ).createShader(bounds),
                  child: Text(
                    '✦ PREMIUM EDITION ✦',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Rajdhani',
                      letterSpacing: 2,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 6),
              Text(
                'IQC Maker • Dark Purple Premium',
                style: TextStyle(
                  color: textSecondary.withOpacity(0.2),
                  fontSize: 10,
                  fontFamily: 'Rajdhani',
                  letterSpacing: 1,
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}