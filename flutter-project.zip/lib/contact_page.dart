import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

class ContactPage extends StatelessWidget {
  const ContactPage({super.key});

  // ─── 🏁 BMW M GARAGE PALETTE ──────────────────────────────
  static const Color garageBlack   = Color(0xFF0A0A0A);
  static const Color carbonDark    = Color(0xFF121212);
  static const Color cardColor     = Color(0xFF1A1A1A);
  static const Color surfaceColor  = Color(0xFF202020);
  static const Color chromeSilver  = Color(0xFFC8C8C8);
  static const Color bmwLightBlue  = Color(0xFF0066B1);
  static const Color bmwDarkBlue   = Color(0xFF0F3D77);
  static const Color bmwRed        = Color(0xFFE32119);
  static const Color bmwBlueGlow   = Color(0xFF1C69D4);
  static const Color textPrimary   = Color(0xFFF5F5F5);
  static const Color textSecondary = Color(0xFF9E9E9E);

  Future<void> _launchUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception('Could not launch $url');
    }
  }

  // 🏁 M-Stripe Widget
  Widget _mStripe({double height = 3, double width = 40}) {
    return Container(
      height: height,
      width: width,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(2),
        gradient: const LinearGradient(
          colors: [bmwLightBlue, bmwDarkBlue, bmwRed],
          stops: [0.0, 0.5, 1.0],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: garageBlack,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: carbonDark.withOpacity(0.85),
        elevation: 0,
        leading: IconButton(
          icon: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: cardColor.withOpacity(0.6),
              shape: BoxShape.circle,
              border: Border.all(
                color: chromeSilver.withOpacity(0.25),
                width: 1,
              ),
            ),
            child: const Icon(
              Icons.arrow_back_ios_new,
              color: chromeSilver,
              size: 14,
            ),
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: Column(
          children: [
            const Text(
              "PIT CREW",
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontFamily: 'Orbitron',
                fontSize: 15,
                letterSpacing: 3,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              "CONTACT & SUPPORT",
              style: TextStyle(
                color: chromeSilver.withOpacity(0.6),
                fontSize: 9,
                letterSpacing: 3,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ],
        ),
        centerTitle: true,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(3),
          child: _mStripe(height: 3, width: double.infinity),
        ),
      ),
      body: Stack(
        children: [
          // ─── CARBON BACKGROUND ───
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [carbonDark, garageBlack, Color(0xFF050505)],
                ),
              ),
            ),
          ),

          // ─── BLUE HEADLIGHT GLOW ───
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: const Alignment(-0.8, -0.7),
                  radius: 1.4,
                  colors: [
                    bmwBlueGlow.withOpacity(0.12),
                    Colors.transparent,
                  ],
                  stops: const [0.0, 1.0],
                ),
              ),
            ),
          ),

          // ─── RED TAIL-LIGHT GLOW ───
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: const Alignment(1.0, 1.0),
                  radius: 1.2,
                  colors: [
                    bmwRed.withOpacity(0.08),
                    Colors.transparent,
                  ],
                  stops: const [0.0, 1.0],
                ),
              ),
            ),
          ),

          // ─── CARBON GRID ───
          Positioned.fill(
            child: CustomPaint(painter: _GridPatternPainter()),
          ),

          // ─── CONTENT ───
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(24),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 500),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // ─── TOP TELEMETRY BADGE ───
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 7),
                        decoration: BoxDecoration(
                          color: cardColor.withOpacity(0.7),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: chromeSilver.withOpacity(0.2),
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              width: 7,
                              height: 7,
                              decoration: BoxDecoration(
                                color: bmwBlueGlow,
                                shape: BoxShape.circle,
                                boxShadow: [
                                  BoxShadow(
                                    color: bmwBlueGlow.withOpacity(0.8),
                                    blurRadius: 8,
                                    spreadRadius: 1,
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 8),
                            Text(
                              "SUPPORT CHANNEL · ONLINE",
                              style: TextStyle(
                                color: chromeSilver.withOpacity(0.8),
                                fontSize: 9,
                                letterSpacing: 2,
                                fontFamily: 'ShareTechMono',
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 28),

                      // ─── HERO ICON (ROUNDEL STYLE) ───
                      Container(
                        width: 110,
                        height: 110,
                        padding: const EdgeInsets.all(3),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: const LinearGradient(
                            colors: [bmwLightBlue, bmwDarkBlue, bmwRed],
                            stops: [0.0, 0.5, 1.0],
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: bmwBlueGlow.withOpacity(0.5),
                              blurRadius: 30,
                              spreadRadius: 4,
                            ),
                            BoxShadow(
                              color: bmwRed.withOpacity(0.2),
                              blurRadius: 40,
                              spreadRadius: 2,
                            ),
                          ],
                        ),
                        child: Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: garageBlack,
                            border: Border.all(
                              color: chromeSilver.withOpacity(0.4),
                              width: 1,
                            ),
                          ),
                          child: const Center(
                            child: Icon(
                              Icons.support_agent_rounded,
                              size: 48,
                              color: chromeSilver,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 28),

                      // ─── TITLE ───
                      ShaderMask(
                        shaderCallback: (bounds) => const LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Color(0xFFFFFFFF),
                            Color(0xFFC8C8C8),
                            Color(0xFF7A7A7A),
                          ],
                          stops: [0.0, 0.5, 1.0],
                        ).createShader(bounds),
                        child: const Text(
                          "NEED ASSISTANCE?",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 22,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Orbitron',
                            letterSpacing: 3,
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      _mStripe(height: 3, width: 80),
                      const SizedBox(height: 12),
                      Text(
                        "Contact our crew through the channels below",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: chromeSilver.withOpacity(0.7),
                          fontSize: 11,
                          letterSpacing: 1.5,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                      const SizedBox(height: 40),

                      // ─── CONTACT BUTTONS ───
                      _buildContactButton(
                        label: "Telegram Developer",
                        subtitle: "Direct support via Telegram",
                        icon: FontAwesomeIcons.telegram,
                        color: const Color(0xFF29A9EB),
                        url: "https://t.me/Skylinnereal",
                      ),
                      const SizedBox(height: 14),
                      _buildContactButton(
                        label: "TikTok Developer",
                        subtitle: "Latest updates & tutorials",
                        icon: FontAwesomeIcons.tiktok,
                        color: Colors.white,
                        url: "https://www.tiktok.com/@ghost.crasher",
                      ),
                      const SizedBox(height: 14),
                      _buildContactButton(
                        label: "YouTube Developer",
                        subtitle: "Video documentation",
                        icon: FontAwesomeIcons.youtube,
                        color: const Color(0xFFFF0000),
                        url: "https://youtube.com/@skylinne18",
                      ),
                      const SizedBox(height: 14),
                      _buildContactButton(
                        label: "Information Channel",
                        subtitle: "Announcements & news",
                        icon: FontAwesomeIcons.bullhorn,
                        color: const Color(0xFF1C69D4),
                        url: "https://t.me/ghostcrasher18",
                      ),

                      const SizedBox(height: 32),

                      // ─── FOOTER ───
                      _mStripe(height: 2, width: 140),
                      const SizedBox(height: 16),
                      Text(
                        "© 2026 GHOSTCRASHER · ///M DIVISION",
                        style: TextStyle(
                          color: textSecondary.withOpacity(0.7),
                          fontSize: 10,
                          letterSpacing: 1.5,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContactButton({
    required String label,
    required String subtitle,
    required IconData icon,
    required Color color,
    required String url,
  }) {
    return InkWell(
      onTap: () => _launchUrl(url),
      borderRadius: BorderRadius.circular(14),
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              cardColor.withOpacity(0.85),
              carbonDark.withOpacity(0.95),
            ],
          ),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: chromeSilver.withOpacity(0.15),
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.5),
              blurRadius: 15,
              offset: const Offset(0, 4),
            ),
            BoxShadow(
              color: color.withOpacity(0.08),
              blurRadius: 20,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Stack(
          children: [
            // Left M-stripe accent
            Positioned(
              left: 0,
              top: 0,
              bottom: 0,
              child: Container(
                width: 4,
                decoration: const BoxDecoration(
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(14),
                    bottomLeft: Radius.circular(14),
                  ),
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [bmwLightBlue, bmwDarkBlue, bmwRed],
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 16, 16),
              child: Row(
                children: [
                  // Icon container
                  Container(
                    width: 46,
                    height: 46,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: garageBlack,
                      border: Border.all(
                        color: color.withOpacity(0.5),
                        width: 1.5,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: color.withOpacity(0.3),
                          blurRadius: 12,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                    child: Center(
                      child: FaIcon(icon, color: color, size: 20),
                    ),
                  ),
                  const SizedBox(width: 16),

                  // Text
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          label,
                          style: const TextStyle(
                            color: textPrimary,
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron',
                            letterSpacing: 0.5,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          subtitle,
                          style: TextStyle(
                            color: chromeSilver.withOpacity(0.6),
                            fontSize: 10,
                            letterSpacing: 1,
                            fontFamily: 'ShareTechMono',
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Arrow
                  Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: cardColor.withOpacity(0.6),
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: chromeSilver.withOpacity(0.2),
                        width: 1,
                      ),
                    ),
                    child: Icon(
                      Icons.arrow_forward_ios,
                      color: chromeSilver.withOpacity(0.8),
                      size: 12,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── CARBON GRID PAINTER ───────────────────────────────────────────────────
class _GridPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF1C69D4).withOpacity(0.04)
      ..strokeWidth = 0.5
      ..style = PaintingStyle.stroke;

    const double spacing = 50;
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}