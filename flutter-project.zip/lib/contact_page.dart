import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter/services.dart';
import 'change_password_page.dart';

// ═══════════════════════════════════════════════════════════════════════════════
// COMIX 3D PALETTE
// ═══════════════════════════════════════════════════════════════════════════════
const Color comixBg       = Color(0xFFFFF8E7);
const Color comixInk      = Color(0xFF1A1A2E);
const Color comixWhite    = Colors.white;
const Color comixRed      = Color(0xFFFF3B30);
const Color comixBlue     = Color(0xFF007AFF);
const Color comixYellow   = Color(0xFFFFD600);
const Color comixGreen    = Color(0xFF34C759);
const Color comixPurple   = Color(0xFFAF52DE);
const Color comixOrange   = Color(0xFFFF9500);
const Color comixPink     = Color(0xFFFF2D8D);
const Color comixCyan     = Color(0xFF32ADE6);
const Color comixTextSub  = Color(0xFF4B5563);
const Color comixTextDim  = Color(0xFF6B7280);

// legacy aliases
class _C {
  static const bg        = comixBg;
  static const surface   = Colors.white;
  static const card      = Colors.white;
  static const cardInner = Colors.white;
  static const border    = comixInk;
  static const borderLit = comixInk;
  static const steel     = comixBlue;
  static const blueMid   = comixBlue;
  static const blueLight = comixBlue;
  static const chrome    = comixCyan;
  static const frost     = comixCyan;
  static const red       = comixRed;
  static const amber     = comixOrange;
  static const green     = comixGreen;
  static const purple    = comixPurple;
  static const pink      = comixPink;
  static const teal      = comixCyan;
  static const blue      = comixBlue;
  static const text      = comixInk;
  static const textSub   = comixTextSub;
  static const textDim   = comixTextDim;
  static const white     = Colors.white;
}

// ═══════════════════════════════════════════════════════════════════════════════
// COMIX REUSABLE WIDGETS
// ═══════════════════════════════════════════════════════════════════════════════
class ComixPanel extends StatelessWidget {
  final Widget child;
  final Color bgColor;
  final Color shadowColor;
  final double borderWidth;
  final double shadowOffset;
  final BorderRadius radius;
  final EdgeInsets padding;

  const ComixPanel({
    Key? key,
    required this.child,
    this.bgColor = Colors.white,
    this.shadowColor = comixInk,
    this.borderWidth = 3,
    this.shadowOffset = 6,
    this.radius = const BorderRadius.all(Radius.circular(20)),
    this.padding = const EdgeInsets.all(16),
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: radius,
        boxShadow: [
          BoxShadow(
            color: shadowColor,
            offset: Offset(shadowOffset, shadowOffset),
            blurRadius: 0,
          ),
        ],
      ),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: radius,
          border: Border.all(color: comixInk, width: borderWidth),
        ),
        child: child,
      ),
    );
  }
}

class ComixChip extends StatelessWidget {
  final Widget child;
  final Color bgColor;
  const ComixChip({Key? key, required this.child, this.bgColor = comixYellow})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: comixInk, width: 2.5),
        boxShadow: const [
          BoxShadow(color: comixInk, offset: Offset(2.5, 2.5), blurRadius: 0),
        ],
      ),
      child: child,
    );
  }
}

class _HalftonePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = comixInk.withOpacity(0.07);
    const spacing = 16.0;
    for (double y = 0; y < size.height; y += spacing) {
      for (double x = 0; x < size.width; x += spacing) {
        canvas.drawCircle(Offset(x, y), 1.5, paint);
      }
    }
  }
  @override
  bool shouldRepaint(covariant CustomPainter _) => false;
}

class _SpeedLinesPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = comixInk.withOpacity(0.035)
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;
    final center = Offset(size.width / 2, size.height / 2);
    const count = 16;
    for (int i = 0; i < count; i++) {
      final angle = (i / count) * 2 * math.pi;
      final start = Offset(
        center.dx + 80 * math.cos(angle),
        center.dy + 80 * math.sin(angle),
      );
      final end = Offset(
        center.dx + 900 * math.cos(angle),
        center.dy + 900 * math.sin(angle),
      );
      canvas.drawLine(start, end, paint);
    }
  }
  @override
  bool shouldRepaint(covariant CustomPainter _) => false;
}

// ═══════════════════════════════════════════════════════════════════════════════
// PROFILE PAGE
// ═══════════════════════════════════════════════════════════════════════════════
class ProfilePage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final String uid;

  const ProfilePage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.uid,
  });

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  File? _profileImage;
  final ImagePicker _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    _loadProfileImage();
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_${widget.username}');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() {
        _profileImage = File(imagePath);
      });
    }
  }

  String _censorText(String text, {bool isPassword = false}) {
    if (text.isEmpty) return "N/A";
    if (isPassword) return "••••••••";
    if (text.length <= 2) return "${text.substring(0, 1)}••";
    return "${text.substring(0, 2)}${'•' * (text.length - 2)}";
  }

  // ─── IMAGE SOURCE PICKER — COMIX ─────────────────────────────────
  Future<void> _showImageSourceDialog() {
    return showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => SafeArea(
        child: ComixPanel(
          bgColor: Colors.white,
          shadowOffset: 0,
          borderWidth: 3,
          radius: const BorderRadius.vertical(top: Radius.circular(24)),
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 50,
                height: 6,
                decoration: BoxDecoration(
                  color: comixInk,
                  borderRadius: BorderRadius.circular(100),
                ),
              ),
              const SizedBox(height: 14),
              ComixChip(
                bgColor: comixYellow,
                child: const Text('PILIH SUMBER FOTO',
                    style: TextStyle(
                        color: comixInk,
                        fontWeight: FontWeight.w900,
                        fontSize: 11,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1)),
              ),
              const SizedBox(height: 16),
              _imageSourceItem(
                icon: Icons.camera_alt_rounded,
                color: comixBlue,
                title: 'Kamera',
                onTap: () {
                  Navigator.pop(context);
                  _pickImage(ImageSource.camera);
                },
              ),
              const SizedBox(height: 10),
              _imageSourceItem(
                icon: Icons.photo_library_rounded,
                color: comixPurple,
                title: 'Galeri',
                onTap: () {
                  Navigator.pop(context);
                  _pickImage(ImageSource.gallery);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _imageSourceItem({
    required IconData icon,
    required Color color,
    required String title,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: ComixPanel(
        bgColor: Colors.white,
        shadowOffset: 3,
        borderWidth: 2.5,
        radius: const BorderRadius.all(Radius.circular(14)),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: color,
                shape: BoxShape.circle,
                border: Border.all(color: comixInk, width: 2.5),
                boxShadow: const [
                  BoxShadow(
                      color: comixInk,
                      offset: Offset(2, 2),
                      blurRadius: 0),
                ],
              ),
              child: Icon(icon, color: Colors.white, size: 20),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Text(title,
                  style: const TextStyle(
                      color: comixInk,
                      fontSize: 14,
                      fontWeight: FontWeight.w900)),
            ),
            const Icon(Icons.arrow_forward_rounded,
                color: comixInk, size: 20),
          ],
        ),
      ),
    );
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final XFile? pickedFile = await _picker.pickImage(
        source: source,
        imageQuality: 70,
      );

      if (pickedFile != null) {
        final File imageFile = File(pickedFile.path);
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString(
            'profile_image_${widget.username}', imageFile.path);
        setState(() {
          _profileImage = imageFile;
        });
      }
    } catch (e) {
      debugPrint("Error picking image: $e");
    }
  }

  Future<void> _copyToClipboard(String text, String label) async {
    await Clipboard.setData(ClipboardData(text: text));
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              const Icon(Icons.check_circle_rounded,
                  color: Colors.white, size: 20),
              const SizedBox(width: 8),
              Text("$label berhasil disalin!",
                  style: const TextStyle(
                      color: Colors.white, fontWeight: FontWeight.w900)),
            ],
          ),
          backgroundColor: comixGreen,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: const BorderSide(color: comixInk, width: 2.5),
          ),
          duration: const Duration(seconds: 2),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: comixBg,
      appBar: _buildComixAppBar(),
      body: Stack(
        children: [
          Positioned.fill(
            child: IgnorePointer(
                child: CustomPaint(painter: _HalftonePainter())),
          ),
          Positioned.fill(
            child: IgnorePointer(
                child: CustomPaint(painter: _SpeedLinesPainter())),
          ),
          SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                const SizedBox(height: 8),
                // ─── Avatar Section ───
                Center(
                  child: GestureDetector(
                    onTap: _showImageSourceDialog,
                    child: Stack(
                      clipBehavior: Clip.none,
                      children: [
                        Container(
                          width: 130,
                          height: 130,
                          padding: const EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: comixYellow,
                            border: Border.all(color: comixInk, width: 3.5),
                            boxShadow: const [
                              BoxShadow(
                                  color: comixInk,
                                  offset: Offset(5, 5),
                                  blurRadius: 0),
                            ],
                          ),
                          child: ClipOval(
                            child: _profileImage != null
                                ? Image.file(_profileImage!, fit: BoxFit.cover)
                                : Container(
                                    color: comixBlue,
                                    child: const Icon(
                                      FontAwesomeIcons.userAstronaut,
                                      size: 54,
                                      color: Colors.white,
                                    ),
                                  ),
                          ),
                        ),
                        Positioned(
                          bottom: 0,
                          right: 0,
                          child: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: comixRed,
                              shape: BoxShape.circle,
                              border: Border.all(color: comixInk, width: 2.5),
                              boxShadow: const [
                                BoxShadow(
                                    color: comixInk,
                                    offset: Offset(2, 2),
                                    blurRadius: 0),
                              ],
                            ),
                            child: const Icon(Icons.camera_alt_rounded,
                                size: 18, color: Colors.white),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 20),

                // Username
                Text(
                  widget.username,
                  style: const TextStyle(
                    color: comixInk,
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1,
                    fontFamily: 'Orbitron',
                  ),
                ),
                const SizedBox(height: 8),

                // Role chip
                ComixChip(
                  bgColor: comixBlue,
                  child: Text(
                    widget.role.toUpperCase(),
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.5,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                ),
                const SizedBox(height: 24),

                // ─── Info Cards Grid ───
                GridView.count(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisCount: 2,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: 1.35,
                  children: [
                    _buildInfoCard(
                      icon: Icons.person_rounded,
                      color: comixBlue,
                      label: "USERNAME",
                      value: _censorText(widget.username),
                    ),
                    _buildInfoCard(
                      icon: Icons.lock_rounded,
                      color: comixRed,
                      label: "PASSWORD",
                      value: _censorText(widget.password, isPassword: true),
                    ),
                    _buildInfoCard(
                      icon: Icons.verified_user_rounded,
                      color: comixGreen,
                      label: "ROLE",
                      value: widget.role.toUpperCase(),
                    ),
                    _buildInfoCard(
                      icon: Icons.calendar_today_rounded,
                      color: comixOrange,
                      label: "EXPIRED",
                      value: widget.expiredDate,
                    ),
                  ],
                ),
                const SizedBox(height: 14),

                // ─── Session Key Card ───
                _buildKeyCard(
                  icon: Icons.vpn_key_rounded,
                  color: comixCyan,
                  label: 'SESSION KEY',
                  value: widget.sessionKey,
                ),
                const SizedBox(height: 12),

                // ─── UID Card ───
                _buildKeyCard(
                  icon: Icons.badge_rounded,
                  color: comixPurple,
                  label: 'UID / ID',
                  value: widget.uid,
                ),
                const SizedBox(height: 28),

                // ─── Change Password Button ───
                _ComixGradBtn(
                  label: 'CHANGE PASSWORD',
                  icon: Icons.lock_reset_rounded,
                  color: comixBlue,
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ChangePasswordPage(
                          username: widget.username,
                          sessionKey: widget.sessionKey,
                        ),
                      ),
                    );
                  },
                ),
                const SizedBox(height: 24),
              ],
            ),
          ),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildComixAppBar() {
    return AppBar(
      backgroundColor: comixBg,
      foregroundColor: comixInk,
      elevation: 0,
      automaticallyImplyLeading: false,
      flexibleSpace: Container(
        decoration: const BoxDecoration(
          border: Border(bottom: BorderSide(color: comixInk, width: 3)),
        ),
      ),
      leading: Padding(
        padding: const EdgeInsets.only(left: 8),
        child: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            decoration: BoxDecoration(
              color: comixYellow,
              borderRadius: BorderRadius.circular(11),
              border: Border.all(color: comixInk, width: 2.5),
              boxShadow: const [
                BoxShadow(
                    color: comixInk, offset: Offset(2.5, 2.5), blurRadius: 0),
              ],
            ),
            child: const Icon(Icons.arrow_back_rounded,
                color: comixInk, size: 20),
          ),
        ),
      ),
      centerTitle: true,
      title: Stack(
        children: [
          Transform.translate(
            offset: const Offset(2, 2),
            child: const Text('PROFILE',
                style: TextStyle(
                    color: comixInk,
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2,
                    fontFamily: 'Orbitron')),
          ),
          const Text('PROFILE',
              style: TextStyle(
                  color: comixBlue,
                  fontSize: 15,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2,
                  fontFamily: 'Orbitron',
                  shadows: [
                    Shadow(color: comixInk, offset: Offset(1.5, 1.5)),
                  ])),
        ],
      ),
    );
  }

  Widget _buildInfoCard({
    required IconData icon,
    required Color color,
    required String label,
    required String value,
  }) {
    return ComixPanel(
      bgColor: Colors.white,
      shadowOffset: 4,
      borderWidth: 2.5,
      radius: const BorderRadius.all(Radius.circular(16)),
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: comixInk, width: 2.5),
              boxShadow: const [
                BoxShadow(
                    color: comixInk, offset: Offset(2, 2), blurRadius: 0),
              ],
            ),
            child: Icon(icon, color: Colors.white, size: 18),
          ),
          const Spacer(),
          Text(label,
              style: const TextStyle(
                  color: comixTextSub,
                  fontSize: 9.5,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1)),
          const SizedBox(height: 3),
          Text(value,
              style: const TextStyle(
                  color: comixInk,
                  fontSize: 13,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron'),
              overflow: TextOverflow.ellipsis,
              maxLines: 1),
        ],
      ),
    );
  }

  Widget _buildKeyCard({
    required IconData icon,
    required Color color,
    required String label,
    required String value,
  }) {
    return ComixPanel(
      bgColor: Colors.white,
      shadowOffset: 5,
      borderWidth: 3,
      radius: const BorderRadius.all(Radius.circular(16)),
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  color: color,
                  borderRadius: BorderRadius.circular(9),
                  border: Border.all(color: comixInk, width: 2.5),
                ),
                child: Icon(icon, color: Colors.white, size: 16),
              ),
              const SizedBox(width: 10),
              Text(label,
                  style: const TextStyle(
                      color: comixInk,
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.2,
                      fontFamily: 'Orbitron')),
              const Spacer(),
              GestureDetector(
                onTap: () => _copyToClipboard(value, label),
                child: Container(
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(
                    color: color,
                    borderRadius: BorderRadius.circular(9),
                    border: Border.all(color: comixInk, width: 2.5),
                    boxShadow: const [
                      BoxShadow(
                          color: comixInk,
                          offset: Offset(2, 2),
                          blurRadius: 0),
                    ],
                  ),
                  child: const Icon(Icons.copy_rounded,
                      color: Colors.white, size: 15),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: color.withOpacity(0.12),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: comixInk, width: 2),
            ),
            child: SelectableText(
              value,
              style: TextStyle(
                color: comixInk,
                fontSize: 12.5,
                fontWeight: FontWeight.w800,
                fontFamily: 'monospace',
                letterSpacing: 0.5,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// COMIX GRAD BUTTON
// ═══════════════════════════════════════════════════════════════════════════════
class _ComixGradBtn extends StatefulWidget {
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  const _ComixGradBtn({
    required this.label,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  State<_ComixGradBtn> createState() => _ComixGradBtnState();
}

class _ComixGradBtnState extends State<_ComixGradBtn> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _down = true),
      onTapUp: (_) {
        setState(() => _down = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _down = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 90),
        transform: Matrix4.translationValues(
            _down ? 2 : 0, _down ? 2 : 0, 0),
        height: 54,
        width: double.infinity,
        decoration: BoxDecoration(
          color: widget.color,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: comixInk, width: 3),
          boxShadow: [
            BoxShadow(
              color: comixInk,
              offset: Offset(_down ? 2 : 5, _down ? 2 : 5),
              blurRadius: 0,
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(widget.icon, color: Colors.white, size: 20),
            const SizedBox(width: 10),
            Text(widget.label,
                style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                    fontSize: 14,
                    letterSpacing: 1.5,
                    fontFamily: 'Orbitron')),
          ],
        ),
      ),
    );
  }
}