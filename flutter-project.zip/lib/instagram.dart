import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ─── COLORS ────────────────────────────────────────────────────────────────────
const Color kBg = Color(0xFF09090B);
const Color kCard = Color(0xFF18181B);
const Color kCardAlt = Color(0xFF1C1C1F);
const Color kBorder = Color(0xFF27272A);
const Color kBlue = Color(0xFF1565C0);
const Color kBlueMid = Color(0xFF1976D2);
const Color kBlueLight = Color(0xFF42A5F5);
const Color kPink = Color(0xFFE91E8C);
const Color kPurple = Color(0xFF7C4DFF);
const Color kYellow = Color(0xFFFFD600);
const Color kGreen = Color(0xFF10B981);
const Color kWhite = Colors.white;
const Color kWhite54 = Colors.white54;
const Color kWhite24 = Colors.white24;

const String BASE_URL = 'http://shinoa-cpanelpanel.xtxintax.my.id:2003';

// ─── MODELS ────────────────────────────────────────────────────────────────────
class InstagramUser {
  final String id;
  final String username;
  final String fullName;
  final String? avatar;
  final String bio;
  bool isFollowing;
  bool isOnline;
  final int followers;
  final int following;

  InstagramUser({
    required this.id,
    required this.username,
    required this.fullName,
    this.avatar,
    required this.bio,
    this.isFollowing = false,
    this.isOnline = false,
    this.followers = 0,
    this.following = 0,
  });

  factory InstagramUser.fromJson(Map<String, dynamic> json) {
    return InstagramUser(
      id: json['id'] ?? '',
      username: json['username'] ?? '',
      fullName: json['full_name'] ?? '',
      avatar: json['avatar'],
      bio: json['bio'] ?? '',
      isFollowing: json['is_following'] ?? false,
      isOnline: json['is_online'] ?? false,
      followers: json['followers'] ?? 0,
      following: json['following'] ?? 0,
    );
  }
}

class InstagramStory {
  final String id;
  final String userId;
  final String username;
  final String? userAvatar;
  final String mediaUrl;
  final String mediaType; // 'image' or 'video'
  final DateTime createdAt;
  final int views;

  InstagramStory({
    required this.id,
    required this.userId,
    required this.username,
    this.userAvatar,
    required this.mediaUrl,
    required this.mediaType,
    required this.createdAt,
    this.views = 0,
  });

  factory InstagramStory.fromJson(Map<String, dynamic> json) {
    return InstagramStory(
      id: json['id'] ?? '',
      userId: json['user_id'] ?? '',
      username: json['username'] ?? '',
      userAvatar: json['user_avatar'],
      mediaUrl: json['media_url'] ?? '',
      mediaType: json['media_type'] ?? 'image',
      createdAt: DateTime.tryParse(json['created_at'] ?? '') ?? DateTime.now(),
      views: json['views'] ?? 0,
    );
  }
}

class InstagramPost {
  final String id;
  final String userId;
  final String username;
  final String? userAvatar;
  final String mediaUrl;
  final String mediaType; // 'image', 'video', 'carousel'
  final String? caption;
  final DateTime createdAt;
  final int likes;
  final int comments;
  bool isLiked;

  InstagramPost({
    required this.id,
    required this.userId,
    required this.username,
    this.userAvatar,
    required this.mediaUrl,
    required this.mediaType,
    this.caption,
    required this.createdAt,
    this.likes = 0,
    this.comments = 0,
    this.isLiked = false,
  });

  factory InstagramPost.fromJson(Map<String, dynamic> json) {
    return InstagramPost(
      id: json['id'] ?? '',
      userId: json['user_id'] ?? '',
      username: json['username'] ?? '',
      userAvatar: json['user_avatar'],
      mediaUrl: json['media_url'] ?? '',
      mediaType: json['media_type'] ?? 'image',
      caption: json['caption'],
      createdAt: DateTime.tryParse(json['created_at'] ?? '') ?? DateTime.now(),
      likes: json['likes'] ?? 0,
      comments: json['comments'] ?? 0,
      isLiked: json['is_liked'] ?? false,
    );
  }
}

class InstagramMessage {
  final String id;
  final String senderId;
  final String senderName;
  final String? senderAvatar;
  final String message;
  final DateTime timestamp;
  bool isRead;

  InstagramMessage({
    required this.id,
    required this.senderId,
    required this.senderName,
    this.senderAvatar,
    required this.message,
    required this.timestamp,
    this.isRead = false,
  });

  factory InstagramMessage.fromJson(Map<String, dynamic> json) {
    return InstagramMessage(
      id: json['id'] ?? '',
      senderId: json['sender_id'] ?? '',
      senderName: json['sender_name'] ?? '',
      senderAvatar: json['sender_avatar'],
      message: json['message'] ?? '',
      timestamp: DateTime.tryParse(json['timestamp'] ?? '') ?? DateTime.now(),
      isRead: json['is_read'] ?? false,
    );
  }
}

// ─── INSTAGRAM SERVICE ──────────────────────────────────────────────────────────
class InstagramService {
  static Future<List<InstagramStory>> fetchStories(String sessionKey) async {
    try {
      final res = await http.get(
        Uri.parse('$BASE_URL/api/instagram/stories'),
        headers: {'Authorization': 'Bearer $sessionKey'},
      ).timeout(const Duration(seconds: 10));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body) as List;
        return data.map((e) => InstagramStory.fromJson(e)).toList();
      }
    } catch (e) {
      print('Error fetching stories: $e');
    }
    return [];
  }

  static Future<List<InstagramPost>> fetchFeed(String sessionKey) async {
    try {
      final res = await http.get(
        Uri.parse('$BASE_URL/api/instagram/feed'),
        headers: {'Authorization': 'Bearer $sessionKey'},
      ).timeout(const Duration(seconds: 10));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body) as List;
        return data.map((e) => InstagramPost.fromJson(e)).toList();
      }
    } catch (e) {
      print('Error fetching feed: $e');
    }
    return [];
  }

  static Future<List<InstagramUser>> searchUsers(String query, String sessionKey) async {
    try {
      final res = await http.get(
        Uri.parse('$BASE_URL/api/instagram/search/users?q=$query'),
        headers: {'Authorization': 'Bearer $sessionKey'},
      ).timeout(const Duration(seconds: 10));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body) as List;
        return data.map((e) => InstagramUser.fromJson(e)).toList();
      }
    } catch (e) {
      print('Error searching users: $e');
    }
    return [];
  }

  static Future<List<InstagramPost>> searchPosts(String query, String sessionKey) async {
    try {
      final res = await http.get(
        Uri.parse('$BASE_URL/api/instagram/search/posts?q=$query'),
        headers: {'Authorization': 'Bearer $sessionKey'},
      ).timeout(const Duration(seconds: 10));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body) as List;
        return data.map((e) => InstagramPost.fromJson(e)).toList();
      }
    } catch (e) {
      print('Error searching posts: $e');
    }
    return [];
  }

  static Future<bool> followUser(String userId, String sessionKey) async {
    try {
      final res = await http.post(
        Uri.parse('$BASE_URL/api/instagram/follow'),
        headers: {
          'Authorization': 'Bearer $sessionKey',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({'user_id': userId}),
      ).timeout(const Duration(seconds: 10));
      return res.statusCode == 200;
    } catch (e) {
      print('Error following user: $e');
    }
    return false;
  }

  static Future<bool> unfollowUser(String userId, String sessionKey) async {
    try {
      final res = await http.post(
        Uri.parse('$BASE_URL/api/instagram/unfollow'),
        headers: {
          'Authorization': 'Bearer $sessionKey',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({'user_id': userId}),
      ).timeout(const Duration(seconds: 10));
      return res.statusCode == 200;
    } catch (e) {
      print('Error unfollowing user: $e');
    }
    return false;
  }

  static Future<bool> uploadPost(File mediaFile, String caption, String sessionKey) async {
    try {
      final req = http.MultipartRequest('POST', Uri.parse('$BASE_URL/api/instagram/upload'))
        ..headers['Authorization'] = 'Bearer $sessionKey'
        ..fields['caption'] = caption
        ..files.add(await http.MultipartFile.fromPath('media', mediaFile.path));

      final res = await req.send().timeout(const Duration(seconds: 30));
      return res.statusCode == 200;
    } catch (e) {
      print('Error uploading post: $e');
    }
    return false;
  }

  static Future<bool> uploadStory(File mediaFile, String sessionKey) async {
    try {
      final req = http.MultipartRequest('POST', Uri.parse('$BASE_URL/api/instagram/story'))
        ..headers['Authorization'] = 'Bearer $sessionKey'
        ..files.add(await http.MultipartFile.fromPath('media', mediaFile.path));

      final res = await req.send().timeout(const Duration(seconds: 30));
      return res.statusCode == 200;
    } catch (e) {
      print('Error uploading story: $e');
    }
    return false;
  }

  static Future<List<InstagramMessage>> fetchMessages(String conversationId, String sessionKey) async {
    try {
      final res = await http.get(
        Uri.parse('$BASE_URL/api/instagram/messages/$conversationId'),
        headers: {'Authorization': 'Bearer $sessionKey'},
      ).timeout(const Duration(seconds: 10));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body) as List;
        return data.map((e) => InstagramMessage.fromJson(e)).toList();
      }
    } catch (e) {
      print('Error fetching messages: $e');
    }
    return [];
  }

  static Future<bool> sendMessage(String userId, String message, String sessionKey) async {
    try {
      final res = await http.post(
        Uri.parse('$BASE_URL/api/instagram/message'),
        headers: {
          'Authorization': 'Bearer $sessionKey',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({'user_id': userId, 'message': message}),
      ).timeout(const Duration(seconds: 10));
      return res.statusCode == 200;
    } catch (e) {
      print('Error sending message: $e');
    }
    return false;
  }
}

// ─── MAIN INSTAGRAM PAGE ───────────────────────────────────────────────────────
class InstagramPage extends StatefulWidget {
  final String sessionKey;
  final String currentUsername;

  const InstagramPage({
    required this.sessionKey,
    required this.currentUsername,
  });

  @override
  State<InstagramPage> createState() => _InstagramPageState();
}

class _InstagramPageState extends State<InstagramPage> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  List<InstagramStory> stories = [];
  List<InstagramPost> posts = [];
  List<InstagramUser> searchResults = [];
  String searchQuery = '';
  bool isSearching = false;
  int searchTabIndex = 0; // 0 = users, 1 = posts
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _loadData();
  }

  void _loadData() async {
    setState(() => isLoading = true);
    final storyList = await InstagramService.fetchStories(widget.sessionKey);
    final postList = await InstagramService.fetchFeed(widget.sessionKey);
    if (mounted) {
      setState(() {
        stories = storyList;
        posts = postList;
        isLoading = false;
      });
    }
  }

  void _performSearch(String query) async {
    if (query.isEmpty) {
      setState(() {
        searchResults = [];
        searchQuery = '';
      });
      return;
    }

    setState(() {
      searchQuery = query;
      isLoading = true;
    });

    if (searchTabIndex == 0) {
      final users = await InstagramService.searchUsers(query, widget.sessionKey);
      if (mounted) {
        setState(() {
          searchResults = users;
          isLoading = false;
        });
      }
    } else {
      final foundPosts = await InstagramService.searchPosts(query, widget.sessionKey);
      if (mounted) {
        setState(() {
          posts = foundPosts;
          isLoading = false;
        });
      }
    }
  }

  void _pickAndUploadMedia(bool isStory) async {
    final picker = ImagePicker();
    final media = await picker.pickMedia();

    if (media != null) {
      if (mounted) {
        _showUploadDialog(File(media.path), isStory);
      }
    }
  }

  void _showUploadDialog(File file, bool isStory) {
    final captionCtrl = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: kCard,
        title: Text(isStory ? 'Add Story' : 'New Post',
            style: const TextStyle(color: kWhite, fontWeight: FontWeight.bold)),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (!isStory)
                TextField(
                  controller: captionCtrl,
                  decoration: InputDecoration(
                    hintText: 'Write a caption...',
                    hintStyle: const TextStyle(color: kWhite24),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(color: kBorder),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(color: kBlue),
                    ),
                  ),
                  style: const TextStyle(color: kWhite),
                  maxLines: 3,
                ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel', style: TextStyle(color: kWhite54)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: kBlue,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
            onPressed: () async {
              Navigator.pop(ctx);
              if (mounted) {
                _showLoadingDialog('Uploading...');
              }

              final success = isStory
                  ? await InstagramService.uploadStory(file, widget.sessionKey)
                  : await InstagramService.uploadPost(file, captionCtrl.text, widget.sessionKey);

              if (mounted) {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(success ? 'Upload successful!' : 'Upload failed'),
                    backgroundColor: success ? kGreen : Colors.red,
                  ),
                );
                if (success) _loadData();
              }
            },
            child: const Text('Upload', style: TextStyle(color: kWhite)),
          ),
        ],
      ),
    );
  }

  void _showLoadingDialog(String message) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        backgroundColor: kCard,
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const CircularProgressIndicator(color: kBlue),
            const SizedBox(height: 16),
            Text(message, style: const TextStyle(color: kWhite)),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        backgroundColor: kBg,
        appBar: AppBar(
          backgroundColor: kCard,
          elevation: 0,
          title: const Text('Instagram',
              style: TextStyle(
                color: kWhite,
                fontWeight: FontWeight.bold,
                fontSize: 24,
                fontStyle: FontStyle.italic,
              )),
          actions: [
            IconButton(
              icon: const Icon(FontAwesomeIcons.heart, color: kPink),
              onPressed: () {},
            ),
            IconButton(
              icon: const Icon(FontAwesomeIcons.paperPlane, color: kBlue),
              onPressed: () => _showMessagesDialog(),
            ),
          ],
          bottom: TabBar(
            controller: _tabController,
            indicatorColor: kBlue,
            labelColor: kWhite,
            unselectedLabelColor: kWhite54,
            tabs: const [
              Tab(icon: Icon(FontAwesomeIcons.house), text: 'Feed'),
              Tab(icon: Icon(FontAwesomeIcons.magnifyingGlass), text: 'Search'),
              Tab(icon: Icon(FontAwesomeIcons.user), text: 'Profile'),
            ],
          ),
        ),
        body: isLoading
            ? const Center(
                child: CircularProgressIndicator(color: kBlue, strokeWidth: 2),
              )
            : TabBarView(
                controller: _tabController,
                children: [
                  _buildFeedTab(),
                  _buildSearchTab(),
                  _buildProfileTab(),
                ],
              ),
      ),
    );
  }

  Widget _buildFeedTab() {
    return RefreshIndicator(
      onRefresh: () async => _loadData(),
      color: kBlue,
      backgroundColor: kCard,
      child: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          _buildStoryCarousel(),
          const SizedBox(height: 24),
          ...posts.map((post) => _buildPostCard(post)),
        ],
      ),
    );
  }

  Widget _buildStoryCarousel() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 12),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Stories',
                  style: TextStyle(color: kWhite, fontWeight: FontWeight.bold, fontSize: 16)),
              GestureDetector(
                onTap: () => _pickAndUploadMedia(true),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: kBlue,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(FontAwesomeIcons.plus, color: kWhite, size: 12),
                      SizedBox(width: 6),
                      Text('Add', style: TextStyle(color: kWhite, fontSize: 12, fontWeight: FontWeight.w600)),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(
          height: 120,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: stories.length + 1,
            itemBuilder: (ctx, i) {
              if (i == 0) {
                return Padding(
                  padding: const EdgeInsets.only(right: 12),
                  child: GestureDetector(
                    onTap: () => _pickAndUploadMedia(true),
                    child: _buildStoryThumbnail(
                      null,
                      isAddButton: true,
                    ),
                  ),
                );
              }
              final story = stories[i - 1];
              return Padding(
                padding: const EdgeInsets.only(right: 12),
                child: GestureDetector(
                  onTap: () => _showStoryViewer(story),
                  child: _buildStoryThumbnail(story),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildStoryThumbnail(InstagramStory? story, {bool isAddButton = false}) {
    return Container(
      width: 100,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        gradient: const LinearGradient(
          colors: [kBlue, kPurple],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        border: Border.all(color: kBorder, width: 2),
      ),
      child: isAddButton
          ? const Center(
              child: Icon(FontAwesomeIcons.plus, color: kWhite, size: 32),
            )
          : Stack(
              fit: StackFit.expand,
              children: [
                if (story!.mediaType == 'image')
                  Image.network(story.mediaUrl, fit: BoxFit.cover)
                else
                  Container(
                    color: kCard,
                    child: const Icon(FontAwesomeIcons.video, color: kWhite54),
                  ),
                Positioned(
                  top: 8,
                  left: 8,
                  child: CircleAvatar(
                    radius: 16,
                    backgroundColor: kCard,
                    backgroundImage: story.userAvatar != null
                        ? NetworkImage(story.userAvatar!)
                        : null,
                    child: story.userAvatar == null
                        ? const Icon(FontAwesomeIcons.user, size: 12, color: kWhite)
                        : null,
                  ),
                ),
                Positioned(
                  bottom: 8,
                  left: 8,
                  right: 8,
                  child: Text(
                    story.username,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: kWhite,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
    );
  }

  Widget _buildPostCard(InstagramPost post) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: kCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: kBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 20,
                  backgroundColor: kCardAlt,
                  backgroundImage: post.userAvatar != null
                      ? NetworkImage(post.userAvatar!)
                      : null,
                  child: post.userAvatar == null
                      ? const Icon(FontAwesomeIcons.user, size: 14, color: kWhite)
                      : null,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(post.username,
                          style: const TextStyle(
                            color: kWhite,
                            fontWeight: FontWeight.bold,
                            fontSize: 13,
                          )),
                      Text(
                        _formatTime(post.createdAt),
                        style: const TextStyle(color: kWhite24, fontSize: 11),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  icon: const Icon(FontAwesomeIcons.ellipsis, color: kWhite54, size: 16),
                  onPressed: () {},
                ),
              ],
            ),
          ),
          // Media
          if (post.mediaType == 'image')
            Container(
              width: double.infinity,
              height: 300,
              color: kCardAlt,
              child: Image.network(post.mediaUrl, fit: BoxFit.cover),
            )
          else
            Container(
              width: double.infinity,
              height: 300,
              color: kCardAlt,
              child: const Center(
                child: Icon(FontAwesomeIcons.play, color: kWhite54, size: 48),
              ),
            ),
          // Interactions
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    IconButton(
                      icon: Icon(
                        post.isLiked ? FontAwesomeIcons.solidHeart : FontAwesomeIcons.heart,
                        color: post.isLiked ? kPink : kWhite54,
                        size: 20,
                      ),
                      onPressed: () {},
                    ),
                    IconButton(
                      icon: const Icon(FontAwesomeIcons.comment, color: kWhite54, size: 20),
                      onPressed: () {},
                    ),
                    IconButton(
                      icon: const Icon(FontAwesomeIcons.paperPlane, color: kWhite54, size: 20),
                      onPressed: () {},
                    ),
                    const Spacer(),
                    IconButton(
                      icon: const Icon(FontAwesomeIcons.bookmark, color: kWhite54, size: 20),
                      onPressed: () {},
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('${post.likes} likes',
                          style: const TextStyle(
                            color: kWhite,
                            fontWeight: FontWeight.bold,
                            fontSize: 12,
                          )),
                      const SizedBox(height: 6),
                      RichText(
                        text: TextSpan(
                          children: [
                            TextSpan(
                              text: post.username,
                              style: const TextStyle(
                                color: kWhite,
                                fontWeight: FontWeight.bold,
                                fontSize: 12,
                              ),
                            ),
                            TextSpan(
                              text: ' ${post.caption ?? ''}',
                              style: const TextStyle(color: kWhite, fontSize: 12),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text('View all ${post.comments} comments',
                          style: const TextStyle(color: kWhite24, fontSize: 11)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchTab() {
    return SingleChildScrollView(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              onChanged: _performSearch,
              decoration: InputDecoration(
                hintText: searchTabIndex == 0 ? 'Search users...' : 'Search videos...',
                hintStyle: const TextStyle(color: kWhite24),
                prefixIcon: const Icon(FontAwesomeIcons.magnifyingGlass, color: kWhite24, size: 16),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(24),
                  borderSide: const BorderSide(color: kBorder),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(24),
                  borderSide: const BorderSide(color: kBlue),
                ),
                filled: true,
                fillColor: kCardAlt,
              ),
              style: const TextStyle(color: kWhite),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _buildSearchTabButton(0, 'Users'),
                  const SizedBox(width: 8),
                  _buildSearchTabButton(1, 'Videos'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          if (searchQuery.isEmpty && searchResults.isEmpty)
            _buildEmptySearchState()
          else if (searchTabIndex == 0)
            ...searchResults.map((user) => _buildUserCard(user)),
        ],
      ),
    );
  }

  Widget _buildSearchTabButton(int index, String label) {
    final isActive = searchTabIndex == index;
    return GestureDetector(
      onTap: () => setState(() => searchTabIndex = index),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isActive ? kBlue : kCardAlt,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isActive ? kBlue : kBorder,
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: kWhite,
            fontWeight: FontWeight.w600,
            fontSize: 12,
          ),
        ),
      ),
    );
  }

  Widget _buildEmptySearchState() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 48),
      child: Column(
        children: [
          Icon(
            searchTabIndex == 0 ? FontAwesomeIcons.users : FontAwesomeIcons.video,
            color: kWhite24,
            size: 48,
          ),
          const SizedBox(height: 16),
          const Text(
            'Search users or videos',
            style: TextStyle(color: kWhite54, fontSize: 14),
          ),
        ],
      ),
    );
  }

  Widget _buildUserCard(InstagramUser user) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: kCard,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: kBorder),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 28,
            backgroundColor: kCardAlt,
            backgroundImage: user.avatar != null ? NetworkImage(user.avatar!) : null,
            child: user.avatar == null
                ? const Icon(FontAwesomeIcons.user, color: kWhite)
                : null,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(user.username,
                        style: const TextStyle(
                          color: kWhite,
                          fontWeight: FontWeight.bold,
                          fontSize: 13,
                        )),
                    if (user.isOnline)
                      Padding(
                        padding: const EdgeInsets.only(left: 6),
                        child: Container(
                          width: 8,
                          height: 8,
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            color: kGreen,
                          ),
                        ),
                      ),
                  ],
                ),
                Text(user.fullName,
                    style: const TextStyle(color: kWhite54, fontSize: 12)),
                const SizedBox(height: 4),
                Text('${user.followers} followers',
                    style: const TextStyle(color: kWhite24, fontSize: 11)),
              ],
            ),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: user.isFollowing ? kCardAlt : kBlue,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            ),
            onPressed: () async {
              final success = user.isFollowing
                  ? await InstagramService.unfollowUser(user.id, widget.sessionKey)
                  : await InstagramService.followUser(user.id, widget.sessionKey);

              if (success && mounted) {
                setState(() => user.isFollowing = !user.isFollowing);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(user.isFollowing ? 'Followed!' : 'Unfollowed!'),
                    backgroundColor: kGreen,
                    duration: const Duration(seconds: 2),
                  ),
                );
              }
            },
            child: Text(
              user.isFollowing ? 'Following' : 'Follow',
              style: const TextStyle(
                color: kWhite,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProfileTab() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircleAvatar(
            radius: 64,
            backgroundColor: kCardAlt,
            child: const Icon(FontAwesomeIcons.user, color: kWhite, size: 48),
          ),
          const SizedBox(height: 16),
          Text(
            widget.currentUsername,
            style: const TextStyle(
              color: kWhite,
              fontWeight: FontWeight.bold,
              fontSize: 18,
            ),
          ),
          const SizedBox(height: 24),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildProfileStat('0', 'Posts'),
              _buildProfileStat('0', 'Followers'),
              _buildProfileStat('0', 'Following'),
            ],
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: kBlue,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
            ),
            onPressed: () => _pickAndUploadMedia(false),
            icon: const Icon(FontAwesomeIcons.plus),
            label: const Text('New Post'),
          ),
        ],
      ),
    );
  }

  Widget _buildProfileStat(String count, String label) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 32),
      child: Column(
        children: [
          Text(count,
              style: const TextStyle(
                color: kWhite,
                fontWeight: FontWeight.bold,
                fontSize: 16,
              )),
          Text(label,
              style: const TextStyle(color: kWhite54, fontSize: 12)),
        ],
      ),
    );
  }

  void _showStoryViewer(InstagramStory story) {
    showModalBottomSheet(
      context: context,
      backgroundColor: kCard,
      builder: (ctx) => Container(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 24,
                  backgroundColor: kCardAlt,
                  backgroundImage: story.userAvatar != null
                      ? NetworkImage(story.userAvatar!)
                      : null,
                  child: story.userAvatar == null
                      ? const Icon(FontAwesomeIcons.user, size: 16)
                      : null,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(story.username,
                          style: const TextStyle(
                            color: kWhite,
                            fontWeight: FontWeight.bold,
                          )),
                      Text(_formatTime(story.createdAt),
                          style: const TextStyle(
                            color: kWhite24,
                            fontSize: 11,
                          )),
                    ],
                  ),
                ),
                IconButton(
                  icon: const Icon(FontAwesomeIcons.paperPlane, color: kBlue),
                  onPressed: () => Navigator.pop(ctx),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  color: kCardAlt,
                ),
                child: story.mediaType == 'image'
                    ? Image.network(story.mediaUrl, fit: BoxFit.cover)
                    : const Center(
                        child: Icon(FontAwesomeIcons.video, color: kWhite54, size: 48),
                      ),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Icon(FontAwesomeIcons.eye, color: kWhite54, size: 14),
                const SizedBox(width: 6),
                Text('${story.views} views',
                    style: const TextStyle(color: kWhite54, fontSize: 12)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showMessagesDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: kCard,
        title: const Text('Messages', style: TextStyle(color: kWhite)),
        content: Container(
          width: double.maxFinite,
          height: 300,
          child: const Center(
            child: Text(
              'Messages coming soon!',
              style: TextStyle(color: kWhite54),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Close', style: TextStyle(color: kBlue)),
          ),
        ],
      ),
    );
  }

  String _formatTime(DateTime dateTime) {
    final now = DateTime.now();
    final diff = now.difference(dateTime);

    if (diff.inSeconds < 60) return 'now';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    if (diff.inDays < 7) return '${diff.inDays}d ago';

    return '${dateTime.day}/${dateTime.month}/${dateTime.year}';
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }
}
