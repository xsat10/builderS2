import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../config/api_config.dart';

class ApiException implements Exception {
  ApiException(this.message, [this.statusCode]);

  final String message;
  final int? statusCode;

  @override
  String toString() => message;
}

class WaSession {
  WaSession({
    required this.id,
    required this.number,
    required this.status,
    this.pairingCode,
  });

  final String id;
  final String number;
  final String status;
  final String? pairingCode;

  factory WaSession.fromJson(Map<String, dynamic> json) {
    return WaSession(
      id: (json['id'] ?? json['sessionId'] ?? json['number'] ?? '').toString(),
      number: (json['number'] ?? json['id'] ?? '').toString(),
      status: (json['status'] ?? 'unknown').toString(),
      pairingCode: json['pairingCode']?.toString(),
    );
  }
}

class ApiService {
  ApiService._();
  static final ApiService instance = ApiService._();

  final http.Client _client = http.Client();

  Future<String?> _token() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(ApiConfig.tokenKey);
  }

  Future<void> saveToken(String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(ApiConfig.tokenKey, token);
  }

  Future<void> clearToken() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(ApiConfig.tokenKey);
  }

  Future<bool> hasToken() async {
    final token = await _token();
    return token != null && token.isNotEmpty;
  }

  Map<String, String> _headers(String? token) {
    return {
      'Content-Type': 'application/json',
      if (token != null && token.isNotEmpty) 'Authorization': 'Bearer $token',
    };
  }

  Future<dynamic> _send(
    String method,
    String path, {
    Map<String, dynamic>? body,
    Duration? timeout,
  }) async {
    final uri = Uri.parse('${ApiConfig.baseUrl}$path');
    final token = await _token();
    final headers = _headers(token);
    final encoded = body == null ? null : jsonEncode(body);
    final limit = timeout ?? ApiConfig.shortTimeout;

    try {
      late http.Response res;
      if (method == 'GET') {
        res = await _client.get(uri, headers: headers).timeout(limit);
      } else if (method == 'POST') {
        res = await _client
            .post(uri, headers: headers, body: encoded)
            .timeout(limit);
      } else if (method == 'DELETE') {
        res = await _client.delete(uri, headers: headers).timeout(limit);
      } else {
        throw ApiException('Method tidak didukung');
      }

      dynamic decoded;
      if (res.body.isNotEmpty) {
        try {
          decoded = jsonDecode(res.body);
        } catch (_) {
          decoded = {'error': res.body};
        }
      } else {
        decoded = {};
      }

      if (res.statusCode < 200 || res.statusCode >= 300) {
        final message = decoded is Map && decoded['error'] != null
            ? decoded['error'].toString()
            : 'Request gagal (${res.statusCode})';
        throw ApiException(message, res.statusCode);
      }
      return decoded;
    } on TimeoutException {
      throw ApiException('Timeout. Server tidak merespons.');
    } on ApiException {
      rethrow;
    } catch (e) {
      throw ApiException('Koneksi gagal: $e');
    }
  }

  Future<String> login(String username, String password) async {
    final data = await _send(
      'POST',
      '/login',
      body: {'username': username, 'password': password},
    );
    final token = (data is Map ? data['token'] : null)?.toString() ?? '';
    if (token.isEmpty) {
      throw ApiException('Token tidak diterima dari server');
    }
    await saveToken(token);
    return token;
  }

  Future<List<WaSession>> getSessions() async {
    final data = await _send('GET', '/sessions');
    List<dynamic> list;
    if (data is List) {
      list = data;
    } else if (data is Map && data['sessions'] is List) {
      list = data['sessions'] as List<dynamic>;
    } else {
      list = const [];
    }
    return list
        .whereType<Map>()
        .map((item) => WaSession.fromJson(Map<String, dynamic>.from(item)))
        .toList();
  }

  Future<String> addSession(String number) async {
    final data = await _send(
      'POST',
      '/add-session',
      body: {'number': number},
      timeout: ApiConfig.longTimeout,
    );
    if (data is Map && data['pairingCode'] != null) {
      return data['pairingCode'].toString();
    }
    throw ApiException('Pairing code tidak diterima');
  }

  Future<void> sendMessage({
    required String sessionId,
    required String number,
    required String message,
  }) async {
    await _send(
      'POST',
      '/send-message',
      body: {
        'sessionId': sessionId,
        'number': number,
        'message': message,
      },
      timeout: ApiConfig.longTimeout,
    );
  }

  Future<void> deleteSession(String id) async {
    await _send('DELETE', '/session/$id');
  }
}
