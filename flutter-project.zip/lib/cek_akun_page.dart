// ============================================================
// 🔍 CEK AKUN PAGE — Dark Red Comic 3D Edition
// File: cek_akun_page.dart
// ============================================================
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class _MC {
  static const red          = Color(0xFF8B0000);
  static const redDeep      = Color(0xFF1A0A0A);
  static const redDark      = Color(0xFF4A0000);
  static const redSoft      = Color(0xFF2A0E0E);
  static const brightRed    = Color(0xFFFF3B3B);
  static const buttonYellow = Color(0xFFB8860B);
  static const buttonDark   = Color(0xFF1A1A1A);
  static const comicBlack   = Color(0xFF000000);
  static const white        = Color(0xFFFFF5F5);
  static const textGrey     = Color(0xFFC9A0A0);
  static const textLight    = Color(0xFF8A6060);
  static const green        = Color(0xFF22C55E);
  static const greenLite    = Color(0xFF4ADE80);
  static const amber        = Color(0xFFFBBF24);
}

class CekAkunPage extends StatefulWidget {
  const CekAkunPage({super.key});

  @override
  State<CekAkunPage> createState() => _CekAkunPageState();
}

class _CekAkunPageState extends State<CekAkunPage>
    with TickerProviderStateMixin {
  final _userCtrl = TextEditingController();
  final _passCtrl = TextEditingController();

  bool _checking = false;
  String? _errorMsg;
  String? _resultStatus; // 'aktif', 'tidak_terdaftar', 'expired', 'error'
  Map<String, dynamic>? _resultData;

  late AnimationController _badgeCtrl;
  late Animation<double> _badgeSwing;

  static const String _baseUrl = "http://shinoa-cpanelpanel.xtxintax.my.id:2003";

  @override
  void initState() {
    super.initState();
    _badgeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2400),
    )..repeat(reverse: true);
    _badgeSwing = Tween<double>(begin: -0.05, end: 0.05).animate(
      CurvedAnimation(parent: _badgeCtrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _userCtrl.dispose();
    _passCtrl.dispose();
    _badgeCtrl.dispose();
    super.dispose();
  }

  // ════════════════════════════════════════════════════════════
  // 🔍 CEK AKUN KE SERVER
  // ════════════════════════════════════════════════════════════
  Future<void> _cekAkun() async {
    final uname = _userCtrl.text.trim();
    final pass = _passCtrl.text.trim();

    if (uname.isEmpty || pass.isEmpty) {
      setState(() => _errorMsg = '❌ Username dan password wajib diisi!');
      return;
    }

    setState(() {
      _checking = true;
      _errorMsg = null;
      _resultStatus = null;
      _resultData = null;
    });

    try {
      // ═══ COBA ENDPOINT 1: /checkAccount ═══
      bool gotResponse = false;
      Map<String, dynamic>? serverData;

      try {
        final res = await http.post(
          Uri.parse('$_baseUrl/checkAccount'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'username': uname,
            'password': pass,
          }),
        ).timeout(const Duration(seconds: 10));

        if (res.statusCode == 200) {
          try {
            final data = jsonDecode(res.body);
            if (data is Map) {
              serverData = Map<String, dynamic>.from(data);
              gotResponse = true;
            }
          } catch (_) {}
        }
      } catch (_) {}

      // ═══ FALLBACK: coba /validate ═══
      if (!gotResponse) {
        try {
          final res = await http.post(
            Uri.parse('$_baseUrl/validate'),
            body: {
              'username': uname,
              'password': pass,
              'androidId': 'cek_akun_web',
              'version': '6.3',
            },
          ).timeout(const Duration(seconds: 10));

          if (res.statusCode == 200) {
            try {
              final data = jsonDecode(res.body);
              if (data is Map) {
                serverData = Map<String, dynamic>.from(data);
                gotResponse = true;
              }
            } catch (_) {}
          }
        } catch (_) {}
      }

      if (!mounted) return;

      if (!gotResponse || serverData == null) {
        setState(() {
          _checking = false;
          _resultStatus = 'error';
          _errorMsg = '⚠️ Server tidak dapat dijangkau. Coba lagi nanti.';
        });
        return;
      }

      // ═══ PARSE RESPONSE ═══
      final valid = serverData['valid'] == true;
      final expired = serverData['expired'] == true;

      if (valid && !expired) {
        setState(() {
          _checking = false;
          _resultStatus = 'aktif';
          _resultData = serverData;
        });
      } else if (valid && expired) {
        setState(() {
          _checking = false;
          _resultStatus = 'expired';
          _resultData = serverData;
        });
      } else {
        setState(() {
          _checking = false;
          _resultStatus = 'tidak_terdaftar';
        });
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _checking = false;
        _resultStatus = 'error';
        _errorMsg = '❌ Koneksi error: $e';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _MC.redDeep,
      body: Stack(
        children: [
          // Background grid
          Positioned.fill(
            child: CustomPaint(painter: _GridPainter()),
          ),
          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // ═══ TOP BAR: BACK + BADGE "CEK AKUN" (kanan, animated) ═══
                  _buildTopBar(),
                  const SizedBox(height: 16),
                  _buildHeaderCard(),
                  const SizedBox(height: 16),
                  _buildFormCard(),
                  if (_errorMsg != null) ...[
                    const SizedBox(height: 12),
                    _buildErrorBox(),
                  ],
                  const SizedBox(height: 16),
                  _buildCekButton(),
                  if (_resultStatus != null) ...[
                    const SizedBox(height: 16),
                    _buildResultCard(),
                  ],
                  const SizedBox(height: 30),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // TOP BAR — BADGE "CEK AKUN" KANAN ATAS (ANIMATED)
  // ═══════════════════════════════════════════════════════════
  Widget _buildTopBar() {
    return Row(
      children: [
        GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            width: 42, height: 42,
            decoration: BoxDecoration(
              color: _MC.buttonDark,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _MC.comicBlack, width: 3),
              boxShadow: const [
                BoxShadow(
                    color: _MC.comicBlack,
                    offset: Offset(3, 3),
                    blurRadius: 0),
              ],
            ),
            child: const Icon(Icons.arrow_back_ios_new_rounded,
                color: _MC.white, size: 16),
          ),
        ),
        const Spacer(),
        // ═══ PAPAN TEKS "CEK AKUN" BERGERAK ═══
        AnimatedBuilder(
          animation: _badgeSwing,
          builder: (_, __) => Transform.rotate(
            angle: _badgeSwing.value,
            alignment: Alignment.topCenter,
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: _MC.red,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _MC.comicBlack, width: 3),
                boxShadow: const [
                  BoxShadow(
                      color: _MC.comicBlack,
                      offset: Offset(4, 5),
                      blurRadius: 0),
                ],
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.search_rounded,
                      color: _MC.white, size: 14),
                  SizedBox(width: 6),
                  Text(
                    'CEK AKUN',
                    style: TextStyle(
                      color: _MC.white,
                      fontSize: 12,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2,
                      fontFamily: 'Astral',
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildHeaderCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: _MC.redSoft,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _MC.comicBlack, width: 3.5),
        boxShadow: const [
          BoxShadow(
              color: _MC.comicBlack,
              offset: Offset(6, 6),
              blurRadius: 0),
        ],
      ),
      child: Column(
        children: [
          Container(
            width: 70, height: 70,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _MC.red,
              border: Border.all(color: _MC.comicBlack, width: 3.5),
              boxShadow: const [
                BoxShadow(
                    color: _MC.comicBlack,
                    offset: Offset(3, 3),
                    blurRadius: 0),
              ],
            ),
            child: const Icon(Icons.manage_search_rounded,
                color: _MC.white, size: 34),
          ),
          const SizedBox(height: 14),
          const Text(
            'CEK AKUN ANDA',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: _MC.white,
              fontWeight: FontWeight.w900,
              fontSize: 18,
              letterSpacing: 2,
              fontFamily: 'Astral',
            ),
          ),
          const SizedBox(height: 6),
          const Text(
            'Cek apakah akun Anda aktif atau tidak terdaftar di database apk ini. Masukkan username & password dengan benar.',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: _MC.textGrey,
              fontSize: 12,
              height: 1.5,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFormCard() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: _MC.redSoft,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _MC.comicBlack, width: 3.5),
        boxShadow: const [
          BoxShadow(
              color: _MC.comicBlack,
              offset: Offset(6, 6),
              blurRadius: 0),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // USERNAME
          Row(
            children: const [
              Icon(Icons.person_rounded,
                  color: _MC.brightRed, size: 16),
              SizedBox(width: 8),
              Text(
                'USERNAME',
                style: TextStyle(
                  color: _MC.white,
                  fontWeight: FontWeight.w900,
                  fontSize: 11,
                  letterSpacing: 1.5,
                  fontFamily: 'Astral',
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          _buildInput(
            controller: _userCtrl,
            hint: 'Masukkan username',
            icon: Icons.person_rounded,
          ),
          const SizedBox(height: 14),
          // PASSWORD
          Row(
            children: const [
              Icon(Icons.lock_rounded,
                  color: _MC.brightRed, size: 16),
              SizedBox(width: 8),
              Text(
                'PASSWORD',
                style: TextStyle(
                  color: _MC.white,
                  fontWeight: FontWeight.w900,
                  fontSize: 11,
                  letterSpacing: 1.5,
                  fontFamily: 'Astral',
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          _buildInput(
            controller: _passCtrl,
            hint: 'Masukkan password',
            icon: Icons.lock_rounded,
            obscure: true,
          ),
        ],
      ),
    );
  }

  Widget _buildInput({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    bool obscure = false,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: _MC.redDeep,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _MC.comicBlack, width: 3),
        boxShadow: const [
          BoxShadow(
              color: _MC.comicBlack,
              offset: Offset(4, 4),
              blurRadius: 0),
        ],
      ),
      child: TextField(
        controller: controller,
        obscureText: obscure,
        style: const TextStyle(
          color: _MC.white,
          fontSize: 14,
          fontWeight: FontWeight.w700,
        ),
        cursorColor: _MC.brightRed,
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: const TextStyle(
              color: _MC.textLight, fontSize: 13),
          prefixIcon: Icon(icon, color: _MC.brightRed, size: 20),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
              vertical: 16, horizontal: 12),
        ),
      ),
    );
  }

  Widget _buildErrorBox() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _MC.red.withOpacity(0.3),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _MC.comicBlack, width: 2.5),
        boxShadow: const [
          BoxShadow(
              color: _MC.comicBlack,
              offset: Offset(3, 3),
              blurRadius: 0),
        ],
      ),
      child: Row(
        children: [
          const Icon(Icons.error_outline_rounded,
              color: _MC.brightRed, size: 18),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              _errorMsg!,
              style: const TextStyle(
                color: _MC.brightRed,
                fontSize: 12,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // 🟥 BUTTON "CEK SEKARANG" — MERAH GELAP COMIC 3D
  // ═══════════════════════════════════════════════════════════
  Widget _buildCekButton() {
    return GestureDetector(
      onTap: _checking ? null : _cekAkun,
      child: Container(
        height: 62,
        decoration: BoxDecoration(
          // ═══ MERAH GELAP ═══
          color: _checking ? _MC.buttonDark : _MC.red,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _MC.comicBlack, width: 4),
          boxShadow: const [
            BoxShadow(
                color: _MC.comicBlack,
                offset: Offset(5, 6),
                blurRadius: 0),
          ],
        ),
        child: Center(
          child: _checking
              ? const SizedBox(
                  width: 26, height: 26,
                  child: CircularProgressIndicator(
                    color: _MC.white,
                    strokeWidth: 3,
                  ),
                )
              : const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.search_rounded,
                        color: _MC.white, size: 24),
                    SizedBox(width: 10),
                    Text(
                      'CEK SEKARANG',
                      style: TextStyle(
                        color: _MC.white,
                        fontWeight: FontWeight.w900,
                        fontSize: 16,
                        letterSpacing: 2,
                        fontFamily: 'Astral',
                        shadows: [
                          Shadow(
                            color: _MC.comicBlack,
                            offset: Offset(2, 2),
                            blurRadius: 0,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // 📊 HASIL CEK
  // ═══════════════════════════════════════════════════════════
  Widget _buildResultCard() {
    final status = _resultStatus ?? 'error';

    Color bgColor;
    Color borderColor;
    IconData icon;
    String title;
    String message;

    switch (status) {
      case 'aktif':
        bgColor = _MC.green;
        borderColor = _MC.comicBlack;
        icon = Icons.check_circle_rounded;
        title = 'AKUN AKTIF';
        message = '✅ Akun Anda terdaftar dan aktif di database!';
        break;
      case 'expired':
        bgColor = _MC.amber;
        borderColor = _MC.comicBlack;
        icon = Icons.warning_rounded;
        title = 'AKUN EXPIRED';
        message =
            '⚠️ Akun terdaftar tapi sudah kadaluarsa.\nSilakan perpanjang.';
        break;
      case 'tidak_terdaftar':
        bgColor = _MC.brightRed;
        borderColor = _MC.comicBlack;
        icon = Icons.cancel_rounded;
        title = 'TIDAK TERDAFTAR';
        message =
            '❌ Akun tidak ditemukan di database.\nCek username & password.';
        break;
      default:
        bgColor = _MC.buttonDark;
        borderColor = _MC.comicBlack;
        icon = Icons.error_rounded;
        title = 'KONEKSI ERROR';
        message = '❌ Tidak dapat menghubungi server. Coba lagi.';
    }

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: _MC.redSoft,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: borderColor, width: 3.5),
        boxShadow: const [
          BoxShadow(
              color: _MC.comicBlack,
              offset: Offset(6, 6),
              blurRadius: 0),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              Container(
                width: 54, height: 54,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: bgColor,
                  border: Border.all(
                      color: _MC.comicBlack, width: 3),
                  boxShadow: const [
                    BoxShadow(
                        color: _MC.comicBlack,
                        offset: Offset(2, 2),
                        blurRadius: 0),
                  ],
                ),
                child: Icon(icon, color: _MC.white, size: 28),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'HASIL CEK',
                      style: TextStyle(
                        color: _MC.textGrey,
                        fontSize: 9,
                        letterSpacing: 1.5,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      title,
                      style: const TextStyle(
                        color: _MC.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Astral',
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: bgColor.withOpacity(0.2),
              borderRadius: BorderRadius.circular(12),
              border:
                  Border.all(color: _MC.comicBlack, width: 2.5),
            ),
            child: Text(
              message,
              style: const TextStyle(
                color: _MC.white,
                fontSize: 12,
                height: 1.5,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          // Data akun kalau aktif/expired
          if (status == 'aktif' || status == 'expired') ...[
            const SizedBox(height: 12),
            if (_resultData != null) ...[
              if (_resultData!['role'] != null)
                _infoRow('Role',
                    (_resultData!['role'] ?? '-').toString().toUpperCase()),
              if (_resultData!['expiredDate'] != null)
                _infoRow('Expired',
                    (_resultData!['expiredDate'] ?? '-').toString()),
              if (_resultData!['key'] != null)
                _infoRow(
                    'Session Key',
                    (_resultData!['key'] ?? '-')
                        .toString()
                        .substring(
                            0,
                            (_resultData!['key'] ?? '')
                                    .toString()
                                    .length >
                                12
                                ? 12
                                : (_resultData!['key'] ?? '')
                                    .toString()
                                    .length)),
            ],
          ],
        ],
      ),
    );
  }

  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          Expanded(
            flex: 4,
            child: Text(
              label,
              style: const TextStyle(
                color: _MC.textGrey,
                fontSize: 11,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          Expanded(
            flex: 6,
            child: Text(
              value,
              textAlign: TextAlign.right,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: _MC.white,
                fontSize: 11.5,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ═════════════════════════════════════════════════════════════
// 🎨 GRID PAINTER — Background
// ═════════════════════════════════════════════════════════════
class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(
      Offset.zero & size,
      Paint()..color = _MC.redDeep,
    );
    final grid = Paint()
      ..color = _MC.red.withOpacity(0.08)
      ..strokeWidth = 1;
    const step = 34.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}