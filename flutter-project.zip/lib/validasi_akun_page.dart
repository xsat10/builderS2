// ============================================================
// ✅ VALIDASI AKUN — Dark Red Comic 3D Edition
// File: validasi_akun_page.dart
// ============================================================
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class _MC {
  static const red          = Color(0xFF8B0000);
  static const redDeep      = Color(0xFF1A0A0A);
  static const redDark      = Color(0xFF4A0000);
  static const redSoft      = Color(0xFF2A0E0E);
  static const brightRed    = Color(0xFFFF3B3B);
  static const buttonYellow = Color(0xFFB8860B);
  static const buttonDark   = Color(0xFF1A1A1A);
  static const comicBlack   = Color(0xFF000000);
  static const white        = Color(0xFFFFF5F5);
  static const textGrey     = Color(0xFFC9A0A0);
  static const textLight    = Color(0xFF8A6060);
  static const green        = Color(0xFF22C55E);
  static const greenLite    = Color(0xFF4ADE80);
  static const amber        = Color(0xFFFBBF24);
}

class ValidasiAkunPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;
  const ValidasiAkunPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<ValidasiAkunPage> createState() => _ValidasiAkunPageState();
}

class _ValidasiAkunPageState extends State<ValidasiAkunPage> {
  List<Map<String, dynamic>> _pendingList = [];
  List<Map<String, dynamic>> _historyList = [];
  bool _loading = true;
  String _tab = 'pending';

  bool get _isOwner => widget.role.toLowerCase() == 'owner';

  @override
  void initState() {
    super.initState();
    _loadAll();
  }

  Future<void> _loadAll() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final keys = prefs.getKeys();

      final all = <Map<String, dynamic>>[];

      for (final k in keys) {
        if (k.startsWith('validasi_akun_')) {
          final list = prefs.getStringList(k) ?? [];
          for (final e in list) {
            try {
              final data = Map<String, dynamic>.from(jsonDecode(e));
              all.add(data);
            } catch (_) {}
          }
        }
      }

      all.sort((a, b) =>
          ((b['timestamp'] ?? 0) as int)
              .compareTo((a['timestamp'] ?? 0) as int));

      if (mounted) {
        setState(() {
          _pendingList =
              all.where((e) => e['status'] == 'pending').toList();
          _historyList =
              all.where((e) => e['status'] != 'pending').toList();
          _loading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _updateStatus(Map<String, dynamic> data, String newStatus) async {
    if (!_isOwner) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          backgroundColor: _MC.red,
          content: Text(
            '❌ Hanya OWNER yang bisa ACC / TOLAK',
            style: TextStyle(
                color: _MC.white, fontWeight: FontWeight.w800),
          ),
        ),
      );
      return;
    }

    try {
      final prefs = await SharedPreferences.getInstance();
      final seller = (data['seller'] ?? '').toString();
      final key = 'validasi_akun_$seller';
      final existing = prefs.getStringList(key) ?? [];

      final updated = existing.map((e) {
        try {
          final d = Map<String, dynamic>.from(jsonDecode(e));
          if (d['id'] == data['id']) {
            d['status'] = newStatus;
            d['reviewedBy'] = widget.username;
            d['reviewedAt'] = DateTime.now().millisecondsSinceEpoch;
          }
          return jsonEncode(d);
        } catch (_) {
          return e;
        }
      }).toList();

      await prefs.setStringList(key, updated);

      // Update stats
      if (newStatus == 'accept') {
        final pendapatan =
            prefs.getInt('jualan_pendapatan_$seller') ?? 0;
        final storedPrice =
            (data['paymentType'] == 'LUNAS') ? 50000 : 25000;
        await prefs.setInt(
            'jualan_pendapatan_$seller', pendapatan + storedPrice);
      }

      await _loadAll();

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            backgroundColor: newStatus == 'accept' ? _MC.green : _MC.red,
            content: Text(
              newStatus == 'accept'
                  ? '✅ Akun di-ACC!'
                  : '❌ Akun ditolak!',
              style: const TextStyle(
                  color: _MC.comicBlack, fontWeight: FontWeight.w900),
            ),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            backgroundColor: _MC.red,
            content: Text('❌ Gagal: $e',
                style: const TextStyle(color: _MC.white)),
          ),
        );
      }
    }
  }

  String _formatDate(int ts) {
    try {
      final dt = DateTime.fromMillisecondsSinceEpoch(ts);
      return '${dt.day}/${dt.month}/${dt.year} ${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
    } catch (_) {
      return '-';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _MC.redDeep,
      appBar: AppBar(
        backgroundColor: _MC.redDark,
        elevation: 0,
        centerTitle: true,
        leading: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            margin: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: _MC.buttonDark,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _MC.comicBlack, width: 2.5),
              boxShadow: const [
                BoxShadow(
                    color: _MC.comicBlack,
                    offset: Offset(2, 2),
                    blurRadius: 0),
              ],
            ),
            child: const Icon(Icons.arrow_back_ios_new_rounded,
                color: _MC.white, size: 16),
          ),
        ),
        title: Container(
          padding:
              const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
          decoration: BoxDecoration(
            color: _MC.buttonDark,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: _MC.comicBlack, width: 2.5),
            boxShadow: const [
              BoxShadow(
                  color: _MC.comicBlack,
                  offset: Offset(3, 3),
                  blurRadius: 0),
            ],
          ),
          child: const Text(
            'VALIDASI AKUN',
            style: TextStyle(
              color: _MC.white,
              fontWeight: FontWeight.w900,
              fontSize: 13,
              letterSpacing: 2,
              fontFamily: 'Astral',
            ),
          ),
        ),
      ),
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(color: _MC.brightRed))
          : Column(
              children: [
                _buildTabSwitcher(),
                Expanded(
                  child: _tab == 'pending'
                      ? _buildList(_pendingList, isPending: true)
                      : _buildList(_historyList, isPending: false),
                ),
              ],
            ),
    );
  }

  Widget _buildTabSwitcher() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Expanded(
            child: GestureDetector(
              onTap: () => setState(() => _tab = 'pending'),
              child: Container(
                height: 48,
                decoration: BoxDecoration(
                  color: _tab == 'pending' ? _MC.brightRed : _MC.buttonDark,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _MC.comicBlack, width: 3),
                  boxShadow: const [
                    BoxShadow(
                        color: _MC.comicBlack,
                        offset: Offset(3, 3),
                        blurRadius: 0),
                  ],
                ),
                child: Center(
                  child: Text(
                    'PENDING (${_pendingList.length})',
                    style: const TextStyle(
                      color: _MC.white,
                      fontWeight: FontWeight.w900,
                      fontSize: 11,
                      letterSpacing: 1,
                      fontFamily: 'Astral',
                    ),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: GestureDetector(
              onTap: () => setState(() => _tab = 'history'),
              child: Container(
                height: 48,
                decoration: BoxDecoration(
                  color: _tab == 'history' ? _MC.brightRed : _MC.buttonDark,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _MC.comicBlack, width: 3),
                  boxShadow: const [
                    BoxShadow(
                        color: _MC.comicBlack,
                        offset: Offset(3, 3),
                        blurRadius: 0),
                  ],
                ),
                child: Center(
                  child: Text(
                    'RIWAYAT (${_historyList.length})',
                    style: const TextStyle(
                      color: _MC.white,
                      fontWeight: FontWeight.w900,
                      fontSize: 11,
                      letterSpacing: 1,
                      fontFamily: 'Astral',
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildList(List<Map<String, dynamic>> list, {required bool isPending}) {
    if (list.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 90,
              height: 90,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _MC.redSoft,
                border: Border.all(color: _MC.comicBlack, width: 3),
              ),
              child: Icon(
                isPending ? Icons.hourglass_empty : Icons.history,
                color: _MC.brightRed,
                size: 40,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              isPending ? 'Belum ada validasi' : 'Belum ada riwayat',
              style: const TextStyle(
                color: _MC.white,
                fontWeight: FontWeight.w900,
                fontSize: 14,
                fontFamily: 'Astral',
              ),
            ),
          ],
        ),
      );
    }

    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.all(16),
      child: Column(
        children: list.map((data) => _buildAkunCard(data, isPending: isPending)).toList(),
      ),
    );
  }

  Widget _buildAkunCard(Map<String, dynamic> data, {required bool isPending}) {
    final status = (data['status'] ?? 'pending').toString();
    final seller = (data['seller'] ?? '-').toString();
    final uname = (data['username'] ?? '-').toString();
    final pass = (data['password'] ?? '-').toString();
    final hari = data['hari'] ?? 0;
    final payment = (data['paymentType'] ?? 'DP').toString();
    final role = (data['role'] ?? 'MEMBER').toString();
    final ts = data['timestamp'] ?? 0;

    Color statusColor;
    String statusLabel;
    if (status == 'accept') {
      statusColor = _MC.green;
      statusLabel = 'ACCEPTED';
    } else if (status == 'reject') {
      statusColor = _MC.red;
      statusLabel = 'REJECTED';
    } else {
      statusColor = _MC.amber;
      statusLabel = 'PENDING';
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _MC.redSoft,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _MC.comicBlack, width: 3),
        boxShadow: const [
          BoxShadow(
              color: _MC.comicBlack,
              offset: Offset(4, 4),
              blurRadius: 0),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: statusColor,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _MC.comicBlack, width: 2),
                ),
                child: Text(
                  statusLabel,
                  style: const TextStyle(
                    color: _MC.white,
                    fontSize: 9,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.8,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: _MC.buttonDark,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _MC.comicBlack, width: 1.5),
                ),
                child: Text(
                  payment,
                  style: const TextStyle(
                    color: _MC.buttonYellow,
                    fontSize: 9,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
              const SizedBox(width: 6),
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: _MC.buttonDark,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _MC.comicBlack, width: 1.5),
                ),
                child: Text(
                  role,
                  style: const TextStyle(
                    color: _MC.brightRed,
                    fontSize: 9,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          _infoRow('Seller', seller),
          _infoRow('Username', uname),
          _infoRow('Password', pass),
          _infoRow('Hari', '$hari'),
          _infoRow('Waktu', _formatDate(ts)),
          if (isPending) ...[
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () => _updateStatus(data, 'accept'),
                    child: Container(
                      height: 42,
                      decoration: BoxDecoration(
                        color: _isOwner ? _MC.green : _MC.buttonDark,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: _MC.comicBlack, width: 2.5),
                        boxShadow: const [
                          BoxShadow(
                              color: _MC.comicBlack,
                              offset: Offset(2, 2),
                              blurRadius: 0),
                        ],
                      ),
                      child: Center(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              _isOwner ? Icons.check_rounded : Icons.lock_rounded,
                              color: _MC.white,
                              size: 16,
                            ),
                            const SizedBox(width: 6),
                            Text(
                              _isOwner ? 'ACC' : 'ACC (OWNER ONLY)',
                              style: const TextStyle(
                                color: _MC.white,
                                fontSize: 10,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Astral',
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: GestureDetector(
                    onTap: () => _updateStatus(data, 'reject'),
                    child: Container(
                      height: 42,
                      decoration: BoxDecoration(
                        color: _isOwner ? _MC.red : _MC.buttonDark,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: _MC.comicBlack, width: 2.5),
                        boxShadow: const [
                          BoxShadow(
                              color: _MC.comicBlack,
                              offset: Offset(2, 2),
                              blurRadius: 0),
                        ],
                      ),
                      child: Center(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              _isOwner ? Icons.close_rounded : Icons.lock_rounded,
                              color: _MC.white,
                              size: 16,
                            ),
                            const SizedBox(width: 6),
                            Text(
                              _isOwner ? 'TOLAK' : 'TOLAK (OWNER ONLY)',
                              style: const TextStyle(
                                color: _MC.white,
                                fontSize: 10,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Astral',
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          Expanded(
            flex: 4,
            child: Text(
              label,
              style: const TextStyle(
                color: _MC.textGrey,
                fontSize: 11,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          Expanded(
            flex: 6,
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: const TextStyle(
                color: _MC.white,
                fontSize: 11.5,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ],
      ),
    );
  }
}