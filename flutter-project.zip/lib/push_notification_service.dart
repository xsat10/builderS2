import 'dart:io';

import 'package:android_intent_plus/android_intent.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:url_launcher/url_launcher.dart';

class PushNotificationService {
  PushNotificationService._();

  static final FlutterLocalNotificationsPlugin _local =
      FlutterLocalNotificationsPlugin();
  static bool _initialized = false;

  static const AndroidNotificationChannel _channel =
      AndroidNotificationChannel(
    'developer_notifications',
    'Developer Notifications',
    description: 'Notifikasi langsung dari developer',
    importance: Importance.max,
  );

  static final RegExp _urlPattern =
      RegExp(r'https?://[^\s]+', caseSensitive: false);

  static String? _extractUrl(String text) {
    final match = _urlPattern.firstMatch(text);
    if (match == null) return null;
    return match.group(0)!.replaceFirst(RegExp(r'[),.]+$'), '');
  }

  static Future<void> _openUrl(String? url) async {
    if (url == null || url.isEmpty) return;
    final uri = Uri.tryParse(url);
    if (uri == null || (uri.scheme != 'http' && uri.scheme != 'https')) {
      return;
    }

    // Android: coba langsung buka Google Chrome. Jika Chrome tidak tersedia,
    // fallback ke browser default perangkat.
    if (Platform.isAndroid) {
      try {
        final intent = AndroidIntent(
          action: 'android.intent.action.VIEW',
          data: uri.toString(),
          package: 'com.android.chrome',
        );
        await intent.launch();
        return;
      } catch (_) {
        // Chrome tidak tersedia → lanjut ke browser default.
      }
    }

    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {}
  }

  static Future<void> _handleRemoteMessage(RemoteMessage message) async {
    final url = message.data['url']?.toString() ??
        _extractUrl(message.data['body']?.toString() ??
            message.notification?.body ?? '');
    await _openUrl(url);
  }

  static Future<void> initialize() async {
    if (_initialized) return;

    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    await _local.initialize(
      const InitializationSettings(android: android),
      onDidReceiveNotificationResponse: (response) async {
        await _openUrl(response.payload);
      },
    );

    await _local
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(_channel);

    final messaging = FirebaseMessaging.instance;
    await messaging.setAutoInitEnabled(true);

    // Saat aplikasi sedang terbuka, FCM diteruskan ke local notification.
    FirebaseMessaging.onMessage.listen((message) async {
      final notification = message.notification;
      final title = notification?.title ??
          message.data['title'] ??
          'Developer';
      final body = notification?.body ?? message.data['body'] ?? '';
      if (body.isNotEmpty) {
        await _show(title.toString(), body.toString(),
            message.data['url']?.toString() ?? _extractUrl(body.toString()));
      }
    });

    // Saat user mengetuk notification ketika aplikasi berada di background.
    FirebaseMessaging.onMessageOpenedApp.listen(_handleRemoteMessage);

    // Saat user mengetuk notification ketika aplikasi benar-benar tertutup.
    final initialMessage = await messaging.getInitialMessage();
    if (initialMessage != null) {
      // Beri waktu Flutter menyelesaikan startup sebelum membuka Chrome.
      Future<void>.delayed(const Duration(milliseconds: 500), () {
        _handleRemoteMessage(initialMessage);
      });
    }

    _initialized = true;
  }

  static Future<void> requestPermissionAndSubscribe() async {
    final messaging = FirebaseMessaging.instance;
    final settings = await messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
      provisional: false,
    );

    if (settings.authorizationStatus == AuthorizationStatus.denied) {
      return;
    }

    await messaging.subscribeToTopic('developer_notifications');
  }

  static Future<void> _show(String title, String body, String? url) async {
    await _local.show(
      DateTime.now().millisecondsSinceEpoch.remainder(2147483647),
      title,
      body,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'developer_notifications',
          'Developer Notifications',
          channelDescription: 'Notifikasi langsung dari developer',
          importance: Importance.max,
          priority: Priority.high,
          icon: '@mipmap/ic_launcher',
        ),
      ),
      payload: url,
    );
  }
}
