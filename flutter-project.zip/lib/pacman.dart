import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:math';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const PacmanGame());

class PacmanGame extends StatelessWidget {
  const PacmanGame({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PACMAN',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),
      home: const GameScreen(),
    );
  }
}

class GameScreen extends StatefulWidget {
  const GameScreen({super.key});

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  late GameEngine engine;
  late Timer gameTimer;
  bool isGameOver = false;
  bool isWin = false;
  int highScore = 0;
  late SharedPreferences prefs;

  @override
  void initState() {
    super.initState();
    initSharedPrefs();
  }

  Future<void> initSharedPrefs() async {
    prefs = await SharedPreferences.getInstance();
    highScore = prefs.getInt('pacman_highscore') ?? 0;
    engine = GameEngine();
    engine.initGame();
    startGameLoop();
    setState(() {});
  }

  void saveHighScore(int currentScore) {
    if (currentScore > highScore) {
      highScore = currentScore;
      prefs.setInt('pacman_highscore', highScore);
      setState(() {});
    }
  }

  void startGameLoop() {
    gameTimer = Timer.periodic(const Duration(milliseconds: 100), (timer) {
      if (!isGameOver && !isWin) {
        engine.update();
        
        saveHighScore(engine.score);
        
        if (engine.pacman.lives <= 0) {
          isGameOver = true;
          timer.cancel();
          saveHighScore(engine.score);
        }
        if (engine.score >= engine.totalDots) {
          isWin = true;
          timer.cancel();
          saveHighScore(engine.score);
        }
        setState(() {});
      }
    });
  }

  void resetGame() {
    engine = GameEngine();
    engine.initGame();
    isGameOver = false;
    isWin = false;
    startGameLoop();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            color: Colors.black,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  children: [
                    const Text('SCORE', style: TextStyle(color: Colors.white, fontSize: 12)),
                    Text('${engine.score}', style: const TextStyle(color: Colors.yellow, fontSize: 24, fontWeight: FontWeight.bold)),
                  ],
                ),
                Column(
                  children: [
                    const Text('HIGH SCORE', style: TextStyle(color: Colors.white, fontSize: 12)),
                    Text('$highScore', style: const TextStyle(color: Colors.yellow, fontSize: 24, fontWeight: FontWeight.bold, shadows: [
                      Shadow(color: Colors.orange, blurRadius: 5)
                    ])),
                  ],
                ),
                Row(
                  children: List.generate(engine.pacman.lives, (index) => 
                    const Icon(Icons.favorite, color: Colors.red, size: 20)
                  ),
                ),
              ],
            ),
          ),
          
          Expanded(
            child: Container(
              margin: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.black,
                border: Border.all(color: Colors.blue, width: 2),
              ),
              child: AspectRatio(
                aspectRatio: GameEngine.boardWidth / GameEngine.boardHeight,
                child: CustomPaint(
                  painter: GamePainter(engine: engine),
                  size: Size.infinite,
                ),
              ),
            ),
          ),
          
          Container(
            padding: const EdgeInsets.all(16),
            color: Colors.black,
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ControlButton(
                      icon: Icons.arrow_upward,
                      onPressed: () => engine.setDirection(Direction.up),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ControlButton(
                      icon: Icons.arrow_left,
                      onPressed: () => engine.setDirection(Direction.left),
                    ),
                    const SizedBox(width: 20),
                    ControlButton(
                      icon: Icons.arrow_downward,
                      onPressed: () => engine.setDirection(Direction.down),
                    ),
                    const SizedBox(width: 20),
                    ControlButton(
                      icon: Icons.arrow_right,
                      onPressed: () => engine.setDirection(Direction.right),
                    ),
                  ],
                ),
              ],
            ),
          ),
          
          if (isGameOver || isWin)
            Container(
              color: Colors.black.withOpacity(0.8),
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      isWin ? 'YOU WIN! 🎉' : 'GAME OVER! 💀',
                      style: const TextStyle(color: Colors.yellow, fontSize: 32, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 20),
                    Text(
                      'YOUR SCORE: ${engine.score}',
                      style: const TextStyle(color: Colors.white, fontSize: 24),
                    ),
                    Text(
                      'HIGH SCORE: $highScore',
                      style: const TextStyle(color: Colors.orange, fontSize: 20),
                    ),
                    const SizedBox(height: 20),
                    ElevatedButton(
                      onPressed: resetGame,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                      ),
                      child: const Text('PLAY AGAIN', style: TextStyle(fontSize: 18)),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    gameTimer.cancel();
    super.dispose();
  }
}

class ControlButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onPressed;
  
  const ControlButton({super.key, required this.icon, required this.onPressed});
  
  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.blue[900],
        foregroundColor: Colors.yellow,
        shape: const CircleBorder(),
        padding: const EdgeInsets.all(20),
      ),
      child: Icon(icon, size: 30),
    );
  }
}

enum Direction { up, down, left, right, none }

class Position {
  int x, y;
  Position(this.x, this.y);
  
  @override
  bool operator ==(Object other) {
    return other is Position && other.x == x && other.y == y;
  }
  
  @override
  int get hashCode => x.hashCode ^ y.hashCode;
}

class Pacman {
  Position pos;
  Direction direction = Direction.right;
  Direction nextDirection = Direction.right;
  int lives = 3;
  double mouthAngle = 0;
  bool mouthOpen = true;
  
  Pacman(this.pos);
  
  void move(int dx, int dy) {
    pos.x += dx;
    pos.y += dy;
    updateMouth();
  }
  
  void updateMouth() {
    mouthAngle = mouthOpen ? (mouthAngle + 0.3) : (mouthAngle - 0.3);
    if (mouthAngle >= 0.5) mouthOpen = false;
    if (mouthAngle <= 0) mouthOpen = true;
  }
}

class Ghost {
  Position pos;
  Color color;
  Direction direction = Direction.right;
  Random random = Random();
  
  Ghost(this.pos, this.color);
  
  void moveAI(Position pacmanPos, List<List<int>> maze) {
    List<Direction> possibleMoves = [];
    
    // FIX: Boundary checking yang aman
    if (pos.y > 0 && pos.y - 1 < maze.length && pos.x < maze[0].length && maze[pos.y - 1][pos.x] != 1) {
      possibleMoves.add(Direction.up);
    }
    if (pos.y < maze.length - 1 && pos.y + 1 < maze.length && pos.x < maze[0].length && maze[pos.y + 1][pos.x] != 1) {
      possibleMoves.add(Direction.down);
    }
    if (pos.x > 0 && pos.y < maze.length && pos.x - 1 < maze[0].length && maze[pos.y][pos.x - 1] != 1) {
      possibleMoves.add(Direction.left);
    }
    if (pos.x < maze[0].length - 1 && pos.y < maze.length && pos.x + 1 < maze[0].length && maze[pos.y][pos.x + 1] != 1) {
      possibleMoves.add(Direction.right);
    }
    
    if (random.nextDouble() < 0.7 && possibleMoves.isNotEmpty) {
      int bestMove = 0;
      double bestDistance = double.infinity;
      
      for (int i = 0; i < possibleMoves.length; i++) {
        int newX = pos.x, newY = pos.y;
        switch (possibleMoves[i]) {
          case Direction.up: newY--; break;
          case Direction.down: newY++; break;
          case Direction.left: newX--; break;
          case Direction.right: newX++; break;
          default: break;
        }
        
        double distance = sqrt(pow(newX - pacmanPos.x, 2) + pow(newY - pacmanPos.y, 2));
        if (distance < bestDistance) {
          bestDistance = distance;
          bestMove = i;
        }
      }
      direction = possibleMoves[bestMove];
    } else if (possibleMoves.isNotEmpty) {
      direction = possibleMoves[random.nextInt(possibleMoves.length)];
    }
    
    switch (direction) {
      case Direction.up: pos.y--; break;
      case Direction.down: pos.y++; break;
      case Direction.left: pos.x--; break;
      case Direction.right: pos.x++; break;
      default: break;
    }
  }
}

class GameEngine {
  static const int boardWidth = 19;
  static const int boardHeight = 21;
  
  late List<List<int>> maze;
  late Pacman pacman;
  late List<Ghost> ghosts;
  late List<Position> dots;
  int score = 0;
  int totalDots = 0;
  
  final List<List<int>> classicMaze = [
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1],
    [1,0,1,1,0,1,1,1,0,1,0,1,1,1,0,1,1,0,1],
    [1,0,1,1,0,1,1,1,0,1,0,1,1,1,0,1,1,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,1,1,0,1,0,1,1,1,1,1,0,1,0,1,1,0,1],
    [1,0,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,0,1],
    [1,1,1,1,0,1,1,1,0,1,0,1,1,1,0,1,1,1,1],
    [0,0,0,1,0,1,0,0,0,0,0,0,0,1,0,1,0,0,0],
    [1,1,1,1,0,1,0,1,1,2,1,1,0,1,0,1,1,1,1],
    [0,0,0,0,0,0,0,1,2,2,2,1,0,0,0,0,0,0,0],
    [1,1,1,1,0,1,0,1,1,1,1,1,0,1,0,1,1,1,1],
    [0,0,0,1,0,1,0,0,0,0,0,0,0,1,0,1,0,0,0],
    [1,1,1,1,0,1,0,1,1,1,1,1,0,1,0,1,1,1,1],
    [1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1],
    [1,0,1,1,0,1,1,1,0,1,0,1,1,1,0,1,1,0,1],
    [1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1],
    [1,1,0,1,0,1,0,1,1,1,1,1,0,1,0,1,0,1,1],
    [1,0,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,0,1],
    [1,0,1,1,1,1,1,1,0,1,0,1,1,1,1,1,1,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
  ];
  
  void initGame() {
    maze = List.generate(classicMaze.length, (i) => List.from(classicMaze[i]));
    pacman = Pacman(Position(9, 15));
    
    ghosts = [
      Ghost(Position(9, 9), Colors.red),
      Ghost(Position(8, 9), Colors.pink),
      Ghost(Position(10, 9), Colors.cyan),
      Ghost(Position(9, 8), Colors.orange),
    ];
    
    dots = [];
    for (int y = 0; y < maze.length; y++) {
      for (int x = 0; x < maze[y].length; x++) {
        if (maze[y][x] == 0) {
          dots.add(Position(x, y));
        }
      }
    }
    totalDots = dots.length;
    score = 0;
  }
  
  void setDirection(Direction dir) {
    pacman.nextDirection = dir;
  }
  
  void update() {
    Direction finalDir = pacman.nextDirection;
    int newX = pacman.pos.x, newY = pacman.pos.y;
    
    switch (finalDir) {
      case Direction.up: newY--; break;
      case Direction.down: newY++; break;
      case Direction.left: newX--; break;
      case Direction.right: newX++; break;
      default: break;
    }
    
    // FIX: Boundary check yang aman
    if (newY >= 0 && newY < maze.length && newX >= 0 && newX < maze[0].length) {
      if (maze[newY][newX] != 1) {
        pacman.direction = finalDir;
      }
    }
    
    switch (pacman.direction) {
      case Direction.up: 
        if (pacman.pos.y > 0 && maze[pacman.pos.y - 1][pacman.pos.x] != 1) {
          pacman.move(0, -1);
        }
        break;
      case Direction.down: 
        if (pacman.pos.y < maze.length - 1 && maze[pacman.pos.y + 1][pacman.pos.x] != 1) {
          pacman.move(0, 1);
        }
        break;
      case Direction.left: 
        if (pacman.pos.x > 0 && maze[pacman.pos.y][pacman.pos.x - 1] != 1) {
          pacman.move(-1, 0);
        }
        break;
      case Direction.right: 
        if (pacman.pos.x < maze[0].length - 1 && maze[pacman.pos.y][pacman.pos.x + 1] != 1) {
          pacman.move(1, 0);
        }
        break;
      default: break;
    }
    
    if (pacman.pos.x < 0) pacman.pos.x = maze[0].length - 1;
    if (pacman.pos.x >= maze[0].length) pacman.pos.x = 0;
    
    // FIX: Safe dot eating
    if (pacman.pos.y >= 0 && pacman.pos.y < maze.length && 
        pacman.pos.x >= 0 && pacman.pos.x < maze[0].length) {
      Position currentPos = Position(pacman.pos.x, pacman.pos.y);
      int index = dots.indexWhere((dot) => dot.x == currentPos.x && dot.y == currentPos.y);
      if (index != -1) {
        dots.removeAt(index);
        score++;
        if (pacman.pos.y < maze.length && pacman.pos.x < maze[0].length) {
          maze[pacman.pos.y][pacman.pos.x] = 2;
        }
      }
    }
    
    for (var ghost in ghosts) {
      ghost.moveAI(pacman.pos, maze);
      
      if (ghost.pos.x < 0) ghost.pos.x = maze[0].length - 1;
      if (ghost.pos.x >= maze[0].length) ghost.pos.x = 0;
      
      if (ghost.pos.x == pacman.pos.x && ghost.pos.y == pacman.pos.y) {
        pacman.lives--;
        if (pacman.lives > 0) {
          resetPositions();
        }
      }
    }
  }
  
  void resetPositions() {
    pacman.pos = Position(9, 15);
    pacman.direction = Direction.right;
    pacman.nextDirection = Direction.right;
    ghosts[0].pos = Position(9, 9);
    ghosts[1].pos = Position(8, 9);
    ghosts[2].pos = Position(10, 9);
    ghosts[3].pos = Position(9, 8);
  }
}

class GamePainter extends CustomPainter {
  final GameEngine engine;
  
  GamePainter({required this.engine});
  
  @override
  void paint(Canvas canvas, Size size) {
    double cellWidth = size.width / GameEngine.boardWidth;
    double cellHeight = size.height / GameEngine.boardHeight;
    
    // FIX: Safe maze drawing with boundary checks
    for (int y = 0; y < engine.maze.length && y < GameEngine.boardHeight; y++) {
      for (int x = 0; x < engine.maze[y].length && x < GameEngine.boardWidth; x++) {
        Rect rect = Rect.fromLTWH(x * cellWidth, y * cellHeight, cellWidth, cellHeight);
        
        if (engine.maze[y][x] == 1) {
          Paint wallPaint = Paint()..color = Colors.blue[900]!;
          canvas.drawRect(rect, wallPaint);
        } else if (engine.maze[y][x] == 0) {
          Paint dotPaint = Paint()..color = Colors.white;
          canvas.drawCircle(rect.center, cellWidth * 0.1, dotPaint);
        }
      }
    }
    
    // FIX: Safe dots drawing
    for (var dot in engine.dots) {
      if (dot.y >= 0 && dot.y < GameEngine.boardHeight && 
          dot.x >= 0 && dot.x < GameEngine.boardWidth) {
        Rect rect = Rect.fromLTWH(dot.x * cellWidth, dot.y * cellHeight, cellWidth, cellHeight);
        Paint dotPaint = Paint()..color = Colors.yellow;
        canvas.drawCircle(rect.center, cellWidth * 0.15, dotPaint);
      }
    }
    
    // Draw Pacman with safe position
    if (engine.pacman.pos.y >= 0 && engine.pacman.pos.y < GameEngine.boardHeight &&
        engine.pacman.pos.x >= 0 && engine.pacman.pos.x < GameEngine.boardWidth) {
      drawPacman(canvas, 
        engine.pacman.pos.x * cellWidth, 
        engine.pacman.pos.y * cellHeight, 
        cellWidth, cellHeight, 
        engine.pacman);
    }
    
    // Draw Ghosts with safe positions
    for (var ghost in engine.ghosts) {
      if (ghost.pos.y >= 0 && ghost.pos.y < GameEngine.boardHeight &&
          ghost.pos.x >= 0 && ghost.pos.x < GameEngine.boardWidth) {
        drawGhost(canvas, 
          ghost.pos.x * cellWidth, 
          ghost.pos.y * cellHeight, 
          cellWidth, cellHeight, 
          ghost.color);
      }
    }
  }
  
  void drawPacman(Canvas canvas, double x, double y, double w, double h, Pacman pacman) {
    Paint paint = Paint()..color = Colors.yellow;
    double radius = (w / 2) - 2;
    Offset center = Offset(x + w / 2, y + h / 2);
    
    double angle = pacman.mouthAngle * pi;
    double startAngle = -angle / 2;
    double sweepAngle = 2 * pi - angle;
    
    switch (pacman.direction) {
      case Direction.right:
        canvas.drawArc(Rect.fromCircle(center: center, radius: radius), startAngle, sweepAngle, true, paint);
        break;
      case Direction.left:
        canvas.drawArc(Rect.fromCircle(center: center, radius: radius), pi - startAngle, sweepAngle, true, paint);
        break;
      case Direction.up:
        canvas.drawArc(Rect.fromCircle(center: center, radius: radius), -pi/2 - startAngle, sweepAngle, true, paint);
        break;
      case Direction.down:
        canvas.drawArc(Rect.fromCircle(center: center, radius: radius), pi/2 - startAngle, sweepAngle, true, paint);
        break;
      default:
        canvas.drawCircle(center, radius, paint);
    }
  }
  
  void drawGhost(Canvas canvas, double x, double y, double w, double h, Color color) {
    Paint paint = Paint()..color = color;
    double radius = (w / 2) - 2;
    Offset center = Offset(x + w / 2, y + h / 2);
    
    Path path = Path();
    path.addArc(Rect.fromCircle(center: Offset(center.dx, center.dy - radius/2), radius: radius), 0, pi);
    path.lineTo(center.dx + radius, center.dy + radius/2);
    path.lineTo(center.dx + radius * 0.7, center.dy + radius/4);
    path.lineTo(center.dx + radius * 0.3, center.dy + radius/2);
    path.lineTo(center.dx - radius * 0.3, center.dy + radius/4);
    path.lineTo(center.dx - radius * 0.7, center.dy + radius/2);
    path.lineTo(center.dx - radius, center.dy + radius/2);
    path.close();
    
    canvas.drawPath(path, paint);
    
    Paint eyePaint = Paint()..color = Colors.white;
    canvas.drawCircle(Offset(center.dx - radius/2, center.dy - radius/3), radius/4, eyePaint);
    canvas.drawCircle(Offset(center.dx + radius/2, center.dy - radius/3), radius/4, eyePaint);
    
    eyePaint.color = Colors.black;
    canvas.drawCircle(Offset(center.dx - radius/2, center.dy - radius/3), radius/8, eyePaint);
    canvas.drawCircle(Offset(center.dx + radius/2, center.dy - radius/3), radius/8, eyePaint);
  }
  
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}