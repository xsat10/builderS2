import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/neo_skin.dart';

class NeoThemeProvider extends ChangeNotifier {
  static const _isDarkPreferenceKey = 'neo_theme_is_dark';

  bool _isDark = true;

  bool get isDark => _isDark;

  ThemeMode get themeMode => _isDark ? ThemeMode.dark : ThemeMode.light;

  String get skinId => NeoSkinId.midnight;

  NeoPalette get palette => NeoSkin.byId[NeoSkinId.midnight]!;

  Future<void> loadFromDisk() async {
    final preferences = await SharedPreferences.getInstance();
    final storedIsDark = preferences.getBool(_isDarkPreferenceKey);
    if (storedIsDark != null && storedIsDark != _isDark) {
      _isDark = storedIsDark;
      notifyListeners();
    }
  }

  Future<void> toggle() async {
    final nextIsDark = !_isDark;
    final preferences = await SharedPreferences.getInstance();
    final saved = await preferences.setBool(_isDarkPreferenceKey, nextIsDark);
    if (!saved) {
      throw StateError('Unable to save the selected theme preference.');
    }

    _isDark = nextIsDark;
    notifyListeners();
  }
}
