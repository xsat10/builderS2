import 'package:flutter/material.dart';
import 'chart_page.dart';
import 'trade_page.dart';
import 'quote_page.dart';
import 'riwayat_trade.dart';
import 'trading_models.dart';

// ─── MAIN TRADING PAGE — Neon Purple Elegant ─────────────────────────────
class MainTradingPage extends StatefulWidget {
  final String sessionKey;
  final String role;

  const MainTradingPage({
    Key? key,
    required this.sessionKey,
    required this.role,
  }) : super(key: key);

  @override
  State<MainTradingPage> createState() => _MainTradingPageState();
}

class _MainTradingPageState extends State<MainTradingPage>
    with SingleTickerProviderStateMixin {
  int _currentIndex = 0;
  late PageController _pageController;
  late AnimationController _animationController;

  // ─── NAVIGATION ITEMS (4 tab) ────────────────────────────────────────
  final List<NavItem> _navItems = const [
    NavItem(icon: Icons.area_chart_rounded, label: 'Chart'),
    NavItem(icon: Icons.swap_horiz_rounded, label: 'Trade'),
    NavItem(icon: Icons.trending_up_rounded, label: 'Quote'),
    NavItem(icon: Icons.history_rounded, label: 'Riwayat'),
  ];

  @override
  void initState() {
    super.initState();
    _pageController = PageController(initialPage: _currentIndex);
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    _animationController.forward();
  }

  @override
  void dispose() {
    _pageController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  void _onNavTap(int index) {
    if (_currentIndex == index) return;
    setState(() {
      _currentIndex = index;
      _animationController.reset();
      _animationController.forward();
    });
    _pageController.animateToPage(
      index,
      duration: const Duration(milliseconds: 350),
      curve: Curves.easeInOutCubic,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: TradingTheme.bg,
      body: Container(
        decoration: const BoxDecoration(gradient: TradingTheme.bgGradient),
        child: SafeArea(
          child: Column(
            children: [
              // ─── HEADER ──────────────────────────────────────────────
              _buildHeader(),
              // ─── PAGE VIEW ──────────────────────────────────────────
              Expanded(
                child: PageView(
                  controller: _pageController,
                  physics: const NeverScrollableScrollPhysics(),
                  children: [
                    ChartPage(
                      sessionKey: widget.sessionKey,
                      role: widget.role,
                      onTradePressed: () => _onNavTap(1),
                      onQuotePressed: () => _onNavTap(2),
                      onHistoryPressed: () => _onNavTap(3),
                    ),
                    TradePage(
                      sessionKey: widget.sessionKey,
                      role: widget.role,
                      onChartPressed: () => _onNavTap(0),
                      onQuotePressed: () => _onNavTap(2),
                      onHistoryPressed: () => _onNavTap(3),
                    ),
                    QuotePage(
                      sessionKey: widget.sessionKey,
                      role: widget.role,
                      onChartPressed: () => _onNavTap(0),
                      onTradePressed: () => _onNavTap(1),
                      onHistoryPressed: () => _onNavTap(3),
                    ),
                    RiwayatTradePage(
                      sessionKey: widget.sessionKey,
                      role: widget.role,
                      onChartPressed: () => _onNavTap(0),
                      onTradePressed: () => _onNavTap(1),
                      onQuotePressed: () => _onNavTap(2),
                    ),
                  ],
                ),
              ),
              // ─── BOTTOM NAVIGATION ──────────────────────────────────
              _buildBottomNav(),
              const SizedBox(height: 10),
            ],
          ),
        ),
      ),
    );
  }

  // ─── HEADER ────────────────────────────────────────────────────────────
  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: TradingTheme.accentGradient,
              boxShadow: TradingTheme.neonGlow(TradingTheme.accent),
            ),
            child: const Icon(
              Icons.trending_up_rounded,
              color: Colors.white,
              size: 24,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'TRADING HUB',
                  style: TextStyle(
                    color: TradingTheme.textPrimary,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.5,
                    fontFamily: 'Astral',
                  ),
                ),
                Text(
                  '@${widget.role}',
                  style: const TextStyle(
                    color: TradingTheme.textSecondary,
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: TradingTheme.success.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: TradingTheme.success.withOpacity(0.3),
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 6,
                  height: 6,
                  decoration: const BoxDecoration(
                    color: TradingTheme.success,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 6),
                const Text(
                  'LIVE',
                  style: TextStyle(
                    color: TradingTheme.success,
                    fontSize: 9,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── BOTTOM NAVIGATION (neon purple glass pill) ──────────────────────
  Widget _buildBottomNav() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
      decoration: BoxDecoration(
        color: TradingTheme.card.withOpacity(0.85),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(
          color: TradingTheme.accent.withOpacity(0.22),
          width: 0.8,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 20,
            spreadRadius: 2,
          ),
          BoxShadow(
            color: TradingTheme.accent.withOpacity(0.12),
            blurRadius: 24,
            spreadRadius: -6,
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: List.generate(_navItems.length, (index) {
          final item = _navItems[index];
          final isActive = _currentIndex == index;
          return _buildNavItem(
            icon: item.icon,
            label: item.label,
            isActive: isActive,
            onTap: () => _onNavTap(index),
          );
        }),
      ),
    );
  }

  Widget _buildNavItem({
    required IconData icon,
    required String label,
    required bool isActive,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeInOut,
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
        decoration: BoxDecoration(
          color: isActive
              ? TradingTheme.accent.withOpacity(0.16)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(16),
          border: isActive
              ? Border.all(
                  color: TradingTheme.accent.withOpacity(0.4),
                  width: 0.8,
                )
              : null,
          boxShadow: isActive ? TradingTheme.neonGlow(TradingTheme.accent) : null,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              color: isActive ? TradingTheme.accentLight : TradingTheme.textSecondary,
              size: isActive ? 26 : 22,
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(
                color: isActive ? TradingTheme.textPrimary : TradingTheme.textSecondary,
                fontSize: isActive ? 11 : 10,
                fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
              ),
            ),
            if (isActive)
              Container(
                margin: const EdgeInsets.only(top: 4),
                width: 20,
                height: 2,
                decoration: BoxDecoration(
                  gradient: TradingTheme.accentGradient,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

// ─── NAVIGATION ITEM MODEL ──────────────────────────────────────────────
class NavItem {
  final IconData icon;
  final String label;

  const NavItem({required this.icon, required this.label});
}
