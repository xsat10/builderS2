import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:ui';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'api_config.dart';

// ═══════════════════════════════════════════════════════════════════════════
// OWNER UTAMA PAGE — Tema "Gold Premium Luxury"
// UI: Kartu hitam-emas dengan garis diagonal shimmer, border gold gradient,
// aksen mewah untuk role tertinggi.
// ═══════════════════════════════════════════════════════════════════════════

const String _apiBase = 'http://shinoa-cpanelpanel.xtxintax.my.id:2003';

class OwnerUtamaPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const OwnerUtamaPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<OwnerUtamaPage> createState() => _OwnerUtamaPageState();
}

class _OwnerUtamaPageState extends State<OwnerUtamaPage> with SingleTickerProviderStateMixin {
  late String sessionKey;
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];

    final List<String> roleOptions = [
    'owner_utama',
    'owner',
    'staff',
    'executorius',
    'forius_utama',
    'moderator',
    'ceo_utama',
    'tangan_kanan',
    'tangan_kiri',
    'developers',
    'partner_pribadi',
    'partner',
    'admin',
    'reseller',
    'tukang_bubur',
    'vip',
    'member',
  ];

String selectedRole = 'member';



  int currentPage = 1;
  int itemsPerPage = 25;

  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  final deleteController = TextEditingController();
  final editUsernameController = TextEditingController();
  final editDayController = TextEditingController();

  String newUserRole = 'member';
  bool isLoading = false;

  late AnimationController _shimmerCtrl;

  // ── TEMA GOLD PREMIUM ──
  final Color bgDark = const Color(0xFF0A0806);
  final Color primaryGold = const Color(0xFFD4AF37);
  final Color accentGold = const Color(0xFFF5D580);
  final Color primaryWhite = Colors.white;
  final Color textGrey = Colors.grey.shade400;
  final Color cardDark = const Color(0xFF15130E);
  final Color borderGold = const Color(0xFFD4AF37).withOpacity(0.25);

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    _shimmerCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat();
    _fetchUsers();
  }

  @override
  void dispose() {
    _shimmerCtrl.dispose();
    super.dispose();
  }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse('$_apiBase/listUsers?key=$sessionKey'));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _alert("Info", data['message'] ?? 'Gagal memuat user.');
      }
    } catch (_) {
      _alert("Error", "Gagal terhubung ke server.");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList = fullUserList.where((u) => u['role'] == selectedRole).toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = (start + itemsPerPage);
    return filteredList.sublist(start, end > filteredList.length ? filteredList.length : end);
  }

  int get totalPages => (filteredList.length / itemsPerPage).ceil().clamp(1, 9999);

  Future<void> _deleteUser() async {
    final username = deleteController.text.trim();
    if (username.isEmpty) {
      _alert("Peringatan", "Masukkan username yang ingin dihapus.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse('$_apiBase/deleteUser?key=$sessionKey&username=$username'));
      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        _alert("Sukses", "User berhasil dihapus.");
        deleteController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal menghapus user.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _createAccount() async {
    final u = createUsernameController.text.trim();
    final p = createPasswordController.text.trim();
    final d = createDayController.text.trim();
    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final url = Uri.parse('$_apiBase/userAdd?key=$sessionKey&username=$u&password=$p&day=$d&role=$newUserRole');
      final res = await http.get(url);
      final data = jsonDecode(res.body);
      if (data['created'] == true) {
        _alert("Sukses", "Akun berhasil dibuat sebagai ${newUserRole.toUpperCase()}.");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        newUserRole = 'member';
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal membuat akun.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _editUser() async {
    final u = editUsernameController.text.trim();
    final d = editDayController.text.trim();
    if (u.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final url = Uri.parse('$_apiBase/editUser?key=$sessionKey&username=$u&addDays=$d');
      final res = await http.get(url);
      final data = jsonDecode(res.body);
      if (data['edited'] == true) {
        _alert("Sukses", "Durasi berhasil diperbarui.");
        editUsernameController.clear();
        editDayController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal mengubah durasi.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  void _alert(String title, String message) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: cardDark,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: BorderSide(color: borderGold)),
        title: Row(children: [
          Icon(FontAwesomeIcons.crown, color: accentGold, size: 18),
          const SizedBox(width: 10),
          Text(title, style: TextStyle(color: primaryWhite)),
        ]),
        content: Text(message, style: TextStyle(color: textGrey)),
        actions: [
          Center(
            child: Container(
              decoration: BoxDecoration(gradient: LinearGradient(colors: [primaryGold, accentGold]), borderRadius: BorderRadius.circular(12)),
              child: TextButton(onPressed: () => Navigator.pop(context), child: Text("OK", style: TextStyle(color: bgDark, fontWeight: FontWeight.bold))),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInput({required String label, required TextEditingController controller, required IconData icon, TextInputType type = TextInputType.text}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextField(
        controller: controller,
        keyboardType: type,
        style: TextStyle(color: primaryWhite),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: accentGold),
          prefixIcon: Icon(icon, color: accentGold, size: 18),
          filled: true,
          fillColor: Colors.black.withOpacity(0.3),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: borderGold)),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: borderGold)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: accentGold, width: 1.6)),
        ),
      ),
    );
  }

  // Kartu dengan garis diagonal shimmer gold yang bergerak halus
  Widget _buildLuxuryCard({required String title, required IconData icon, required List<Widget> children}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 22),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: LinearGradient(
          begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: [primaryGold.withOpacity(0.5), Colors.transparent, primaryGold.withOpacity(0.2)],
        ),
      ),
      padding: const EdgeInsets.all(1.2),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(19),
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(color: cardDark, borderRadius: BorderRadius.circular(19)),
          child: Stack(
            children: [
              Positioned.fill(
                child: AnimatedBuilder(
                  animation: _shimmerCtrl,
                  builder: (context, _) => ClipRRect(
                    borderRadius: BorderRadius.circular(19),
                    child: Align(
                      alignment: Alignment(-1.5 + 3 * _shimmerCtrl.value, -1),
                      child: Transform.rotate(
                        angle: -0.6,
                        child: Container(
                          width: 40, height: 400,
                          color: accentGold.withOpacity(0.035),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: primaryGold.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: borderGold),
                        ),
                        child: Icon(icon, color: accentGold, size: 18),
                      ),
                      const SizedBox(width: 12),
                      Text(title, style: TextStyle(color: primaryWhite, fontSize: 15, fontWeight: FontWeight.bold, letterSpacing: 1.2)),
                    ],
                  ),
                  const SizedBox(height: 20),
                  ...children,
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildUserItem(Map user) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(color: Colors.black.withOpacity(0.3), borderRadius: BorderRadius.circular(14), border: Border.all(color: borderGold)),
      child: Row(
        children: [
          Container(
            width: 34, height: 34,
            decoration: BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [primaryGold, accentGold])),
            child: Icon(FontAwesomeIcons.crown, color: bgDark, size: 14),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(user['username'] ?? '-', style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold, fontSize: 14)),
                const SizedBox(height: 3),
                Text("ROLE: ${(user['role'] ?? '-').toString().toUpperCase()} | EXP: ${user['expiredDate'] ?? '-'}", style: TextStyle(color: textGrey, fontSize: 11.5)),
              ],
            ),
          ),
          IconButton(
            icon: Icon(FontAwesomeIcons.trashCan, color: accentGold.withOpacity(0.85), size: 16),
            onPressed: () async {
              final confirm = await showDialog<bool>(
                context: context,
                builder: (_) => AlertDialog(
                  backgroundColor: cardDark,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: borderGold)),
                  title: Text("Konfirmasi", style: TextStyle(color: primaryWhite)),
                  content: Text("Hapus user ini?", style: TextStyle(color: textGrey)),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context, false), child: Text("Batal", style: TextStyle(color: textGrey))),
                    TextButton(onPressed: () => Navigator.pop(context, true), child: Text("Hapus", style: TextStyle(color: accentGold))),
                  ],
                ),
              );
              if (confirm == true) {
                deleteController.text = user['username'];
                _deleteUser();
              }
            },
          ),
        ],
      ),
    );
  }

  Widget _buildPagination() {
    return Wrap(
      spacing: 8, runSpacing: 8,
      children: List.generate(totalPages, (index) {
        final page = index + 1;
        final active = currentPage == page;
        return GestureDetector(
          onTap: () => setState(() => currentPage = page),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              gradient: active ? LinearGradient(colors: [primaryGold, accentGold]) : null,
              color: active ? null : Colors.transparent,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: active ? accentGold : borderGold),
            ),
            child: Text("$page", style: TextStyle(color: active ? bgDark : textGrey, fontSize: 12, fontWeight: active ? FontWeight.bold : FontWeight.normal)),
          ),
        );
      }),
    );
  }

  Widget _buildGoldButton({required String label, required IconData icon, required VoidCallback? onPressed}) {
    return Container(
      height: 52,
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [primaryGold, accentGold]),
        borderRadius: BorderRadius.circular(12),
        boxShadow: [BoxShadow(color: primaryGold.withOpacity(0.4), blurRadius: 16, offset: const Offset(0, 6))],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: onPressed,
          child: Center(
            child: isLoading
                ? SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: bgDark))
                : Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [Icon(icon, size: 17, color: bgDark), const SizedBox(width: 8), Text(label, style: TextStyle(color: bgDark, fontWeight: FontWeight.bold, letterSpacing: 1))],
                  ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter, end: Alignment.bottomCenter,
            colors: [bgDark, primaryGold.withOpacity(0.06), bgDark],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 20),
            child: Column(
              children: [
                Row(children: [
                  IconButton(icon: Icon(Icons.arrow_back_ios_new_rounded, color: accentGold, size: 18), onPressed: () => Navigator.pop(context)),
                ]),
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(colors: [primaryGold.withOpacity(0.3), Colors.transparent]),
                    border: Border.all(color: accentGold.withOpacity(0.6), width: 2),
                    boxShadow: [BoxShadow(color: primaryGold.withOpacity(0.35), blurRadius: 24, spreadRadius: 2)],
                  ),
                  child: Icon(FontAwesomeIcons.crown, color: accentGold, size: 34),
                ),
                const SizedBox(height: 14),
                ShaderMask(
                  shaderCallback: (bounds) => LinearGradient(colors: [primaryGold, accentGold, primaryGold]).createShader(bounds),
                  child: const Text(
                    "OWNER UTAMA",
                    style: TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.w900, letterSpacing: 3),
                  ),
                ),
                const SizedBox(height: 4),
                Text("Kendali penuh seluruh sistem & akun", style: TextStyle(color: textGrey, fontSize: 12.5)),
                const SizedBox(height: 30),

                _buildLuxuryCard(
                  title: "DELETE USER",
                  icon: FontAwesomeIcons.userSlash,
                  children: [
                    _buildInput(label: "Username Target", controller: deleteController, icon: FontAwesomeIcons.user),
                    const SizedBox(height: 6),
                    _buildGoldButton(label: "DELETE ACCOUNT", icon: FontAwesomeIcons.trashCan, onPressed: isLoading ? null : _deleteUser),
                  ],
                ),

                _buildLuxuryCard(
                  title: "CREATE ACCOUNT",
                  icon: FontAwesomeIcons.userPlus,
                  children: [
                    _buildInput(label: "Username", controller: createUsernameController, icon: FontAwesomeIcons.user),
                    _buildInput(label: "Password", controller: createPasswordController, icon: FontAwesomeIcons.lock),
                    _buildInput(label: "Durasi (Hari)", controller: createDayController, icon: FontAwesomeIcons.calendarDay, type: TextInputType.number),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                      decoration: BoxDecoration(color: Colors.black.withOpacity(0.3), borderRadius: BorderRadius.circular(12), border: Border.all(color: borderGold)),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                          value: newUserRole,
                          dropdownColor: cardDark,
                          isExpanded: true,
                          style: TextStyle(color: primaryWhite),
                          items: roleOptions.map((role) => DropdownMenuItem(value: role, child: Text(role.toUpperCase()))).toList(),
                          onChanged: (val) => setState(() => newUserRole = val ?? 'member'),
                        ),
                      ),
                    ),
                    const SizedBox(height: 18),
                    _buildGoldButton(label: "CREATE ACCOUNT", icon: FontAwesomeIcons.userPlus, onPressed: isLoading ? null : _createAccount),
                  ],
                ),

                _buildLuxuryCard(
                  title: "EXTEND DURATION",
                  icon: FontAwesomeIcons.clock,
                  children: [
                    _buildInput(label: "Username Target", controller: editUsernameController, icon: FontAwesomeIcons.userPen),
                    _buildInput(label: "Tambah Hari", controller: editDayController, icon: FontAwesomeIcons.calendarPlus, type: TextInputType.number),
                    const SizedBox(height: 6),
                    _buildGoldButton(label: "ADD DAYS", icon: FontAwesomeIcons.calendarPlus, onPressed: isLoading ? null : _editUser),
                  ],
                ),

                _buildLuxuryCard(
                  title: "USER LIST",
                  icon: FontAwesomeIcons.users,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                      decoration: BoxDecoration(color: Colors.black.withOpacity(0.3), borderRadius: BorderRadius.circular(12), border: Border.all(color: borderGold)),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                          value: selectedRole,
                          dropdownColor: cardDark,
                          isExpanded: true,
                          style: TextStyle(color: primaryWhite),
                          items: roleOptions.map((role) => DropdownMenuItem(value: role, child: Text(role.toUpperCase()))).toList(),
                          onChanged: (val) {
                            if (val != null) {
                              selectedRole = val;
                              _filterAndPaginate();
                            }
                          },
                        ),
                      ),
                    ),
                    const SizedBox(height: 18),
                    isLoading
                        ? Padding(padding: const EdgeInsets.all(20), child: Center(child: CircularProgressIndicator(color: accentGold)))
                        : filteredList.isEmpty
                            ? Padding(padding: const EdgeInsets.symmetric(vertical: 30), child: Center(child: Text("Tidak ada user pada role ini", style: TextStyle(color: textGrey))))
                            : Column(children: [..._getCurrentPageData().map((u) => _buildUserItem(u)).toList(), const SizedBox(height: 16), _buildPagination()]),
                  ],
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
