import 'package:flutter/material.dart';

// ============================================================
// 📌 TRADING THEME — Neon Purple Elegant
// ============================================================
// Satu-satunya sumber warna & style untuk seluruh modul trading.
// Semua nama member di bawah ini SENGAJA lengkap (termasuk alias
// seperti white/textPrimary, grey/textSecondary) supaya semua
// halaman (chart/trade/quote/riwayat/main) tetap kompatibel
// walau menggunakan penamaan yang berbeda-beda.
class TradingTheme {
  // ── Base surfaces (deep purple-black, bukan hitam polos) ──
  static const Color bg = Color(0xFF0B0417);
  static const Color bgLight = Color(0xFF160A2E);
  static const Color card = Color(0xFF190B32);
  static const Color cardAlt = Color(0xFF221142);
  static const Color cardHover = Color(0xFF2C1856);
  static const Color border = Color(0xFF3B1F63);
  static const Color borderLit = Color(0xFF8B5CF6);

  // ── Neon purple accent (dipakai untuk chrome/branding/glow) ──
  static const Color accent = Color(0xFFA855F7);
  static const Color accentDeep = Color(0xFF7C3AED);
  static const Color accentLight = Color(0xFFD9B8FF);

  // ── Semantic trading colors (tetap merah=sell, hijau=buy) ──
  static const Color primary = Color(0xFFFF3D8F); // neon pink-red (Sell)
  static const Color primaryDark = Color(0xFFC81E66);
  static const Color primaryLight = Color(0xFFFF6FAE);
  static const Color success = Color(0xFF00F5A0); // neon green (Buy)
  static const Color successDark = Color(0xFF00C97F);
  static const Color warning = Color(0xFFFFC44D);
  static const Color warningDark = Color(0xFFE0A82E);

  // ── Text ──
  static const Color white = Color(0xFFF6F2FF);
  static const Color textPrimary = white; // alias
  static const Color white87 = Color(0xDEF6F2FF);
  static const Color white54 = Color(0x8AF6F2FF);
  static const Color white24 = Color(0x3DF6F2FF);
  static const Color grey = Color(0xFFA394C7);
  static const Color textSecondary = grey; // alias
  static const Color textDim = Color(0xFF564A78);

  static const Color shadow = Color(0x66000000);
  static const Color glass = Color(0x1AFFFFFF);

  // ── Gradients ──
  static const LinearGradient primaryGradient = LinearGradient(
    colors: [Color(0xFFFF3D8F), Color(0xFFFF6FAE)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient successGradient = LinearGradient(
    colors: [Color(0xFF00F5A0), Color(0xFF00C97F)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient accentGradient = LinearGradient(
    colors: [Color(0xFFA855F7), Color(0xFF7C3AED)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient bgGradient = LinearGradient(
    colors: [Color(0xFF0B0417), Color(0xFF160A2E)],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );

  static const LinearGradient glassGradient = LinearGradient(
    colors: [Color(0x1FFFFFFF), Color(0x0AFFFFFF)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  // Non-const getter (Border.all bukan factory const, jadi tidak bisa
  // dipakai di dalam "static const" — inilah salah satu penyebab error
  // build sebelumnya). Dipanggil sebagai TradingTheme.glassDecoration().
  static BoxDecoration glassDecoration() => BoxDecoration(
        gradient: glassGradient,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: accent.withOpacity(0.18)),
        boxShadow: [
          BoxShadow(color: shadow, blurRadius: 20, spreadRadius: 2),
          BoxShadow(
            color: accent.withOpacity(0.12),
            blurRadius: 24,
            spreadRadius: -4,
          ),
        ],
      );

  // Glow shadow siap pakai untuk tombol/kartu aktif bertema neon purple.
  static List<BoxShadow> neonGlow([Color? color]) => [
        BoxShadow(
          color: (color ?? accent).withOpacity(0.35),
          blurRadius: 16,
          spreadRadius: 0,
        ),
        BoxShadow(
          color: (color ?? accent).withOpacity(0.15),
          blurRadius: 28,
          spreadRadius: 2,
        ),
      ];
}

// ============================================================
// 📌 MODELS
// ============================================================
class CandleData {
  final double open;
  final double close;
  final double high;
  final double low;
  final DateTime time;
  final int volume;

  CandleData({
    required this.open,
    required this.close,
    required this.high,
    required this.low,
    required this.time,
    required this.volume,
  });

  bool get isBullish => close >= open;
  double get range => high - low;
  double get body => (open - close).abs();
}

class Position {
  final String id;
  final String symbol;
  final String type; // 'buy' or 'sell'
  final double volume;
  final double entryPrice;
  double currentPrice; // mutable — diupdate real-time
  final DateTime openTime;
  double pnl;

  Position({
    required this.id,
    required this.symbol,
    required this.type,
    required this.volume,
    required this.currentPrice,
    required this.entryPrice,
    required this.openTime,
    required this.pnl,
  });

  bool get isProfit => pnl >= 0;
  double get priceChange => currentPrice - entryPrice;
  double get changePercent => (priceChange / entryPrice) * 100;
}

class Quote {
  final String symbol;
  final String displayName;
  final double bid;
  final double ask;
  final double change;
  final double changePercent;
  final DateTime lastUpdate;
  final double low;
  final double high;
  bool isWatching;

  Quote({
    required this.symbol,
    required this.displayName,
    required this.bid,
    required this.ask,
    required this.change,
    required this.changePercent,
    required this.lastUpdate,
    required this.low,
    required this.high,
    this.isWatching = false,
  });

  bool get isUp => changePercent >= 0;
  double get spread => ask - bid;
}

class TradeHistory {
  final String id;
  final String symbol;
  final String type; // 'open', 'close'
  final double volume;
  final double entryPrice;
  final double closePrice;
  final double pnl;
  final DateTime timestamp;
  final String status; // 'completed', 'pending'

  TradeHistory({
    required this.id,
    required this.symbol,
    required this.type,
    required this.volume,
    required this.entryPrice,
    required this.closePrice,
    required this.pnl,
    required this.timestamp,
    required this.status,
  });

  bool get isProfitable => pnl >= 0;
  bool get isCompleted => status == 'completed';
}

class SymbolData {
  final String symbol;
  final String displayName;
  final double price;
  final double change;
  final double changePercent;
  final double buy;
  final double sell;
  final double low;
  final double high;

  const SymbolData({
    required this.symbol,
    required this.displayName,
    required this.price,
    required this.change,
    required this.changePercent,
    required this.buy,
    required this.sell,
    required this.low,
    required this.high,
  });

  bool get isUp => changePercent >= 0;
  double get spread => sell - buy;
}

class Order {
  final String id;
  final String symbol;
  final String type; // 'buy' or 'sell'
  final double volume;
  final double price;
  final DateTime createdAt;
  final String status; // 'pending', 'filled', 'cancelled'

  Order({
    required this.id,
    required this.symbol,
    required this.type,
    required this.volume,
    required this.price,
    required this.createdAt,
    required this.status,
  });

  bool get isBuy => type == 'buy';
  bool get isFilled => status == 'filled';
}

// ============================================================
// 📌 UTILITIES
// ============================================================
class TradingUtils {
  static String formatPrice(double price) {
    if (price > 1000) return price.toStringAsFixed(2);
    return price.toStringAsFixed(4);
  }

  static String formatCurrency(double value) {
    if (value >= 1000000) return '${(value / 1000000).toStringAsFixed(2)}M';
    if (value >= 1000) return '${(value / 1000).toStringAsFixed(2)}K';
    return value.toStringAsFixed(2);
  }

  static String formatDateTime(DateTime dt) {
    final diff = DateTime.now().difference(dt);
    if (diff.inMinutes < 1) return 'Baru saja';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    if (diff.inDays < 7) return '${diff.inDays}d ago';
    return '${dt.day}/${dt.month}/${dt.year}';
  }

  static Color getChangeColor(double value) {
    if (value > 0) return TradingTheme.success;
    if (value < 0) return TradingTheme.primary;
    return TradingTheme.grey;
  }

  static String getFormattedChange(double value) {
    if (value > 0) return '+${value.toStringAsFixed(2)}';
    return value.toStringAsFixed(2);
  }

  static IconData getOrderTypeIcon(String type) => type == 'buy'
      ? Icons.arrow_upward_rounded
      : Icons.arrow_downward_rounded;

  static Color getOrderTypeColor(String type) =>
      type == 'buy' ? TradingTheme.success : TradingTheme.primary;

  static String getOrderTypeLabel(String type) =>
      type == 'buy' ? 'BUY' : 'SELL';
}

// ============================================================
// 📌 ANIMATION HELPERS
// ============================================================
class TradingAnimations {
  static const Duration defaultDuration = Duration(milliseconds: 600);
  static const Duration chartDuration = Duration(milliseconds: 800);
  static const Duration slideDuration = Duration(milliseconds: 350);
  static const Curve defaultCurve = Curves.easeOutCubic;
  static const Curve chartCurve = Curves.easeOutBack;

  static Tween<Offset> slideFromRight() =>
      Tween<Offset>(begin: const Offset(1, 0), end: Offset.zero);
  static Tween<Offset> slideFromBottom() =>
      Tween<Offset>(begin: const Offset(0, 1), end: Offset.zero);
  static Tween<double> scaleIn() => Tween<double>(begin: 0.8, end: 1.0);
  static Tween<double> fadeIn() => Tween<double>(begin: 0.0, end: 1.0);
}

// ============================================================
// 📌 DEFAULT SYMBOLS DATABASE
// ============================================================
class SymbolsDatabase {
  static const Map<String, SymbolData> defaultSymbols = {
    'ADAUSD': SymbolData(
      symbol: 'ADAUSD',
      displayName: 'Cardano vs US Dollar',
      price: 0.2130,
      change: -0.0020,
      changePercent: -0.93,
      buy: 0.2022,
      sell: 0.2027,
      low: 0.2020,
      high: 0.2171,
    ),
    'AUDCHF': SymbolData(
      symbol: 'AUDCHF',
      displayName: 'Australian Dollar vs Swiss Franc',
      price: 0.5819,
      change: 0.0181,
      changePercent: 0.31,
      buy: 0.5795,
      sell: 0.5820,
      low: 0.5790,
      high: 0.5823,
    ),
    'AUDJPY': SymbolData(
      symbol: 'AUDJPY',
      displayName: 'Australian Dollar vs Japanese Yen',
      price: 114.64,
      change: 0.0000,
      changePercent: -0.02,
      buy: 114.50,
      sell: 114.65,
      low: 114.50,
      high: 114.96,
    ),
    'AUDNZD': SymbolData(
      symbol: 'AUDNZD',
      displayName: 'Australian Dollar vs New Zealand Dollar',
      price: 1.2110,
      change: 0.0232,
      changePercent: 0.19,
      buy: 1.2100,
      sell: 1.2113,
      low: 1.2072,
      high: 1.2120,
    ),
    'AUDUSD': SymbolData(
      symbol: 'AUDUSD',
      displayName: 'Australian Dollar vs US Dollar',
      price: 0.7155,
      change: -0.0338,
      changePercent: -0.47,
      buy: 0.7155,
      sell: 0.7161,
      low: 0.7155,
      high: 0.7207,
    ),
    'BTCUSD': SymbolData(
      symbol: 'BTCUSD',
      displayName: 'Bitcoin vs US Dollar',
      price: 77670.00,
      change: 31900,
      changePercent: 0.41,
      buy: 77500.00,
      sell: 77697.00,
      low: 77200.00,
      high: 77800.00,
    ),
    'CADJPY': SymbolData(
      symbol: 'CADJPY',
      displayName: 'Canadian Dollar vs Japanese Yen',
      price: 114.64,
      change: 0.0081,
      changePercent: 0.07,
      buy: 114.50,
      sell: 114.65,
      low: 114.50,
      high: 115.32,
    ),
    'CHFJPY': SymbolData(
      symbol: 'CHFJPY',
      displayName: 'Swiss Franc vs Japanese Yen',
      price: 197.75,
      change: -0.0433,
      changePercent: -0.22,
      buy: 197.75,
      sell: 197.84,
      low: 197.68,
      high: 198.77,
    ),
    'CHFSGD': SymbolData(
      symbol: 'CHFSGD',
      displayName: 'Swiss Franc vs Singapore Dollar',
      price: 1.6004,
      change: 0.0025,
      changePercent: 0.16,
      buy: 1.5973,
      sell: 1.6010,
      low: 1.5973,
      high: 1.6010,
    ),
    'AUDCAD': SymbolData(
      symbol: 'AUDCAD',
      displayName: 'Australian Dollar vs Canadian Dollar',
      price: 0.9959,
      change: -0.0060,
      changePercent: -0.06,
      buy: 0.9951,
      sell: 0.9960,
      low: 0.9951,
      high: 0.9979,
    ),
  };
}
