import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../services/api_service.dart';
import '../widgets/app_toast.dart';
import '../widgets/glow_button.dart';
import '../widgets/glow_card.dart';
import '../widgets/loading_overlay.dart';

class SendMessageScreen extends StatefulWidget {
  const SendMessageScreen({super.key});

  @override
  State<SendMessageScreen> createState() => _SendMessageScreenState();
}

class _SendMessageScreenState extends State<SendMessageScreen> {
  final _destCtrl = TextEditingController();
  final _msgCtrl = TextEditingController();
  List<WaSession> _sessions = [];
  String? _sessionId;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _destCtrl.dispose();
    _msgCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final list = await ApiService.instance.getSessions();
      if (!mounted) return;
      setState(() {
        _sessions = list;
        _sessionId = list.isEmpty ? null : list.first.id;
      });
    } catch (e) {
      if (!mounted) return;
      showAppToast(context, e.toString(), error: true);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _submit() async {
    final sessionId = _sessionId;
    final dest = _destCtrl.text.replaceAll(RegExp(r'\D'), '');
    final message = _msgCtrl.text.trim();
    if (sessionId == null) {
      showAppToast(context, 'Pilih sesi pengirim', error: true);
      return;
    }
    if (dest.length < 10) {
      showAppToast(context, 'Nomor tujuan tidak valid', error: true);
      return;
    }
    if (message.isEmpty) {
      showAppToast(context, 'Pesan kosong', error: true);
      return;
    }
    setState(() => _loading = true);
    try {
      await ApiService.instance.sendMessage(
        sessionId: sessionId,
        number: dest,
        message: message,
      );
      if (!mounted) return;
      _msgCtrl.clear();
      showAppToast(context, 'Pesan terkirim');
    } catch (e) {
      if (!mounted) return;
      showAppToast(context, e.toString(), error: true);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: const Text('Kirim pesan'),
      ),
      body: LoadingOverlay(
        loading: _loading,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            GlowCard(
              glow: true,
              child: Column(
                children: [
                  DropdownButtonFormField<String>(
                    value: _sessionId,
                    dropdownColor: const Color(0xFF141414),
                    decoration: const InputDecoration(labelText: 'Sesi pengirim'),
                    items: _sessions
                        .map(
                          (s) => DropdownMenuItem(
                            value: s.id,
                            child: Text('${s.number} (${s.status})'),
                          ),
                        )
                        .toList(),
                    onChanged: (value) => setState(() => _sessionId = value),
                  ),
                  const SizedBox(height: 14),
                  TextField(
                    controller: _destCtrl,
                    keyboardType: TextInputType.phone,
                    decoration: const InputDecoration(labelText: 'Nomor tujuan'),
                  ),
                  const SizedBox(height: 14),
                  TextField(
                    controller: _msgCtrl,
                    minLines: 4,
                    maxLines: 8,
                    decoration: const InputDecoration(labelText: 'Pesan'),
                  ),
                  const SizedBox(height: 16),
                  GlowButton(label: 'Kirim', onPressed: _submit),
                ],
              ),
            ),
          ],
        ).animate().fadeIn(duration: 350.ms),
      ),
    );
  }
}
