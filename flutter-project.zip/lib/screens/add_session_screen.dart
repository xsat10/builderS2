import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../services/api_service.dart';
import '../widgets/app_toast.dart';
import '../widgets/glow_button.dart';
import '../widgets/glow_card.dart';
import '../widgets/loading_overlay.dart';

class AddSessionScreen extends StatefulWidget {
  const AddSessionScreen({super.key});

  @override
  State<AddSessionScreen> createState() => _AddSessionScreenState();
}

class _AddSessionScreenState extends State<AddSessionScreen> {
  final _numberCtrl = TextEditingController();
  bool _loading = false;
  String? _pairingCode;

  @override
  void dispose() {
    _numberCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final number = _numberCtrl.text.replaceAll(RegExp(r'\D'), '');
    if (number.length < 10) {
      showAppToast(
        context,
        'Masukkan nomor lengkap dengan kode negara',
        error: true,
      );
      return;
    }
    setState(() => _loading = true);
    try {
      final code = await ApiService.instance.addSession(number);
      if (!mounted) return;
      setState(() => _pairingCode = code);
      showAppToast(context, 'Pairing code dibuat');
    } catch (e) {
      if (!mounted) return;
      showAppToast(context, e.toString(), error: true);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _copy() async {
    final code = _pairingCode;
    if (code == null) return;
    await Clipboard.setData(ClipboardData(text: code.replaceAll('-', '')));
    if (!mounted) return;
    showAppToast(context, 'Kode disalin');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: const Text('Tambah sesi'),
      ),
      body: LoadingOverlay(
        loading: _loading,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const Text(
              'Nomor tanpa plus. Contoh: 628123456789',
              style: TextStyle(color: Color(0xFF8B8B90)),
            ),
            const SizedBox(height: 16),
            GlowCard(
              glow: true,
              child: Column(
                children: [
                  TextField(
                    controller: _numberCtrl,
                    keyboardType: TextInputType.phone,
                    decoration: const InputDecoration(
                      labelText: 'Nomor WhatsApp',
                    ),
                  ),
                  const SizedBox(height: 16),
                  GlowButton(label: 'Buat pairing code', onPressed: _submit),
                ],
              ),
            ),
            if (_pairingCode != null) ...[
              const SizedBox(height: 16),
              GlowCard(
                glow: true,
                child: Column(
                  children: [
                    const Text(
                      'PAIRING CODE',
                      style: TextStyle(
                        letterSpacing: 2,
                        color: Color(0xFF8B8B90),
                        fontSize: 12,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      _pairingCode!,
                      style: const TextStyle(
                        fontSize: 32,
                        letterSpacing: 4,
                        fontFamily: 'monospace',
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 16),
                    GlowButton(
                      label: 'Salin kode',
                      outlined: true,
                      onPressed: _copy,
                    ),
                  ],
                ),
              ),
            ],
          ],
        ).animate().fadeIn(duration: 350.ms),
      ),
    );
  }
}
