import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../services/api_service.dart';
import '../widgets/app_toast.dart';
import '../widgets/glow_button.dart';
import '../widgets/glow_card.dart';
import '../widgets/loading_overlay.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>
    with SingleTickerProviderStateMixin {
  final _userCtrl = TextEditingController(text: 'admin');
  final _passCtrl = TextEditingController();
  bool _loading = false;
  bool _passwordVisible = false;
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 2000),
      vsync: this,
    )..repeat();
    _pulseAnimation =
        Tween<double>(begin: 1, end: 1.05).animate(_pulseController);
  }

  @override
  void dispose() {
    _userCtrl.dispose();
    _passCtrl.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final username = _userCtrl.text.trim();
    final password = _passCtrl.text;
    if (username.isEmpty || password.isEmpty) {
      showAppToast(context, 'Username dan password wajib', error: true);
      return;
    }
    setState(() => _loading = true);
    try {
      await ApiService.instance.login(username, password);
      if (!mounted) return;
      showAppToast(context, 'Berhasil masuk');
      Navigator.of(context).pushReplacementNamed('/dashboard');
    } catch (e) {
      if (!mounted) return;
      showAppToast(context, e.toString(), error: true);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: LoadingOverlay(
        loading: _loading,
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  // Animated Logo Container
                  ScaleTransition(
                    scale: _pulseAnimation,
                    child: Container(
                      width: 120,
                      height: 120,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: const Color(0x0FFF0000),
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(
                          color: const Color(0x60FF0000),
                          width: 2,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFFFF0000).withOpacity(0.4),
                            blurRadius: 30,
                            spreadRadius: 2,
                          ),
                          BoxShadow(
                            color: const Color(0xFFFF0000).withOpacity(0.2),
                            blurRadius: 60,
                            spreadRadius: 10,
                          ),
                        ],
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          // Custom lock icon with animation
                          Container(
                            padding: const EdgeInsets.all(8),
                            child: CustomPaint(
                              size: const Size(48, 48),
                              painter: LockIconPainter(),
                            ),
                          ),
                        ],
                      ),
                    ),
                  )
                      .animate()
                      .slideY(
                        begin: -0.3,
                        end: 0,
                        duration: 600.ms,
                        curve: Curves.easeOutBack,
                      )
                      .fadeIn(duration: 300.ms),
                  const SizedBox(height: 24),

                  // Title section with staggered animation
                  const Text(
                    'NEVEX',
                    style: TextStyle(
                      fontSize: 42,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2.5,
                      color: Color(0xFFFFFFFF),
                    ),
                  )
                      .animate()
                      .fadeIn(
                        duration: 400.ms,
                        delay: 100.ms,
                      )
                      .slideY(
                        begin: 0.1,
                        end: 0,
                        duration: 400.ms,
                        delay: 100.ms,
                      ),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      border: Border.all(color: const Color(0xFFFF0000)),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: const Text(
                      'RED DARK ACCESS v3.1',
                      style: TextStyle(
                        fontSize: 11,
                        letterSpacing: 1.5,
                        color: Color(0xFFFF0000),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  )
                      .animate()
                      .fadeIn(
                        duration: 400.ms,
                        delay: 200.ms,
                      )
                      .slideY(
                        begin: 0.1,
                        end: 0,
                        duration: 400.ms,
                        delay: 200.ms,
                      ),
                  const SizedBox(height: 8),
                  const Text(
                    'Beep boop. Identify yourself.',
                    style: TextStyle(
                      fontSize: 12,
                      letterSpacing: 1,
                      color: Color(0xFF8B8B90),
                      fontStyle: FontStyle.italic,
                    ),
                  )
                      .animate()
                      .fadeIn(
                        duration: 400.ms,
                        delay: 300.ms,
                      ),
                  const SizedBox(height: 40),

                  // Form Container with animated appearance
                  GlowCard(
                    glow: true,
                    child: Column(
                      children: [
                        // Username field with icon
                        Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: const Color(0xFF333333),
                              width: 1,
                            ),
                          ),
                          child: Row(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(12),
                                child: CustomPaint(
                                  size: const Size(20, 20),
                                  painter: UserIconPainter(),
                                ),
                              ),
                              Expanded(
                                child: TextField(
                                  controller: _userCtrl,
                                  textInputAction: TextInputAction.next,
                                  style: const TextStyle(
                                    fontSize: 14,
                                    letterSpacing: 0.5,
                                  ),
                                  decoration: const InputDecoration(
                                    hintText: 'Your username',
                                    hintStyle: TextStyle(
                                      color: Color(0xFF666666),
                                      fontSize: 13,
                                    ),
                                    border: InputBorder.none,
                                    contentPadding: EdgeInsets.only(right: 12),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 14),

                        // Password field with icon and visibility toggle
                        Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: const Color(0xFF333333),
                              width: 1,
                            ),
                          ),
                          child: Row(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(12),
                                child: CustomPaint(
                                  size: const Size(20, 20),
                                  painter: LockIconSmallPainter(),
                                ),
                              ),
                              Expanded(
                                child: TextField(
                                  controller: _passCtrl,
                                  obscureText: !_passwordVisible,
                                  onSubmitted: (_) => _submit(),
                                  style: const TextStyle(
                                    fontSize: 14,
                                    letterSpacing: 0.5,
                                  ),
                                  decoration: const InputDecoration(
                                    hintText: 'Super secret password',
                                    hintStyle: TextStyle(
                                      color: Color(0xFF666666),
                                      fontSize: 13,
                                    ),
                                    border: InputBorder.none,
                                    contentPadding:
                                        EdgeInsets.only(right: 12, top: 12),
                                  ),
                                ),
                              ),
                              IconButton(
                                icon: Icon(
                                  _passwordVisible
                                      ? Icons.visibility
                                      : Icons.visibility_off,
                                  color: const Color(0xFF666666),
                                  size: 18,
                                ),
                                onPressed: () {
                                  setState(() {
                                    _passwordVisible = !_passwordVisible;
                                  });
                                },
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 20),
                        GlowButton(label: 'LOGIN // ACCESS', onPressed: _submit),
                      ],
                    ),
                  )
                      .animate()
                      .fadeIn(
                        duration: 400.ms,
                        delay: 400.ms,
                      )
                      .slideY(
                        begin: 0.1,
                        end: 0,
                        duration: 400.ms,
                        delay: 400.ms,
                      ),
                  const SizedBox(height: 32),

                  // Footer with animation
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 20,
                        height: 2,
                        color: const Color(0xFF333333),
                      ),
                      const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 12),
                        child: Text(
                          'CONTACT & DEV',
                          style: TextStyle(
                            fontSize: 10,
                            letterSpacing: 1,
                            color: Color(0xFF666666),
                          ),
                        ),
                      ),
                      Container(
                        width: 20,
                        height: 2,
                        color: const Color(0xFF333333),
                      ),
                    ],
                  )
                      .animate()
                      .fadeIn(
                        duration: 500.ms,
                        delay: 600.ms,
                      ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// Custom Painter for Lock Icon (Large)
class LockIconPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFFFF0000)
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final fillPaint = Paint()
      ..color = const Color(0xFFFF0000)
      ..style = PaintingStyle.fill;

    // Lock body
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(size.width * 0.2, size.height * 0.45, size.width * 0.6,
            size.height * 0.4),
        Radius.circular(size.width * 0.06),
      ),
      paint,
    );

    // Lock shackle (top arc)
    canvas.drawPath(
      Path()
        ..arcToPoint(
          Offset(size.width * 0.8, size.height * 0.45),
          radius: Radius.circular(size.width * 0.3),
          clockwise: true,
        ),
      paint,
    );

    // Lock hole/circle
    canvas.drawCircle(
      Offset(size.width * 0.5, size.height * 0.58),
      size.width * 0.06,
      fillPaint,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// Custom Painter for Lock Icon (Small)
class LockIconSmallPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF8B8B90)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final fillPaint = Paint()
      ..color = const Color(0xFF8B8B90)
      ..style = PaintingStyle.fill;

    // Lock body
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(size.width * 0.2, size.height * 0.5, size.width * 0.6,
            size.height * 0.35),
        Radius.circular(size.width * 0.08),
      ),
      paint,
    );

    // Lock shackle
    canvas.drawPath(
      Path()
        ..arcToPoint(
          Offset(size.width * 0.8, size.height * 0.5),
          radius: Radius.circular(size.width * 0.25),
          clockwise: true,
        ),
      paint,
    );

    // Lock hole
    canvas.drawCircle(
      Offset(size.width * 0.5, size.height * 0.6),
      size.width * 0.05,
      fillPaint,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// Custom Painter for User Icon
class UserIconPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF8B8B90)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    // Head circle
    canvas.drawCircle(
      Offset(size.width * 0.5, size.height * 0.3),
      size.width * 0.2,
      paint,
    );

    // Body/shoulders
    canvas.drawPath(
      Path()
        ..moveTo(size.width * 0.2, size.height * 0.5)
        ..cubicTo(
          size.width * 0.2,
          size.height * 0.65,
          size.width * 0.3,
          size.height * 0.8,
          size.width * 0.4,
          size.height * 0.9,
        )
        ..lineTo(size.width * 0.6, size.height * 0.9)
        ..cubicTo(
          size.width * 0.7,
          size.height * 0.8,
          size.width * 0.8,
          size.height * 0.65,
          size.width * 0.8,
          size.height * 0.5,
        ),
      paint,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
