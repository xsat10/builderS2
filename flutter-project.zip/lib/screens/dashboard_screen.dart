import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../services/api_service.dart';
import '../widgets/app_toast.dart';
import '../widgets/glow_button.dart';
import '../widgets/glow_card.dart';
import '../widgets/loading_overlay.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen>
    with SingleTickerProviderStateMixin {
  List<WaSession> _sessions = [];
  bool _loading = true;
  late AnimationController _animController;
  Map<String, Animation<double>> _itemAnimations = {};

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );
    _refresh();
  }

  @override
  void dispose() {
    _animController.dispose();
    super.dispose();
  }

  Future<void> _refresh() async {
    setState(() => _loading = true);
    try {
      final list = await ApiService.instance.getSessions();
      if (!mounted) return;
      setState(() {
        _sessions = list;
        _itemAnimations.clear();
        for (int i = 0; i < list.length; i++) {
          _itemAnimations[list[i].id] = Tween<double>(begin: 0, end: 1).animate(
            CurvedAnimation(
              parent: _animController,
              curve: Interval(
                i * 0.1,
                0.5 + i * 0.1,
                curve: Curves.easeOutCubic,
              ),
            ),
          );
        }
        _animController.forward(from: 0);
      });
    } catch (e) {
      if (!mounted) return;
      showAppToast(context, e.toString(), error: true);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _logout() async {
    await ApiService.instance.clearToken();
    if (!mounted) return;
    Navigator.of(context).pushNamedAndRemoveUntil('/login', (_) => false);
  }

  Future<void> _delete(WaSession session) async {
    setState(() => _loading = true);
    try {
      await ApiService.instance.deleteSession(session.id);
      if (!mounted) return;
      showAppToast(context, 'Sesi dihapus');
      await _refresh();
    } catch (e) {
      if (!mounted) return;
      showAppToast(context, e.toString(), error: true);
      setState(() => _loading = false);
    }
  }

  Color _statusColor(String status) {
    switch (status.toLowerCase()) {
      case 'connected':
      case 'open':
        return const Color(0xFF3DD68C);
      case 'pairing':
      case 'connecting':
        return const Color(0xFFF5A524);
      default:
        return const Color(0xFFFF0000);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: LoadingOverlay(
        loading: _loading,
        child: SafeArea(
          child: RefreshIndicator(
            color: const Color(0xFFFF0000),
            backgroundColor: const Color(0xFF141414),
            onRefresh: _refresh,
            child: ListView(
              padding: const EdgeInsets.all(20),
              children: [
                // Header with user greeting
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Dashboard',
                          style: TextStyle(
                            fontSize: 28,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1.2,
                          ),
                        )
                            .animate()
                            .slideX(
                              begin: -0.2,
                              end: 0,
                              duration: 400.ms,
                              curve: Curves.easeOutCubic,
                            )
                            .fadeIn(duration: 300.ms),
                        const SizedBox(height: 4),
                        Text(
                          'Sessions Active',
                          style: TextStyle(
                            fontSize: 12,
                            letterSpacing: 1,
                            color: const Color(0xFF8B8B90),
                          ),
                        )
                            .animate()
                            .slideX(
                              begin: -0.2,
                              end: 0,
                              duration: 400.ms,
                              delay: 50.ms,
                              curve: Curves.easeOutCubic,
                            )
                            .fadeIn(duration: 300.ms),
                      ],
                    ),
                    Container(
                      width: 50,
                      height: 50,
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: const Color(0xFF333333),
                          width: 2,
                        ),
                        borderRadius: BorderRadius.circular(12),
                        color: const Color(0x0FFF0000).withOpacity(0.1),
                      ),
                      child: Material(
                        color: Colors.transparent,
                        child: InkWell(
                          onTap: _logout,
                          child: Center(
                            child: CustomPaint(
                              size: const Size(24, 24),
                              painter: LogoutIconPainter(),
                            ),
                          ),
                        ),
                      ),
                    )
                        .animate()
                        .slideX(
                          begin: 0.2,
                          end: 0,
                          duration: 400.ms,
                          curve: Curves.easeOutCubic,
                        )
                        .fadeIn(duration: 300.ms),
                  ],
                ),
                const SizedBox(height: 20),

                // Action buttons
                GlowButton(
                  label: '+ ADD SESSION',
                  onPressed: () async {
                    await Navigator.of(context).pushNamed('/add-session');
                    _refresh();
                  },
                )
                    .animate()
                    .slideY(
                      begin: 0.1,
                      end: 0,
                      duration: 400.ms,
                      delay: 100.ms,
                      curve: Curves.easeOutCubic,
                    )
                    .fadeIn(duration: 300.ms),
                const SizedBox(height: 10),

                Row(
                  children: [
                    Expanded(
                      child: GlowButton(
                        label: 'SEND',
                        outlined: true,
                        onPressed: () {
                          Navigator.of(context).pushNamed('/send-message');
                        },
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: GlowButton(
                        label: 'REFRESH',
                        outlined: true,
                        onPressed: _refresh,
                      ),
                    ),
                  ],
                )
                    .animate()
                    .slideY(
                      begin: 0.1,
                      end: 0,
                      duration: 400.ms,
                      delay: 150.ms,
                      curve: Curves.easeOutCubic,
                    )
                    .fadeIn(duration: 300.ms),
                const SizedBox(height: 24),

                // Sessions list or empty state
                if (_sessions.isEmpty && !_loading)
                  GlowCard(
                    child: Column(
                      children: [
                        Container(
                          width: 80,
                          height: 80,
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: const Color(0xFF333333),
                              width: 2,
                            ),
                            borderRadius: BorderRadius.circular(16),
                            color: const Color(0x0FFF0000).withOpacity(0.1),
                          ),
                          child: Center(
                            child: CustomPaint(
                              size: const Size(40, 40),
                              painter: EmptyDeviceIconPainter(),
                            ),
                          ),
                        ),
                        const SizedBox(height: 16),
                        const Text(
                          'No Active Sessions',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            letterSpacing: 0.5,
                          ),
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          'Add a new session to get started',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 12,
                            color: Color(0xFF8B8B90),
                            letterSpacing: 0.3,
                          ),
                        ),
                      ],
                    ),
                  )
                      .animate()
                      .fadeIn(duration: 400.ms, delay: 200.ms)
                      .slideY(begin: 0.2, end: 0, duration: 400.ms, delay: 200.ms)
                else if (_sessions.isNotEmpty)
                  Column(
                    children: List.generate(_sessions.length, (index) {
                      final session = _sessions[index];
                      final anim = _itemAnimations[session.id] ??
                          AlwaysStoppedAnimation(1.0);
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: ScaleTransition(
                          scale: anim as Animation<double>,
                          child: DeviceSessionCard(
                            session: session,
                            statusColor: _statusColor(session.status),
                            onDelete: () => _delete(session),
                          ),
                        ),
                      );
                    }),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// Device Session Card Widget
class DeviceSessionCard extends StatefulWidget {
  final WaSession session;
  final Color statusColor;
  final VoidCallback onDelete;

  const DeviceSessionCard({
    required this.session,
    required this.statusColor,
    required this.onDelete,
  });

  @override
  State<DeviceSessionCard> createState() => _DeviceSessionCardState();
}

class _DeviceSessionCardState extends State<DeviceSessionCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _pulseController;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 2000),
      vsync: this,
    );
    if (widget.session.status.toLowerCase() == 'connected') {
      _pulseController.repeat();
    }
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isConnected = widget.session.status.toLowerCase() == 'connected';

    return GlowCard(
      glow: isConnected,
      child: Column(
        children: [
          // Device Header with phone-like display
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: widget.statusColor.withOpacity(0.3),
                width: 1,
              ),
              color: const Color(0xFFFFFFFF).withOpacity(0.05),
            ),
            child: Row(
              children: [
                // Phone-like device visualization
                Container(
                  width: 60,
                  height: 90,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(
                      color: widget.statusColor,
                      width: 2,
                    ),
                    color: const Color(0xFF0A0A0A),
                    boxShadow: [
                      BoxShadow(
                        color: widget.statusColor.withOpacity(0.2),
                        blurRadius: 8,
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ScaleTransition(
                        scale: Tween<double>(begin: 1, end: 1.1).animate(
                          CurvedAnimation(
                            parent: _pulseController,
                            curve: Curves.easeInOut,
                          ),
                        ),
                        child: Container(
                          width: 20,
                          height: 20,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: widget.statusColor,
                            boxShadow: [
                              BoxShadow(
                                color: widget.statusColor.withOpacity(0.5),
                                blurRadius: 8,
                                spreadRadius: isConnected ? 2 : 0,
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        isConnected ? 'ON' : 'OFF',
                        style: TextStyle(
                          fontSize: 8,
                          color: widget.statusColor,
                          fontWeight: FontWeight.w600,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.session.number,
                        style: const TextStyle(
                          fontSize: 16,
                          fontFamily: 'monospace',
                          fontWeight: FontWeight.w700,
                          letterSpacing: 0.5,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(4),
                          color: widget.statusColor.withOpacity(0.1),
                          border: Border.all(
                            color: widget.statusColor.withOpacity(0.3),
                          ),
                        ),
                        child: Text(
                          widget.session.status.toUpperCase(),
                          style: TextStyle(
                            color: widget.statusColor,
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                            letterSpacing: 0.8,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),

          // Action button
          SizedBox(
            width: double.infinity,
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: widget.onDelete,
                borderRadius: BorderRadius.circular(8),
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: const Color(0xFFFF0000),
                      width: 1,
                    ),
                    color: const Color(0xFF0A0A0A),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CustomPaint(
                        size: const Size(16, 16),
                        painter: DeleteIconPainter(),
                      ),
                      const SizedBox(width: 8),
                      const Text(
                        'REMOVE',
                        style: TextStyle(
                          color: Color(0xFFFF0000),
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          letterSpacing: 0.8,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// Custom Painters for Icons
class LogoutIconPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF8B8B90)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    // Arrow pointing out
    canvas.drawPath(
      Path()
        ..moveTo(size.width * 0.3, size.height * 0.2)
        ..lineTo(size.width * 0.7, size.height * 0.5)
        ..lineTo(size.width * 0.3, size.height * 0.8),
      paint,
    );

    // Door/box
    canvas.drawRect(
      Rect.fromLTWH(
        size.width * 0.05,
        size.height * 0.1,
        size.width * 0.35,
        size.height * 0.8,
      ),
      paint,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class EmptyDeviceIconPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF8B8B90)
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    // Phone body
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(
          size.width * 0.15,
          size.height * 0.1,
          size.width * 0.7,
          size.height * 0.8,
        ),
        Radius.circular(size.width * 0.08),
      ),
      paint,
    );

    // Screen
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(
          size.width * 0.2,
          size.height * 0.15,
          size.width * 0.6,
          size.height * 0.6,
        ),
        Radius.circular(size.width * 0.04),
      ),
      paint,
    );

    // Question mark
    const textPainter = TextPainter(
      text: TextSpan(
        text: '?',
        style: TextStyle(
          color: Color(0xFF8B8B90),
          fontSize: 24,
          fontWeight: FontWeight.bold,
        ),
      ),
      textDirection: TextDirection.ltr,
    );
    textPainter.layout();
    textPainter.paint(
      canvas,
      Offset(
        size.width * 0.5 - textPainter.width * 0.5,
        size.height * 0.35 - textPainter.height * 0.5,
      ),
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class DeleteIconPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFFFF0000)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    // Trash bin body
    canvas.drawPath(
      Path()
        ..moveTo(size.width * 0.2, size.height * 0.3)
        ..lineTo(size.width * 0.8, size.height * 0.3)
        ..lineTo(size.width * 0.7, size.height * 0.9)
        ..lineTo(size.width * 0.3, size.height * 0.9)
        ..close(),
      paint,
    );

    // Handle
    canvas.drawPath(
      Path()
        ..moveTo(size.width * 0.35, size.height * 0.1)
        ..lineTo(size.width * 0.65, size.height * 0.1),
      paint,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
