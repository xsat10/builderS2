class Api {
  static const String api = "https://ramjiprivate.sanzcloud.biz.id:25595";
}