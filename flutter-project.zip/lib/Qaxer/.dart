class Api {
  static const String api = "http://danmaunikah.r-cloud.my.id:2327";
}