import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:ui' as ui;

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pengaturan Tema',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: 'Roboto',
        scaffoldBackgroundColor: const Color(0xFFF7F2E7),
      ),
      home: const ThemaPage(),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
//  TEMA PAGE
// ══════════════════════════════════════════════════════════════════════════════
class ThemaPage extends StatefulWidget {
  const ThemaPage({super.key});

  @override
  State<ThemaPage> createState() => _ThemaPageState();
}

class _ThemaPageState extends State<ThemaPage> {
  // Aksen (biru)
  static const List<Color> _accentColors = [
    Color(0xFF2E75B6), // 0 - biru (default)
    Color(0xFF29B6F6), // 1 - light blue
    Color(0xFF7C4DFF), // 2 - ungu
    Color(0xFF00BFA5), // 3 - teal
    Color(0xFFFFA726), // 4 - orange
    Color(0xFFEF5350), // 5 - merah
    Color(0xFFEC407A), // 6 - pink
    Color(0xFF1A1A1A), // 7 - hitam
  ];

  // Latar (putih)
  static const List<Color> _bgColors = [
    Color(0xFFF0F4FA), // 0 - putih (default)
    Color(0xFFFFFDF5), // 1 - cream
    Color(0xFFFDF6E3), // 2 - beige
    Color(0xFFF5F5F5), // 3 - abu terang
    Color(0xFFFFFFFF), // 4 - putih total
    Color(0xFFE0E7EF), // 5 - abu kebiruan
    Color(0xFF1A1A2E), // 6 - navy (dark mode)
    Color(0xFF0A0A0A), // 7 - hitam (dark mode)
  ];

  int _selectedAccentIndex = 0;
  int _selectedBgIndex = 0;

  Color _customAccent = const Color(0xFF2E75B6);
  Color _customBg = const Color(0xFFF0F4FA);

  bool _isCustomAccent = false;
  bool _isCustomBg = false;

  bool _isDarkMode = false;

  bool _loading = true;

  static const String _prefAccent = 'theme_accent_color';
  static const String _prefBg = 'theme_bg_color';
  static const String _prefDark = 'theme_dark_mode';

  @override
  void initState() {
    super.initState();
    _loadTheme();
  }

  Future<void> _loadTheme() async {
    final prefs = await SharedPreferences.getInstance();
    final accent = prefs.getInt(_prefAccent);
    final bg = prefs.getInt(_prefBg);
    final dark = prefs.getBool(_prefDark) ?? false;

    if (mounted) {
      setState(() {
        _selectedAccentIndex = accent ?? 0;
        _selectedBgIndex = bg ?? 0;
        _isDarkMode = dark;
        _loading = false;
      });
    }
  }

  Future<void> _saveTheme() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_prefAccent, _selectedAccentIndex);
    await prefs.setInt(_prefBg, _selectedBgIndex);
    await prefs.setBool(_prefDark, _isDarkMode);

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('✅ Tema berhasil disimpan'),
        backgroundColor: _accentColor,
        behavior: SnackBarBehavior.floating,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  Future<void> _resetTheme() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16)),
        title: const Text('Reset Tema?',
            style: TextStyle(
                fontWeight: FontWeight.bold, fontSize: 16)),
        content: const Text(
            'Semua pengaturan tema akan kembali ke default.',
            style: TextStyle(fontSize: 13)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Batal', style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.redAccent,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8)),
            ),
            child: const Text('Reset',
                style: TextStyle(
                    color: Colors.white, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );

    if (confirm == true) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_prefAccent);
      await prefs.remove(_prefBg);
      await prefs.remove(_prefDark);
      if (!mounted) return;
      setState(() {
        _selectedAccentIndex = 0;
        _selectedBgIndex = 0;
        _isDarkMode = false;
        _isCustomAccent = false;
        _isCustomBg = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('🔄 Tema direset ke default'),
          backgroundColor: Colors.grey.shade800,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10)),
        ),
      );
    }
  }

  Color get _accentColor =>
      _isCustomAccent ? _customAccent : _accentColors[_selectedAccentIndex];

  Color get _bgColor =>
      _isCustomBg ? _customBg : _bgColors[_selectedBgIndex];

  bool get _isBgDark {
    if (_isDarkMode) return true;
    // Cek brightness dari warna bg
    return _bgColor.computeLuminance() < 0.3;
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      backgroundColor: _bgColor,
      body: Stack(
        children: [
          SafeArea(
            child: Column(
              children: [
                // Header
                _buildHeader(),

                // Content
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildPreviewCard(),
                        const SizedBox(height: 24),
                        _buildAccentColorSection(),
                        const SizedBox(height: 24),
                        _buildBgColorSection(),
                        const SizedBox(height: 24),
                        _buildSaveButton(),
                        const SizedBox(height: 12),
                        _buildResetButton(),
                        const SizedBox(height: 40),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Gantungan kanan atas
          Positioned(
            top: 50,
            right: 12,
            child: IgnorePointer(
              child: Image.asset(
                'assets/images/gantungan.png',
                width: 70,
                height: 70,
                fit: BoxFit.contain,
                errorBuilder: (_, __, ___) => const SizedBox.shrink(),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════════
  //  HEADER
  // ═══════════════════════════════════════════════════════════════════════
  Widget _buildHeader() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 20),
      decoration: BoxDecoration(
        color: _isBgDark ? const Color(0xFF1A1A2E) : Colors.white,
        border: Border(
          bottom: BorderSide(
            color: _isBgDark
                ? Colors.white.withValues(alpha: 0.1)
                : Colors.black.withValues(alpha: 0.05),
            width: 1,
          ),
        ),
      ),
      child: Center(
        child: Text(
          'PENGATURAN TEMA',
          style: TextStyle(
            color: _isBgDark ? Colors.white : const Color(0xFF1A1A1A),
            fontSize: 18,
            fontWeight: FontWeight.w900,
            letterSpacing: 2.5,
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════════
  //  PREVIEW TEMA
  // ═══════════════════════════════════════════════════════════════════════
  Widget _buildPreviewCard() {
    final cardBg = _isBgDark ? const Color(0xFF1E1E2E) : Colors.white;
    final textColor = _isBgDark ? Colors.white : const Color(0xFF1A1A1A);
    final textSubColor =
        _isBgDark ? Colors.white70 : const Color(0xFF888888);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: _isBgDark
              ? Colors.white.withValues(alpha: 0.08)
              : Colors.black.withValues(alpha: 0.06),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: _isBgDark ? 0.3 : 0.05),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'PREVIEW TEMA',
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.5,
              color: textSubColor,
            ),
          ),
          const SizedBox(height: 16),

          // Row 1: SYAM + bell
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: _isBgDark
                  ? Colors.white.withValues(alpha: 0.04)
                  : const Color(0xFFF8F9FB),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: _isBgDark
                    ? Colors.white.withValues(alpha: 0.06)
                    : Colors.black.withValues(alpha: 0.04),
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: _accentColor,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.bolt_rounded,
                      color: Colors.white, size: 22),
                ),
                const SizedBox(width: 12),
                Text(
                  'SYAM',
                  style: TextStyle(
                    color: textColor,
                    fontWeight: FontWeight.w900,
                    fontSize: 16,
                    letterSpacing: 1,
                  ),
                ),
                const Spacer(),
                Icon(Icons.notifications_none_rounded,
                    color: textSubColor, size: 22),
              ],
            ),
          ),

          const SizedBox(height: 10),

          // Row 2: Kartu Contoh + switch
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: _isBgDark
                  ? Colors.white.withValues(alpha: 0.04)
                  : const Color(0xFFF8F9FB),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: _isBgDark
                    ? Colors.white.withValues(alpha: 0.06)
                    : Colors.black.withValues(alpha: 0.04),
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(
                    color: _accentColor.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(Icons.dashboard_rounded,
                      color: _accentColor, size: 18),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Kartu Contoh',
                        style: TextStyle(
                          color: textColor,
                          fontWeight: FontWeight.bold,
                          fontSize: 13,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        'Dashboard mengikuti warna ini.',
                        style: TextStyle(
                          color: textSubColor,
                          fontSize: 10,
                        ),
                      ),
                    ],
                  ),
                ),
                // Switch
                Container(
                  width: 44,
                  height: 24,
                  decoration: BoxDecoration(
                    color: _accentColor,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Align(
                    alignment: Alignment.centerRight,
                    child: Container(
                      width: 20,
                      height: 20,
                      margin: const EdgeInsets.all(2),
                      decoration: const BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 14),

          // Divider
          Container(
            height: 1,
            color: _isBgDark
                ? Colors.white.withValues(alpha: 0.06)
                : Colors.black.withValues(alpha: 0.05),
          ),
          const SizedBox(height: 12),

          Text(
            'Teks sekunder & garis tepi otomatis menyesuaikan kontras.',
            style: TextStyle(color: textSubColor, fontSize: 10),
          ),

          const SizedBox(height: 16),

          // Buttons
          Row(
            children: [
              // Tombol Utama
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 20, vertical: 12),
                decoration: BoxDecoration(
                  color: _accentColor,
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [
                    BoxShadow(
                      color: _accentColor.withValues(alpha: 0.35),
                      blurRadius: 12,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: const Text(
                  'TOMBOL UTAMA',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 11,
                    letterSpacing: 1,
                  ),
                ),
              ),
              const SizedBox(width: 10),
              // Aksen Lembut
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 20, vertical: 12),
                decoration: BoxDecoration(
                  color: Colors.transparent,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: _accentColor.withValues(alpha: 0.5),
                    width: 1.5,
                  ),
                ),
                child: Text(
                  'AKSEN LEMBUT',
                  style: TextStyle(
                    color: _accentColor,
                    fontWeight: FontWeight.bold,
                    fontSize: 11,
                    letterSpacing: 1,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════════
  //  WARNA AKSEN
  // ═══════════════════════════════════════════════════════════════════════
  Widget _buildAccentColorSection() {
    final textColor = _isBgDark ? Colors.white : const Color(0xFF1A1A1A);
    final textSubColor =
        _isBgDark ? Colors.white70 : const Color(0xFF888888);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 4,
              height: 20,
              decoration: BoxDecoration(
                color: _accentColor,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(width: 10),
            Text(
              'WARNA ${_getAccentName().toUpperCase()} (AKSEN)',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w900,
                letterSpacing: 1,
                color: textColor,
              ),
            ),
          ],
        ),
        const SizedBox(height: 6),
        Text(
          'Mengubah warna utama tombol, highlight, dan aksen di semua halaman.',
          style: TextStyle(color: textSubColor, fontSize: 11),
        ),
        const SizedBox(height: 16),

        // Grid warna
        Wrap(
          spacing: 12,
          runSpacing: 12,
          children: [
            ...List.generate(_accentColors.length, (i) {
              final color = _accentColors[i];
              final isSelected =
                  !_isCustomAccent && _selectedAccentIndex == i;
              return _buildColorCircle(
                color: color,
                isSelected: isSelected,
                onTap: () => setState(() {
                  _selectedAccentIndex = i;
                  _isCustomAccent = false;
                }),
              );
            }),
            // Tombol custom (color picker)
            _buildCustomColorButton(
              isSelected: _isCustomAccent,
              currentColor: _customAccent,
              onTap: _openColorPicker,
              textColor: textColor,
            ),
          ],
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════════════════
  //  WARNA LATAR
  // ═══════════════════════════════════════════════════════════════════════
  Widget _buildBgColorSection() {
    final textColor = _isBgDark ? Colors.white : const Color(0xFF1A1A1A);
    final textSubColor =
        _isBgDark ? Colors.white70 : const Color(0xFF888888);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 4,
              height: 20,
              decoration: BoxDecoration(
                color: _accentColor,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(width: 10),
            Text(
              'WARNA PUTIH (LATAR)',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w900,
                letterSpacing: 1,
                color: textColor,
              ),
            ),
          ],
        ),
        const SizedBox(height: 6),
        Text(
          'Mengubah warna latar halaman & kartu. Gelap = mode gelap otomatis.',
          style: TextStyle(color: textSubColor, fontSize: 11),
        ),
        const SizedBox(height: 16),

        Wrap(
          spacing: 12,
          runSpacing: 12,
          children: [
            ...List.generate(_bgColors.length, (i) {
              final color = _bgColors[i];
              final isSelected = !_isCustomBg && _selectedBgIndex == i;
              return _buildColorCircle(
                color: color,
                isSelected: isSelected,
                onTap: () => setState(() {
                  _selectedBgIndex = i;
                  _isCustomBg = false;
                  _isDarkMode = color.computeLuminance() < 0.3;
                }),
              );
            }),
            _buildCustomColorButton(
              isSelected: _isCustomBg,
              currentColor: _customBg,
              onTap: _openColorPickerBg,
              textColor: textColor,
            ),
          ],
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════════════════
  //  BUTTONS
  // ═══════════════════════════════════════════════════════════════════════
  Widget _buildSaveButton() {
    return GestureDetector(
      onTap: _saveTheme,
      child: Container(
        width: double.infinity,
        height: 54,
        decoration: BoxDecoration(
          color: _accentColor,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: _accentColor.withValues(alpha: 0.4),
              blurRadius: 15,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.save_rounded, color: Colors.white, size: 20),
            SizedBox(width: 10),
            Text(
              'SIMPAN',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w900,
                fontSize: 15,
                letterSpacing: 2,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildResetButton() {
    return GestureDetector(
      onTap: _resetTheme,
      child: Container(
        width: double.infinity,
        height: 54,
        decoration: BoxDecoration(
          color: Colors.transparent,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Colors.redAccent, width: 1.5),
        ),
        child: const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.restart_alt_rounded,
                color: Colors.redAccent, size: 20),
            SizedBox(width: 10),
            Text(
              'RESET KE DEFAULT',
              style: TextStyle(
                color: Colors.redAccent,
                fontWeight: FontWeight.w900,
                fontSize: 13,
                letterSpacing: 2,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════════
  //  COLOR CIRCLE
  // ═══════════════════════════════════════════════════════════════════════
  Widget _buildColorCircle({
    required Color color,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    final isLight = color.computeLuminance() > 0.7;
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: 52,
        height: 52,
        decoration: BoxDecoration(
          color: color,
          shape: BoxShape.circle,
          border: Border.all(
            color: isSelected
                ? _accentColor
                : (isLight
                    ? Colors.black.withValues(alpha: 0.15)
                    : Colors.transparent),
            width: isSelected ? 3 : 1.5,
          ),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: _accentColor.withValues(alpha: 0.4),
                    blurRadius: 12,
                    spreadRadius: 1,
                  ),
                ]
              : [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.08),
                    blurRadius: 6,
                    offset: const Offset(0, 2),
                  ),
                ],
        ),
        child: isSelected
            ? Icon(
                Icons.check_rounded,
                color: isLight ? Colors.black87 : Colors.white,
                size: 26,
              )
            : null,
      ),
    );
  }

  Widget _buildCustomColorButton({
    required bool isSelected,
    required Color currentColor,
    required VoidCallback onTap,
    required Color textColor,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: 52,
        height: 52,
        decoration: BoxDecoration(
          color: _isBgDark
              ? Colors.white.withValues(alpha: 0.05)
              : Colors.white,
          shape: BoxShape.circle,
          border: Border.all(
            color: isSelected ? _accentColor : _accentColor.withValues(alpha: 0.5),
            width: isSelected ? 3 : 1.5,
          ),
        ),
        child: Icon(
          Icons.colorize_rounded,
          color: _accentColor,
          size: 22,
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════════
  //  COLOR PICKER DIALOG
  // ═══════════════════════════════════════════════════════════════════════
  void _openColorPicker() {
    _showColorPickerDialog(
      initialColor: _customAccent,
      title: 'Pilih Warna Aksen',
      onPicked: (color) {
        setState(() {
          _customAccent = color;
          _isCustomAccent = true;
        });
      },
    );
  }

  void _openColorPickerBg() {
    _showColorPickerDialog(
      initialColor: _customBg,
      title: 'Pilih Warna Latar',
      onPicked: (color) {
        setState(() {
          _customBg = color;
          _isCustomBg = true;
          _isDarkMode = color.computeLuminance() < 0.3;
        });
      },
    );
  }

  void _showColorPickerDialog({
    required Color initialColor,
    required String title,
    required Function(Color) onPicked,
  }) {
    Color tempColor = initialColor;
    double h = 0, s = 0, v = 0;
    HSVColor hsv = HSVColor.fromColor(initialColor);

    h = hsv.hue;
    s = hsv.saturation;
    v = hsv.value;

    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return Dialog(
              backgroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(24),
              ),
              insetPadding: const EdgeInsets.all(20),
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Area gradient
                    Container(
                      height: 280,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [
                            HSVColor.fromAHSV(1, h, 0, 1).toColor(),
                            HSVColor.fromAHSV(1, h, 1, 1).toColor(),
                            HSVColor.fromAHSV(1, h, 1, 0).toColor(),
                          ],
                          stops: const [0.0, 0.5, 1.0],
                        ),
                      ),
                      child: Stack(
                        children: [
                          // Pointer
                          Align(
                            alignment: Alignment(
                              (s * 2) - 1,
                              (v * 2) - 1,
                            ),
                            child: Container(
                              width: 24,
                              height: 24,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                    color: Colors.white, width: 3),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black
                                        .withValues(alpha: 0.3),
                                    blurRadius: 4,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 16),

                    // Preview + Hue slider
                    Row(
                      children: [
                        Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            color: tempColor,
                            shape: BoxShape.circle,
                            border: Border.all(
                                color: Colors.black.withValues(alpha: 0.1),
                                width: 1.5),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Container(
                            height: 12,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(6),
                              gradient: LinearGradient(
                                colors: List.generate(
                                  7,
                                  (i) => HSVColor.fromAHSV(
                                          1, i * 60.0, 1, 1)
                                      .toColor(),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 20),

                    // Actions
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: Text(
                            'Batal',
                            style: TextStyle(
                              color: Colors.grey.shade600,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        TextButton(
                          onPressed: () {
                            onPicked(tempColor);
                            Navigator.pop(context);
                          },
                          child: const Text(
                            'Pilih',
                            style: TextStyle(
                              color: Color(0xFF2E75B6),
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════════════════
  //  HELPERS
  // ═══════════════════════════════════════════════════════════════════════
  String _getAccentName() {
    if (_isCustomAccent) return 'KUSTOM';
    final idx = _selectedAccentIndex;
    const names = [
      'BIRU',
      'LIGHT BLUE',
      'UNGU',
      'TEAL',
      'ORANGE',
      'MERAH',
      'PINK',
      'HITAM',
    ];
    if (idx >= 0 && idx < names.length) return names[idx];
    return 'BIRU';
  }
}