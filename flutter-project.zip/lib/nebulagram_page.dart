// ═══════════════════════════════════════════════════════════════
//  NEBULAGRAM — Halaman Story
// ═══════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';
import 'story_service.dart';

// ─── COLORS ────────────────────────────────────────────────────────────────────
const Color kBg      = Color(0xFF0A1A3F);
const Color kCard    = Color(0xFF11285C);
const Color kBorder  = Color(0xFF2B4A8F);
const Color kCyan    = Color(0xFF00E5FF);
const Color kGreen   = Color(0xFF00E676);
const Color kOrange  = Color(0xFFFF6D00);
const Color kWhite   = Colors.white;
const Color kWhite54 = Colors.white54;
const Color kWhite24 = Colors.white24;

class NebulagramPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const NebulagramPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<NebulagramPage> createState() => _NebulagramPageState();
}

class _NebulagramPageState extends State<NebulagramPage> {
  List<Map<String, dynamic>> _stories = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadStories();
  }

  Future<void> _loadStories() async {
    if (!mounted) return;
    setState(() {
      _loading = true;
      _error = null;
    });

    final list = await StoryService.fetchStories(
      sessionKey: widget.sessionKey,
    );

    if (list.isEmpty) {
      final cached = await StoryService.getCachedStories();
      if (!mounted) return;
      setState(() {
        _stories = cached;
        _loading = false;
        if (cached.isEmpty) _error = 'Belum ada story.';
      });
      return;
    }

    await StoryService.cacheStories(list);
    if (!mounted) return;
    setState(() {
      _stories = list;
      _loading = false;
    });
  }

  Future<void> _showUploadSheet() async {
    showModalBottomSheet(
      context: context,
      backgroundColor: kCard,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        side: BorderSide(color: kBorder, width: 1.5),
      ),
      builder: (_) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: kWhite24,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 16),
              const Text(
                'BUAT STORY',
                style: TextStyle(
                  color: kWhite,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1.5,
                ),
              ),
              const SizedBox(height: 20),
              _uploadOption(
                icon: Icons.camera_alt,
                label: 'Kamera',
                color: kCyan,
                onTap: () {
                  Navigator.pop(context);
                  _pickMedia(ImageSource.camera);
                },
              ),
              const SizedBox(height: 10),
              _uploadOption(
                icon: Icons.photo_library,
                label: 'Galeri',
                color: kGreen,
                onTap: () {
                  Navigator.pop(context);
                  _pickMedia(ImageSource.gallery);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _uploadOption({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: kBg,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: color, width: 1.5),
          ),
          child: Row(
            children: [
              Icon(icon, color: color, size: 22),
              const SizedBox(width: 14),
              Text(
                label,
                style: const TextStyle(
                  color: kWhite,
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                ),
              ),
              const Spacer(),
              Icon(Icons.arrow_forward_ios, color: color, size: 14),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _pickMedia(ImageSource src) async {
    final picker = ImagePicker();
    final x = await picker.pickImage(source: src, imageQuality: 85);
    if (x == null) return;
    final file = File(x.path);

    if (!mounted) return;
    setState(() => _loading = true);

    final result = await StoryService.uploadStory(
      sessionKey: widget.sessionKey,
      username: widget.username,
      type: 'image',
      mediaFile: file,
    );

    if (!mounted) return;
    setState(() => _loading = false);

    if (result != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('✅ Story berhasil diupload'),
          backgroundColor: kGreen,
        ),
      );
      _loadStories();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('❌ Gagal upload story'),
          backgroundColor: Colors.redAccent,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: kBg,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: kWhite, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        centerTitle: true,
        title: const Text(
          'NEBULAGRAM',
          style: TextStyle(
            color: kWhite,
            fontSize: 15,
            fontWeight: FontWeight.bold,
            fontFamily: 'Orbitron',
            letterSpacing: 2,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.add_circle_outline, color: kCyan),
            onPressed: _showUploadSheet,
          ),
        ],
      ),
      body: _loading
          ? const Center(
              child:
                  CircularProgressIndicator(color: kCyan, strokeWidth: 2),
            )
          : _error != null && _stories.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.auto_stories,
                          color: kWhite24, size: 64),
                      const SizedBox(height: 16),
                      Text(_error!,
                          style: const TextStyle(color: kWhite54)),
                      const SizedBox(height: 16),
                      ElevatedButton.icon(
                        onPressed: _showUploadSheet,
                        icon: const Icon(Icons.add),
                        label: const Text('Buat Story'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: kCyan,
                          foregroundColor: Colors.black,
                        ),
                      ),
                    ],
                  ),
                )
              : RefreshIndicator(
                  color: kCyan,
                  backgroundColor: kCard,
                  onRefresh: _loadStories,
                  child: GridView.builder(
                    padding: const EdgeInsets.all(12),
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                      crossAxisSpacing: 8,
                      mainAxisSpacing: 8,
                      childAspectRatio: 0.75,
                    ),
                    itemCount: _stories.length,
                    itemBuilder: (_, i) =>
                        _buildStoryCard(_stories[i]),
                  ),
                ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: kCyan,
        onPressed: _showUploadSheet,
        child: const Icon(Icons.add, color: Colors.black),
      ),
    );
  }

  Widget _buildStoryCard(Map<String, dynamic> s) {
    final mediaUrl = s['mediaUrl']?.toString() ?? '';
    final type = s['type']?.toString() ?? 'image';
    final uname = s['username']?.toString() ?? '?';

    return GestureDetector(
      onTap: () => _openStoryViewer(s),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: kCard,
          border: Border.all(color: kBorder, width: 1.5),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(11),
          child: Stack(
            fit: StackFit.expand,
            children: [
              // Media
              if (type == 'image' && mediaUrl.isNotEmpty)
                Image.network(
                  mediaUrl,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const Center(
                    child: Icon(Icons.broken_image,
                        color: kWhite24, size: 30),
                  ),
                )
              else if (type == 'video' && mediaUrl.isNotEmpty)
                Container(
                  color: Colors.black,
                  child: const Center(
                    child: Icon(Icons.play_circle,
                        color: kWhite, size: 40),
                  ),
                )
              else
                const Center(
                  child:
                      Icon(Icons.image, color: kWhite24, size: 40),
                ),
              // Gradient overlay
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.transparent,
                      Colors.black.withValues(alpha: 0.8),
                    ],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                ),
              ),
              // Username
              Positioned(
                left: 6,
                right: 6,
                bottom: 6,
                child: Text(
                  uname,
                  style: const TextStyle(
                    color: kWhite,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              // Badge "LIVE"
              Positioned(
                top: 6,
                left: 6,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: kOrange,
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: const Text(
                    'STORY',
                    style: TextStyle(
                      color: kWhite,
                      fontSize: 8,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _openStoryViewer(Map<String, dynamic> s) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withValues(alpha: 0.9),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.all(16),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: kWhite, width: 2),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(14),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Media full
                AspectRatio(
                  aspectRatio: 3 / 4,
                  child: s['type'] == 'image'
                      ? Image.network(
                          s['mediaUrl']?.toString() ?? '',
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) =>
                              Container(color: kCard),
                        )
                      : Container(
                          color: Colors.black,
                          child: const Center(
                            child: Icon(Icons.play_circle,
                                color: kWhite, size: 60),
                          ),
                        ),
                ),
                // Footer
                Container(
                  padding: const EdgeInsets.all(12),
                  color: kCard,
                  child: Row(
                    children: [
                      const Icon(Icons.person, color: kCyan, size: 16),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          s['username']?.toString() ?? '?',
                          style: const TextStyle(
                            color: kWhite,
                            fontWeight: FontWeight.bold,
                            fontSize: 13,
                          ),
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.close,
                            color: kWhite, size: 20),
                        onPressed: () => Navigator.pop(context),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}