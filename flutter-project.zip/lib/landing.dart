import 'servers.dart';
import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:http/http.dart' as http;
import 'package:device_info_plus/device_info_plus.dart';
import 'login_page.dart';
import 'utils/update_checker.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  // ─── 🏁 BMW M GARAGE PALETTE ─────────────────────
  static const Color garageBlack   = Color(0xFF0A0A0A);   // Base asphalt
  static const Color carbonDark    = Color(0xFF121212);   // Carbon fiber dark
  static const Color surfaceColor  = Color(0xFF161616);   // Surface panel
  static const Color cardColor     = Color(0xFF1A1A1A);   // Card panel
  static const Color chromeSilver  = Color(0xFFC8C8C8);   // Chrome trim
  static const Color bmwLightBlue  = Color(0xFF0066B1);   // BMW M Light Blue
  static const Color bmwDarkBlue   = Color(0xFF0F3D77);   // BMW M Dark Blue
  static const Color bmwRed        = Color(0xFFE32119);   // BMW M Red
  static const Color bmwBlueGlow   = Color(0xFF1C69D4);   // Electric blue glow
  static const Color textPrimary   = Color(0xFFF5F5F5);
  static const Color textSecondary = Color(0xFF9E9E9E);
  static const Color dividerColor  = Color(0xFF2A2A2A);
  static const Color telegramBlue  = Color(0xFF29A9EB);
  static const Color emailRed      = Color(0xFFE32119);

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with SingleTickerProviderStateMixin {
  late VideoPlayerController _videoController;
  bool _isVideoInitialized = false;
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<double> _logoScale;
  late Animation<Offset> _titleSlide;
  late Animation<double> _cardOpacity;
  late Animation<double> _buttonSlide;

  String? androidId;
  String baseUrl = "";

  @override
  void initState() {
    super.initState();

    _videoController = VideoPlayerController.asset("assets/videos/glich.mp4")
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() => _isVideoInitialized = true);
        _videoController.setLooping(true);
        _videoController.setVolume(1);
        _videoController.play();
      });

    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    );

    _fadeAnimation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: const Interval(0.0, 0.4, curve: Curves.easeOut),
      ),
    );

    _logoScale = Tween<double>(begin: 0.5, end: 1).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: const Interval(0.1, 0.5, curve: Curves.elasticOut),
      ),
    );

    _titleSlide = Tween<Offset>(
      begin: const Offset(0, 30),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: const Interval(0.3, 0.7, curve: Curves.easeOut),
      ),
    );

    _cardOpacity = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: const Interval(0.4, 0.8, curve: Curves.easeInOut),
      ),
    );

    _buttonSlide = Tween<double>(begin: 50, end: 0).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: const Interval(0.6, 1.0, curve: Curves.easeOutBack),
      ),
    );

    _animationController.forward();

    _initLanding();
  }

  Future<void> _initLanding() async {
    await loadConfig();
    androidId = await getAndroidId();
    if (!mounted) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      checkForUpdate(context);
    });
  }

  Future<void> loadConfig() async {
    try {
      final response = await http.get(
        Uri.parse(
            Servers.configUrl),
      );
      final data = jsonDecode(response.body);
      baseUrl = data['base_url'];
    } catch (e) {
      // ignore, keep default
    }
  }

  Future<String> getAndroidId() async {
    final DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
    final android = await deviceInfo.androidInfo;
    return android.id;
  }

  @override
  void dispose() {
    _videoController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  void _showError(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: LandingPage.cardColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: BorderSide(
            color: LandingPage.bmwRed.withOpacity(0.6),
            width: 1.2,
          ),
        ),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: LandingPage.bmwRed.withOpacity(0.15),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.warning_amber_rounded,
                color: LandingPage.bmwRed,
                size: 20,
              ),
            ),
            const SizedBox(width: 10),
            const Text(
              'SYSTEM ERROR',
              style: TextStyle(
                color: LandingPage.textPrimary,
                fontFamily: 'Orbitron',
                letterSpacing: 1.5,
                fontSize: 15,
              ),
            ),
          ],
        ),
        content: Text(
          message,
          style: const TextStyle(color: LandingPage.textSecondary),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              'ACKNOWLEDGE',
              style: TextStyle(
                color: LandingPage.bmwBlueGlow,
                fontWeight: FontWeight.bold,
                letterSpacing: 1,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // 🏁 M-Stripe Widget
  Widget _mStripe({double height = 3, double width = 40}) {
    return Container(
      height: height,
      width: width,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(2),
        gradient: const LinearGradient(
          colors: [
            LandingPage.bmwLightBlue,
            LandingPage.bmwDarkBlue,
            LandingPage.bmwRed,
          ],
          stops: [0.0, 0.5, 1.0],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: LandingPage.garageBlack,
      body: Stack(
        children: [
          // ─── CARBON FIBER GRADIENT BACKGROUND ───
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    LandingPage.carbonDark,
                    LandingPage.garageBlack,
                    Color(0xFF050505),
                  ],
                ),
              ),
            ),
          ),

          // ─── RADIAL BLUE HEADLIGHT GLOW ───
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: const Alignment(-0.8, -0.7),
                  radius: 1.4,
                  colors: [
                    LandingPage.bmwBlueGlow.withOpacity(0.12),
                    Colors.transparent,
                    Colors.transparent,
                  ],
                  stops: const [0.0, 0.5, 1.0],
                ),
              ),
            ),
          ),

          // ─── RED VIGNETTE GLOW (Tail light) ───
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: const Alignment(1.0, 1.0),
                  radius: 1.2,
                  colors: [
                    LandingPage.bmwRed.withOpacity(0.08),
                    Colors.transparent,
                  ],
                  stops: const [0.0, 1.0],
                ),
              ),
            ),
          ),

          // ─── CARBON GRID PATTERN ───
          Positioned.fill(
            child: CustomPaint(painter: _GridPainter()),
          ),

          // ─── SCROLLABLE CONTENT ───
          SafeArea(
            child: LayoutBuilder(
              builder: (context, constraints) {
                return SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  child: ConstrainedBox(
                    constraints:
                        BoxConstraints(minHeight: constraints.maxHeight),
                    child: Center(
                      child: Container(
                        constraints: const BoxConstraints(maxWidth: 600),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 24, vertical: 20),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            // ─── TOP M-STRIPE BAR ───
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 14, vertical: 8),
                              decoration: BoxDecoration(
                                color: LandingPage.cardColor.withOpacity(0.7),
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(
                                  color: LandingPage.chromeSilver
                                      .withOpacity(0.2),
                                ),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Container(
                                    width: 8,
                                    height: 8,
                                    decoration: BoxDecoration(
                                      color: LandingPage.bmwBlueGlow,
                                      shape: BoxShape.circle,
                                      boxShadow: [
                                        BoxShadow(
                                          color: LandingPage.bmwBlueGlow
                                              .withOpacity(0.8),
                                          blurRadius: 8,
                                          spreadRadius: 1,
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  Text(
                                    "BAVARIAN MOTOR WORKS  ///M DIVISION",
                                    style: TextStyle(
                                      color: LandingPage.chromeSilver
                                          .withOpacity(0.8),
                                      fontSize: 9,
                                      letterSpacing: 2,
                                      fontFamily: 'ShareTechMono',
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ),

                            const SizedBox(height: 20),

                            // ─── VIDEO BANNER (Windshield / Dashboard style) ───
                            ScaleTransition(
                              scale: _logoScale,
                              child: Stack(
                                alignment: Alignment.center,
                                children: [
                                  // Outer glow
                                  Container(
                                    width: 340,
                                    height: 190,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(16),
                                      boxShadow: [
                                        BoxShadow(
                                          color: LandingPage.bmwBlueGlow
                                              .withOpacity(0.35),
                                          blurRadius: 40,
                                          spreadRadius: 5,
                                        ),
                                      ],
                                    ),
                                  ),
                                  // Frame
                                  Container(
                                    width: 320,
                                    height: 170,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(14),
                                      border: Border.all(
                                        color: LandingPage.chromeSilver
                                            .withOpacity(0.5),
                                        width: 1.5,
                                      ),
                                      gradient: LinearGradient(
                                        colors: [
                                          LandingPage.bmwLightBlue
                                              .withOpacity(0.3),
                                          LandingPage.chromeSilver
                                              .withOpacity(0.15),
                                          LandingPage.bmwRed.withOpacity(0.3),
                                        ],
                                        stops: const [0.0, 0.5, 1.0],
                                      ),
                                    ),
                                    padding: const EdgeInsets.all(3),
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(11),
                                      child: _isVideoInitialized
                                          ? FittedBox(
                                              fit: BoxFit.cover,
                                              child: SizedBox(
                                                width: _videoController
                                                    .value.size.width,
                                                height: _videoController
                                                    .value.size.height,
                                                child: VideoPlayer(
                                                    _videoController),
                                              ),
                                            )
                                          : const Center(
                                              child: CircularProgressIndicator(
                                                color: LandingPage.bmwBlueGlow,
                                                strokeWidth: 2,
                                              ),
                                            ),
                                    ),
                                  ),
                                  // Corner accents (M-stripe)
                                  Positioned(
                                    top: 0,
                                    left: 20,
                                    right: 20,
                                    child: _mStripe(
                                        height: 3, width: double.infinity),
                                  ),
                                ],
                              ),
                            ),

                            const SizedBox(height: 30),

                            // ─── TITLE ───
                            SlideTransition(
                              position: _titleSlide,
                              child: Column(
                                children: [
                                  // ✅ FIX: textBaseline DIHAPUS (bukan parameter Text)
                                  //         Tetap pakai strutStyle + height 1.0 + letterSpacing rapat
                                  ShaderMask(
                                    shaderCallback: (bounds) => const LinearGradient(
                                      begin: Alignment.topCenter,
                                      end: Alignment.bottomCenter,
                                      colors: [
                                        Color(0xFFFFFFFF),
                                        Color(0xFFC8C8C8),
                                        Color(0xFF7A7A7A),
                                      ],
                                      stops: [0.0, 0.5, 1.0],
                                    ).createShader(bounds),
                                    child: const Text(
                                      "GHOST",
                                      textAlign: TextAlign.center,
                                      maxLines: 1,
                                      softWrap: false,
                                      strutStyle: StrutStyle(
                                        fontFamily: 'Orbitron',
                                        fontSize: 56,
                                        height: 1.0,
                                        forceStrutHeight: true,
                                      ),
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 56,
                                        fontWeight: FontWeight.w900,
                                        letterSpacing: 6,
                                        height: 1.0,
                                        fontFamily: 'Orbitron',
                                        leadingDistribution:
                                            TextLeadingDistribution.even,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 14),
                                  // M-Stripe divider
                                  _mStripe(height: 3, width: 120),
                                  const SizedBox(height: 14),
                                  // Subtitle
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 16, vertical: 6),
                                    decoration: BoxDecoration(
                                      color: LandingPage.cardColor
                                          .withOpacity(0.6),
                                      borderRadius: BorderRadius.circular(20),
                                      border: Border.all(
                                        color: LandingPage.bmwBlueGlow
                                            .withOpacity(0.4),
                                        width: 1,
                                      ),
                                    ),
                                    child: const Text(
                                      "/// M POWER EDITION",
                                      style: TextStyle(
                                        color: LandingPage.chromeSilver,
                                        fontSize: 10,
                                        fontWeight: FontWeight.bold,
                                        letterSpacing: 4,
                                        fontFamily: 'ShareTechMono',
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),

                            const SizedBox(height: 32),

                            // ─── WELCOME CARD (Dashboard Panel) ───
                            FadeTransition(
                              opacity: _cardOpacity,
                              child: Container(
                                width: double.infinity,
                                padding: const EdgeInsets.symmetric(
                                    vertical: 26, horizontal: 20),
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                    colors: [
                                      LandingPage.cardColor.withOpacity(0.85),
                                      LandingPage.carbonDark.withOpacity(0.9),
                                    ],
                                  ),
                                  borderRadius: BorderRadius.circular(16),
                                  border: Border.all(
                                    color: LandingPage.chromeSilver
                                        .withOpacity(0.18),
                                    width: 1,
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.5),
                                      blurRadius: 25,
                                      spreadRadius: 2,
                                    ),
                                    BoxShadow(
                                      color: LandingPage.bmwBlueGlow
                                          .withOpacity(0.08),
                                      blurRadius: 30,
                                      spreadRadius: 2,
                                    ),
                                  ],
                                ),
                                child: Column(
                                  children: [
                                    // BMW Roundel-inspired icon
                                    Container(
                                      padding: const EdgeInsets.all(10),
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        gradient: const LinearGradient(
                                          colors: [
                                            LandingPage.bmwLightBlue,
                                            LandingPage.bmwDarkBlue,
                                            LandingPage.bmwRed,
                                          ],
                                          stops: [0.0, 0.5, 1.0],
                                        ),
                                        boxShadow: [
                                          BoxShadow(
                                            color: LandingPage.bmwBlueGlow
                                                .withOpacity(0.5),
                                            blurRadius: 15,
                                          ),
                                        ],
                                      ),
                                      child: const Icon(
                                        Icons.directions_car_filled_rounded,
                                        color: Colors.white,
                                        size: 26,
                                      ),
                                    ),
                                    const SizedBox(height: 14),
                                    const Text(
                                      "GHOSTCRASHER",
                                      style: TextStyle(
                                        color: LandingPage.textPrimary,
                                        fontSize: 22,
                                        fontWeight: FontWeight.bold,
                                        letterSpacing: 4,
                                        fontFamily: 'Orbitron',
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    _mStripe(height: 2, width: 60),
                                    const SizedBox(height: 14),
                                    const Text(
                                      "Precision-engineered application with elegant design & latest features. Built with the spirit of the M Division.",
                                      style: TextStyle(
                                        color: LandingPage.textSecondary,
                                        fontSize: 13,
                                        height: 1.6,
                                        fontWeight: FontWeight.w300,
                                      ),
                                      textAlign: TextAlign.center,
                                    ),
                                  ],
                                ),
                              ),
                            ),

                            const SizedBox(height: 28),

                            // ─── ACTION BUTTONS ───
                            AnimatedBuilder(
                              animation: _buttonSlide,
                              builder: (context, child) {
                                return Transform.translate(
                                  offset: Offset(0, _buttonSlide.value),
                                  child: child,
                                );
                              },
                              child: Column(
                                children: [
                                  _ElevatedButton(
                                    onPressed: () async {
                                      if (baseUrl.isEmpty) {
                                        await loadConfig();
                                      }
                                      if (!mounted) return;
                                      if (baseUrl.isEmpty) {
                                        _showError(
                                            "Server belum siap. Coba lagi nanti.");
                                        return;
                                      }
                                      Navigator.pushReplacement(
                                        context,
                                        MaterialPageRoute(
                                          builder: (_) => const LoginPage(),
                                        ),
                                      );
                                    },
                                    label: "START ENGINE",
                                    icon: Icons.power_settings_new_rounded,
                                  ),
                                  const SizedBox(height: 14),
                                  _OutlinedButton(
                                    onPressed: () =>
                                        _openUrl("https://t.me/Skylinnereal"),
                                    label: "PIT STOP / SUPPORT",
                                    icon: Icons.support_agent_rounded,
                                  ),
                                ],
                              ),
                            ),

                            const SizedBox(height: 32),

                            // ─── SOCIAL FOOTER (Garage Contact Panel) ───
                            Container(
                              width: double.infinity,
                              padding: const EdgeInsets.symmetric(
                                  vertical: 22, horizontal: 16),
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter,
                                  colors: [
                                    LandingPage.surfaceColor.withOpacity(0.7),
                                    LandingPage.carbonDark.withOpacity(0.8),
                                  ],
                                ),
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(
                                  color: LandingPage.chromeSilver
                                      .withOpacity(0.15),
                                  width: 1,
                                ),
                              ),
                              child: Column(
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Container(
                                        width: 6,
                                        height: 6,
                                        decoration: const BoxDecoration(
                                          color: LandingPage.bmwBlueGlow,
                                          shape: BoxShape.circle,
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      Text(
                                        "CONTACT THE CREW",
                                        style: TextStyle(
                                          color: LandingPage.chromeSilver
                                              .withOpacity(0.8),
                                          fontSize: 11,
                                          fontWeight: FontWeight.bold,
                                          letterSpacing: 3,
                                          fontFamily: 'Orbitron',
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      Container(
                                        width: 6,
                                        height: 6,
                                        decoration: const BoxDecoration(
                                          color: LandingPage.bmwRed,
                                          shape: BoxShape.circle,
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 18),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.center,
                                    children: [
                                      _SocialButton(
                                        icon: Icons.telegram,
                                        color: LandingPage.telegramBlue,
                                        url: "https://t.me/Skylinnereal",
                                        label: "Telegram",
                                      ),
                                      const SizedBox(width: 22),
                                      _SocialButton(
                                        icon: Icons.music_note_rounded,
                                        color: Colors.white,
                                        url: "https://tiktok.com/@skylinne18",
                                        label: "TikTok",
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 20),
                                  // M-stripe divider
                                  _mStripe(height: 2, width: double.infinity),
                                  const SizedBox(height: 14),
                                  Text(
                                    "© 2026 GHOSTCRASHER · ///M DIVISION",
                                    style: TextStyle(
                                      color: LandingPage.textSecondary
                                          .withOpacity(0.6),
                                      fontSize: 10,
                                      fontWeight: FontWeight.w400,
                                      letterSpacing: 1.5,
                                      fontFamily: 'ShareTechMono',
                                    ),
                                  ),
                                ],
                              ),
                            ),

                            const SizedBox(height: 20),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

// ─── CARBON GRID PAINTER ────────────────────────────────────────────────────
class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF1C69D4).withOpacity(0.04)
      ..strokeWidth = 0.5
      ..style = PaintingStyle.stroke;

    for (double x = 0; x < size.width; x += 50) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += 50) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ─── ELEVATED (M-STRIPE / RED GRADIENT) BUTTON ──────────────────────────────
class _ElevatedButton extends StatefulWidget {
  final VoidCallback onPressed;
  final String label;
  final IconData icon;

  const _ElevatedButton({
    required this.onPressed,
    required this.label,
    required this.icon,
  });

  @override
  State<_ElevatedButton> createState() => _ElevatedButtonState();
}

class _ElevatedButtonState extends State<_ElevatedButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scale;
  late Animation<double> _glow;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 200),
    );
    _scale = Tween<double>(begin: 1, end: 0.97).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
    _glow = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _controller.forward(),
      onTapUp: (_) {
        _controller.reverse();
        widget.onPressed();
      },
      onTapCancel: () => _controller.reverse(),
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, child) {
          return Transform.scale(
            scale: _scale.value,
            child: Container(
              height: 56,
              width: double.infinity,
              decoration: BoxDecoration(
                // M-STYLE GRADIENT: Light Blue → Dark Blue → Red
                gradient: const LinearGradient(
                  colors: [
                    LandingPage.bmwLightBlue,
                    LandingPage.bmwDarkBlue,
                    LandingPage.bmwRed,
                  ],
                  stops: [0.0, 0.5, 1.0],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: LandingPage.chromeSilver.withOpacity(0.35),
                  width: 1,
                ),
                boxShadow: [
                  BoxShadow(
                    color: LandingPage.bmwBlueGlow
                        .withOpacity(0.35 + _glow.value * 0.25),
                    blurRadius: 20,
                    spreadRadius: 1,
                  ),
                  BoxShadow(
                    color: LandingPage.bmwRed
                        .withOpacity(0.20 + _glow.value * 0.15),
                    blurRadius: 20,
                    offset: const Offset(6, 0),
                  ),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(widget.icon, color: Colors.white, size: 20),
                  const SizedBox(width: 10),
                  Text(
                    widget.label,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 2.5,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

// ─── OUTLINED (CHROME / BLUE BORDER) BUTTON ─────────────────────────────────
class _OutlinedButton extends StatefulWidget {
  final VoidCallback onPressed;
  final String label;
  final IconData icon;

  const _OutlinedButton({
    required this.onPressed,
    required this.label,
    required this.icon,
  });

  @override
  State<_OutlinedButton> createState() => _OutlinedButtonState();
}

class _OutlinedButtonState extends State<_OutlinedButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 200),
    );
    _scale = Tween<double>(begin: 1, end: 0.97).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _controller.forward(),
      onTapUp: (_) {
        _controller.reverse();
        widget.onPressed();
      },
      onTapCancel: () => _controller.reverse(),
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, child) {
          return Transform.scale(
            scale: _scale.value,
            child: Container(
              height: 56,
              width: double.infinity,
              decoration: BoxDecoration(
                color: LandingPage.cardColor.withOpacity(0.5),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: LandingPage.chromeSilver.withOpacity(0.5),
                  width: 1.2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.3),
                    blurRadius: 10,
                  ),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    widget.icon,
                    color: LandingPage.chromeSilver,
                    size: 20,
                  ),
                  const SizedBox(width: 10),
                  Text(
                    widget.label,
                    style: const TextStyle(
                      color: LandingPage.chromeSilver,
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 2,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

// ─── SOCIAL BUTTON (CIRCULAR, ROUNDEL STYLE) ────────────────────────────────
class _SocialButton extends StatefulWidget {
  final IconData icon;
  final Color color;
  final String url;
  final String label;

  const _SocialButton({
    required this.icon,
    required this.color,
    required this.url,
    required this.label,
  });

  @override
  State<_SocialButton> createState() => _SocialButtonState();
}

class _SocialButtonState extends State<_SocialButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 250),
    );
    _scale = Tween<double>(begin: 1, end: 1.12).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _launchURL() async {
    final Uri uri = Uri.parse(widget.url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch ${widget.url}");
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _controller.forward(),
      onTapUp: (_) {
        _controller.reverse();
        _launchURL();
      },
      onTapCancel: () => _controller.reverse(),
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, child) {
          return Transform.scale(
            scale: _scale.value,
            child: Column(
              children: [
                // BMW Roundel-style outer ring
                Container(
                  width: 54,
                  height: 54,
                  padding: const EdgeInsets.all(2),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const LinearGradient(
                      colors: [
                        LandingPage.bmwLightBlue,
                        LandingPage.bmwDarkBlue,
                        LandingPage.bmwRed,
                      ],
                      stops: [0.0, 0.5, 1.0],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: widget.color.withOpacity(0.3),
                        blurRadius: 15,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: LandingPage.garageBlack,
                      border: Border.all(
                        color: LandingPage.chromeSilver.withOpacity(0.3),
                        width: 0.5,
                      ),
                    ),
                    child: Center(
                      child: Icon(
                        widget.icon,
                        color: widget.color,
                        size: 22,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  widget.label,
                  style: const TextStyle(
                    color: LandingPage.textSecondary,
                    fontSize: 11,
                    fontWeight: FontWeight.w500,
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}