import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:video_player/video_player.dart'; // Sesuai pubspec.yaml
import 'api_config.dart';
import 'login_page.dart';

// ─── Palette: Dark Blue Navy Theme (Sesuai Foto) ────────────────────────────────
class _C {
  static const bg         = Color(0xFF0B132B); // Latar belakang biru gelap
  static const surface    = Color(0xFF1C2541); 
  static const card       = Color(0xFF1C2541); 
  static const border     = Color(0xFF3A506B); 
  
  static const blueAccent = Color(0xFF00B4D8); // Biru cerah untuk tombol masuk
  static const blueDark   = Color(0xFF0077B6);
  static const text       = Color(0xFFFFFFFF);
  static const textSub    = Color(0xFFB0C4DE); 
  static const textDim    = Color(0xFF6B7B8D);
}

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> with TickerProviderStateMixin {
  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;
  late AnimationController _floatCtrl;
  
  // Video Controller untuk background splash.mp4
  late VideoPlayerController _videoController;

  @override
  void initState() {
    super.initState();
    
    // Inisialisasi Video Background
    _videoController = VideoPlayerController.asset('assets/videos/splash.mp4')
      ..initialize().then((_) {
        _videoController.setLooping(true);
        _videoController.setVolume(0); // Mute video
        _videoController.play();
        setState(() {});
      }).catchError((error) {
        debugPrint("Gagal memuat video: $error");
      });

    _fadeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOutCubic);
    
    _floatCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true);
    
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _fadeCtrl.forward();
    });
  }

  @override
  void dispose() {
    _videoController.dispose(); // Hentikan video saat widget dihancurkan
    _fadeCtrl.dispose();
    _floatCtrl.dispose();
    super.dispose();
  }

  Future<void> _openUrl(String url) async {
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception('Could not launch $uri');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Stack(
        children: [
          // ─── Background Video ────────────────────────────────
          if (_videoController.value.isInitialized)
            SizedBox.expand(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController.value.size.width,
                  height: _videoController.value.size.height,
                  child: VideoPlayer(_videoController),
                ),
              ),
            )
          else
            Container(color: _C.bg), // Fallback jika video belum siap

          // Overlay gelap agar teks tetap terbaca
          Container(
            color: Colors.black.withOpacity(0.7),
          ),

          // ─── Konten Utama ─────────────────────────────────────
          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnim,
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const SizedBox(height: 20),
                    _buildHeaderBadges(),
                    const SizedBox(height: 20),
                    _buildLogoBox(),
                    const SizedBox(height: 16),
                    _buildBigTitle(),
                    const SizedBox(height: 20),
                    _buildFeatureRow(),
                    const SizedBox(height: 16),
                    _buildDescCard(),
                    const SizedBox(height: 20),
                    _buildLoginButton(),
                    const SizedBox(height: 12),
                    _buildBuyAccessButton(),
                    const SizedBox(height: 12),
                    _buildContactSupportButton(),
                    const SizedBox(height: 24),
                    _buildSocialSection(),
                    const SizedBox(height: 20),
                    _buildFooter(),
                    const SizedBox(height: 30),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── Header Badges (TERMUX, VPS, UBOT) ──────────────────────
  Widget _buildHeaderBadges() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          _badgeItem('TERMUX'),
          Row(
            children: [
              _badgeItem('VPS'),
              const SizedBox(width: 8),
              _badgeItem('UBOT'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _badgeItem(String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.2)),
      ),
      child: Text(
        text,
        style: const TextStyle(
          color: Colors.white70,
          fontSize: 10,
          fontWeight: FontWeight.bold,
          letterSpacing: 1,
        ),
      ),
    );
  }

  // ─── Logo Box ───────────────────────────────────────────────
  Widget _buildLogoBox() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: AnimatedBuilder(
        animation: _floatCtrl,
        builder: (context, child) {
          return Transform.translate(
            offset: Offset(0, 5 * _floatCtrl.value),
            child: Container(
              width: double.infinity,
              height: 180, // Disesuaikan agar proporsional
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Image.asset(
                  'assets/images/login.png', // Pastikan file ini ada
                  fit: BoxFit.contain,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  // ─── Big Title (APK SYAM) ───────────────────────────────────
  Widget _buildBigTitle() {
    return Column(
      children: [
        const Text(
          'APK SYAM · FOR YOU',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
            fontFamily: 'Branda', // Sesuai pubspec.yaml
            letterSpacing: 1.5,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          'APK Terbaru dengan fitur lengkap',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: _C.textSub,
            fontSize: 12,
            letterSpacing: 0.5,
          ),
        ),
      ],
    );
  }

  // ─── Feature Row (TERMUX, VPS, UBOT) ────────────────────────
  Widget _buildFeatureRow() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Row(
        children: [
          _featureCard(
            icon: Icons.phone_android,
            title: 'TERMUX',
            subtitle: 'install di HP, langsung jalan',
          ),
          const SizedBox(width: 10),
          _featureCard(
            icon: Icons.dns,
            title: 'VPS',
            subtitle: 'Server 24/7 stabil',
          ),
          const SizedBox(width: 10),
          _featureCard(
            icon: Icons.send_rounded,
            title: 'UBOT',
            subtitle: 'Bot per user',
          ),
        ],
      ),
    );
  }

  Widget _featureCard({required IconData icon, required String title, required String subtitle}) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.05),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white.withOpacity(0.1)),
        ),
        child: Column(
          children: [
            Icon(icon, color: Colors.white70, size: 28),
            const SizedBox(height: 8),
            Text(
              title,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 11,
                fontWeight: FontWeight.bold,
                letterSpacing: 1,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              subtitle,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: _C.textDim,
                fontSize: 8,
                height: 1.2,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── Description Card (KENAPA PILIH SYAM?) ──────────────────
  Widget _buildDescCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.05),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white.withOpacity(0.1)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.anchor, color: Colors.white70, size: 18),
                const SizedBox(width: 8),
                Text(
                  'KENAPA PILIH SYAM?',
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.9),
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1,
                    fontFamily: 'Branda',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              'integrasi server cerdas dengan beberapa fitur serta benefit.\nSYAM For you and Always For You.',
              style: TextStyle(
                color: _C.textSub,
                fontSize: 11,
                height: 1.5,
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                _tagBadge('OTA'),
                const SizedBox(width: 8),
                _tagBadge('AYUN'),
                const SizedBox(width: 8),
                _tagBadge('SYAM'),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _tagBadge(String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        text,
        style: const TextStyle(
          color: Colors.white70,
          fontSize: 9,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  // ─── Login Button (MASUK) ───────────────────────────────────
  Widget _buildLoginButton() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Container(
        width: double.infinity,
        height: 52,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [_C.blueDark, _C.blueAccent],
          ),
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: _C.blueAccent.withOpacity(0.3),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: () => Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (_) => LoginPage()),
            ),
            borderRadius: BorderRadius.circular(12),
            child: const Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.login_rounded, color: Colors.white, size: 20),
                SizedBox(width: 10),
                Text(
                  'MASUK',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Branda',
                    letterSpacing: 2,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ─── Buy Access Button (BELI AKSES) ─────────────────────────
  Widget _buildBuyAccessButton() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Container(
        width: double.infinity,
        height: 52,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.08),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.white.withOpacity(0.15)),
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: () {
              // Fungsi beli akses (diarahkan ke link pembelian)
              _openUrl('https://t.me/maklongemis'); 
            },
            borderRadius: BorderRadius.circular(12),
            child: const Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.shopping_bag_outlined, color: Colors.white70, size: 20),
                SizedBox(width: 10),
                Text(
                  'BELI AKSES',
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Branda',
                    letterSpacing: 2,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ─── Contact Support Button (HUBUNGI SUPPORT) ───────────────
  Widget _buildContactSupportButton() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Container(
        width: double.infinity,
        height: 52,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.05),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.white.withOpacity(0.1)),
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: () => _openUrl('https://t.me/maklongemis'),
            borderRadius: BorderRadius.circular(12),
            child: const Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.headset_mic_rounded, color: Colors.white70, size: 20),
                SizedBox(width: 10),
                Text(
                  'HUBUNGI SUPPORT',
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Branda',
                    letterSpacing: 2,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ─── Social Section (Telegram & TikTok) ─────────────────────
  Widget _buildSocialSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 24),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.05),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white.withOpacity(0.1)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _buildSocialItem(
              icon: FontAwesomeIcons.telegram,
              label: 'Telegram',
              onTap: () => _openUrl('https://t.me/maklongemis'),
            ),
            _buildSocialItem(
              icon: FontAwesomeIcons.tiktok,
              label: 'TikTok',
              onTap: () => _openUrl('https://tiktok.com/@maklowh'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSocialItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white.withOpacity(0.1),
              border: Border.all(color: Colors.white.withOpacity(0.2), width: 1),
            ),
            child: Center(
              child: FaIcon(icon, color: Colors.white70, size: 22),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            style: const TextStyle(
              color: Colors.white54,
              fontSize: 10,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  // ─── Footer (© 2026 SYAM) ───────────────────────────────────
  Widget _buildFooter() {
    return Text(
      '© 2026 SYAM',
      style: TextStyle(
        color: Colors.white.withOpacity(0.3),
        fontSize: 10,
        letterSpacing: 1,
      ),
    );
  }
}