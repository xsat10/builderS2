// ============================================================
// 🚀 LANDING PAGE — Dark Red Comic 3D Edition
// File: landing.dart
// v4 — + Menu CEK AKUN (di bawah LOGIN)
// ============================================================
import 'dart:async';
import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:local_auth/local_auth.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';

// ═══ IMPORT HALAMAN CEK AKUN ═══
import 'cek_akun_page.dart';

// ═════════════════════════════════════════════════════════════
// 🎨 DARK RED COMIC PALETTE
// ═════════════════════════════════════════════════════════════
class _P {
  static const red          = Color(0xFF8B0000);
  static const redDeep      = Color(0xFF1A0A0A);
  static const redDark      = Color(0xFF4A0000);
  static const redSoft      = Color(0xFF2A0E0E);
  static const redLight     = Color(0xFF3D1414);
  static const accentRed    = Color(0xFFD32F2F);
  static const brightRed    = Color(0xFFFF3B3B);
  static const buttonYellow = Color(0xFFB8860B);
  static const buttonDark   = Color(0xFF1A1A1A);
  // ═══ COMIC OUTLINE ═══
  static const comicBlack   = Color(0xFF000000);
  // ═══ TEXT ═══
  static const white        = Color(0xFFFFF5F5);
  static const textGrey     = Color(0xFFC9A0A0);
  static const textLight    = Color(0xFF8A6060);
  // ═══ ACCENT ═══
  static const green        = Color(0xFF22C55E);
  static const greenLite    = Color(0xFF4ADE80);
  static const gold         = Color(0xFFFDE68A);
  static const amber        = Color(0xFFFBBF24);
  static const blueCheck    = Color(0xFF60A5FA);
  // ═══ BACKGROUND ═══
  static const cream        = Color(0xFF0F0505);
}

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  static const String baseUrl = 'http://shinoa-cpanelpanel.xtxintax.my.id:2003';

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with TickerProviderStateMixin {
  // ── AUTH STATE ──────────────────────────
  bool _isUnlocked = false;
  bool _isScanning = false;
  bool _fingerOnSensor = false;
  bool _scanSuccess = false;
  bool _scanFailed = false;
  double _scanProgress = 0;
  String _scanStatus = 'TEMPELKAN JARI ANDA';

  final LocalAuthentication _localAuth = LocalAuthentication();
  Timer? _scanTimer;

  // ── VIDEO ───────────────────────────────
  late final VideoPlayerController _videoController;
  bool _videoReady = false;

  // ── ANIMATIONS ──────────────────────────
  late final AnimationController _auroraCtrl;
  late final AnimationController _pulseCtrl;
  late final AnimationController _glitchCtrl;
  late final AnimationController _fadeCtrl;
  late final AnimationController _revealCtrl;
  late final AnimationController _scanCtrl;
  late final AnimationController _floatCtrl;

  @override
  void initState() {
    super.initState();

    _auroraCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 12),
    )..repeat();

    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1700),
    )..repeat(reverse: true);

    _glitchCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 180),
    )..repeat(reverse: true);

    _fadeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 850),
    )..forward();

    _revealCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1300),
    );

    _scanCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    );

    _floatCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 5),
    )..repeat(reverse: true);

    _initVideo();
  }

  void _initVideo() {
    _videoController =
        VideoPlayerController.asset('assets/videos/banner.mp4');

    _videoController.initialize().then((_) {
      if (!mounted) return;
      setState(() => _videoReady = true);
      _videoController
        ..setLooping(true)
        ..setVolume(0)
        ..play();
    }).catchError((Object error) {
      debugPrint('Video initialization error: $error');
    });
  }

  @override
  void dispose() {
    _scanTimer?.cancel();
    _videoController.dispose();
    _auroraCtrl.dispose();
    _pulseCtrl.dispose();
    _glitchCtrl.dispose();
    _fadeCtrl.dispose();
    _revealCtrl.dispose();
    _scanCtrl.dispose();
    _floatCtrl.dispose();
    super.dispose();
  }

  // ── FINGERPRINT LOGIC ──
  void _fingerDown() {
    if (_scanSuccess || _isScanning) return;
    HapticFeedback.mediumImpact();
    setState(() {
      _fingerOnSensor = true;
      _isScanning = true;
      _scanFailed = false;
      _scanProgress = 0;
      _scanStatus = 'MEMINDAI SIDIK JARI...';
    });
    _scanCtrl.forward(from: 0);
    _scanTimer?.cancel();
    _scanTimer = Timer.periodic(const Duration(milliseconds: 50), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      if (!_fingerOnSensor) {
        timer.cancel();
        _abortScan();
        return;
      }
      final progress = _scanCtrl.value.clamp(0.0, 1.0);
      setState(() {
        _scanProgress = progress;
        if (progress < .30) {
          _scanStatus = 'MEMINDAI SIDIK JARI...';
        } else if (progress < .60) {
          _scanStatus = 'MEMVERIFIKASI POLA...';
        } else if (progress < .90) {
          _scanStatus = 'MENCOCOKKAN DATA...';
        } else {
          _scanStatus = 'AKSES DIBERIKAN!';
        }
      });
      if (progress >= 1) {
        timer.cancel();
        _completeScan();
      }
    });
  }

  void _fingerUp() {
    if (_scanSuccess) return;
    _fingerOnSensor = false;
    if (_scanProgress < 1) _abortScan();
  }

  void _abortScan() {
    if (_scanSuccess) return;
    _scanTimer?.cancel();
    _scanCtrl.reset();
    if (!mounted) return;
    setState(() {
      _isScanning = false;
      _scanProgress = 0;
      _scanStatus = 'TEMPELKAN JARI ANDA';
      _scanFailed = true;
    });
    HapticFeedback.heavyImpact();
    Future.delayed(const Duration(milliseconds: 600), () {
      if (!mounted) return;
      setState(() => _scanFailed = false);
    });
  }

  Future<void> _completeScan() async {
    bool authenticated = true;
    try {
      final supported = await _localAuth.isDeviceSupported();
      final biometrics = await _localAuth.canCheckBiometrics;
      if (supported && biometrics) {
        authenticated = await _localAuth.authenticate(
          localizedReason: 'Verifikasi sidik jari untuk membuka X-SPYDER',
        );
      }
    } catch (error) {
      debugPrint('Biometric error: $error');
      authenticated = true;
    }
    if (!mounted) return;
    if (authenticated) {
      setState(() {
        _scanSuccess = true;
        _isScanning = false;
        _scanStatus = '✓ VERIFIED';
      });
      HapticFeedback.heavyImpact();
      await Future.delayed(const Duration(milliseconds: 700));
      if (!mounted) return;
      setState(() => _isUnlocked = true);
      _revealCtrl.forward(from: 0);
    } else {
      setState(() {
        _scanFailed = true;
        _isScanning = false;
        _scanStatus = 'VERIFIKASI GAGAL';
      });
      _scanCtrl.reset();
    }
  }

  Future<void> _openUrl(String url) async {
    try {
      await launchUrl(Uri.parse(url),
          mode: LaunchMode.externalApplication);
    } catch (error) {
      debugPrint('Launch error: $error');
    }
  }

  void _openCekAkun() {
    Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => const CekAkunPage(),
        transitionDuration: const Duration(milliseconds: 400),
        transitionsBuilder: (_, anim, __, child) => SlideTransition(
          position: Tween<Offset>(
                  begin: const Offset(1, 0), end: Offset.zero)
              .animate(
                  CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
          child: FadeTransition(opacity: anim, child: child),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _P.cream,
      body: Stack(
        children: [
          Positioned.fill(
            child: CustomPaint(
              painter: _AuroraPainter(animation: _auroraCtrl),
            ),
          ),
          if (!_isUnlocked)
            Positioned.fill(
              child: AnimatedBuilder(
                animation: _glitchCtrl,
                builder: (_, __) {
                  if (!_fingerOnSensor && !_isScanning) {
                    return const SizedBox.shrink();
                  }
                  return IgnorePointer(
                    child: CustomPaint(
                      painter: _GlitchPainter(
                        intensity: _glitchCtrl.value *
                            (_isScanning ? 1 : .25),
                      ),
                    ),
                  );
                },
              ),
            ),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 650),
            switchInCurve: Curves.easeOutBack,
            switchOutCurve: Curves.easeIn,
            transitionBuilder: (child, animation) => FadeTransition(
              opacity: animation,
              child: ScaleTransition(
                scale: Tween<double>(begin: .92, end: 1)
                    .animate(animation),
                child: child,
              ),
            ),
            child: _isUnlocked
                ? _buildLanding()
                : _buildSecureAccess(),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // 🔐 SECURE ACCESS
  // ═══════════════════════════════════════════════════════════
  Widget _buildSecureAccess() {
    return SafeArea(
      child: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildLogo(),
              const SizedBox(height: 52),
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 18, vertical: 8),
                decoration: BoxDecoration(
                  color: _scanSuccess ? _P.green : _P.red,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _P.comicBlack, width: 3),
                  boxShadow: const [
                    BoxShadow(
                        color: _P.comicBlack,
                        offset: Offset(4, 5),
                        blurRadius: 0),
                  ],
                ),
                child: Text(
                  _scanSuccess ? 'ACCESS GRANTED' : 'SECURE ACCESS',
                  style: const TextStyle(
                    color: _P.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 4,
                    fontFamily: 'Astral',
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Text(
                _scanStatus,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: _P.textGrey,
                  fontSize: 10,
                  letterSpacing: 2,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 48),
              GestureDetector(
                onTapDown: (_) => _fingerDown(),
                onTapUp: (_) => _fingerUp(),
                onTapCancel: _fingerUp,
                onLongPressStart: (_) => _fingerDown(),
                onLongPressEnd: (_) => _fingerUp,
                child: AnimatedBuilder(
                  animation: Listenable.merge([_pulseCtrl, _scanCtrl]),
                  builder: (_, __) => _buildFingerprintSensor(),
                ),
              ),
              const SizedBox(height: 38),
              if (_isScanning || _scanProgress > 0) _buildProgress(),
              const SizedBox(height: 30),
              Text(
                _scanSuccess
                    ? 'Membuka X-SPYDER...'
                    : 'Tempelkan jari pada sensor',
                style: const TextStyle(
                  color: _P.textLight,
                  fontSize: 10,
                  letterSpacing: 1.2,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLogo() {
    return Column(
      children: [
        AnimatedBuilder(
          animation: _pulseCtrl,
          builder: (_, __) {
            final scale = .96 + (_pulseCtrl.value * .04);
            return Transform.scale(
              scale: scale,
              child: Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _P.red,
                  border: Border.all(color: _P.comicBlack, width: 4),
                  boxShadow: const [
                    BoxShadow(
                        color: _P.comicBlack,
                        offset: Offset(5, 6),
                        blurRadius: 0),
                  ],
                ),
                child: const Icon(
                  Icons.security_rounded,
                  color: _P.white,
                  size: 48,
                ),
              ),
            );
          },
        ),
        const SizedBox(height: 18),
        Container(
          padding:
              const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          decoration: BoxDecoration(
            color: _P.red,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _P.comicBlack, width: 3.5),
            boxShadow: const [
              BoxShadow(
                  color: _P.comicBlack,
                  offset: Offset(4, 5),
                  blurRadius: 0),
            ],
          ),
          child: const Text(
            'X-SPYDER',
            style: TextStyle(
              color: _P.white,
              fontSize: 22,
              fontWeight: FontWeight.w900,
              letterSpacing: 6,
              fontFamily: 'Astral',
              shadows: [
                Shadow(
                  color: _P.comicBlack,
                  offset: Offset(2, 2),
                  blurRadius: 0,
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 8),
        const Text(
          'SECURE • FLUTTER • COMIC',
          style: TextStyle(
            color: _P.textGrey,
            fontSize: 8,
            letterSpacing: 3,
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );
  }

  Widget _buildFingerprintSensor() {
    final progress = _scanProgress;
    final sensorColor = _scanSuccess
        ? _P.green
        : _scanFailed
            ? _P.brightRed
            : _P.red;

    return Transform.scale(
      scale: _fingerOnSensor
          ? 1.025
          : (.97 + (_pulseCtrl.value * .03)),
      child: Stack(
        alignment: Alignment.center,
        children: [
          if (_isScanning) ...[
            _pulseRing(1.15),
            _pulseRing(1.35),
            _pulseRing(1.55),
          ],
          Container(
            width: 210,
            height: 210,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _P.redSoft,
              border: Border.all(
                color: _P.comicBlack,
                width: 3.5 + progress,
              ),
              boxShadow: const [
                BoxShadow(
                  color: _P.comicBlack,
                  offset: Offset(6, 8),
                  blurRadius: 0,
                ),
              ],
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                Icon(
                  Icons.fingerprint_rounded,
                  size: 112,
                  color: sensorColor.withOpacity(.5 + (progress * .5)),
                ),
                if (_isScanning)
                  Positioned.fill(
                    child: ClipOval(
                      child: CustomPaint(
                        painter: _ScanPainter(progress: progress),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          if (_scanSuccess)
            const Icon(Icons.check_circle_rounded,
                color: _P.green, size: 58),
          if (_scanFailed)
            const Icon(Icons.cancel_rounded,
                color: _P.brightRed, size: 58),
        ],
      ),
    );
  }

  Widget _pulseRing(double scale) {
    return Transform.scale(
      scale: scale,
      child: Container(
        width: 210,
        height: 210,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(
            color: _P.brightRed.withOpacity(.2),
            width: 2,
          ),
        ),
      ),
    );
  }

  Widget _buildProgress() {
    return SizedBox(
      width: 280,
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'SCAN',
                style: TextStyle(
                  color: _P.textGrey,
                  fontSize: 8,
                  letterSpacing: 3,
                  fontWeight: FontWeight.w800,
                ),
              ),
              Text(
                '${(_scanProgress * 100).toInt()}%',
                style: const TextStyle(
                  color: _P.white,
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _P.comicBlack, width: 2.5),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Stack(
                children: [
                  Container(
                    height: 8,
                    color: _P.buttonDark,
                  ),
                  FractionallySizedBox(
                    widthFactor: _scanProgress.clamp(0, 1),
                    child: Container(
                      height: 8,
                      color: _P.brightRed,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // 🎨 LANDING (setelah unlock)
  // ═══════════════════════════════════════════════════════════
  Widget _buildLanding() {
    return SafeArea(
      child: Stack(
        children: [
          SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(18, 16, 18, 112),
            child: Column(
              children: [
                _spawn(.00, _buildHeader()),
                const SizedBox(height: 18),
                _spawn(.08, _buildHero()),
                const SizedBox(height: 15),
                _spawn(.18, _buildWelcomeCards()),
                const SizedBox(height: 15),
                _spawn(.30, _buildEngineStatus()),
                const SizedBox(height: 15),
                _spawn(.42, _buildOnlineCard()),
                const SizedBox(height: 15),
                _spawn(.54, _buildEnterButton()),
                const SizedBox(height: 11),
                // ═══ BUTTON CEK AKUN (BARU) ═══
                _spawn(.58, _buildCekAkunButton()),
                const SizedBox(height: 11),
                _spawn(.64, _buildContactButton()),
                const SizedBox(height: 16),
                _spawn(.75, _buildFooter()),
              ],
            ),
          ),
          Positioned(
            left: 14,
            right: 14,
            bottom: 12,
            child: _buildBottomNavigation(),
          ),
        ],
      ),
    );
  }

  Widget _spawn(double start, Widget child) {
    final end = math.min(start + .32, 1.0);
    return AnimatedBuilder(
      animation: _revealCtrl,
      child: child,
      builder: (_, child) {
        final raw = ((_revealCtrl.value - start) / (end - start))
            .clamp(0.0, 1.0);
        final curve = Curves.easeOutBack.transform(raw);
        return Opacity(
          opacity: raw,
          child: Transform.translate(
            offset: Offset(0, 32 * (1 - curve)),
            child: Transform.scale(
              scale: .93 + (.07 * curve),
              child: child,
            ),
          ),
        );
      },
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        Expanded(
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: _P.red,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _P.comicBlack, width: 3),
                  boxShadow: const [
                    BoxShadow(
                        color: _P.comicBlack,
                        offset: Offset(4, 5),
                        blurRadius: 0),
                  ],
                ),
                child: const Text(
                  'X-SPYDER',
                  style: TextStyle(
                    color: _P.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 4,
                    fontFamily: 'Astral',
                  ),
                ),
              ),
              const SizedBox(height: 6),
              const Text(
                'FLUTTER COMIC • MODERN ENGINE',
                style: TextStyle(
                  color: _P.textGrey,
                  fontSize: 8,
                  letterSpacing: 2,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(width: 8),
        _glassIcon(
          Icons.support_agent_rounded,
          _P.gold,
          () => _openUrl('https://t.me/Candrayonz'),
        ),
      ],
    );
  }

  Widget _glassIcon(IconData icon, Color color, VoidCallback onTap) {
    return _Pressable(
      onTap: onTap,
      child: Container(
        width: 46,
        height: 46,
        decoration: BoxDecoration(
          color: _P.buttonDark,
          borderRadius: BorderRadius.circular(15),
          border: Border.all(color: _P.comicBlack, width: 3),
          boxShadow: const [
            BoxShadow(
                color: _P.comicBlack,
                offset: Offset(3, 3),
                blurRadius: 0),
          ],
        ),
        child: Icon(icon, color: color, size: 21),
      ),
    );
  }

  Widget _buildHero() {
    return Container(
      height: 218,
      width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(29),
        border: Border.all(color: _P.comicBlack, width: 4),
        boxShadow: const [
          BoxShadow(
              color: _P.comicBlack,
              offset: Offset(6, 8),
              blurRadius: 0),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(26),
        child: Stack(
          children: [
            if (_videoReady)
              Positioned.fill(
                child: Opacity(
                  opacity: .35,
                  child: FittedBox(
                    fit: BoxFit.cover,
                    child: SizedBox(
                      width: _videoController.value.size.width,
                      height: _videoController.value.size.height,
                      child: VideoPlayer(_videoController),
                    ),
                  ),
                ),
              )
            else
              const Positioned.fill(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: RadialGradient(
                      colors: [_P.redDeep, _P.cream],
                    ),
                  ),
                ),
              ),
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      _P.redDeep.withOpacity(0.5),
                      _P.red.withOpacity(0.35),
                      _P.redDeep.withOpacity(0.7),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
              ),
            ),
            Positioned.fill(
              child: CustomPaint(
                painter: _CosmicPainter(animation: _pulseCtrl.value),
              ),
            ),
            Positioned(
              top: 15,
              right: 15,
              child: _statusPill('● LIVE', _P.greenLite),
            ),
            Positioned(
              left: 20,
              bottom: 20,
              right: 20,
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'GOOD EVENING',
                          style: TextStyle(
                            color: _P.textGrey,
                            fontSize: 9,
                            letterSpacing: 3,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 5),
                        const Text(
                          'WELCOME TO X-SPYDER',
                          style: TextStyle(
                            color: _P.white,
                            fontSize: 20,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1,
                            fontFamily: 'Astral',
                            shadows: [
                              Shadow(
                                color: _P.comicBlack,
                                offset: Offset(2, 2),
                                blurRadius: 0,
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            _statusPill('FLUTTER', _P.brightRed),
                            const SizedBox(width: 7),
                            _statusPill('COMIC ON!', _P.gold),
                          ],
                        ),
                      ],
                    ),
                  ),
                  _floatingIcon(Icons.auto_awesome_rounded, _P.gold),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _statusPill(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: _P.comicBlack, width: 2),
      ),
      child: Text(
        text,
        style: const TextStyle(
          color: _P.white,
          fontSize: 7.5,
          fontWeight: FontWeight.w900,
          letterSpacing: 1,
        ),
      ),
    );
  }

  Widget _floatingIcon(IconData icon, Color color) {
    return AnimatedBuilder(
      animation: _floatCtrl,
      builder: (_, __) {
        final offset = math.sin(_floatCtrl.value * math.pi) * 4;
        return Transform.translate(
          offset: Offset(0, -offset),
          child: Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color,
              border: Border.all(color: _P.comicBlack, width: 3.5),
              boxShadow: const [
                BoxShadow(
                    color: _P.comicBlack,
                    offset: Offset(3, 3),
                    blurRadius: 0),
              ],
            ),
            child: Icon(icon, color: _P.comicBlack, size: 27),
          ),
        );
      },
    );
  }

  Widget _buildWelcomeCards() {
    return Row(
      children: [
        Expanded(
          child: _infoCard(
            icon: Icons.waving_hand_rounded,
            value: 'WELCOME',
            label: 'X-SPYDER USER',
            color: _P.brightRed,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _infoCard(
            icon: Icons.auto_awesome_rounded,
            value: 'FLUTTER',
            label: 'COMIC ON!',
            color: _P.gold,
          ),
        ),
      ],
    );
  }

  Widget _infoCard({
    required IconData icon,
    required String value,
    required String label,
    required Color color,
  }) {
    return Container(
      height: 140,
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: _P.redSoft,
        borderRadius: BorderRadius.circular(23),
        border: Border.all(color: _P.comicBlack, width: 3.5),
        boxShadow: const [
          BoxShadow(
              color: _P.comicBlack,
              offset: Offset(5, 5),
              blurRadius: 0),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _P.comicBlack, width: 2.5),
            ),
            child: Icon(icon, color: _P.comicBlack, size: 22),
          ),
          const Spacer(),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: color,
              fontSize: 17,
              fontWeight: FontWeight.w900,
              fontFamily: 'Astral',
            ),
          ),
          const SizedBox(height: 3),
          Text(
            label,
            style: const TextStyle(
              color: _P.textGrey,
              fontSize: 7.5,
              letterSpacing: 1.4,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEngineStatus() {
    return _glassPanel(
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 45,
                height: 45,
                decoration: BoxDecoration(
                  color: _P.green,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: _P.comicBlack, width: 2.5),
                ),
                child: const Icon(
                  Icons.speed_rounded,
                  color: _P.white,
                ),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'ACTIVE SESSION',
                      style: TextStyle(
                        color: _P.textGrey,
                        fontSize: 8,
                        letterSpacing: 2,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      'X-SPYDER CORE READY',
                      style: TextStyle(
                        color: _P.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Astral',
                      ),
                    ),
                  ],
                ),
              ),
              _statusPill('READY', _P.green),
            ],
          ),
          const SizedBox(height: 15),
          AnimatedBuilder(
            animation: _pulseCtrl,
            builder: (_, __) {
              final value = .84 + (_pulseCtrl.value * .05);
              return Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: _P.comicBlack, width: 2.5),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: LinearProgressIndicator(
                    value: value,
                    minHeight: 10,
                    backgroundColor: _P.buttonDark,
                    valueColor:
                        const AlwaysStoppedAnimation(_P.green),
                  ),
                ),
              );
            },
          ),
          const SizedBox(height: 8),
          const Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'ENGINE STABILITY',
                style: TextStyle(
                  color: _P.textGrey,
                  fontSize: 7.5,
                  letterSpacing: 1.4,
                  fontWeight: FontWeight.w700,
                ),
              ),
              Text(
                'OPTIMAL',
                style: TextStyle(
                  color: _P.greenLite,
                  fontSize: 7.5,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.4,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildOnlineCard() {
    return _glassPanel(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
      child: Row(
        children: [
          AnimatedBuilder(
            animation: _pulseCtrl,
            builder: (_, __) {
              final size = 12 + (_pulseCtrl.value * 3);
              return Container(
                width: size,
                height: size,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _P.greenLite,
                  border: Border.all(color: _P.comicBlack, width: 2),
                ),
              );
            },
          ),
          const SizedBox(width: 11),
          const Expanded(
            child: Text(
              'X-SPYDER USERS ONLINE',
              style: TextStyle(
                color: _P.white,
                fontSize: 9,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.7,
                fontFamily: 'Astral',
              ),
            ),
          ),
          const Text(
            'COMIC LIVE',
            style: TextStyle(
              color: _P.textGrey,
              fontSize: 7,
              letterSpacing: 1.2,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEnterButton() {
    return _GradientButton(
      label: 'ENTER X-SPYDER',
      icon: Icons.arrow_forward_rounded,
      color: _P.buttonYellow,
      onTap: () => Navigator.pushNamed(context, '/login'),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // 🔍 BUTTON CEK AKUN — MERAH GELAP COMIC 3D
  // ═══════════════════════════════════════════════════════════
  Widget _buildCekAkunButton() {
    return _Pressable(
      onTap: _openCekAkun,
      child: Container(
        height: 58,
        decoration: BoxDecoration(
          // ═══ MERAH GELAP ═══
          color: _P.red,
          borderRadius: BorderRadius.circular(17),
          border: Border.all(color: _P.comicBlack, width: 4),
          boxShadow: const [
            BoxShadow(
                color: _P.comicBlack,
                offset: Offset(5, 6),
                blurRadius: 0),
          ],
        ),
        child: const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.manage_search_rounded,
                color: _P.white, size: 22),
            SizedBox(width: 11),
            Text(
              'CEK AKUN',
              style: TextStyle(
                color: _P.white,
                fontSize: 14,
                fontWeight: FontWeight.w900,
                letterSpacing: 2,
                fontFamily: 'Astral',
                shadows: [
                  Shadow(
                    color: _P.comicBlack,
                    offset: Offset(2, 2),
                    blurRadius: 0,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContactButton() {
    return _OutlineButton(
      label: 'CONTACT DEVELOPER',
      icon: Icons.telegram_rounded,
      color: _P.gold,
      onTap: () => _openUrl('https://t.me/dilzxxwkwk'),
    );
  }

  Widget _buildBottomNavigation() {
    return Container(
      height: 72,
      padding: const EdgeInsets.symmetric(horizontal: 5),
      decoration: BoxDecoration(
        color: _P.redDark,
        borderRadius: BorderRadius.circular(25),
        border: Border.all(color: _P.comicBlack, width: 3.5),
        boxShadow: const [
          BoxShadow(
              color: _P.comicBlack,
              offset: Offset(5, 5),
              blurRadius: 0),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: _navItem(
              icon: Icons.home_rounded,
              label: 'HOME',
              active: true,
              color: _P.brightRed,
              onTap: () {},
            ),
          ),
          Expanded(
            child: _navItem(
              icon: Icons.manage_search_rounded,
              label: 'CEK AKUN',
              active: false,
              color: _P.red,
              onTap: _openCekAkun,
            ),
          ),
          Expanded(
            child: _navItem(
              icon: Icons.login_rounded,
              label: 'LOGIN',
              active: false,
              color: _P.buttonYellow,
              onTap: () => Navigator.pushNamed(context, '/login'),
            ),
          ),
          Expanded(
            child: _navItem(
              icon: Icons.telegram_rounded,
              label: 'CONTACT',
              active: false,
              color: _P.gold,
              onTap: () => _openUrl('https://t.me/Oxy_Reals01'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _navItem({
    required IconData icon,
    required String label,
    required bool active,
    required Color color,
    required VoidCallback onTap,
  }) {
    return _Pressable(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 280),
        curve: Curves.easeOutBack,
        margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 3),
        decoration: BoxDecoration(
          color: active ? color : _P.buttonDark,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: _P.comicBlack, width: 3),
          boxShadow: const [
            BoxShadow(
                color: _P.comicBlack,
                offset: Offset(2, 3),
                blurRadius: 0),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 260),
              transform: active
                  ? Matrix4.translationValues(0, -2, 0)
                  : Matrix4.identity(),
              child: Icon(
                icon,
                color: active ? _P.comicBlack : color,
                size: 20,
              ),
            ),
            const SizedBox(height: 3),
            Text(
              label,
              style: TextStyle(
                color: active ? _P.comicBlack : color,
                fontSize: 7,
                fontWeight: FontWeight.w900,
                letterSpacing: 1,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFooter() {
    return _glassPanel(
      child: Column(
        children: [
          const Text(
            'X-SPYDER',
            style: TextStyle(
              color: _P.white,
              fontSize: 12,
              fontWeight: FontWeight.w900,
              letterSpacing: 4,
              fontFamily: 'Astral',
            ),
          ),
          const SizedBox(height: 6),
          const Text(
            'COMIC DARK RED EXPERIENCE',
            style: TextStyle(
              color: _P.textGrey,
              fontSize: 7.5,
              letterSpacing: 2,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 17),
          Container(height: 2, color: _P.comicBlack),
          const SizedBox(height: 13),
          const Text(
            '© 2026 X-SPYDER • ALL RIGHTS RESERVED',
            style: TextStyle(
              color: _P.textLight,
              fontSize: 7.5,
              letterSpacing: 1.2,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _glassPanel({
    required Widget child,
    EdgeInsetsGeometry padding = const EdgeInsets.all(17),
  }) {
    return Container(
      width: double.infinity,
      padding: padding,
      decoration: BoxDecoration(
        color: _P.redSoft,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: _P.comicBlack, width: 3.5),
        boxShadow: const [
          BoxShadow(
              color: _P.comicBlack,
              offset: Offset(5, 5),
              blurRadius: 0),
        ],
      ),
      child: child,
    );
  }
}

// ═════════════════════════════════════════════════════════════
// 🎨 AURORA PAINTER
// ═════════════════════════════════════════════════════════════
class _AuroraPainter extends CustomPainter {
  final Animation<double> animation;
  _AuroraPainter({required this.animation}) : super(repaint: animation);

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(
      Rect.fromLTWH(0, 0, size.width, size.height),
      Paint()..color = _P.cream,
    );

    final gridPaint = Paint()
      ..color = _P.red.withOpacity(.08)
      ..strokeWidth = 0.8;
    const spacing = 42.0;
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), gridPaint);
    }
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    }

    final t = animation.value * 2 * math.pi;
    final pts = [
      Offset(size.width * .15 + math.sin(t) * 40, size.height * .12),
      Offset(size.width * .85, size.height * .35 + math.cos(t) * 50),
      Offset(size.width * .5, size.height * .85 + math.sin(t) * 30),
    ];
    final colors = [
      _P.red.withOpacity(.22),
      _P.brightRed.withOpacity(.14),
      _P.redDark.withOpacity(.20),
    ];
    for (var i = 0; i < pts.length; i++) {
      final p = Paint()
        ..shader = RadialGradient(
          colors: [colors[i], Colors.transparent],
        ).createShader(Rect.fromCircle(center: pts[i], radius: 260));
      canvas.drawCircle(pts[i], 260, p);
    }

    final particle = Paint()..color = _P.brightRed.withOpacity(.15);
    for (int i = 0; i < 45; i++) {
      final x = ((i * 73.0) % size.width);
      final y = ((i * 127.0 + animation.value * 120) % size.height);
      canvas.drawCircle(Offset(x, y), 1.1, particle);
    }
  }

  @override
  bool shouldRepaint(covariant _AuroraPainter old) => true;
}

// ═════════════════════════════════════════════════════════════
// 🎨 GLITCH PAINTER
// ═════════════════════════════════════════════════════════════
class _GlitchPainter extends CustomPainter {
  final double intensity;
  _GlitchPainter({required this.intensity});

  @override
  void paint(Canvas canvas, Size size) {
    if (intensity < .05) return;
    final random = math.Random(
      DateTime.now().millisecondsSinceEpoch ~/ 120,
    );
    final blocks = (intensity * 14).round();
    for (int i = 0; i < blocks; i++) {
      final width = random.nextDouble() * 110 + 20;
      final height = random.nextDouble() * 8 + 2;
      final x = random.nextDouble() * size.width;
      final y = random.nextDouble() * size.height;
      final color = i.isEven ? _P.brightRed : _P.gold;
      canvas.drawRect(
        Rect.fromLTWH(x, y, width, height),
        Paint()..color = color.withOpacity(.15 * intensity),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _GlitchPainter old) =>
      old.intensity != intensity;
}

// ═════════════════════════════════════════════════════════════
// 🎨 SCAN PAINTER
// ═════════════════════════════════════════════════════════════
class _ScanPainter extends CustomPainter {
  final double progress;
  _ScanPainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 8;

    final paint = Paint()
      ..color = _P.comicBlack.withOpacity(.3)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 5;

    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      -math.pi / 2,
      math.pi * 2 * progress,
      false,
      paint,
    );

    final bright = Paint()
      ..color = _P.brightRed
      ..style = PaintingStyle.stroke
      ..strokeWidth = 5
      ..strokeCap = StrokeCap.round;

    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      -math.pi / 2,
      math.pi * 2 * progress,
      false,
      bright,
    );
  }

  @override
  bool shouldRepaint(covariant _ScanPainter old) =>
      old.progress != progress;
}

// ═════════════════════════════════════════════════════════════
// 🎨 COSMIC HERO PAINTER
// ═════════════════════════════════════════════════════════════
class _CosmicPainter extends CustomPainter {
  final double animation;
  _CosmicPainter({required this.animation});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width * .76, size.height * .48);

    final ringPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.3
      ..color = _P.brightRed.withOpacity(.25);

    for (int i = 0; i < 7; i++) {
      final radius = 30 + (i * 18) + animation * 5;
      canvas.drawCircle(center, radius, ringPaint);
    }

    final particles = Paint()..color = _P.gold.withOpacity(.28);
    for (int i = 0; i < 35; i++) {
      final x = (i * 43.0) % size.width;
      final y = (i * 29.0 + animation * 20) % size.height;
      canvas.drawCircle(Offset(x, y), 1.1, particles);
    }
  }

  @override
  bool shouldRepaint(covariant _CosmicPainter old) =>
      old.animation != animation;
}

// ═════════════════════════════════════════════════════════════
// 🎁 HELPER WIDGETS
// ═════════════════════════════════════════════════════════════
class _Pressable extends StatefulWidget {
  final Widget child;
  final VoidCallback onTap;
  const _Pressable({required this.child, required this.onTap});

  @override
  State<_Pressable> createState() => _PressableState();
}

class _PressableState extends State<_Pressable>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 110),
    lowerBound: 0,
    upperBound: .045,
  );

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: (_) => _controller.forward(),
      onTapUp: (_) {
        _controller.reverse();
        widget.onTap();
      },
      onTapCancel: () => _controller.reverse(),
      child: AnimatedBuilder(
        animation: _controller,
        builder: (_, child) => Transform.scale(
          scale: 1 - _controller.value,
          child: child,
        ),
        child: widget.child,
      ),
    );
  }
}

// ═════════════════════════════════════════════════════════════
// 🟡 GRADIENT BUTTON — KUNING GELAP COMIC 3D
// ═════════════════════════════════════════════════════════════
class _GradientButton extends StatefulWidget {
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const _GradientButton({
    required this.label,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  State<_GradientButton> createState() => _GradientButtonState();
}

class _GradientButtonState extends State<_GradientButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 120),
  );

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _controller.forward(),
      onTapUp: (_) {
        _controller.reverse();
        widget.onTap();
      },
      onTapCancel: () => _controller.reverse(),
      child: AnimatedBuilder(
        animation: _controller,
        builder: (_, child) => Transform.scale(
          scale: 1 - (_controller.value * .035),
          child: child,
        ),
        child: Container(
          height: 60,
          decoration: BoxDecoration(
            color: widget.color,
            borderRadius: BorderRadius.circular(17),
            border: Border.all(color: _P.comicBlack, width: 4),
            boxShadow: [
              BoxShadow(
                color: _P.comicBlack,
                offset: Offset(5, 6 + (_controller.value * 2)),
                blurRadius: 0,
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(widget.icon, color: _P.comicBlack, size: 22),
              const SizedBox(width: 11),
              Text(
                widget.label,
                style: const TextStyle(
                  color: _P.comicBlack,
                  fontSize: 14,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.4,
                  fontFamily: 'Astral',
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _OutlineButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const _OutlineButton({
    required this.label,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return _Pressable(
      onTap: onTap,
      child: Container(
        height: 58,
        decoration: BoxDecoration(
          color: _P.buttonDark,
          borderRadius: BorderRadius.circular(17),
          border: Border.all(color: _P.comicBlack, width: 3.5),
          boxShadow: const [
            BoxShadow(
                color: _P.comicBlack,
                offset: Offset(4, 5),
                blurRadius: 0),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 20),
            const SizedBox(width: 11),
            Text(
              label,
              style: TextStyle(
                color: color,
                fontSize: 12,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.1,
                fontFamily: 'Astral',
              ),
            ),
          ],
        ),
      ),
    );
  }
}