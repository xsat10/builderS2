import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import 'trading_models.dart';

// ─── RIWAYAT TRADE PAGE ───────────────────────────────────────────────────
class RiwayatTradePage extends StatefulWidget {
  final String sessionKey;
  final String role;
  final VoidCallback? onChartPressed;
  final VoidCallback? onTradePressed;
  final VoidCallback? onQuotePressed;

  const RiwayatTradePage({
    Key? key,
    required this.sessionKey,
    required this.role,
    this.onChartPressed,
    this.onTradePressed,
    this.onQuotePressed,
  }) : super(key: key);

  @override
  State<RiwayatTradePage> createState() => _RiwayatTradePageState();
}

class _RiwayatTradePageState extends State<RiwayatTradePage> {
  String selectedFilter = 'All';

  List<TradeHistory> tradeHistories = [
    TradeHistory(
      id: '1',
      symbol: 'ADAUSD',
      type: 'close',
      volume: 0.90,
      entryPrice: 0.2130,
      closePrice: 0.2023,
      pnl: -96.30,
      timestamp: DateTime.now().subtract(const Duration(hours: 1)),
      status: 'completed',
    ),
    TradeHistory(
      id: '2',
      symbol: 'BTCUSD',
      type: 'open',
      volume: 0.01,
      entryPrice: 77600.00,
      closePrice: 77650.00,
      pnl: 50.00,
      timestamp: DateTime.now().subtract(const Duration(hours: 2)),
      status: 'completed',
    ),
    TradeHistory(
      id: '3',
      symbol: 'AUDUSD',
      type: 'close',
      volume: 1.0,
      entryPrice: 0.7160,
      closePrice: 0.7155,
      pnl: -5.00,
      timestamp: DateTime.now().subtract(const Duration(hours: 3)),
      status: 'completed',
    ),
    TradeHistory(
      id: '4',
      symbol: 'CHFJPY',
      type: 'open',
      volume: 5.0,
      entryPrice: 197.75,
      closePrice: 197.80,
      pnl: 25.00,
      timestamp: DateTime.now().subtract(const Duration(hours: 4)),
      status: 'completed',
    ),
    TradeHistory(
      id: '5',
      symbol: 'AUDNZD',
      type: 'close',
      volume: 2.5,
      entryPrice: 1.2110,
      closePrice: 1.2105,
      pnl: -12.50,
      timestamp: DateTime.now().subtract(const Duration(hours: 5)),
      status: 'completed',
    ),
    TradeHistory(
      id: '6',
      symbol: 'CADJPY',
      type: 'open',
      volume: 1.5,
      entryPrice: 114.64,
      closePrice: 114.70,
      pnl: 9.00,
      timestamp: DateTime.now().subtract(const Duration(hours: 6)),
      status: 'completed',
    ),
    TradeHistory(
      id: '7',
      symbol: 'ADAUSD',
      type: 'open',
      volume: 0.90,
      entryPrice: 0.2130,
      closePrice: 0.2130,
      pnl: 0.00,
      timestamp: DateTime.now().subtract(const Duration(hours: 7)),
      status: 'pending',
    ),
  ];

  late List<TradeHistory> filteredHistories;

  @override
  void initState() {
    super.initState();
    _filterHistories();
  }

  void _filterHistories() {
    if (selectedFilter == 'All') {
      filteredHistories = tradeHistories;
    } else if (selectedFilter == 'Buy') {
      filteredHistories =
          tradeHistories.where((h) => h.type == 'open').toList();
    } else if (selectedFilter == 'Sell') {
      filteredHistories =
          tradeHistories.where((h) => h.type == 'close').toList();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: TradingTheme.bg,
      body: Column(
        children: [
          // ─── HEADER ───────────────────────────────────
          _buildHeader(),

          // ─── FILTER TABS ───────────────────────────────
          _buildFilterTabs(),

          // ─── HISTORY LIST ─────────────────────────────
          Expanded(
            child: filteredHistories.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.history_rounded,
                          color: TradingTheme.grey,
                          size: 48,
                        ),
                        const SizedBox(height: 16),
                        Text(
                          'Tidak ada riwayat',
                          style: TextStyle(
                            color: TradingTheme.grey,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  )
                : ListView.separated(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 8),
                    itemCount: filteredHistories.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 8),
                    itemBuilder: (context, index) {
                      return _buildHistoryCard(filteredHistories[index]);
                    },
                  ),
          ),

          // ─── BOTTOM NAV ────────────────────────────────
          _buildBottomNav(),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: TradingTheme.card,
        border: Border(
          bottom: BorderSide(color: TradingTheme.accent.withOpacity(0.25)),
        ),
        boxShadow: [
          BoxShadow(
            color: TradingTheme.accent.withOpacity(0.08),
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Riwayat Transaksi',
            style: TextStyle(
              color: TradingTheme.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
              fontFamily: 'Astral',
            ),
          ),
          Text(
            'Total transaksi: ${tradeHistories.length}',
            style: TextStyle(
              color: TradingTheme.grey,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterTabs() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: TradingTheme.card,
        border: Border(
          bottom: BorderSide(color: TradingTheme.accent.withOpacity(0.15)),
        ),
      ),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: ['All', 'Buy', 'Sell'].map((filter) {
            final isActive = selectedFilter == filter;
            return Padding(
              padding: const EdgeInsets.only(right: 8),
              child: GestureDetector(
                onTap: () {
                  setState(() {
                    selectedFilter = filter;
                    _filterHistories();
                  });
                },
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(
                    color: isActive
                        ? TradingTheme.accent.withOpacity(0.2)
                        : TradingTheme.cardAlt,
                    border: Border.all(
                      color: isActive
                          ? TradingTheme.accent.withOpacity(0.6)
                          : TradingTheme.accent.withOpacity(0.12),
                    ),
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: isActive
                        ? TradingTheme.neonGlow(TradingTheme.accent)
                        : null,
                  ),
                  child: Text(
                    filter,
                    style: TextStyle(
                      color: isActive
                          ? TradingTheme.accentLight
                          : TradingTheme.white,
                      fontWeight: isActive
                          ? FontWeight.w600
                          : FontWeight.w500,
                      fontSize: 12,
                    ),
                  ),
                ),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }

  Widget _buildHistoryCard(TradeHistory history) {
    final isProfit = history.pnl >= 0;
    final typeIcon = history.type == 'open'
        ? Icons.arrow_upward_rounded
        : Icons.arrow_downward_rounded;
    final typeColor =
        history.type == 'open' ? TradingTheme.success : TradingTheme.primary;

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: TradingTheme.cardAlt,
        border: Border.all(color: TradingTheme.accent.withOpacity(0.15)),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: typeColor.withOpacity(0.15),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(typeIcon, color: typeColor, size: 16),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        history.symbol,
                        style: const TextStyle(
                          color: TradingTheme.white,
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Astral',
                        ),
                      ),
                      Text(
                        '${history.type == 'open' ? 'BUY' : 'SELL'} ${history.volume}',
                        style: TextStyle(
                          color: TradingTheme.grey,
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    '${isProfit ? '+' : ''}${history.pnl.toStringAsFixed(2)}',
                    style: TextStyle(
                      color: isProfit
                          ? TradingTheme.success
                          : TradingTheme.primary,
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Astral',
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: history.status == 'completed'
                          ? TradingTheme.success.withOpacity(0.15)
                          : TradingTheme.warning.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Text(
                      history.status == 'completed' ? 'Done' : 'Pending',
                      style: TextStyle(
                        color: history.status == 'completed'
                            ? TradingTheme.success
                            : TradingTheme.warning,
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Entry: ${formatPrice(history.entryPrice)}',
                    style: TextStyle(
                      color: TradingTheme.grey,
                      fontSize: 10,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    _formatDateTime(history.timestamp),
                    style: TextStyle(
                      color: TradingTheme.grey,
                      fontSize: 9,
                    ),
                  ),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    'Close: ${formatPrice(history.closePrice)}',
                    style: TextStyle(
                      color: TradingTheme.grey,
                      fontSize: 10,
                    ),
                  ),
                  const SizedBox(height: 2),
                  GestureDetector(
                    onTap: () => _showDetailDialog(history),
                    child: Text(
                      'Lihat Detail →',
                      style: TextStyle(
                        color: TradingTheme.primary,
                        fontSize: 9,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildBottomNav() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        color: TradingTheme.card,
        border: Border(
          top: BorderSide(color: TradingTheme.accent.withOpacity(0.2)),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _buildNavButton(
            icon: Icons.compare_arrows_rounded,
            label: 'Trade',
            onTap: widget.onTradePressed ?? () {},
          ),
          _buildNavButton(
            icon: Icons.show_chart_rounded,
            label: 'Chart',
            onTap: widget.onChartPressed ?? () {},
          ),
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                '${filteredHistories.length}',
                style: const TextStyle(
                  color: TradingTheme.white,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
              Text(
                'Trades',
                style: TextStyle(color: TradingTheme.grey, fontSize: 10),
              ),
            ],
          ),
          _buildNavButton(
            icon: Icons.access_time_rounded,
            label: 'Riwayat',
            isActive: true,
            onTap: () {},
          ),
          Stack(
            clipBehavior: Clip.none,
            children: [
              _buildNavButton(
                icon: Icons.notifications_active_rounded,
                label: 'Pesan',
                onTap: () {},
              ),
              Positioned(
                top: -4,
                right: -4,
                child: Container(
                  width: 16,
                  height: 16,
                  decoration: BoxDecoration(
                    color: TradingTheme.primary,
                    shape: BoxShape.circle,
                  ),
                  child: const Center(
                    child: Text(
                      '1',
                      style: TextStyle(
                        color: TradingTheme.white,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildNavButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool isActive = false,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            color: isActive ? TradingTheme.primary : TradingTheme.white54,
            size: 20,
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: TextStyle(
              color: isActive ? TradingTheme.primary : TradingTheme.grey,
              fontSize: 10,
              fontWeight: isActive ? FontWeight.w600 : FontWeight.normal,
            ),
          ),
        ],
      ),
    );
  }

  void _showDetailDialog(TradeHistory history) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: TradingTheme.card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        title: const Text(
          'Detail Transaksi',
          style: TextStyle(
            color: TradingTheme.white,
            fontFamily: 'Astral',
          ),
        ),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildDetailRow('Symbol', history.symbol),
              _buildDetailRow('Type', history.type.toUpperCase()),
              _buildDetailRow('Volume', '${history.volume}'),
              _buildDetailRow('Entry Price', formatPrice(history.entryPrice)),
              _buildDetailRow('Close Price', formatPrice(history.closePrice)),
              _buildDetailRow('P&L', '${history.pnl.toStringAsFixed(2)} USD'),
              _buildDetailRow('Status', history.status),
              _buildDetailRow(
                  'Waktu', _formatDateTime(history.timestamp)),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
              color: TradingTheme.grey,
              fontSize: 12,
            ),
          ),
          Text(
            value,
            style: const TextStyle(
              color: TradingTheme.white,
              fontSize: 12,
              fontWeight: FontWeight.w600,
              fontFamily: 'Astral',
            ),
          ),
        ],
      ),
    );
  }

  String _formatDateTime(DateTime dateTime) {
    return DateFormat('dd MMM yy, HH:mm').format(dateTime);
  }

  String formatPrice(double price) {
    if (price > 1000) {
      return price.toStringAsFixed(2);
    }
    return price.toStringAsFixed(4);
  }
}
