import 'dart:convert';
import 'dart:ui' show FontFeature;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class JadwalSholat extends StatefulWidget {
  const JadwalSholat({super.key});

  @override
  State<JadwalSholat> createState() => _JadwalSholatState();
}

class _JadwalSholatState extends State<JadwalSholat> {
  Map<String, String> jadwal = {
    "Imsak": "--:--",
    "Subuh": "--:--",
    "Dzuhur": "--:--",
    "Ashar": "--:--",
    "Maghrib": "--:--",
    "Isya": "--:--",
  };
  String nextSholat = "Subuh";
  bool loading = true;
  String idKota = "1305"; // Semarang
  String namaKota = "Semarang";
  bool _isFirstLoad = true;

  // ── Palet BMW ──────────────────────────────────────────────
  static const Color _bmwBlue = Color(0xFF1C69D4);
  static const Color _bmwMLight = Color(0xFF0066B1);
  static const Color _bmwMNavy = Color(0xFF1C2D5A);
  static const Color _bmwMRed = Color(0xFFE22718);
  static const Color _bg1 = Color(0xFF0D0D0D);
  static const Color _bg2 = Color(0xFF1A1A1A);
  static const Color _card = Color(0xFF141414);
  static const Color _border = Color(0xFF232323);

  @override
  void initState() {
    super.initState();
    _initializeLocation();
  }

  // ─── INISIALISASI LOKASI ────────────────────────────────────────────
  Future<void> _initializeLocation() async {
    setState(() => loading = true);

    final prefs = await SharedPreferences.getInstance();
    final savedId = prefs.getString('kota_id');
    final savedName = prefs.getString('kota_nama');

    if (savedId != null && savedName != null && savedId.isNotEmpty) {
      setState(() {
        idKota = savedId;
        namaKota = savedName;
      });
      await loadJadwal();
      return;
    }

    await _saveDefaultCity();
  }

  Future<void> _saveDefaultCity() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('kota_id', '1305');
    await prefs.setString('kota_nama', 'Semarang');

    setState(() {
      idKota = '1305';
      namaKota = 'Semarang';
    });
    await loadJadwal();
  }

  // ─── LOAD JADWAL ────────────────────────────────────────────────────
  Future<void> loadJadwal() async {
    if (!mounted) return;

    setState(() => loading = true);

    final now = DateTime.now();
    try {
      final url = Uri.parse(
        "https://api.myquran.com/v2/sholat/jadwal/$idKota/${now.year}/${now.month}/${now.day}",
      );

      final response = await http.get(url).timeout(
        const Duration(seconds: 10),
        onTimeout: () {
          throw Exception('Koneksi timeout');
        },
      );

      if (response.statusCode != 200) {
        throw Exception('Gagal memuat data');
      }

      final data = jsonDecode(response.body);

      if (data['status'] != true || data['data'] == null) {
        throw Exception('Data tidak valid');
      }

      final j = data['data']['jadwal'];

      if (j == null) {
        throw Exception('Jadwal tidak tersedia');
      }

      setState(() {
        jadwal = {
          "Imsak": j["imsak"] ?? "--:--",
          "Subuh": j["subuh"] ?? "--:--",
          "Dzuhur": j["dzuhur"] ?? "--:--",
          "Ashar": j["ashar"] ?? "--:--",
          "Maghrib": j["maghrib"] ?? "--:--",
          "Isya": j["isya"] ?? "--:--",
        };
        nextSholat = getNextPrayer(jadwal);
        loading = false;
        _isFirstLoad = false;
      });
    } catch (e) {
      debugPrint("Error loading jadwal: $e");
      setState(() {
        loading = false;
        _isFirstLoad = false;

        jadwal = {
          "Imsak": "04:00",
          "Subuh": "04:30",
          "Dzuhur": "12:00",
          "Ashar": "15:15",
          "Maghrib": "17:45",
          "Isya": "19:00",
        };
        nextSholat = getNextPrayer(jadwal);
      });
    }
  }

  // ─── CARI SHOLAT BERIKUTNYA ────────────────────────────────────────
  String getNextPrayer(Map<String, String> jadwal) {
    final now = TimeOfDay.now();
    final prayerOrder = ["Imsak", "Subuh", "Dzuhur", "Ashar", "Maghrib", "Isya"];

    for (var prayer in prayerOrder) {
      final timeStr = jadwal[prayer];
      if (timeStr == null || timeStr == "--:--") continue;

      final parts = timeStr.split(":");
      if (parts.length >= 2) {
        try {
          final hour = int.parse(parts[0].trim());
          final minute = int.parse(parts[1].trim());
          final prayerTime = TimeOfDay(hour: hour, minute: minute);

          if (prayerTime.hour > now.hour ||
              (prayerTime.hour == now.hour && prayerTime.minute > now.minute)) {
            return prayer;
          }
        } catch (_) {
          continue;
        }
      }
    }
    return prayerOrder.first;
  }

  // ─── MODAL CARI LOKASI (BMW style) ─────────────────────────────────
  void _showSearchLocation() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: _bg1,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(10)),
        side: BorderSide(color: _border),
      ),
      builder: (context) {
        String query = "";
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Container(
              height: MediaQuery.of(context).size.height * 0.7,
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Container(
                    width: 44,
                    height: 3,
                    decoration: BoxDecoration(
                      color: _bmwBlue,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          style: const TextStyle(
                              color: Colors.white, letterSpacing: 0.5),
                          cursorColor: _bmwBlue,
                          decoration: InputDecoration(
                            hintText: "Cari Kota/Kabupaten...",
                            hintStyle: const TextStyle(
                                color: Colors.white38, fontSize: 13),
                            prefixIcon:
                                const Icon(Icons.search, color: _bmwBlue),
                            filled: true,
                            fillColor: _card,
                            contentPadding:
                                const EdgeInsets.symmetric(vertical: 14),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(4),
                              borderSide: const BorderSide(color: _border),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(4),
                              borderSide: const BorderSide(color: _border),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(4),
                              borderSide: const BorderSide(
                                  color: _bmwBlue, width: 1.5),
                            ),
                          ),
                          onChanged: (val) =>
                              setModalState(() => query = val),
                        ),
                      ),
                      const SizedBox(width: 8),
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text(
                          "TUTUP",
                          style: TextStyle(
                            color: _bmwBlue,
                            letterSpacing: 2,
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 15),
                  Expanded(
                    child: FutureBuilder<List<dynamic>>(
                      future: _searchKota(query),
                      builder: (context, snapshot) {
                        if (query.isEmpty) {
                          return const Center(
                            child: Text(
                              "CARI KOTA UNTUK MENGUBAH LOKASI",
                              style: TextStyle(
                                color: Colors.white38,
                                fontSize: 11,
                                letterSpacing: 2,
                              ),
                            ),
                          );
                        }
                        if (query.length < 3) {
                          return const Center(
                            child: Text(
                              "KETIK MINIMAL 3 HURUF",
                              style: TextStyle(
                                color: Colors.white38,
                                fontSize: 11,
                                letterSpacing: 2,
                              ),
                            ),
                          );
                        }
                        if (snapshot.connectionState ==
                            ConnectionState.waiting) {
                          return const Center(
                            child: SizedBox(
                              width: 26,
                              height: 26,
                              child: CircularProgressIndicator(
                                color: _bmwBlue,
                                strokeWidth: 2,
                              ),
                            ),
                          );
                        }
                        if (!snapshot.hasData || snapshot.data!.isEmpty) {
                          return const Center(
                            child: Text(
                              "KOTA TIDAK DITEMUKAN",
                              style: TextStyle(
                                color: Colors.white38,
                                letterSpacing: 2,
                                fontSize: 11,
                              ),
                            ),
                          );
                        }
                        return ListView.builder(
                          itemCount: snapshot.data!.length,
                          itemBuilder: (context, index) {
                            final item = snapshot.data![index];
                            return Container(
                              margin: const EdgeInsets.only(bottom: 6),
                              decoration: BoxDecoration(
                                color: _card,
                                borderRadius: BorderRadius.circular(4),
                                border: Border.all(color: _border),
                              ),
                              child: ListTile(
                                leading: const Icon(
                                  Icons.location_on,
                                  color: _bmwBlue,
                                  size: 20,
                                ),
                                title: Text(
                                  item['lokasi'] ?? 'Unknown',
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 13,
                                    letterSpacing: 0.5,
                                  ),
                                ),
                                subtitle: Text(
                                  (item['provinsi'] ?? '')
                                      .toString()
                                      .toUpperCase(),
                                  style: const TextStyle(
                                    color: Colors.white38,
                                    fontSize: 10,
                                    letterSpacing: 1.5,
                                  ),
                                ),
                                onTap: () async {
                                  final prefs =
                                      await SharedPreferences.getInstance();
                                  await prefs.setString(
                                      'kota_id', item['id'].toString());
                                  await prefs.setString(
                                      'kota_nama', item['lokasi']);

                                  setState(() {
                                    idKota = item['id'].toString();
                                    namaKota = item['lokasi'];
                                  });
                                  await loadJadwal();
                                  if (context.mounted) Navigator.pop(context);
                                },
                              ),
                            );
                          },
                        );
                      },
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Future<List<dynamic>> _searchKota(String q) async {
    if (q.length < 3) return [];
    try {
      final res = await http
          .get(Uri.parse("https://api.myquran.com/v2/sholat/kota/cari/$q"))
          .timeout(const Duration(seconds: 5));
      final data = jsonDecode(res.body);
      return data['data'] ?? [];
    } catch (e) {
      debugPrint("Search error: $e");
      return [];
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading && _isFirstLoad) {
      return Container(
        height: 180,
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [_bg1, _bg2],
          ),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: _border),
        ),
        child: const Center(
          child: SizedBox(
            width: 28,
            height: 28,
            child: CircularProgressIndicator(
              color: _bmwBlue,
              strokeWidth: 2,
            ),
          ),
        ),
      );
    }

    return buildJadwalSholat(
      kota: namaKota,
      jadwal: jadwal,
      sholatSelanjutnya: nextSholat,
      onGanti: _showSearchLocation,
    );
  }

  // ─── UI UTAMA ───────────────────────────────────────────────────────
  Widget buildJadwalSholat({
    required String kota,
    required Map<String, String> jadwal,
    required String sholatSelanjutnya,
    required VoidCallback onGanti,
  }) {
    final Map<String, Color> accentSholat = {
      "Imsak": const Color(0xFF3A3A3A),
      "Subuh": _bmwMLight,
      "Dzuhur": _bmwBlue,
      "Ashar": _bmwMRed,
      "Maghrib": _bmwMNavy,
      "Isya": const Color(0xFF0B1E4A),
    };

    return Container(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [_bg1, _bg2],
        ),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: _border, width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.6),
            blurRadius: 24,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // M-stripe
          const Row(
            children: [
              _MStripe(color: _bmwMLight),
              _MStripe(color: _bmwMNavy),
              _MStripe(color: _bmwMRed),
            ],
          ),
          const SizedBox(height: 16),

          // Header
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _card,
                      border: Border.all(color: _bmwBlue, width: 1.5),
                    ),
                    child: const Center(
                      child: Icon(
                        Icons.mosque,
                        color: _bmwBlue,
                        size: 20,
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        "JADWAL SHOLAT",
                        style: TextStyle(
                          color: Color(0xFFEDEDED),
                          fontWeight: FontWeight.w600,
                          fontSize: 13,
                          letterSpacing: 3,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        kota.toUpperCase(),
                        style: const TextStyle(
                          color: _bmwBlue,
                          fontSize: 10,
                          letterSpacing: 2.5,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              GestureDetector(
                onTap: onGanti,
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
                  decoration: BoxDecoration(
                    color: _card,
                    borderRadius: BorderRadius.circular(4),
                    border: Border.all(color: _bmwBlue, width: 1),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.location_on, color: _bmwBlue, size: 13),
                      SizedBox(width: 6),
                      Text(
                        "LOKASI",
                        style: TextStyle(
                          color: Color(0xFFEDEDED),
                          fontWeight: FontWeight.w600,
                          fontSize: 10,
                          letterSpacing: 2,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),

          if (loading)
            const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: CircularProgressIndicator(
                  color: _bmwBlue,
                  strokeWidth: 2,
                ),
              ),
            )
          else
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: jadwal.entries.map((entry) {
                  final isNext = entry.key == sholatSelanjutnya;
                  final isValid = entry.value != "--:--";
                  final accent =
                      accentSholat[entry.key] ?? const Color(0xFF3A3A3A);

                  return AnimatedContainer(
                    duration: const Duration(milliseconds: 350),
                    curve: Curves.easeOutCubic,
                    width: isNext ? 118 : 96,
                    height: 128,
                    margin: const EdgeInsets.only(right: 10),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: isNext
                            ? [
                                accent.withOpacity(0.28),
                                const Color(0xFF0A0A0A),
                              ]
                            : [
                                const Color(0xFF1A1A1A),
                                const Color(0xFF0F0F0F),
                              ],
                      ),
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(
                        color: isNext ? accent : const Color(0xFF262626),
                        width: isNext ? 1.5 : 1,
                      ),
                      boxShadow: isNext
                          ? [
                              BoxShadow(
                                color: accent.withOpacity(0.45),
                                blurRadius: 18,
                                spreadRadius: 1,
                              ),
                            ]
                          : null,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          height: 3,
                          decoration: BoxDecoration(
                            color: isNext ? accent : const Color(0xFF2A2A2A),
                            borderRadius: const BorderRadius.vertical(
                              top: Radius.circular(6),
                            ),
                          ),
                        ),
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.all(12),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      entry.key.toUpperCase(),
                                      style: TextStyle(
                                        color: isNext
                                            ? const Color(0xFFEDEDED)
                                            : const Color(0xFF8A8A8A),
                                        fontSize: 10,
                                        fontWeight: FontWeight.w600,
                                        letterSpacing: 2,
                                      ),
                                    ),
                                    if (isNext) ...[
                                      const SizedBox(height: 5),
                                      Container(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 6,
                                          vertical: 2,
                                        ),
                                        decoration: BoxDecoration(
                                          color: accent,
                                          borderRadius:
                                              BorderRadius.circular(2),
                                        ),
                                        child: const Text(
                                          "NEXT",
                                          style: TextStyle(
                                            fontSize: 7,
                                            color: Colors.white,
                                            fontWeight: FontWeight.bold,
                                            letterSpacing: 1.5,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ],
                                ),
                                Text(
                                  entry.value,
                                  style: TextStyle(
                                    fontSize: isNext ? 22 : 18,
                                    fontWeight: FontWeight.w300,
                                    color: isValid
                                        ? (isNext
                                            ? Colors.white
                                            : const Color(0xFFD0D0D0))
                                        : const Color(0xFF4A4A4A),
                                    letterSpacing: 1,
                                    fontFeatures: const [
                                      FontFeature.tabularFigures(),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                }).toList(),
              ),
            ),
        ],
      ),
    );
  }
}

// ── M-stripe helper ─────────────────────────────────────────────
class _MStripe extends StatelessWidget {
  final Color color;
  const _MStripe({required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 22,
      height: 3,
      margin: const EdgeInsets.only(right: 3),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(1),
      ),
    );
  }
}