import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:http/http.dart' as http;
import 'package:permission_handler/permission_handler.dart';
import 'package:share_plus/share_plus.dart';
import 'package:video_player/video_player.dart';
import 'api_config.dart';

class EncryptPage extends StatefulWidget {
  const EncryptPage({super.key});

  @override
  State<EncryptPage> createState() => _EncryptPageState();
}

class _EncryptPageState extends State<EncryptPage> {
  File? encryptedFile;
  bool isLoading = false;
  late VideoPlayerController _videoController;

  @override
  void initState() {
    super.initState();
    requestStoragePermission();

    _videoController = VideoPlayerController.asset("assets/videos/banner.mp4")
      ..initialize().then((_) {
        setState(() {});
        _videoController.setLooping(true);
        _videoController.play();
      });
  }

  @override
  void dispose() {
    _videoController.dispose();
    super.dispose();
  }

  Future<void> requestStoragePermission() async {
    var status = await Permission.manageExternalStorage.request();
    if (!status.isGranted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("⚠️ Izin storage ditolak")),
      );
    }
  }

  Future<void> pickAndEncryptFile() async {
    final result = await FilePicker.platform.pickFiles();
if (result.isNotEmpty) {
  final file = File(result.first.path!);
      final bytes = await file.readAsBytes();

      setState(() => isLoading = true);

      try {
        var request = http.MultipartRequest(
          'POST',
          Uri.parse("$baseUrl/encrypt"),
        );
        request.files.add(
          http.MultipartFile.fromBytes(
            'file',
            bytes,
            filename: result.first.name,
          ),
        );

        var response = await request.send();

        if (response.statusCode == 200) {
          var responseData = await response.stream.toBytes();
          var responseString = utf8.decode(responseData);
          final jsonData = jsonDecode(responseString);
          final encryptedBase64 = jsonData["encrypted"];
          final encryptedBytes = base64Decode(encryptedBase64);

          final outFile = File("${file.parent.path}/encrypted_${result.first.name}");
          await outFile.writeAsBytes(encryptedBytes);

          setState(() {
            encryptedFile = outFile;
          });
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("❌ Gagal mengenkripsi file")),
          );
        }
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Error: $e")),
        );
      } finally {
        setState(() => isLoading = false);
      }
    }
  }

  void downloadFile() {
    if (encryptedFile != null) {
      Share.shareXFiles([XFile(encryptedFile!.path)],
          text: "File terenkripsi siap diunduh");
    }
  }

  @override
Widget build(BuildContext context) {
  return Scaffold(
    body: Stack(
      children: [
        // Background gradient
        Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF0F2027), Color(0xFF203A43), Color(0xFF2C5364)],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
        ),

        // Konten utama
        SingleChildScrollView(
          child: Column(
            children: [
              // Video banner di atas
              _videoController.value.isInitialized
                  ? AspectRatio(
                      aspectRatio: _videoController.value.aspectRatio,
                      child: VideoPlayer(_videoController),
                    )
                  : const SizedBox(height: 200),

              const SizedBox(height: 20),

              ShaderMask(
                shaderCallback: (bounds) => const LinearGradient(
                  colors: [Colors.cyanAccent, Colors.blueAccent],
                ).createShader(bounds),
                child: const Text(
                  "Nted Encrypt File",
                  style: TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                    color: Colors.white,
                    letterSpacing: 2,
                  ),
                ),
              ),

              const SizedBox(height: 10),

              // Deskripsi
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 16),
                child: Text(
                  "Pilih file yang mau dienkripsi.\n"
                  "File akan terenkripsi dan bisa diunduh kembali.",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 16,
                    fontFamily: 'Orbitron',
                  ),
                ),
              ),

              const SizedBox(height: 30),

              // Card bergaya glassmorphism
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 20),
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.white.withOpacity(0.2)),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.3),
                      blurRadius: 10,
                      offset: const Offset(0, 5),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    // Tombol Encrypt
                    ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blueAccent.withOpacity(0.8),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 24, vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      onPressed: isLoading ? null : pickAndEncryptFile,
                      icon: const Icon(Icons.lock, color: Colors.white),
                      label: isLoading
                          ? const SizedBox(
                              height: 20,
                              width: 20,
                              child: CircularProgressIndicator(
                                  color: Colors.white),
                            )
                          : const Text(
                              "Encrypt File",
                              style: TextStyle(fontFamily: 'Orbitron'),
                            ),
                    ),

                    const SizedBox(height: 20),

                    // Tombol Download / Status
                    encryptedFile != null
                        ? ElevatedButton.icon(
                            style: ElevatedButton.styleFrom(
                              backgroundColor:
                                  Colors.greenAccent.withOpacity(0.8),
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 24, vertical: 14),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            onPressed: downloadFile,
                            icon: const Icon(Icons.download,
                                color: Colors.white),
                            label: const Text(
                              "Download File Terenkripsi",
                              style: TextStyle(fontFamily: 'Orbitron'),
                            ),
                          )
                        : const Text(
                            "Belum ada file terenkripsi",
                            style: TextStyle(
                              color: Colors.white70,
                              fontFamily: 'Orbitron',
                            ),
                          ),
                  ],
                ),
              ),

              const SizedBox(height: 40),
            ],
          ),
        ),
      ],
    ),
  );
}
}