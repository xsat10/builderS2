// ============================================================
// 🚨 LAPORKAN MASALAH — Dark Red Comic 3D Edition
// File: laporkan_masalah_page.dart
// ============================================================
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class _MC {
  static const red          = Color(0xFF8B0000);
  static const redDeep      = Color(0xFF1A0A0A);
  static const redDark      = Color(0xFF4A0000);
  static const redSoft      = Color(0xFF2A0E0E);
  static const brightRed    = Color(0xFFFF3B3B);
  static const buttonYellow = Color(0xFFB8860B);
  static const buttonDark   = Color(0xFF1A1A1A);
  static const comicBlack   = Color(0xFF000000);
  static const white        = Color(0xFFFFF5F5);
  static const textGrey     = Color(0xFFC9A0A0);
  static const textLight    = Color(0xFF8A6060);
  static const green        = Color(0xFF22C55E);
  static const greenLite    = Color(0xFF4ADE80);
  static const amber        = Color(0xFFFBBF24);
}

class LaporkanMasalahPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;
  const LaporkanMasalahPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<LaporkanMasalahPage> createState() => _LaporkanMasalahPageState();
}

class _LaporkanMasalahPageState extends State<LaporkanMasalahPage> {
  final _messageCtrl = TextEditingController();
  String _selectedCategory = 'BUG APK';
  bool _sending = false;
  String? _errorMsg;

  static const List<String> _categories = [
    'BUG APK',
    'KENDALA PROJECT',
    'FITUR TIDAK JALAN',
    'ERROR LOGIN',
    'LAINNYA',
  ];

  static const String _baseUrl = "http://shinoa-cpanelpanel.xtxintax.my.id:2003";

  @override
  void dispose() {
    _messageCtrl.dispose();
    super.dispose();
  }

  Future<void> _sendReport() async {
    final msg = _messageCtrl.text.trim();

    if (msg.isEmpty) {
      setState(() => _errorMsg = '❌ Tuliskan dulu masalah/kendala kamu!');
      return;
    }
    if (msg.length < 10) {
      setState(() =>
          _errorMsg = '❌ Minimal 10 karakter untuk deskripsi masalah');
      return;
    }

    setState(() {
      _sending = true;
      _errorMsg = null;
    });

    try {
      // Simpan ke local storage
      final prefs = await SharedPreferences.getInstance();
      final listKey = 'reports_${widget.username}';
      final existing = prefs.getStringList(listKey) ?? [];

      final reportData = {
        'id': DateTime.now().millisecondsSinceEpoch.toString(),
        'username': widget.username,
        'role': widget.role,
        'category': _selectedCategory,
        'message': msg,
        'timestamp': DateTime.now().millisecondsSinceEpoch,
        'status': 'pending',
      };

      existing.insert(0, jsonEncode(reportData));
      await prefs.setStringList(listKey, existing);

      // Kirim ke server (opsional, tidak error kalau gagal)
      try {
        await http.post(
          Uri.parse('$_baseUrl/reportIssue'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'key': widget.sessionKey,
            'username': widget.username,
            'role': widget.role,
            'category': _selectedCategory,
            'message': msg,
          }),
        ).timeout(const Duration(seconds: 6));
      } catch (_) {}

      if (!mounted) return;

      setState(() {
        _sending = false;
        _messageCtrl.clear();
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          backgroundColor: _MC.green,
          content: Row(
            children: [
              Icon(Icons.check_circle_rounded,
                  color: _MC.comicBlack, size: 20),
              SizedBox(width: 8),
              Expanded(
                child: Text(
                  '✅ Laporan terkirim ke riwayat!',
                  style: TextStyle(
                      color: _MC.comicBlack,
                      fontWeight: FontWeight.w800),
                ),
              ),
            ],
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _sending = false;
        _errorMsg = '❌ Gagal kirim: $e';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _MC.redDeep,
      appBar: AppBar(
        backgroundColor: _MC.redDark,
        elevation: 0,
        centerTitle: true,
        leading: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            margin: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: _MC.buttonDark,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _MC.comicBlack, width: 2.5),
              boxShadow: const [
                BoxShadow(
                    color: _MC.comicBlack,
                    offset: Offset(2, 2),
                    blurRadius: 0),
              ],
            ),
            child: const Icon(Icons.arrow_back_ios_new_rounded,
                color: _MC.white, size: 16),
          ),
        ),
        title: Container(
          padding:
              const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
          decoration: BoxDecoration(
            color: _MC.buttonDark,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: _MC.comicBlack, width: 2.5),
            boxShadow: const [
              BoxShadow(
                  color: _MC.comicBlack,
                  offset: Offset(3, 3),
                  blurRadius: 0),
            ],
          ),
          child: const Text(
            'LAPORKAN MASALAH',
            style: TextStyle(
              color: _MC.white,
              fontWeight: FontWeight.w900,
              fontSize: 13,
              letterSpacing: 2,
              fontFamily: 'Astral',
            ),
          ),
        ),
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _buildHeaderCard(),
            const SizedBox(height: 16),
            _buildCategorySelector(),
            const SizedBox(height: 16),
            _buildMessageInput(),
            if (_errorMsg != null) ...[
              const SizedBox(height: 12),
              _buildErrorBox(),
            ],
            const SizedBox(height: 20),
            _buildSendButton(),
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }

  Widget _buildHeaderCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: _MC.redSoft,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _MC.comicBlack, width: 3.5),
        boxShadow: const [
          BoxShadow(
              color: _MC.comicBlack,
              offset: Offset(6, 6),
              blurRadius: 0),
        ],
      ),
      child: Column(
        children: [
          Container(
            width: 70,
            height: 70,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _MC.brightRed,
              border: Border.all(color: _MC.comicBlack, width: 3.5),
              boxShadow: const [
                BoxShadow(
                    color: _MC.comicBlack,
                    offset: Offset(3, 3),
                    blurRadius: 0),
              ],
            ),
            child: const Icon(Icons.report_problem_rounded,
                color: _MC.white, size: 34),
          ),
          const SizedBox(height: 14),
          const Text(
            'LAPORKAN MASALAH',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: _MC.white,
              fontWeight: FontWeight.w900,
              fontSize: 18,
              letterSpacing: 2,
              fontFamily: 'Astral',
            ),
          ),
          const SizedBox(height: 6),
          const Text(
            'Tuliskan masalah atau kendala yang kamu alami di apk ini. Laporan akan masuk ke riwayat dan ditinjau admin.',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: _MC.textGrey,
              fontSize: 12,
              height: 1.5,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCategorySelector() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _MC.redSoft,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _MC.comicBlack, width: 3.5),
        boxShadow: const [
          BoxShadow(
              color: _MC.comicBlack,
              offset: Offset(5, 5),
              blurRadius: 0),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.category_rounded,
                  color: _MC.brightRed, size: 18),
              SizedBox(width: 8),
              Text(
                'KATEGORI MASALAH',
                style: TextStyle(
                  color: _MC.white,
                  fontWeight: FontWeight.w900,
                  fontSize: 12,
                  letterSpacing: 1.5,
                  fontFamily: 'Astral',
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: _categories.map((cat) {
              final active = _selectedCategory == cat;
              return GestureDetector(
                onTap: () => setState(() => _selectedCategory = cat),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: active ? _MC.brightRed : _MC.buttonDark,
                    borderRadius: BorderRadius.circular(10),
                    border:
                        Border.all(color: _MC.comicBlack, width: 2.5),
                    boxShadow: const [
                      BoxShadow(
                          color: _MC.comicBlack,
                          offset: Offset(2, 2),
                          blurRadius: 0),
                    ],
                  ),
                  child: Text(
                    cat,
                    style: const TextStyle(
                      color: _MC.white,
                      fontSize: 10.5,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 0.8,
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildMessageInput() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _MC.redSoft,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _MC.comicBlack, width: 3.5),
        boxShadow: const [
          BoxShadow(
              color: _MC.comicBlack,
              offset: Offset(5, 5),
              blurRadius: 0),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.edit_note_rounded,
                  color: _MC.brightRed, size: 18),
              SizedBox(width: 8),
              Text(
                'DESKRIPSI MASALAH',
                style: TextStyle(
                  color: _MC.white,
                  fontWeight: FontWeight.w900,
                  fontSize: 12,
                  letterSpacing: 1.5,
                  fontFamily: 'Astral',
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            decoration: BoxDecoration(
              color: _MC.redDeep,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _MC.comicBlack, width: 3),
              boxShadow: const [
                BoxShadow(
                    color: _MC.comicBlack,
                    offset: Offset(4, 4),
                    blurRadius: 0),
              ],
            ),
            child: TextField(
              controller: _messageCtrl,
              maxLines: 6,
              minLines: 4,
              style: const TextStyle(
                color: _MC.white,
                fontSize: 13,
                fontWeight: FontWeight.w600,
              ),
              cursorColor: _MC.brightRed,
              decoration: const InputDecoration(
                hintText:
                    'Contoh: saat buka menu tools, aplikasi langsung crash. Kendala terjadi sejak update terakhir...',
                hintStyle:
                    TextStyle(color: _MC.textLight, fontSize: 12),
                border: InputBorder.none,
                contentPadding: EdgeInsets.all(14),
              ),
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Minimal 10 karakter. Jelaskan sedetail mungkin.',
            style: TextStyle(
              color: _MC.textGrey,
              fontSize: 10,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorBox() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _MC.red.withOpacity(0.3),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _MC.comicBlack, width: 2.5),
      ),
      child: Row(
        children: [
          const Icon(Icons.error_outline_rounded,
              color: _MC.brightRed, size: 18),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              _errorMsg!,
              style: const TextStyle(
                color: _MC.brightRed,
                fontSize: 12,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSendButton() {
    return GestureDetector(
      onTap: _sending ? null : _sendReport,
      child: Container(
        height: 60,
        decoration: BoxDecoration(
          color: _sending ? _MC.buttonDark : _MC.buttonYellow,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _MC.comicBlack, width: 3.5),
          boxShadow: const [
            BoxShadow(
                color: _MC.comicBlack,
                offset: Offset(5, 6),
                blurRadius: 0),
          ],
        ),
        child: Center(
          child: _sending
              ? const SizedBox(
                  width: 26,
                  height: 26,
                  child: CircularProgressIndicator(
                    color: _MC.comicBlack,
                    strokeWidth: 3,
                  ),
                )
              : const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.send_rounded,
                        color: _MC.comicBlack, size: 22),
                    SizedBox(width: 10),
                    Text(
                      'KIRIM LAPORAN',
                      style: TextStyle(
                        color: _MC.comicBlack,
                        fontWeight: FontWeight.w900,
                        fontSize: 15,
                        letterSpacing: 1.5,
                        fontFamily: 'Astral',
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}