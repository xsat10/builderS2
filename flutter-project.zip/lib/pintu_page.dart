import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'landing.dart';

class PintuPage extends StatefulWidget {
  const PintuPage({super.key});

  @override
  State<PintuPage> createState() => _PintuPageState();
}

class _PintuPageState extends State<PintuPage> with TickerProviderStateMixin {
  late VideoPlayerController _videoCtrl;
  late AnimationController _bocilCtrl;
  late Animation<double> _bocilFloatAnim;

  bool _isOpen = false;
  bool _hasNavigated = false;

  @override
  void initState() {
    super.initState();

    // ── 1. Video pintu.mp4 ─────────────────────────────────
    _videoCtrl = VideoPlayerController.asset('assets/videos/pintu.mp4')
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() {});
        _videoCtrl.setLooping(false);
        _videoCtrl.setVolume(0.0);
        _videoCtrl.seekTo(Duration.zero);
        _videoCtrl.pause();
      });

    // ── 2. Bocil float (naik-turun) ────────────────────────
    _bocilCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);
    _bocilFloatAnim = Tween<double>(begin: -6.0, end: 6.0).animate(
      CurvedAnimation(parent: _bocilCtrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _videoCtrl.dispose();
    _bocilCtrl.dispose();
    super.dispose();
  }

  // ─── Saat pintu diklik ───────────────────────────────────
  Future<void> _onTap() async {
    if (_isOpen) return;

    setState(() => _isOpen = true);

    // Play video dari awal
    await _videoCtrl.seekTo(Duration.zero);
    await _videoCtrl.play();

    // Tunggu video selesai + jeda
    final videoDuration = _videoCtrl.value.duration;
    await Future.delayed(videoDuration + const Duration(milliseconds: 500));

    if (!mounted) return;
    if (!_hasNavigated) {
      _hasNavigated = true;
      _navigateToLanding();
    }
  }

  void _navigateToLanding() {
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => const LandingPage(),
        transitionsBuilder: (_, animation, __, child) {
          return FadeTransition(
            opacity: CurvedAnimation(
              parent: animation,
              curve: Curves.easeInOut,
            ),
            child: child,
          );
        },
        transitionDuration: const Duration(milliseconds: 1200),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onTap: _onTap,
        behavior: HitTestBehavior.opaque,
        child: Stack(
          children: [
            // ── 1. Background hitam titik-titik ──────────────
            Positioned.fill(
              child: CustomPaint(painter: _DotPatternPainter()),
            ),

            // ── 2. Video pintu.mp4 (di tengah) ───────────────
            Center(
              child: SizedBox(
                width: 380,
                height: 700,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Stack(
                    children: [
                      // Video player
                      if (_videoCtrl.value.isInitialized)
                        Positioned.fill(
                          child: FittedBox(
                            fit: BoxFit.cover,
                            child: SizedBox(
                              width: _videoCtrl.value.size.width,
                              height: _videoCtrl.value.size.height,
                              child: VideoPlayer(_videoCtrl),
                            ),
                          ),
                        )
                      else
                        Container(color: const Color(0xFF0A0A0A)),

                      // Overlay gelap tipis
                      Positioned.fill(
                        child: Container(
                          color: Colors.black.withValues(alpha: 0.15),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),

            // ── 3. Bocil.png kanan bawah ─────────────────────
            Positioned(
              bottom: 100,
              right: 10,
              child: IgnorePointer(
                child: AnimatedBuilder(
                  animation: _bocilFloatAnim,
                  builder: (context, child) {
                    return Transform.translate(
                      offset: Offset(0, _bocilFloatAnim.value),
                      child: child,
                    );
                  },
                  child: Image.asset(
                    'assets/images/bocil.png',
                    width: 110,
                    height: 110,
                    fit: BoxFit.contain,
                    errorBuilder: (_, __, ___) => const SizedBox.shrink(),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
//  DOT PATTERN PAINTER — Background hitam titik-titik
// ══════════════════════════════════════════════════════════════════════════════
class _DotPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    // Background hitam
    final bgPaint = Paint()..color = const Color(0xFF000000);
    canvas.drawRect(Offset.zero & size, bgPaint);

    // Titik-titik abu
    final dotPaint = Paint()
      ..color = Colors.white.withValues(alpha: 0.08)
      ..style = PaintingStyle.fill;

    const double spacing = 22.0;
    const double radius = 1.2;

    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        canvas.drawCircle(Offset(x, y), radius, dotPaint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}