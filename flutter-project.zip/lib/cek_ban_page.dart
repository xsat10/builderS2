import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';
import 'api_config.dart';

class CekBanPage extends StatefulWidget {
  const CekBanPage({super.key});

  @override
  State<CekBanPage> createState() => _CekBanPageState();
}

class _CekBanPageState extends State<CekBanPage>
    with TickerProviderStateMixin {
  // ─── Controllers ────────────────────────────────────────────────
  late VideoPlayerController _videoController;
  late AnimationController _pulseController;
  late AnimationController _resultCtrl;
  late Animation<double> _resultFade;
  late Animation<Offset> _resultSlide;

  final TextEditingController _nomorController = TextEditingController();
  final FocusNode _nomorFocus = FocusNode();

  // ─── State ──────────────────────────────────────────────────────
  bool _isLoading = false;
  String _statusMessage = 'Masukkan nomor 62xxx lalu tekan tombol cek.';
  Color _statusColor = Colors.grey;
  Map<String, dynamic>? _profileData;
  List<Map<String, dynamic>> _history = [];
  bool _showProfile = false;
  bool _isFetching = false;

  // ─── Colors ─────────────────────────────────────────────────────
  final Color _tealAccent = const Color(0xFF00E5FF);
  final Color _greenAccent = const Color(0xFF00FF88);
  final Color _purpleAccent = const Color(0xFFB388FF);
  final Color _textWhite = Colors.white;
  final Color _textGrey = const Color(0xFF8BAAB8);

  // ─── Lifecycle ──────────────────────────────────────────────────
  @override
  void initState() {
    super.initState();

    _videoController = VideoPlayerController.asset('assets/videos/background.mp4')
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() {});
        _videoController.setLooping(true);
        _videoController.setVolume(0.0);
        _videoController.play();
      });

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _resultCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 500));
    _resultFade = CurvedAnimation(parent: _resultCtrl, curve: Curves.easeOut);
    _resultSlide = Tween<Offset>(begin: const Offset(0, 0.15), end: Offset.zero)
        .animate(CurvedAnimation(parent: _resultCtrl, curve: Curves.easeOutCubic));

    _loadHistory();
  }

  @override
  void dispose() {
    _videoController.dispose();
    _pulseController.dispose();
    _resultCtrl.dispose();
    _nomorController.dispose();
    _nomorFocus.dispose();
    super.dispose();
  }

  // ─── History Storage ────────────────────────────────────────────
  Future<void> _loadHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final String? data = prefs.getString('cekban_history');
    if (data != null) {
      try {
        final List<dynamic> list = jsonDecode(data);
        setState(() {
          _history = list.cast<Map<String, dynamic>>();
          _history.sort((a, b) => (b['timestamp'] as int).compareTo(a['timestamp'] as int));
        });
      } catch (_) {}
    }
  }

  Future<void> _saveHistory() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('cekban_history', jsonEncode(_history));
  }

  Future<void> _addHistory(Map<String, dynamic> entry) async {
    setState(() {
      _history.insert(0, entry);
    });
    await _saveHistory();
  }

  Future<void> _clearHistory() async {
    setState(() {
      _history.clear();
    });
    await _saveHistory();
  }

  Future<void> _removeHistoryItem(int index) async {
    setState(() {
      _history.removeAt(index);
    });
    await _saveHistory();
  }

  // ─── API Call ────────────────────────────────────────────────────
  Future<void> _checkBan() async {
    String raw = _nomorController.text.trim();
    // Bersihkan non-digit
    String cleaned = raw.replaceAll(RegExp(r'[^\d]'), '');
    if (!cleaned.startsWith('62')) {
      setState(() {
        _statusMessage = '❌ Nomor harus diawali 62 (contoh: 6281227125165)';
        _statusColor = Colors.redAccent;
        _showProfile = false;
        _profileData = null;
        _resultCtrl.forward(from: 0);
      });
      return;
    }

    if (cleaned.length < 10) {
      setState(() {
        _statusMessage = '❌ Nomor terlalu pendek, minimal 10 digit.';
        _statusColor = Colors.redAccent;
        _showProfile = false;
        _profileData = null;
        _resultCtrl.forward(from: 0);
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _isFetching = true;
      _statusMessage = '🔄 Sedang mengecek nomor $cleaned...';
      _statusColor = Colors.amber;
      _showProfile = false;
      _profileData = null;
    });

    try {
      final response = await http.get(
        Uri.parse('$baseUrl/checkBan?nomor=$cleaned'),
      ).timeout(const Duration(seconds: 15));

      final data = jsonDecode(response.body);
      if (response.statusCode == 200 && data['success'] == true) {
        // Data profil
        final profile = data['profile'] ?? {};
        final bool isBanned = data['banned'] ?? false;
        final String statusText = isBanned ? '🚫 BANNED' : '✅ AKTIF';
        final Color statusCol = isBanned ? Colors.redAccent : _greenAccent;

        setState(() {
          _profileData = {
            'nomor': cleaned,
            'isBanned': isBanned,
            'status': statusText,
            'namaKontak': profile['nama_kontak'] ?? 'Tidak tersedia',
            'namaAsli': profile['nama_asli'] ?? 'Tidak tersedia',
            'fotoUrl': profile['foto_url'] ?? '',
            'waVersion': profile['wa_version'] ?? 'Tidak diketahui',
            'device': profile['device'] ?? 'Tidak diketahui',
          };
          _showProfile = true;
          _statusMessage = '✅ Selesai! Nomor $cleaned : $statusText';
          _statusColor = statusCol;
          _resultCtrl.forward(from: 0);
        });

        // Simpan riwayat
        await _addHistory({
          'nomor': cleaned,
          'status': statusText,
          'timestamp': DateTime.now().millisecondsSinceEpoch,
          'namaKontak': profile['nama_kontak'] ?? 'Tidak tersedia',
        });
      } else {
        // Gagal
        setState(() {
          _statusMessage = '❌ Gagal: ${data['message'] ?? 'Server error'}';
          _statusColor = Colors.redAccent;
          _showProfile = false;
          _profileData = null;
          _resultCtrl.forward(from: 0);
        });
      }
    } on TimeoutException {
      setState(() {
        _statusMessage = '❌ Request timeout, periksa koneksi.';
        _statusColor = Colors.redAccent;
        _showProfile = false;
        _profileData = null;
      });
    } catch (e) {
      setState(() {
        _statusMessage = '❌ Error: ${e.toString()}';
        _statusColor = Colors.redAccent;
        _showProfile = false;
        _profileData = null;
      });
    } finally {
      setState(() {
        _isLoading = false;
        _isFetching = false;
      });
    }
  }

  // ─── UI Helpers ─────────────────────────────────────────────────
  Widget _glassCard({required Widget child, EdgeInsets? padding, double? blur}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(22),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: blur ?? 14, sigmaY: blur ?? 14),
        child: Container(
          padding: padding ?? const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.06),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: Colors.white.withOpacity(0.12), width: 1.2),
          ),
          child: child,
        ),
      ),
    );
  }

  void _showHistoryDialog() {
  showDialog(
    context: context,
    builder: (_) => BackdropFilter(
      filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
      child: AlertDialog(
        backgroundColor: Colors.black.withOpacity(0.85),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: Row(
          children: [
            Icon(Icons.history_rounded, color: _tealAccent),
            const SizedBox(width: 10),
            Text('Riwayat Cek Banned',
                style: TextStyle(color: _textWhite, fontFamily: 'Astral')),
            const Spacer(),
            if (_history.isNotEmpty)
              TextButton(
                onPressed: _clearHistory,
                child: Text('Hapus Semua',
                    style: TextStyle(color: Colors.redAccent, fontFamily: 'Astral')),
              ),
          ],
        ),
        content: SizedBox(
          width: double.maxFinite,
          height: 350,
          child: _history.isEmpty
              ? Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.history_outlined, color: _textGrey, size: 48),  
                      const SizedBox(height: 12),
                      Text('Belum ada riwayat',
                          style: TextStyle(color: _textGrey, fontFamily: 'Astral')),
                    ],
                  ),
                )
              : ListView.builder(
                  itemCount: _history.length,
                  itemBuilder: (ctx, i) {
                    final item = _history[i];
                    final timestamp = DateTime.fromMillisecondsSinceEpoch(item['timestamp'] as int);
                    final formatted = '${timestamp.day}/${timestamp.month}/${timestamp.year} ${timestamp.hour}:${timestamp.minute}';
                    return ListTile(
                      leading: Icon(Icons.history_rounded, color: _tealAccent),
                      title: Text(item['nomor'] ?? '--',
                          style: TextStyle(color: _textWhite, fontFamily: 'Astral')),
                      subtitle: Text(
                        '${item['status']} • $formatted\n${item['namaKontak'] ?? ''}',
                        style: TextStyle(color: _textGrey, fontFamily: 'Astral', fontSize: 12),
                      ),
                      trailing: IconButton(
                        icon: Icon(Icons.delete_rounded, color: Colors.redAccent),
                        onPressed: () => _removeHistoryItem(i),
                      ),
                    );
                  },
                ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Tutup',
                style: TextStyle(color: _tealAccent, fontFamily: 'Astral')),
          ),
        ],
      ),
    ),
  );
}

  // ─── Build ──────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Background Video
          SizedBox(
            width: double.infinity,
            height: double.infinity,
            child: _videoController.value.isInitialized
                ? VideoPlayer(_videoController)
                : Container(color: Colors.black),
          ),
          // Gradient Overlay
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.black.withOpacity(0.55),
                  Colors.black.withOpacity(0.85),
                ],
              ),
            ),
          ),
          // Content
          SafeArea(
            child: Column(
              children: [
                // Custom AppBar
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
                  child: Row(
                    children: [
                      GestureDetector(
                        onTap: () => Navigator.pop(context),
                        child: Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.white.withOpacity(0.08),
                            border: Border.all(color: Colors.white.withOpacity(0.15)),
                          ),
                          child: const Icon(Icons.arrow_back_rounded, color: Colors.white),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Text(
                        'CEK BANNED WA',
                        style: TextStyle(
                          color: _textWhite,
                          fontFamily: 'Astral',
                          fontWeight: FontWeight.w900,
                          fontSize: 20,
                          letterSpacing: 2,
                        ),
                      ),
                      const Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: _tealAccent, width: 1.5),
                          color: _tealAccent.withOpacity(0.1),
                        ),
                        child: Text(
                          'v1.0',
                          style: TextStyle(
                            color: _tealAccent,
                            fontFamily: 'Astral',
                            fontWeight: FontWeight.bold,
                            fontSize: 13,
                            letterSpacing: 1.5,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const Divider(height: 1, color: Colors.white12),
                Expanded(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        // Input Nomor
                        _glassCard(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Icon(Icons.phone_android_rounded, color: _tealAccent),
                                  const SizedBox(width: 10),
                                  Text(
                                    'Masukkan Nomor Target',
                                    style: TextStyle(
                                      color: _textWhite,
                                      fontFamily: 'Astral',
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 12),
                              ClipRRect(
                                borderRadius: BorderRadius.circular(16),
                                child: BackdropFilter(
                                  filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: Colors.black.withOpacity(0.25),
                                      borderRadius: BorderRadius.circular(16),
                                      border: Border.all(color: Colors.white.withOpacity(0.1)),
                                    ),
                                    child: TextField(
                                      controller: _nomorController,
                                      focusNode: _nomorFocus,
                                      style: TextStyle(color: _textWhite, fontFamily: 'Astral', fontSize: 16),
                                      cursorColor: _tealAccent,
                                      keyboardType: TextInputType.phone,
                                      onSubmitted: (_) => _checkBan(),
                                      decoration: InputDecoration(
                                        hintText: 'Contoh: 6281227125165',
                                        hintStyle: TextStyle(
                                          color: _textGrey.withOpacity(0.5),
                                          fontFamily: 'Astral',
                                          fontSize: 14,
                                        ),
                                        prefixIcon: Padding(
                                          padding: const EdgeInsets.symmetric(horizontal: 16),
                                          child: Icon(Icons.search_rounded, color: _tealAccent, size: 22),
                                        ),
                                        border: InputBorder.none,
                                        contentPadding: const EdgeInsets.symmetric(vertical: 18, horizontal: 16),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 16),
                              // Running Status
                              Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: _statusColor.withOpacity(0.08),
                                  borderRadius: BorderRadius.circular(14),
                                  border: Border.all(color: _statusColor.withOpacity(0.25)),
                                ),
                                child: Row(
                                  children: [
                                    if (_isFetching)
                                      SizedBox(
                                        width: 20,
                                        height: 20,
                                        child: CircularProgressIndicator(
                                          strokeWidth: 2,
                                          valueColor: AlwaysStoppedAnimation<Color>(_statusColor),
                                        ),
                                      )
                                    else
                                      Icon(
                                        _statusColor == Colors.grey
                                            ? Icons.info_outline_rounded
                                            : _statusColor == Colors.amber
                                                ? Icons.timer_rounded
                                                : _statusColor == Colors.redAccent
                                                    ? Icons.error_outline_rounded
                                                    : Icons.check_circle_rounded,
                                        color: _statusColor,
                                        size: 20,
                                      ),
                                    const SizedBox(width: 12),
                                    Expanded(
                                      child: Text(
                                        _statusMessage,
                                        style: TextStyle(
                                          color: _statusColor,
                                          fontFamily: 'Astral',
                                          fontSize: 13,
                                          height: 1.4,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 14),
                        // Row: History Button + Cek Button
                        Row(
                          children: [
                            Expanded(
                              flex: 1,
                              child: GestureDetector(
                                onTap: _showHistoryDialog,
                                child: Container(
                                  height: 56,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(16),
                                    border: Border.all(color: Colors.white.withOpacity(0.15)),
                                    color: Colors.white.withOpacity(0.04),
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(Icons.history_rounded, color: _tealAccent),
                                      const SizedBox(width: 8),
                                      Text(
                                        'Riwayat',
                                        style: TextStyle(
                                          color: _textWhite,
                                          fontFamily: 'Astral',
                                          fontWeight: FontWeight.bold,
                                          fontSize: 14,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              flex: 2,
                              child: AnimatedBuilder(
                                animation: _pulseController,
                                builder: (context, child) {
                                  return Container(
                                    height: 56,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(16),
                                      gradient: const LinearGradient(
                                        colors: [Color(0xFF00E5FF), Color(0xFF00FFB3)],
                                        begin: Alignment.centerLeft,
                                        end: Alignment.centerRight,
                                      ),
                                      boxShadow: [
                                        BoxShadow(
                                          color: _tealAccent.withOpacity(
                                              0.25 + _pulseController.value * 0.3),
                                          blurRadius: 28 + _pulseController.value * 12,
                                          spreadRadius: 2,
                                        ),
                                      ],
                                    ),
                                    child: ElevatedButton(
                                      onPressed: _isLoading ? null : _checkBan,
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: Colors.transparent,
                                        shadowColor: Colors.transparent,
                                        shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(16)),
                                        elevation: 0,
                                      ),
                                      child: _isLoading
                                          ? const SizedBox(
                                              width: 24,
                                              height: 24,
                                              child: CircularProgressIndicator(
                                                  color: Colors.black87, strokeWidth: 3),
                                            )
                                          : Row(
                                              mainAxisAlignment: MainAxisAlignment.center,
                                              children: [
                                                Icon(Icons.shield_rounded,
                                                    color: Colors.black87, size: 22),
                                                const SizedBox(width: 8),
                                                const Text(
                                                  'CEK BANNED',
                                                  style: TextStyle(
                                                    color: Colors.black87,
                                                    fontWeight: FontWeight.w900,
                                                    fontSize: 16,
                                                    fontFamily: 'Astral',
                                                    letterSpacing: 2,
                                                  ),
                                                ),
                                              ],
                                            ),
                                    ),
                                  );
                                },
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 14),
                        // Profile Result
                        if (_showProfile && _profileData != null)
                          _glassCard(
                            padding: const EdgeInsets.all(16),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Container(
                                      width: 60,
                                      height: 60,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        border: Border.all(color: _tealAccent, width: 2),
                                        image: _profileData!['fotoUrl'] != null &&
                                                _profileData!['fotoUrl'].isNotEmpty
                                            ? DecorationImage(
                                                image: NetworkImage(_profileData!['fotoUrl']),
                                                fit: BoxFit.cover,
                                              )
                                            : null,
                                        color: Colors.grey[800],
                                      ),
                                      child: (_profileData!['fotoUrl'] == null ||
                                              _profileData!['fotoUrl'].isEmpty)
                                          ? Icon(Icons.person_rounded,
                                              color: _textGrey, size: 30)
                                          : null,
                                    ),
                                    const SizedBox(width: 16),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            _profileData!['nomor'] ?? '',
                                            style: TextStyle(
                                              color: _textWhite,
                                              fontFamily: 'Astral',
                                              fontWeight: FontWeight.bold,
                                              fontSize: 18,
                                            ),
                                          ),
                                          const SizedBox(height: 4),
                                          Container(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 10, vertical: 3),
                                            decoration: BoxDecoration(
                                              color: (_profileData!['isBanned'] == true)
                                                  ? Colors.redAccent.withOpacity(0.15)
                                                  : _greenAccent.withOpacity(0.15),
                                              borderRadius: BorderRadius.circular(12),
                                              border: Border.all(
                                                color: (_profileData!['isBanned'] == true)
                                                    ? Colors.redAccent
                                                    : _greenAccent,
                                                width: 1.2,
                                              ),
                                            ),
                                            child: Text(
                                              _profileData!['status'] ?? '',
                                              style: TextStyle(
                                                color: (_profileData!['isBanned'] == true)
                                                    ? Colors.redAccent
                                                    : _greenAccent,
                                                fontFamily: 'Astral',
                                                fontWeight: FontWeight.bold,
                                                fontSize: 12,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                                const Divider(color: Colors.white12, height: 24),
                                _buildInfoRow('Nama Kontak', _profileData!['namaKontak'] ?? ''),
                                _buildInfoRow('Nama Asli', _profileData!['namaAsli'] ?? ''),
                                _buildInfoRow('Versi WA', _profileData!['waVersion'] ?? ''),
                                _buildInfoRow('Perangkat', _profileData!['device'] ?? ''),
                                const SizedBox(height: 8),
                                Row(
                                  children: [
                                    Icon(Icons.storage_rounded, color: _textGrey, size: 14),
                                    const SizedBox(width: 8),
                                    Text(
                                      'Data real-time dari server',
                                      style: TextStyle(color: _textGrey, fontFamily: 'Astral', fontSize: 11),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        const SizedBox(height: 30),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 100,
            child: Text(
              label,
              style: TextStyle(
                color: _textGrey,
                fontFamily: 'Astral',
                fontSize: 13,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value.isNotEmpty ? value : '-',
              style: TextStyle(
                color: _textWhite,
                fontFamily: 'Astral',
                fontSize: 13,
              ),
            ),
          ),
        ],
      ),
    );
  }
}