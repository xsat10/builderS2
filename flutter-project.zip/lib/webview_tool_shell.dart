import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

/// Reusable full-screen WebView shell for gateway tools.
/// The shell owns navigation, loading, error recovery, and visual chrome.
class McWebViewShell extends StatefulWidget {
  final String title;
  final String subtitle;
  final String initialUrl;
  final Color accent;
  final IconData icon;

  const McWebViewShell({
    super.key,
    required this.title,
    required this.subtitle,
    required this.initialUrl,
    required this.accent,
    required this.icon,
  });

  @override
  State<McWebViewShell> createState() => _McWebViewShellState();
}

class _McWebViewShellState extends State<McWebViewShell>
    with SingleTickerProviderStateMixin {
  late final WebViewController _controller;
  late final AnimationController _pulseController;

  int _progress = 0;
  bool _hasError = false;
  bool _canGoBack = false;
  bool _canGoForward = false;
  String _currentUrl = '';

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF08080D))
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (value) {
            if (!mounted) return;
            setState(() => _progress = value.clamp(0, 100));
          },
          onPageStarted: (url) {
            if (!mounted) return;
            setState(() {
              _hasError = false;
              _progress = 0;
              _currentUrl = url;
            });
          },
          onPageFinished: (url) async {
            if (!mounted) return;
            final canBack = await _controller.canGoBack();
            final canForward = await _controller.canGoForward();
            if (!mounted) return;
            setState(() {
              _progress = 100;
              _currentUrl = url;
              _canGoBack = canBack;
              _canGoForward = canForward;
            });
          },
          onNavigationRequest: (request) => NavigationDecision.navigate,
          onWebResourceError: (error) {
            // Ignore sub-resource failures; only replace the page on main-frame failure.
            if (error.isForMainFrame != true || !mounted) return;
            setState(() => _hasError = true);
          },
        ),
      )
      ..loadRequest(Uri.parse(widget.initialUrl));
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  Future<void> _refresh() async {
    setState(() {
      _hasError = false;
      _progress = 0;
    });
    await _controller.reload();
  }

  Future<void> _goBack() async {
    if (await _controller.canGoBack()) {
      await _controller.goBack();
    }
  }

  Future<void> _goForward() async {
    if (await _controller.canGoForward()) {
      await _controller.goForward();
    }
  }

  Future<void> _goHome() async {
    setState(() => _hasError = false);
    await _controller.loadRequest(Uri.parse(widget.initialUrl));
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;

    return Scaffold(
      backgroundColor: const Color(0xFF07070B),
      body: SafeArea(
        child: Stack(
          children: [
            Column(
              children: [
                _buildHeader(context),
                Expanded(
                  child: ClipRRect(
                    borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(22),
                    ),
                    child: _hasError
                        ? _buildError(context)
                        : WebViewWidget(controller: _controller),
                  ),
                ),
                _buildBottomBar(context),
              ],
            ),
            if (_progress < 100 && !_hasError)
              Positioned(
                top: 72,
                left: 0,
                right: 0,
                child: LinearProgressIndicator(
                  minHeight: 2,
                  value: _progress / 100,
                  backgroundColor: Colors.transparent,
                  valueColor: AlwaysStoppedAnimation<Color>(widget.accent),
                ),
              ),
          ],
        ),
      ),
      floatingActionButton: _buildFloatingRefresh(context),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Container(
      height: 72,
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: const Color(0xFF0C0C12).withOpacity(.96),
        border: Border(
          bottom: BorderSide(color: Colors.white.withOpacity(.07)),
        ),
      ),
      child: Row(
        children: [
          Semantics(
            button: true,
            label: 'Kembali',
            child: IconButton(
              onPressed: () => Navigator.of(context).maybePop(),
              icon: const Icon(Icons.arrow_back_ios_new_rounded),
              color: Colors.white,
            ),
          ),
          _buildBrandIcon(),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 17,
                    fontWeight: FontWeight.w800,
                    letterSpacing: -.2,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  widget.subtitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: Colors.white.withOpacity(.55),
                    fontSize: 11,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          _livePill(),
        ],
      ),
    );
  }

  Widget _buildBrandIcon() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (context, child) {
        final glow = .18 + (_pulseController.value * .16);
        return Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: widget.accent.withOpacity(.14),
            border: Border.all(color: widget.accent.withOpacity(.55)),
            boxShadow: [
              BoxShadow(
                color: widget.accent.withOpacity(glow),
                blurRadius: 18,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Icon(widget.icon, color: widget.accent, size: 22),
        );
      },
    );
  }

  Widget _livePill() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.greenAccent.withOpacity(.08),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: Colors.greenAccent.withOpacity(.22)),
      ),
      child: const Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.circle, size: 7, color: Colors.greenAccent),
          SizedBox(width: 5),
          Text(
            'LIVE',
            style: TextStyle(
              color: Colors.greenAccent,
              fontSize: 9,
              fontWeight: FontWeight.w900,
              letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomBar(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(8, 8, 8, 10),
      decoration: BoxDecoration(
        color: const Color(0xFF0C0C12),
        border: Border(top: BorderSide(color: Colors.white.withOpacity(.07))),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _navButton(
            icon: Icons.chevron_left_rounded,
            label: 'Back',
            enabled: _canGoBack,
            onPressed: _goBack,
          ),
          _navButton(
            icon: Icons.chevron_right_rounded,
            label: 'Next',
            enabled: _canGoForward,
            onPressed: _goForward,
          ),
          _navButton(
            icon: Icons.home_rounded,
            label: 'Home',
            enabled: true,
            onPressed: _goHome,
          ),
          _navButton(
            icon: Icons.refresh_rounded,
            label: 'Refresh',
            enabled: true,
            onPressed: _refresh,
          ),
        ],
      ),
    );
  }

  Widget _navButton({
    required IconData icon,
    required String label,
    required bool enabled,
    required Future<void> Function() onPressed,
  }) {
    return Semantics(
      button: true,
      enabled: enabled,
      label: label,
      child: IconButton(
        onPressed: enabled ? onPressed : null,
        tooltip: label,
        icon: Icon(icon),
        color: enabled ? Colors.white : Colors.white24,
      ),
    );
  }

  Widget _buildFloatingRefresh(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: .92, end: 1),
      duration: const Duration(milliseconds: 700),
      curve: Curves.easeOutBack,
      builder: (context, scale, child) => Transform.scale(
        scale: scale,
        child: child,
      ),
      child: FloatingActionButton.small(
        heroTag: '${widget.title}_refresh',
        onPressed: _refresh,
        backgroundColor: widget.accent,
        foregroundColor: Colors.white,
        tooltip: 'Refresh halaman',
        child: const Icon(Icons.refresh_rounded),
      ),
    );
  }

  Widget _buildError(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF11111A), Color(0xFF07070B)],
        ),
      ),
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.cloud_off_rounded, size: 58, color: widget.accent),
              const SizedBox(height: 18),
              const Text(
                'Halaman gagal dimuat',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 21,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'Koneksi atau halaman tujuan sedang bermasalah. WebView tetap aman dan siap dicoba lagi.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white.withOpacity(.58),
                  height: 1.45,
                ),
              ),
              const SizedBox(height: 22),
              FilledButton.icon(
                onPressed: _refresh,
                icon: const Icon(Icons.refresh_rounded),
                label: const Text('Muat ulang'),
                style: FilledButton.styleFrom(
                  backgroundColor: widget.accent,
                  minimumSize: const Size(150, 48),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
