import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dart:io';
import '../dashboard_page.dart';

class ModeratorGbScreen extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const ModeratorGbScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<ModeratorGbScreen> createState() => _ModeratorGbScreenState();
}

class _ModeratorGbScreenState extends State<ModeratorGbScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;
  bool _isPressed = false;

  // ─── PALET WARNA HITAM PREMIUM ELEGAN ─────────────────────────────
  final Color _bgColor = const Color(0xFF0A0A0A);         // Hitam pekat
  final Color _cardColor = const Color(0xFF141414);       // Hitam card
  final Color _borderColor = const Color(0xFF2A2A2A);     // Abu gelap
  final Color _accentWhite = const Color(0xFFE8E8E8);     // Putih premium (pengganti emas)
  final Color _accentSoft = const Color(0xFF9CA3AF);      // Abu medium (pengganti emas redup)
  final Color _textPrimary = const Color(0xFFF5F5F5);     // Putih tulang
  final Color _textSecondary = const Color(0xFF888888);   // Abu medium

  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    _fadeController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 800));
    _fadeAnimation =
        CurvedAnimation(parent: _fadeController, curve: Curves.easeOut);
    _fadeController.forward();
  }

  void _navigateToDashboard() {
    if (!mounted) return;
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => DashboardPage(
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          listDoos: widget.listDoos,
          news: widget.news,
        ),
      ),
    );
  }

  Future<void> _openTelegram(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Tidak dapat membuka Telegram')));
    }
  }

  Future<void> _downloadTelegram() async {
    final url = Platform.isAndroid
        ? 'https://play.google.com/store/apps/details?id=org.telegram.messenger'
        : 'https://apps.apple.com/app/telegram-messenger/id686449807';
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  Future<void> _copyText(String text) async {
    await Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Link disalin!')));
  }

  @override
  void dispose() {
    _fadeController.dispose();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final groupUrl = 'https://t.me/+WUQxhbnmaVw4YWVl';
    final groupUrlAby = 'https://t.me/+aYEv1ghFn11mMWZl';

    return Scaffold(
      backgroundColor: _bgColor,
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: const AssetImage('assets/images/telelink.jpg'),
            fit: BoxFit.cover,
            colorFilter: ColorFilter.mode(
              Colors.black.withOpacity(0.88),
              BlendMode.darken,
            ),
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildAppBar(),
              Expanded(
                child: FadeTransition(
                  opacity: _fadeAnimation,
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: Column(
                      children: [
                        const SizedBox(height: 12),
                        _buildKhsSection(
                            title: 'Moderator Ghostcrasher',
                            groupUrl: groupUrl),
                        const SizedBox(height: 20),
                        _buildAbySection(
                            title: 'GhostCrasher',
                            groupUrl: groupUrlAby),
                        const SizedBox(height: 24),
                        _buildSkipButton(),
                        const SizedBox(height: 20),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: _bgColor.withOpacity(0.9),
        border: Border(
          bottom: BorderSide(color: _borderColor.withOpacity(0.6), width: 1),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _cardColor,
                  border: Border.all(
                      color: _accentWhite.withOpacity(0.35), width: 1.5),
                  boxShadow: [
                    BoxShadow(
                        color: Colors.white.withOpacity(0.05),
                        blurRadius: 12,
                        spreadRadius: 1),
                  ],
                ),
                child: Icon(Icons.telegram, color: _accentWhite, size: 22),
              ),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Telegram',
                      style: TextStyle(
                        color: _textPrimary,
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 0.5,
                      )),
                  Text('Official Group',
                      style: TextStyle(
                        color: _textSecondary,
                        fontSize: 11,
                        letterSpacing: 0.5,
                      )),
                ],
              ),
            ],
          ),
          GestureDetector(
            onTap: _downloadTelegram,
            onTapDown: (_) => setState(() => _isPressed = true),
            onTapUp: (_) => setState(() => _isPressed = false),
            onTapCancel: () => setState(() => _isPressed = false),
            child: AnimatedScale(
              scale: _isPressed ? 0.95 : 1.0,
              duration: const Duration(milliseconds: 100),
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: _cardColor,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: _borderColor, width: 1),
                ),
                child: Row(
                  children: [
                    Icon(Icons.download_rounded,
                        color: _accentWhite, size: 16),
                    const SizedBox(width: 6),
                    Text('Download',
                        style: TextStyle(
                          color: _textPrimary,
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                        )),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildKhsSection(
      {required String title, required String groupUrl}) {
    return _buildSection(title: title, groupUrl: groupUrl, isKhs: true);
  }

  Widget _buildAbySection(
      {required String title, required String groupUrl}) {
    return _buildSection(title: title, groupUrl: groupUrl, isKhs: false);
  }

  Widget _buildSection(
      {required String title,
      required String groupUrl,
      required bool isKhs}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: _cardColor.withOpacity(0.95),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _borderColor, width: 1),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.6),
              blurRadius: 20,
              spreadRadius: 2),
          BoxShadow(
              color: Colors.white.withOpacity(0.03),
              blurRadius: 15,
              spreadRadius: 1),
        ],
      ),
      child: Column(
        children: [
          Container(
            width: isKhs ? 78 : 68,
            height: isKhs ? 78 : 68,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                  color: _accentWhite.withOpacity(0.45), width: 2),
              boxShadow: [
                BoxShadow(
                    color: Colors.white.withOpacity(0.08),
                    blurRadius: 20,
                    spreadRadius: 2),
              ],
              image: const DecorationImage(
                  image: AssetImage('assets/images/login.jpg'),
                  fit: BoxFit.cover),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            title,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: _textPrimary,
              fontSize: 18,
              fontWeight: FontWeight.bold,
              letterSpacing: 1.2,
            ),
          ),
          const SizedBox(height: 8),
          Container(
            height: 1.5,
            width: 50,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [
                _accentWhite.withOpacity(0.7),
                _accentWhite.withOpacity(0.05),
              ]),
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(height: 16),
          _buildUrlRow(groupUrl),
          const SizedBox(height: 18),
          _buildDescription(),
          const SizedBox(height: 20),
          _buildJoinButton(groupUrl),
        ],
      ),
    );
  }

  Widget _buildUrlRow(String url) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: _bgColor.withOpacity(0.8),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _borderColor, width: 1),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.link_rounded,
              color: _accentSoft, size: 16),
          const SizedBox(width: 8),
          Flexible(
            child: Text(
              url,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: _textSecondary,
                fontSize: 12,
                letterSpacing: 0.3,
              ),
            ),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: () => _copyText(url),
            child: Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: _cardColor,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: _borderColor, width: 0.5),
              ),
              child: Icon(Icons.copy_rounded,
                  color: _accentWhite, size: 14),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDescription() {
    return Column(
      children: [
        _buildDescRow('Pemilik', '@Skylinnereal'),
        _buildDescRow('Official Channel', '@ghostcrasher18'),
        const SizedBox(height: 10),
        Text(
          'Wajib simpan bukti transfer!',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: _accentWhite.withOpacity(0.9),
            fontSize: 12,
            fontWeight: FontWeight.w500,
            letterSpacing: 0.5,
          ),
        ),
        const SizedBox(height: 12),
        Container(
          padding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: _bgColor.withOpacity(0.6),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _borderColor, width: 0.5),
          ),
          child: Column(
            children: [
              Text('📌 Rules:',
                  style: TextStyle(
                    color: _textPrimary,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  )),
              const SizedBox(height: 8),
              Text(
                '• Dilarang share akun secara gratis\n'
                '• Dilarang promosi\n'
                '• Dilarang menjual akun selain Staff / Moderator / Owner / Admin / Reseller!\n'
                '• Dilarang terima sembarangan\n\n'
                'Apk? Ketik apk.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: _textSecondary,
                  fontSize: 11.5,
                  height: 1.6,
                  letterSpacing: 0.2,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildDescRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text('$label: ',
              style: TextStyle(
                color: _textSecondary,
                fontSize: 12,
                fontWeight: FontWeight.w400,
              )),
          Text(value,
              style: TextStyle(
                color: _accentWhite,
                fontSize: 12,
                fontWeight: FontWeight.w500,
                letterSpacing: 0.3,
              )),
        ],
      ),
    );
  }

  Widget _buildJoinButton(String url) {
    return GestureDetector(
      onTap: () => _openTelegram(url),
      onTapDown: (_) => setState(() => _isPressed = true),
      onTapUp: (_) => setState(() => _isPressed = false),
      onTapCancel: () => setState(() => _isPressed = false),
      child: AnimatedScale(
        scale: _isPressed ? 0.95 : 1.0,
        duration: const Duration(milliseconds: 100),
        child: Container(
          padding:
              const EdgeInsets.symmetric(horizontal: 36, vertical: 14),
          decoration: BoxDecoration(
            color: _accentWhite,
            borderRadius: BorderRadius.circular(30),
            boxShadow: [
              BoxShadow(
                  color: Colors.white.withOpacity(0.15),
                  blurRadius: 16,
                  spreadRadius: 1),
              BoxShadow(
                  color: Colors.black.withOpacity(0.4),
                  blurRadius: 10,
                  offset: const Offset(0, 4)),
            ],
          ),
          child: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.telegram, color: Colors.black, size: 20),
              SizedBox(width: 10),
              Text('Join Group',
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.5,
                  )),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSkipButton() {
    return GestureDetector(
      onTap: _navigateToDashboard,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 14),
        decoration: BoxDecoration(
          color: _cardColor,
          borderRadius: BorderRadius.circular(30),
          border: Border.all(color: _borderColor, width: 1.2),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withOpacity(0.5),
                blurRadius: 10,
                spreadRadius: 2),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Lewati',
                style: TextStyle(
                  color: _textPrimary,
                  fontSize: 15,
                  fontWeight: FontWeight.w500,
                  letterSpacing: 1,
                )),
            const SizedBox(width: 10),
            Icon(Icons.arrow_forward_rounded,
                color: _accentWhite, size: 18),
          ],
        ),
      ),
    );
  }
}