import 'package:flutter/material.dart';
import 'package:otax/ui/theme/themes.dart';
import 'package:otax/ui/theme/types.dart';

/// Dark, glassy, neon-teal theme used for the revamped 3D dashboard.
class AuroraGlow extends ThemeItem {
  @override
  int get id => 2;

  @override
  String get name => 'Aurora Glow';

  @override
  AnimeStreamTheme get theme => AnimeStreamTheme(
        accentColor: const Color(0xFF17E8AC),
        textMainColor: const Color(0xFFEAFFF3),
        textSubColor: const Color(0xFF8FB8A9),
        backgroundColor: const Color(0xFF050B09),
        backgroundSubColor: const Color(0xFF0A1712),
        modalSheetBackgroundColor: const Color(0xFF0D1F16),
        onAccent: const Color(0xFF04231A),
        glowColor: const Color(0xFF17E8AC),
        cardBorderColor: const Color(0x5917E8AC),
        glassColor: const Color(0x8C142C24),
        warmAccent: const Color(0xFFFFB648),
      );

  @override
  AnimeStreamTheme get lightVariant => AnimeStreamTheme(
        accentColor: const Color(0xFF0BA888),
        textMainColor: const Color(0xFF0A1712),
        textSubColor: const Color(0xFF3E6657),
        backgroundColor: const Color(0xFFEFFBF6),
        backgroundSubColor: const Color(0xFFDCF2E9),
        modalSheetBackgroundColor: const Color(0xFFF4FBF8),
        onAccent: const Color(0xFFFFFFFF),
        glowColor: const Color(0xFF0BA888),
        cardBorderColor: const Color(0x330BA888),
        glassColor: const Color(0xB3FFFFFF),
        warmAccent: const Color(0xFFE0692A),
      );
}
