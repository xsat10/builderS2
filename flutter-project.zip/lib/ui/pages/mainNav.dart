import 'package:flutter/material.dart';
import 'package:otax/ui/theme/aurora_glow.dart';
import 'package:otax/ui/theme/types.dart';
import 'package:otax/ui/widgets/glow_card.dart';

class MainNavigator extends StatefulWidget {
  const MainNavigator({super.key});

  @override
  State<MainNavigator> createState() => _MainNavigatorState();
}

class _MainNavigatorState extends State<MainNavigator> {
  int _navIndex = 0;

  // Swap this for a theme pulled from your ThemeProvider once it's wired up.
  final AnimeStreamTheme _theme = AuroraGlow().theme;

  @override
  Widget build(BuildContext context) {
    final theme = _theme;

    return Scaffold(
      backgroundColor: theme.backgroundColor,
      body: Stack(
        children: [
          // Soft ambient glow blob in the top-right corner, like the
          // reference design's background sparkle.
          Positioned(
            top: -100,
            right: -80,
            child: Container(
              width: 260,
              height: 260,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    theme.glowColor.withOpacity(0.18),
                    theme.glowColor.withOpacity(0),
                  ],
                ),
              ),
            ),
          ),
          SafeArea(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
              children: [
                _TopBar(theme: theme),
                const SizedBox(height: 18),
                _LiveBanner(theme: theme, title: 'OTAX X ONE'),
                const SizedBox(height: 20),
                _SectionHeader(theme: theme),
                const SizedBox(height: 12),
                _StatGrid(theme: theme),
                const SizedBox(height: 18),
                _GreetingCard(
                  theme: theme,
                  greeting: 'Selamat siang · 5 Sep 2026',
                  name: 'SYAM',
                  team: 'Team Projeth',
                ),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: _BottomNav(
        theme: theme,
        index: _navIndex,
        onChanged: (i) => setState(() => _navIndex = i),
      ),
      extendBody: true,
    );
  }
}

class _TopBar extends StatelessWidget {
  final AnimeStreamTheme theme;
  const _TopBar({required this.theme});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        _iconChip(Icons.menu, theme),
        Row(
          children: [
            _iconChip(Icons.headset_mic_outlined, theme),
            const SizedBox(width: 8),
            _iconChip(Icons.music_note_outlined, theme),
            const SizedBox(width: 8),
            _iconChip(Icons.notifications_outlined, theme),
            const SizedBox(width: 8),
            _iconChip(Icons.logout, theme),
          ],
        ),
      ],
    );
  }

  Widget _iconChip(IconData icon, AnimeStreamTheme theme) {
    return Container(
      width: 38,
      height: 38,
      decoration: BoxDecoration(
        color: theme.glassColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.35),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Icon(icon, size: 17, color: theme.textSubColor),
    );
  }
}

class _LiveBanner extends StatelessWidget {
  final AnimeStreamTheme theme;
  final String title;
  const _LiveBanner({required this.theme, required this.title});

  @override
  Widget build(BuildContext context) {
    return GlowCard(
      theme: theme,
      strongGlow: true,
      borderRadius: 26,
      padding: EdgeInsets.zero,
      child: SizedBox(
        height: 210,
        child: Stack(
          children: [
            Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topRight,
                    end: Alignment.bottomLeft,
                    colors: [
                      const Color(0xFF1B3D4A),
                      theme.backgroundColor,
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              top: 14,
              left: 14,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: theme.warmAccent,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: theme.warmAccent.withOpacity(0.5),
                      blurRadius: 12,
                    ),
                  ],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: const BoxDecoration(
                        color: Colors.black,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 6),
                    const Text(
                      'LIVE',
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              top: 14,
              right: 14,
              child: GlowIcon(
                icon: Icons.bolt,
                color: theme.warmAccent,
                onColor: Colors.black,
                size: 34,
              ),
            ),
            Positioned(
              left: 16,
              bottom: 16,
              right: 16,
              child: Text(
                title,
                style: TextStyle(
                  color: theme.textMainColor,
                  fontSize: 24,
                  fontWeight: FontWeight.w800,
                  shadows: [
                    Shadow(color: theme.glowColor.withOpacity(0.6), blurRadius: 20),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final AnimeStreamTheme theme;
  const _SectionHeader({required this.theme});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
          decoration: BoxDecoration(
            color: theme.glassColor,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.white.withOpacity(0.08)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 6,
                height: 6,
                decoration: BoxDecoration(
                  color: theme.accentColor,
                  shape: BoxShape.circle,
                  boxShadow: [BoxShadow(color: theme.glowColor, blurRadius: 6)],
                ),
              ),
              const SizedBox(width: 8),
              Text(
                'WAKTU JAM SHOLAT',
                style: TextStyle(
                  color: theme.textMainColor,
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.4,
                ),
              ),
            ],
          ),
        ),
        Container(
          width: 38,
          height: 38,
          decoration: BoxDecoration(
            color: theme.glassColor,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: theme.cardBorderColor),
            boxShadow: [
              BoxShadow(color: theme.glowColor.withOpacity(0.35), blurRadius: 16, spreadRadius: -4),
            ],
          ),
          child: Icon(Icons.refresh, size: 17, color: theme.accentColor),
        ),
      ],
    );
  }
}

class _StatGrid extends StatelessWidget {
  final AnimeStreamTheme theme;
  const _StatGrid({required this.theme});

  @override
  Widget build(BuildContext context) {
    return GlowCard(
      theme: theme,
      borderRadius: 24,
      child: GridView.count(
        crossAxisCount: 2,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
        childAspectRatio: 1.35,
        children: [
          _StatTile(
            theme: theme,
            icon: Icons.battery_charging_full,
            iconColor: theme.accentColor,
            value: '97%',
            label: 'CHARGING',
          ),
          _StatTile(
            theme: theme,
            icon: Icons.thermostat,
            iconColor: const Color(0xFFFF9A5A),
            borderColor: const Color(0x59FF9A5A),
            value: '29°',
            label: 'Cerah',
            sub: 'Terasa 29° · 44%',
          ),
          _StatTile(
            theme: theme,
            icon: Icons.access_time,
            iconColor: const Color(0xFFC6A8FF),
            borderColor: const Color(0x59C6A8FF),
            value: '12:21:11',
            valueFontSize: 16,
            sub: 'Sab, 5 Sep 2026',
          ),
          _StatTile(
            theme: theme,
            icon: Icons.wb_sunny_outlined,
            iconColor: const Color(0xFF2FD6A8),
            value: 'ONLINE',
            valueFontSize: 14,
            sub: 'Surabaya',
          ),
        ],
      ),
    );
  }
}

class _StatTile extends StatelessWidget {
  final AnimeStreamTheme theme;
  final IconData icon;
  final Color iconColor;
  final Color? borderColor;
  final String value;
  final double valueFontSize;
  final String? label;
  final String? sub;

  const _StatTile({
    required this.theme,
    required this.icon,
    required this.iconColor,
    required this.value,
    this.borderColor,
    this.valueFontSize = 18,
    this.label,
    this.sub,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderColor ?? Colors.white.withOpacity(0.08)),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Colors.white.withOpacity(0.05), Colors.white.withOpacity(0)],
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Row(
            children: [
              GlowIcon(icon: icon, color: iconColor, size: 32),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  value,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: theme.textMainColor,
                    fontSize: valueFontSize,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),
          if (label != null) ...[
            const SizedBox(height: 6),
            Text(label!,
                style: TextStyle(color: theme.textSubColor, fontSize: 11, letterSpacing: 0.3)),
          ],
          if (sub != null) ...[
            const SizedBox(height: 2),
            Text(sub!, style: TextStyle(color: theme.textSubColor, fontSize: 10)),
          ],
        ],
      ),
    );
  }
}

class _GreetingCard extends StatelessWidget {
  final AnimeStreamTheme theme;
  final String greeting;
  final String name;
  final String team;

  const _GreetingCard({
    required this.theme,
    required this.greeting,
    required this.name,
    required this.team,
  });

  @override
  Widget build(BuildContext context) {
    return GlowCard(
      theme: theme,
      strongGlow: true,
      borderRadius: 26,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: theme.backgroundColor,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: Colors.white.withOpacity(0.1)),
                ),
                child: Icon(Icons.person_outline, color: theme.accentColor),
              ),
              const Spacer(),
              GlowIcon(
                icon: Icons.chevron_right,
                color: theme.accentColor,
                onColor: theme.onAccent,
                size: 38,
              ),
            ],
          ),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: theme.accentColor.withOpacity(0.14),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              greeting.toUpperCase(),
              style: TextStyle(color: theme.accentColor, fontSize: 10, fontWeight: FontWeight.w800),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            name,
            style: TextStyle(
              color: theme.textMainColor,
              fontSize: 22,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.4,
            ),
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: theme.warmAccent,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [BoxShadow(color: theme.warmAccent.withOpacity(0.4), blurRadius: 10)],
            ),
            child: Text(
              team.toUpperCase(),
              style: const TextStyle(color: Colors.black, fontSize: 10, fontWeight: FontWeight.w800),
            ),
          ),
          const SizedBox(height: 16),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 10),
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: theme.warmAccent.withOpacity(0.14),
              border: Border.all(color: theme.warmAccent.withOpacity(0.3)),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Text(
              '★  OTAX DASHBOARD  ★',
              style: TextStyle(
                color: theme.warmAccent,
                fontSize: 11,
                fontWeight: FontWeight.w800,
                letterSpacing: 1,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _BottomNav extends StatelessWidget {
  final AnimeStreamTheme theme;
  final int index;
  final ValueChanged<int> onChanged;

  const _BottomNav({required this.theme, required this.index, required this.onChanged});

  static const _icons = [
    Icons.home_rounded,
    Icons.groups_outlined,
    Icons.rocket_launch_outlined,
    Icons.build_outlined,
    Icons.person_outline,
  ];

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      child: Container(
        height: 64,
        decoration: BoxDecoration(
          color: theme.backgroundColor.withOpacity(0.85),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: Colors.white.withOpacity(0.08)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.5),
              blurRadius: 24,
              offset: const Offset(0, -6),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: List.generate(_icons.length, (i) {
            final active = i == index;
            return GestureDetector(
              onTap: () => onChanged(i),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: active
                      ? RadialGradient(
                          colors: [
                            Color.lerp(theme.accentColor, Colors.white, 0.35)!,
                            theme.accentColor,
                          ],
                        )
                      : null,
                  boxShadow: active
                      ? [BoxShadow(color: theme.glowColor.withOpacity(0.6), blurRadius: 18, spreadRadius: -2)]
                      : null,
                ),
                child: Icon(
                  _icons[i],
                  size: 19,
                  color: active ? theme.onAccent : theme.textSubColor,
                ),
              ),
            );
          }),
        ),
      ),
    );
  }
}
