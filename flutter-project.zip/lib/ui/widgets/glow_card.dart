import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:otax/ui/theme/types.dart';

/// A glassmorphism card with a soft neon glow and a subtle 3D bevel.
///
/// The "3D" feeling comes from three layers stacked on top of each other:
/// 1. A blurred colored glow behind the card (outer [BoxShadow]).
/// 2. A frosted glass fill (blurred backdrop + translucent color).
/// 3. A 1px gradient border that is lighter on top than on the bottom,
///    which reads as a soft bevel catching light from above.
class GlowCard extends StatelessWidget {
  final Widget child;
  final AnimeStreamTheme theme;
  final EdgeInsetsGeometry padding;
  final double borderRadius;
  final bool strongGlow;
  final VoidCallback? onTap;

  const GlowCard({
    super.key,
    required this.child,
    required this.theme,
    this.padding = const EdgeInsets.all(16),
    this.borderRadius = 22,
    this.strongGlow = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final radius = BorderRadius.circular(borderRadius);

    return Container(
      decoration: BoxDecoration(
        borderRadius: radius,
        boxShadow: [
          // Dark contact shadow for depth.
          BoxShadow(
            color: Colors.black.withOpacity(0.45),
            blurRadius: 24,
            offset: const Offset(0, 14),
          ),
          // Soft colored glow.
          BoxShadow(
            color: theme.glowColor.withOpacity(strongGlow ? 0.35 : 0.18),
            blurRadius: strongGlow ? 44 : 26,
            spreadRadius: strongGlow ? -6 : -8,
          ),
        ],
      ),
      // Gradient "border" trick: outer gradient container padded by 1px,
      // inner container carries the actual glass fill.
      padding: const EdgeInsets.all(1),
      child: DecoratedBox(
        decoration: BoxDecoration(
          borderRadius: radius,
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Colors.white.withOpacity(0.16),
              theme.cardBorderColor,
              Colors.black.withOpacity(0.25),
            ],
          ),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(borderRadius - 1),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
            child: InkWell(
              onTap: onTap,
              child: Container(
                padding: padding,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      theme.glassColor,
                      theme.backgroundColor.withOpacity(0.85),
                    ],
                  ),
                ),
                child: child,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Small round icon "chip" with its own glow, used inside stat cards,
/// the lightning-bolt badge, and the bottom nav's active item.
class GlowIcon extends StatelessWidget {
  final IconData icon;
  final Color color;
  final Color onColor;
  final double size;

  const GlowIcon({
    super.key,
    required this.icon,
    required this.color,
    this.onColor = Colors.black,
    this.size = 34,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.3, -0.3),
          colors: [
            Color.lerp(color, Colors.white, 0.35)!,
            color,
          ],
        ),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.55),
            blurRadius: 14,
            spreadRadius: -2,
          ),
        ],
      ),
      child: Icon(icon, size: size * 0.5, color: onColor),
    );
  }
}
