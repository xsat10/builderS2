import 'package:otax/ui/theme/aurora_glow.dart';
import 'package:otax/ui/theme/lime.dart';
import 'package:otax/ui/theme/types.dart';

abstract class ThemeItem {
  int get id;
  String get name;
  AnimeStreamTheme get theme;
  AnimeStreamTheme get lightVariant;
}

List<ThemeItem> availableThemes = [
  AuroraGlow(),
  LimeZest(),
];
