import 'package:flutter/material.dart';

class AnimeStreamTheme {
  Color accentColor;
  Color textMainColor;
  Color textSubColor;
  Color backgroundColor;
  Color backgroundSubColor;
  Color modalSheetBackgroundColor;
  Color onAccent;

  /// Color used for the soft outer glow around cards, badges and buttons.
  /// Falls back to [accentColor] when not supplied so existing themes
  /// (e.g. LimeZest) keep working without changes.
  Color glowColor;

  /// Hairline border color drawn around glass-style cards.
  Color cardBorderColor;

  /// Semi-transparent fill used for the glassmorphism card background.
  Color glassColor;

  /// Warm secondary accent used for badges like "LIVE" / team tags.
  Color warmAccent;

  AnimeStreamTheme({
    required this.accentColor,
    required this.textMainColor,
    required this.textSubColor,
    required this.backgroundColor,
    required this.backgroundSubColor,
    required this.modalSheetBackgroundColor,
    required this.onAccent,
    Color? glowColor,
    Color? cardBorderColor,
    Color? glassColor,
    Color? warmAccent,
  })  : glowColor = glowColor ?? accentColor,
        cardBorderColor = cardBorderColor ?? accentColor.withOpacity(0.35),
        glassColor = glassColor ?? backgroundSubColor.withOpacity(0.55),
        warmAccent = warmAccent ?? const Color(0xFFFFB648);
}
