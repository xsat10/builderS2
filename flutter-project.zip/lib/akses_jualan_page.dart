// ============================================================
// 💰 AKSES JUALAN — Dark Red Comic 3D Edition
// File: akses_jualan_page.dart
// ============================================================
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class _MC {
  static const red          = Color(0xFF8B0000);
  static const redDeep      = Color(0xFF1A0A0A);
  static const redDark      = Color(0xFF4A0000);
  static const redSoft      = Color(0xFF2A0E0E);
  static const brightRed    = Color(0xFFFF3B3B);
  static const buttonYellow = Color(0xFFB8860B);
  static const buttonDark   = Color(0xFF1A1A1A);
  static const comicBlack   = Color(0xFF000000);
  static const white        = Color(0xFFFFF5F5);
  static const textGrey     = Color(0xFFC9A0A0);
  static const textLight    = Color(0xFF8A6060);
  static const green        = Color(0xFF22C55E);
  static const greenLite    = Color(0xFF4ADE80);
  static const amber        = Color(0xFFFBBF24);
}

class AksesJualanPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  const AksesJualanPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<AksesJualanPage> createState() => _AksesJualanPageState();
}

class _AksesJualanPageState extends State<AksesJualanPage> {
  final _usernameCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();
  final _hariCtrl = TextEditingController();

  String _paymentType = 'DP';
  String _roleType = 'MEMBER';
  bool _submitting = false;
  String? _errorMsg;

  // Stats
  int _totalPendapatan = 0;
  int _totalStoran = 0;
  int _totalAkunDibuat = 0;

  @override
  void initState() {
    super.initState();
    _loadStats();
  }

  @override
  void dispose() {
    _usernameCtrl.dispose();
    _passwordCtrl.dispose();
    _hariCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadStats() async {
    final prefs = await SharedPreferences.getInstance();
    if (mounted) {
      setState(() {
        _totalPendapatan =
            prefs.getInt('jualan_pendapatan_${widget.username}') ?? 0;
        _totalStoran =
            prefs.getInt('jualan_storan_${widget.username}') ?? 0;
        _totalAkunDibuat =
            prefs.getInt('jualan_akun_${widget.username}') ?? 0;
      });
    }
  }

  Future<void> _submitAkun() async {
    final uname = _usernameCtrl.text.trim();
    final pass = _passwordCtrl.text.trim();
    final hariStr = _hariCtrl.text.trim();

    if (uname.isEmpty || pass.isEmpty || hariStr.isEmpty) {
      setState(() => _errorMsg = '❌ Semua field harus diisi!');
      return;
    }

    final hari = int.tryParse(hariStr);
    if (hari == null || hari <= 0) {
      setState(() => _errorMsg = '❌ Hari harus berupa angka > 0');
      return;
    }

    setState(() {
      _submitting = true;
      _errorMsg = null;
    });

    try {
      final prefs = await SharedPreferences.getInstance();
      final key = 'validasi_akun_${widget.username}';
      final existing = prefs.getStringList(key) ?? [];

      final data = {
        'id': DateTime.now().millisecondsSinceEpoch.toString(),
        'seller': widget.username,
        'username': uname,
        'password': pass,
        'hari': hari,
        'paymentType': _paymentType,
        'role': _roleType,
        'status': 'pending',
        'timestamp': DateTime.now().millisecondsSinceEpoch,
      };

      existing.insert(0, jsonEncode(data));
      await prefs.setStringList(key, existing);

      // Update counter akun
      await prefs.setInt('jualan_akun_${widget.username}',
          _totalAkunDibuat + 1);

      if (!mounted) return;

      setState(() {
        _submitting = false;
        _usernameCtrl.clear();
        _passwordCtrl.clear();
        _hariCtrl.clear();
        _totalAkunDibuat += 1;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          backgroundColor: _MC.green,
          content: Row(
            children: [
              Icon(Icons.check_circle_rounded,
                  color: _MC.comicBlack, size: 20),
              SizedBox(width: 8),
              Expanded(
                child: Text(
                  '✅ Akun dikirim ke validasi! Tunggu ACC dari Owner.',
                  style: TextStyle(
                      color: _MC.comicBlack,
                      fontWeight: FontWeight.w800),
                ),
              ),
            ],
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _submitting = false;
        _errorMsg = '❌ Gagal submit: $e';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _MC.redDeep,
      appBar: AppBar(
        backgroundColor: _MC.redDark,
        elevation: 0,
        centerTitle: true,
        leading: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            margin: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: _MC.buttonDark,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _MC.comicBlack, width: 2.5),
              boxShadow: const [
                BoxShadow(
                    color: _MC.comicBlack,
                    offset: Offset(2, 2),
                    blurRadius: 0),
              ],
            ),
            child: const Icon(Icons.arrow_back_ios_new_rounded,
                color: _MC.white, size: 16),
          ),
        ),
        title: Container(
          padding:
              const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
          decoration: BoxDecoration(
            color: _MC.buttonDark,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: _MC.comicBlack, width: 2.5),
            boxShadow: const [
              BoxShadow(
                  color: _MC.comicBlack,
                  offset: Offset(3, 3),
                  blurRadius: 0),
            ],
          ),
          child: const Text(
            'AKSES JUALAN',
            style: TextStyle(
              color: _MC.white,
              fontWeight: FontWeight.w900,
              fontSize: 13,
              letterSpacing: 2,
              fontFamily: 'Astral',
            ),
          ),
        ),
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _buildStatsRow(),
            const SizedBox(height: 16),
            _buildPaymentSelector(),
            const SizedBox(height: 16),
            _buildRoleSelector(),
            const SizedBox(height: 16),
            _buildAccountForm(),
            if (_errorMsg != null) ...[
              const SizedBox(height: 12),
              _buildErrorBox(),
            ],
            const SizedBox(height: 20),
            _buildSubmitButton(),
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }

  // ═══ STATS ROW — 3 BUTTON DI ATAS ═══
  Widget _buildStatsRow() {
    return Row(
      children: [
        Expanded(
          child: _buildStatCard(
            icon: Icons.attach_money_rounded,
            label: 'PENDAPATAN',
            value: 'Rp $_totalPendapatan',
            color: _MC.greenLite,
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: _buildStatCard(
            icon: Icons.savings_rounded,
            label: 'STORAN',
            value: 'Rp $_totalStoran',
            color: _MC.buttonYellow,
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: _buildStatCard(
            icon: Icons.person_add_rounded,
            label: 'AKUN DIBUAT',
            value: '$_totalAkunDibuat',
            color: _MC.brightRed,
          ),
        ),
      ],
    );
  }

  Widget _buildStatCard({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
      decoration: BoxDecoration(
        color: _MC.redSoft,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _MC.comicBlack, width: 3),
        boxShadow: const [
          BoxShadow(
              color: _MC.comicBlack,
              offset: Offset(4, 4),
              blurRadius: 0),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color,
              border: Border.all(color: _MC.comicBlack, width: 2),
            ),
            child: Icon(icon, color: _MC.comicBlack, size: 16),
          ),
          const SizedBox(height: 6),
          Text(
            label,
            style: const TextStyle(
              color: _MC.textGrey,
              fontSize: 8,
              fontWeight: FontWeight.w900,
              letterSpacing: 0.8,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: _MC.white,
              fontSize: 11,
              fontWeight: FontWeight.w900,
              fontFamily: 'Astral',
            ),
          ),
        ],
      ),
    );
  }

  // ═══ PAYMENT SELECTOR — DP / LUNAS ═══
  Widget _buildPaymentSelector() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _MC.redSoft,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _MC.comicBlack, width: 3.5),
        boxShadow: const [
          BoxShadow(
              color: _MC.comicBlack,
              offset: Offset(5, 5),
              blurRadius: 0),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.payment_rounded,
                  color: _MC.brightRed, size: 18),
              SizedBox(width: 8),
              Text(
                'TIPE PEMBAYARAN',
                style: TextStyle(
                  color: _MC.white,
                  fontWeight: FontWeight.w900,
                  fontSize: 12,
                  letterSpacing: 1.5,
                  fontFamily: 'Astral',
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _buildSelectBtn('DP', 'DP', Icons.timer_rounded),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _buildSelectBtn(
                    'LUNAS', 'LUNAS', Icons.check_circle_rounded),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ═══ ROLE SELECTOR — MEMBER / RESELLER ═══
  Widget _buildRoleSelector() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _MC.redSoft,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _MC.comicBlack, width: 3.5),
        boxShadow: const [
          BoxShadow(
              color: _MC.comicBlack,
              offset: Offset(5, 5),
              blurRadius: 0),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.verified_user_rounded,
                  color: _MC.brightRed, size: 18),
              SizedBox(width: 8),
              Text(
                'PILIH ROLE',
                style: TextStyle(
                  color: _MC.white,
                  fontWeight: FontWeight.w900,
                  fontSize: 12,
                  letterSpacing: 1.5,
                  fontFamily: 'Astral',
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _buildSelectBtn(
                    'MEMBER', 'MEMBER', Icons.person_rounded),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _buildSelectBtn(
                    'RESELLER', 'RESELLER', Icons.storefront_rounded),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSelectBtn(String label, String value, IconData icon) {
    final active = (label == 'DP' || label == 'LUNAS')
        ? _paymentType == value
        : _roleType == value;

    return GestureDetector(
      onTap: () {
        setState(() {
          if (label == 'DP' || label == 'LUNAS') {
            _paymentType = value;
          } else {
            _roleType = value;
          }
        });
      },
      child: Container(
        height: 54,
        decoration: BoxDecoration(
          color: active ? _MC.brightRed : _MC.buttonDark,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _MC.comicBlack, width: 3),
          boxShadow: const [
            BoxShadow(
                color: _MC.comicBlack,
                offset: Offset(3, 3),
                blurRadius: 0),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: _MC.white, size: 18),
            const SizedBox(width: 8),
            Text(
              label,
              style: const TextStyle(
                color: _MC.white,
                fontWeight: FontWeight.w900,
                fontSize: 12,
                letterSpacing: 1.2,
                fontFamily: 'Astral',
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══ ACCOUNT FORM ═══
  Widget _buildAccountForm() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _MC.redSoft,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _MC.comicBlack, width: 3.5),
        boxShadow: const [
          BoxShadow(
              color: _MC.comicBlack,
              offset: Offset(5, 5),
              blurRadius: 0),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.account_box_rounded,
                  color: _MC.brightRed, size: 18),
              SizedBox(width: 8),
              Text(
                'DATA AKUN BUYER',
                style: TextStyle(
                  color: _MC.white,
                  fontWeight: FontWeight.w900,
                  fontSize: 12,
                  letterSpacing: 1.5,
                  fontFamily: 'Astral',
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          _buildInputField(
            controller: _usernameCtrl,
            label: 'USERNAME',
            hint: 'username buyer',
            icon: Icons.person_rounded,
          ),
          const SizedBox(height: 10),
          _buildInputField(
            controller: _passwordCtrl,
            label: 'PASSWORD',
            hint: 'password buyer',
            icon: Icons.lock_rounded,
          ),
          const SizedBox(height: 10),
          _buildInputField(
            controller: _hariCtrl,
            label: 'HARI',
            hint: 'contoh: 30',
            icon: Icons.calendar_today_rounded,
            keyboardType: TextInputType.number,
          ),
        ],
      ),
    );
  }

  Widget _buildInputField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
    TextInputType keyboardType = TextInputType.text,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            color: _MC.textGrey,
            fontSize: 9,
            fontWeight: FontWeight.w900,
            letterSpacing: 1.2,
            fontFamily: 'Astral',
          ),
        ),
        const SizedBox(height: 5),
        Container(
          decoration: BoxDecoration(
            color: _MC.redDeep,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _MC.comicBlack, width: 3),
            boxShadow: const [
              BoxShadow(
                  color: _MC.comicBlack,
                  offset: Offset(3, 3),
                  blurRadius: 0),
            ],
          ),
          child: TextField(
            controller: controller,
            keyboardType: keyboardType,
            style: const TextStyle(
              color: _MC.white,
              fontSize: 13,
              fontWeight: FontWeight.w700,
            ),
            cursorColor: _MC.brightRed,
            decoration: InputDecoration(
              hintText: hint,
              hintStyle:
                  const TextStyle(color: _MC.textLight, fontSize: 12),
              prefixIcon: Icon(icon, color: _MC.brightRed, size: 18),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(
                  vertical: 14, horizontal: 10),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildErrorBox() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _MC.red.withOpacity(0.3),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _MC.comicBlack, width: 2.5),
      ),
      child: Row(
        children: [
          const Icon(Icons.error_outline_rounded,
              color: _MC.brightRed, size: 18),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              _errorMsg!,
              style: const TextStyle(
                color: _MC.brightRed,
                fontSize: 12,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSubmitButton() {
    return GestureDetector(
      onTap: _submitting ? null : _submitAkun,
      child: Container(
        height: 60,
        decoration: BoxDecoration(
          color: _submitting ? _MC.buttonDark : _MC.buttonYellow,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _MC.comicBlack, width: 3.5),
          boxShadow: const [
            BoxShadow(
                color: _MC.comicBlack,
                offset: Offset(5, 6),
                blurRadius: 0),
          ],
        ),
        child: Center(
          child: _submitting
              ? const SizedBox(
                  width: 26,
                  height: 26,
                  child: CircularProgressIndicator(
                    color: _MC.comicBlack,
                    strokeWidth: 3,
                  ),
                )
              : const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.upload_rounded,
                        color: _MC.comicBlack, size: 22),
                    SizedBox(width: 10),
                    Text(
                      'KIRIM KE VALIDASI',
                      style: TextStyle(
                        color: _MC.comicBlack,
                        fontWeight: FontWeight.w900,
                        fontSize: 15,
                        letterSpacing: 1.5,
                        fontFamily: 'Astral',
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}