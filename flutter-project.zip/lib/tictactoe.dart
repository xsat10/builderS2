import 'package:flutter/material.dart';
import 'dart:math';

void main() {
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: TicTacToeGame(),
  ));
}

enum GameMode { bot, twoPlayer }

class TicTacToeGame extends StatefulWidget {
  const TicTacToeGame({super.key});

  @override
  State<TicTacToeGame> createState() => _TicTacToeGameState();
}

// ✅ FIX DI SINI (DITAMBAH _ )
class _TicTacToeGameState extends State<TicTacToeGame> {
  List<String> board = List.generate(9, (_) => '');
  String currentPlayer = 'X';
  bool gameOver = false;
  String winner = '';
  GameMode selectedMode = GameMode.bot;
  int scoreX = 0;
  int scoreO = 0;

  void handleTap(int index) {
    if (board[index].isNotEmpty || gameOver) return;

    setState(() {
      board[index] = currentPlayer;
      checkWinner();

      if (!gameOver) {
        if (selectedMode == GameMode.bot && currentPlayer == 'X') {
          currentPlayer = 'O';
          Future.delayed(const Duration(milliseconds: 400), botMove);
        } else {
          currentPlayer = currentPlayer == 'X' ? 'O' : 'X';
        }
      }
    });
  }

  void botMove() {
    if (gameOver) return;

    List<int> emptyIndexes = [];
    for (int i = 0; i < board.length; i++) {
      if (board[i].isEmpty) emptyIndexes.add(i);
    }

    if (emptyIndexes.isEmpty) return;

    int move = emptyIndexes[Random().nextInt(emptyIndexes.length)];

    setState(() {
      board[move] = 'O';
      checkWinner();
      if (!gameOver) currentPlayer = 'X';
    });
  }

  void checkWinner() {
    const winPatterns = [
      [0, 1, 2],
      [3, 4, 5],
      [6, 7, 8],
      [0, 3, 6],
      [1, 4, 7],
      [2, 5, 8],
      [0, 4, 8],
      [2, 4, 6],
    ];

    for (var pattern in winPatterns) {
      if (board[pattern[0]].isNotEmpty &&
          board[pattern[0]] == board[pattern[1]] &&
          board[pattern[1]] == board[pattern[2]]) {
        gameOver = true;
        winner = board[pattern[0]];
        if (winner == 'X') scoreX++;
        if (winner == 'O') scoreO++;
        return;
      }
    }

    if (!board.contains('')) {
      gameOver = true;
      winner = 'Draw';
    }
  }

  void resetGame() {
    setState(() {
      board = List.generate(9, (_) => '');
      currentPlayer = 'X';
      gameOver = false;
      winner = '';
    });
  }

  void changeMode(GameMode mode) {
    setState(() {
      selectedMode = mode;
      scoreX = 0;
      scoreO = 0;
      resetGame();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF141E30),
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              'TIC TAC TOE',
              style: TextStyle(
                fontSize: 32,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 10),
            ToggleButtons(
              isSelected: [
                selectedMode == GameMode.bot,
                selectedMode == GameMode.twoPlayer
              ],
              onPressed: (index) {
                changeMode(
                    index == 0 ? GameMode.bot : GameMode.twoPlayer);
              },
              borderRadius: BorderRadius.circular(20),
              children: const [
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16),
                  child: Text('VS BOT'),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16),
                  child: Text('2 PLAYER'),
                ),
              ],
            ),
            const SizedBox(height: 15),
            Text(
              'Score  X: $scoreX  |  O: $scoreO',
              style: const TextStyle(fontSize: 18, color: Colors.white),
            ),
            const SizedBox(height: 10),
            Text(
              gameOver
                  ? winner == 'Draw'
                      ? 'Game Seri!'
                      : 'Pemenang: $winner'
                  : 'Giliran: $currentPlayer',
              style:
                  const TextStyle(fontSize: 20, color: Colors.white),
            ),
            const SizedBox(height: 25),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: AspectRatio(
                aspectRatio: 1,
                child: GridView.builder(
                  itemCount: 9,
                  gridDelegate:
                      const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    mainAxisSpacing: 12,
                    crossAxisSpacing: 12,
                  ),
                  itemBuilder: (context, index) {
                    return GestureDetector(
                      onTap: () => handleTap(index),
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.white10,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Center(
                          child: Text(
                            board[index],
                            style: TextStyle(
                              fontSize: 60,
                              fontWeight: FontWeight.bold,
                              color: board[index] == 'X'
                                  ? Colors.blue
                                  : Colors.red,
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: resetGame,
              child: const Text('MAIN LAGI'),
            ),
          ],
        ),
      ),
    );
  }
}