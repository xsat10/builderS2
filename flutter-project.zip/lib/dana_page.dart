// ============================================================
// 💰 DANA PAGE — Dark Red Comic 3D Edition
// File: dana_page.dart
// v2 — Fixed (_MC.cream added) + DANA Wallet Local
// ============================================================
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ═════════════════════════════════════════════════════════════
// 🎨 DARK RED COMIC PALETTE
// ═════════════════════════════════════════════════════════════
class _MC {
  static const red          = Color(0xFF8B0000);
  static const redDeep      = Color(0xFF1A0A0A);
  static const redDark      = Color(0xFF4A0000);
  static const redSoft      = Color(0xFF2A0E0E);
  static const redLight     = Color(0xFF3D1414);
  static const accentRed    = Color(0xFFD32F2F);
  static const brightRed    = Color(0xFFFF3B3B);
  static const buttonYellow = Color(0xFFB8860B);
  static const buttonDark   = Color(0xFF1A1A1A);
  static const comicBlack   = Color(0xFF000000);
  static const comicOutline = Color(0xFF1A0000);
  static const white        = Color(0xFFFFF5F5);
  static const cream        = Color(0xFF0F0505);   // ═══ FIX ═══
  static const textDark     = Color(0xFFFFF5F5);
  static const textGrey     = Color(0xFFC9A0A0);
  static const textLight    = Color(0xFF8A6060);
  static const green        = Color(0xFF22C55E);
  static const greenLite    = Color(0xFF4ADE80);
  static const amber        = Color(0xFFFBBF24);
  static const gold         = Color(0xFFFDE68A);
  static const blueCheck    = Color(0xFF60A5FA);
  // ═══ DANA BLUE ═══
  static const danaBlue     = Color(0xFF0B6EF5);
  static const danaBlueDark = Color(0xFF0848A8);
  static const danaBlueLite = Color(0xFF3B8EFF);
}

class DanaPage extends StatefulWidget {
  final String username;
  const DanaPage({super.key, required this.username});

  @override
  State<DanaPage> createState() => _DanaPageState();
}

class _DanaPageState extends State<DanaPage> {
  // ═══ STATE ═══
  bool _isRegistered = false;
  bool _loading = true;
  String? _phoneNumber;
  int _balance = 0;

  // Form input nomor HP
  final _phoneCtrl = TextEditingController();
  String? _errorMsg;

  // State untuk Top Up
  final _topupCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadWallet();
  }

  @override
  void dispose() {
    _phoneCtrl.dispose();
    _topupCtrl.dispose();
    super.dispose();
  }

  // ════════════════════════════════════════════════════════════
  // 📂 LOAD WALLET DARI LOCAL STORAGE
  // ════════════════════════════════════════════════════════════
  Future<void> _loadWallet() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final phone = prefs.getString('dana_phone_${widget.username}');
      final balance = prefs.getInt('dana_balance_${widget.username}') ?? 0;

      if (mounted) {
        setState(() {
          _phoneNumber = phone;
          _balance = balance;
          _isRegistered = phone != null && phone.isNotEmpty;
          _loading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  // ════════════════════════════════════════════════════════════
  // 📱 REGISTER NOMOR HP (WAJIB seperti DANA asli)
  // ════════════════════════════════════════════════════════════
  Future<void> _registerPhone() async {
    final raw = _phoneCtrl.text.trim();

    if (raw.isEmpty) {
      setState(() => _errorMsg = '❌ Masukkan nomor HP Anda!');
      return;
    }
    if (!raw.startsWith('08')) {
      setState(() =>
          _errorMsg = '❌ Nomor harus dimulai dengan 08 (contoh: 08123456789)');
      return;
    }
    if (raw.length < 10 || raw.length > 13) {
      setState(() =>
          _errorMsg = '❌ Panjang nomor tidak valid (10-13 digit)');
      return;
    }
    if (!RegExp(r'^[0-9]+$').hasMatch(raw)) {
      setState(() => _errorMsg = '❌ Nomor hanya boleh angka!');
      return;
    }

    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('dana_phone_${widget.username}', raw);
      await prefs.setInt('dana_balance_${widget.username}', 0);
      await prefs.setInt(
          'dana_registered_at_${widget.username}',
          DateTime.now().millisecondsSinceEpoch);

      if (!mounted) return;

      setState(() {
        _phoneNumber = raw;
        _balance = 0;
        _isRegistered = true;
        _errorMsg = null;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          backgroundColor: _MC.green,
          content: Text(
            '✅ Akun DANA berhasil dibuat!',
            style: TextStyle(
                color: _MC.comicBlack, fontWeight: FontWeight.w900),
          ),
        ),
      );
    } catch (e) {
      setState(() => _errorMsg = '❌ Gagal: $e');
    }
  }

  // ════════════════════════════════════════════════════════════
  // 💵 TOP UP SALDO
  // ════════════════════════════════════════════════════════════
  Future<void> _topup() async {
    final raw = _topupCtrl.text.trim();
    final nominal = int.tryParse(raw);

    if (nominal == null || nominal < 10000) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          backgroundColor: _MC.red,
          content: Text('❌ Minimal Top Up Rp 10.000',
              style: TextStyle(
                  color: _MC.white, fontWeight: FontWeight.w900)),
        ),
      );
      return;
    }

    try {
      final prefs = await SharedPreferences.getInstance();
      final newBalance = _balance + nominal;
      await prefs.setInt(
          'dana_balance_${widget.username}', newBalance);

      if (!mounted) return;

      setState(() {
        _balance = newBalance;
        _topupCtrl.clear();
      });

      Navigator.pop(context);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: _MC.green,
          content: Text(
            '✅ Top Up Rp ${_formatRupiah(nominal)} berhasil!',
            style: const TextStyle(
                color: _MC.comicBlack, fontWeight: FontWeight.w900),
          ),
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: _MC.red,
          content: Text('❌ Gagal: $e',
              style: const TextStyle(color: _MC.white)),
        ),
      );
    }
  }

  // ════════════════════════════════════════════════════════════
  // 🚪 LOGOUT DANA
  // ════════════════════════════════════════════════════════════
  Future<void> _logoutDana() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: _MC.redSoft,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _MC.comicBlack, width: 3.5),
            boxShadow: const [
              BoxShadow(
                  color: _MC.comicBlack,
                  offset: Offset(6, 6),
                  blurRadius: 0),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 60, height: 60,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _MC.brightRed,
                  border: Border.all(color: _MC.comicBlack, width: 3),
                ),
                child: const Icon(Icons.warning_rounded,
                    color: _MC.white, size: 30),
              ),
              const SizedBox(height: 14),
              const Text('KELUAR DANA?',
                  style: TextStyle(
                    color: _MC.white,
                    fontWeight: FontWeight.w900,
                    fontSize: 16,
                    fontFamily: 'Astral',
                  )),
              const SizedBox(height: 8),
              const Text(
                  'Anda yakin ingin keluar dari akun DANA ini? Saldo tetap tersimpan.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: _MC.textGrey, fontSize: 12, height: 1.4)),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () => Navigator.pop(ctx, false),
                      child: Container(
                        height: 46,
                        decoration: BoxDecoration(
                          color: _MC.buttonDark,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                              color: _MC.comicBlack, width: 2.5),
                        ),
                        child: const Center(
                          child: Text('BATAL',
                              style: TextStyle(
                                color: _MC.white,
                                fontSize: 12,
                                fontWeight: FontWeight.w900,
                              )),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: GestureDetector(
                      onTap: () => Navigator.pop(ctx, true),
                      child: Container(
                        height: 46,
                        decoration: BoxDecoration(
                          color: _MC.red,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                              color: _MC.comicBlack, width: 2.5),
                        ),
                        child: const Center(
                          child: Text('KELUAR',
                              style: TextStyle(
                                color: _MC.white,
                                fontSize: 12,
                                fontWeight: FontWeight.w900,
                              )),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );

    if (confirm != true) return;

    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('dana_phone_${widget.username}');
    await prefs.remove('dana_balance_${widget.username}');

    if (mounted) {
      setState(() {
        _isRegistered = false;
        _phoneNumber = null;
        _balance = 0;
      });
    }
  }

  // ════════════════════════════════════════════════════════════
  // 🎨 FORMAT RUPIAH
  // ════════════════════════════════════════════════════════════
  String _formatRupiah(int value) {
    final str = value.toString();
    final buffer = StringBuffer();
    for (int i = 0; i < str.length; i++) {
      if (i > 0 && (str.length - i) % 3 == 0) buffer.write('.');
      buffer.write(str[i]);
    }
    return buffer.toString();
  }

  String _maskPhone(String phone) {
    if (phone.length < 6) return phone;
    return '${phone.substring(0, 4)}****${phone.substring(phone.length - 3)}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _MC.cream,
      body: Stack(
        children: [
          Positioned.fill(child: CustomPaint(painter: _GridPainter())),
          SafeArea(
            child: _loading
                ? const Center(
                    child: CircularProgressIndicator(
                        color: _MC.brightRed))
                : _isRegistered
                    ? _buildWalletView()
                    : _buildRegisterView(),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // 📱 REGISTER VIEW (Wajib isi nomor HP dulu)
  // ═══════════════════════════════════════════════════════════
  Widget _buildRegisterView() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // TOP BAR
          Row(
            children: [
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: 42, height: 42,
                  decoration: BoxDecoration(
                    color: _MC.buttonDark,
                    borderRadius: BorderRadius.circular(12),
                    border:
                        Border.all(color: _MC.comicBlack, width: 3),
                    boxShadow: const [
                      BoxShadow(
                          color: _MC.comicBlack,
                          offset: Offset(3, 3),
                          blurRadius: 0),
                    ],
                  ),
                  child: const Icon(
                      Icons.arrow_back_ios_new_rounded,
                      color: _MC.white, size: 16),
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: _MC.danaBlue,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _MC.comicBlack, width: 3),
                  boxShadow: const [
                    BoxShadow(
                        color: _MC.comicBlack,
                        offset: Offset(4, 5),
                        blurRadius: 0),
                  ],
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.account_balance_wallet_rounded,
                        color: _MC.white, size: 14),
                    SizedBox(width: 6),
                    Text('DANA',
                        style: TextStyle(
                          color: _MC.white,
                          fontSize: 13,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 2,
                          fontFamily: 'Astral',
                        )),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 30),

          // LOGO DANA
          Center(
            child: Container(
              width: 110, height: 110,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _MC.danaBlue,
                border: Border.all(color: _MC.comicBlack, width: 4),
                boxShadow: const [
                  BoxShadow(
                      color: _MC.comicBlack,
                      offset: Offset(5, 6),
                      blurRadius: 0),
                ],
              ),
              child: const Icon(
                  Icons.account_balance_wallet_rounded,
                  color: _MC.white, size: 54),
            ),
          ),
          const SizedBox(height: 20),

          // TITLE
          const Text('DAFTAR DANA',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: _MC.white,
                fontWeight: FontWeight.w900,
                fontSize: 22,
                letterSpacing: 3,
                fontFamily: 'Astral',
                shadows: [
                  Shadow(
                      color: _MC.comicBlack,
                      offset: Offset(2, 2),
                      blurRadius: 0),
                ],
              )),
          const SizedBox(height: 8),
          const Text(
            'Masukkan nomor HP Anda untuk membuat akun DANA.\nNomor harus sesuai dengan nomor asli seperti DANA pada umumnya.',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: _MC.textGrey,
              fontSize: 12,
              height: 1.5,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 30),

          // FORM NOMOR HP
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: _MC.redSoft,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _MC.comicBlack, width: 3.5),
              boxShadow: const [
                BoxShadow(
                    color: _MC.comicBlack,
                    offset: Offset(5, 5),
                    blurRadius: 0),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  children: [
                    Icon(Icons.phone_android_rounded,
                        color: _MC.brightRed, size: 18),
                    SizedBox(width: 8),
                    Text('NOMOR HP',
                        style: TextStyle(
                          color: _MC.white,
                          fontWeight: FontWeight.w900,
                          fontSize: 12,
                          letterSpacing: 1.5,
                          fontFamily: 'Astral',
                        )),
                  ],
                ),
                const SizedBox(height: 12),
                Container(
                  decoration: BoxDecoration(
                    color: _MC.redDeep,
                    borderRadius: BorderRadius.circular(14),
                    border:
                        Border.all(color: _MC.comicBlack, width: 3),
                    boxShadow: const [
                      BoxShadow(
                          color: _MC.comicBlack,
                          offset: Offset(4, 4),
                          blurRadius: 0),
                    ],
                  ),
                  child: TextField(
                    controller: _phoneCtrl,
                    keyboardType: TextInputType.phone,
                    inputFormatters: [
                      FilteringTextInputFormatter.digitsOnly,
                      LengthLimitingTextInputFormatter(13),
                    ],
                    style: const TextStyle(
                      color: _MC.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2,
                    ),
                    cursorColor: _MC.brightRed,
                    decoration: const InputDecoration(
                      hintText: '08xxxxxxxxxx',
                      hintStyle: TextStyle(
                          color: _MC.textLight,
                          fontSize: 15,
                          letterSpacing: 1.5),
                      prefixIcon: Padding(
                        padding: EdgeInsets.only(left: 14, right: 8),
                        child: Center(
                          widthFactor: 1,
                          child: Text('+62',
                              style: TextStyle(
                                color: _MC.white,
                                fontSize: 15,
                                fontWeight: FontWeight.w900,
                              )),
                        ),
                      ),
                      prefixIconConstraints:
                          BoxConstraints(minWidth: 50, minHeight: 50),
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.symmetric(
                          vertical: 18, horizontal: 8),
                    ),
                  ),
                ),
                if (_errorMsg != null) ...[
                  const SizedBox(height: 10),
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: _MC.red.withOpacity(0.3),
                      borderRadius: BorderRadius.circular(10),
                      border:
                          Border.all(color: _MC.comicBlack, width: 2),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.error_outline_rounded,
                            color: _MC.brightRed, size: 16),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(_errorMsg!,
                              style: const TextStyle(
                                color: _MC.brightRed,
                                fontSize: 11.5,
                                fontWeight: FontWeight.w800,
                              )),
                        ),
                      ],
                    ),
                  ),
                ],
                const SizedBox(height: 16),
                GestureDetector(
                  onTap: _registerPhone,
                  child: Container(
                    height: 56,
                    decoration: BoxDecoration(
                      color: _MC.danaBlue,
                      borderRadius: BorderRadius.circular(14),
                      border:
                          Border.all(color: _MC.comicBlack, width: 3.5),
                      boxShadow: const [
                        BoxShadow(
                            color: _MC.comicBlack,
                            offset: Offset(5, 5),
                            blurRadius: 0),
                      ],
                    ),
                    child: const Center(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.verified_rounded,
                              color: _MC.white, size: 20),
                          SizedBox(width: 10),
                          Text('BUAT AKUN DANA',
                              style: TextStyle(
                                color: _MC.white,
                                fontWeight: FontWeight.w900,
                                fontSize: 14,
                                letterSpacing: 1.5,
                                fontFamily: 'Astral',
                              )),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),

          // INFO CARD
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: _MC.buttonDark,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _MC.comicBlack, width: 2.5),
            ),
            child: const Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.info_outline_rounded,
                    color: _MC.amber, size: 16),
                SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Nomor HP akan disimpan sebagai identitas akun DANA Anda. Tidak dapat diubah setelah registrasi.',
                    style: TextStyle(
                      color: _MC.textGrey,
                      fontSize: 11,
                      height: 1.4,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // 💰 WALLET VIEW (Setelah Register)
  // ═══════════════════════════════════════════════════════════
  Widget _buildWalletView() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // TOP BAR
          Row(
            children: [
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: 42, height: 42,
                  decoration: BoxDecoration(
                    color: _MC.buttonDark,
                    borderRadius: BorderRadius.circular(12),
                    border:
                        Border.all(color: _MC.comicBlack, width: 3),
                    boxShadow: const [
                      BoxShadow(
                          color: _MC.comicBlack,
                          offset: Offset(3, 3),
                          blurRadius: 0),
                    ],
                  ),
                  child: const Icon(
                      Icons.arrow_back_ios_new_rounded,
                      color: _MC.white, size: 16),
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  color: _MC.danaBlue,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _MC.comicBlack, width: 3),
                  boxShadow: const [
                    BoxShadow(
                        color: _MC.comicBlack,
                        offset: Offset(4, 5),
                        blurRadius: 0),
                  ],
                ),
                child: const Text('DANA',
                    style: TextStyle(
                      color: _MC.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 3,
                      fontFamily: 'Astral',
                    )),
              ),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: _logoutDana,
                child: Container(
                  width: 42, height: 42,
                  decoration: BoxDecoration(
                    color: _MC.brightRed,
                    borderRadius: BorderRadius.circular(12),
                    border:
                        Border.all(color: _MC.comicBlack, width: 3),
                    boxShadow: const [
                      BoxShadow(
                          color: _MC.comicBlack,
                          offset: Offset(3, 3),
                          blurRadius: 0),
                    ],
                  ),
                  child: const Icon(Icons.logout_rounded,
                      color: _MC.white, size: 18),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // ═══ SALDO CARD BESAR (DANA STYLE) ═══
          _buildBalanceCard(),
          const SizedBox(height: 16),

          // ═══ QUICK ACTIONS ═══
          Row(
            children: [
              Expanded(
                child: _buildActionBtn(
                  icon: Icons.add_rounded,
                  label: 'TOP UP',
                  color: _MC.green,
                  onTap: _showTopupDialog,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _buildActionBtn(
                  icon: Icons.send_rounded,
                  label: 'KIRIM',
                  color: _MC.danaBlue,
                  onTap: () => _showInfoDialog(
                    'Kirim Saldo',
                    'Fitur kirim saldo akan segera hadir.\nSaldo Anda aman tersimpan.',
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _buildActionBtn(
                  icon: Icons.qr_code_rounded,
                  label: 'BAYAR',
                  color: _MC.amber,
                  onTap: () => _showInfoDialog(
                    'Bayar QRIS',
                    'Fitur pembayaran QRIS akan segera hadir.',
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // ═══ INFO AKUN ═══
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: _MC.redSoft,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: _MC.comicBlack, width: 3.5),
              boxShadow: const [
                BoxShadow(
                    color: _MC.comicBlack,
                    offset: Offset(5, 5),
                    blurRadius: 0),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  children: [
                    Icon(Icons.person_rounded,
                        color: _MC.brightRed, size: 18),
                    SizedBox(width: 8),
                    Text('INFO AKUN DANA',
                        style: TextStyle(
                          color: _MC.white,
                          fontWeight: FontWeight.w900,
                          fontSize: 12,
                          letterSpacing: 1.5,
                          fontFamily: 'Astral',
                        )),
                  ],
                ),
                const SizedBox(height: 12),
                _buildInfoRow('Username', widget.username),
                _buildInfoRow('Nomor HP', _maskPhone(_phoneNumber ?? '-')),
                _buildInfoRow('Status', '✅ Terverifikasi'),
                _buildInfoRow(
                    'Saldo',
                    'Rp ${_formatRupiah(_balance)}'),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // ═══ RIWAYAT ═══
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: _MC.redSoft,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: _MC.comicBlack, width: 3.5),
              boxShadow: const [
                BoxShadow(
                    color: _MC.comicBlack,
                    offset: Offset(5, 5),
                    blurRadius: 0),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  children: [
                    Icon(Icons.history_rounded,
                        color: _MC.amber, size: 18),
                    SizedBox(width: 8),
                    Text('RIWAYAT TRANSAKSI',
                        style: TextStyle(
                          color: _MC.white,
                          fontWeight: FontWeight.w900,
                          fontSize: 12,
                          letterSpacing: 1.5,
                          fontFamily: 'Astral',
                        )),
                  ],
                ),
                const SizedBox(height: 12),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: _MC.redDeep,
                    borderRadius: BorderRadius.circular(12),
                    border:
                        Border.all(color: _MC.comicBlack, width: 2),
                  ),
                  child: Column(
                    children: [
                      const Icon(Icons.receipt_long_rounded,
                          color: _MC.textLight, size: 32),
                      const SizedBox(height: 8),
                      const Text('Belum ada transaksi',
                          style: TextStyle(
                            color: _MC.textGrey,
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                          )),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // 💳 BALANCE CARD (DANA STYLE)
  // ═══════════════════════════════════════════════════════════
  Widget _buildBalanceCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [_MC.danaBlue, _MC.danaBlueDark],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: _MC.comicBlack, width: 4),
        boxShadow: const [
          BoxShadow(
              color: _MC.comicBlack,
              offset: Offset(6, 7),
              blurRadius: 0),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text('Saldo DANA',
                  style: TextStyle(
                    color: _MC.white,
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1,
                  )),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: _MC.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(8),
                  border:
                      Border.all(color: _MC.comicBlack, width: 2),
                ),
                child: const Text('AKTIF',
                    style: TextStyle(
                      color: _MC.white,
                      fontSize: 8.5,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1,
                    )),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Padding(
                padding: EdgeInsets.only(top: 6),
                child: Text('Rp',
                    style: TextStyle(
                      color: _MC.white,
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                    )),
              ),
              const SizedBox(width: 8),
              Flexible(
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  alignment: Alignment.centerLeft,
                  child: Text(
                    _formatRupiah(_balance),
                    style: const TextStyle(
                      color: _MC.white,
                      fontSize: 40,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Astral',
                      height: 1,
                      shadows: [
                        Shadow(
                          color: _MC.comicBlack,
                          offset: Offset(2, 2),
                          blurRadius: 0,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              const Icon(Icons.phone_android_rounded,
                  color: _MC.white, size: 14),
              const SizedBox(width: 6),
              Text(_maskPhone(_phoneNumber ?? '-'),
                  style: const TextStyle(
                    color: _MC.white,
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1,
                  )),
              const Spacer(),
              const Icon(Icons.verified_rounded,
                  color: _MC.white, size: 14),
              const SizedBox(width: 4),
              const Text('TERVERIFIKASI',
                  style: TextStyle(
                    color: _MC.white,
                    fontSize: 8.5,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1,
                  )),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildActionBtn({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 80,
        decoration: BoxDecoration(
          color: _MC.redSoft,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _MC.comicBlack, width: 3.5),
          boxShadow: const [
            BoxShadow(
                color: _MC.comicBlack,
                offset: Offset(4, 4),
                blurRadius: 0),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 38, height: 38,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: color,
                border:
                    Border.all(color: _MC.comicBlack, width: 2.5),
              ),
              child:
                  Icon(icon, color: _MC.white, size: 20),
            ),
            const SizedBox(height: 6),
            Text(label,
                style: const TextStyle(
                  color: _MC.white,
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1,
                  fontFamily: 'Astral',
                )),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          Expanded(
            flex: 4,
            child: Text(label,
                style: const TextStyle(
                  color: _MC.textGrey,
                  fontSize: 11.5,
                  fontWeight: FontWeight.w600,
                )),
          ),
          Expanded(
            flex: 6,
            child: Text(value,
                textAlign: TextAlign.right,
                style: const TextStyle(
                  color: _MC.white,
                  fontSize: 12,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Astral',
                )),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // 💵 TOPUP DIALOG
  // ═══════════════════════════════════════════════════════════
  void _showTopupDialog() {
    _topupCtrl.clear();
    showDialog(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: _MC.redSoft,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _MC.comicBlack, width: 3.5),
            boxShadow: const [
              BoxShadow(
                  color: _MC.comicBlack,
                  offset: Offset(6, 8),
                  blurRadius: 0),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Row(
                children: [
                  Icon(Icons.add_card_rounded,
                      color: _MC.green, size: 22),
                  SizedBox(width: 10),
                  Text('TOP UP SALDO',
                      style: TextStyle(
                        color: _MC.white,
                        fontWeight: FontWeight.w900,
                        fontSize: 14,
                        letterSpacing: 1.5,
                        fontFamily: 'Astral',
                      )),
                ],
              ),
              const SizedBox(height: 16),
              const Text('Nominal Top Up',
                  style: TextStyle(
                    color: _MC.textGrey,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                  )),
              const SizedBox(height: 8),
              Container(
                decoration: BoxDecoration(
                  color: _MC.redDeep,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _MC.comicBlack, width: 3),
                ),
                child: TextField(
                  controller: _topupCtrl,
                  keyboardType: TextInputType.number,
                  inputFormatters: [
                    FilteringTextInputFormatter.digitsOnly,
                    LengthLimitingTextInputFormatter(9),
                  ],
                  style: const TextStyle(
                    color: _MC.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2,
                  ),
                  cursorColor: _MC.brightRed,
                  decoration: const InputDecoration(
                    hintText: 'Min 10000',
                    hintStyle: TextStyle(
                        color: _MC.textLight, fontSize: 14),
                    prefixIcon: Padding(
                      padding: EdgeInsets.only(left: 14, right: 4),
                      child: Center(
                        widthFactor: 1,
                        child: Text('Rp',
                            style: TextStyle(
                              color: _MC.green,
                              fontSize: 16,
                              fontWeight: FontWeight.w900,
                            )),
                      ),
                    ),
                    prefixIconConstraints:
                        BoxConstraints(minWidth: 50, minHeight: 50),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(
                        vertical: 16, horizontal: 8),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              // Quick Amount
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [10000, 25000, 50000, 100000, 250000]
                    .map((amount) => GestureDetector(
                          onTap: () {
                            _topupCtrl.text = amount.toString();
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 8),
                            decoration: BoxDecoration(
                              color: _MC.buttonDark,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  color: _MC.comicBlack, width: 2),
                            ),
                            child: Text(
                                'Rp ${_formatRupiah(amount)}',
                                style: const TextStyle(
                                  color: _MC.greenLite,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w900,
                                )),
                          ),
                        ))
                    .toList(),
              ),
              const SizedBox(height: 18),
              Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () => Navigator.pop(ctx),
                      child: Container(
                        height: 48,
                        decoration: BoxDecoration(
                          color: _MC.buttonDark,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                              color: _MC.comicBlack, width: 2.5),
                        ),
                        child: const Center(
                          child: Text('BATAL',
                              style: TextStyle(
                                color: _MC.white,
                                fontSize: 12,
                                fontWeight: FontWeight.w900,
                              )),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: GestureDetector(
                      onTap: _topup,
                      child: Container(
                        height: 48,
                        decoration: BoxDecoration(
                          color: _MC.green,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                              color: _MC.comicBlack, width: 2.5),
                          boxShadow: const [
                            BoxShadow(
                                color: _MC.comicBlack,
                                offset: Offset(3, 3),
                                blurRadius: 0),
                          ],
                        ),
                        child: const Center(
                          child: Text('TOP UP',
                              style: TextStyle(
                                color: _MC.comicBlack,
                                fontSize: 12,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Astral',
                              )),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showInfoDialog(String title, String message) {
    showDialog(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: _MC.redSoft,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _MC.comicBlack, width: 3.5),
            boxShadow: const [
              BoxShadow(
                  color: _MC.comicBlack,
                  offset: Offset(6, 8),
                  blurRadius: 0),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 60, height: 60,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _MC.danaBlue,
                  border: Border.all(color: _MC.comicBlack, width: 3),
                ),
                child: const Icon(Icons.info_rounded,
                    color: _MC.white, size: 30),
              ),
              const SizedBox(height: 14),
              Text(title,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: _MC.white,
                    fontWeight: FontWeight.w900,
                    fontSize: 16,
                    fontFamily: 'Astral',
                  )),
              const SizedBox(height: 8),
              Text(message,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      color: _MC.textGrey,
                      fontSize: 12,
                      height: 1.5)),
              const SizedBox(height: 20),
              GestureDetector(
                onTap: () => Navigator.pop(ctx),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 32, vertical: 12),
                  decoration: BoxDecoration(
                    color: _MC.brightRed,
                    borderRadius: BorderRadius.circular(12),
                    border:
                        Border.all(color: _MC.comicBlack, width: 3),
                    boxShadow: const [
                      BoxShadow(
                          color: _MC.comicBlack,
                          offset: Offset(3, 3),
                          blurRadius: 0),
                    ],
                  ),
                  child: const Text('OK',
                      style: TextStyle(
                        color: _MC.white,
                        fontWeight: FontWeight.w900,
                        fontSize: 13,
                        letterSpacing: 1.5,
                      )),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ═════════════════════════════════════════════════════════════
// 🎨 GRID PAINTER
// ═════════════════════════════════════════════════════════════
class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(
      Offset.zero & size,
      Paint()..color = _MC.cream,
    );
    final grid = Paint()
      ..color = _MC.red.withOpacity(0.08)
      ..strokeWidth = 1;
    const step = 34.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}