import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';

class BugSystem {
  final String id;
  final String name;
  final String description;
  final String icon;
  final int count;
  final int delay;

  BugSystem({
    required this.id,
    required this.name,
    required this.description,
    required this.icon,
    this.count = 0,
    this.delay = 0,
  });
}

class GroupInfo {
  final String id;
  final String name;
  final String description;
  final int memberCount;
  final bool joined;
  final String status; // 'active', 'suspended', 'error'
  final String? photoUrl;
  final DateTime? createdAt;

  GroupInfo({
    required this.id,
    required this.name,
    required this.description,
    required this.memberCount,
    required this.joined,
    required this.status,
    this.photoUrl,
    this.createdAt,
  });

  factory GroupInfo.fromJson(Map<String, dynamic> json) {
    return GroupInfo(
      id: json['id'] ?? '',
      name: json['name'] ?? 'Unknown Group',
      description: json['description'] ?? '',
      memberCount: json['memberCount'] ?? 0,
      joined: json['joined'] ?? false,
      status: json['status'] ?? 'active',
      photoUrl: json['photoUrl'],
      createdAt: json['createdAt'] != null
          ? DateTime.tryParse(json['createdAt'])
          : null,
    );
  }
}

class BugGroupPage extends StatefulWidget {
  final String sessionKey;
  final String role;

  const BugGroupPage({
    super.key,
    required this.sessionKey,
    required this.role,
  });

  @override
  State<BugGroupPage> createState() => _BugGroupPageState();
}

class _BugGroupPageState extends State<BugGroupPage>
    with TickerProviderStateMixin {
  // ─── Controllers ──────────────────────────────────────────────────
  final TextEditingController _groupInputController = TextEditingController();
  final TextEditingController _searchController = TextEditingController();

  // ─── Video Background ────────────────────────────────────────────
  late VideoPlayerController _videoController;
  ChewieController? _chewieController;
  bool _isVideoReady = false;

  // ─── Animations ──────────────────────────────────────────────────
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  // ─── State ──────────────────────────────────────────────────────
  bool _isLoading = false;
  bool _isCheckingGroup = false;
  bool _isSending = false;
  bool _hasSender = false;
  List<BugSystem> _bugSystems = [];
  BugSystem? _selectedBug;
  GroupInfo? _groupInfo;
  GroupInfo? _selectedGroup;
  String _groupError = '';
  double _sendProgress = 0.0;
  bool _showProgressOverlay = false;

  // ─── Colors ──────────────────────────────────────────────────────
  static const Color _bgDark = Color(0xFF0A0A10);
  static const Color _glassBg = Color(0x1AFFFFFF);
  static const Color _glassBorder = Color(0x33FFFFFF);
  static const Color _accentRed = Color(0xFFCC1A2B);
  static const Color _accentRedLight = Color(0xFFFF3B4A);
  static const Color _textPrimary = Color(0xFFF0F0F0);
  static const Color _textSecondary = Color(0xFFA0A0B0);
  static const Color _errorRed = Color(0xFFFF4444);

  @override
  void initState() {
    super.initState();
    _initVideo();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
    _pulseAnimation = Tween<double>(begin: 0.96, end: 1.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
    _checkSender();
    _fetchBugSystems();
  }

  void _initVideo() {
    _videoController = VideoPlayerController.asset('assets/videos/background.mp4');
    _videoController.initialize().then((_) {
      if (mounted) {
        setState(() {
          _videoController.setLooping(true);
          _videoController.setVolume(0.0);
          _chewieController = ChewieController(
            videoPlayerController: _videoController,
            autoPlay: true,
            looping: true,
            showControls: false,
            showControlsOnInitialize: false,
          );
          _isVideoReady = true;
        });
        _videoController.play();
      }
    }).catchError((_) {
      // fallback jika video gagal
      setState(() => _isVideoReady = false);
    });
  }

  @override
  void dispose() {
    _videoController.dispose();
    _chewieController?.dispose();
    _pulseController.dispose();
    _groupInputController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  // ─── API Calls ──────────────────────────────────────────────────
  Future<void> _checkSender() async {
    try {
      final res = await http.get(
        Uri.parse("http://shinoa-cpanelpanel.xtxintax.my.id:2003/mySender?key=${widget.sessionKey}"),
      );
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        setState(() {
          _hasSender = data["valid"] == true &&
              data["connections"] != null &&
              (data["connections"] as List).isNotEmpty;
        });
      }
    } catch (_) {}
  }

  Future<void> _fetchBugSystems() async {
    try {
      final res = await http.get(
        Uri.parse("http://shinoa-cpanelpanel.xtxintax.my.id:2003/bugGroupSystems"),
      );
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data["valid"] == true) {
          final bugSystems = data["bugSystems"] as List?;
          final newBugs = bugSystems?.map((b) => BugSystem(
            id: b["id"] ?? "",
            name: b["name"] ?? "",
            description: b["description"] ?? "",
            icon: b["icon"] ?? "🐛",
            count: b["count"] ?? 0,
            delay: b["delay"] ?? 0,
          )).toList() ?? [];
          setState(() {
            _bugSystems = newBugs;
            if (newBugs.isNotEmpty && _selectedBug == null) {
              _selectedBug = newBugs.first;
            }
          });
        }
      }
    } catch (_) {}
  }

  Future<void> _checkGroup() async {
    final input = _groupInputController.text.trim();
    if (input.isEmpty) {
      _showToast("Masukkan link atau ID grup", isError: true);
      return;
    }

    setState(() {
      _isCheckingGroup = true;
      _groupInfo = null;
      _groupError = '';
    });

    try {
      final res = await http.post(
        Uri.parse("http://shinoa-cpanelpanel.xtxintax.my.id:2003/groupInfo"),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'groupInput': input,
        }),
      );

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data["valid"] == true && data["success"] == true) {
          setState(() {
            _groupInfo = GroupInfo(
              id: data["id"] ?? '',
              name: data["name"] ?? 'Unknown Group',
              description: data["description"] ?? '',
              memberCount: data["memberCount"] ?? 0,
              joined: data["joined"] ?? false,
              status: data["status"] ?? 'active',
              photoUrl: data["photoUrl"],
              createdAt: data["createdAt"] != null
                  ? DateTime.tryParse(data["createdAt"])
                  : null,
            );
            _selectedGroup = _groupInfo;
            _groupError = '';
          });
        } else {
          setState(() {
            _groupError = data["message"] ?? "Gagal mendapatkan info grup";
            _groupInfo = null;
          });
        }
      } else {
        setState(() {
          _groupError = "Server error ${res.statusCode}";
          _groupInfo = null;
        });
      }
    } catch (e) {
      setState(() {
        _groupError = "Koneksi error: $e";
        _groupInfo = null;
      });
    } finally {
      setState(() => _isCheckingGroup = false);
    }
  }

  Future<void> _sendBugToGroup() async {
    if (_selectedGroup == null) {
      _showToast("Pilih grup terlebih dahulu", isError: true);
      return;
    }
    if (_selectedBug == null) {
      _showToast("Pilih payload", isError: true);
      return;
    }
    if (!_hasSender) {
      _showToast("Tidak ada sender aktif", isError: true);
      return;
    }

    // Tampilkan overlay progress
    setState(() {
      _showProgressOverlay = true;
      _sendProgress = 0.0;
      _isSending = true;
    });

    // Simulasi progress 0-100%
    Timer.periodic(Duration(milliseconds: 200), (timer) {
      if (!mounted) { timer.cancel(); return; }
      setState(() {
        _sendProgress += 0.02;
        if (_sendProgress >= 0.95) {
          _sendProgress = 0.95;
          timer.cancel();
        }
      });
    });

    try {
      final groupId = _selectedGroup!.id.split('@')[0];
      final res = await http.get(
        Uri.parse(
          "http://shinoa-cpanelpanel.xtxintax.my.id:2003/sendBug?"
          "key=${widget.sessionKey}"
          "&group=$groupId"
          "&bugType=${_selectedBug!.id}"
        ),
      );

      // Set progress 100%
      setState(() => _sendProgress = 1.0);

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data["cooldown"] == true) {
          _showToast("Cooldown ${data['wait']}s", isError: true);
        } else if (data["sended"] == true) {
          _showToast("✅ ${_selectedBug!.name} terkirim!", isError: false);
        } else {
          _showToast("Gagal kirim", isError: true);
        }
      } else {
        _showToast("Server error ${res.statusCode}", isError: true);
      }
    } catch (e) {
      setState(() => _sendProgress = 1.0);
      _showToast("Error: $e", isError: true);
    } finally {
      // Tutup overlay setelah 1 detik
      await Future.delayed(Duration(seconds: 1));
      if (mounted) {
        setState(() {
          _showProgressOverlay = false;
          _isSending = false;
          _sendProgress = 0.0;
        });
      }
    }
  }

  // ─── UI Helpers ──────────────────────────────────────────────────
  void _showToast(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              isError ? Icons.error_outline : Icons.check_circle_outline,
              color: Colors.white,
              size: 20,
            ),
            SizedBox(width: 12),
            Expanded(child: Text(msg, style: TextStyle(color: Colors.white))),
          ],
        ),
        backgroundColor: isError ? _errorRed : _accentRed,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        duration: Duration(seconds: 3),
        margin: EdgeInsets.all(20),
      ),
    );
  }

  // ─── Widget Builders ──────────────────────────────────────────────
  Widget _buildGlassContainer({required Widget child, EdgeInsets? padding}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
        child: Container(
          padding: padding ?? EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: _glassBg,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _glassBorder, width: 1),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.3),
                blurRadius: 30,
                spreadRadius: 5,
                offset: Offset(0, 10),
              ),
            ],
          ),
          child: child,
        ),
      ),
    );
  }

  Widget _buildGroupInfoCard() {
    if (_isCheckingGroup) {
      return _buildGlassContainer(
        child: Center(
          child: Column(
            children: [
              SizedBox(
                width: 30,
                height: 30,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: _accentRed,
                ),
              ),
              SizedBox(height: 12),
              Text(
                'Mengecek grup...',
                style: TextStyle(color: _textSecondary, fontSize: 14),
              ),
            ],
          ),
        ),
      );
    }

    if (_groupError.isNotEmpty) {
      return _buildGlassContainer(
        child: Column(
          children: [
            Icon(Icons.error_outline, color: _errorRed, size: 50),
            SizedBox(height: 12),
            Text(
              '❌ GAGAL DETEKSI',
              style: TextStyle(
                color: _errorRed,
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 8),
            Text(
              _groupError,
              textAlign: TextAlign.center,
              style: TextStyle(color: _textSecondary, fontSize: 14),
            ),
          ],
        ),
      );
    }

    if (_groupInfo == null) return SizedBox.shrink();

    final group = _groupInfo!;
    return _buildGlassContainer(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [_accentRed, _accentRedLight],
                  ),
                  image: group.photoUrl != null
                      ? DecorationImage(
                          image: NetworkImage(group.photoUrl!),
                          fit: BoxFit.cover,
                        )
                      : null,
                ),
                child: group.photoUrl == null
                    ? Icon(Icons.group_rounded, color: Colors.white, size: 30)
                    : null,
              ),
              SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      group.name,
                      style: TextStyle(
                        color: _textPrimary,
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    SizedBox(height: 4),
                    Row(
                      children: [
                        Icon(Icons.people_alt, color: _textSecondary, size: 14),
                        SizedBox(width: 4),
                        Text(
                          '${group.memberCount} members',
                          style: TextStyle(color: _textSecondary, fontSize: 12),
                        ),
                        SizedBox(width: 12),
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            color: group.joined
                                ? Colors.green.withOpacity(0.2)
                                : Colors.grey.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: group.joined
                                  ? Colors.green.withOpacity(0.3)
                                  : Colors.grey.withOpacity(0.3),
                            ),
                          ),
                          child: Text(
                            group.joined ? 'JOINED' : 'NOT JOINED',
                            style: TextStyle(
                              color: group.joined ? Colors.green : Colors.grey,
                              fontSize: 10,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: 12),
          if (group.description.isNotEmpty)
            Text(
              group.description,
              style: TextStyle(color: _textSecondary, fontSize: 13),
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
            ),
          SizedBox(height: 8),
          Row(
            children: [
              Icon(Icons.info_outline, color: _textSecondary, size: 14),
              SizedBox(width: 6),
              Text(
                'Status: ${group.status.toUpperCase()}',
                style: TextStyle(
                  color: group.status == 'active' ? Colors.green : _errorRed,
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                ),
              ),
              Spacer(),
              if (group.createdAt != null)
                Text(
                  'Dibuat: ${_formatDate(group.createdAt!)}',
                  style: TextStyle(color: _textSecondary, fontSize: 11),
                ),
            ],
          ),
        ],
      ),
    );
  }

  String _formatDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year}';
  }

  // ─── Build ────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bgDark,
      body: Stack(
        children: [
          // ─── Video Background ──────────────────────────────────────
          Positioned.fill(
            child: _isVideoReady && _chewieController != null
                ? Chewie(controller: _chewieController!)
                : Container(color: _bgDark),
          ),
          // Overlay
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withOpacity(0.6),
                    Colors.black.withOpacity(0.85),
                  ],
                ),
              ),
            ),
          ),

          // ─── Main Content ──────────────────────────────────────────
          SafeArea(
            child: Column(
              children: [
                _buildAppBar(),
                Expanded(
                  child: SingleChildScrollView(
                    physics: BouncingScrollPhysics(),
                    padding: EdgeInsets.all(16),
                    child: Column(
                      children: [
                        // ─── Input Group ─────────────────────────────
                        _buildGlassContainer(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Icon(Icons.link_rounded,
                                      color: _accentRed, size: 22),
                                  SizedBox(width: 8),
                                  Text(
                                    'Link / ID Grup',
                                    style: TextStyle(
                                      color: _textPrimary,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(height: 12),
                              Row(
                                children: [
                                  Expanded(
                                    child: TextField(
                                      controller: _groupInputController,
                                      style: TextStyle(
                                        color: _textPrimary,
                                        fontSize: 14,
                                      ),
                                      decoration: InputDecoration(
                                        hintText: 'Masukkan link atau ID...',
                                        hintStyle: TextStyle(
                                          color: _textSecondary,
                                          fontSize: 13,
                                        ),
                                        filled: true,
                                        fillColor: Colors.black26,
                                        border: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(12),
                                          borderSide: BorderSide.none,
                                        ),
                                        contentPadding: EdgeInsets.symmetric(
                                            horizontal: 16, vertical: 14),
                                      ),
                                    ),
                                  ),
                                  SizedBox(width: 12),
                                  GestureDetector(
                                    onTap: _isCheckingGroup ? null : _checkGroup,
                                    child: Container(
                                      height: 50,
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 20),
                                      decoration: BoxDecoration(
                                        gradient: LinearGradient(
                                          colors: [_accentRed, _accentRedLight],
                                        ),
                                        borderRadius: BorderRadius.circular(12),
                                        boxShadow: [
                                          BoxShadow(
                                            color: _accentRed.withOpacity(0.3),
                                            blurRadius: 10,
                                            offset: Offset(0, 4),
                                          ),
                                        ],
                                      ),
                                      child: Center(
                                        child: _isCheckingGroup
                                            ? SizedBox(
                                                width: 20,
                                                height: 20,
                                                child:
                                                    CircularProgressIndicator(
                                                  strokeWidth: 2,
                                                  color: Colors.white,
                                                ),
                                              )
                                            : Text(
                                                'CEK',
                                                style: TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 14,
                                                  fontWeight: FontWeight.w600,
                                                  letterSpacing: 0.5,
                                                ),
                                              ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: 16),

                        // ─── Group Info ──────────────────────────────
                        _buildGroupInfoCard(),
                        SizedBox(height: 16),

                        // ─── Payload Selection ──────────────────────
                        if (_groupInfo != null && _groupError.isEmpty) ...[
                          _buildGlassContainer(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Icon(Icons.bug_report_rounded,
                                        color: _accentRed, size: 22),
                                    SizedBox(width: 8),
                                    Text(
                                      'Pilih Payload',
                                      style: TextStyle(
                                        color: _textPrimary,
                                        fontSize: 16,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 12),
                                Container(
                                  height: 100,
                                  child: ListView.builder(
                                    scrollDirection: Axis.horizontal,
                                    itemCount: _bugSystems.length,
                                    itemBuilder: (context, index) {
                                      final bug = _bugSystems[index];
                                      final isSelected =
                                          _selectedBug?.id == bug.id;
                                      return GestureDetector(
                                        onTap: () {
                                          setState(() {
                                            _selectedBug = bug;
                                          });
                                        },
                                        child: Container(
                                          width: 120,
                                          margin: EdgeInsets.only(right: 12),
                                          padding: EdgeInsets.all(12),
                                          decoration: BoxDecoration(
                                            gradient: isSelected
                                                ? LinearGradient(
                                                    colors: [
                                                      _accentRed,
                                                      _accentRedLight
                                                    ],
                                                  )
                                                : LinearGradient(
                                                    colors: [
                                                      Colors.white.withOpacity(0.1),
                                                      Colors.white.withOpacity(0.05)
                                                    ],
                                                  ),
                                            borderRadius:
                                                BorderRadius.circular(14),
                                            border: Border.all(
                                              color: isSelected
                                                  ? Colors.white
                                                  : Colors.white.withOpacity(0.24),
                                              width: isSelected ? 2 : 1,
                                            ),
                                            boxShadow: isSelected
                                                ? [
                                                    BoxShadow(
                                                      color: _accentRed
                                                          .withOpacity(0.3),
                                                      blurRadius: 12,
                                                      spreadRadius: 2,
                                                    ),
                                                  ]
                                                : [],
                                          ),
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              Text(
                                                bug.icon,
                                                style: TextStyle(fontSize: 28),
                                              ),
                                              SizedBox(height: 4),
                                              Text(
                                                bug.name,
                                                style: TextStyle(
                                                  color: isSelected
                                                      ? Colors.white
                                                      : _textSecondary,
                                                  fontSize: 12,
                                                  fontWeight: isSelected
                                                      ? FontWeight.w600
                                                      : FontWeight.w400,
                                                ),
                                                maxLines: 1,
                                                overflow:
                                                    TextOverflow.ellipsis,
                                              ),
                                            ],
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 16),
                        ],

                        // ─── Send Button with Chibi ────────────────
                        if (_groupInfo != null && _groupError.isEmpty) ...[
                          Stack(
                            children: [
                              // Tombol Kirim
                              GestureDetector(
                                onTap: _sendBugToGroup,
                                child: AnimatedBuilder(
                                  animation: _pulseController,
                                  builder: (_, __) => Transform.scale(
                                    scale: _pulseAnimation.value,
                                    child: Container(
                                      width: double.infinity,
                                      height: 56,
                                      decoration: BoxDecoration(
                                        gradient: LinearGradient(
                                          colors: [
                                            _accentRed,
                                            _accentRedLight
                                          ],
                                        ),
                                        borderRadius:
                                            BorderRadius.circular(16),
                                        boxShadow: [
                                          BoxShadow(
                                            color: _accentRed
                                                .withOpacity(0.4),
                                            blurRadius: 20,
                                            spreadRadius: 3,
                                            offset: Offset(0, 6),
                                          ),
                                        ],
                                      ),
                                      child: Center(
                                        child: Text(
                                          'KIRIM BUG GROUP',
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 16,
                                            fontWeight: FontWeight.w700,
                                            letterSpacing: 1.2,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              // Chibi di pojok kanan tombol
                              Positioned(
                                right: 4,
                                bottom: 4,
                                child: Image.asset(
                                  'assets/images/but.png',
                                  width: 44,
                                  height: 44,
                                  fit: BoxFit.contain,
                                  errorBuilder: (_, __, ___) =>
                                      SizedBox.shrink(),
                                ),
                              ),
                            ],
                          ),
                        ],

                        // ─── Chibi atas kanan ──────────────────────
                        // akan ditaruh di app bar
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),

          // ─── Progress Overlay ──────────────────────────────────────
          if (_showProgressOverlay)
            Positioned.fill(
              child: Container(
                color: Colors.black.withOpacity(0.7),
                child: Center(
                  child: _buildGlassContainer(
                    padding: EdgeInsets.all(30),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          'MENGIRIM PAYLOAD',
                          style: TextStyle(
                            color: _textPrimary,
                            fontSize: 20,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        SizedBox(height: 20),
                        Stack(
                          alignment: Alignment.center,
                          children: [
                            SizedBox(
                              width: 120,
                              height: 120,
                              child: CircularProgressIndicator(
                                value: _sendProgress.clamp(0.0, 1.0),
                                strokeWidth: 8,
                                valueColor: AlwaysStoppedAnimation<Color>(
                                  _accentRed,
                                ),
                                backgroundColor: Colors.white10,
                              ),
                            ),
                            Text(
                              '${(_sendProgress * 100).toInt()}%',
                              style: TextStyle(
                                color: _textPrimary,
                                fontSize: 28,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 16),
                        Text(
                          '${_selectedBug?.name ?? 'Payload'} • ${_selectedGroup?.name ?? ''}',
                          style: TextStyle(
                            color: _textSecondary,
                            fontSize: 14,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildAppBar() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.3),
        border: Border(
          bottom: BorderSide(color: _glassBorder, width: 1),
        ),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Icon(Icons.arrow_back_ios_new_rounded,
                color: _textPrimary, size: 20),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Text(
              'BUG GROUP',
              style: TextStyle(
                color: _textPrimary,
                fontSize: 18,
                fontWeight: FontWeight.w600,
                letterSpacing: 1,
              ),
            ),
          ),
          // ─── Chibi di pojok kanan atas ──────────────────────────
          Image.asset(
            'assets/images/group.png',
            width: 40,
            height: 40,
            fit: BoxFit.contain,
            errorBuilder: (_, __, ___) => SizedBox.shrink(),
          ),
        ],
      ),
    );
  }
}