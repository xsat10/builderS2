// ════════════════════════════════════════════════════════════════════════
// USER MANAGEMENT APPS
// ════════════════════════════════════════════════════════════════════════
// Dibangun mengikuti arsitektur project yang SUDAH ADA (dashboard_page.dart):
//   • Navigasi: bottomNavigationBar + switch(_navIndex) — bukan IndexedStack.
//   • Role asli project (dari roleOptions di owner_utama_page.dart):
//       owner_utama, owner, staff, executorius, forius_utama, moderator,
//       ceo_utama, tangan_kanan, tangan_kiri, developers, partner_pribadi,
//       partner, admin, reseller, tukang_bubur, vip, member.
//   • Warna disamakan persis dengan McLarenTheme yang sudah dipakai.
//
// 🌐 BASE URL — KHUSUS HALAMAN INI
//   Atas permintaan eksplisit: seluruh base URL di halaman User Management
//   memakai server terpisah (`_userMgmtBaseUrl`), BUKAN `baseUrl` dari
//   api_config.dart yang dipakai halaman lain. Kalau ternyata server ini
//   sebenarnya sama dengan server utama, cukup ganti nilai konstanta di
//   bawah — semua endpoint di halaman ini otomatis ikut berubah.
//
// ✅ STATUS BACKEND: TERSAMBUNG KE ENDPOINT ASLI (path dikonfirmasi dari
//   owner_utama_page.dart, base URL diarahkan ke server baru di bawah):
//     GET  $_userMgmtBaseUrl/listUsers?key=<sessionKey>
//          → { valid: bool, authorized: bool, users: [...], message }
//     GET  $_userMgmtBaseUrl/deleteUser?key=<sessionKey>&username=<username>
//          → { deleted: bool, message }
//   Backend TIDAK mengembalikan field 'id' terpisah — identitas user adalah
//   `username` itu sendiri. Field lain (telegram, created_by, creator_role,
//   status eksplisit) TIDAK terkonfirmasi ada di response asli, jadi tetap
//   diparsing secara opsional/fallback (kalau tidak ada, tampil "—" /
//   "Unknown Creator" — tidak pernah crash). Kalau ternyata backend memang
//   mengirim field tersebut dengan nama lain, tinggal tambahkan nama field
//   itu ke daftar kandidat di `ManagedUser.fromJson`.
//
// ⚡ REALTIME
//   Server ini tidak terkonfirmasi punya WebSocket/stream (tidak ada bukti
//   di file yang pernah dibagikan), jadi "realtime" diimplementasikan lewat
//   polling singkat (setiap 5 detik) + refresh otomatis saat app kembali
//   ke foreground + indikator "LIVE" berdenyut di app bar supaya terasa
//   hidup — bukan mengklaim WebSocket yang belum tentu ada.
// ════════════════════════════════════════════════════════════════════════

import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';

// Base URL khusus untuk seluruh endpoint di halaman User Management.
const String _userMgmtBaseUrl = "http://shinoa-cpanelpanel.xtxintax.my.id:2003";

// ─── THEME (nilai disamakan persis dengan McLarenTheme di dashboard_page.dart) ──
class _UMTheme {
  static const Color bg = Color(0xFF0A0A0F);
  static const Color card = Color(0xFF14141A);
  static const Color cardAlt = Color(0xFF1A1A22);
  static const Color border = Color(0xFF2A2A35);
  static const Color primary = Color(0xFFE80000);
  static const Color primaryDark = Color(0xFFB00000);
  static const Color accent = Color(0xFFFF6B00);
  static const Color gold = Color(0xFFFFD700);
  static const Color white = Color(0xFFFFFFFF);
  static const Color white54 = Color(0x8AFFFFFF);
  static const Color grey = Color(0xFF8A8A9A);
  static const Color success = Color(0xFF00E676);
  static const Color warning = Color(0xFFFFAB00);

  static const LinearGradient primaryGradient = LinearGradient(
    colors: [Color(0xFFE80000), Color(0xFFFF6B00)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

// ─── MODEL ──────────────────────────────────────────────────────────────────
class ManagedUser {
  final String id;
  final String username;
  final String? telegramUsername;
  final String? telegramId;
  final String role;
  final String rawStatus;
  final DateTime? createdAt;
  final DateTime? expiredAt;
  final String? createdBy;
  final String? creatorRole;
  final String? avatarUrl;

  ManagedUser({
    required this.id,
    required this.username,
    this.telegramUsername,
    this.telegramId,
    required this.role,
    required this.rawStatus,
    this.createdAt,
    this.expiredAt,
    this.createdBy,
    this.creatorRole,
    this.avatarUrl,
  });

  // Parsing fleksibel dengan beberapa kemungkinan nama field, supaya TIDAK
  // crash dan TIDAK memaksa satu asumsi skema sebagai satu-satunya yang benar.
  // Sesuaikan daftar key di bawah begitu Anda tahu nama field asli dari backend.
  factory ManagedUser.fromJson(Map<String, dynamic> json) {
    String? str(List<String> keys) {
      for (final k in keys) {
        final v = json[k];
        if (v != null && v.toString().trim().isNotEmpty) return v.toString().trim();
      }
      return null;
    }

    DateTime? date(List<String> keys) {
      final raw = str(keys);
      if (raw == null) return null;
      return DateTime.tryParse(raw);
    }

    return ManagedUser(
      // Backend asli (owner_utama_page.dart) TIDAK mengembalikan field 'id'
      // terpisah — identitas user adalah username itu sendiri (dipakai juga
      // oleh /deleteUser?...&username=...), jadi id fallback ke username.
      id: str(['id', 'user_id', 'uid', 'username', 'user']) ?? '',
      username: str(['username', 'user', 'name']) ?? 'Unknown',
      telegramUsername: str(['telegram_username', 'telegram', 'tele', 'tele_username']),
      telegramId: str(['telegram_id', 'tele_id']),
      role: (str(['role']) ?? 'member').toLowerCase(),
      rawStatus: (str(['status', 'account_status']) ?? '').toLowerCase(),
      createdAt: date(['created_at', 'created_date', 'created', 'createdAt']),
      // 'expiredDate' adalah field ASLI yang dipakai backend (dikonfirmasi
      // dari owner_utama_page.dart: user['expiredDate']) — diprioritaskan
      // paling pertama, sisanya tetap sebagai fallback aman.
      expiredAt: date(['expiredDate', 'expired_at', 'expired_date', 'exp', 'exp_date']),
      createdBy: str(['created_by', 'creator', 'creator_username']),
      creatorRole: str(['creator_role', 'creatorRole']),
      avatarUrl: str(['avatar', 'photo', 'avatar_url']),
    );
  }
}

// ─── STATUS ─────────────────────────────────────────────────────────────────
enum UserAccStatus { pending, success, expired, unknown }

UserAccStatus resolveStatus(ManagedUser u) {
  final raw = u.rawStatus;
  if (raw.contains('pending')) return UserAccStatus.pending;
  if (raw.contains('expired')) return UserAccStatus.expired;
  if (raw.contains('success') || raw.contains('active')) return UserAccStatus.success;
  // Fallback: hitung dari expiredAt bila status mentah tidak tersedia.
  // Menggunakan DateTime asli (bukan string compare) supaya timezone aman.
  if (u.expiredAt != null) {
    return u.expiredAt!.isBefore(DateTime.now()) ? UserAccStatus.expired : UserAccStatus.success;
  }
  return UserAccStatus.unknown;
}

String statusLabel(UserAccStatus s) {
  switch (s) {
    case UserAccStatus.pending: return 'PENDING';
    case UserAccStatus.success: return 'ACTIVE';
    case UserAccStatus.expired: return 'EXPIRED';
    case UserAccStatus.unknown: return 'UNKNOWN';
  }
}

Color statusColor(UserAccStatus s) {
  switch (s) {
    case UserAccStatus.pending: return _UMTheme.warning;
    case UserAccStatus.success: return _UMTheme.success;
    case UserAccStatus.expired: return _UMTheme.primary;
    case UserAccStatus.unknown: return _UMTheme.grey;
  }
}

IconData statusIcon(UserAccStatus s) {
  switch (s) {
    case UserAccStatus.pending: return Icons.hourglass_top_rounded;
    case UserAccStatus.success: return Icons.check_circle_rounded;
    case UserAccStatus.expired: return Icons.timer_off_rounded;
    case UserAccStatus.unknown: return Icons.help_outline_rounded;
  }
}

// ─── ROLE METADATA (ikon & warna disamakan dgn skema warna role-page existing) ──
class RoleMeta {
  // Hierarchy PALING TINGGI → PALING RENDAH. Hanya role di list ini yang
  // boleh membuka User Management (lihat UserManagementAccess). Role lain
  // (admin, reseller, partner, partner_pribadi, developer, tangan_kiri, dst)
  // tetap bisa TAMPIL sebagai data/filter, tapi tidak diberi akses ke halaman.
  static const List<String> hierarchy = [
    'owner_utama',
    'owner',
    'staff',
    'executorius',
    'forius_utama',
    'moderator',
  ];

  static IconData icon(String role) {
    switch (role.toLowerCase()) {
      case 'owner_utama': return Icons.workspace_premium_rounded;
      case 'owner': return Icons.shield_rounded;
      case 'staff': return Icons.support_agent_rounded;
      case 'executorius': return Icons.admin_panel_settings_rounded;
      case 'forius_utama': return Icons.security_rounded;
      case 'moderator': return Icons.gavel_rounded;
      case 'ceo_utama': return Icons.business_center_rounded;
      case 'tangan_kanan': return Icons.person_pin_rounded;
      case 'tangan_kiri': return Icons.back_hand_rounded;
      case 'developers': return Icons.code_rounded;
      case 'developer': return Icons.code_rounded;
      case 'partner_pribadi': return Icons.badge_rounded;
      case 'partner': return Icons.handshake_rounded;
      case 'admin': return Icons.admin_panel_settings_rounded;
      case 'reseller': return Icons.storefront_rounded;
      case 'tukang_bubur': return Icons.ramen_dining_rounded;
      case 'vip': return Icons.star_rounded;
      case 'member': return Icons.person_rounded;
      default: return Icons.person_rounded;
    }
  }

  static Color color(String role) {
    switch (role.toLowerCase()) {
      case 'owner_utama': return _UMTheme.gold;
      case 'owner': return _UMTheme.warning;
      case 'staff': return _UMTheme.success;
      case 'executorius': return _UMTheme.primary;
      case 'forius_utama': return const Color(0xFF8E24AA);
      case 'moderator': return const Color(0xFF8B5CF6);
      case 'ceo_utama': return const Color(0xFFFFD54F);
      case 'tangan_kanan': return const Color(0xFF29B6F6);
      case 'tangan_kiri': return const Color(0xFFFF7043);
      case 'developers': return const Color(0xFF6366F1);
      case 'developer': return const Color(0xFF6366F1);
      case 'partner_pribadi': return const Color(0xFFEC407A);
      case 'partner': return const Color(0xFFEC4899);
      case 'admin': return _UMTheme.primary;
      case 'reseller': return _UMTheme.accent;
      case 'tukang_bubur': return const Color(0xFFA1887F);
      case 'vip': return const Color(0xFF9C27B0);
      case 'member': return _UMTheme.grey;
      default: return _UMTheme.grey;
    }
  }

  static String label(String role) => role.toUpperCase().replaceAll('_', ' ');
}

// ─── PERMISSION RESOLVER (satu sumber kebenaran, tidak dicek acak per widget) ──
// PENTING: ini lapisan UI-guard. Otorisasi sesungguhnya (siapa BENAR-BENAR
// boleh delete/ubah data) tetap wajib divalidasi di backend/database —
// menyembunyikan tombol di UI bukan security.
class UserManagementAccess {
  static bool canAccess(String role) => RoleMeta.hierarchy.contains(role.toLowerCase());

  /// Rank lebih kecil = lebih tinggi. Role di luar hierarchy dianggap paling
  /// rendah (tidak pernah dianggap "lebih tinggi" dari role yang dikenal).
  static int rank(String role) {
    final idx = RoleMeta.hierarchy.indexOf(role.toLowerCase());
    return idx == -1 ? RoleMeta.hierarchy.length : idx;
  }

  /// owner_utama melihat semua role. Role lain hanya melihat role dengan
  /// rank sama atau di bawah dirinya (tidak melihat yang lebih tinggi).
  static bool canView(String myRole, String targetRole) {
    final me = myRole.toLowerCase();
    if (me == 'owner_utama') return true;
    return rank(targetRole) >= rank(me);
  }

  /// Default aman: hanya boleh delete role yang secara hierarchy ada DI BAWAH
  /// dirinya sendiri. owner_utama boleh delete siapa saja yang diizinkan
  /// backend. Role di luar hierarchy (tidak punya akses halaman ini) selalu false.
  static bool canDelete(String myRole, String targetRole) {
    final me = myRole.toLowerCase();
    if (!canAccess(me)) return false;
    if (me == 'owner_utama') return true;
    return rank(targetRole) > rank(me);
  }

  static bool canCreate(String myRole) => canAccess(myRole);
}

// ─── SERVICE LAYER ────────────────────────────────────────────────────────────
class FetchUsersResult {
  final bool success;
  final List<ManagedUser> users;
  final String? error;
  FetchUsersResult({required this.success, required this.users, this.error});
}

class UserManagementService {
  final String sessionKey;
  UserManagementService(this.sessionKey);

  // Endpoint ASLI — dikonfirmasi dari owner_utama_page.dart (bukan lagi
  // placeholder). Response listUsers: {valid, authorized, users, message}.
  // Response deleteUser: {deleted, message}. Keduanya GET, bukan POST,
  // dan delete mengidentifikasi user lewat `username`, bukan `id`.
  Future<FetchUsersResult> fetchUsers() async {
    try {
      final uri = Uri.parse('$_userMgmtBaseUrl/listUsers?key=$sessionKey');
      final res = await http.get(uri).timeout(const Duration(seconds: 12));
      if (res.statusCode != 200) {
        return FetchUsersResult(
          success: false,
          users: const [],
          error: 'Server merespons kode ${res.statusCode}',
        );
      }
      final decoded = jsonDecode(res.body);
      if (decoded is! Map) {
        return FetchUsersResult(success: false, users: const [], error: 'Format respons tidak dikenali');
      }
      if (decoded['valid'] != true || decoded['authorized'] != true) {
        return FetchUsersResult(
          success: false,
          users: const [],
          error: decoded['message']?.toString() ?? 'Sesi tidak valid atau tidak diizinkan',
        );
      }
      final List rawList = decoded['users'] is List ? decoded['users'] as List : [];
      final users = rawList
          .whereType<Map>()
          .map((e) => ManagedUser.fromJson(Map<String, dynamic>.from(e)))
          .toList();
      return FetchUsersResult(success: true, users: users);
    } catch (e) {
      debugPrint('UserManagementService.fetchUsers error: $e');
      return FetchUsersResult(success: false, users: const [], error: 'Gagal terhubung ke server');
    }
  }

  /// [username] dipakai sebagai identitas hapus (bukan id) — sesuai kontrak
  /// asli GET /deleteUser?key=...&username=...
  Future<bool> deleteUser(String username) async {
    try {
      final uri = Uri.parse('$_userMgmtBaseUrl/deleteUser?key=$sessionKey&username=$username');
      final res = await http.get(uri).timeout(const Duration(seconds: 12));
      if (res.statusCode != 200) return false;
      final decoded = jsonDecode(res.body);
      if (decoded is Map) return decoded['deleted'] == true;
      return false;
    } catch (e) {
      debugPrint('UserManagementService.deleteUser error: $e');
      return false;
    }
  }
}

// ─── PRESSABLE SCALE (micro-interaction, lokal ke file ini) ─────────────────
class _PressableScale extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final double pressedScale;
  const _PressableScale({required this.child, this.onTap, this.pressedScale = 0.96});
  @override
  State<_PressableScale> createState() => _PressableScaleState();
}

class _PressableScaleState extends State<_PressableScale> {
  bool _pressed = false;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: widget.onTap,
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) => setState(() => _pressed = false),
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? widget.pressedScale : 1.0,
        duration: const Duration(milliseconds: 150),
        curve: Curves.easeOut,
        child: widget.child,
      ),
    );
  }
}

// ─── PULSE DOT (indikator status hidup, ringan & aman) ──────────────────────
class _PulseDot extends StatefulWidget {
  final Color color;
  const _PulseDot({required this.color});
  @override
  State<_PulseDot> createState() => _PulseDotState();
}

class _PulseDotState extends State<_PulseDot> with SingleTickerProviderStateMixin {
  late final AnimationController _c;
  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 1000))
      ..repeat(reverse: true);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) {
        final t = 0.4 + (_c.value * 0.6);
        return Container(
          width: 7,
          height: 7,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: widget.color.withOpacity(t),
            boxShadow: [BoxShadow(color: widget.color.withOpacity(t * 0.6), blurRadius: 6, spreadRadius: 1)],
          ),
        );
      },
    );
  }
}

// ─── LIVE INDICATOR (app bar) ────────────────────────────────────────────────
// Menunjukkan siklus sync realtime (polling 5 detik) benar-benar berjalan:
// titik hijau berdenyut selalu menyala, ikon refresh berputar sesaat setiap
// kali polling silent sedang mengambil data baru dari server.
class _LiveIndicator extends StatefulWidget {
  final bool isSyncing;
  final DateTime? lastUpdated;
  const _LiveIndicator({required this.isSyncing, required this.lastUpdated});

  @override
  State<_LiveIndicator> createState() => _LiveIndicatorState();
}

class _LiveIndicatorState extends State<_LiveIndicator> with SingleTickerProviderStateMixin {
  late final AnimationController _spinCtrl;

  @override
  void initState() {
    super.initState();
    _spinCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 700));
  }

  @override
  void didUpdateWidget(covariant _LiveIndicator oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isSyncing && !oldWidget.isSyncing) {
      _spinCtrl.repeat();
    } else if (!widget.isSyncing && oldWidget.isSyncing) {
      _spinCtrl.stop();
      _spinCtrl.value = 0;
    }
  }

  @override
  void dispose() {
    _spinCtrl.dispose();
    super.dispose();
  }

  String _agoLabel() {
    final t = widget.lastUpdated;
    if (t == null) return '';
    final diff = DateTime.now().difference(t).inSeconds;
    if (diff < 3) return 'baru saja';
    return '${diff}d lalu';
  }

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: widget.lastUpdated != null ? 'Update terakhir: ${_agoLabel()}' : 'Menyambungkan...',
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: _UMTheme.success.withOpacity(0.10),
          borderRadius: BorderRadius.circular(50),
          border: Border.all(color: _UMTheme.success.withOpacity(0.35)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            _PulseDot(color: _UMTheme.success),
            const SizedBox(width: 6),
            const Text('LIVE',
                style: TextStyle(color: _UMTheme.success, fontSize: 9.5, fontWeight: FontWeight.w800, letterSpacing: 0.5)),
            const SizedBox(width: 5),
            RotationTransition(
              turns: _spinCtrl,
              child: Icon(Icons.sync_rounded, size: 11, color: _UMTheme.success.withOpacity(widget.isSyncing ? 1 : 0.4)),
            ),
          ],
        ),
      ),
    );
  }
}


// ─── ACCESS DENIED VIEW ─────────────────────────────────────────────────────
class _AccessDeniedView extends StatelessWidget {
  const _AccessDeniedView();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _UMTheme.bg,
      appBar: AppBar(
        backgroundColor: _UMTheme.bg,
        elevation: 0,
        iconTheme: const IconThemeData(color: _UMTheme.white),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 84,
                height: 84,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _UMTheme.primary.withOpacity(0.12),
                  border: Border.all(color: _UMTheme.primary.withOpacity(0.4), width: 1.5),
                ),
                child: const Icon(Icons.lock_person_rounded, color: _UMTheme.primary, size: 38),
              ),
              const SizedBox(height: 22),
              const Text(
                'Access Restricted',
                style: TextStyle(color: _UMTheme.white, fontSize: 19, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 10),
              const Text(
                'Anda tidak memiliki permission untuk membuka\nUSER MANAGEMENT APPS.',
                textAlign: TextAlign.center,
                style: TextStyle(color: _UMTheme.grey, fontSize: 13, height: 1.6),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── MAIN PAGE ──────────────────────────────────────────────────────────────
class UserManagementPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;
  const UserManagementPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<UserManagementPage> createState() => _UserManagementPageState();
}

class _UserManagementPageState extends State<UserManagementPage> with WidgetsBindingObserver {
  late final UserManagementService _service;

  bool _loading = true;
  bool _hasError = false;
  bool _isSyncing = false; // dipakai untuk pulse "LIVE" saat polling silent berjalan
  String? _errorMsg;
  DateTime? _lastUpdated;

  List<ManagedUser> _allUsers = [];
  String _query = '';
  String _roleFilter = 'ALL';
  String _statusFilter = 'ALL';

  Timer? _debounce;
  Timer? _pollTimer;
  final TextEditingController _searchCtrl = TextEditingController();

  bool get _hasAccess => UserManagementAccess.canAccess(widget.role);

  @override
  void initState() {
    super.initState();
    if (!_hasAccess) return; // guard: jangan fetch apapun kalau tidak punya akses
    WidgetsBinding.instance.addObserver(this);
    _service = UserManagementService(widget.sessionKey);
    _loadUsers();
    // Server belum terkonfirmasi punya WebSocket/stream, jadi "realtime"
    // dicapai lewat polling singkat setiap 5 detik (silent, tanpa skeleton
    // loading berulang) + refresh otomatis saat app kembali ke foreground +
    // pull-to-refresh manual. Indikator "LIVE" di app bar menandakan siklus
    // sync ini benar-benar berjalan.
    _pollTimer = Timer.periodic(const Duration(seconds: 5), (_) => _loadUsers(silent: true));
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && _hasAccess) {
      _loadUsers(silent: true);
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _debounce?.cancel();
    _pollTimer?.cancel();
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadUsers({bool silent = false}) async {
    if (!silent) {
      setState(() => _loading = true);
    } else {
      setState(() => _isSyncing = true);
    }
    final result = await _service.fetchUsers();
    if (!mounted) return;
    setState(() {
      _loading = false;
      _isSyncing = false;
      _hasError = !result.success;
      _errorMsg = result.error;
      if (result.success) {
        _lastUpdated = DateTime.now();
        _allUsers = result.users.where((u) => UserManagementAccess.canView(widget.role, u.role)).toList();
      }
    });
  }

  void _onSearchChanged(String value) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 350), () {
      if (mounted) setState(() => _query = value.trim().toLowerCase());
    });
  }

  List<ManagedUser> get _filtered {
    return _allUsers.where((u) {
      if (_roleFilter != 'ALL' && u.role.toLowerCase() != _roleFilter.toLowerCase()) return false;
      if (_statusFilter != 'ALL') {
        final s = statusLabel(resolveStatus(u));
        if (s != _statusFilter) return false;
      }
      if (_query.isEmpty) return true;
      final haystack = [
        u.username,
        u.telegramUsername ?? '',
        u.telegramId ?? '',
        u.createdBy ?? '',
        u.role,
        statusLabel(resolveStatus(u)),
      ].join(' ').toLowerCase();
      return haystack.contains(_query);
    }).toList();
  }

  List<String> get _availableRoles {
    final set = <String>{};
    for (final u in _allUsers) {
      set.add(u.role);
    }
    final list = set.toList()..sort((a, b) => RoleMeta.hierarchy.contains(a) == RoleMeta.hierarchy.contains(b)
        ? a.compareTo(b)
        : (RoleMeta.hierarchy.contains(a) ? -1 : 1));
    return ['ALL', ...list];
  }

  Future<void> _confirmDelete(ManagedUser u) async {
    final confirmed = await showDialog<bool>(
      context: context,
      barrierColor: Colors.black87,
      builder: (ctx) => _DeleteConfirmDialog(user: u),
    );
    if (confirmed != true || !mounted) return;

    final ok = await _service.deleteUser(u.username);
    if (!mounted) return;
    if (ok) {
      setState(() => _allUsers.removeWhere((e) => e.username == u.username));
      _showSnack('User "${u.username}" berhasil dihapus', success: true);
    } else {
      _showSnack('Gagal menghapus user. Coba lagi.', success: false);
    }
  }

  void _showSnack(String msg, {required bool success}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: success ? const Color(0xFF0D2818) : const Color(0xFF2A0D0D),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        content: Row(
          children: [
            Icon(success ? Icons.check_circle_rounded : Icons.error_rounded,
                color: success ? _UMTheme.success : _UMTheme.primary, size: 20),
            const SizedBox(width: 10),
            Expanded(child: Text(msg, style: const TextStyle(color: _UMTheme.white, fontSize: 13))),
          ],
        ),
      ),
    );
  }

  void _openDetail(ManagedUser u) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => _UserDetailSheet(
        user: u,
        canDelete: UserManagementAccess.canDelete(widget.role, u.role),
        onDelete: () {
          Navigator.pop(context);
          _confirmDelete(u);
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (!_hasAccess) return const _AccessDeniedView();

    final filtered = _filtered;
    final stats = _computeStats();

    return Scaffold(
      backgroundColor: _UMTheme.bg,
      appBar: AppBar(
        backgroundColor: _UMTheme.bg,
        elevation: 0,
        iconTheme: const IconThemeData(color: _UMTheme.white),
        titleSpacing: 0,
        title: const Padding(
          padding: EdgeInsets.only(left: 4),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('USER MANAGMENT APPS',
                  style: TextStyle(color: _UMTheme.white, fontSize: 15, fontWeight: FontWeight.w800, letterSpacing: 0.5)),
              Text('Manage & monitor all users',
                  style: TextStyle(color: _UMTheme.grey, fontSize: 11, fontWeight: FontWeight.w400)),
            ],
          ),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: _LiveIndicator(isSyncing: _isSyncing, lastUpdated: _lastUpdated),
          ),
        ],
      ),
      body: RefreshIndicator(
        color: _UMTheme.primary,
        backgroundColor: _UMTheme.card,
        onRefresh: () => _loadUsers(),
        child: CustomScrollView(
          physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
          slivers: [
            SliverToBoxAdapter(child: _StatisticsHeader(stats: stats)),
            SliverToBoxAdapter(
              child: _SearchBar(controller: _searchCtrl, onChanged: _onSearchChanged),
            ),
            SliverToBoxAdapter(
              child: _RoleFilterChips(
                roles: _availableRoles,
                selected: _roleFilter,
                onSelected: (r) => setState(() => _roleFilter = r),
              ),
            ),
            SliverToBoxAdapter(
              child: _StatusFilterChips(
                selected: _statusFilter,
                onSelected: (s) => setState(() => _statusFilter = s),
              ),
            ),
            const SliverToBoxAdapter(child: SizedBox(height: 4)),
            if (_loading)
              SliverList(
                delegate: SliverChildBuilderDelegate(
                  (_, __) => const _SkeletonCard(),
                  childCount: 5,
                ),
              )
            else if (_hasError)
              SliverFillRemaining(
                hasScrollBody: false,
                child: _ErrorView(message: _errorMsg, onRetry: () => _loadUsers()),
              )
            else if (filtered.isEmpty)
              SliverFillRemaining(
                hasScrollBody: false,
                child: _EmptyView(isSearching: _query.isNotEmpty || _roleFilter != 'ALL' || _statusFilter != 'ALL'),
              )
            else
              SliverPadding(
                padding: const EdgeInsets.only(bottom: 24),
                sliver: SliverList(
                  delegate: SliverChildBuilderDelegate(
                    (ctx, i) => _UserCard(
                      user: filtered[i],
                      canDelete: UserManagementAccess.canDelete(widget.role, filtered[i].role),
                      onTap: () => _openDetail(filtered[i]),
                      onDelete: () => _confirmDelete(filtered[i]),
                    ),
                    childCount: filtered.length,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Map<String, int> _computeStats() {
    int active = 0, pending = 0, expired = 0;
    for (final u in _allUsers) {
      switch (resolveStatus(u)) {
        case UserAccStatus.success: active++; break;
        case UserAccStatus.pending: pending++; break;
        case UserAccStatus.expired: expired++; break;
        case UserAccStatus.unknown: break;
      }
    }
    return {'total': _allUsers.length, 'active': active, 'pending': pending, 'expired': expired};
  }
}

// ─── STATISTICS HEADER ───────────────────────────────────────────────────────
class _StatisticsHeader extends StatelessWidget {
  final Map<String, int> stats;
  const _StatisticsHeader({required this.stats});

  @override
  Widget build(BuildContext context) {
    final items = [
      {'label': 'TOTAL', 'value': stats['total'] ?? 0, 'color': _UMTheme.white},
      {'label': 'ACTIVE', 'value': stats['active'] ?? 0, 'color': _UMTheme.success},
      {'label': 'PENDING', 'value': stats['pending'] ?? 0, 'color': _UMTheme.warning},
      {'label': 'EXPIRED', 'value': stats['expired'] ?? 0, 'color': _UMTheme.primary},
    ];
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
      child: Row(
        children: items.map((it) {
          return Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 12),
                decoration: BoxDecoration(
                  color: _UMTheme.card,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: _UMTheme.border, width: 1),
                ),
                child: Column(
                  children: [
                    TweenAnimationBuilder<double>(
                      tween: Tween(begin: 0, end: (it['value'] as int).toDouble()),
                      duration: const Duration(milliseconds: 700),
                      curve: Curves.easeOutCubic,
                      builder: (_, v, __) => Text(
                        v.round().toString(),
                        style: TextStyle(color: it['color'] as Color, fontSize: 18, fontWeight: FontWeight.w800),
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(it['label'] as String,
                        style: const TextStyle(color: _UMTheme.grey, fontSize: 9.5, fontWeight: FontWeight.w600, letterSpacing: 0.5)),
                  ],
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}

// ─── SEARCH BAR ───────────────────────────────────────────────────────────────
class _SearchBar extends StatelessWidget {
  final TextEditingController controller;
  final ValueChanged<String> onChanged;
  const _SearchBar({required this.controller, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 6, 16, 10),
      child: Container(
        decoration: BoxDecoration(
          color: _UMTheme.card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _UMTheme.border, width: 1),
        ),
        child: TextField(
          controller: controller,
          onChanged: onChanged,
          style: const TextStyle(color: _UMTheme.white, fontSize: 13.5),
          decoration: const InputDecoration(
            hintText: 'Cari username / telegram / creator...',
            hintStyle: TextStyle(color: _UMTheme.grey, fontSize: 13),
            prefixIcon: Icon(Icons.search_rounded, color: _UMTheme.grey, size: 22),
            border: InputBorder.none,
            contentPadding: EdgeInsets.symmetric(horizontal: 4, vertical: 15),
          ),
        ),
      ),
    );
  }
}

// ─── ROLE FILTER CHIPS ────────────────────────────────────────────────────────
class _RoleFilterChips extends StatelessWidget {
  final List<String> roles;
  final String selected;
  final ValueChanged<String> onSelected;
  const _RoleFilterChips({required this.roles, required this.selected, required this.onSelected});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 44,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: roles.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (ctx, i) {
          final role = roles[i];
          final isAll = role == 'ALL';
          final isActive = selected == role;
          final color = isAll ? _UMTheme.primary : RoleMeta.color(role);
          return _PressableScale(
            onTap: () => onSelected(role),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              curve: Curves.easeOut,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                color: isActive ? color.withOpacity(0.16) : _UMTheme.card,
                borderRadius: BorderRadius.circular(50),
                border: Border.all(color: isActive ? color.withOpacity(0.6) : _UMTheme.border, width: 1.2),
              ),
              alignment: Alignment.center,
              child: Text(
                isAll ? 'ALL' : RoleMeta.label(role),
                style: TextStyle(
                  color: isActive ? color : _UMTheme.grey,
                  fontSize: 11.5,
                  fontWeight: isActive ? FontWeight.w800 : FontWeight.w600,
                  letterSpacing: 0.3,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

// ─── STATUS FILTER CHIPS ──────────────────────────────────────────────────────
class _StatusFilterChips extends StatelessWidget {
  final String selected;
  final ValueChanged<String> onSelected;
  const _StatusFilterChips({required this.selected, required this.onSelected});

  @override
  Widget build(BuildContext context) {
    final items = [
      {'label': 'ALL', 'icon': Icons.apps_rounded, 'color': _UMTheme.white},
      {'label': 'PENDING', 'icon': Icons.hourglass_top_rounded, 'color': _UMTheme.warning},
      {'label': 'ACTIVE', 'icon': Icons.check_circle_rounded, 'color': _UMTheme.success},
      {'label': 'EXPIRED', 'icon': Icons.timer_off_rounded, 'color': _UMTheme.primary},
    ];
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      child: Wrap(
        spacing: 8,
        runSpacing: 8,
        children: items.map((it) {
          final label = it['label'] as String;
          final isActive = selected == label;
          final color = it['color'] as Color;
          return _PressableScale(
            onTap: () => onSelected(label),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
              decoration: BoxDecoration(
                color: isActive ? color.withOpacity(0.14) : _UMTheme.cardAlt,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: isActive ? color.withOpacity(0.55) : _UMTheme.border),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(it['icon'] as IconData, size: 14, color: isActive ? color : _UMTheme.grey),
                  const SizedBox(width: 6),
                  Text(label,
                      style: TextStyle(
                        color: isActive ? color : _UMTheme.grey,
                        fontSize: 10.5,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.3,
                      )),
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}

// ─── USER CARD ────────────────────────────────────────────────────────────────
class _UserCard extends StatelessWidget {
  final ManagedUser user;
  final bool canDelete;
  final VoidCallback onTap;
  final VoidCallback onDelete;
  const _UserCard({required this.user, required this.canDelete, required this.onTap, required this.onDelete});

  String _remainingLabel() {
    if (user.expiredAt == null) return '';
    final diff = user.expiredAt!.difference(DateTime.now()).inDays;
    if (diff < 0) return 'EXPIRED';
    return '$diff HARI';
  }

  @override
  Widget build(BuildContext context) {
    final status = resolveStatus(user);
    final rColor = RoleMeta.color(user.role);
    final remaining = _remainingLabel();
    final dateFmt = DateFormat('dd MMM yyyy');

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      child: _PressableScale(
        pressedScale: 0.98,
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: _UMTheme.card,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _UMTheme.border, width: 1),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.25), blurRadius: 14, offset: const Offset(0, 6))],
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(colors: [rColor.withOpacity(0.35), rColor.withOpacity(0.1)]),
                  border: Border.all(color: rColor.withOpacity(0.5), width: 1.2),
                ),
                child: Center(
                  child: Text(
                    user.username.isNotEmpty ? user.username[0].toUpperCase() : '?',
                    style: TextStyle(color: rColor, fontSize: 17, fontWeight: FontWeight.w800),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: Text(user.username,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(color: _UMTheme.white, fontSize: 14.5, fontWeight: FontWeight.w700)),
                        ),
                        if (remaining.isNotEmpty) ...[
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                              color: statusColor(status).withOpacity(0.15),
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: statusColor(status).withOpacity(0.4)),
                            ),
                            child: Text(remaining,
                                style: TextStyle(color: statusColor(status), fontSize: 9.5, fontWeight: FontWeight.w800)),
                          ),
                        ],
                      ],
                    ),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                          decoration: BoxDecoration(
                            color: _UMTheme.cardAlt,
                            borderRadius: BorderRadius.circular(7),
                            border: Border.all(color: _UMTheme.border),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(RoleMeta.icon(user.role), size: 10, color: rColor),
                              const SizedBox(width: 4),
                              Text(RoleMeta.label(user.role),
                                  style: TextStyle(color: rColor, fontSize: 9, fontWeight: FontWeight.w700)),
                            ],
                          ),
                        ),
                        const SizedBox(width: 6),
                        _PulseDot(color: statusColor(status)),
                        const SizedBox(width: 4),
                        Text(statusLabel(status),
                            style: TextStyle(color: statusColor(status), fontSize: 9.5, fontWeight: FontWeight.w700)),
                        if (user.expiredAt != null) ...[
                          const SizedBox(width: 6),
                          Text('EXP ${dateFmt.format(user.expiredAt!)}',
                              style: const TextStyle(color: _UMTheme.grey, fontSize: 9.5)),
                        ],
                      ],
                    ),
                    const SizedBox(height: 7),
                    Row(
                      children: [
                        const Icon(Icons.send_rounded, size: 12, color: Color(0xFF2F7BFF)),
                        const SizedBox(width: 5),
                        Text(
                          user.telegramUsername != null ? '@${user.telegramUsername}' : 'Tele: —',
                          style: const TextStyle(color: Color(0xFF2F7BFF), fontSize: 10.5, fontWeight: FontWeight.w500),
                        ),
                      ],
                    ),
                    const SizedBox(height: 3),
                    Row(
                      children: [
                        const Icon(Icons.person_outline_rounded, size: 12, color: _UMTheme.gold),
                        const SizedBox(width: 5),
                        Expanded(
                          child: Text(
                            user.createdBy != null ? 'Created by: @${user.createdBy}' : 'Unknown Creator',
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(color: _UMTheme.gold, fontSize: 10.5, fontWeight: FontWeight.w600),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 6),
              Column(
                children: [
                  _PressableScale(
                    onTap: onTap,
                    child: Container(
                      padding: const EdgeInsets.all(7),
                      decoration: BoxDecoration(
                        color: const Color(0xFF2F7BFF).withOpacity(0.12),
                        shape: BoxShape.circle,
                        border: Border.all(color: const Color(0xFF2F7BFF).withOpacity(0.4)),
                      ),
                      child: const Icon(Icons.visibility_rounded, size: 15, color: Color(0xFF2F7BFF)),
                    ),
                  ),
                  if (canDelete) ...[
                    const SizedBox(height: 8),
                    _PressableScale(
                      onTap: onDelete,
                      child: Container(
                        padding: const EdgeInsets.all(7),
                        decoration: BoxDecoration(
                          color: _UMTheme.primary.withOpacity(0.12),
                          shape: BoxShape.circle,
                          border: Border.all(color: _UMTheme.primary.withOpacity(0.4)),
                        ),
                        child: const Icon(Icons.delete_outline_rounded, size: 15, color: _UMTheme.primary),
                      ),
                    ),
                  ],
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── SKELETON LOADING ─────────────────────────────────────────────────────────
class _SkeletonCard extends StatefulWidget {
  const _SkeletonCard();
  @override
  State<_SkeletonCard> createState() => _SkeletonCardState();
}

class _SkeletonCardState extends State<_SkeletonCard> with SingleTickerProviderStateMixin {
  late final AnimationController _c;
  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 1100))..repeat(reverse: true);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      child: AnimatedBuilder(
        animation: _c,
        builder: (_, __) {
          final op = 0.35 + (_c.value * 0.25);
          return Container(
            height: 118,
            decoration: BoxDecoration(
              color: _UMTheme.card.withOpacity(op),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _UMTheme.border.withOpacity(op)),
            ),
          );
        },
      ),
    );
  }
}

// ─── ERROR VIEW ───────────────────────────────────────────────────────────────
class _ErrorView extends StatelessWidget {
  final String? message;
  final VoidCallback onRetry;
  const _ErrorView({this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 60),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 72,
            height: 72,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _UMTheme.primary.withOpacity(0.1),
              border: Border.all(color: _UMTheme.primary.withOpacity(0.35)),
            ),
            child: const Icon(Icons.cloud_off_rounded, color: _UMTheme.primary, size: 30),
          ),
          const SizedBox(height: 18),
          const Text('Unable to load users',
              style: TextStyle(color: _UMTheme.white, fontSize: 15, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          Text(
            message ?? 'Terjadi kesalahan saat memuat data.',
            textAlign: TextAlign.center,
            style: const TextStyle(color: _UMTheme.grey, fontSize: 12, height: 1.5),
          ),
          const SizedBox(height: 20),
          _PressableScale(
            onTap: onRetry,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 12),
              decoration: BoxDecoration(gradient: _UMTheme.primaryGradient, borderRadius: BorderRadius.circular(14)),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.refresh_rounded, color: Colors.white, size: 16),
                  SizedBox(width: 8),
                  Text('Retry', style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─── EMPTY VIEW ───────────────────────────────────────────────────────────────
class _EmptyView extends StatelessWidget {
  final bool isSearching;
  const _EmptyView({required this.isSearching});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 60),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 72,
            height: 72,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _UMTheme.cardAlt,
              border: Border.all(color: _UMTheme.border),
            ),
            child: Icon(isSearching ? Icons.search_off_rounded : Icons.people_outline_rounded, color: _UMTheme.grey, size: 30),
          ),
          const SizedBox(height: 16),
          Text(
            isSearching ? 'No matching users' : 'No Users Found',
            style: const TextStyle(color: _UMTheme.white, fontSize: 14.5, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 6),
          Text(
            isSearching ? 'Coba kata kunci atau filter lain.' : 'Belum ada user yang terdaftar.',
            style: const TextStyle(color: _UMTheme.grey, fontSize: 12),
          ),
        ],
      ),
    );
  }
}

// ─── DELETE CONFIRM DIALOG ────────────────────────────────────────────────────
class _DeleteConfirmDialog extends StatelessWidget {
  final ManagedUser user;
  const _DeleteConfirmDialog({required this.user});

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: _UMTheme.card,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 56,
              height: 56,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _UMTheme.primary.withOpacity(0.12),
                border: Border.all(color: _UMTheme.primary.withOpacity(0.4)),
              ),
              child: const Icon(Icons.delete_forever_rounded, color: _UMTheme.primary, size: 26),
            ),
            const SizedBox(height: 16),
            const Text('Delete User?', style: TextStyle(color: _UMTheme.white, fontSize: 16, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Text(
              'Apakah Anda yakin ingin menghapus account ini?',
              textAlign: TextAlign.center,
              style: const TextStyle(color: _UMTheme.grey, fontSize: 12.5, height: 1.5),
            ),
            const SizedBox(height: 14),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
              decoration: BoxDecoration(color: _UMTheme.cardAlt, borderRadius: BorderRadius.circular(12)),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('@${user.username}', style: const TextStyle(color: _UMTheme.white, fontSize: 13, fontWeight: FontWeight.w700)),
                  const SizedBox(width: 8),
                  Text('· ${RoleMeta.label(user.role)}',
                      style: TextStyle(color: RoleMeta.color(user.role), fontSize: 11, fontWeight: FontWeight.w700)),
                ],
              ),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: _PressableScale(
                    onTap: () => Navigator.pop(context, false),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 13),
                      decoration: BoxDecoration(
                        color: _UMTheme.cardAlt,
                        borderRadius: BorderRadius.circular(13),
                        border: Border.all(color: _UMTheme.border),
                      ),
                      alignment: Alignment.center,
                      child: const Text('Batal', style: TextStyle(color: _UMTheme.white, fontWeight: FontWeight.w700, fontSize: 13)),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _PressableScale(
                    onTap: () => Navigator.pop(context, true),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 13),
                      decoration: BoxDecoration(
                        gradient: _UMTheme.primaryGradient,
                        borderRadius: BorderRadius.circular(13),
                      ),
                      alignment: Alignment.center,
                      child: const Text('Hapus', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 13)),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ─── DETAIL SHEET ─────────────────────────────────────────────────────────────
class _UserDetailSheet extends StatelessWidget {
  final ManagedUser user;
  final bool canDelete;
  final VoidCallback onDelete;
  const _UserDetailSheet({required this.user, required this.canDelete, required this.onDelete});

  Widget _row(String label, String value, {Color? valueColor, IconData? icon}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Row(
              children: [
                if (icon != null) ...[Icon(icon, size: 13, color: _UMTheme.grey), const SizedBox(width: 6)],
                Text(label, style: const TextStyle(color: _UMTheme.grey, fontSize: 11.5, fontWeight: FontWeight.w500)),
              ],
            ),
          ),
          Expanded(
            child: Text(value,
                style: TextStyle(color: valueColor ?? _UMTheme.white, fontSize: 12.5, fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final status = resolveStatus(user);
    final rColor = RoleMeta.color(user.role);
    final dateFmt = DateFormat('dd MMMM yyyy');
    final remainingDays = user.expiredAt?.difference(DateTime.now()).inDays;

    return Container(
      decoration: const BoxDecoration(
        color: _UMTheme.card,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom + 24,
        top: 14, left: 22, right: 22,
      ),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Center(
              child: Container(
                width: 40, height: 4,
                decoration: BoxDecoration(color: _UMTheme.border, borderRadius: BorderRadius.circular(2)),
              ),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Container(
                  width: 54,
                  height: 54,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(colors: [rColor.withOpacity(0.4), rColor.withOpacity(0.12)]),
                    border: Border.all(color: rColor.withOpacity(0.5), width: 1.2),
                  ),
                  child: Center(
                    child: Text(user.username.isNotEmpty ? user.username[0].toUpperCase() : '?',
                        style: TextStyle(color: rColor, fontSize: 20, fontWeight: FontWeight.w800)),
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(user.username, style: const TextStyle(color: _UMTheme.white, fontSize: 17, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Icon(RoleMeta.icon(user.role), size: 12, color: rColor),
                          const SizedBox(width: 4),
                          Text(RoleMeta.label(user.role), style: TextStyle(color: rColor, fontSize: 11, fontWeight: FontWeight.w700)),
                          const SizedBox(width: 8),
                          _PulseDot(color: statusColor(status)),
                          const SizedBox(width: 4),
                          Text(statusLabel(status), style: TextStyle(color: statusColor(status), fontSize: 11, fontWeight: FontWeight.w700)),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const Padding(padding: EdgeInsets.symmetric(vertical: 16), child: Divider(color: _UMTheme.border, height: 1)),
            _row('Telegram', user.telegramUsername != null ? '@${user.telegramUsername}' : '—', icon: Icons.send_rounded),
            if (user.telegramId != null) _row('Telegram ID', user.telegramId!, icon: Icons.tag_rounded),
            // Catatan: backend asli tidak mengembalikan 'id' terpisah dari
            // username, jadi baris "User ID" redundan dan dihapus di sini.
            const Padding(padding: EdgeInsets.symmetric(vertical: 8), child: Divider(color: _UMTheme.border, height: 1)),
            _row('Created', user.createdAt != null ? dateFmt.format(user.createdAt!) : 'No creation date', icon: Icons.calendar_today_rounded),
            _row('Expired', user.expiredAt != null ? dateFmt.format(user.expiredAt!) : 'No expiration', icon: Icons.event_busy_rounded),
            if (remainingDays != null)
              _row('Remaining', remainingDays >= 0 ? '$remainingDays hari' : 'Expired',
                  valueColor: statusColor(status), icon: Icons.hourglass_bottom_rounded),
            const Padding(padding: EdgeInsets.symmetric(vertical: 8), child: Divider(color: _UMTheme.border, height: 1)),
            _row('Created by', user.createdBy != null ? '@${user.createdBy}' : 'Unknown Creator', icon: Icons.person_rounded),
            if (user.creatorRole != null) _row('Creator Role', RoleMeta.label(user.creatorRole!), icon: Icons.badge_rounded),
            if (canDelete) ...[
              const SizedBox(height: 20),
              _PressableScale(
                onTap: onDelete,
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  decoration: BoxDecoration(
                    color: _UMTheme.primary.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: _UMTheme.primary.withOpacity(0.4)),
                  ),
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.delete_outline_rounded, color: _UMTheme.primary, size: 17),
                      SizedBox(width: 8),
                      Text('Hapus User Ini', style: TextStyle(color: _UMTheme.primary, fontSize: 13, fontWeight: FontWeight.w700)),
                    ],
                  ),
                ),
              ),
            ],
            const SizedBox(height: 4),
          ],
        ),
      ),
    );
  }
}
