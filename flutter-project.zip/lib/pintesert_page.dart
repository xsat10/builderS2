import 'package:flutter/material.dart';
import 'webview_tool_shell.dart';

class PintesertPage extends StatelessWidget {
  const PintesertPage({super.key});

  @override
  Widget build(BuildContext context) => const McWebViewShell(
        title: 'Pintesert',
        subtitle: 'Pinterest Web • Real-time',
        initialUrl: 'https://www.pinterest.com/',
        accent: Color(0xFFE60023),
        icon: Icons.push_pin_rounded,
      );
}
