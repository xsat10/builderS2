import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:math' as math;

import 'trading_models.dart';

// ─── TRADE PAGE ──────────────────────────────────────────────────────────
class TradePage extends StatefulWidget {
  final String sessionKey;
  final String role;
  final VoidCallback? onChartPressed;
  final VoidCallback? onQuotePressed;
  final VoidCallback? onHistoryPressed;

  const TradePage({
    Key? key,
    required this.sessionKey,
    required this.role,
    this.onChartPressed,
    this.onQuotePressed,
    this.onHistoryPressed,
  }) : super(key: key);

  @override
  State<TradePage> createState() => _TradePageState();
}

class _TradePageState extends State<TradePage>
    with SingleTickerProviderStateMixin {
  late AnimationController _animController;
  late Timer _updateTimer;

  double saldo = 10000000; // 10 juta
  double equity = 10000000;
  double margin = 766.80;
  double marginBebasRupiah = 7413.60;
  double levelMargin = 1066.82;
  double totalPnL = -948.32;

  List<Position> positions = [
    Position(
      id: '1',
      symbol: 'ADAUSD',
      type: 'buy',
      volume: 0.90,
      entryPrice: 0.2130,
      currentPrice: 0.2023,
      openTime: DateTime.now().subtract(const Duration(hours: 2)),
      pnl: -96.30,
    ),
    Position(
      id: '2',
      symbol: 'ADAUSD',
      type: 'buy',
      volume: 0.90,
      entryPrice: 0.2130,
      currentPrice: 0.2023,
      openTime: DateTime.now().subtract(const Duration(hours: 1, minutes: 30)),
      pnl: -96.30,
    ),
    Position(
      id: '3',
      symbol: 'ADAUSD',
      type: 'buy',
      volume: 0.90,
      entryPrice: 0.2130,
      currentPrice: 0.2023,
      openTime: DateTime.now().subtract(const Duration(hours: 1)),
      pnl: -96.30,
    ),
  ];

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    )..forward();

    _startPriceUpdate();
  }

  void _startPriceUpdate() {
    _updateTimer = Timer.periodic(Duration(seconds: 3), (_) {
      if (!mounted) return;

      final random = math.Random();
      setState(() {
        // Update posisi dengan fluctuasi harga
        for (var position in positions) {
          position.currentPrice +=
              (random.nextDouble() - 0.5) * 0.0001;
        }

        // Recalculate PnL
        double newTotalPnL = 0;
        for (var pos in positions) {
          final priceDiff = pos.currentPrice - pos.entryPrice;
          pos.pnl = priceDiff * pos.volume * 100;
          newTotalPnL += pos.pnl;
        }

        totalPnL = newTotalPnL;
        equity = saldo + totalPnL;

        _animController.forward(from: 0.0);
      });
    });
  }

  @override
  void dispose() {
    _updateTimer.cancel();
    _animController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: TradingTheme.bg,
      body: Column(
        children: [
          // ─── HEADER ───────────────────────────────────
          _buildHeader(),

          // ─── ACCOUNT STATS ─────────────────────────────
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildAccountStats(),
                  const SizedBox(height: 20),
                  _buildPositionsList(),
                ],
              ),
            ),
          ),

          // ─── BOTTOM NAV ────────────────────────────────
          _buildBottomNav(),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: TradingTheme.card,
        border: Border(
          bottom: BorderSide(color: TradingTheme.accent.withOpacity(0.25)),
        ),
        boxShadow: [
          BoxShadow(
            color: TradingTheme.accent.withOpacity(0.08),
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Trade',
                style: TextStyle(
                  color: TradingTheme.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Astral',
                ),
              ),
              Text(
                'Total PnL: ${totalPnL > 0 ? '+' : ''}${totalPnL.toStringAsFixed(2)} USD',
                style: TextStyle(
                  color: totalPnL > 0
                      ? TradingTheme.success
                      : TradingTheme.primary,
                  fontSize: 12,
                ),
              ),
            ],
          ),
          ScaleTransition(
            scale: Tween<double>(begin: 0.8, end: 1.0).animate(
              CurvedAnimation(
                  parent: _animController, curve: Curves.easeOutBack),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  formatCurrency(equity),
                  style: const TextStyle(
                    color: TradingTheme.white,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Astral',
                  ),
                ),
                Text(
                  'Equity',
                  style: TextStyle(color: TradingTheme.grey, fontSize: 11),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAccountStats() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Account Overview',
          style: TextStyle(
            color: TradingTheme.white,
            fontSize: 14,
            fontWeight: FontWeight.w600,
            fontFamily: 'Astral',
          ),
        ),
        const SizedBox(height: 12),
        _buildStatCard('Saldo', formatCurrency(saldo)),
        const SizedBox(height: 8),
        _buildStatCard('Equity', formatCurrency(equity)),
        const SizedBox(height: 8),
        _buildStatCard('Margin Used', formatCurrency(margin)),
        const SizedBox(height: 8),
        _buildStatCard('Margin Bebas Rp', formatCurrency(marginBebasRupiah)),
        const SizedBox(height: 8),
        _buildStatCard('Level Margin (%)', levelMargin.toStringAsFixed(2)),
      ],
    );
  }

  Widget _buildStatCard(String label, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: TradingTheme.cardAlt,
        border: Border.all(color: TradingTheme.accent.withOpacity(0.15)),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: TradingTheme.white,
              fontSize: 13,
              fontWeight: FontWeight.w500,
            ),
          ),
          Text(
            value,
            style: const TextStyle(
              color: TradingTheme.white,
              fontSize: 13,
              fontWeight: FontWeight.bold,
              fontFamily: 'Astral',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPositionsList() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Posisi Terbuka',
          style: TextStyle(
            color: TradingTheme.white,
            fontSize: 14,
            fontWeight: FontWeight.w600,
            fontFamily: 'Astral',
          ),
        ),
        const SizedBox(height: 12),
        ...positions.asMap().entries.map((entry) {
          final index = entry.key;
          final position = entry.value;
          return Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: _buildPositionCard(position, index),
          );
        }).toList(),
      ],
    );
  }

  Widget _buildPositionCard(Position position, int index) {
    final isProfit = position.pnl >= 0;
    final delay = index * 50;

    return SlideTransition(
      position: Tween<Offset>(begin: const Offset(1, 0), end: Offset.zero)
          .animate(
        CurvedAnimation(
          parent: _animController,
          curve: Interval(
            delay / 600,
            (delay + 200) / 600,
            curve: Curves.easeOutCubic,
          ),
        ),
      ),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: TradingTheme.cardAlt,
          border: Border.all(color: TradingTheme.accent.withOpacity(0.15)),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: position.type == 'buy'
                            ? TradingTheme.success
                            : TradingTheme.primary,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '${position.symbol}, ${position.type.toUpperCase()} ${position.volume}',
                          style: const TextStyle(
                            color: TradingTheme.white,
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        Text(
                          '${position.entryPrice.toStringAsFixed(4)} → ${position.currentPrice.toStringAsFixed(4)}',
                          style: TextStyle(
                            color: TradingTheme.grey,
                            fontSize: 11,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                Text(
                  '${isProfit ? '+' : ''}${position.pnl.toStringAsFixed(2)}',
                  style: TextStyle(
                    color: isProfit ? TradingTheme.success : TradingTheme.primary,
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Astral',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Dibuka: ${_formatTime(position.openTime)}',
                  style: TextStyle(
                    color: TradingTheme.grey,
                    fontSize: 10,
                  ),
                ),
                Row(
                  children: [
                    SizedBox(
                      width: 60,
                      height: 28,
                      child: ElevatedButton(
                        onPressed: () => _closePosition(position.id),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: TradingTheme.primary,
                          padding: EdgeInsets.zero,
                        ),
                        child: const Text(
                          'Close',
                          style: TextStyle(fontSize: 11),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBottomNav() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        color: TradingTheme.card,
        border: Border(
          top: BorderSide(color: TradingTheme.accent.withOpacity(0.2)),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _buildNavButton(
            icon: Icons.compare_arrows_rounded,
            label: 'Trade',
            isActive: true,
            onTap: () {},
          ),
          _buildNavButton(
            icon: Icons.show_chart_rounded,
            label: 'Chart',
            onTap: widget.onChartPressed ?? () {},
          ),
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                totalPnL.toStringAsFixed(2),
                style: TextStyle(
                  color: totalPnL > 0 ? TradingTheme.success : TradingTheme.primary,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
              Text(
                'USD',
                style: TextStyle(color: TradingTheme.grey, fontSize: 10),
              ),
            ],
          ),
          _buildNavButton(
            icon: Icons.access_time_rounded,
            label: 'Riwayat',
            onTap: widget.onHistoryPressed ?? () {},
          ),
          Stack(
            clipBehavior: Clip.none,
            children: [
              _buildNavButton(
                icon: Icons.notifications_active_rounded,
                label: 'Pesan',
                onTap: () {},
              ),
              Positioned(
                top: -4,
                right: -4,
                child: Container(
                  width: 16,
                  height: 16,
                  decoration: BoxDecoration(
                    color: TradingTheme.primary,
                    shape: BoxShape.circle,
                  ),
                  child: const Center(
                    child: Text(
                      '1',
                      style: TextStyle(
                        color: TradingTheme.white,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildNavButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool isActive = false,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            color:
                isActive ? TradingTheme.primary : TradingTheme.white54,
            size: 20,
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: TextStyle(
              color: isActive ? TradingTheme.primary : TradingTheme.grey,
              fontSize: 10,
              fontWeight: isActive ? FontWeight.w600 : FontWeight.normal,
            ),
          ),
        ],
      ),
    );
  }

  void _closePosition(String id) {
    setState(() {
      positions.removeWhere((p) => p.id == id);
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Posisi ditutup'),
        backgroundColor: TradingTheme.success,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  String _formatTime(DateTime time) {
    final now = DateTime.now();
    final diff = now.difference(time);

    if (diff.inMinutes < 1) {
      return 'Baru saja';
    } else if (diff.inMinutes < 60) {
      return '${diff.inMinutes}m ago';
    } else if (diff.inHours < 24) {
      return '${diff.inHours}h ago';
    } else {
      return '${diff.inDays}d ago';
    }
  }

  String formatCurrency(double value) {
    if (value >= 1000000) {
      return '${(value / 1000000).toStringAsFixed(2)}M';
    }
    return value.toStringAsFixed(2);
  }
}
