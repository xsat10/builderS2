import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:ui';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'api_config.dart';

// ═══════════════════════════════════════════════════════════════════════════
// STAFF PAGE — Tema "Emerald Glass"
// UI: Glassmorphism dengan floating gradient orb di background,
// kartu kaca blur, aksen hijau emerald & mint.
// ═══════════════════════════════════════════════════════════════════════════

class StaffPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const StaffPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<StaffPage> createState() => _StaffPageState();
}

class _StaffPageState extends State<StaffPage> with SingleTickerProviderStateMixin {
  late String sessionKey;
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];

  final List<String> roleOptions = [
  'executorius',
  'forius_utama',
  'moderator',
  'ceo_utama',
  'tangan_kanan',
  'tangan_kiri',
  'developers',
  'partner_pribadi',
  'partner',
  'admin',
  'reseller',
  'tukang_bubur',
  'vip',
  'member',
];

String selectedRole = 'member';

int currentPage = 1;
int itemsPerPage = 25;

  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  final deleteController = TextEditingController();
  final editUsernameController = TextEditingController();
  final editDayController = TextEditingController();

  String newUserRole = 'member';
  bool isLoading = false;

  late AnimationController _orbCtrl;

  // ── TEMA EMERALD ──
  final Color bgDark = const Color(0xFF061410);
  final Color primaryEmerald = const Color(0xFF10B981);
  final Color accentMint = const Color(0xFF6EE7B7);
  final Color primaryWhite = Colors.white;
  final Color textGrey = Colors.grey.shade400;
  final Color cardGlass = Colors.white.withOpacity(0.045);
  final Color borderGlass = Colors.white.withOpacity(0.09);

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    _orbCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 8))..repeat();
    _fetchUsers();
  }

  @override
  void dispose() {
    _orbCtrl.dispose();
    super.dispose();
  }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('http://shinoa-cpanelpanel.xtxintax.my.id:2003/listUsers?key=$sessionKey'),
      );
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _alert("Info", data['message'] ?? 'Gagal memuat user.');
      }
    } catch (_) {
      _alert("Error", "Gagal terhubung ke server.");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList = fullUserList.where((u) => u['role'] == selectedRole).toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = (start + itemsPerPage);
    return filteredList.sublist(start, end > filteredList.length ? filteredList.length : end);
  }

  int get totalPages => (filteredList.length / itemsPerPage).ceil().clamp(1, 9999);

  Future<void> _deleteUser() async {
    final username = deleteController.text.trim();
    if (username.isEmpty) {
      _alert("Peringatan", "Masukkan username yang ingin dihapus.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('http://shinoa-cpanelpanel.xtxintax.my.id:2003/deleteUser?key=$sessionKey&username=$username'),
      );
      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        _alert("Sukses", "User berhasil dihapus.");
        deleteController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal menghapus user.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _createAccount() async {
    final u = createUsernameController.text.trim();
    final p = createPasswordController.text.trim();
    final d = createDayController.text.trim();

    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
        'http://shinoa-cpanelpanel.xtxintax.my.id:2003/userAdd?key=$sessionKey&username=$u&password=$p&day=$d&role=$newUserRole',
      );
      final res = await http.get(url);
      final data = jsonDecode(res.body);

      if (data['created'] == true) {
        _alert("Sukses", "Akun berhasil dibuat sebagai ${newUserRole.toUpperCase()}.");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        newUserRole = 'member';
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal membuat akun.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _editUser() async {
    final u = editUsernameController.text.trim();
    final d = editDayController.text.trim();

    if (u.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
        'http://shinoa-cpanelpanel.xtxintax.my.id:2003/editUser?key=$sessionKey&username=$u&addDays=$d',
      );
      final res = await http.get(url);
      final data = jsonDecode(res.body);

      if (data['edited'] == true) {
        _alert("Sukses", "Durasi berhasil diperbarui.");
        editUsernameController.clear();
        editDayController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal mengubah durasi.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  void _alert(String title, String message) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: bgDark,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: accentMint.withOpacity(0.3)),
        ),
        title: Row(
          children: [
            Icon(FontAwesomeIcons.leaf, color: accentMint, size: 18),
            const SizedBox(width: 10),
            Text(title, style: TextStyle(color: primaryWhite)),
          ],
        ),
        content: Text(message, style: TextStyle(color: textGrey)),
        actions: [
          Center(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [primaryEmerald, accentMint]),
                borderRadius: BorderRadius.circular(12),
              ),
              child: TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text("OK", style: TextStyle(color: bgDark, fontWeight: FontWeight.bold)),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInput({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    TextInputType type = TextInputType.text,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextField(
        controller: controller,
        keyboardType: type,
        style: TextStyle(color: primaryWhite),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: accentMint),
          prefixIcon: Icon(icon, color: accentMint, size: 18),
          filled: true,
          fillColor: cardGlass,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: borderGlass),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: borderGlass),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: accentMint, width: 1.6),
          ),
        ),
      ),
    );
  }

  Widget _buildGlassCard({
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(22),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          margin: const EdgeInsets.only(bottom: 22),
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: cardGlass,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: borderGlass),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                primaryEmerald.withOpacity(0.06),
                Colors.transparent,
              ],
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: primaryEmerald.withOpacity(0.18),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: accentMint.withOpacity(0.3)),
                    ),
                    child: Icon(icon, color: accentMint, size: 18),
                  ),
                  const SizedBox(width: 12),
                  Text(
                    title,
                    style: TextStyle(
                      color: primaryWhite,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.1,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              ...children,
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildUserItem(Map user) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: cardGlass,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderGlass),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(9),
            decoration: BoxDecoration(color: primaryEmerald.withOpacity(0.16), shape: BoxShape.circle),
            child: Icon(FontAwesomeIcons.userGroup, color: accentMint, size: 15),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(user['username'] ?? '-',
                    style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold, fontSize: 14)),
                const SizedBox(height: 3),
                Text("ROLE: ${(user['role'] ?? '-').toString().toUpperCase()} | EXP: ${user['expiredDate'] ?? '-'}",
                    style: TextStyle(color: textGrey, fontSize: 11.5)),
              ],
            ),
          ),
          IconButton(
            icon: Icon(FontAwesomeIcons.trashCan, color: accentMint.withOpacity(0.8), size: 16),
            onPressed: () async {
              final confirm = await showDialog<bool>(
                context: context,
                builder: (_) => AlertDialog(
                  backgroundColor: bgDark,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(18),
                    side: BorderSide(color: accentMint.withOpacity(0.3)),
                  ),
                  title: Text("Konfirmasi", style: TextStyle(color: primaryWhite)),
                  content: Text("Hapus user ini?", style: TextStyle(color: textGrey)),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context, false), child: Text("Batal", style: TextStyle(color: textGrey))),
                    TextButton(onPressed: () => Navigator.pop(context, true), child: Text("Hapus", style: TextStyle(color: accentMint))),
                  ],
                ),
              );
              if (confirm == true) {
                deleteController.text = user['username'];
                _deleteUser();
              }
            },
          ),
        ],
      ),
    );
  }

  Widget _buildPagination() {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: List.generate(totalPages, (index) {
        final page = index + 1;
        final active = currentPage == page;
        return GestureDetector(
          onTap: () => setState(() => currentPage = page),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              color: active ? primaryEmerald.withOpacity(0.25) : Colors.transparent,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: active ? accentMint : borderGlass),
            ),
            child: Text("$page", style: TextStyle(color: active ? accentMint : textGrey, fontSize: 12)),
          ),
        );
      }),
    );
  }

  Widget _buildGradientButton({required String label, required IconData icon, required VoidCallback? onPressed}) {
    return Container(
      height: 52,
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [primaryEmerald, accentMint]),
        borderRadius: BorderRadius.circular(14),
        boxShadow: [BoxShadow(color: primaryEmerald.withOpacity(0.35), blurRadius: 16, offset: const Offset(0, 6))],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: onPressed,
          child: Center(
            child: isLoading
                ? SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: bgDark))
                : Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(icon, size: 17, color: bgDark),
                      const SizedBox(width: 8),
                      Text(label, style: TextStyle(color: bgDark, fontWeight: FontWeight.bold, letterSpacing: 1)),
                    ],
                  ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: Stack(
        children: [
          // Floating gradient orbs (background ambience)
          AnimatedBuilder(
            animation: _orbCtrl,
            builder: (context, _) {
              final t = _orbCtrl.value * 2 * 3.1416;
              return Stack(
                children: [
                  Positioned(
                    top: 60 + 20 * (0.5 + 0.5 * (t.remainder(6.28) / 6.28)),
                    left: -80,
                    child: Container(
                      width: 220, height: 220,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: RadialGradient(colors: [primaryEmerald.withOpacity(0.25), Colors.transparent]),
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 120,
                    right: -60,
                    child: Container(
                      width: 260, height: 260,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: RadialGradient(colors: [accentMint.withOpacity(0.16), Colors.transparent]),
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      IconButton(
                        icon: Icon(Icons.arrow_back_ios_new_rounded, color: accentMint, size: 18),
                        onPressed: () => Navigator.pop(context),
                      ),
                      const SizedBox(width: 40),
                    ],
                  ),
                  Container(
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(colors: [primaryEmerald.withOpacity(0.25), Colors.transparent]),
                      border: Border.all(color: accentMint.withOpacity(0.4)),
                    ),
                    child: Icon(FontAwesomeIcons.userTie, color: accentMint, size: 34),
                  ),
                  const SizedBox(height: 14),
                  Text(
                    "STAFF PANEL",
                    style: TextStyle(
                      color: primaryWhite,
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2,
                      shadows: [Shadow(color: primaryEmerald.withOpacity(0.7), blurRadius: 12)],
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text("Manajemen akun tingkat staff", style: TextStyle(color: textGrey, fontSize: 12.5)),
                  const SizedBox(height: 30),

                  _buildGlassCard(
                    title: "DELETE USER",
                    icon: FontAwesomeIcons.userSlash,
                    children: [
                      _buildInput(label: "Username Target", controller: deleteController, icon: FontAwesomeIcons.user),
                      const SizedBox(height: 8),
                      _buildGradientButton(label: "DELETE ACCOUNT", icon: FontAwesomeIcons.trashCan, onPressed: isLoading ? null : _deleteUser),
                    ],
                  ),

                  _buildGlassCard(
                    title: "CREATE ACCOUNT",
                    icon: FontAwesomeIcons.userPlus,
                    children: [
                      _buildInput(label: "Username", controller: createUsernameController, icon: FontAwesomeIcons.user),
                      _buildInput(label: "Password", controller: createPasswordController, icon: FontAwesomeIcons.lock),
                      _buildInput(label: "Durasi (Hari)", controller: createDayController, icon: FontAwesomeIcons.calendarDay, type: TextInputType.number),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: borderGlass),
                        ),
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton<String>(
                            value: newUserRole,
                            dropdownColor: bgDark,
                            isExpanded: true,
                            style: TextStyle(color: primaryWhite),
                            items: roleOptions.map((role) => DropdownMenuItem(value: role, child: Text(role.toUpperCase()))).toList(),
                            onChanged: (val) => setState(() => newUserRole = val ?? 'member'),
                          ),
                        ),
                      ),
                      const SizedBox(height: 18),
                      _buildGradientButton(label: "CREATE ACCOUNT", icon: FontAwesomeIcons.userPlus, onPressed: isLoading ? null : _createAccount),
                    ],
                  ),

                  _buildGlassCard(
                    title: "EXTEND DURATION",
                    icon: FontAwesomeIcons.clock,
                    children: [
                      _buildInput(label: "Username Target", controller: editUsernameController, icon: FontAwesomeIcons.userPen),
                      _buildInput(label: "Tambah Hari", controller: editDayController, icon: FontAwesomeIcons.calendarPlus, type: TextInputType.number),
                      const SizedBox(height: 8),
                      _buildGradientButton(label: "ADD DAYS", icon: FontAwesomeIcons.calendarPlus, onPressed: isLoading ? null : _editUser),
                    ],
                  ),

                  _buildGlassCard(
                    title: "USER LIST",
                    icon: FontAwesomeIcons.users,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: borderGlass),
                        ),
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton<String>(
                            value: selectedRole,
                            dropdownColor: bgDark,
                            isExpanded: true,
                            style: TextStyle(color: primaryWhite),
                            items: roleOptions.map((role) => DropdownMenuItem(value: role, child: Text(role.toUpperCase()))).toList(),
                            onChanged: (val) {
                              if (val != null) {
                                selectedRole = val;
                                _filterAndPaginate();
                              }
                            },
                          ),
                        ),
                      ),
                      const SizedBox(height: 18),
                      isLoading
                          ? Padding(padding: const EdgeInsets.all(20), child: Center(child: CircularProgressIndicator(color: accentMint)))
                          : filteredList.isEmpty
                              ? Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 30),
                                  child: Center(child: Text("Tidak ada user pada role ini", style: TextStyle(color: textGrey))),
                                )
                              : Column(
                                  children: [
                                    ..._getCurrentPageData().map((u) => _buildUserItem(u)).toList(),
                                    const SizedBox(height: 16),
                                    _buildPagination(),
                                  ],
                                ),
                    ],
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
