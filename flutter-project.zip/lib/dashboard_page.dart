import 'dart:convert';
import 'dart:math'; // Diperlukan untuk Random particles
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:http/http.dart' as http; // Added for Coin Function

// Custom Imports
import 'bug_sender.dart';
import 'nik_check.dart';
import 'admin_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'anime_home.dart';
import 'history_coin.dart'; // Added for History Page

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  late AnimationController _controller;
  late AnimationController _fadeController;
  late Animation<double> _animation;
  late Animation<double> _fadeAnimation;
  late WebSocketChannel channel;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;
  String androidId = "unknown";

  int _selectedTabIndex = 0;
  Widget _selectedPage = const Placeholder();

  int onlineUsers = 0;
  int activeConnections = 0;

  // --- COIN VARIABLES ---
  int bCoin = 0;
  int lCoin = 0;

  // --- NEON PURPLE PINK BLACK THEME PALETTE ---
  final Color bgBlack = const Color(0xFF050505); // Deep Black Background
  final Color cardBlack = const Color(0xFF141414); // Slightly Lighter Black
  final Color primaryPurple = const Color(0xFFD500F9); // Neon Purple
  final Color primaryPink = const Color(0xFFFF4081); // Neon Pink
  final Color textWhite = const Color(0xFFFFFFFF);
  final Color textGrey = const Color(0xFFB0BEC5);

  // --- SERVER URL CONFIG ---
  final String baseUrl = "http://publikzero.bypstar7.web.id:3585";

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    // Load Coin Data
    loadCoin();

    _controller = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    );

    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeInOut),
    );

    _controller.forward();
    _fadeController.forward();

    // Default Page set to the Dashboard UI
    _selectedPage = _buildNeonDashboard();

    _initAndroidIdAndConnect();
  }

  // --- COIN FUNCTIONS ---
  Future<void> loadCoin() async {
    try {
      final res = await http.post(
        Uri.parse("$baseUrl/profile"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"username": username}),
      );

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (mounted) {
          setState(() {
            bCoin = data["bitcoin"] ?? 0;
            lCoin = data["lcoin"] ?? 0;
          });
        }
      }
    } catch (e) {
      debugPrint("Error loading coin: $e");
    }
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(
        Uri.parse(baseUrl)); // Menggunakan Base URL yang sama
    channel.sink.add(jsonEncode({
      "type": "validate",
      "key": sessionKey,
      "androidId": androidId,
    }));
    channel.sink.add(jsonEncode({"type": "stats"}));

    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'myInfo') {
        if (data['valid'] == false) {
          if (data['reason'] == 'androidIdMismatch') {
            _handleInvalidSession(
                "Your account has logged on another device.");
          } else if (data['reason'] == 'keyInvalid') {
            _handleInvalidSession("Key is not valid. Please login again.");
          }
        }
      }
      if (data['type'] == 'stats') {
        if (mounted) {
          setState(() {
            onlineUsers = data['onlineUsers'] ?? 0;
            activeConnections = data['activeConnections'] ?? 0;
          });
        }
      }
    });
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: cardBlack,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
            side: BorderSide(color: primaryPurple.withOpacity(0.5))),
        title: Text("⚠️ Session Expired",
            style: TextStyle(color: primaryPink, fontWeight: FontWeight.bold)),
        content: Text(message, style: TextStyle(color: textWhite)),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                (route) => false,
              );
            },
            child: Text("OK",
                style: TextStyle(
                    color: primaryPurple, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  // --- NAVIGATION LOGIC ---
  void _onTabTapped(int index) {
    setState(() {
      _selectedTabIndex = index;
      if (index == 0) {
        _selectedPage = _buildNeonDashboard();
      } else if (index == 1) {
        _selectedPage = ToolsPage(
            sessionKey: sessionKey, userRole: role, listDoos: listDoos);
      } else if (index == 2) {
        _selectedPage = HomeAnimePage();
      }
    });
  }

  void _onDrawerItemSelected(int index) {
    setState(() {
      if (index == 3) {
        _selectedPage = NikCheckerPage();
      } else if (index == 4) {
        _selectedPage = ChangePasswordPage(
            username: username, sessionKey: sessionKey);
      } else if (index == 5) {
        _selectedPage = SellerPage(keyToken: sessionKey);
      } else if (index == 6) {
        _selectedPage = AdminPage(sessionKey: sessionKey);
      }
    });
  }

  // --- NEON BLACK DASHBOARD UI ---
  Widget _buildNeonDashboard() {
    return FadeTransition(
      opacity: _fadeAnimation,
      child: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 10),

            // 1. Header Banner
            _buildHeaderBanner(),

            const SizedBox(height: 24),

            // === 🆕 NEW: JPG SLIDER (2 IMAGES) ===
            _buildImageSlider(),

            const SizedBox(height: 24),

            // === WALLET SECTION ===
            Row(
              children: const [
                Icon(
                  Icons.account_balance_wallet_rounded,
                  color: Color(0xFFFFC107), // 🟡 kuning
                  size: 22,
                ),
                SizedBox(width: 10),
                Text(
                  "My Wallet",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            // WALLET CARD
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: const Color(0xFF0F0F0F),
                borderRadius: BorderRadius.circular(26),
                border: Border.all(
                  color: Colors.white.withOpacity(0.08),
                  width: 1,
                ),
              ),
              child: Column(
                children: [
                  _AccountTiles(
                    icon: Icons.person,
                    iconColor: const Color(0xFF9E9E9E),
                    title: "Username",
                    amount: username,
                    badgeColor: const Color(0xFF9E9E9E),
                  ),
                  const SizedBox(height: 14),
                  _coinTile(
                    icon: Icons.currency_bitcoin,
                    iconColor: const Color(0xFFFFC107),
                    title: "B Coin",
                    amount: bCoin.toString(),
                    badgeColor: const Color(0xFFFFC107),
                  ),
                  const SizedBox(height: 14),
                  _coinTile(
                    icon: Icons.monetization_on,
                    iconColor: const Color(0xFF4DA3FF),
                    title: "L Coin",
                    amount: lCoin.toString(),
                    badgeColor: const Color(0xFF4DA3FF),
                  ),
                  const SizedBox(height: 22),
                  Row(
                    children: [
                      Expanded(
                        child: _actionButton(
                          icon: Icons.add_circle_outline,
                          label: "Top Up",
                          color: const Color(0xFFFFC107),
                          onTap: () {
                            final redeemCtrl = TextEditingController();

                            showDialog(
                              context: context,
                              builder: (_) => AlertDialog(
                                backgroundColor: const Color(0xFF0F0F0F),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(18),
                                ),
                                title: const Text(
                                  "Top Up",
                                  style: TextStyle(color: Colors.white),
                                ),
                                content: TextField(
                                  controller: redeemCtrl,
                                  style: const TextStyle(color: Colors.white),
                                  decoration: const InputDecoration(
                                    hintText: "Masukkan kode redeem",
                                    hintStyle: TextStyle(color: Colors.white54),
                                  ),
                                ),
                                actions: [
                                  TextButton(
                                    onPressed: () => Navigator.pop(context),
                                    child: const Text("Batal"),
                                  ),
                                  TextButton(
                                    onPressed: () async {
                                      Navigator.pop(context);

                                      showDialog(
                                        context: context,
                                        barrierDismissible: false,
                                        builder: (_) => const Center(
                                            child: CircularProgressIndicator()),
                                      );

                                      try {
                                        final res = await http.post(
                                          Uri.parse("$baseUrl/topup"),
                                          headers: {
                                            "Content-Type": "application/json"
                                          },
                                          body: jsonEncode({
                                            "username": widget.username,
                                            "code": redeemCtrl.text,
                                          }),
                                        );

                                        Navigator.pop(context); // Close loading

                                        final data = jsonDecode(res.body);

                                        if (data["success"] == true) {
                                          await loadCoin();
                                        }

                                        showDialog(
                                          context: context,
                                          builder: (_) => AlertDialog(
                                            backgroundColor:
                                                const Color(0xFF0F0F0F),
                                            title: Text(
                                              data["success"]
                                                  ? "Berhasil"
                                                  : "Gagal",
                                              style: const TextStyle(
                                                  color: Colors.white),
                                            ),
                                            content: Text(
                                              data["message"],
                                              style: const TextStyle(
                                                  color: Colors.white70),
                                            ),
                                          ),
                                        );
                                      } catch (e) {
                                        Navigator.pop(context);
                                        debugPrint("Topup Error: $e");
                                      }
                                    },
                                    child: const Text("Kirim"),
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                      ),
                      const SizedBox(width: 14),

                      // === TOMBOL TRANSFER FIXED ===
                      Expanded(
                        child: _actionButton(
                          icon: Icons.send,
                          label: "Transfer",
                          color: const Color(0xFF4DA3FF),
                          onTap: () {
                            final userCtrl = TextEditingController();
                            final amountCtrl = TextEditingController();
                            String selectedCoin = "bitcoin"; // default value

                            showDialog(
                              context: context,
                              builder: (context) {
                                return StatefulBuilder(
                                  builder: (context, setState) {
                                    return AlertDialog(
                                      backgroundColor: const Color(0xFF0F0F0F),
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(18),
                                      ),
                                      title: const Text(
                                        "Transfer Coin",
                                        style: TextStyle(color: Colors.white),
                                      ),
                                      content: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          TextField(
                                            controller: userCtrl,
                                            style: const TextStyle(
                                                color: Colors.white),
                                            decoration: const InputDecoration(
                                              hintText: "Username Tujuan",
                                              hintStyle: TextStyle(
                                                  color: Colors.white54),
                                              prefixIcon: Icon(Icons.person,
                                                  color: Colors.white54),
                                            ),
                                          ),
                                          const SizedBox(height: 12),
                                          DropdownButtonFormField<String>(
                                            value: selectedCoin,
                                            dropdownColor:
                                                const Color(0xFF151515),
                                            decoration: const InputDecoration(
                                              hintText: "Pilih Coin",
                                              hintStyle: TextStyle(
                                                  color: Colors.white54),
                                              prefixIcon: Icon(
                                                  Icons.monetization_on,
                                                  color: Colors.white54),
                                            ),
                                            style: const TextStyle(
                                                color: Colors.white),
                                            items: const [
                                              DropdownMenuItem(
                                                value: "bitcoin",
                                                child: Text("B Coin (Bitcoin)"),
                                              ),
                                              DropdownMenuItem(
                                                value: "lcoin",
                                                child: Text("L Coin"),
                                              ),
                                            ],
                                            onChanged: (value) {
                                              setState(() {
                                                selectedCoin = value!;
                                              });
                                            },
                                          ),
                                          const SizedBox(height: 12),
                                          TextField(
                                            controller: amountCtrl,
                                            keyboardType: TextInputType.number,
                                            style: const TextStyle(
                                                color: Colors.white),
                                            decoration: const InputDecoration(
                                              hintText: "Jumlah",
                                              hintStyle: TextStyle(
                                                  color: Colors.white54),
                                              prefixIcon: Icon(Icons.numbers,
                                                  color: Colors.white54),
                                            ),
                                          ),
                                        ],
                                      ),
                                      actions: [
                                        TextButton(
                                          onPressed: () =>
                                              Navigator.pop(context),
                                          child: const Text("Batal"),
                                        ),
                                        TextButton(
                                          onPressed: () async {
                                            // Validasi input
                                            if (userCtrl.text.isEmpty ||
                                                amountCtrl.text.isEmpty) {
                                              return;
                                            }
                                            
                                            // Tutup dialog input
                                            Navigator.pop(context);

                                            // Tampilkan Loading
                                            showDialog(
                                              context: context,
                                              barrierDismissible: false,
                                              builder: (_) => const Center(
                                                  child:
                                                      CircularProgressIndicator()),
                                            );

                                            try {
                                              // Hit API /transfer sesuai index.js
                                              final res = await http.post(
                                                Uri.parse("$baseUrl/transfer"),
                                                headers: {
                                                  "Content-Type":
                                                      "application/json"
                                                },
                                                body: jsonEncode({
                                                  "from": widget.username,
                                                  "to": userCtrl.text,
                                                  "amount": amountCtrl.text,
                                                  "coinType": selectedCoin,
                                                }),
                                              );

                                              Navigator.pop(context); // Tutup Loading

                                              final data = jsonDecode(res.body);

                                              // Jika sukses, refresh saldo
                                              if (data["success"] == true) {
                                                await loadCoin();
                                              }

                                              // Tampilkan Hasil
                                              showDialog(
                                                context: context,
                                                builder: (_) => AlertDialog(
                                                  backgroundColor:
                                                      const Color(0xFF0F0F0F),
                                                  title: Text(
                                                    data["success"]
                                                        ? "Berhasil"
                                                        : "Gagal",
                                                    style: TextStyle(
                                                        color: data["success"]
                                                            ? Colors.green
                                                            : Colors.red),
                                                  ),
                                                  content: Text(
                                                    data["message"],
                                                    style: const TextStyle(
                                                        color: Colors.white70),
                                                  ),
                                                  actions: [
                                                    TextButton(
                                                      onPressed: () =>
                                                          Navigator.pop(
                                                              context),
                                                      child: const Text("OK"),
                                                    )
                                                  ],
                                                ),
                                              );
                                            } catch (e) {
                                              Navigator.pop(context);
                                              debugPrint("Transfer Error: $e");
                                              ScaffoldMessenger.of(context).showSnackBar(
                                                  SnackBar(content: Text("Error: $e"))
                                              );
                                            }
                                          },
                                          child: const Text("Kirim",
                                              style: TextStyle(
                                                  color: Color(0xFF4DA3FF),
                                                  fontWeight: FontWeight.bold)),
                                        ),
                                      ],
                                    );
                                  },
                                );
                              },
                            );
                          },
                        ),
                      ),
                      const SizedBox(width: 14),

                      // BUTTON HISTORY
                      Expanded(
                        child: _actionButton(
                          icon: Icons.restore,
                          label: "History",
                          color: const Color(0xFF00C853),
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => CoinHistoryPage(
                                  username: widget.username,
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // 2. Developer Hub
            _buildSectionTitle("Developer Hub", primaryPurple),
            const SizedBox(height: 12),
            _buildGradientButton(
              text: "JOIN CHANNEL DEV",
              icon: FontAwesomeIcons.telegram,
              colors: [Colors.purple.shade900, Colors.deepPurple],
              onTap: () {
                // Action for join channel
              },
            ),

            const SizedBox(height: 24),

            // 3. Divine Missions (Quick Actions)
            _buildSectionTitle("Divine Missions", primaryPink),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: _buildActionCard(
                    title: "WhatsApp",
                    icon: FontAwesomeIcons.whatsapp,
                    color: cardBlack,
                    iconColor: primaryPink,
                    onTap: () {
                      setState(() {
                        _selectedPage = HomePage(
                          username: username,
                          password: password,
                          listBug: listBug,
                          role: role,
                          expiredDate: expiredDate,
                          sessionKey: sessionKey,
                        );
                      });
                    },
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: _buildActionCard(
                    title: "Senders",
                    icon: Icons.mobile_friendly,
                    color: cardBlack,
                    iconColor: primaryPurple,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => BugSenderPage(
                            sessionKey: sessionKey,
                            username: username,
                            role: role,
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),

            const SizedBox(height: 24),

            // 4. Shrine Status (Stats)
            _buildSectionTitle("Shrine Status", primaryPurple),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: cardBlack,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                    color: primaryPurple.withOpacity(0.3), width: 1),
                boxShadow: [
                  BoxShadow(
                      color: primaryPurple.withOpacity(0.1),
                      blurRadius: 15,
                      offset: const Offset(0, 0)),
                ],
              ),
              child: Column(
                children: [
                  _buildStatRow(Icons.person_outline, "Username", username),
                  Divider(height: 20, color: Colors.grey.shade800),
                  _buildStatRow(Icons.security, "Role", role.toUpperCase()),
                  Divider(height: 20, color: Colors.grey.shade800),
                  _buildStatRow(
                      Icons.calendar_today, "Expired", expiredDate),
                  Divider(height: 20, color: Colors.grey.shade800),
                  _buildStatRow(
                      Icons.wifi, "Online Users", "$onlineUsers"),
                ],
              ),
            ),

            const SizedBox(height: 80), // Bottom padding
          ],
        ),
      ),
    );
  }

  // --- NEW: IMAGE SLIDER WIDGET ---
  Widget _buildImageSlider() {
    final List<String> images = [
      "https://files.catbox.moe/az1rjo.jpg",
      "https://files.catbox.moe/eag4g9.jpg",
      "https://files.catbox.moe/ktr8wm.jpg",
      "https://files.catbox.moe/gb74fv.jpg",
      "https://files.catbox.moe/bce1na.jpg",
      "https://files.catbox.moe/6ldtfh.jpg",
      "https://files.catbox.moe/x6ar3t.jpg",
    ];

    return SizedBox(
      height: 160,
      child: PageView.builder(
        itemCount: images.length,
        controller: PageController(viewportFraction: 0.92),
        itemBuilder: (context, index) {
          return Container(
            margin: const EdgeInsets.symmetric(horizontal: 6.0),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: primaryPurple.withOpacity(0.3)),
              image: DecorationImage(
                image: NetworkImage(images[index]),
                fit: BoxFit.cover,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.5),
                  blurRadius: 10,
                  offset: const Offset(0, 5),
                ),
              ],
            ),
            child: Container( 
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.transparent, Colors.black.withOpacity(0.3)],
                  )
                ),
            ),
          );
        },
      ),
    );
  }

  // --- WALLET HELPER WIDGETS ---
  Widget _actionButton({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 18),
        decoration: BoxDecoration(
          color: color.withOpacity(0.18),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.35),
              blurRadius: 10,
              offset: const Offset(0, 8),
            ),
          ],
          border: Border.all(
            color: color.withOpacity(0.4),
            width: 0.8,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 26),
            const SizedBox(height: 8),
            Text(
              label,
              style: TextStyle(
                color: color,
                fontSize: 14,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _AccountTiles({
    required IconData icon,
    required Color iconColor,
    required String title,
    required String amount,
    required Color badgeColor,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: const Color(0xFF151515),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: badgeColor.withOpacity(0.4),
          width: 0.8,
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: badgeColor.withOpacity(0.18),
            ),
            child: Icon(icon, color: badgeColor, size: 22),
          ),
          const SizedBox(width: 14),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(
                  color: badgeColor,
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                ),
              ),
              Text(
                amount,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: badgeColor.withOpacity(0.15),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.shield_outlined,
                  size: 12,
                  color: badgeColor,
                ),
                const SizedBox(width: 4),
                Text(
                  "Status",
                  style: TextStyle(
                    color: badgeColor,
                    fontSize: 11,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _coinTile({
    required IconData icon,
    required Color iconColor,
    required String title,
    required String amount,
    required Color badgeColor,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: const Color(0xFF151515),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: badgeColor.withOpacity(0.4),
          width: 0.8,
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: badgeColor.withOpacity(0.18),
            ),
            child: Icon(icon, color: badgeColor, size: 22),
          ),
          const SizedBox(width: 14),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(
                  color: badgeColor,
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                ),
              ),
              Text(
                amount,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: badgeColor.withOpacity(0.15),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Text(
              "Balance",
              style: TextStyle(
                color: badgeColor,
                fontSize: 11,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title, Color color) {
    return Container(
      padding: const EdgeInsets.only(left: 10),
      decoration: BoxDecoration(
        border: Border(left: BorderSide(color: color, width: 4)),
      ),
      child: Text(
        title,
        style: TextStyle(
          color: textWhite,
          fontSize: 16,
          fontWeight: FontWeight.bold,
          fontFamily: 'Poppins',
          shadows: [
            Shadow(color: color.withOpacity(0.6), blurRadius: 10),
          ],
        ),
      ),
    );
  }

  // --- NEW HEADER IMPLEMENTATION (CYBER CARD) ---
  Widget _buildHeaderBanner() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF031018), // Dark Cyan/Black Background
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Colors.cyanAccent.withOpacity(0.3)),
        boxShadow: [
          BoxShadow(
            color: Colors.cyanAccent.withOpacity(0.1),
            blurRadius: 20,
            spreadRadius: 1,
          ),
        ],
      ),
      child: Stack(
        children: [
          // Background Particles Effect (Dots)
          Positioned.fill(
            child: CustomPaint(
              painter:
                  _ParticlePainter(color: Colors.cyanAccent.withOpacity(0.2)),
            ),
          ),

          Column(
            children: [
              // Top Section: Avatar & Info
              Row(
                children: [
                  // Avatar with Glowing Border
                  Container(
                    padding: const EdgeInsets.all(3),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.cyanAccent, width: 2),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.cyanAccent.withOpacity(0.4),
                          blurRadius: 15,
                        )
                      ],
                    ),
                    child: const CircleAvatar(
                      radius: 35,
                      backgroundColor: Colors.black,
                      backgroundImage: NetworkImage(
                          'https://files.catbox.moe/jfb77m.jpg'), // Menggunakan avatar yang ada
                    ),
                  ),
                  const SizedBox(width: 20),

                  // Text Info
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "WELCOME BACK,",
                          style: TextStyle(
                            color: Colors.cyanAccent,
                            fontSize: 10,
                            letterSpacing: 2,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 5),
                        Text(
                          username, // Dynamic Username
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 28,
                            fontWeight: FontWeight.bold,
                            shadows: [
                              Shadow(color: Colors.cyan, blurRadius: 10),
                            ],
                          ),
                        ),
                        const SizedBox(height: 5),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 4),
                          decoration: BoxDecoration(
                            color: const Color(0xFF052025),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(
                                color: Colors.cyanAccent.withOpacity(0.5)),
                          ),
                          child: Text(
                            role.toUpperCase(), // Dynamic Role
                            style: const TextStyle(
                              color: Colors.cyanAccent,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 25),

              // Bottom Section: Buttons
              Row(
                children: [
                  // Change Password Button
                  Expanded(
                    child: _buildCyberButton(
                      text: "CHANGE PASS",
                      icon: Icons.lock_reset,
                      color: const Color(0xFF1E88E5), // Blue
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) => ChangePasswordPage(
                                    username: username,
                                    sessionKey: sessionKey)));
                      },
                    ),
                  ),
                  const SizedBox(width: 15),
                  // Logout Button
                  Expanded(
                    child: _buildCyberButton(
                      text: "LOGOUT",
                      icon: Icons.logout,
                      color: const Color(0xFFD32F2F), // Red
                      onTap: () async {
                        final prefs = await SharedPreferences.getInstance();
                        await prefs.clear();
                        if (!mounted) return;
                        Navigator.of(context).pushAndRemoveUntil(
                          MaterialPageRoute(builder: (_) => const LoginPage()),
                          (route) => false,
                        );
                      },
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  // Helper Widget for the Cyber Buttons
  Widget _buildCyberButton(
      {required String text,
      required IconData icon,
      required Color color,
      required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: color.withOpacity(0.5)),
            boxShadow: [
              BoxShadow(color: color.withOpacity(0.05), blurRadius: 5)
            ]),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 18),
            const SizedBox(width: 8),
            Text(
              text,
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 12,
                letterSpacing: 1,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGradientButton(
      {required String text,
      required IconData icon,
      required List<Color> colors,
      required VoidCallback onTap}) {
    return Container(
      width: double.infinity,
      height: 55,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          gradient: LinearGradient(colors: colors),
          boxShadow: [
            BoxShadow(
                color: colors[0].withOpacity(0.6),
                blurRadius: 15,
                offset: const Offset(0, 4)),
          ],
          border: Border.all(color: Colors.white.withOpacity(0.1))),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(30),
          onTap: onTap,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: Colors.white),
              const SizedBox(width: 10),
              Text(
                text,
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildActionCard(
      {required String title,
      required IconData icon,
      required Color color,
      required Color iconColor,
      required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 100,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: iconColor.withOpacity(0.3)),
          boxShadow: [
            BoxShadow(
                color: iconColor.withOpacity(0.1),
                blurRadius: 10,
                offset: const Offset(0, 5)),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: iconColor, size: 32),
            const SizedBox(height: 12),
            Text(
              title,
              style: TextStyle(
                  color: textWhite, fontSize: 14, fontWeight: FontWeight.w600),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatRow(IconData icon, String label, String value) {
    return Row(
      children: [
        Icon(icon, color: primaryPink, size: 20),
        const SizedBox(width: 12),
        Text(label, style: TextStyle(color: textGrey)),
        const Spacer(),
        Text(value,
            style: TextStyle(
                fontWeight: FontWeight.bold, color: textWhite)),
      ],
    );
  }

  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: cardBlack, // Warna Background Drawer Gelap
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          UserAccountsDrawerHeader(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                  colors: [primaryPurple, primaryPink]), // Gradient Header
            ),
            accountName: Text(username,
                style: const TextStyle(
                    fontWeight: FontWeight.bold, color: Colors.white)),
            accountEmail: Text("Role: $role",
                style: const TextStyle(color: Colors.white70)),
            currentAccountPicture: const CircleAvatar(
              backgroundColor: Colors.white,
              child: Icon(Icons.person, color: Colors.black, size: 40),
            ),
          ),
          ListTile(
            leading: Icon(Icons.store, color: primaryPurple),
            title: const Text("Seller Page",
                style: TextStyle(color: Colors.white)),
            onTap: () {
              Navigator.pop(context);
              if (role == "reseller" || role == "owner")
                _onDrawerItemSelected(5);
            },
          ),
          if (role == "owner")
            ListTile(
              leading: Icon(Icons.admin_panel_settings, color: primaryPink),
              title: const Text("Admin Page",
                  style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.pop(context);
                _onDrawerItemSelected(6);
              },
            ),
          Divider(color: Colors.grey.shade800),
          ListTile(
            leading: const Icon(Icons.logout, color: Colors.grey),
            title: const Text("Logout", style: TextStyle(color: Colors.white)),
            onTap: () async {
              final prefs = await SharedPreferences.getInstance();
              await prefs.clear();
              if (!mounted) return;
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                (route) => false,
              );
            },
          ),
        ],
      ),
    );
  }

  void _showAccountMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: cardBlack,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                    color: Colors.grey.shade600,
                    borderRadius: BorderRadius.circular(2))),
            const SizedBox(height: 20),
            Text("Settings",
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: textWhite)),
            const SizedBox(height: 20),
            ListTile(
              leading: Icon(Icons.lock_reset, color: primaryPurple),
              title: Text("Change Password", style: TextStyle(color: textWhite)),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => ChangePasswordPage(
                            username: username, sessionKey: sessionKey)));
              },
            ),
            ListTile(
              leading: const Icon(Icons.logout, color: Colors.red),
              title: Text("Logout", style: TextStyle(color: textWhite)),
              onTap: () async {
                final prefs = await SharedPreferences.getInstance();
                await prefs.clear();
                if (!mounted) return;
                Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (_) => const LoginPage()),
                  (route) => false,
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      appBar: AppBar(
        backgroundColor: bgBlack,
        elevation: 0,
        centerTitle: false,
        automaticallyImplyLeading: true,
        iconTheme: const IconThemeData(color: Colors.white),
        title: Row(
          children: [
            const Icon(Icons.code, color: Colors.white, size: 20),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(
                  color: cardBlack,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: primaryPurple)),
              child: const Text("Cancer Invasion",
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.bold)),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: CircleAvatar(
              radius: 16,
              backgroundColor: cardBlack,
              // Optimized Network Image for Avatar
              backgroundImage: const NetworkImage(
                  'https://files.catbox.moe/jfb77m.jpg'),
            ),
            onPressed: _showAccountMenu,
          ),
          const SizedBox(width: 16),
        ],
      ),
      drawer: _buildDrawer(),
      body: FadeTransition(opacity: _animation, child: _selectedPage),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: cardBlack,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          boxShadow: [
            BoxShadow(
                color: primaryPurple.withOpacity(0.1),
                blurRadius: 20,
                offset: const Offset(0, -5)),
          ],
        ),
        child: ClipRRect(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          child: BottomNavigationBar(
            backgroundColor: cardBlack,
            selectedItemColor: primaryPink,
            unselectedItemColor: Colors.grey,
            currentIndex: _selectedTabIndex,
            onTap: _onTabTapped,
            type: BottomNavigationBarType.fixed,
            showSelectedLabels: true,
            showUnselectedLabels: true,
            items: const [
              BottomNavigationBarItem(
                icon: Icon(Icons.home_filled),
                label: "Home",
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.build_circle_outlined),
                activeIcon: Icon(Icons.build_circle),
                label: "Tools",
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.video_library_outlined),
                activeIcon: Icon(Icons.video_library),
                label: "Anime",
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    channel.sink.close(status.goingAway);
    _controller.dispose();
    _fadeController.dispose();
    super.dispose();
  }
}

// --- PARTICLE PAINTER FOR BACKGROUND ---
class _ParticlePainter extends CustomPainter {
  final Color color;
  final Random _random = Random();

  _ParticlePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = color;
    for (int i = 0; i < 20; i++) {
      double x = _random.nextDouble() * size.width;
      double y = _random.nextDouble() * size.height;
      double r = _random.nextDouble() * 3;
      canvas.drawCircle(Offset(x, y), r, paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _controller;

  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          if (mounted) setState(() {});
          _controller?.setLooping(true);
          _controller?.setVolume(0.0);
          _controller?.play();
        });
    }
  }

  bool _isVideo(String url) {
    return url.endsWith(".mp4") ||
        url.endsWith(".webm") ||
        url.endsWith(".mov") ||
        url.endsWith(".mkv");
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_controller != null && _controller!.value.isInitialized) {
        return AspectRatio(
          aspectRatio: _controller!.value.aspectRatio,
          child: VideoPlayer(_controller!),
        );
      } else {
        return const Center(
            child: CircularProgressIndicator(color: Colors.purpleAccent));
      }
    } else {
      // Image Handling for DPI
      return Image.network(
        widget.url,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(
          color: Colors.grey.shade900,
          child: const Icon(Icons.error, color: Colors.purpleAccent),
        ),
        loadingBuilder: (context, child, loadingProgress) {
          if (loadingProgress == null) return child;
          return Center(
            child: CircularProgressIndicator(
              value: loadingProgress.expectedTotalBytes != null
                  ? loadingProgress.cumulativeBytesLoaded /
                      loadingProgress.expectedTotalBytes!
                  : null,
              color: Colors.purpleAccent,
            ),
          );
        },
      );
    }
  }
}