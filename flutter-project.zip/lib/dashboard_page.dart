import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'dart:ui' show ImageFilter;

import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:xml/xml.dart';

import 'api_config.dart';
import 'nik_check.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'netrax_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'al_quran.dart';
import 'anime_home.dart';
import 'sellect_page.dart';
import 'thema.dart';
import 'dracin_page.dart';
import 'global_chat.dart';
import 'nebulagram_page.dart';

// ✅ FIX: import contact_page — ProfilePage ada di sini (butuh username)
import 'contact_page.dart' as contact; // <-- Gunakan alias contact
// ✅ ProfilePage dari contact_page; profile_page diimport untuk class lain kalau ada
import 'profile_page.dart' hide ProfilePage;

// ─── COLORS ────────────────────────────────────────────────────────────────────
const Color kBg      = Color(0xFF0A1A3F);
const Color kCard    = Color(0xFF11285C);
const Color kCardAlt = Color(0xFF173373);
const Color kBorder  = Color(0xFF2B4A8F);
const Color kCyan    = Color(0xFF00E5FF);
const Color kGreen   = Color(0xFF00E676);
const Color kPink    = Color(0xFFE91E8C);
const Color kOrange  = Color(0xFFFF6D00);
const Color kBlue    = Color(0xFF2979FF);
const Color kPurple  = Color(0xFF7C4DFF);
const Color kYellow  = Color(0xFFFFD600);
const Color kWhite   = Colors.white;
const Color kWhite54 = Colors.white54;
const Color kWhite24 = Colors.white24;

const Color kNavBlue       = Color(0xFF1D4ED8);
const Color kNavIconActive = Color(0xFF2563EB);

// ─── Nav Item ─────────────────────────────────────────────────────────────────
class _NavItem {
  final IconData icon;
  final String label;
  const _NavItem({required this.icon, required this.label});
}

// ─── Status Item Model ────────────────────────────────────────────────────────
class _StatusItem {
  final String id;
  final String name;
  final String avatarUrl;
  final bool isMe;
  final bool hasNewStatus;

  _StatusItem({
    required this.id,
    required this.name,
    this.avatarUrl = '',
    this.isMe = false,
    this.hasNewStatus = true,
  });
}

// ─── News Model ───────────────────────────────────────────────────────────────
class _NewsItem {
  final String title;
  final String description;
  final String imageUrl;
  final String source;
  final String timeAgo;
  final String url;

  _NewsItem({
    required this.title,
    required this.description,
    required this.imageUrl,
    required this.source,
    required this.timeAgo,
    required this.url,
  });
}

// ─── Weather Service ───────────────────────────────────────────────────────────
class WeatherService {
  static const String apiKey = 'test';
  static const String baseUrl = 'http://api.agromonitoring.com/agro/1.0';

  static final Map<String, Map<String, double>> _cityCoords = {
    'Surabaya': {'lat': -7.2575, 'lon': 112.7521},
    'Jakarta': {'lat': -6.2088, 'lon': 106.8456},
    'Bandung': {'lat': -6.9175, 'lon': 107.6191},
    'Medan': {'lat': 3.5952, 'lon': 98.6722},
    'Makassar': {'lat': -5.1477, 'lon': 119.4327},
    'Semarang': {'lat': -6.9667, 'lon': 110.4167},
    'Yogyakarta': {'lat': -7.7971, 'lon': 110.3688},
    'Malang': {'lat': -7.9797, 'lon': 112.6304},
    'Denpasar': {'lat': -8.6704, 'lon': 115.2126},
    'Palembang': {'lat': -2.9909, 'lon': 104.7566},
  };

  static Future<Map<String, dynamic>> fetchWeather(String city) async {
    try {
      final coords = _getCityCoordinates(city);
      if (coords == null) return {};
      final uri = Uri.parse(
          '$baseUrl/weather?lat=${coords['lat']}&lon=${coords['lon']}&appid=$apiKey');
      final res = await http.get(uri).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return {};
  }

  static Map<String, double>? _getCityCoordinates(String city) {
    if (_cityCoords.containsKey(city)) return _cityCoords[city];
    final lowerCity = city.toLowerCase();
    for (final entry in _cityCoords.entries) {
      if (entry.key.toLowerCase() == lowerCity) return entry.value;
    }
    return _cityCoords['Surabaya'];
  }

  static bool isGoodWeather(String weatherMain) {
    final goodWeathers = ['Clear', 'Clouds', 'Haze', 'Mist', 'Fog', 'Sunny', 'Fair'];
    return goodWeathers.contains(weatherMain);
  }

  static IconData getWeatherIcon(String weatherMain, bool isGood) {
    if (isGood) {
      switch (weatherMain) {
        case 'Clear':
        case 'Sunny':
          return Icons.wb_sunny_rounded;
        case 'Clouds':
        case 'Haze':
        case 'Mist':
        case 'Fog':
          return Icons.cloud_rounded;
        default:
          return Icons.wb_sunny_rounded;
      }
    } else {
      switch (weatherMain) {
        case 'Rain':
        case 'Drizzle':
          return Icons.grain_rounded;
        case 'Thunderstorm':
        case 'Storm':
          return Icons.flash_on_rounded;
        default:
          return Icons.cloud_rounded;
      }
    }
  }

  static Color getWeatherColor(String weatherMain, bool isGood) {
    if (isGood) {
      switch (weatherMain) {
        case 'Clear':
        case 'Sunny':
          return const Color(0xFFFFD600);
        case 'Clouds':
          return const Color(0xFFB0BEC5);
        default:
          return const Color(0xFFFFD600);
      }
    } else {
      return const Color(0xFF1A237E);
    }
  }

  static Map<String, dynamic> parseWeatherResponse(Map<String, dynamic> data) {
    final weather = data['weather'] ?? [];
    final main = weather.isNotEmpty ? weather[0]['main'] ?? 'Clear' : 'Clear';
    double temp = data['main']?['temp'] ?? 0.0;
    if (temp > 100) temp = temp - 273.15;

    return {
      'main': main,
      'temp': temp,
      'description': weather.isNotEmpty ? weather[0]['description'] ?? '' : '',
    };
  }
}

// ─── News Service — RSS ANTARA ────────────────────────────
class NewsService {
  static const String rssUrl = 'https://www.antaranews.com/rss/terkini.xml';

  static Future<List<_NewsItem>> fetchNews() async {
    try {
      final res = await http.get(Uri.parse(rssUrl))
          .timeout(const Duration(seconds: 15));

      if (res.statusCode == 200) {
        final doc = XmlDocument.parse(res.body);
        final items = doc.findAllElements('item');
        final list = <_NewsItem>[];
        for (final item in items.take(10)) {
          final title = item.findElements('title').firstOrNull?.innerText ?? '';
          final desc = item.findElements('description').firstOrNull?.innerText ?? '';
          final link = item.findElements('link').firstOrNull?.innerText ?? '';
          final pubDate = item.findElements('pubDate').firstOrNull?.innerText ?? '';
          final img = _extractImageFromDesc(desc);
          final cleanDesc = desc.replaceAll(RegExp(r'<[^>]*>'), '').trim();

          list.add(_NewsItem(
            title: title.isEmpty ? 'No Title' : title,
            description: cleanDesc,
            imageUrl: img,
            source: 'Antara News',
            timeAgo: _timeAgoRss(pubDate),
            url: link,
          ));
        }
        if (list.isNotEmpty) return list;
      }
    } catch (_) {}
    return _fallbackNews();
  }

  static String _extractImageFromDesc(String desc) {
    final match = RegExp(r'src="([^"]+)"').firstMatch(desc);
    return match?.group(1) ?? '';
  }

  static String _timeAgoRss(String pubDate) {
    try {
      final dt = DateTime.parse(pubDate).toLocal();
      final diff = DateTime.now().difference(dt);
      if (diff.inMinutes < 60) return '${diff.inMinutes} menit lalu';
      if (diff.inHours < 24) return '${diff.inHours} jam lalu';
      return '${diff.inDays} hari lalu';
    } catch (_) {
      return 'baru saja';
    }
  }

  static List<_NewsItem> _fallbackNews() => [
        _NewsItem(
          title: 'Mentan Amran tegaskan komitmen pemerintah berantas mafia pangan',
          description:
              'ANTARA - Menteri Pertanian Andi Amran Sulaiman menegaskan komitmen pemerintah untuk memberantas mafia pangan.',
          imageUrl: '',
          source: 'Antara News',
          timeAgo: '9 jam lalu',
          url: 'https://www.antaranews.com',
        ),
        _NewsItem(
          title: 'Pemerintah percepat program swasembada pangan nasional',
          description:
              'Program swasembada pangan terus digenjot di berbagai daerah untuk mencapai target nasional.',
          imageUrl: '',
          source: 'Antara News',
          timeAgo: '12 jam lalu',
          url: 'https://www.antaranews.com',
        ),
        _NewsItem(
          title: 'Harga pangan stabil jelang akhir tahun',
          description:
              'Pemerintah memastikan stok dan harga pangan stabil menjelang akhir tahun.',
          imageUrl: '',
          source: 'Antara News',
          timeAgo: '1 hari lalu',
          url: 'https://www.antaranews.com',
        ),
      ];
}

// ─── Role helpers ─────────────────────────────────────────────────────────────
IconData _roleIcon(String role) {
  switch (role.toLowerCase()) {
    case 'owner':
      return Icons.workspace_premium_rounded;
    case 'admin':
      return Icons.admin_panel_settings_rounded;
    case 'reseller':
      return Icons.storefront_rounded;
    case 'vip':
      return Icons.star_rounded;
    default:
      return Icons.person_rounded;
  }
}

// ─── GRID PATTERN PAINTER ─────────────────────────────────────────────────────
class _GridPatternPainter extends CustomPainter {
  final Color gridColor;
  final Color lineColor;
  final double spacing;
  const _GridPatternPainter({
    required this.gridColor,
    required this.lineColor,
    required this.spacing,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paintGrid = Paint()
      ..color = gridColor
      ..strokeWidth = 0.8
      ..style = PaintingStyle.stroke;
    final paintLines = Paint()
      ..color = lineColor
      ..strokeWidth = 0.4
      ..style = PaintingStyle.stroke;
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paintGrid);
    }
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paintGrid);
    }
    for (double x = -size.height;
        x < size.width + size.height;
        x += spacing * 2) {
      canvas.drawLine(Offset(x, 0), Offset(x + size.height, size.height),
          paintLines);
    }
    for (double x = -size.height;
        x < size.width + size.height;
        x += spacing * 2) {
      canvas.drawLine(Offset(x, size.height), Offset(x + size.height, 0),
          paintLines);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter _) => false;
}

// ─── NAV NOTCH PAINTER ────────────────────────────────────────────────────────
class _NavNotchPainter extends CustomPainter {
  final double centerX;
  final double notchRadius;
  final Color color;

  _NavNotchPainter({
    required this.centerX,
    required this.notchRadius,
    required this.color,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.fill;

    final path = Path();

    path.moveTo(0, 0);
    path.lineTo(centerX - notchRadius - 12, 0);

    path.quadraticBezierTo(
      centerX - notchRadius, 0,
      centerX - notchRadius + 6, 10,
    );

    path.arcToPoint(
      Offset(centerX + notchRadius - 6, 10),
      radius: Radius.circular(notchRadius),
      clockwise: false,
    );

    path.quadraticBezierTo(
      centerX + notchRadius, 0,
      centerX + notchRadius + 12, 0,
    );

    path.lineTo(size.width, 0);
    path.lineTo(size.width, size.height);
    path.lineTo(0, size.height);
    path.close();

    canvas.drawShadow(path, Colors.black.withValues(alpha: 0.3), 8, true);
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant _NavNotchPainter old) =>
      old.centerX != centerX ||
      old.notchRadius != notchRadius ||
      old.color != color;
}

// ─── Embedded Wrapper ─────────────────────────────────────────────────────────
class _EmbeddedPage extends StatelessWidget {
  final Widget child;
  const _EmbeddedPage({required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(color: Colors.transparent, child: child);
  }
}

// ─── Dashboard Page ───────────────────────────────────────────────────────────
class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  late String sessionKey, username, password, role, expiredDate;
  late List<Map<String, dynamic>> listBug, listDoos;
  late List<dynamic> newsList;

  late WebSocketChannel channel;
  String androidId = 'unknown';
  String uidFromPrefs = '-'; // <--- STATE BARU UNTUK UID
  File? _profileImage;
  VideoPlayerController? _menuVideoCtrl;

  int _navIndex = 0;
  int onlineUsers = 0;
  int activeConns = 0;

  List<_StatusItem> _statusList = [
    _StatusItem(id: '1', name: 'partiganteng', hasNewStatus: true),
    _StatusItem(id: '2', name: 'Zhaa', hasNewStatus: true),
    _StatusItem(id: '3', name: 'angga7', hasNewStatus: true),
    _StatusItem(id: '4', name: 'wildanx', hasNewStatus: true),
    _StatusItem(id: '5', name: 'Jancikteam', hasNewStatus: true),
    _StatusItem(id: '6', name: 'Damzy', hasNewStatus: true),
  ];

  List<_NewsItem> _newsItems = [];
  bool _newsLoading = true;
  int _newsPageIndex = 0;
  late PageController _newsPageController;

  String _weatherCity = 'Surabaya';
  String _weatherMain = 'Clear';
  double _weatherTemp = 0;
  bool _weatherLoading = true;
  bool _weatherIsGood = true;

  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  Timer? _statsTimer;

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    _fadeCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 700));
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _fadeCtrl.forward();

    _pulseCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.85, end: 1.0).animate(
        CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _newsPageController = PageController(viewportFraction: 0.92);

    _initAndroidId();
    _loadProfileImage();
    _loadUidFromPrefs(); // <--- PANGGIL FUNGSI INI
    _initMenuVideo();
    _detectLocationAndFetchWeather();
    _loadNews();
  }

  // ── FUNGSI BARU UNTUK MENGAMBIL UID DARI SHARED PREFERENCES ──
  Future<void> _loadUidFromPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    if (mounted) {
      setState(() {
        uidFromPrefs = prefs.getString('uid') ?? '-';
      });
    }
  }

  @override
  void dispose() {
    _statsTimer?.cancel();
    try {
      channel.sink.close(status.goingAway);
    } catch (_) {}
    _fadeCtrl.dispose();
    _pulseCtrl.dispose();
    _menuVideoCtrl?.dispose();
    _newsPageController.dispose();
    super.dispose();
  }

  Future<void> _loadNews() async {
    setState(() => _newsLoading = true);
    final items = await NewsService.fetchNews();
    if (!mounted) return;
    setState(() {
      _newsItems = items;
      _newsLoading = false;
    });
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final path = prefs.getString('profile_image_$username');
    if (path != null && path.isNotEmpty && mounted) {
      setState(() => _profileImage = File(path));
    }
  }

  void _initMenuVideo() {
    _menuVideoCtrl = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        if (mounted) setState(() {});
        _menuVideoCtrl?.setLooping(true);
        _menuVideoCtrl?.setVolume(0);
        _menuVideoCtrl?.play();
      });
  }

  Future<void> _initAndroidId() async {
    final info = await DeviceInfoPlugin().androidInfo;
    androidId = info.id;
    _connectWS();
  }

  void _connectWS() {
    try {
      channel = WebSocketChannel.connect(
          Uri.parse('ws://yefan.myserverr.web.id:2111'));

      channel.sink.add(jsonEncode({
        'type': 'validate',
        'key': sessionKey,
        'androidId': androidId,
      }));

      channel.stream.listen((event) {
        final data = jsonDecode(event);

        if (data['type'] == 'myInfo' && data['valid'] == true && mounted) {
          channel.sink.add(jsonEncode({'type': 'stats'}));
        }

        if (data['type'] == 'stats' && mounted) {
          setState(() {
            onlineUsers = data['onlineUsers'] ?? 0;
            activeConns = data['activeConnections'] ?? 0;
          });
        }

        if (data['type'] == 'myInfo' && data['valid'] == false && mounted) {
          _handleInvalidSession(data['reason'] ?? 'Session invalid');
        }

        if (data['type'] == 'forceLogout' && mounted) {
          _handleInvalidSession(data['reason'] ?? 'Logged out');
        }
      }, onError: (_) {
        Future.delayed(const Duration(seconds: 3), () {
          if (mounted) _connectWS();
        });
      });

      _statsTimer?.cancel();
      _statsTimer = Timer.periodic(const Duration(seconds: 5), (_) {
        try {
          channel.sink.add(jsonEncode({'type': 'stats'}));
        } catch (_) {}
      });
    } catch (e) {
      Future.delayed(const Duration(seconds: 3), () {
        if (mounted) _connectWS();
      });
    }
  }

  Future<void> _openUrl(String url) async {
    if (url.isEmpty) return;
    try {
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } catch (_) {}
  }

  Future<void> _fetchWeather() async {
    if (!mounted) return;
    setState(() => _weatherLoading = true);
    final data = await WeatherService.fetchWeather(_weatherCity);
    if (!mounted) return;

    if (data.isNotEmpty) {
      final parsed = WeatherService.parseWeatherResponse(data);
      final main = parsed['main'] ?? 'Clear';
      final temp = parsed['temp'] ?? 0.0;
      final isGood = WeatherService.isGoodWeather(main);

      setState(() {
        _weatherMain = main;
        _weatherTemp = temp;
        _weatherIsGood = isGood;
        _weatherLoading = false;
      });
    } else {
      setState(() {
        _weatherMain = 'Clear';
        _weatherTemp = 28.0;
        _weatherIsGood = true;
        _weatherLoading = false;
      });
    }
  }

  Future<void> _detectLocationAndFetchWeather() async {
    if (!mounted) return;
    setState(() => _weatherLoading = true);

    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        if (mounted) {
          setState(() {
            _weatherLoading = false;
            _weatherCity = 'Surabaya';
          });
          await _fetchWeather();
        }
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          if (mounted) {
            setState(() {
              _weatherLoading = false;
              _weatherCity = 'Surabaya';
            });
            await _fetchWeather();
          }
          return;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        if (mounted) {
          setState(() {
            _weatherLoading = false;
            _weatherCity = 'Surabaya';
          });
          await _fetchWeather();
        }
        return;
      }

      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.medium,
      );

      final placemarks = await placemarkFromCoordinates(
        position.latitude,
        position.longitude,
      );

      if (placemarks.isNotEmpty && mounted) {
        final place = placemarks.first;
        String city = 'Surabaya';

        if (place.subAdministrativeArea?.isNotEmpty == true) {
          city = place.subAdministrativeArea!;
        } else if (place.locality?.isNotEmpty == true) {
          city = place.locality!;
        }

        setState(() {
          _weatherCity = city;
          _weatherLoading = false;
        });

        await _fetchWeather();
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _weatherLoading = false;
          _weatherCity = 'Surabaya';
        });
        await _fetchWeather();
      }
    }
  }

  void _openNebulagram() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => NebulagramPage(
          sessionKey: sessionKey,
          username: username,
          role: role,
        ),
      ),
    );
  }

  void _addStatus() {
    _openNebulagram();
  }

  void _viewStatus(_StatusItem item) {
    _openNebulagram();
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: kCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text('⚠️ Session Expired',
            style: TextStyle(color: kWhite)),
        content: Text(message, style: const TextStyle(color: kWhite54)),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                (_) => false),
            child: const Text('OK', style: TextStyle(color: kCyan)),
          ),
        ],
      ),
    );
  }

  void _onNavTap(int index) {
    if (_navIndex == index) return;
    setState(() => _navIndex = index);
  }

  void _onDrawerNav(int index) {
    Widget page;
    switch (index) {
      case 1:
        page = SellerPage(keyToken: sessionKey);
        break;
      case 2:
        page = AdminPage(sessionKey: sessionKey);
        break;
      case 3:
        page = OwnerPage(sessionKey: sessionKey, username: username);
        break;
      default:
        return;
    }
    Navigator.pop(context);
    Navigator.push(context, MaterialPageRoute(builder: (_) => page))
        .then((_) {
      if (mounted) setState(() => _navIndex = 0);
    });
  }

  Widget _buildCurrentPage() {
    switch (_navIndex) {
      case 1:
        return NetraxPage(
          username: username,
          password: password,
          sessionKey: sessionKey,
          role: role,
          expiredDate: expiredDate,
          listPayload: listBug,
        );
      case 2:
        // ✅ SellectPage2 butuh sessionKey
        return _EmbeddedPage(
          child: SellectPage2(sessionKey: sessionKey),
        );
      case 3:
        return _EmbeddedPage(
          child: ToolsPage(
            sessionKey: sessionKey,
            userRole: role,
            listDoos: listDoos,
          ),
        );
      case 4:
        return const _EmbeddedPage(child: ThemaPage());
      case 0:
      default:
        return _buildHomePage();
    }
  }

  Widget _buildHomePage() {
    return FadeTransition(
      opacity: _fadeAnim,
      child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildTopHeader(),

            const SizedBox(height: 10),
            Center(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: 30,
                    height: 2,
                    color: Colors.white.withValues(alpha: 0.9),
                  ),
                  const SizedBox(width: 6),
                  const Text('☁️', style: TextStyle(fontSize: 18)),
                  const SizedBox(width: 8),
                  const Text(
                    'S Y A M',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron',
                      letterSpacing: 3,
                      shadows: [
                        Shadow(
                          color: Colors.black54,
                          blurRadius: 8,
                          offset: Offset(0, 2),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  const Text('☁️', style: TextStyle(fontSize: 18)),
                  const SizedBox(width: 6),
                  Container(
                    width: 30,
                    height: 2,
                    color: Colors.white.withValues(alpha: 0.9),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),

            _buildStatusSection(),
            const SizedBox(height: 14),
            _buildWelcomeCard(),
            const SizedBox(height: 14),
            _buildQuickActionsSection(),
            const SizedBox(height: 14),
            _buildNewsSection(),
            const SizedBox(height: 14),
            _buildConnectSection(),
            const SizedBox(height: 24),
            Center(
              child: Text('..',
                  style: TextStyle(
                    color: kWhite.withValues(alpha: 0.12),
                    fontSize: 13,
                    letterSpacing: 4,
                    fontFamily: 'Orbitron',
                  )),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildTopHeader() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Container(
          height: 190,
          width: double.infinity,
          color: const Color(0xFF080C12),
          child: Stack(
            fit: StackFit.expand,
            children: [
              Image.asset(
                'assets/images/kiw.jpg',
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Color(0xFF0A0F1E), Color(0xFF1A1A2E)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                ),
              ),
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.black.withValues(alpha: 0.6),
                      Colors.transparent,
                      Colors.black.withValues(alpha: 0.3),
                    ],
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatusSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.black.withValues(alpha: 0.55),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: Colors.white.withValues(alpha: 0.15),
            width: 1,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                GestureDetector(
                  onTap: _openNebulagram,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.6),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: Colors.white.withValues(alpha: 0.2),
                      ),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.auto_stories,
                            color: Colors.white, size: 16),
                        SizedBox(width: 6),
                        Text(
                          'STATUS SYAMGRAM',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w900,
                            fontSize: 12,
                            fontFamily: 'Orbitron',
                            letterSpacing: 1,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: _openNebulagram,
                  child: const Icon(Icons.more_horiz, color: Colors.white70),
                ),
              ],
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 100,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                physics: const BouncingScrollPhysics(),
                itemCount: _statusList.length + 1,
                itemBuilder: (context, index) {
                  if (index == 0) {
                    return GestureDetector(
                      onTap: _addStatus,
                      child: Padding(
                        padding: const EdgeInsets.only(right: 16),
                        child: Column(
                          children: [
                            Container(
                              width: 60,
                              height: 60,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.white.withValues(alpha: 0.15),
                                border: Border.all(
                                    color: Colors.white, width: 2),
                              ),
                              child: const Icon(Icons.add,
                                  color: Colors.white, size: 30),
                            ),
                            const SizedBox(height: 6),
                            const Text('Buat',
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 11,
                                    fontWeight: FontWeight.bold)),
                          ],
                        ),
                      ),
                    );
                  }
                  final item = _statusList[index - 1];
                  return GestureDetector(
                    onTap: () => _viewStatus(item),
                    child: Padding(
                      padding: const EdgeInsets.only(right: 16),
                      child: Column(
                        children: [
                          Container(
                            width: 60,
                            height: 60,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.white,
                              border: Border.all(
                                color: item.hasNewStatus
                                    ? const Color(0xFFE91E8C)
                                    : Colors.white,
                                width: 3,
                              ),
                            ),
                            child: ClipOval(
                              child: item.avatarUrl.isNotEmpty
                                  ? Image.network(item.avatarUrl,
                                      fit: BoxFit.cover,
                                      errorBuilder: (_, __, ___) => Center(
                                            child: Text(
                                              item.name.isNotEmpty
                                                  ? item.name[0].toUpperCase()
                                                  : '?',
                                              style: const TextStyle(
                                                  color: Color(0xFF2563EB),
                                                  fontSize: 24,
                                                  fontWeight:
                                                      FontWeight.bold),
                                            ),
                                          ))
                                  : Center(
                                      child: Text(
                                        item.name.isNotEmpty
                                            ? item.name[0].toUpperCase()
                                            : '?',
                                        style: const TextStyle(
                                            color: Color(0xFF2563EB),
                                            fontSize: 24,
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ),
                            ),
                          ),
                          const SizedBox(height: 6),
                          SizedBox(
                            width: 64,
                            child: Text(
                              item.name,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _formatExpired(String raw) {
    final text = raw.trim();
    if (text.isEmpty) return '-';
    final parsed = DateTime.tryParse(text);
    if (parsed != null) {
      final d = parsed.day.toString().padLeft(2, '0');
      final m = parsed.month.toString().padLeft(2, '0');
      return '$d/$m/${parsed.year}';
    }
    return text.length > 10 ? text.substring(0, 10) : text;
  }

  IconData _welcomeRoleIcon() {
    if (role.toLowerCase() == 'reseller') return Icons.emoji_events_outlined;
    return _roleIcon(role);
  }

  Widget _buildWelcomeCard() {
    final String roleText = role.trim().isEmpty ? 'USER' : role.toUpperCase();
    final IconData weatherIcon =
        WeatherService.getWeatherIcon(_weatherMain, _weatherIsGood);
    final Color weatherColor =
        WeatherService.getWeatherColor(_weatherMain, _weatherIsGood);
    final String tempText =
        _weatherLoading ? '--' : '${_weatherTemp.round()}°C';

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: Colors.white.withValues(alpha: 0.3),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.3),
              blurRadius: 20,
              spreadRadius: 2,
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: Stack(
            children: [
              Positioned.fill(
                child: Image.asset(
                  'assets/images/Syam.jpg',
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) =>
                      Container(color: const Color(0xFF1C2541)),
                ),
              ),
              Positioned.fill(
                child: Container(
                  color: Colors.black.withValues(alpha: 0.35),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 18, 16, 18),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _welcomeAvatar(),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const SizedBox(height: 4),
                              const Text('Ahlan Wa Sahlan,',
                                  style: TextStyle(
                                      color: Colors.white70,
                                      fontSize: 11,
                                      fontWeight: FontWeight.w600,
                                      fontFamily: 'Orbitron',
                                      letterSpacing: 0.5)),
                              const SizedBox(height: 4),
                              Row(
                                children: [
                                  Flexible(
                                    child: Text(username,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                            color: Colors.white,
                                            fontSize: 20,
                                            fontWeight: FontWeight.w800,
                                            fontFamily: 'Orbitron',
                                            shadows: [
                                              Shadow(
                                                color: Colors.black54,
                                                blurRadius: 6,
                                              ),
                                            ])),
                                  ),
                                  const SizedBox(width: 6),
                                  const Icon(Icons.star_rounded,
                                      color: Color(0xFFFFD600), size: 22),
                                ],
                              ),
                              const SizedBox(height: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 14, vertical: 9),
                                decoration: BoxDecoration(
                                  color: Colors.white.withValues(alpha: 0.2),
                                  borderRadius: BorderRadius.circular(30),
                                  border: Border.all(
                                    color:
                                        Colors.white.withValues(alpha: 0.3),
                                  ),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Icon(_welcomeRoleIcon(),
                                        color: Colors.white, size: 15),
                                    const SizedBox(width: 8),
                                    Flexible(
                                      child: Text(roleText,
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: const TextStyle(
                                              color: Colors.white,
                                              fontSize: 11,
                                              fontWeight: FontWeight.w700,
                                              fontFamily: 'Orbitron',
                                              letterSpacing: 1.4)),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 8),
                        Padding(
                          padding: const EdgeInsets.only(top: 14),
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 14, vertical: 10),
                            decoration: BoxDecoration(
                              color: Colors.white.withValues(alpha: 0.2),
                              borderRadius: BorderRadius.circular(30),
                              border: Border.all(
                                color: Colors.white.withValues(alpha: 0.3),
                              ),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(weatherIcon,
                                    color: weatherColor, size: 20),
                                const SizedBox(width: 6),
                                Text(tempText,
                                    style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontFamily: 'Orbitron',
                                        fontSize: 12)),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 34,
                          height: 6,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(3),
                          ),
                        ),
                        const SizedBox(width: 6),
                        Container(
                          width: 6,
                          height: 6,
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.4),
                            shape: BoxShape.circle,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),
                    Row(
                      children: [
                        Expanded(
                            child: _glassVpsBox(
                                title: 'VPS SYAM',
                                ram: '10.3GB/35.2GB',
                                cpu: '5.43')),
                        const SizedBox(width: 10),
                        Expanded(child: _glassVpsBox(title: 'VPS RAT')),
                      ],
                    ),
                    const SizedBox(height: 18),
                    Container(
                        height: 1.5,
                        color: Colors.white.withValues(alpha: 0.15)),
                    const SizedBox(height: 16),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _glassStatItem(
                          icon: Icons.people_alt_rounded,
                          value: '$onlineUsers',
                          label: 'Online Users',
                          topOffset: 0,
                          showDot: true,
                          footer: ScaleTransition(
                            scale: _pulseAnim,
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 2),
                              decoration: BoxDecoration(
                                color: const Color(0xFF22C55E)
                                    .withValues(alpha: 0.85),
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(
                                    color: Colors.white
                                        .withValues(alpha: 0.35)),
                              ),
                              child: const Text('LIVE',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 9,
                                      fontWeight: FontWeight.bold)),
                            ),
                          ),
                        ),
                        _glassStatItem(
                          icon: Icons.link_rounded,
                          value: '$activeConns',
                          label: 'Sender',
                          topOffset: 12,
                        ),
                        _glassStatItem(
                          icon: Icons.calendar_today_rounded,
                          value: _formatExpired(expiredDate),
                          label: 'Expired',
                          topOffset: 6,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _welcomeAvatar() {
    const Color ring = Color(0xFF2979FF);
    return ScaleTransition(
      scale: _pulseAnim,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: 68,
            height: 68,
            child: Stack(
              clipBehavior: Clip.none,
              children: [
                Container(
                  width: 68,
                  height: 68,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: ring, width: 3),
                    boxShadow: [
                      BoxShadow(
                        color: ring.withValues(alpha: 0.6),
                        blurRadius: 10,
                        spreadRadius: 1,
                      ),
                    ],
                    image: const DecorationImage(
                      image: AssetImage('assets/images/Avatar.jpg'),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                Positioned(
                  right: 0,
                  bottom: 0,
                  child: Container(
                    width: 16,
                    height: 16,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: const Color(0xFF22C55E),
                      border:
                          Border.all(color: const Color(0xFF1F2937), width: 2),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 4),
          Image.asset(
            'assets/images/gantuangan.png',
            width: 60,
            height: 20,
            fit: BoxFit.contain,
            errorBuilder: (_, __, ___) => const SizedBox.shrink(),
          ),
        ],
      ),
    );
  }

  Widget _glassVpsBox({
    required String title,
    String? ram,
    String? cpu,
  }) {
    return Container(
      constraints: const BoxConstraints(minHeight: 78),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(
            color: Colors.white.withValues(alpha: 0.3), width: 1.2),
      ),
      child: Row(
        children: [
          const Text('🗳️', style: TextStyle(fontSize: 24)),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                FittedBox(
                  fit: BoxFit.scaleDown,
                  alignment: Alignment.centerLeft,
                  child: Text(title,
                      style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Orbitron',
                          letterSpacing: 0.8,
                          fontSize: 11)),
                ),
                if (ram != null) ...[
                  const SizedBox(height: 4),
                  FittedBox(
                    fit: BoxFit.scaleDown,
                    alignment: Alignment.centerLeft,
                    child: Text('RAM: $ram',
                        style: const TextStyle(
                            color: Colors.white70,
                            fontSize: 10,
                            fontWeight: FontWeight.w600)),
                  ),
                ],
                if (cpu != null)
                  FittedBox(
                    fit: BoxFit.scaleDown,
                    alignment: Alignment.centerLeft,
                    child: Text('CPU: $cpu',
                        style: const TextStyle(
                            color: Colors.white70,
                            fontSize: 10,
                            fontWeight: FontWeight.w600)),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _glassStatItem({
    required IconData icon,
    required String value,
    required String label,
    double topOffset = 0,
    bool showDot = false,
    Widget? footer,
  }) {
    return Padding(
      padding: EdgeInsets.only(top: topOffset),
      child: SizedBox(
        width: 92,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Stack(
              clipBehavior: Clip.none,
              alignment: Alignment.center,
              children: [
                ClipOval(
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
                    child: Container(
                      width: 66,
                      height: 66,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.white.withValues(alpha: 0.15),
                        border: Border.all(
                            color: Colors.white.withValues(alpha: 0.3),
                            width: 1.4),
                      ),
                      child: Icon(icon, color: Colors.white, size: 32),
                    ),
                  ),
                ),
                if (showDot)
                  Positioned(
                    top: 0,
                    right: 2,
                    child: ScaleTransition(
                      scale: _pulseAnim,
                      child: Container(
                        width: 14,
                        height: 14,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: const Color(0xFF22C55E),
                          border: Border.all(color: Colors.white, width: 1.5),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 8),
            FittedBox(
              fit: BoxFit.scaleDown,
              child: Text(value,
                  style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      fontFamily: 'Orbitron')),
            ),
            const SizedBox(height: 2),
            FittedBox(
              fit: BoxFit.scaleDown,
              child: Text(label,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      color: Colors.white70,
                      fontSize: 11,
                      fontWeight: FontWeight.bold)),
            ),
            if (footer != null) ...[
              const SizedBox(height: 4),
              footer,
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildQuickActionsSection() {
    final actions = [
      _QuickActionData(
        icon: FontAwesomeIcons.bookOpen,
        bgIcon: FontAwesomeIcons.bookOpen,
        title: 'MANAGE SENDER',
        subtitle: '',
        gradient: [const Color(0xFF0D47A1), const Color(0xFF1976D2)],
        glowColor: const Color(0xFF00B0FF),
        onTap: () => Navigator.push(
          context,
          _slideRoute(BugSenderPage(
              sessionKey: sessionKey, username: username, role: role)),
        ),
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.film,
        bgIcon: FontAwesomeIcons.film,
        title: 'DRACIN',
        subtitle: '',
        gradient: [const Color(0xFF6A1B9A), const Color(0xFF9C27B0)],
        glowColor: const Color(0xFFE040FB),
        onTap: () => Navigator.push(
          context,
          _slideRoute(const DracinPage()),
        ),
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.comments,
        bgIcon: FontAwesomeIcons.comments,
        title: 'GLOBAL',
        subtitle: '',
        gradient: [const Color(0xFF1B5E20), const Color(0xFF2E7D32)],
        glowColor: const Color(0xFF69F0AE),
        onTap: () => Navigator.push(
          context,
          _slideRoute(GlobalChatPage(
            sessionKey: sessionKey,
            username: username,
            role: role,
          )),
        ),
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.bookQuran,
        bgIcon: FontAwesomeIcons.bookQuran,
        title: 'AL QUR\'AN',
        subtitle: '',
        gradient: [const Color(0xFFAD1457), const Color(0xFFE91E63)],
        glowColor: const Color(0xFFFF80AB),
        onTap: () => Navigator.push(
          context,
          _slideRoute(const AlQuranPage()),
        ),
      ),
    ];

    return Column(
      children: [
        const SizedBox(height: 16),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 14,
              mainAxisSpacing: 14,
              childAspectRatio: 1.6,
            ),
            itemCount: actions.length,
            itemBuilder: (context, index) {
              return _buildQuickActionCard(actions[index]);
            },
          ),
        ),
      ],
    );
  }

  Widget _buildQuickActionCard(_QuickActionData action) {
    return GestureDetector(
      onTap: action.onTap,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          gradient: LinearGradient(
            colors: action.gradient,
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          border: Border.all(
            color: action.glowColor,
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: action.glowColor.withValues(alpha: 0.3),
              blurRadius: 12,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                action.icon,
                color: Colors.white,
                size: 42,
              ),
              const SizedBox(height: 12),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6),
                child: Text(
                  action.title,
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                    fontSize: 12,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNewsSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(22),
        child: Stack(
          children: [
            Positioned.fill(
              child: Image.asset(
                'assets/images/connect_bg.jpg',
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) =>
                    Container(color: const Color(0xFF0F1B33)),
              ),
            ),
            Positioned.fill(
              child: Container(
                color: const Color(0xFF0A0F1E).withValues(alpha: 0.78),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          color: const Color(0xFFFF6D00)
                              .withValues(alpha: 0.18),
                          border: Border.all(
                              color: const Color(0xFFFF6D00)
                                  .withValues(alpha: 0.5)),
                        ),
                        child: const Center(
                          child: Icon(Icons.article_rounded,
                              color: Color(0xFFFF6D00), size: 22),
                        ),
                      ),
                      const SizedBox(width: 12),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('BERITA TERKINI',
                                style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 15,
                                    fontFamily: 'Orbitron',
                                    letterSpacing: 1.2)),
                            Text('Sumber: Antara News',
                                style: TextStyle(
                                    color: Colors.white54, fontSize: 11)),
                          ],
                        ),
                      ),
                      GestureDetector(
                        onTap: _loadNews,
                        child: Container(
                          width: 38,
                          height: 38,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: const Color(0xFFFF6D00)
                                .withValues(alpha: 0.18),
                            border: Border.all(
                                color: const Color(0xFFFF6D00)
                                    .withValues(alpha: 0.5)),
                          ),
                          child: const Icon(Icons.refresh_rounded,
                              color: Color(0xFFFF6D00), size: 20),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),

                  if (_newsLoading)
                    const SizedBox(
                      height: 240,
                      child: Center(
                        child: CircularProgressIndicator(
                            color: Color(0xFFFF6D00), strokeWidth: 2),
                      ),
                    )
                  else if (_newsItems.isEmpty)
                    Container(
                      height: 200,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16),
                        color: Colors.white.withValues(alpha: 0.05),
                      ),
                      child: const Center(
                        child: Text('Tidak ada berita',
                            style: TextStyle(color: Colors.white54)),
                      ),
                    )
                  else
                    SizedBox(
                      height: 260,
                      child: PageView.builder(
                        controller: _newsPageController,
                        onPageChanged: (i) =>
                            setState(() => _newsPageIndex = i),
                        itemCount: _newsItems.length,
                        itemBuilder: (ctx, i) =>
                            _buildNewsCard(_newsItems[i], i + 1),
                      ),
                    ),

                  if (!_newsLoading && _newsItems.isNotEmpty) ...[
                    const SizedBox(height: 12),
                    Center(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: List.generate(_newsItems.length, (i) {
                          final active = i == _newsPageIndex;
                          return AnimatedContainer(
                            duration: const Duration(milliseconds: 300),
                            margin: const EdgeInsets.symmetric(horizontal: 3),
                            width: active ? 22 : 6,
                            height: 6,
                            decoration: BoxDecoration(
                              color: active
                                  ? const Color(0xFFFF6D00)
                                  : Colors.white24,
                              borderRadius: BorderRadius.circular(3),
                            ),
                          );
                        }),
                      ),
                    ),
                  ],

                  const SizedBox(height: 14),

                  GestureDetector(
                    onTap: () => _openUrl('https://www.antaranews.com'),
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                            color: const Color(0xFFFF6D00)
                                .withValues(alpha: 0.6),
                            width: 1.5),
                        color: const Color(0xFFFF6D00)
                            .withValues(alpha: 0.08),
                      ),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.list_alt_rounded,
                              color: Color(0xFFFF6D00), size: 18),
                          SizedBox(width: 8),
                          Text('Lihat Semua Berita',
                              style: TextStyle(
                                  color: Color(0xFFFF6D00),
                                  fontWeight: FontWeight.bold,
                                  fontSize: 13,
                                  letterSpacing: 0.5)),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNewsCard(_NewsItem item, int index) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: GestureDetector(
        onTap: () {
          if (item.url.isNotEmpty) _openUrl(item.url);
        },
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            color: const Color(0xFF1A1F2E).withValues(alpha: 0.85),
            border: Border.all(color: Colors.white.withValues(alpha: 0.1)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius:
                    const BorderRadius.vertical(top: Radius.circular(16)),
                child: Stack(
                  children: [
                    Container(
                      height: 120,
                      width: double.infinity,
                      color: const Color(0xFF0F1626),
                      child: item.imageUrl.isNotEmpty
                          ? Image.network(item.imageUrl,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => const Center(
                                  child: Icon(Icons.image_rounded,
                                      color: Colors.white24, size: 36)))
                          : const Center(
                              child: Icon(Icons.article_rounded,
                                  color: Colors.white24, size: 36)),
                    ),
                    Positioned(
                      top: 8,
                      left: 8,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: const Color(0xFFD32F2F),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: const Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.local_fire_department_rounded,
                                color: Colors.white, size: 12),
                            SizedBox(width: 4),
                            Text('TERKINI',
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 10,
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 0.5)),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      top: 8,
                      right: 8,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: 0.7),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text('#$index',
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 10,
                                fontWeight: FontWeight.bold)),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 10, 12, 6),
                child: Text(
                  item.title,
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                      height: 1.35),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: Text(
                  item.description,
                  style: const TextStyle(
                      color: Colors.white54, fontSize: 11, height: 1.4),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              const Spacer(),
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
                child: Row(
                  children: [
                    const Icon(Icons.access_time_rounded,
                        color: Colors.white54, size: 12),
                    const SizedBox(width: 4),
                    Text(item.timeAgo,
                        style: const TextStyle(
                            color: Colors.white54, fontSize: 10)),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(6),
                        color: const Color(0xFFFF6D00)
                            .withValues(alpha: 0.18),
                      ),
                      child: const Icon(Icons.arrow_forward_rounded,
                          color: Color(0xFFFF6D00), size: 12),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildConnectSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Stack(
          children: [
            Positioned.fill(
              child: Image.asset(
                'assets/images/connect_bg.jpg',
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) =>
                    Container(color: const Color(0xFF0F1B33)),
              ),
            ),
            Positioned.fill(
              child: Container(
                color: Colors.black.withValues(alpha: 0.55),
              ),
            ),
            Padding(
              padding:
                  const EdgeInsets.symmetric(vertical: 24, horizontal: 24),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildConnectIcon(
                    icon: FontAwesomeIcons.telegram,
                    label: 'Telegram',
                    onTap: () => _openUrl('https://t.me/aboutszamz'),
                  ),
                  _buildConnectIcon(
                    icon: FontAwesomeIcons.tiktok,
                    label: 'TikTok',
                    onTap: () => _openUrl('https://tiktok.com/@aboutszamz'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildConnectIcon({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white.withValues(alpha: 0.1),
              border: Border.all(
                color: Colors.white.withValues(alpha: 0.2),
                width: 1,
              ),
            ),
            child: Center(
              child: FaIcon(icon, color: Colors.white70, size: 22),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            style: const TextStyle(
              color: Colors.white54,
              fontSize: 10,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    final titles = <String>['', 'MENU', 'RAT', 'TOOLS', 'TEMA'];
    final showLogo = _navIndex == 0;

    return AppBar(
      backgroundColor: kNavBlue,
      elevation: 0,
      iconTheme: const IconThemeData(color: kWhite),
      centerTitle: true,
      titleSpacing: 0,
      leading: Builder(
        builder: (context) => IconButton(
          icon: const Icon(Icons.menu, color: kWhite),
          onPressed: () => Scaffold.of(context).openDrawer(),
        ),
      ),
      title: showLogo
          ? Image.asset(
              'assets/images/reze.png',
              height: 40,
              fit: BoxFit.contain,
              errorBuilder: (context, error, stackTrace) {
                return const Text(
                  'NEBULA',
                  style: TextStyle(
                    color: kWhite,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                    letterSpacing: 2,
                  ),
                );
              },
            )
          : Text(
              titles[_navIndex],
              style: const TextStyle(
                color: kWhite,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold,
                fontSize: 18,
                letterSpacing: 3,
              ),
            ),
      actions: [
        GestureDetector(
          onTap: () => Navigator.push(
            context,
            // ✅ PERBAIKAN: Panggil contact.ProfilePage dengan 6 parameter
            _slideRoute(contact.ProfilePage(
              username: username,
              password: password,
              role: role,
              expiredDate: expiredDate,
              sessionKey: sessionKey,
              uid: uidFromPrefs, // Menggunakan UID dari SharedPreferences
            )),
          ),
          child: const Padding(
            padding: EdgeInsets.symmetric(horizontal: 8),
            child: Icon(Icons.headset_mic_outlined, color: kWhite, size: 24),
          ),
        ),
        IconButton(
          icon: const Icon(Icons.rocket_launch_rounded,
              color: kWhite, size: 22),
          onPressed: () {},
        ),
        IconButton(
          icon: const Icon(Icons.shield_rounded, color: kWhite, size: 22),
          onPressed: () {},
        ),
        const SizedBox(width: 8),
      ],
    );
  }

  // ══════════════════════════════════════════════════════════════════════
  //  BOTTOM NAV — TANPA efek, langsung cepet
  // ══════════════════════════════════════════════════════════════════════
  Widget _buildBottomNav() {
    const items = [
      _NavItem(icon: Icons.home_rounded, label: 'Beranda'),
      _NavItem(icon: Icons.grid_view_rounded, label: 'Menu'),
      _NavItem(icon: Icons.settings_remote_rounded, label: 'RAT'),
      _NavItem(icon: Icons.settings_rounded, label: 'Tools'),
      _NavItem(icon: Icons.palette_rounded, label: 'Tema'),
    ];

    const double navHeight = 78;
    const double circleSize = 60;
    const double circleRadius = circleSize / 2;

    return LayoutBuilder(
      builder: (context, constraints) {
        final double totalWidth = constraints.maxWidth;
        final double itemWidth = totalWidth / items.length;
        final double targetCenterX = itemWidth * _navIndex + itemWidth / 2;

        return SizedBox(
          height: navHeight + 30,
          child: Stack(
            clipBehavior: Clip.none,
            alignment: Alignment.bottomCenter,
            children: [
              Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                height: navHeight,
                child: CustomPaint(
                  painter: _NavNotchPainter(
                    centerX: targetCenterX,
                    notchRadius: circleRadius + 8,
                    color: kNavBlue,
                  ),
                  child: SafeArea(
                    top: false,
                    child: Row(
                      children: List.generate(items.length, (i) {
                        final isActive = _navIndex == i;
                        return Expanded(
                          child: GestureDetector(
                            onTap: () => _onNavTap(i),
                            behavior: HitTestBehavior.opaque,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                if (!isActive)
                                  Container(
                                    width: 44,
                                    height: 44,
                                    decoration: BoxDecoration(
                                      color: Colors.white
                                          .withValues(alpha: 0.12),
                                      borderRadius:
                                          BorderRadius.circular(12),
                                      border: Border.all(
                                        color: Colors.white
                                            .withValues(alpha: 0.25),
                                        width: 1.5,
                                      ),
                                    ),
                                    child: Icon(
                                      items[i].icon,
                                      color: Colors.white
                                          .withValues(alpha: 0.85),
                                      size: 24,
                                    ),
                                  )
                                else
                                  const SizedBox(height: 44),
                                const SizedBox(height: 3),
                                Text(
                                  items[i].label,
                                  style: TextStyle(
                                    color: isActive
                                        ? Colors.white
                                        : Colors.white
                                            .withValues(alpha: 0.75),
                                    fontSize: 10,
                                    fontWeight: isActive
                                        ? FontWeight.bold
                                        : FontWeight.w500,
                                    fontFamily: 'Orbitron',
                                    letterSpacing: 0.5,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      }),
                    ),
                  ),
                ),
              ),
              Positioned(
                left: targetCenterX - circleRadius,
                bottom: navHeight - circleRadius,
                child: IgnorePointer(
                  child: Container(
                    width: circleSize,
                    height: circleSize,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.25),
                          blurRadius: 12,
                          offset: const Offset(0, 4),
                        ),
                        BoxShadow(
                          color: kNavBlue.withValues(alpha: 0.4),
                          blurRadius: 20,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: Icon(
                      items[_navIndex].icon,
                      color: kNavIconActive,
                      size: 30,
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: kBg,
      width: MediaQuery.of(context).size.width * 0.8,
      child: Column(
        children: [
          Container(
            height: 240,
            color: Colors.black,
            child: Stack(
              children: [
                if (_menuVideoCtrl != null &&
                    _menuVideoCtrl!.value.isInitialized)
                  SizedBox.expand(
                    child: FittedBox(
                      fit: BoxFit.cover,
                      child: SizedBox(
                        width: _menuVideoCtrl!.value.size.width,
                        height: _menuVideoCtrl!.value.size.height,
                        child: VideoPlayer(_menuVideoCtrl!),
                      ),
                    ),
                  ),
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.black.withValues(alpha: 0.3),
                        Colors.black.withValues(alpha: 0.85)
                      ],
                    ),
                  ),
                ),
                SafeArea(
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 80,
                          height: 80,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                                color: kCyan.withValues(alpha: 0.6),
                                width: 2.5),
                          ),
                          child: ClipOval(
                            child: _profileImage != null
                                ? Image.file(_profileImage!,
                                    fit: BoxFit.cover)
                                : const Icon(
                                    FontAwesomeIcons.userAstronaut,
                                    size: 38,
                                    color: kWhite),
                          ),
                        ),
                        const SizedBox(height: 12),
                        Text(username,
                            style: const TextStyle(
                                color: kWhite,
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Orbitron')),
                        Text(role.toUpperCase(),
                            style: const TextStyle(
                                color: kCyan,
                                fontSize: 12,
                                letterSpacing: 2)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Container(
              color: kBg,
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 16),
                children: [
                  if (role == 'reseller')
                    _buildDrawerItem(
                        icon: Icons.storefront_rounded,
                        label: 'Seller Page',
                        onTap: () => _onDrawerNav(1)),
                  if (role == 'admin')
                    _buildDrawerItem(
                        icon: Icons.admin_panel_settings_rounded,
                        label: 'Admin Page',
                        onTap: () => _onDrawerNav(2)),
                  if (role == 'owner')
                    _buildDrawerItem(
                        icon: Icons.workspace_premium_rounded,
                        label: 'Owner Page',
                        onTap: () => _onDrawerNav(3)),
                  _buildDrawerItem(
                    icon: Icons.history_rounded,
                    label: 'Riwayat Aktivitas',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                          context,
                          _slideRoute(RiwayatPage(
                              sessionKey: sessionKey, role: role)));
                    },
                  ),
                  _buildDrawerItem(
                    icon: Icons.lock_outline_rounded,
                    label: 'Ganti Password',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        _slideRoute(ChangePasswordPage(
                            username: username, sessionKey: sessionKey)),
                      );
                    },
                  ),
                  const SizedBox(height: 16),
                  _buildDrawerItem(
                    icon: Icons.logout_rounded,
                    label: 'Keluar',
                    isLogout: true,
                    onTap: () async {
                      Navigator.pop(context);
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.clear();
                      if (!mounted) return;
                      Navigator.of(context).pushAndRemoveUntil(
                          MaterialPageRoute(
                              builder: (_) => const LoginPage()),
                          (_) => false);
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool isLogout = false,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
      decoration: BoxDecoration(
        color: isLogout ? Colors.red.withValues(alpha: 0.08) : kCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
            color: isLogout
                ? Colors.red.withValues(alpha: 0.3)
                : kBorder.withValues(alpha: 0.4)),
      ),
      child: ListTile(
        leading:
            Icon(icon, color: isLogout ? Colors.redAccent : kCyan, size: 20),
        title: Text(label,
            style: TextStyle(
                color: isLogout ? Colors.redAccent : kWhite,
                fontWeight: FontWeight.w600,
                fontSize: 14)),
        trailing: const Icon(Icons.arrow_forward_ios_rounded,
            color: kWhite24, size: 13),
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        onTap: onTap,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      extendBodyBehindAppBar: false,
      extendBody: false,
      appBar: _buildAppBar(),
      drawer: _buildDrawer(),
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              'assets/images/background.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(color: kBg),
            ),
          ),
          Positioned.fill(
            child: Container(color: Colors.black.withValues(alpha: 0.6)),
          ),
          Positioned.fill(
            child: CustomPaint(
              painter: _GridPatternPainter(
                gridColor: kCyan.withValues(alpha: 0.04),
                lineColor: kPink.withValues(alpha: 0.02),
                spacing: 35,
              ),
            ),
          ),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 700),
            switchInCurve: Curves.easeInOutCubic,
            switchOutCurve: Curves.easeInOutCubic,
            transitionBuilder: (child, animation) {
              final offsetAnim = Tween<Offset>(
                begin: const Offset(0.15, 0),
                end: Offset.zero,
              ).animate(CurvedAnimation(
                parent: animation,
                curve: Curves.easeOutCubic,
              ));
              return FadeTransition(
                opacity: animation,
                child: SlideTransition(
                  position: offsetAnim,
                  child: child,
                ),
              );
            },
            child: KeyedSubtree(
              key: ValueKey(_navIndex),
              child: _buildCurrentPage(),
            ),
          ),
        ],
      ),
      bottomNavigationBar: _buildBottomNav(),
    );
  }
}

// ─── Quick Action Data ─────────────────────────────────────────────────────────
class _QuickActionData {
  final IconData icon;
  final IconData bgIcon;
  final String title;
  final String subtitle;
  final List<Color> gradient;
  final Color glowColor;
  final VoidCallback onTap;
  const _QuickActionData({
    required this.icon,
    required this.bgIcon,
    required this.title,
    required this.subtitle,
    required this.gradient,
    required this.glowColor,
    required this.onTap,
  });
}

// ─── Slide Route ──────────────────────────────────────────────────────────────
PageRoute _slideRoute(Widget page) => PageRouteBuilder(
      pageBuilder: (_, __, ___) => page,
      transitionDuration: const Duration(milliseconds: 350),
      transitionsBuilder: (_, anim, __, child) => SlideTransition(
        position: Tween<Offset>(
                begin: const Offset(1, 0), end: Offset.zero)
            .animate(CurvedAnimation(
                parent: anim, curve: Curves.easeOutCubic)),
        child: FadeTransition(opacity: anim, child: child),
      ),
    );

// ─── NewsMedia ────────────────────────────────────────────────────────────────
class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});
  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _ctrl;

  bool _isVideo(String url) =>
      url.endsWith('.mp4') ||
      url.endsWith('.webm') ||
      url.endsWith('.mov') ||
      url.endsWith('.mkv');

  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _ctrl = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          if (mounted) setState(() {});
          _ctrl?.setLooping(true);
          _ctrl?.setVolume(0.0);
          _ctrl?.play();
        });
    }
  }

  @override
  void dispose() {
    _ctrl?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_ctrl != null && _ctrl!.value.isInitialized) {
        return AspectRatio(
            aspectRatio: _ctrl!.value.aspectRatio,
            child: VideoPlayer(_ctrl!));
      }
      return const Center(
          child: CircularProgressIndicator(color: kCyan, strokeWidth: 2));
    }
    return Image.network(
      widget.url,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => Container(
          color: kCard,
          child: const Icon(Icons.error_rounded, color: kWhite24)),
    );
  }
}