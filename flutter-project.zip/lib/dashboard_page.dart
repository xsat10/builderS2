import 'servers.dart';
import 'dart:convert';
import 'dart:core';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:chewie/chewie.dart';
import 'spotify.dart';
import 'alquran.dart';
import 'media/xneuron_chat.dart';
import 'media/games_menu.dart';
import 'media/donghua.dart';
import 'media/animek.dart';
import 'media/dracin_page.dart';
import 'media/music.dart';
import 'tools/wifi_internal.dart';
import 'link/fullup_gb.dart';
import 'link/reseller_gb.dart';
import 'link/admin_gb.dart';
import 'link/owner_gb.dart';
import 'link/moderator_gb.dart';
import 'link/staff_gb.dart';
import 'media/comic.dart';
import 'buy_account.dart';
import 'infoh.dart';
import 'up_role.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'contact_page.dart';
import 'jadwal_sholat.dart';
import 'package:http/http.dart' as http;
import 'dart:ui' as ui;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:video_player/video_player.dart';
import 'bugs/bug_sender.dart';
import 'manager/admin_page.dart';
import 'bugs/home_page.dart';
import 'control_panel.dart';
import 'info/tqto.dart';
import 'info/info.dart';
import 'ghostcrasher_trader.dart';
import 'tools/tele.dart';
import 'riwayat_page.dart';
import 'manager/change_password_page.dart';
import 'package:intl/intl.dart';
import 'dart:async';
import 'info/chat.dart';
import 'tools/load_tools.dart';
import 'login_page.dart';
import 'bugs/ddos_panel.dart';
import 'floating/floating_bug.dart';
import 'floating/floating_bagger.dart';
import 'dart:math';
import 'package:carousel_slider/carousel_slider.dart' as carousel;
import 'push_notification_service.dart';
import 'package:firebase_core/firebase_core.dart';

// ═══════════════════════════════════════════════════════════════
// 🏁 BMW M-SPORT GARAGE PALETTE
// ═══════════════════════════════════════════════════════════════
const Color bmwBlue      = Color(0xFF0066B1);   // BMW Classic Blue
const Color bmwLightBlue = Color(0xFF1C69D4);   // BMW Light Blue
const Color bmwRed       = Color(0xFFE30613);   // BMW M Red
const Color bmwYellow    = Color(0xFFFFD700);   // M Gold/Yellow
const Color bmwSilver    = Color(0xFFB0B0B0);   // BMW Silver
const Color bmwChrome    = Color(0xFFE0E0E0);   // Chrome
const Color bmwCarbon    = Color(0xFF0A0A0A);   // Carbon Fiber Black
const Color bmwDark      = Color(0xFF141414);   // Dark Carbon
const Color bmwGunmetal  = Color(0xFF2A2A2A);   // Gunmetal
const Color bmwPit       = Color(0xFF1A1A1A);   // Pit Bay

// ─── Alias warna global (backward compat) ───
const Color kCard        = Color(0xFF141414);
const Color kBorder      = Color(0xFF2E2E2E);
const Color kGray        = Color(0xFFB0B0B0);
const Color _greenSoft   = Color(0xFF3CB371);
const Color kGrayLight   = Color(0xFFD1D5DB);
const Color kGrayDark    = Color(0xFF4B5563);
const Color kWhite       = Color(0xFFFFFFFF);
const Color kWhite54     = Color(0x8AFFFFFF);
const Color kCardNews    = Color(0xFF141414);
const Color kCardAltNews = Color(0xFF1F1F1F);
const Color kBorderNews  = Color(0xFF2E2E2E);

// Premium Colors
const Color premiumLightBlue = Color(0xFF1C69D4);
const Color premiumDarkBlue  = Color(0xFF03045E);

// ═══════════════════════════════════════════════════════════════
// DASHBOARD PAGE
// ═══════════════════════════════════════════════════════════════
class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

// ═══════════════════════════════════════════════════════════════
// STATE
// ═══════════════════════════════════════════════════════════════
class _DashboardPageState extends State<DashboardPage>
    with WidgetsBindingObserver, TickerProviderStateMixin {
  late AnimationController _controller;
  late AnimationController _fadeController;
  late Animation<double> _animation;
  late Animation<double> _fadeAnimation;

  String? get sessionKey => widget.sessionKey;
  List<dynamic> get news => widget.news;

  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  List<Map<String, dynamic>> _activityLogs = [];
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;
  String androidId = "unknown";
  Timer? _clockTimer;
  DateTime _now = DateTime.now();

  int _selectedTabIndex = 0;
  int _carouselCurrentIndex = 0;
  Widget _selectedPage = const Center(child: CircularProgressIndicator());
  int totalUsers = 91;
  final FlutterLocalNotificationsPlugin _notifications =
      FlutterLocalNotificationsPlugin();

  // ─── BMW themed color fields ───
  final Color darkRed        = const Color(0xFFE30613);
  final Color primaryDark    = const Color(0xFF0A0A0A);
  final Color cardDark       = const Color(0xFF141414);
  final Color cardDarker     = const Color(0xFF0A0A0A);
  final Color darkCardLighter= const Color(0xFF2A2A2A);
  final Color textSecondary  = const Color(0xFFB0B0B0);
  final Color accentGrey     = const Color(0xFF666666);
  final Color goldColor      = const Color(0xFFFFD700);
  final Color accentRead     = const Color(0xFFE30613);
  final Color blueColor      = const Color(0xFF0066B1);
  final Color accentRed      = const Color(0xFFB0B0B0);

  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  late AnimationController _slideController;
  late Animation<Offset> _slideAnimation;

  bool isLoadingUsers = true;
  bool senderConnected = false;
  bool _isLoadingKey = false;
  bool _isFloatingBaggerActive = false;
  bool _isLoadingWeather = true;
  bool _hasWeatherError = false;
  String _weatherCity = "Semarang";
  String _weatherTemperature = "--";
  String _weatherCondition = "Loading...";
  String _weatherIcon = "🌤️";
  int _weatherHumidity = 0;
  double _weatherWindSpeed = 0;
  int _weatherPressure = 0;
  bool _isLoadingActivityLogs = false;
  bool _hasActivityLogsError = false;

  Map<String, dynamic>? _hadith;
  bool _hadithLoading = false;
  int _lastHadithNumber = 0;

  String baseUrl = "";
  String _selectedCity = "Semarang";
  double _cityLat = -6.9667;
  double _cityLon = 110.4167;

  List<dynamic> _beritaList = [];
  bool _isLoadingBerita = true;

  final List<Map<String, dynamic>> _cities = [
    {'name': 'Jakarta',    'lat': -6.2088, 'lon': 106.8456},
    {'name': 'Surabaya',   'lat': -7.2575, 'lon': 112.7521},
    {'name': 'Bandung',    'lat': -6.9175, 'lon': 107.6191},
    {'name': 'Medan',      'lat': 3.5952,  'lon': 98.6722},
    {'name': 'Makassar',   'lat': -5.1477, 'lon': 119.4327},
    {'name': 'Semarang',   'lat': -6.9667, 'lon': 110.4167},
    {'name': 'Yogyakarta', 'lat': -7.7956, 'lon': 110.3695},
    {'name': 'Bali',       'lat': -8.3405, 'lon': 115.0920},
    {'name': 'Palembang',  'lat': -2.9761, 'lon': 104.7754},
    {'name': 'Balikpapan', 'lat': -1.2379, 'lon': 116.8529},
  ];

  @override
  void initState() {
    super.initState();
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    _loadConfigAndInit();
    _setFallbackHadith();
    _initNotifications();
    _fetchNews();
    _fetchActivityLogs();
    _fetchWeather();
    _fetchBerita();

    _activityLogs = [
      {
        'activity': 'Login',
        'timestamp': DateTime.now().toIso8601String(),
        'details': {'target': 'Dashboard'}
      },
      {
        'activity': 'Welcome',
        'timestamp': DateTime.now().toIso8601String(),
        'details': {'target': 'GhostCrasher Apps'}
      },
    ];

    Timer.periodic(const Duration(minutes: 10), (timer) {
      if (mounted) _fetchWeather();
    });

    _controller = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    );

    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    )..repeat(reverse: true);

    _slideController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..forward();

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.5),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _slideController,
      curve: Curves.easeOutCubic,
    ));

    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeInOut),
    );

    _pulseAnimation = Tween<double>(begin: 0.95, end: 1.05).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _controller.forward();
    _fadeController.forward();

    _selectedPage = const Center(child: CircularProgressIndicator());
  }

  // ═══════════════════════════════════════════════════════════════
  // FETCH BERITA
  // ═══════════════════════════════════════════════════════════════
  Future<void> _fetchBerita() async {
    setState(() => _isLoadingBerita = true);
    try {
      final response = await http.get(
        Uri.parse(
            "https://api.rss2json.com/v1/api.json?rss_url=https://www.antaranews.com/rss/terkini.xml"),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status'] == 'ok') {
          setState(() {
            _beritaList = data['items'] ?? [];
            _isLoadingBerita = false;
          });
        } else {
          setState(() => _isLoadingBerita = false);
        }
      } else {
        setState(() => _isLoadingBerita = false);
      }
    } catch (e) {
      print('Error fetch berita: $e');
      setState(() => _isLoadingBerita = false);
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // CONFIG & INIT
  // ═══════════════════════════════════════════════════════════════
  void _loadConfigAndInit() async {
    await _loadConfig();
    await _initAndroidIdAndConnect();
    await _getSessionKey();
    await _checkFloatingBaggerStatus();

    Timer.periodic(const Duration(seconds: 5), (timer) {
      if (sessionKey != null && mounted) {
        checkSenderStatus();
      }
    });
  }

  void _setFallbackHadith() {
    setState(() {
      _hadith = {
        'data': {
          'text': {
            'ar':
                'لا تتركوا صلواتكم واحفظوها، فإذا ضاعت صلواتكم، ستفقدون كل شيء.',
            'id':
                'Jangan lah engkau tinggalkan sholat mu dan jagalah sholat mu, ketika kamu kehilangan sholat, kamu akan kehilangan segalanya.'
          },
          'id': 1,
          'source': 'Muslim',
          'grade': 'Sahih Muslim'
        }
      };
      _hadithLoading = false;
    });
  }

  void _initNotifications() async {
    const AndroidInitializationSettings initializationSettingsAndroid =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    const InitializationSettings initializationSettings = InitializationSettings(
      android: initializationSettingsAndroid,
    );

    await _notifications.initialize(initializationSettings);
    if (Firebase.apps.isNotEmpty) {
      await PushNotificationService.initialize();
    }
  }

  Future<void> _fetchNews() async {
    try {
      final response = await http
          .get(Uri.parse("$baseUrl/news"))
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true && data['news'] != null) {
          setState(() {
            newsList = data['news'];
          });
          return;
        }
      }
    } catch (e) {
      debugPrint('Error fetching news: $e');
    }
  }

  Future<void> _fetchActivityLogs() async {
    if (_activityLogs.isEmpty) {
      setState(() {
        _activityLogs = [
          {
            'activity': 'Welcome',
            'timestamp': DateTime.now().toIso8601String(),
            'details': {'target': 'GhostCrasher Apps'}
          },
        ];
      });
    }

    setState(() {
      _isLoadingActivityLogs = true;
      _hasActivityLogsError = false;
    });

    try {
      final response = await http.get(
        Uri.parse('$baseUrl/getActivityLogs?key=$sessionKey&limit=10'),
      ).timeout(const Duration(seconds: 5));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true && data['logs'] != null) {
          final logs = data['logs'];
          if (logs.isNotEmpty) {
            setState(() {
              _activityLogs = List<Map<String, dynamic>>.from(logs);
              _isLoadingActivityLogs = false;
            });
          } else {
            setState(() => _isLoadingActivityLogs = false);
          }
        } else {
          setState(() => _isLoadingActivityLogs = false);
        }
      } else {
        setState(() => _isLoadingActivityLogs = false);
      }
    } catch (e) {
      setState(() {
        _isLoadingActivityLogs = false;
        _hasActivityLogsError = false;
      });
    }
  }

  Future<void> _fetchWeather() async {
    setState(() {
      _isLoadingWeather = true;
      _hasWeatherError = false;
    });

    try {
      final response = await http.get(
        Uri.parse(
            "https://api.open-meteo.com/v1/forecast?latitude=${_cityLat}&longitude=${_cityLon}&current_weather=true&timezone=auto"),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final current = data['current_weather'];

        setState(() {
          _weatherCity = _selectedCity;
          _weatherTemperature = "${current['temperature'].round()}°C";
          _weatherCondition = _getWeatherCondition(current['weathercode']);
          _weatherIcon = _getWeatherIconFromCode(current['weathercode']);
          _weatherHumidity = 65;
          _weatherWindSpeed = current['windspeed'] ?? 0;
          _weatherPressure = 1013;
          _isLoadingWeather = false;
          _hasWeatherError = false;
        });
      } else {
        _setFallbackWeather(_selectedCity);
      }
    } catch (e) {
      debugPrint('Weather fetch error: $e');
      _setFallbackWeather(_selectedCity);
    }
  }

  void _setFallbackWeather(String city) {
    setState(() {
      _weatherCity = city;
      _weatherTemperature = "28°C";
      _weatherCondition = "Cerah Berawan";
      _weatherIcon = "🌤️";
      _weatherHumidity = 65;
      _weatherWindSpeed = 12.5;
      _weatherPressure = 1013;
      _isLoadingWeather = false;
      _hasWeatherError = false;
    });
  }

  String _getWeatherCondition(int code) {
    switch (code) {
      case 0: return 'Cerah';
      case 1:
      case 2:
      case 3: return 'Berawan';
      case 45:
      case 48: return 'Kabut';
      case 51:
      case 53:
      case 55: return 'Gerimis';
      case 61:
      case 63:
      case 65: return 'Hujan';
      case 71:
      case 73:
      case 75: return 'Salju';
      case 80:
      case 81:
      case 82: return 'Hujan Deras';
      case 95:
      case 96:
      case 99: return 'Badai Petir';
      default: return 'Cerah Berawan';
    }
  }

  String _getWeatherIconFromCode(int code) {
    switch (code) {
      case 0: return '☀️';
      case 1:
      case 2:
      case 3: return '⛅';
      case 45:
      case 48: return '🌫️';
      case 51:
      case 53:
      case 55: return '🌦️';
      case 61:
      case 63:
      case 65: return '🌧️';
      case 71:
      case 73:
      case 75: return '❄️';
      case 80:
      case 81:
      case 82: return '⛈️';
      case 95:
      case 96:
      case 99: return '⛈️';
      default: return '🌤️';
    }
  }

  Future<void> _loadConfig() async {
    final response = await http.get(Uri.parse(
        Servers.configUrl));
    final data = jsonDecode(response.body);
    baseUrl = data['base_url'];
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
  }

  Future<void> _getSessionKey() async {
    setState(() => _isLoadingKey = true);
    try {
      final response = await http.get(
        Uri.parse("$baseUrl/getKey?username=${widget.username}"),
      ).timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          if (!mounted) return;
          await checkSenderStatus();
          // Notifikasi developer dikirim langsung melalui FCM.
          // Jangan tampilkan notifikasi terbaru lagi saat masuk APK,
          // agar satu pesan tidak muncul dua kali.
          await fetchTotalUsers();
          if (Firebase.apps.isNotEmpty && sessionKey != null && sessionKey!.isNotEmpty) {
            await PushNotificationService.requestPermissionAndSubscribe();
          }
          setState(() {
            _isLoadingKey = false;
            _selectedPage = _buildNewsPage();
          });
        }
      } else {
        setState(() => _isLoadingKey = false);
      }
    } catch (e) {
      print("Error get session key: $e");
      setState(() => _isLoadingKey = false);
    }
  }

  Future<void> _checkFloatingBaggerStatus() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _isFloatingBaggerActive =
          prefs.getBool('floating_bagger_running') ?? false;
    });
  }

  Future<void> checkSenderStatus() async {
    if (sessionKey == null || sessionKey!.isEmpty) {
      print("Session key null, skip check sender");
      return;
    }

    try {
      final response = await http
          .get(Uri.parse("$baseUrl/mySender?key=$sessionKey"))
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          if (data['connections'] != null && data['connections'].length > 0) {
            senderConnected = true;
          } else {
            senderConnected = false;
          }
        });
      } else {
        setState(() => senderConnected = false);
      }
    } catch (e) {
      print("Error cek sender: $e");
      setState(() => senderConnected = false);
    }
  }

  Future<void> _checkNotifications() async {
    if (sessionKey == null) return;

    try {
      final url = '$baseUrl/getNotifications?key=$sessionKey';
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true && data['notifications'] != null) {
          final notifs = data['notifications'];
          if (notifs.isNotEmpty) {
            final latest = notifs[0];
            _showNotification(latest['title'], latest['body']);
          }
        }
      }
    } catch (e) {
      print('Error check notif: $e');
    }
  }

  Future<void> _showNotification(String title, String body) async {
    const AndroidNotificationDetails androidPlatformChannelSpecifics =
        AndroidNotificationDetails(
      'GhostCrasher',
      'GhostCrasher Notifikasi',
      channelDescription: 'Notifikasi dari GhostCrasher Apps',
      importance: Importance.max,
      priority: Priority.high,
      icon: '@mipmap/ic_launcher',
    );

    const NotificationDetails platformChannelSpecifics = NotificationDetails(
      android: androidPlatformChannelSpecifics,
    );

    await _notifications.show(0, title, body, platformChannelSpecifics);
  }

  Future<void> fetchTotalUsers() async {
    if (sessionKey == null) return;
    try {
      final response =
          await http.get(Uri.parse('$baseUrl/listUsers?key=$sessionKey'));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['valid'] == true && data['users'] != null) {
          List<dynamic> users = data['users'];
          setState(() {
            totalUsers = users.length;
            isLoadingUsers = false;
          });
        } else {
          setState(() => isLoadingUsers = false);
        }
      } else {
        setState(() => isLoadingUsers = false);
      }
    } catch (e) {
      print('Error fetch users: $e');
      setState(() => isLoadingUsers = false);
    }
  }

  Future<void> refreshSenderStatus() async {
    await checkSenderStatus();
  }

  // ═══════════════════════════════════════════════════════════════
  // HELPER: ROLE CEK & WARNA (BMW M-SPORT STYLE)
  // ═══════════════════════════════════════════════════════════════
  bool _isRoleAllowed(List<String> allowedRoles) {
    return allowedRoles.contains(role.toLowerCase());
  }

  Color _getRoleColor(String role) {
    switch (role.toLowerCase()) {
      case "owner":     return bmwRed;
      case "tk":        return const Color(0xFF8B00FF); // M Purple
      case "pt":        return const Color(0xFF00A651); // M Green
      case "reseller":  return bmwYellow;
      case "staff":     return const Color(0xFF00A651);
      case "moderator": return bmwLightBlue;
      case "admin":     return bmwYellow;
      default:          return bmwLightBlue;
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // QUICK STAT
  // ═══════════════════════════════════════════════════════════════
  Widget _buildQuickStat({
    required dynamic icon,
    required String label,
    required String value,
  }) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: bmwSilver.withOpacity(0.08),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: bmwYellow.withOpacity(0.2)),
        ),
        child: Row(
          children: [
            Icon(icon, color: bmwYellow, size: 20),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: TextStyle(
                      color: bmwSilver.withOpacity(0.7),
                      fontSize: 10,
                    ),
                  ),
                  Text(
                    value,
                    style: const TextStyle(
                      color: bmwChrome,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // CHIP STAT
  // ═══════════════════════════════════════════════════════════════
  Widget _buildRealTimeStatChipGradient({
    required dynamic icon,
    required String value,
    required String label,
    required Color color,
    bool isLive = false,
  }) {
    return Column(
      children: [
        Stack(
          alignment: Alignment.center,
          children: [
            Container(
              width: 56,
              height: 56,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [
                    color.withOpacity(0.2),
                    color.withOpacity(0.1),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                border: Border.all(
                  color: color.withOpacity(0.3),
                  width: 1,
                ),
              ),
              child: Center(
                child: Icon(icon, color: color, size: 24),
              ),
            ),
            if (isLive)
              Positioned(
                top: 0,
                right: 0,
                child: Container(
                  width: 12,
                  height: 12,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: bmwYellow,
                    boxShadow: [
                      BoxShadow(
                        color: bmwYellow.withOpacity(0.8),
                        blurRadius: 8,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
        const SizedBox(height: 8),
        Text(
          value,
          style: const TextStyle(
            color: bmwChrome,
            fontSize: 16,
            fontWeight: FontWeight.w700,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            color: bmwSilver.withOpacity(0.6),
            fontSize: 11,
            fontWeight: FontWeight.w400,
          ),
        ),
        if (isLive)
          Container(
            margin: const EdgeInsets.only(top: 4),
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(
              color: bmwYellow.withOpacity(0.2),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: bmwYellow.withOpacity(0.4)),
            ),
            child: const Text(
              "LIVE",
              style: TextStyle(
                color: bmwYellow,
                fontSize: 8,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // WHATSAPP MENU PAGE (TAB INDEX 1) — BMW PADDOCK
  // ═══════════════════════════════════════════════════════════════
  Widget _buildWhatsAppMenuPage() {
    final List<Map<String, dynamic>> menuOptions = [
      {
        'title': 'GHOST BUG',
        'subtitle': 'Hanya bug Whatsapp',
        'description': 'Gunakan langsung all work',
        'icon': Icons.bug_report,
        'iconColor': bmwLightBlue,
        'gradientColors': [
          const Color(0xFF0F1923),
          const Color(0xFF1A2530),
          const Color(0xFF0A0A0A),
        ],
        'badgeText': 'M-POWERED',
        'badgeColor': bmwYellow,
        'features': [
          'Mudah digunakan',
          'Function terbaru',
          'All work gacor',
          'GHOST BUG'
        ],
        'onTap': () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => HomePage(
                  username: username,
                  password: password,
                  listBug: listBug,
                  role: role,
                  expiredDate: expiredDate,
                  sessionKey: sessionKey!,
                ),
              ),
            ),
      },
      {
        'title': 'REPORT TELEGRAM',
        'subtitle': 'Menu report Telegram',
        'description': 'Report telegram no gimick',
        'icon': FontAwesomeIcons.telegram,
        'iconColor': bmwLightBlue,
        'gradientColors': [
          const Color(0xFF0F1923),
          const Color(0xFF1A2530),
          const Color(0xFF0A0A0A),
        ],
        'badgeText': 'PIT STOP',
        'badgeColor': bmwYellow,
        'features': [
          'Pengaturan Mudah',
          'Report Telegram',
          'Bebas Spam',
          'Work'
        ],
        'onTap': () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => TelegramSpamPage(sessionKey: sessionKey!),
              ),
            ),
      },
      {
        'title': 'RAT',
        'subtitle': 'Kontrol perangkat',
        'description': 'Kelola perangkat yang terhubung',
        'icon': Icons.settings_remote_rounded,
        'iconColor': bmwLightBlue,
        'gradientColors': [
          const Color(0xFF0F1923),
          const Color(0xFF1A2530),
          const Color(0xFF0A0A0A),
        ],
        'badgeText': 'REMOTE CONTROL',
        'badgeColor': bmwLightBlue,
        'features': [
          'Device Control',
          'Status Perangkat',
          'Kontrol Jarak Jauh',
          'Monitoring'
        ],
        'onTap': () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => const ControlPanelPage(),
              ),
            ),
      },
      {
        'title': 'GHOSTCRASHER TRADER',
        'subtitle': 'Menu Trader',
        'description': 'Kelola modal trading Anda dengan cerdas dan aman',
        'icon': Icons.trending_up,
        'iconColor': bmwLightBlue,
        'gradientColors': [
          const Color(0xFF0F1923),
          const Color(0xFF1A2530),
          const Color(0xFF0A0A0A),
        ],
        'badgeText': 'TRACK MODE',
        'badgeColor': bmwRed,
        'features': ['Kelola Uang Anda', 'Ghost Trader', 'Aman'],
        'onTap': () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => const GhostCrasherTraderApp(),
              ),
            ),
      },
    ];

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF05080D),
              Color(0xFF0A0F16),
              Color(0xFF141414),
              Color(0xFF05080D),
            ],
          ),
        ),
        child: Stack(
          children: [
            Positioned.fill(
              child: Opacity(
                opacity: 0.55,
                child: Container(
                  decoration: const BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage('assets/images/car.jpg'),
                      fit: BoxFit.cover,
                      alignment: Alignment.center,
                    ),
                  ),
                ),
              ),
            ),
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.black.withOpacity(0.30),
                      Colors.black.withOpacity(0.45),
                      Colors.black.withOpacity(0.65),
                      Colors.black.withOpacity(0.85),
                    ],
                    stops: const [0.0, 0.3, 0.7, 1.0],
                  ),
                ),
              ),
            ),
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              height: 4,
              child: Row(
                children: [
                  Expanded(child: Container(color: bmwBlue)),
                  Expanded(child: Container(color: bmwLightBlue)),
                  Expanded(child: Container(color: bmwRed)),
                ],
              ),
            ),
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              height: 90,
              child: Opacity(
                opacity: 0.4,
                child: CustomPaint(painter: _GarageFloorPainter()),
              ),
            ),
            Positioned(
              top: -80,
              left: 0,
              right: 0,
              height: 300,
              child: Container(
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    center: Alignment.topCenter,
                    radius: 1.0,
                    colors: [
                      bmwYellow.withOpacity(0.14),
                      bmwBlue.withOpacity(0.06),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
            Positioned.fill(
              child: Opacity(
                opacity: 0.04,
                child: Container(
                  decoration: const BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage('assets/images/cargo.png'),
                      repeat: ImageRepeat.repeat,
                      scale: 3.5,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              bottom: -100,
              left: -60,
              right: -60,
              height: 300,
              child: Container(
                decoration: BoxDecoration(
                  gradient: RadialGradient(
                    center: Alignment.bottomCenter,
                    radius: 1.0,
                    colors: [
                      bmwBlue.withOpacity(0.10),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
            Column(
              children: [
                _buildWhatsAppHeader(),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(top: 8, bottom: 16),
                    child: Column(
                      children: [
                        Expanded(
                          child: carousel.CarouselSlider.builder(
                            options: carousel.CarouselOptions(
                              height: double.infinity,
                              viewportFraction: 0.82,
                              initialPage: 0,
                              enableInfiniteScroll: true,
                              autoPlay: false,
                              enlargeCenterPage: true,
                              enlargeFactor: 0.18,
                              scrollDirection: Axis.horizontal,
                              onPageChanged: (index, reason) {
                                setState(() => _carouselCurrentIndex = index);
                              },
                            ),
                            itemCount: menuOptions.length,
                            itemBuilder: (context, index, realIndex) {
                              return _buildCarouselCard(menuOptions[index], index);
                            },
                          ),
                        ),
                        const SizedBox(height: 16),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: List.generate(menuOptions.length, (i) {
                            final bool active = i == _carouselCurrentIndex;
                            return AnimatedContainer(
                              duration: const Duration(milliseconds: 300),
                              margin: const EdgeInsets.symmetric(horizontal: 4),
                              width: active ? 24 : 8,
                              height: 8,
                              decoration: BoxDecoration(
                                color: active
                                    ? bmwYellow
                                    : bmwSilver.withOpacity(0.15),
                                borderRadius: BorderRadius.circular(4),
                                boxShadow: active
                                    ? [
                                        BoxShadow(
                                          color: bmwYellow.withOpacity(0.5),
                                          blurRadius: 8,
                                        )
                                      ]
                                    : [],
                              ),
                            );
                          }),
                        ),
                        const SizedBox(height: 16),
                        _buildInfoPanel(),
                        const SizedBox(height: 16),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // HEADER: BMW GARAGE
  // ═══════════════════════════════════════════════════════════════
  Widget _buildWhatsAppHeader() {
    return Container(
      height: 190,
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            const Color(0xFF141414),
            const Color(0xFF1F1F1F),
            const Color(0xFF05080D).withOpacity(0.0),
          ],
          stops: const [0.0, 0.6, 1.0],
        ),
      ),
      child: Stack(
        children: [
          Positioned.fill(
            child: Opacity(
              opacity: 0.65,
              child: Container(
                decoration: const BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage('assets/images/bmw.jpg'),
                    fit: BoxFit.cover,
                    alignment: Alignment.center,
                  ),
                ),
              ),
            ),
          ),
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withOpacity(0.35),
                    Colors.black.withOpacity(0.25),
                    const Color(0xFF05080D).withOpacity(0.85),
                  ],
                  stops: const [0.0, 0.5, 1.0],
                ),
              ),
            ),
          ),
          Positioned(
            top: 0,
            left: 0,
            child: Row(
              children: [
                Container(width: 60, height: 4, color: bmwBlue),
                Container(width: 60, height: 4, color: bmwLightBlue),
                Container(width: 60, height: 4, color: bmwRed),
              ],
            ),
          ),
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            height: 40,
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.transparent, Color(0xFF05080D)],
                ),
              ),
            ),
          ),
          Positioned(
            top: 12,
            right: 12,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.65),
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: bmwYellow.withOpacity(0.6), width: 1.5),
                boxShadow: [
                  BoxShadow(color: bmwYellow.withOpacity(0.25), blurRadius: 8),
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 6,
                    height: 6,
                    decoration: BoxDecoration(
                      color: bmwYellow,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(color: bmwYellow.withOpacity(0.7), blurRadius: 6),
                      ],
                    ),
                  ),
                  const SizedBox(width: 6),
                  const Text(
                    "GARAGE OPEN",
                    style: TextStyle(
                      color: bmwYellow,
                      fontSize: 9,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1.2,
                    ),
                  ),
                ],
              ),
            ),
          ),
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 82,
                  height: 82,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const LinearGradient(
                      colors: [Color(0xFF2D2D2D), Color(0xFF0A0A0A)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: bmwBlue.withOpacity(0.4),
                        blurRadius: 24,
                        spreadRadius: 4,
                      ),
                      BoxShadow(
                        color: Colors.black.withOpacity(0.7),
                        blurRadius: 15,
                        offset: const Offset(0, 5),
                      ),
                    ],
                    border: Border.all(color: bmwYellow.withOpacity(0.6), width: 2),
                  ),
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      Container(
                        width: 58,
                        height: 58,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: bmwLightBlue.withOpacity(0.7),
                            width: 2,
                          ),
                        ),
                      ),
                      const Icon(
                        FontAwesomeIcons.whatsapp,
                        color: bmwChrome,
                        size: 34,
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                ShaderMask(
                  shaderCallback: (bounds) => const LinearGradient(
                    colors: [bmwYellow, bmwChrome, bmwLightBlue],
                  ).createShader(bounds),
                  child: const Text(
                    "GARASI MENU",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 3,
                      shadows: [
                        Shadow(color: Colors.black, blurRadius: 10),
                        Shadow(color: Colors.black87, blurRadius: 16),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  "SERVICE BAY — PILIH MODUL ANDA",
                  style: TextStyle(
                    color: bmwSilver.withOpacity(0.9),
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 2,
                    shadows: const [
                      Shadow(color: Colors.black, blurRadius: 6),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 40,
                      height: 2.5,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [Colors.transparent, bmwBlue],
                        ),
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                    const SizedBox(width: 6),
                    Container(
                      width: 10,
                      height: 10,
                      decoration: BoxDecoration(
                        color: bmwYellow,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(color: bmwYellow.withOpacity(0.6), blurRadius: 8),
                        ],
                      ),
                    ),
                    const SizedBox(width: 6),
                    Container(
                      width: 40,
                      height: 2.5,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [bmwRed, Colors.transparent],
                        ),
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // FADE IN UP
  // ═══════════════════════════════════════════════════════════════
  Widget _fadeInUp({
    required Widget child,
    Duration duration = const Duration(milliseconds: 600),
    Duration delay = Duration.zero,
    double begin = 0.0,
    double end = 1.0,
    double offsetY = 30.0,
  }) {
    return TweenAnimationBuilder(
      tween: Tween(begin: begin, end: end),
      duration: duration,
      curve: Curves.easeOutCubic,
      child: child,
      builder: (context, value, child) {
        return Transform.translate(
          offset: Offset(0, (1 - value) * offsetY),
          child: Opacity(opacity: value, child: child),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // CAROUSEL CARD: BMW PADDOCK BAY
  // ═══════════════════════════════════════════════════════════════
  Widget _buildCarouselCard(Map<String, dynamic> option, int index) {
    final gradientColors = option['gradientColors'] as List<Color>;
    final features = option['features'] as List<String>;

    return _fadeInUp(
      duration: const Duration(milliseconds: 350),
      delay: Duration(milliseconds: 80 * index),
      child: GestureDetector(
        onTap: option['onTap'] as VoidCallback,
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 6, vertical: 8),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: gradientColors,
            ),
            border: Border.all(color: bmwYellow.withOpacity(0.20), width: 1),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.65),
                blurRadius: 28,
                offset: const Offset(0, 12),
              ),
              BoxShadow(
                color: bmwBlue.withOpacity(0.20),
                blurRadius: 30,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: Stack(
              children: [
                Positioned.fill(
                  child: Opacity(
                    opacity: 0.32,
                    child: Container(
                      decoration: const BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage('assets/images/car.jpg'),
                          fit: BoxFit.cover,
                          alignment: Alignment.center,
                        ),
                      ),
                    ),
                  ),
                ),
                Positioned.fill(
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          Colors.black.withOpacity(0.30),
                          Colors.black.withOpacity(0.50),
                          Colors.black.withOpacity(0.70),
                        ],
                      ),
                    ),
                  ),
                ),
                Positioned(
                  top: 0,
                  right: 0,
                  child: Row(
                    children: [
                      Container(width: 22, height: 3, color: bmwBlue),
                      Container(width: 22, height: 3, color: bmwLightBlue),
                      Container(width: 22, height: 3, color: bmwRed),
                    ],
                  ),
                ),
                Positioned(
                  bottom: 0,
                  left: 0,
                  right: 0,
                  height: 6,
                  child: Row(
                    children: [
                      Expanded(child: Container(color: bmwYellow.withOpacity(0.6))),
                      Expanded(child: Container(color: Colors.black.withOpacity(0.5))),
                      Expanded(child: Container(color: bmwYellow.withOpacity(0.6))),
                      Expanded(child: Container(color: Colors.black.withOpacity(0.5))),
                      Expanded(child: Container(color: bmwYellow.withOpacity(0.6))),
                    ],
                  ),
                ),
                Positioned(
                  bottom: -10,
                  right: -10,
                  child: Opacity(
                    opacity: 0.07,
                    child: const Text(
                      "BMW",
                      style: TextStyle(
                        color: bmwChrome,
                        fontSize: 90,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 4,
                        fontStyle: FontStyle.italic,
                      ),
                    ),
                  ),
                ),
                Positioned(
                  top: -30,
                  left: -30,
                  child: Container(
                    width: 110,
                    height: 110,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: bmwYellow.withOpacity(0.06),
                    ),
                  ),
                ),
                Positioned(
                  bottom: 60,
                  right: -15,
                  child: Container(
                    width: 60,
                    height: 60,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: bmwBlue.withOpacity(0.10),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(22, 20, 22, 0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: 54,
                            height: 54,
                            decoration: BoxDecoration(
                              color: Colors.black.withOpacity(0.55),
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: bmwYellow.withOpacity(0.6),
                                width: 1.5,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: bmwYellow.withOpacity(0.2),
                                  blurRadius: 10,
                                ),
                              ],
                            ),
                            child: Center(
                              child: Icon(
                                option['icon'] as IconData,
                                color: bmwChrome,
                                size: 26,
                              ),
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 5),
                            decoration: BoxDecoration(
                              color: Colors.black.withOpacity(0.65),
                              borderRadius: BorderRadius.circular(6),
                              border: Border.all(
                                color: bmwYellow.withOpacity(0.7),
                                width: 1.5,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: bmwYellow.withOpacity(0.25),
                                  blurRadius: 8,
                                ),
                              ],
                            ),
                            child: Text(
                              option['badgeText'] as String,
                              style: const TextStyle(
                                color: bmwYellow,
                                fontSize: 10,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 1.2,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 18),
                      Text(
                        option['title'] as String,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 21,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.8,
                          shadows: [
                            Shadow(color: Colors.black, blurRadius: 8),
                            Shadow(color: Colors.black54, blurRadius: 14),
                          ],
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        option['subtitle'] as String,
                        style: TextStyle(
                          color: bmwSilver.withOpacity(0.9),
                          fontSize: 12.5,
                          fontWeight: FontWeight.w500,
                          letterSpacing: 0.3,
                          shadows: const [
                            Shadow(color: Colors.black, blurRadius: 5),
                          ],
                        ),
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Container(width: 30, height: 2, color: bmwYellow),
                          const SizedBox(width: 6),
                          Expanded(
                            child: Container(
                              height: 1,
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    bmwYellow.withOpacity(0.5),
                                    Colors.white.withOpacity(0.02),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Text(
                        option['description'] as String,
                        style: TextStyle(
                          color: bmwChrome.withOpacity(0.95),
                          fontSize: 12.5,
                          height: 1.55,
                          letterSpacing: 0.2,
                          shadows: const [
                            Shadow(color: Colors.black, blurRadius: 5),
                          ],
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 12),
                      Wrap(
                        spacing: 6,
                        runSpacing: 6,
                        children: features
                            .take(3)
                            .map((f) => Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 9, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: Colors.black.withOpacity(0.55),
                                    borderRadius: BorderRadius.circular(6),
                                    border: Border.all(
                                      color: bmwYellow.withOpacity(0.3),
                                    ),
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Icon(
                                        Icons.check_circle_outline,
                                        color: bmwYellow.withOpacity(0.85),
                                        size: 11,
                                      ),
                                      const SizedBox(width: 4),
                                      Text(
                                        f,
                                        style: TextStyle(
                                          color: bmwChrome.withOpacity(0.9),
                                          fontSize: 10,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                    ],
                                  ),
                                ))
                            .toList(),
                      ),
                      const Spacer(),
                      Container(
                        margin: const EdgeInsets.only(bottom: 18),
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.60),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: bmwYellow.withOpacity(0.5),
                            width: 1.2,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: bmwYellow.withOpacity(0.15),
                              blurRadius: 10,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Material(
                          color: Colors.transparent,
                          borderRadius: BorderRadius.circular(14),
                          child: InkWell(
                            borderRadius: BorderRadius.circular(14),
                            onTap: option['onTap'] as VoidCallback,
                            splashColor: bmwYellow.withOpacity(0.2),
                            child: const Padding(
                              padding: EdgeInsets.symmetric(vertical: 14),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    "START ENGINE",
                                    style: TextStyle(
                                      color: bmwYellow,
                                      fontSize: 13,
                                      fontWeight: FontWeight.w900,
                                      letterSpacing: 1.4,
                                      shadows: [
                                        Shadow(color: Colors.black, blurRadius: 6),
                                      ],
                                    ),
                                  ),
                                  SizedBox(width: 8),
                                  _ArrowIcon(),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // INFO PANEL: BMW PIT BAY
  // ═══════════════════════════════════════════════════════════════
  Widget _buildInfoPanel() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.60),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: bmwYellow.withOpacity(0.3), width: 1.2),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.45),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
          BoxShadow(
            color: bmwBlue.withOpacity(0.12),
            blurRadius: 16,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              color: bmwYellow.withOpacity(0.15),
              shape: BoxShape.circle,
              border: Border.all(color: bmwYellow.withOpacity(0.55), width: 1.2),
              boxShadow: [
                BoxShadow(color: bmwYellow.withOpacity(0.2), blurRadius: 8),
              ],
            ),
            child: const Icon(Icons.info_outline_rounded, color: bmwYellow, size: 16),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Kami sudah tes semua fitur work 100%, selamat menikmati fitur kami",
                  style: TextStyle(
                    color: bmwChrome.withOpacity(0.95),
                    fontSize: 12.5,
                    fontWeight: FontWeight.w500,
                    height: 1.4,
                    shadows: const [
                      Shadow(color: Colors.black, blurRadius: 5),
                    ],
                  ),
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: bmwYellow,
                        boxShadow: [
                          BoxShadow(color: bmwYellow.withOpacity(0.7), blurRadius: 8),
                        ],
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      "GARASI BMW • PIT BAY OPEN",
                      style: TextStyle(
                        color: bmwSilver.withOpacity(0.7),
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 1.4,
                        shadows: const [
                          Shadow(color: Colors.black, blurRadius: 4),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // TAB / NAVIGATION
  // ═══════════════════════════════════════════════════════════════
  void _onTabTapped(int index) {
    if (sessionKey == null) return;

    setState(() {
      _selectedTabIndex = index;

      if (index == 0) {
        _selectedPage = _buildNewsPage();
      } else if (index == 1) {
        _selectedPage = _buildWhatsAppMenuPage();
      } else if (index == 2) {
        _selectedPage = InfoPage(sessionKey: sessionKey!);
      } else if (index == 3) {
        _selectedPage = CommunityPage(username: username, role: role);
      }
    });
  }

  Future<void> openLink(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw 'Could not launch $url';
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // WELCOME CARD — BMW STYLE
  // ═══════════════════════════════════════════════════════════════
  Widget _buildWelcomeCard() {
  const Color verifiedBlue = Color(0xFF1DA1F2);
  const Color liveGreen = Color(0xFF00E676);        // hijau premium
  const Color platinum = Color(0xFFD6DCE5);         // pengganti kuning (premium)

  const List<Shadow> strongShadows = [
    Shadow(color: Colors.black, blurRadius: 6, offset: Offset(0, 1)),
    Shadow(color: Colors.black87, blurRadius: 12, offset: Offset(0, 2)),
  ];

  return SlideTransition(
    position: _slideAnimation,
    child: Container(
      decoration: BoxDecoration(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: platinum.withOpacity(0.18), width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.55),
            blurRadius: 30,
            offset: const Offset(0, 10),
          ),
          BoxShadow(
            color: bmwBlue.withOpacity(0.15),
            blurRadius: 30,
            offset: const Offset(0, -10),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: Stack(
          children: [
            Positioned.fill(
              child: Image.asset(
                'assets/images/mobil.jpg',
                fit: BoxFit.cover,
                alignment: Alignment.center,
                errorBuilder: (_, __, ___) =>
                    Container(color: const Color(0xFF0A0F16)),
              ),
            ),
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.black.withOpacity(0.35),
                      Colors.black.withOpacity(0.55),
                      Colors.black.withOpacity(0.82),
                    ],
                    stops: const [0.0, 0.5, 1.0],
                  ),
                ),
              ),
            ),
            Positioned(
              top: 0,
              left: 0,
              child: Row(
                children: [
                  Container(width: 40, height: 3, color: bmwBlue),
                  Container(width: 40, height: 3, color: bmwLightBlue),
                  Container(width: 40, height: 3, color: bmwRed),
                ],
              ),
            ),
            Positioned(
              bottom: -30,
              right: -30,
              child: Opacity(
                opacity: 0.08,
                child: Icon(
                  Icons.shield_rounded,
                  size: 200,
                  color: platinum,
                ),
              ),
            ),
            Positioned(
              top: -30,
              left: -30,
              child: Opacity(
                opacity: 0.06,
                child: Container(
                  width: 130,
                  height: 130,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: bmwBlue,
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        width: 62,
                        height: 62,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                              color: Colors.white.withOpacity(0.85), width: 2),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.white.withOpacity(0.15),
                              blurRadius: 12,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: ClipOval(
                          child: Image.asset(
                            'assets/images/login.jpg',
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => Container(
                              color: bmwSilver.withOpacity(0.15),
                              child: const Icon(Icons.person,
                                  color: bmwChrome, size: 30),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Text(
                              "Ahlan Wa Sahlan,",
                              style: TextStyle(
                                color: bmwSilver,
                                fontSize: 14,
                                fontWeight: FontWeight.w500,
                                height: 1.2,
                                shadows: strongShadows,
                              ),
                            ),
                            const SizedBox(height: 5),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Flexible(
                                  child: Text(
                                    username,
                                    style: const TextStyle(
                                      color: bmwChrome,
                                      fontSize: 22,
                                      fontWeight: FontWeight.w900,
                                      fontFamily: 'Orbitron',
                                      height: 1.15,
                                      shadows: strongShadows,
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                                const SizedBox(width: 6),
                                Container(
                                  padding: const EdgeInsets.all(2),
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: verifiedBlue,
                                    boxShadow: [
                                      BoxShadow(
                                        color: verifiedBlue.withOpacity(0.7),
                                        blurRadius: 8,
                                        spreadRadius: 1,
                                      ),
                                      const BoxShadow(
                                        color: Colors.black45,
                                        blurRadius: 4,
                                        offset: Offset(0, 1),
                                      ),
                                    ],
                                  ),
                                  child: const Icon(
                                    Icons.check_rounded,
                                    color: Colors.white,
                                    size: 13,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 7),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 12, vertical: 5),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.08),
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(
                                  color: Colors.white.withOpacity(0.35),
                                  width: 1.2,
                                ),
                              ),
                              child: Text(
                                role.toUpperCase(),
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                  letterSpacing: 1.2,
                                  height: 1.1,
                                  shadows: strongShadows,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.5),
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: Colors.white.withOpacity(0.55),
                            width: 1.3,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.white.withOpacity(0.08),
                              blurRadius: 10,
                              offset: const Offset(0, 3),
                            ),
                          ],
                        ),
                        child: const Icon(Icons.timer,
                            color: Colors.white, size: 24),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Expanded(
                          child: Container(
                              height: 1, color: platinum.withOpacity(0.25))),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.55),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                                color: platinum.withOpacity(0.25), width: 1),
                          ),
                          child: const Text(
                            "GHOSTCRASHER DASHBOARD",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: bmwChrome,
                              fontSize: 10,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 2,
                              height: 1.1,
                              shadows: strongShadows,
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                          child: Container(
                              height: 1, color: platinum.withOpacity(0.25))),
                    ],
                  ),
                  const SizedBox(height: 24),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildRealTimeStatChip(
                        icon: Icons.people,
                        value: isLoadingUsers ? '...' : '$totalUsers',
                        label: "Online Users",
                        color: liveGreen,
                        isLive: !isLoadingUsers && totalUsers > 0,
                      ),
                      _buildRealTimeStatChip(
                        icon: Icons.link,
                        value: senderConnected ? '1' : '0',
                        label: "Active Connections",
                        color: liveGreen,
                        isLive: senderConnected,
                      ),
                      _buildRealTimeStatChip(
                        icon: Icons.calendar_today,
                        value: expiredDate,
                        label: "Expiration",
                        color: const Color(0xFFFF9800),
                        isLive: false,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

// ─── Helper chip untuk welcome card ───
Widget _buildRealTimeStatChip({
  required IconData icon,
  required String value,
  required String label,
  required Color color,
  bool isLive = false,
}) {
  const Color liveGreen = Color(0xFF00E676);

  return Column(
    children: [
      Stack(
        alignment: Alignment.center,
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color.withOpacity(0.15),
              border: Border.all(color: color.withOpacity(0.4), width: 1.2),
            ),
            child: Icon(icon, color: color, size: 24),
          ),
          if (isLive)
            Positioned(
              top: 2,
              right: 2,
              child: Container(
                width: 10,
                height: 10,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: liveGreen,
                  boxShadow: [
                    BoxShadow(
                      color: liveGreen.withOpacity(0.8),
                      blurRadius: 6,
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
      const SizedBox(height: 6),
      Text(
        value,
        style: const TextStyle(
          color: bmwChrome,
          fontSize: 15,
          fontWeight: FontWeight.w800,
        ),
      ),
      Text(
        label,
        textAlign: TextAlign.center,
        style: TextStyle(
          color: bmwSilver.withOpacity(0.75),
          fontSize: 10,
          fontWeight: FontWeight.w500,
        ),
      ),
      if (isLive) ...[
        const SizedBox(height: 3),
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 6,
              height: 6,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: liveGreen,
                boxShadow: [
                  BoxShadow(
                    color: liveGreen.withOpacity(0.9),
                    blurRadius: 5,
                    spreadRadius: 0.5,
                  ),
                ],
              ),
            ),
            const SizedBox(width: 4),
            const Text(
              "LIVE",
              style: TextStyle(
                color: liveGreen,
                fontSize: 9,
                fontWeight: FontWeight.w800,
                letterSpacing: 1.2,
                height: 1.0,
              ),
            ),
          ],
        ),
      ],
    ],
  );
}
  //quick actions 
  Widget _buildAccountInfo() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: cardDark,
        borderRadius: BorderRadius.circular(20),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF141414), Color(0xFF0F1419), Color(0xFF1F1F1F)],
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.35),
            blurRadius: 15,
            offset: const Offset(0, 8),
          ),
          BoxShadow(
            color: bmwBlue.withOpacity(0.12),
            blurRadius: 5,
            spreadRadius: 1,
          ),
        ],
        border: Border.all(color: bmwYellow.withOpacity(0.15), width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(width: 4, height: 20, color: bmwBlue),
              const SizedBox(width: 4),
              Container(width: 4, height: 20, color: bmwLightBlue),
              const SizedBox(width: 4),
              Container(width: 4, height: 20, color: bmwRed),
              const SizedBox(width: 10),
              const Text(
                "Quick Actions",
                style: TextStyle(
                  color: bmwChrome,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  shadows: [
                    Shadow(color: Colors.black, blurRadius: 8),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 2,
            crossAxisSpacing: 16,
            mainAxisSpacing: 16,
            childAspectRatio: 1.2,
            children: [
              _buildActionCard(
                icon: Icons.build_circle_outlined,
                label: "Digital Tools",
                subtitle: "Show All Tools",
                gradient: const LinearGradient(
                  colors: [Color(0xFF0F1923), Color(0xFF0066B1)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ToolsPage(
                      sessionKey: sessionKey!,
                      username: username,
                      userRole: role,
                    ),
                  ),
                ),
              ),
              _buildActionCard(
                icon: FontAwesomeIcons.whatsapp,
                label: "Sender Manager",
                subtitle: "Add My Sender",
                gradient: const LinearGradient(
                  colors: [Color(0xFF0A3D1E), Color(0xFF1DB954)],
                ),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => BugSenderPage(
                      sessionKey: sessionKey!,
                      username: username,
                      role: role,
                    ),
                  ),
                ),
              ),
              _buildActionCard(
                icon: Icons.menu_book_rounded,
                label: "Al Qur-an",
                subtitle: "Baca Al-Quran",
                gradient: const LinearGradient(
                  colors: [Color(0xFF2A2A2A), Color(0xFF8B8B8B)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => AlQuranPage()),
                ),
              ),
              _buildActionCard(
                icon: Icons.sports_esports_rounded,
                label: "Play Games",
                subtitle: "Main Game Seru",
                gradient: const LinearGradient(
                  colors: [Color(0xFF7A0A0A), Color(0xFFE30613)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                onTap: () => _openGames(context),
              ),
              _buildActionCard(
                icon: FontAwesomeIcons.brain,
                label: "Ghost Ai Fix Code",
                subtitle: "Fix Code Memakai Ai",
                gradient: const LinearGradient(
                  colors: [Color(0xFF00695C), Color(0xFF26A69A)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => XNeuronChatPage(sessionKey: sessionKey!),
                  ),
                ),
              ),
              _buildActionCard(
                icon: FontAwesomeIcons.clapperboard,
                label: "Watching Dracin",
                subtitle: "Nonton Dracin Dll",
                gradient: const LinearGradient(
                  colors: [Color(0xFF996515), Color(0xFFFFD700)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => DracinPage()),
                ),
              ),
              _buildActionCard(
                icon: FontAwesomeIcons.music,
                label: "Music Player",
                subtitle: "Pemutar Musik",
                gradient: const LinearGradient(
                  colors: [Color(0xFF000000), Color(0xFF444444)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MusicPage()),
                ),
              ),
              _buildActionCard(
                icon: Icons.wifi_off_rounded,
                label: "WiFi Killer",
                subtitle: "Serang WiFi Lokal",
                gradient: const LinearGradient(
                  colors: [Color(0xFF4A0000), Color(0xFF8B0000)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => WifiKillerPage()),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: cardDarker.withOpacity(0.8),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: bmwYellow.withOpacity(0.2)),
            ),
            child: Row(
              children: [
                const Icon(Icons.info_outline, color: bmwYellow, size: 20),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    "New 8 features of the GhostCrasher application!",
                    style: TextStyle(color: bmwSilver.withOpacity(0.85), fontSize: 13),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionCard({
    required IconData icon,
    required String label,
    required String subtitle,
    required Gradient gradient,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          gradient: gradient,
          border: Border.all(color: bmwYellow.withOpacity(0.15), width: 1),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.4),
              blurRadius: 15,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Stack(
          children: [
            Positioned(
              right: -20,
              top: -20,
              child: Icon(icon, size: 80, color: bmwChrome.withOpacity(0.1)),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 45,
                    height: 45,
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.35),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: bmwYellow.withOpacity(0.3), width: 1),
                    ),
                    child: Icon(icon, color: bmwYellow, size: 24),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        label,
                        style: const TextStyle(
                          color: bmwChrome,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        subtitle,
                        style: TextStyle(
                          color: bmwChrome.withOpacity(0.8),
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // GAMES
  // ═══════════════════════════════════════════════════════════════
  void _openGames(BuildContext context) {
    _showCustomSheet(
      context,
      title: "Games & Puzzle",
      titleIcon: Icons.games_rounded,
      titleColor: bmwYellow,
      items: [
        _SheetItemData(
          icon: Icons.extension,
          iconColor: bmwYellow,
          title: "Puzzle Game",
          subtitle: "Susun gambar menjadi utuh.",
          onTap: _navigateToPuzzle,
        ),
        _SheetItemData(
          icon: Icons.quiz,
          iconColor: bmwLightBlue,
          title: "Teka Teki",
          subtitle: "Tebak kata & logika.",
          onTap: _navigateToTekaTeki,
        ),
        _SheetItemData(
          icon: Icons.psychology,
          iconColor: bmwLightBlue,
          title: "Tes IQ",
          subtitle: "Uji kecerdasan Anda.",
          onTap: _navigateToIQTest,
        ),
        _SheetItemData(
          icon: Icons.grid_on,
          iconColor: bmwYellow,
          title: "Ular Tangga",
          subtitle: "Game klasik ular tangga.",
          onTap: _navigateToUlarTangga,
        ),
        _SheetItemData(
          icon: Icons.extension,
          iconColor: bmwRed,
          title: "Memecahkan Misteri",
          subtitle: "Selesaikan kasus detektif.",
          onTap: _navigateToMystery,
        ),
        _SheetItemData(
          icon: Icons.games,
          iconColor: bmwYellow,
          title: "Catur",
          subtitle: "Main catur dengan 3 level kesulitan",
          onTap: _navigateToChess,
        ),
        _SheetItemData(
          icon: Icons.text_fields,
          iconColor: bmwLightBlue,
          title: "Tebak Kata",
          subtitle: "Sambung atau tebak kata yang benar",
          onTap: _navigateToWordGame,
        ),
        _SheetItemData(
          icon: Icons.grid_on,
          iconColor: bmwRed,
          title: "Teka Teki Silang",
          subtitle: "Isi teka‑teki silang",
          onTap: _navigateToCrossword,
        ),
        _SheetItemData(
          icon: Icons.code,
          iconColor: bmwYellow,
          title: "Kuis Pemrograman",
          subtitle: "Pilih kategori: JavaScript, HTML, Python",
          onTap: _navigateToProgrammingQuiz,
        ),
      ],
    );
  }

  void _navigateToPuzzle(BuildContext ctx) {
    Navigator.pop(ctx);
    Navigator.push(ctx, MaterialPageRoute(builder: (_) => const PuzzleGame()));
  }

  void _navigateToTekaTeki(BuildContext ctx) {
    Navigator.pop(ctx);
    Navigator.push(ctx, MaterialPageRoute(builder: (_) => const TekaTekiGame()));
  }

  void _navigateToIQTest(BuildContext ctx) {
    Navigator.pop(ctx);
    Navigator.push(ctx, MaterialPageRoute(builder: (_) => const IQTestGame()));
  }

  void _navigateToUlarTangga(BuildContext ctx) {
    Navigator.pop(ctx);
    Navigator.push(ctx, MaterialPageRoute(builder: (_) => const UlarTanggaGame()));
  }

  void _navigateToMystery(BuildContext ctx) {
    Navigator.pop(ctx);
    Navigator.push(ctx, MaterialPageRoute(builder: (_) => const MysteryGame()));
  }

  void _navigateToChess(BuildContext ctx) {
    Navigator.pop(ctx);
    Navigator.push(ctx, MaterialPageRoute(builder: (_) => const ChessGame()));
  }

  void _navigateToWordGame(BuildContext ctx) {
    Navigator.pop(ctx);
    Navigator.push(ctx, MaterialPageRoute(builder: (_) => const WordGame()));
  }

  void _navigateToCrossword(BuildContext ctx) {
    Navigator.pop(ctx);
    Navigator.push(ctx, MaterialPageRoute(builder: (_) => const CrosswordGame()));
  }

  void _navigateToProgrammingQuiz(BuildContext ctx) {
    Navigator.pop(ctx);
    Navigator.push(ctx, MaterialPageRoute(builder: (_) => const ProgrammingQuiz()));
  }

  // ═══════════════════════════════════════════════════════════════
  // NEWS SECTION (BMW)
  // ═══════════════════════════════════════════════════════════════
  Widget _buildNewsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Row(
            children: [
              const Icon(Icons.dashboard_customize_rounded, color: bmwYellow, size: 22),
              const SizedBox(width: 8),
              const Text(
                'LATEST UPDATES',
                style: TextStyle(
                  color: bmwChrome,
                  fontWeight: FontWeight.bold,
                  fontSize: 15,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1,
                ),
              ),
              const Spacer(),
              if (newsList.isNotEmpty)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: bmwYellow.withOpacity(0.15),
                    border: Border.all(color: bmwYellow.withOpacity(0.4)),
                  ),
                  child: Text(
                    '${newsList.length} Updates',
                    style: const TextStyle(
                      color: bmwYellow,
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              IconButton(
                icon: const Icon(Icons.refresh_rounded, color: bmwYellow, size: 18),
                onPressed: _fetchNews,
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(),
                splashRadius: 18,
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        if (newsList.isNotEmpty)
          SizedBox(
            height: 200,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 14),
              itemCount: newsList.length,
              itemBuilder: (ctx, i) => _buildNewsCard(newsList[i]),
            ),
          )
        else
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: Container(
              height: 120,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                color: kCardNews,
                border: Border.all(color: bmwYellow.withOpacity(0.2)),
              ),
              child: const Center(
                child: Text(
                  'No updates available',
                  style: TextStyle(color: bmwSilver),
                ),
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildNewsCard(dynamic item) {
    final imgUrl = item['image']?.toString() ?? '';
    final title = item['title']?.toString() ?? 'No Title';
    final desc = item['desc']?.toString() ?? '';
    final date = item['date']?.toString() ?? item['created_at']?.toString() ?? '';
    final cardWidth = (MediaQuery.of(context).size.width / 2) - 22;

    return Container(
      width: cardWidth,
      margin: const EdgeInsets.only(right: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        color: kCardNews,
        border: Border.all(color: bmwYellow.withOpacity(0.2)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            blurRadius: 12,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
            child: Stack(
              children: [
                Container(
                  height: 110,
                  width: double.infinity,
                  color: kCardAltNews,
                  child: imgUrl.isNotEmpty
                      ? CachedNetworkImage(
                          imageUrl: imgUrl,
                          fit: BoxFit.cover,
                          placeholder: (_, __) => Container(
                            color: kCardAltNews,
                            child: const Center(
                              child: SizedBox(
                                height: 24,
                                width: 24,
                                child: CircularProgressIndicator(
                                  color: bmwYellow,
                                  strokeWidth: 2,
                                ),
                              ),
                            ),
                          ),
                          errorWidget: (_, __, ___) => const Center(
                            child: Icon(Icons.image_not_supported,
                                color: bmwSilver, size: 30),
                          ),
                        )
                      : const Center(
                          child: Icon(Icons.article_rounded,
                              color: bmwSilver, size: 30),
                        ),
                ),
                Positioned(
                  top: 8,
                  right: 8,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.black.withOpacity(0.7),
                      border: Border.all(color: bmwYellow.withOpacity(0.7)),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: const [
                        Icon(Icons.circle_notifications_rounded,
                            color: bmwYellow, size: 10),
                        SizedBox(width: 3),
                        Text(
                          'NEW',
                          style: TextStyle(
                            color: bmwYellow,
                            fontSize: 9,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 10, 10, 6),
            child: Text(
              title,
              style: const TextStyle(
                color: bmwChrome,
                fontSize: 16,
                fontWeight: FontWeight.bold,
                fontFamily: 'Orbitron',
                height: 1.3,
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          if (desc.isNotEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Text(
                desc,
                style: const TextStyle(
                  color: bmwSilver,
                  fontSize: 11,
                  fontFamily: 'ShareTechMono',
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          const Spacer(),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 0, 10, 10),
            child: Row(
              children: [
                const Icon(Icons.access_time_rounded, color: bmwYellow, size: 11),
                const SizedBox(width: 4),
                if (date.isNotEmpty)
                  Expanded(
                    child: Text(
                      date.length > 10 ? date.substring(0, 10) : date,
                      style: const TextStyle(color: bmwSilver, fontSize: 10),
                    ),
                  ),
                Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    color: bmwYellow.withOpacity(0.18),
                  ),
                  child: const Icon(
                    Icons.arrow_forward_ios_rounded,
                    color: bmwYellow,
                    size: 9,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // BERITA SECTION
  // ═══════════════════════════════════════════════════════════════
  Widget _buildBeritaSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(width: 3, height: 14, color: bmwYellow),
                  const SizedBox(width: 8),
                  const Text(
                    'BERITA TERKINI',
                    style: TextStyle(
                      color: bmwChrome,
                      fontSize: 12,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.2,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                ],
              ),
              if (!_isLoadingBerita && _beritaList.isNotEmpty)
                const Text(
                  'Updates',
                  style: TextStyle(
                    color: bmwSilver,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                  ),
                ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        if (_isLoadingBerita)
          const Center(
            child: Padding(
              padding: EdgeInsets.symmetric(vertical: 40),
              child: CircularProgressIndicator(color: bmwYellow),
            ),
          )
        else if (_beritaList.isEmpty)
          const Center(
            child: Padding(
              padding: EdgeInsets.symmetric(vertical: 40),
              child: Text(
                'Tidak ada berita saat ini',
                style: TextStyle(color: bmwSilver, fontSize: 12),
              ),
            ),
          )
        else
          SizedBox(
            height: 180,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              itemCount: _beritaList.length > 5 ? 5 : _beritaList.length,
              itemBuilder: (context, index) {
                final news = _beritaList[index];
                final title = news['title'] ?? 'Judul tidak tersedia';
                final pubDate = news['pubDate'] ?? '';
                final link = news['link'] ?? '';

                String imageUrl = news['thumbnail'] ?? '';
                if (imageUrl.isEmpty && news['enclosure'] != null) {
                  imageUrl = news['enclosure']['link'] ?? '';
                }

                String formattedDate = '';
                try {
                  final date = DateTime.parse(pubDate);
                  formattedDate =
                      '${date.day} ${_getMonthName(date.month)} ${date.year}';
                } catch (_) {
                  formattedDate = pubDate;
                }

                return GestureDetector(
                  onTap: () => launchUrl(Uri.parse(link),
                      mode: LaunchMode.externalApplication),
                  child: Container(
                    width: 280,
                    margin: const EdgeInsets.only(right: 16),
                    decoration: BoxDecoration(
                      color: cardDark,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: bmwYellow.withOpacity(0.25), width: 0.8),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                      child: Stack(
                        fit: StackFit.expand,
                        children: [
                          imageUrl.isNotEmpty
                              ? CachedNetworkImage(
                                  imageUrl: imageUrl,
                                  fit: BoxFit.cover,
                                  placeholder: (context, url) => Container(
                                    color: cardDarker,
                                    child: const Center(
                                      child: SizedBox(
                                        height: 24,
                                        width: 24,
                                        child: CircularProgressIndicator(
                                          color: bmwYellow,
                                          strokeWidth: 2,
                                        ),
                                      ),
                                    ),
                                  ),
                                  errorWidget: (context, url, error) => Container(
                                    color: cardDarker,
                                    child: const Icon(Icons.image_not_supported,
                                        color: bmwSilver),
                                  ),
                                )
                              : Container(
                                  color: cardDarker,
                                  child: const Icon(Icons.article_outlined,
                                      color: bmwSilver, size: 40),
                                ),
                          Container(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: [
                                  Colors.transparent,
                                  Colors.black.withOpacity(0.6),
                                  Colors.black.withOpacity(0.95),
                                ],
                              ),
                            ),
                          ),
                          Positioned(
                            bottom: 16,
                            left: 16,
                            right: 16,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 8, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: bmwYellow.withOpacity(0.9),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: const Text(
                                    "TERBARU",
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 8,
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 0.5,
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  title,
                                  style: const TextStyle(
                                    color: bmwChrome,
                                    fontSize: 13,
                                    fontWeight: FontWeight.w700,
                                    height: 1.3,
                                  ),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                const SizedBox(height: 6),
                                Row(
                                  children: [
                                    const Icon(Icons.access_time_rounded,
                                        color: bmwSilver, size: 10),
                                    const SizedBox(width: 4),
                                    Text(
                                      formattedDate,
                                      style: const TextStyle(
                                          color: bmwSilver, fontSize: 10),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
      ],
    );
  }

  String _getMonthName(int month) {
    const months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun',
      'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'
    ];
    return months[month - 1];
  }

  // ═══════════════════════════════════════════════════════════════
  // HADITH SECTION
  // ═══════════════════════════════════════════════════════════════
  Widget _buildHadithSection() {
    if (_hadithLoading) {
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Container(
          height: 200,
          decoration: BoxDecoration(
            color: kCard,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: bmwYellow.withOpacity(0.2)),
          ),
          child: const Center(
              child: CircularProgressIndicator(color: bmwYellow, strokeWidth: 2)),
        ),
      );
    }

    final arabic = _hadith?['data']?['text']?['ar'] ??
        'لا تتركوا صلواتكم واحفظوها، فإذا ضاعت صلواتكم، ستفقدون كل شيء.';
    final indo = _hadith?['data']?['text']?['id'] ??
        'Jangan lah engkau tinggalkan sholat mu dan jagalah sholatmu, ketika kamu kehilangan sholat, kamu akan kehilangan segalanya.';
    final number = _hadith?['data']?['id']?.toString() ?? '1';
    final source = _hadith?['data']?['source']?.toString() ?? 'Muslim';
    final grade = _hadith?['data']?['grade']?.toString() ?? 'Sahih Muslim';

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: kCard,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: bmwYellow.withOpacity(0.25)),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withOpacity(0.45),
                blurRadius: 18,
                offset: const Offset(0, 8))
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: bmwYellow.withOpacity(0.18)),
                  child: const Center(
                      child: Icon(Icons.menu_book_rounded,
                          color: bmwYellow, size: 26)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('HADITS QUOTES',
                            style: TextStyle(
                              color: bmwChrome,
                              fontWeight: FontWeight.bold,
                              fontSize: 15,
                              fontFamily: 'Orbitron',
                              letterSpacing: 0.5,
                            )),
                        const SizedBox(height: 2),
                        Text('$grade · Tap card to read full',
                            style: const TextStyle(color: bmwSilver, fontSize: 11)),
                      ]),
                ),
              ],
            ),
            const SizedBox(height: 14),
            GestureDetector(
              onTap: () =>
                  _showHadithFullDialog(arabic, indo, source, number, grade),
              child: Column(
                children: [
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(14),
                      color: const Color(0xFF0F1923),
                      border: Border.all(color: bmwYellow.withOpacity(0.15)),
                    ),
                    child: Text(arabic,
                        textAlign: TextAlign.right,
                        textDirection: ui.TextDirection.rtl,
                        style: const TextStyle(
                            color: bmwChrome, fontSize: 17, height: 2.0)),
                  ),
                  const SizedBox(height: 10),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(14),
                        color: const Color(0xFF101418)),
                    child: Text(indo,
                        style: const TextStyle(
                          color: bmwSilver,
                          fontSize: 12,
                          fontStyle: FontStyle.italic,
                          height: 1.7,
                        ),
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: bmwYellow.withOpacity(0.55)),
                    color: bmwYellow.withOpacity(0.08),
                  ),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.receipt_long_rounded, color: bmwYellow, size: 13),
                    const SizedBox(width: 5),
                    Text('${source.isNotEmpty ? source : "Muslim"} #$number',
                        style: const TextStyle(
                            color: bmwYellow,
                            fontSize: 11,
                            fontWeight: FontWeight.bold)),
                  ]),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: _fetchRandomHadith,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: bmwSilver.withOpacity(0.35)),
                    ),
                    child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.touch_app_rounded, color: bmwSilver, size: 14),
                          SizedBox(width: 4),
                          Text('Tap card',
                              style: TextStyle(color: bmwSilver, fontSize: 11)),
                        ]),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showHadithFullDialog(String arabic, String indo, String source,
      String number, String grade) {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
        child: Container(
          decoration: BoxDecoration(
            color: kCard,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: bmwYellow.withOpacity(0.35)),
            boxShadow: [
              BoxShadow(
                  color: bmwYellow.withOpacity(0.10),
                  blurRadius: 30,
                  spreadRadius: 2),
              BoxShadow(
                  color: Colors.black.withOpacity(0.7),
                  blurRadius: 20,
                  offset: const Offset(0, 8)),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  borderRadius:
                      const BorderRadius.vertical(top: Radius.circular(24)),
                  color: bmwYellow.withOpacity(0.10),
                  border: Border(
                      bottom: BorderSide(color: bmwYellow.withOpacity(0.3))),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 42,
                      height: 42,
                      decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: bmwYellow.withOpacity(0.25)),
                      child: const Icon(Icons.menu_book_rounded,
                          color: bmwYellow, size: 22),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('HADITS QUOTES LENGKAP',
                                style: TextStyle(
                                    color: bmwChrome,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 14,
                                    fontFamily: 'Orbitron')),
                            Text(grade,
                                style: const TextStyle(
                                    color: bmwSilver, fontSize: 11)),
                          ]),
                    ),
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        width: 34,
                        height: 34,
                        decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: bmwChrome.withOpacity(0.08)),
                        child: const Icon(Icons.close_rounded,
                            color: bmwSilver, size: 18),
                      ),
                    ),
                  ],
                ),
              ),
              ConstrainedBox(
                constraints: BoxConstraints(
                    maxHeight: MediaQuery.of(context).size.height * 0.62),
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(18),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          color: const Color(0xFF0F1923),
                          border: Border.all(color: bmwYellow.withOpacity(0.2)),
                        ),
                        child: Text(
                          arabic,
                          textAlign: TextAlign.right,
                          textDirection: ui.TextDirection.rtl,
                          style: const TextStyle(
                              color: bmwChrome, fontSize: 19, height: 2.2),
                        ),
                      ),
                      const SizedBox(height: 14),
                      Row(children: [
                        Container(width: 3, height: 18, color: bmwYellow),
                        const SizedBox(width: 8),
                        const Text(
                          'ARTINYA:',
                          style: TextStyle(
                              color: bmwYellow,
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1.2),
                        ),
                      ]),
                      const SizedBox(height: 10),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          color: const Color(0xFF101418),
                          border: Border.all(color: bmwYellow.withOpacity(0.15)),
                        ),
                        child: Text(
                          indo,
                          style: const TextStyle(
                              color: bmwChrome,
                              fontSize: 14,
                              fontStyle: FontStyle.italic,
                              height: 1.8),
                        ),
                      ),
                      const SizedBox(height: 16),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 8),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: bmwYellow.withOpacity(0.6)),
                          color: bmwYellow.withOpacity(0.08),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.receipt_long_rounded,
                                color: bmwYellow, size: 14),
                            const SizedBox(width: 6),
                            Text(
                              '${source.isNotEmpty ? source : "Muslim"} #$number',
                              style: const TextStyle(
                                  color: bmwYellow,
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _fetchRandomHadith() async {
    setState(() => _hadithLoading = true);

    try {
      final response = await http.get(
        Uri.parse("https://api.hadith.sutanlab.id/books/muslim/random"),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          _hadith = data;
          _hadithLoading = false;
        });
      } else {
        _setFallbackHadith();
      }
    } catch (e) {
      debugPrint('Error fetch hadith: $e');
      _setFallbackHadith();
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // WEATHER CARD
  // ═══════════════════════════════════════════════════════════════
  Widget _buildWeatherCard() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF1F1F1F), Color(0xFF0F1419)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: bmwYellow.withOpacity(0.25), width: 1),
        boxShadow: [
          BoxShadow(
            color: bmwYellow.withOpacity(0.10),
            blurRadius: 20,
            spreadRadius: 0,
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: bmwYellow.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: bmwYellow.withOpacity(0.3)),
                  ),
                  child: const Icon(Icons.wb_sunny, color: bmwYellow, size: 18),
                ),
                const SizedBox(width: 10),
                const Text(
                  "WEATHER",
                  style: TextStyle(
                    color: bmwChrome,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                  ),
                ),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: bmwYellow.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: bmwYellow.withOpacity(0.3), width: 1),
                  ),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                      value: _selectedCity,
                      dropdownColor: const Color(0xFF141414),
                      icon: const Icon(Icons.arrow_drop_down, color: bmwYellow, size: 20),
                      style: const TextStyle(
                        color: bmwChrome,
                        fontSize: 12,
                        fontFamily: 'Orbitron',
                      ),
                      onChanged: (String? newValue) async {
                        if (newValue != null) {
                          final city = _cities.firstWhere((c) => c['name'] == newValue);
                          setState(() {
                            _selectedCity = newValue;
                            _cityLat = city['lat'];
                            _cityLon = city['lon'];
                            _weatherCity = newValue;
                          });
                          await Future.microtask(() {});
                          _fetchWeather();
                        }
                      },
                      items: _cities.map<DropdownMenuItem<String>>((city) {
                        return DropdownMenuItem<String>(
                          value: city['name'],
                          child: Text(
                            city['name'],
                            style: const TextStyle(color: bmwChrome, fontSize: 12),
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                GestureDetector(
                  onTap: _fetchWeather,
                  child: Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: bmwYellow.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: bmwYellow.withOpacity(0.3)),
                    ),
                    child: const Icon(Icons.refresh, color: bmwYellow, size: 14),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            if (_isLoadingWeather)
              _buildWeatherDummy()
            else
              Row(
                children: [
                  Container(
                    width: 70,
                    height: 70,
                    decoration: BoxDecoration(
                      gradient: RadialGradient(
                        colors: [bmwYellow.withOpacity(0.25), Colors.transparent],
                      ),
                      shape: BoxShape.circle,
                    ),
                    child: Center(
                      child: Text(_weatherIcon, style: const TextStyle(fontSize: 48)),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _weatherTemperature,
                          style: const TextStyle(
                            color: bmwChrome,
                            fontSize: 32,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                        Text(
                          _weatherCity,
                          style: const TextStyle(
                            color: bmwYellow,
                            fontSize: 14,
                            fontFamily: 'ShareTechMono',
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          _weatherCondition,
                          style: TextStyle(
                            color: bmwSilver.withOpacity(0.8),
                            fontSize: 11,
                            fontFamily: 'ShareTechMono',
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: const Color(0xFF0F1923),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: bmwYellow.withOpacity(0.3), width: 1),
                    ),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            const Icon(Icons.water_drop, color: bmwYellow, size: 12),
                            const SizedBox(width: 4),
                            Text(
                              "$_weatherHumidity%",
                              style: const TextStyle(
                                color: bmwChrome,
                                fontSize: 12,
                                fontFamily: 'ShareTechMono',
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Row(
                          children: [
                            const Icon(Icons.air, color: bmwYellow, size: 12),
                            const SizedBox(width: 4),
                            Text(
                              "${_weatherWindSpeed.toStringAsFixed(1)} km/h",
                              style: const TextStyle(
                                color: bmwChrome,
                                fontSize: 12,
                                fontFamily: 'ShareTechMono',
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildWeatherDummy() {
    return Row(
      children: [
        Container(
          width: 70,
          height: 70,
          decoration: BoxDecoration(
            gradient: RadialGradient(
              colors: [bmwYellow.withOpacity(0.25), Colors.transparent],
            ),
            shape: BoxShape.circle,
          ),
          child: const Center(child: Text("🌤️", style: TextStyle(fontSize: 48))),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "28°C",
                style: TextStyle(
                  color: bmwChrome,
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                ),
              ),
              Text(
                _selectedCity,
                style: const TextStyle(
                  color: bmwYellow,
                  fontSize: 14,
                  fontFamily: 'ShareTechMono',
                ),
              ),
              const SizedBox(height: 4),
              Text(
                "Cerah Berawan",
                style: TextStyle(
                  color: bmwSilver.withOpacity(0.8),
                  fontSize: 11,
                  fontFamily: 'ShareTechMono',
                ),
              ),
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: const Color(0xFF0F1923),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: bmwYellow.withOpacity(0.3), width: 1),
          ),
          child: Column(
            children: [
              Row(
                children: const [
                  Icon(Icons.water_drop, color: bmwYellow, size: 12),
                  SizedBox(width: 4),
                  Text(
                    "65%",
                    style: TextStyle(
                      color: bmwChrome,
                      fontSize: 12,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Row(
                children: const [
                  Icon(Icons.air, color: bmwYellow, size: 12),
                  SizedBox(width: 4),
                  Text(
                    "12.5 km/h",
                    style: TextStyle(
                      color: bmwChrome,
                      fontSize: 12,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // SOCIAL — BMW style
  // ═══════════════════════════════════════════════════════════════
  Widget buildConnectWithTeam() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: bmwYellow.withOpacity(0.25), width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.55),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
          BoxShadow(
            color: bmwBlue.withOpacity(0.12),
            blurRadius: 10,
            spreadRadius: 1,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Stack(
          children: [
            Positioned.fill(
              child: Image.asset(
                'assets/images/sosial.jpg',
                fit: BoxFit.cover,
                alignment: Alignment.center,
                errorBuilder: (context, error, stackTrace) {
                  return Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [Color(0xFF141414), Color(0xFF0F1419), Color(0xFF1F1F1F)],
                      ),
                    ),
                  );
                },
              ),
            ),
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.black.withOpacity(0.55),
                      Colors.black.withOpacity(0.72),
                      Colors.black.withOpacity(0.90),
                    ],
                    stops: const [0.0, 0.5, 1.0],
                  ),
                ),
              ),
            ),
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      bmwYellow.withOpacity(0.10),
                      Colors.transparent,
                      bmwBlue.withOpacity(0.15),
                    ],
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: const [
                      Icon(Icons.wifi_tethering, color: bmwYellow),
                      SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          "SOCIAL MEDIA CREATOR APPS",
                          style: TextStyle(
                            color: bmwChrome,
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                            letterSpacing: 1,
                            shadows: [
                              Shadow(color: Colors.black87, blurRadius: 6),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _buildSocialButton(
                        icon: FontAwesomeIcons.telegram,
                        label: "Telegram",
                        color: bmwLightBlue,
                        link: "https://t.me/ghostcrasher18",
                      ),
                      _buildSocialButton(
                        icon: FontAwesomeIcons.youtube,
                        label: "YouTube",
                        color: bmwRed,
                        link: "https://youtube.com/@skylinne18",
                      ),
                      _buildSocialButton(
                        icon: FontAwesomeIcons.tiktok,
                        label: "TikTok",
                        color: bmwChrome,
                        link: "tiktok.com/@skylinne18",
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Center(
                    child: Text(
                      "All Social Media Creator of the GhostCrasher Application",
                      style: TextStyle(
                        color: bmwChrome.withOpacity(0.9),
                        fontSize: 13,
                        shadows: const [
                          Shadow(color: Colors.black87, blurRadius: 4),
                        ],
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSocialButton({
    required IconData icon,
    required String label,
    required Color color,
    required String link,
  }) {
    return GestureDetector(
      onTap: () => openLink(link),
      child: Column(
        children: [
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.black.withOpacity(0.45),
              border: Border.all(color: color.withOpacity(0.8), width: 1.5),
              boxShadow: [
                BoxShadow(
                  color: color.withOpacity(0.4),
                  blurRadius: 15,
                  spreadRadius: 1,
                ),
                BoxShadow(
                  color: Colors.black.withOpacity(0.35),
                  blurRadius: 8,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: ClipOval(
              child: BackdropFilter(
                filter: ui.ImageFilter.blur(sigmaX: 6, sigmaY: 6),
                child: Container(
                  color: color.withOpacity(0.12),
                  child: Icon(
                    icon,
                    color: color,
                    size: 30,
                    shadows: [
                      Shadow(
                        color: Colors.black.withOpacity(0.5),
                        blurRadius: 6,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            label,
            style: const TextStyle(
              color: bmwChrome,
              fontSize: 12,
              fontWeight: FontWeight.w600,
              shadows: [
                Shadow(color: Colors.black87, blurRadius: 4),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // RECENT ACTIVITY
  // ═══════════════════════════════════════════════════════════════
  Widget _buildRecentActivity() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardDark,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: bmwYellow.withOpacity(0.2), width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 15,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: const [
                  Icon(Icons.history_rounded, color: bmwYellow, size: 20),
                  SizedBox(width: 10),
                  Text(
                    "RECENT ACTIVITY",
                    style: TextStyle(
                      color: bmwChrome,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      fontFamily: "Orbitron",
                    ),
                  ),
                ],
              ),
              TextButton(
                onPressed: () {
                  setState(() {
                    _selectedTabIndex = 3;
                    _selectedPage = _buildActivityLogsPage();
                  });
                },
                child: const Text(
                  "View All",
                  style: TextStyle(color: bmwYellow, fontSize: 12),
                ),
              ),
            ],
          ),
          const SizedBox(height: 15),
          if (_isLoadingActivityLogs)
            Container(
              height: 80,
              decoration: BoxDecoration(
                color: cardDarker.withOpacity(0.8),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Center(
                  child: CircularProgressIndicator(color: bmwYellow, strokeWidth: 2)),
            )
          else if (_activityLogs.isEmpty)
            Container(
              height: 80,
              decoration: BoxDecoration(
                color: cardDarker.withOpacity(0.8),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Center(
                child: Text(
                  "No activity",
                  style: TextStyle(color: bmwSilver, fontSize: 14),
                ),
              ),
            )
          else
            ..._activityLogs.take(3).map((log) {
              final timestamp =
                  DateTime.tryParse(log['timestamp'] ?? '') ?? DateTime.now();
              final formattedTime = _formatDateTime(timestamp);

              return Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: cardDarker.withOpacity(0.8),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: _getActivityColor(log['activity']).withOpacity(0.35),
                    width: 1,
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: _getActivityColor(log['activity']).withOpacity(0.2),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Icon(
                        _getActivityIcon(log['activity']),
                        color: _getActivityColor(log['activity']),
                        size: 16,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            log['activity'] ?? 'Unknown',
                            style: const TextStyle(
                              color: bmwChrome,
                              fontWeight: FontWeight.w500,
                              fontSize: 13,
                            ),
                          ),
                          if (log['details'] != null &&
                              log['details']['target'] != null)
                            Text(
                              "${log['details']['target']}",
                              style: const TextStyle(
                                color: bmwSilver,
                                fontSize: 11,
                              ),
                            ),
                        ],
                      ),
                    ),
                    Text(
                      formattedTime,
                      style: const TextStyle(color: bmwSilver, fontSize: 11),
                    ),
                  ],
                ),
              );
            }).toList(),
        ],
      ),
    );
  }

  Widget _buildActivityLogsPage() {
    return RefreshIndicator(
      color: bmwYellow,
      onRefresh: () async {
        await _fetchActivityLogs();
      },
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: cardDark,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: bmwYellow.withOpacity(0.2), width: 1),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: bmwYellow.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: bmwYellow.withOpacity(0.4)),
                  ),
                  child: const Icon(Icons.history, color: bmwYellow, size: 24),
                ),
                const SizedBox(width: 15),
                const Text(
                  "Activity History",
                  style: TextStyle(
                    color: bmwChrome,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    fontFamily: "Orbitron",
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          if (_isLoadingActivityLogs)
            const Center(child: CircularProgressIndicator(color: bmwYellow))
          else if (_activityLogs.isEmpty)
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: cardDark,
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Center(
                child: Text(
                  "Tidak ada aktivitas",
                  style: TextStyle(color: bmwSilver, fontSize: 16),
                ),
              ),
            )
          else
            ..._activityLogs.map((log) {
              final timestamp =
                  DateTime.tryParse(log['timestamp'] ?? '') ?? DateTime.now();
              final formattedTime = _formatDateTime(timestamp);

              return Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: cardDarker.withOpacity(0.8),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: _getActivityColor(log['activity']).withOpacity(0.35),
                    width: 1,
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: _getActivityColor(log['activity'])
                                .withOpacity(0.15),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Icon(
                            _getActivityIcon(log['activity']),
                            color: _getActivityColor(log['activity']),
                            size: 18,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                log['activity'] ?? 'Unknown Activity',
                                style: const TextStyle(
                                  color: bmwChrome,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              if (log['details'] != null &&
                                  log['details']['target'] != null)
                                Text(
                                  "Target: ${log['details']['target']}",
                                  style: const TextStyle(
                                    color: bmwSilver,
                                    fontSize: 12,
                                  ),
                                ),
                            ],
                          ),
                        ),
                        Text(
                          formattedTime,
                          style: const TextStyle(color: bmwSilver, fontSize: 12),
                        ),
                      ],
                    ),
                  ],
                ),
              );
            }).toList(),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // NEWS PAGE (HOME)
  // ═══════════════════════════════════════════════════════════════
  Widget _buildNewsPage() {
    return FadeTransition(
      opacity: _fadeAnimation,
      child: RefreshIndicator(
        color: bmwYellow,
        onRefresh: () async {
          await _fetchActivityLogs();
          await _fetchWeather();
          await _fetchNews();
          await _fetchRandomHadith();
          await fetchTotalUsers();
          await checkSenderStatus();
          await _fetchBerita();
          setState(() {});
        },
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(),
          slivers: [
            SliverAppBar(
              expandedHeight: 220,
              backgroundColor: Colors.transparent,
              automaticallyImplyLeading: false,
              flexibleSpace: FlexibleSpaceBar(
                collapseMode: CollapseMode.parallax,
                background: Container(
                  decoration: const BoxDecoration(color: Color(0xFF05080D)),
                  child: Stack(
                    children: [
                      Positioned.fill(
                        child: Image.asset(
                          'assets/images/halo.jpg',
                          fit: BoxFit.cover,
                          alignment: Alignment.center,
                          errorBuilder: (context, error, stackTrace) =>
                              Container(color: Colors.black),
                        ),
                      ),
                      Positioned.fill(
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [
                                Colors.black.withOpacity(0.3),
                                Colors.black.withOpacity(0.65),
                                Colors.black.withOpacity(0.92),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        top: 0,
                        left: 0,
                        child: Row(
                          children: [
                            Container(width: 60, height: 3, color: bmwBlue),
                            Container(width: 60, height: 3, color: bmwLightBlue),
                            Container(width: 60, height: 3, color: bmwRed),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildWelcomeCard(),
                    const SizedBox(height: 24),
                    carousel.CarouselSlider.builder(
                      options: carousel.CarouselOptions(
                        height: 190,
                        aspectRatio: 16 / 9,
                        viewportFraction: 0.78,
                        initialPage: 0,
                        enableInfiniteScroll: true,
                        autoPlay: false,
                        enlargeCenterPage: true,
                        enlargeFactor: 0.22,
                        scrollDirection: Axis.horizontal,
                      ),
                      itemCount: 3,
                      itemBuilder: (context, index, realIndex) {
                        final actions = [
                          _ModernActionCard(
                            title: "Join Telegram",
                            subtitle: "Official Channel",
                            icon: FontAwesomeIcons.telegram,
                            iconColor: Colors.white,
                            gradient: const LinearGradient(
                              colors: [
                                Color(0xFF0066B1),
                                Color(0xFF1C69D4),
                                Color(0xFF4FC3F7),
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            onTap: () async {
                              final Uri telegramUrl =
                                  Uri.parse("https://t.me/ghostcrasher18");
                              if (await canLaunchUrl(telegramUrl)) {
                                await launchUrl(
                                  telegramUrl,
                                  mode: LaunchMode.externalApplication,
                                );
                              }
                            },
                            index: index,
                          ),
                          _ModernActionCard(
                            title: "Thanks To",
                            subtitle: "Special Thanks My Friend",
                            icon: Icons.groups_rounded,
                            iconColor: Colors.black,
                            gradient: const LinearGradient(
                              colors: [
                                Color(0xFFB8860B),
                                Color(0xFFFFD700),
                                Color(0xFFFFEB3B),
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            onTap: () {
                              Navigator.push(
                                context,
                                PageRouteBuilder(
                                  pageBuilder: (_, __, ___) =>
                                      const ThanksToPage(),
                                  transitionsBuilder:
                                      (_, animation, __, child) {
                                    final curvedAnimation = CurvedAnimation(
                                      parent: animation,
                                      curve: Curves.easeInOut,
                                    );
                                    return FadeTransition(
                                      opacity: curvedAnimation,
                                      child: ScaleTransition(
                                        scale: Tween<double>(
                                                begin: 0.9, end: 1.0)
                                            .animate(curvedAnimation),
                                        child: child,
                                      ),
                                    );
                                  },
                                  transitionDuration:
                                      const Duration(milliseconds: 400),
                                ),
                              );
                            },
                            index: index,
                          ),
                          _ModernActionCard(
                            title: "Toko GhostCrasher",
                            subtitle: "Buy Account & Up Role",
                            icon: Icons.storefront_rounded,
                            iconColor: Colors.white,
                            gradient: const LinearGradient(
                              colors: [
                                Color(0xFF7A0A0A),
                                Color(0xFFB71C1C),
                                Color(0xFFE30613),
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            onTap: () {
                              Navigator.push(
                                context,
                                PageRouteBuilder(
                                  pageBuilder: (_, __, ___) =>
                                      const BuyAccountPage(),
                                  transitionsBuilder:
                                      (_, animation, __, child) {
                                    final curvedAnimation = CurvedAnimation(
                                      parent: animation,
                                      curve: Curves.easeInOut,
                                    );
                                    return FadeTransition(
                                      opacity: curvedAnimation,
                                      child: ScaleTransition(
                                        scale: Tween<double>(
                                                begin: 0.9, end: 1.0)
                                            .animate(curvedAnimation),
                                        child: child,
                                      ),
                                    );
                                  },
                                  transitionDuration:
                                      const Duration(milliseconds: 400),
                                ),
                              );
                            },
                            index: index,
                          ),
                        ];
                        return actions[index];
                      },
                    ),
                    const SizedBox(height: 24),
                    _buildAccountInfo(),
                    const SizedBox(height: 24),
                    _buildNewsSection(),
                    const SizedBox(height: 24),
                    _buildWeatherCard(),
                    const SizedBox(height: 24),
                    const JadwalSholat(),
                    const SizedBox(height: 24),
                    _buildBeritaSection(),
                    const SizedBox(height: 24),
                    _buildHadithSection(),
                    const SizedBox(height: 24),
                    _buildRecentActivity(),
                    const SizedBox(height: 24),
                    buildConnectWithTeam(),
                    const SizedBox(height: 24),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Color _getActivityColor(String activity) {
    switch (activity.toLowerCase()) {
      case 'login':         return const Color(0xFF00A651);
      case 'logout':        return bmwRed;
      case 'send_bug':      return bmwYellow;
      case 'raid_group':    return bmwLightBlue;
      case 'create_account':return bmwBlue;
      case 'login_failed':  return bmwRed;
      default:              return bmwSilver;
    }
  }

  IconData _getActivityIcon(String activity) {
    switch (activity.toLowerCase()) {
      case 'login':         return Icons.login_rounded;
      case 'logout':        return Icons.logout_rounded;
      case 'send_bug':      return Icons.send_rounded;
      case 'raid_group':    return Icons.group_rounded;
      case 'create_account':return Icons.person_add_rounded;
      case 'login_failed':  return Icons.error_rounded;
      default:              return Icons.circle_rounded;
    }
  }

  String _formatDateTime(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);

    if (difference.inDays > 0) {
      return DateFormat('dd/MM HH:mm').format(date);
    } else if (difference.inHours > 0) {
      return '${difference.inHours}h ago';
    } else if (difference.inMinutes > 0) {
      return '${difference.inMinutes}m ago';
    } else {
      return 'Just now';
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // DRAWER — BMW Garage
  // ═══════════════════════════════════════════════════════════════
  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: cardDarker,
      child: SafeArea(
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              width: double.infinity,
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFF0F1419), Color(0xFF05080D)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(width: 40, height: 3, color: bmwBlue),
                      Container(width: 40, height: 3, color: bmwLightBlue),
                      Container(width: 40, height: 3, color: bmwRed),
                    ],
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    "GHOST CRASHER APPS",
                    style: TextStyle(
                      color: bmwChrome,
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                  const SizedBox(height: 16),
                  _buildDrawerInfo("User:", username),
                  _buildDrawerInfo("Role:", role),
                  _buildDrawerInfo("Expired:", expiredDate),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 8),
                physics: const BouncingScrollPhysics(),
                children: [
                  _buildDrawerItem(
                    icon: Icons.person,
                    label: "My Info",
                    onTap: () {
                      if (sessionKey == null) return;
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => MyInfoPage(
                            username: username,
                            password: password,
                            role: role,
                            expiredDate: expiredDate,
                            sessionKey: sessionKey!,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildDrawerItem(
                    icon: Icons.history_rounded,
                    label: "Riwayat Aktivitas",
                    onTap: () {
                      Navigator.pop(context);
                      if (sessionKey != null) {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => RiwayatPage(sessionKey: sessionKey!, role: role),
                          ),
                        );
                      }
                    },
                  ),
                  _buildSectionHeader("AMBIL LINK GROUP"),
                  if (_isRoleAllowed([
                    'member', 'reseller', 'admin', 'owner',
                    'moderator', 'staff', 'developer',
                  ]))
                    _buildGbItem(
                      icon: Icons.cloud_upload_rounded,
                      label: "Link FullUp GB",
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => FullUpGbScreen(
                              username: username,
                              password: password,
                              role: role,
                              expiredDate: expiredDate,
                              sessionKey: sessionKey ?? '',
                              listBug: listBug,
                              listDoos: listDoos,
                              news: news,
                            ),
                          ),
                        );
                      },
                    ),
                  if (_isRoleAllowed([
                    'reseller', 'admin', 'owner', 'moderator',
                    'staff', 'developer',
                  ]))
                    _buildGbItem(
                      icon: Icons.storefront_rounded,
                      label: "Link Reseller GB",
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => ResellerGbScreen(
                              username: username,
                              password: password,
                              role: role,
                              expiredDate: expiredDate,
                              sessionKey: sessionKey ?? '',
                              listBug: listBug,
                              listDoos: listDoos,
                              news: news,
                            ),
                          ),
                        );
                      },
                    ),
                  if (_isRoleAllowed(
                      ['admin', 'owner', 'moderator', 'staff', 'developer']))
                    _buildGbItem(
                      icon: Icons.admin_panel_settings_rounded,
                      label: "Link Admin GB",
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => AdminGbScreen(
                              username: username,
                              password: password,
                              role: role,
                              expiredDate: expiredDate,
                              sessionKey: sessionKey ?? '',
                              listBug: listBug,
                              listDoos: listDoos,
                              news: news,
                            ),
                          ),
                        );
                      },
                    ),
                  if (_isRoleAllowed(
                      ['owner', 'moderator', 'staff', 'developer']))
                    _buildGbItem(
                      icon: Icons.workspace_premium_rounded,
                      label: "Link Owner GB",
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => OwnerGbScreen(
                              username: username,
                              password: password,
                              role: role,
                              expiredDate: expiredDate,
                              sessionKey: sessionKey ?? '',
                              listBug: listBug,
                              listDoos: listDoos,
                              news: news,
                            ),
                          ),
                        );
                      },
                    ),
                  if (_isRoleAllowed(['moderator', 'staff', 'developer']))
                    _buildGbItem(
                      icon: Icons.shield_rounded,
                      label: "Link Moderator GB",
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => ModeratorGbScreen(
                              username: username,
                              password: password,
                              role: role,
                              expiredDate: expiredDate,
                              sessionKey: sessionKey ?? '',
                              listBug: listBug,
                              listDoos: listDoos,
                              news: news,
                            ),
                          ),
                        );
                      },
                    ),
                  if (_isRoleAllowed(['staff', 'developer']))
                    _buildGbItem(
                      icon: Icons.badge_rounded,
                      label: "Link Staff GB",
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => StaffGbScreen(
                              username: username,
                              password: password,
                              role: role,
                              expiredDate: expiredDate,
                              sessionKey: sessionKey ?? '',
                              listBug: listBug,
                              listDoos: listDoos,
                              news: news,
                            ),
                          ),
                        );
                      },
                    ),
                  _buildSectionHeader("LAINNYA"),
                  _buildDrawerItem(
                    icon: Icons.group,
                    label: "Thanks To",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const ThanksToPage()),
                      );
                    },
                  ),
                  _buildDrawerItem(
                    icon: Icons.logout,
                    label: "Logout",
                    onTap: () async {
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.clear();
                      if (!context.mounted) return;
                      Navigator.of(context).pushAndRemoveUntil(
                        MaterialPageRoute(builder: (_) => const LoginPage()),
                        (route) => false,
                      );
                    },
                  ),
                  const SizedBox(height: 16),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: Row(
        children: [
          Container(
            width: 3,
            height: 14,
            color: bmwYellow,
            margin: const EdgeInsets.only(right: 8),
          ),
          Text(
            title,
            style: const TextStyle(
              color: bmwYellow,
              fontSize: 11,
              fontWeight: FontWeight.w600,
              letterSpacing: 1.2,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGbItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return ListTile(
      leading: Container(
        width: 36,
        height: 36,
        decoration: BoxDecoration(
          color: bmwYellow.withOpacity(0.10),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: bmwYellow.withOpacity(0.35), width: 1),
        ),
        child: Icon(icon, color: bmwYellow, size: 18),
      ),
      title: Text(
        label,
        style: const TextStyle(
          color: bmwChrome,
          fontSize: 14,
          fontWeight: FontWeight.w500,
        ),
      ),
      trailing: const Icon(
        Icons.arrow_forward_ios_rounded,
        color: bmwSilver,
        size: 12,
      ),
      onTap: onTap,
    );
  }

  Widget _buildDrawerInfo(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        children: [
          Text(
            label,
            style: TextStyle(color: bmwSilver.withOpacity(0.7), fontSize: 13),
          ),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                color: bmwChrome,
                fontSize: 13,
                fontWeight: FontWeight.w500,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return ListTile(
      leading: Icon(icon, color: bmwYellow, size: 22),
      title: Text(
        label,
        style: const TextStyle(color: bmwChrome, fontSize: 15),
      ),
      trailing: const Icon(
        Icons.chevron_right,
        color: bmwSilver,
        size: 20,
      ),
      onTap: onTap,
      hoverColor: bmwYellow.withOpacity(0.05),
      splashColor: bmwYellow.withOpacity(0.1),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // FLOATING BUG
  // ═══════════════════════════════════════════════════════════════
  void _showFloatingBugMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [cardDark, cardDarker],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
          border: Border.all(color: bmwYellow.withOpacity(0.35)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              "Floating Bug",
              style: TextStyle(
                color: bmwChrome,
                fontSize: 20,
                fontWeight: FontWeight.bold,
                fontFamily: 'Orbitron',
              ),
            ),
            const SizedBox(height: 20),
            ListTile(
              leading: const Icon(Icons.android, color: bmwYellow),
              title: const Text(
                "Di Dalam Aplikasi",
                style: TextStyle(color: bmwChrome),
              ),
              subtitle: Text(
                "Muncul di dalam APK",
                style: TextStyle(color: bmwSilver.withOpacity(0.7)),
              ),
              onTap: () {
                Navigator.pop(context);
                FloatingBugService().toggleEnabled();
              },
            ),
            const Divider(color: Colors.white24),
            ListTile(
              leading: const Icon(Icons.chat_bubble, color: bmwLightBlue),
              title: const Text(
                "Di Luar Aplikasi",
                style: TextStyle(color: bmwChrome),
              ),
              subtitle: Text(
                "Muncul di semua layar",
                style: TextStyle(color: bmwSilver.withOpacity(0.7)),
              ),
              onTap: () {
                Navigator.pop(context);
                _toggleFloatingBagger();
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _toggleFloatingBagger() async {
    final hasPermission = await FloatingBagger.checkOverlayPermission();
    if (!hasPermission) {
      final granted = await FloatingBagger.requestOverlayPermission();
      if (!granted) {
        _showAlert("❌ Izin Ditolak",
            "Aktifkan izin 'Tampilkan di atas aplikasi lain' di pengaturan");
        return;
      }
    }

    final prefs = await SharedPreferences.getInstance();
    final isServiceRunning =
        prefs.getBool('floating_bagger_running') ?? false;

    if (isServiceRunning) {
      await FloatingBagger.stopService();
      await prefs.setBool('floating_bagger_running', false);
      setState(() => _isFloatingBaggerActive = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Floating Bagger Dimatikan")),
      );
    } else {
      await FloatingBagger.startService(
        username: username,
        password: password,
        sessionKey: sessionKey!,
        role: role,
        expiredDate: expiredDate,
      );
      await prefs.setBool('floating_bagger_running', true);
      setState(() => _isFloatingBaggerActive = true);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Floating Bagger Diaktifkan")),
      );
    }
  }

  void _showAlert(String title, String msg) {
    final bool isSuccess = title.contains("✅");

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return BackdropFilter(
          filter: ui.ImageFilter.blur(sigmaX: 15, sigmaY: 15),
          child: Dialog(
            backgroundColor: Colors.transparent,
            insetPadding: const EdgeInsets.all(24),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(28),
              child: BackdropFilter(
                filter: ui.ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                child: Container(
                  padding: const EdgeInsets.all(32),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        cardDark.withOpacity(0.95),
                        cardDarker.withOpacity(0.98),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(28),
                    border: Border.all(
                      color: isSuccess
                          ? bmwYellow.withOpacity(0.5)
                          : bmwRed.withOpacity(0.5),
                      width: 1.5,
                    ),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(
                            colors: isSuccess
                                ? [
                                    bmwYellow.withOpacity(0.3),
                                    bmwYellow.withOpacity(0.15),
                                  ]
                                : [
                                    bmwRed.withOpacity(0.3),
                                    bmwRed.withOpacity(0.15),
                                  ],
                          ),
                        ),
                        child: Icon(
                          isSuccess ? Icons.check_circle : Icons.error,
                          color: bmwChrome,
                          size: 40,
                        ),
                      ),
                      const SizedBox(height: 24),
                      Text(
                        title,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: bmwChrome,
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 0.5,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                      const SizedBox(height: 16),
                      Text(
                        msg,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: bmwChrome.withOpacity(0.85),
                          fontSize: 15,
                          height: 1.5,
                        ),
                      ),
                      const SizedBox(height: 32),
                      SizedBox(
                        width: double.infinity,
                        height: 56,
                        child: ElevatedButton(
                          onPressed: () => Navigator.of(context).pop(),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: isSuccess
                                ? bmwYellow.withOpacity(0.2)
                                : bmwRed.withOpacity(0.2),
                            elevation: 0,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16),
                              side: BorderSide(
                                color: isSuccess
                                    ? bmwYellow.withOpacity(0.6)
                                    : bmwRed.withOpacity(0.6),
                                width: 1.5,
                              ),
                            ),
                          ),
                          child: const Text(
                            "OK",
                            style: TextStyle(
                              color: bmwChrome,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1.2,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  void _showCustomSheet(
    BuildContext context, {
    required String title,
    required IconData titleIcon,
    required Color titleColor,
    required List<_SheetItemData> items,
  }) {
    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: "sheet",
      barrierColor: Colors.black.withOpacity(0.6),
      transitionDuration: const Duration(milliseconds: 360),
      pageBuilder: (_, __, ___) => const SizedBox.shrink(),
      transitionBuilder: (ctx, anim, _, __) {
        final curved = CurvedAnimation(
            parent: anim,
            curve: Curves.easeOutCubic,
            reverseCurve: Curves.easeInCubic);
        return GestureDetector(
          onTap: () => Navigator.of(ctx).pop(),
          behavior: HitTestBehavior.opaque,
          child: Align(
            alignment: Alignment.bottomCenter,
            child: SlideTransition(
              position: Tween<Offset>(
                      begin: const Offset(0, 1), end: Offset.zero)
                  .animate(curved),
              child: GestureDetector(
                onTap: () {},
                child: _SheetContent(
                  title: title,
                  titleIcon: titleIcon,
                  titleColor: titleColor,
                  items: items,
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // WALLPAPER BACKGROUND (9:16) — TAMBAHAN BARU
  // ═══════════════════════════════════════════════════════════════
  Widget _buildAppBackground() {
    return Positioned.fill(
      child: Stack(
        fit: StackFit.expand,
        children: [
          // 🖼️ Wallpaper 9:16 — ganti path sesuai file kamu
          Image.asset(
            'assets/images/wallpaper.png',
            fit: BoxFit.cover,
            alignment: Alignment.center,
            errorBuilder: (_, __, ___) => Container(color: primaryDark),
          ),
          // 🌫️ Overlay gelap biar teks & icon tetap kebaca
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.black.withOpacity(0.45),
                  Colors.black.withOpacity(0.65),
                  Colors.black.withOpacity(0.88),
                ],
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
          ),
          // ✨ M-Stripe tipis di atas (sentuhan BMW)
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            height: 3,
            child: Row(
              children: [
                Expanded(child: Container(color: bmwBlue.withOpacity(0.7))),
                Expanded(child: Container(color: bmwLightBlue.withOpacity(0.7))),
                Expanded(child: Container(color: bmwRed.withOpacity(0.7))),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  //  FULL _buildPremiumBottomNavBar()
  // ═══════════════════════════════════════════════════════════════
  Widget _buildPremiumBottomNavBar() {
    final bottomPadding = MediaQuery.of(context).viewPadding.bottom;

    const Color elegantBlue = Color(0xFF4FC3F7);
    const Color elegantBlueDeep = Color(0xFF0288D1);

    return Container(
      height: 70 + bottomPadding,
      padding: EdgeInsets.only(bottom: bottomPadding),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Colors.black.withOpacity(0.85),
            Colors.black.withOpacity(0.98),
          ],
        ),
      ),
      child: Container(
        height: 70,
        margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(25),
          border: Border.all(
            color: elegantBlue.withOpacity(0.35),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.65),
              blurRadius: 40,
              spreadRadius: 5,
              offset: const Offset(0, 10),
            ),
            BoxShadow(
              color: elegantBlue.withOpacity(0.22),
              blurRadius: 30,
              spreadRadius: 2,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(25),
          child: BackdropFilter(
            filter: ui.ImageFilter.blur(sigmaX: 20.0, sigmaY: 20.0),
            child: Stack(
              children: [
                Positioned.fill(
                  child: Image.asset(
                    'assets/images/bar.jpg',
                    fit: BoxFit.cover,
                    alignment: Alignment.center,
                    errorBuilder: (_, __, ___) => Container(
                      color: const Color(0xFF0A1929),
                    ),
                  ),
                ),
                Positioned.fill(
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          const Color(0xFF0A1929).withOpacity(0.55),
                          const Color(0xFF05101C).withOpacity(0.82),
                        ],
                      ),
                    ),
                  ),
                ),
                Positioned.fill(
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          bmwChrome.withOpacity(0.06),
                          bmwChrome.withOpacity(0.02),
                        ],
                      ),
                    ),
                  ),
                ),
                AnimatedPositioned(
                  duration: const Duration(milliseconds: 300),
                  curve: Curves.easeInOut,
                  left: (_selectedTabIndex *
                      (MediaQuery.of(context).size.width - 40) /
                      4),
                  child: Container(
                    width: (MediaQuery.of(context).size.width - 40) / 4,
                    height: 70,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          elegantBlue.withOpacity(0.18),
                          Colors.transparent,
                        ],
                      ),
                      borderRadius: BorderRadius.circular(25),
                    ),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _buildPremiumNavItem(
                      index: 0,
                      icon: Icons.home_rounded,
                      label: "Home",
                      activeIcon: Icons.home_filled,
                    ),
                    _buildPremiumNavItem(
                      index: 1,
                      icon: FontAwesomeIcons.whatsapp,
                      label: "WhatsApp",
                      activeIcon: FontAwesomeIcons.whatsappSquare,
                    ),
                    _buildPremiumNavItem(
                      index: 2,
                      icon: Icons.info_outline_rounded,
                      label: "Info",
                      activeIcon: Icons.info_rounded,
                    ),
                    _buildPremiumNavItem(
                      index: 3,
                      icon: Icons.chat_bubble_outline_rounded,
                      label: "Chat",
                      activeIcon: Icons.chat_bubble_rounded,
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  //  FULL _buildPremiumNavItem()
  // ═══════════════════════════════════════════════════════════════
  Widget _buildPremiumNavItem({
    required int index,
    required IconData icon,
    required String label,
    required IconData activeIcon,
  }) {
    bool isActive = _selectedTabIndex == index;

    const Color elegantBlue = Color(0xFF4FC3F7);
    const Color elegantBlueDeep = Color(0xFF0288D1);

    return GestureDetector(
      onTap: () => _onTabTapped(index),
      child: Container(
        width: (MediaQuery.of(context).size.width - 40) / 4,
        height: 80,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Stack(
              alignment: Alignment.center,
              children: [
                if (isActive)
                  Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(
                        colors: [
                          elegantBlue.withOpacity(0.30),
                          Colors.transparent,
                        ],
                        radius: 0.7,
                      ),
                    ),
                  ),
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: isActive
                        ? elegantBlue.withOpacity(0.15)
                        : Colors.transparent,
                    border: Border.all(
                      color: isActive
                          ? elegantBlue.withOpacity(0.65)
                          : Colors.transparent,
                      width: isActive ? 1.5 : 0,
                    ),
                    boxShadow: isActive
                        ? [
                            BoxShadow(
                              color: elegantBlue.withOpacity(0.40),
                              blurRadius: 15,
                              spreadRadius: 2,
                            ),
                          ]
                        : [],
                  ),
                  child: Center(
                    child: AnimatedSwitcher(
                      duration: const Duration(milliseconds: 300),
                      transitionBuilder: (child, animation) {
                        return ScaleTransition(scale: animation, child: child);
                      },
                      child: Icon(
                        isActive ? activeIcon : icon,
                        key: ValueKey<bool>(isActive),
                        color: isActive
                            ? elegantBlue
                            : bmwChrome.withOpacity(0.6),
                        size: isActive ? 22 : 20,
                      ),
                    ),
                  ),
                ),
                if (isActive)
                  Positioned(
                    top: 6,
                    right: 6,
                    child: Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: elegantBlue,
                        boxShadow: [
                          BoxShadow(
                            color: elegantBlue.withOpacity(0.75),
                            blurRadius: 8,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 6),
            AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: isActive
                    ? elegantBlue.withOpacity(0.15)
                    : Colors.transparent,
                borderRadius: BorderRadius.circular(12),
                border: isActive
                    ? Border.all(
                        color: elegantBlue.withOpacity(0.28),
                        width: 0.5,
                      )
                    : null,
              ),
              child: Text(
                label,
                style: TextStyle(
                  color: isActive ? elegantBlue : bmwChrome.withOpacity(0.6),
                  fontSize: 11,
                  fontWeight: isActive ? FontWeight.w700 : FontWeight.w500,
                  letterSpacing: isActive ? 0.5 : 0.3,
                  shadows: const [
                    Shadow(color: Colors.black, blurRadius: 4),
                    Shadow(color: Colors.black87, blurRadius: 8),
                  ],
                ),
              ),
            ),
            if (isActive)
              Container(
                margin: const EdgeInsets.only(top: 4),
                width: 20,
                height: 2.5,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [elegantBlue, elegantBlueDeep],
                  ),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════
  // BUILD (MODIFIED: body dibungkus Stack + wallpaper)
  // ═══════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    if (sessionKey == null) {
      return Scaffold(
        backgroundColor: primaryDark,
        body: const Center(
          child: CircularProgressIndicator(color: bmwYellow),
        ),
      );
    }

    return Scaffold(
      backgroundColor: primaryDark,
      drawer: _buildDrawer(),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        flexibleSpace: Stack(
          children: [
            Opacity(
              opacity: 0.12,
              child: Image.asset(
                'assets/images/hoo.jpg',
                fit: BoxFit.cover,
                alignment: Alignment.centerRight,
                errorBuilder: (context, error, stackTrace) =>
                    const SizedBox.shrink(),
              ),
            ),
            Positioned(
              bottom: 0,
              left: 0,
              child: Row(
                children: [
                  Container(width: 50, height: 2, color: bmwBlue),
                  Container(width: 50, height: 2, color: bmwLightBlue),
                  Container(width: 50, height: 2, color: bmwRed),
                ],
              ),
            ),
          ],
        ),
        title: SizedBox(
          height: 50,
          child: Image.asset(
            'assets/images/ghost.png',
            fit: BoxFit.contain,
            errorBuilder: (context, error, stackTrace) {
              return ShaderMask(
                shaderCallback: (bounds) => const LinearGradient(
                  colors: [bmwYellow, bmwChrome],
                ).createShader(bounds),
                child: const Text(
                  "GHOST",
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 24,
                    color: Colors.white,
                    fontFamily: 'Orbitron',
                  ),
                ),
              );
            },
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.music_note_rounded, color: bmwYellow),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const MonstaMusicPage()),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.headset_mic, color: bmwYellow),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const ContactPage()),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.account_circle, color: bmwYellow),
            onPressed: () {
              if (sessionKey == null) return;
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => MyInfoPage(
                    username: username,
                    password: password,
                    role: role,
                    expiredDate: expiredDate,
                    sessionKey: sessionKey!,
                  ),
                ),
              );
            },
          ),
        ],
      ),
      // 👇 BODY DIBUNGKUS STACK DENGAN WALLPAPER
      body: Stack(
        children: [
          _buildAppBackground(),
          FadeTransition(
            opacity: _animation,
            child: _selectedPage,
          ),
        ],
      ),
      bottomNavigationBar: _buildPremiumBottomNavBar(),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    _fadeController.dispose();
    _pulseController.dispose();
    _slideController.dispose();
    _clockTimer?.cancel();
    super.dispose();
  }
}

// ═══════════════════════════════════════════════════════════════════
// CLASS LAIN-LAIN (TOP LEVEL)
// ═══════════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════════
// PAINTER: LANTAI GARASI (CHECKER PIT BAY)
// ═══════════════════════════════════════════════════════════════
class _GarageFloorPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = bmwYellow.withOpacity(0.35)
      ..strokeWidth = 2;

    for (double i = -size.height; i < size.width; i += 24) {
      canvas.drawLine(
        Offset(i, size.height),
        Offset(i + size.height, 0),
        paint,
      );
    }

    final linePaint = Paint()
      ..color = bmwYellow.withOpacity(0.5)
      ..strokeWidth = 2;
    canvas.drawLine(Offset(0, 20), Offset(size.width, 20), linePaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class NewsMedia extends StatelessWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  Widget build(BuildContext context) {
    return CachedNetworkImage(
      imageUrl: url,
      fit: BoxFit.cover,
      placeholder: (context, url) => Container(
        color: bmwDark,
        child: const Center(
          child: CircularProgressIndicator(color: bmwYellow),
        ),
      ),
      errorWidget: (context, url, error) => Container(
        color: bmwGunmetal,
        child: const Center(child: Icon(Icons.error, color: bmwSilver)),
      ),
    );
  }
}

class _SheetItemData {
  final IconData icon;
  final Color iconColor;
  final String title;
  final String subtitle;
  final void Function(BuildContext) onTap;

  const _SheetItemData({
    required this.icon,
    required this.iconColor,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });
}

class _SheetContent extends StatelessWidget {
  final String title;
  final IconData titleIcon;
  final Color titleColor;
  final List<_SheetItemData> items;

  const _SheetContent({
    required this.title,
    required this.titleIcon,
    required this.titleColor,
    required this.items,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      type: MaterialType.transparency,
      child: ClipRRect(
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        child: BackdropFilter(
          filter: ui.ImageFilter.blur(sigmaX: 18, sigmaY: 18),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(20, 14, 20, 30),
            decoration: BoxDecoration(
              color: const Color(0xFF0A0F16).withOpacity(0.97),
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(28)),
              border: Border(
                  top: BorderSide(
                      color: titleColor.withOpacity(0.55), width: 1.4)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 44,
                    height: 4,
                    decoration: BoxDecoration(
                      color: bmwYellow.withOpacity(0.5),
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: titleColor.withOpacity(0.16),
                        borderRadius: BorderRadius.circular(13),
                        border: Border.all(color: titleColor.withOpacity(0.45)),
                      ),
                      child: Icon(titleIcon, color: titleColor, size: 20),
                    ),
                    const SizedBox(width: 12),
                    Text(
                      title,
                      style: const TextStyle(
                        fontFamily: 'Orbitron',
                        color: bmwChrome,
                        fontWeight: FontWeight.w900,
                        fontSize: 18,
                        letterSpacing: 0.6,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                ...items.map((it) => Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: _SheetButton(data: it, accent: titleColor),
                    )),
                const SizedBox(height: 6),
                Center(
                  child: Text(
                    "Tap di luar untuk menutup",
                    style: TextStyle(
                      fontFamily: 'Orbitron',
                      color: bmwSilver.withOpacity(0.55),
                      fontSize: 11,
                      letterSpacing: 1.0,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SheetButton extends StatelessWidget {
  final _SheetItemData data;
  final Color accent;

  const _SheetButton({required this.data, required this.accent});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => data.onTap(context),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: bmwChrome.withOpacity(0.04),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: accent.withOpacity(0.25), width: 1.1),
        ),
        child: Row(
          children: [
            Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                color: data.iconColor.withOpacity(0.14),
                borderRadius: BorderRadius.circular(13),
                border: Border.all(color: data.iconColor.withOpacity(0.45)),
              ),
              child: Icon(data.icon, color: data.iconColor, size: 20),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    data.title,
                    style: const TextStyle(
                      fontFamily: 'Orbitron',
                      color: bmwChrome,
                      fontSize: 14.5,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 0.5,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    data.subtitle,
                    style: TextStyle(
                      fontFamily: 'Orbitron',
                      color: bmwSilver.withOpacity(0.65),
                      fontSize: 11.5,
                      height: 1.3,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.arrow_forward_ios_rounded,
              color: accent.withOpacity(0.9),
              size: 13,
            ),
          ],
        ),
      ),
    );
  }
}

class DarkCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets? padding;
  final EdgeInsets? margin;

  const DarkCard({
    Key? key,
    required this.child,
    this.padding,
    this.margin,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: margin ?? EdgeInsets.zero,
      padding: padding ?? const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: bmwDark,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: bmwYellow.withOpacity(0.2), width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: child,
    );
  }
}

class _ArrowIcon extends StatelessWidget {
  const _ArrowIcon();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 22,
      height: 22,
      decoration: BoxDecoration(
        color: bmwYellow.withOpacity(0.15),
        shape: BoxShape.circle,
        border: Border.all(color: bmwYellow.withOpacity(0.5)),
      ),
      child: const Icon(
        Icons.arrow_forward_ios,
        color: bmwYellow,
        size: 12,
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// MODERN ACTION CARD — BMW style
// ═══════════════════════════════════════════════════════════════════
class _ModernActionCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color iconColor;
  final LinearGradient gradient;
  final VoidCallback onTap;
  final int index;

  const _ModernActionCard({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.iconColor,
    required this.gradient,
    required this.onTap,
    required this.index,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
        decoration: BoxDecoration(
          gradient: gradient,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: bmwYellow.withOpacity(0.2), width: 1),
          boxShadow: [
            BoxShadow(
              color: gradient.colors.first.withOpacity(0.45),
              blurRadius: 20,
              offset: const Offset(0, 10),
            ),
            BoxShadow(
              color: Colors.black.withOpacity(0.35),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: Stack(
            children: [
              Positioned(
                right: -20,
                bottom: -20,
                child: Icon(
                  icon,
                  size: 140,
                  color: Colors.white.withOpacity(0.08),
                ),
              ),
              Positioned(
                top: 0,
                right: 0,
                child: Row(
                  children: [
                    Container(width: 14, height: 3, color: bmwBlue),
                    Container(width: 14, height: 3, color: bmwLightBlue),
                    Container(width: 14, height: 3, color: bmwRed),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 56,
                          height: 56,
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.4),
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: bmwYellow.withOpacity(0.5),
                              width: 1.5,
                            ),
                          ),
                          child: Icon(icon, color: iconColor, size: 26),
                        ),
                        const Spacer(),
                        Container(
                          width: 36,
                          height: 36,
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.35),
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: bmwYellow.withOpacity(0.4),
                            ),
                          ),
                          child: const Icon(
                            Icons.arrow_forward_rounded,
                            color: bmwYellow,
                            size: 18,
                          ),
                        ),
                      ],
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title,
                          style: const TextStyle(
                            color: bmwChrome,
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 0.5,
                            shadows: [
                              Shadow(color: Colors.black54, blurRadius: 6),
                            ],
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          subtitle,
                          style: TextStyle(
                            color: bmwChrome.withOpacity(0.9),
                            fontSize: 13,
                            fontWeight: FontWeight.w400,
                            shadows: const [
                              Shadow(color: Colors.black45, blurRadius: 4),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}