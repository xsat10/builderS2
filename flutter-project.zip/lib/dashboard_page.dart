// ============================================================
// 🎨 DASHBOARD PAGE — Dark Red Comic 3D Edition
// File: dashboard_page.dart
// v4 — + Laporkan Masalah + Riwayat Laporan + Akses Jualan + Validasi Akun
// ============================================================
import 'dart:convert';
import 'dart:io';
import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:http/http.dart' as http;
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'dart:ui' as ui;

import 'admin_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'anime_home.dart';
import 'music_page.dart';
import 'owner_page.dart';
import 'owner_utama_page.dart';
import 'staff_page.dart';
import 'moderator_page.dart';
import 'partner_page.dart';
import 'executorius_page.dart';
import 'forius_utama_page.dart';
import 'tangan_kiri_page.dart';
import 'partner_prib_page.dart';
import 'menu_page.dart';
import 'chat_room_page.dart';
import 'al_quran.dart';
import 'instagram.dart';
import 'ular.dart';
import 'robot_asissten.dart';
import 'ambil_link_gb_page.dart';
import 'laporkan_masalah_page.dart';
import 'riwayat_laporan_page.dart';
import 'akses_jualan_page.dart';
import 'validasi_akun_page.dart';

const String _nFont = "Astral";
const String kStoryBaseUrl = "http://shinoa-cpanelpanel.xtxintax.my.id:2003";

// ═════════════════════════════════════════════════════════════
// 🎨 DARK RED COMIC PALETTE
// ═════════════════════════════════════════════════════════════
class _MC {
  static const red          = Color(0xFF8B0000);
  static const redDeep      = Color(0xFF1A0A0A);
  static const redDark      = Color(0xFF4A0000);
  static const redSoft      = Color(0xFF2A0E0E);
  static const redLight     = Color(0xFF3D1414);
  static const accentRed    = Color(0xFFD32F2F);
  static const brightRed    = Color(0xFFFF3B3B);
  static const violet       = Color(0xFFA855F7);
  static const cyan         = Color(0xFF22D3EE);
  static const green        = Color(0xFF22C55E);
  static const greenLite    = Color(0xFF4ADE80);
  static const amber        = Color(0xFFFBBF24);
  static const gold         = Color(0xFFFFD700);
  static const silver       = Color(0xFFC0C0C0);
  static const bronze       = Color(0xFFCD7F32);
  static const blueCheck    = Color(0xFF60A5FA);
  static const white        = Color(0xFFFFF5F5);
  static const cream        = Color(0xFF0F0505);
  static const textDark     = Color(0xFFFFF5F5);
  static const textGrey     = Color(0xFFC9A0A0);
  static const textLight    = Color(0xFF8A6060);
  static const comicBlack   = Color(0xFF000000);
  static const comicOutline = Color(0xFF1A0000);
  static const buttonYellow = Color(0xFFB8860B);
  static const buttonDark   = Color(0xFF1A1A1A);
}

class _C {
  static const bg        = Color(0xFF0F0505);
  static const surface   = Color(0xFF1A0808);
  static const card      = Color(0xFF2A0E0E);
  static const cardAlt   = Color(0xFF3D1414);
  static const border    = Color(0xFF000000);
  static const borderLit = Color(0xFF4A0000);
  static const teal      = Color(0xFF4ECDC4);
  static const green     = Color(0xFF22C55E);
  static const blue      = Color(0xFF3B82F6);
  static const amber     = Color(0xFFF59E0B);
  static const red       = Color(0xFF8B0000);
  static const orange    = Color(0xFFFF6B35);
  static const pink      = Color(0xFFEC4899);
  static const indigo    = Color(0xFF4169E1);
  static const text      = Color(0xFFFFF5F5);
  static const textSub   = Color(0xFFC9A0A0);
  static const textDim   = Color(0xFF8A6060);
}

const Color kCard = Color(0xFF2A0E0E);
const Color kBorder = Color(0xFF000000);
const Color kWhite = Color(0xFFFFF5F5);
const Color kWhite54 = Color(0x8AFFF5F5);
const Color kCyan = Color(0xFF22D3EE);
const Color kGreen = Color(0xFF4ADE80);
const Color kBlue = Color(0xFF3B82F6);
const Color kOrange = Color(0xFFFBBF24);
const Color kRed = Color(0xFFFF3B3B);
const Color kYellow = Color(0xFFB8860B);
const Color _nCard = Color(0xFF2A0E0E);

extension ColorExt on Color {
  Color withOpacity(double opacity) => withAlpha((opacity * 255).round());
}

// ═════════════════════════════════════════════════════════════
// 🎭 ROLE HELPERS
// ═════════════════════════════════════════════════════════════
Color _roleColor(String role) {
  switch (role.toLowerCase()) {
    case 'owner_utama': return const Color(0xFFFF3B3B);
    case 'owner': return const Color(0xFFFFB300);
    case 'staff': return const Color(0xFFE53935);
    case 'executorius': return const Color(0xFFFF6B00);
    case 'forius_utama': return const Color(0xFFFF8F00);
    case 'moderator': return const Color(0xFF7E57C2);
    case 'ceo_utama': return const Color(0xFF5C6BC0);
    case 'tangan_kanan': return const Color(0xFF26C6DA);
    case 'tangan_kiri': return const Color(0xFF4DD0E1);
    case 'developers': return const Color(0xFF29B6F6);
    case 'partner_pribadi': return const Color(0xFF66BB6A);
    case 'partner': return const Color(0xFF43A047);
    case 'admin': return const Color(0xFF26A69A);
    case 'tukang_bubur': return const Color(0xFFFFCA28);
    case 'reseller': return const Color(0xFF9CCC65);
    case 'vip': return const Color(0xFFFFD54F);
    default: return const Color(0xFF8B0000);
  }
}

IconData _roleIcon(String role) {
  switch (role.toLowerCase()) {
    case 'owner_utama': return Icons.diamond_rounded;
    case 'owner': return Icons.workspace_premium_rounded;
    case 'staff': return Icons.shield_rounded;
    case 'executorius': return Icons.gavel_rounded;
    case 'forius_utama': return Icons.security_rounded;
    case 'moderator': return Icons.verified_user_rounded;
    case 'ceo_utama': return Icons.business_center_rounded;
    case 'tangan_kanan': return Icons.pan_tool_alt_rounded;
    case 'tangan_kiri': return Icons.back_hand_rounded;
    case 'developers': return Icons.code_rounded;
    case 'partner_pribadi': return Icons.person_pin_rounded;
    case 'partner': return Icons.handshake_rounded;
    case 'admin': return Icons.admin_panel_settings_rounded;
    case 'tukang_bubur': return Icons.ramen_dining_rounded;
    case 'reseller': return Icons.storefront_rounded;
    case 'vip': return Icons.star_rounded;
    default: return Icons.person_rounded;
  }
}

int _roleRingLevel(String role) {
  switch (role.toLowerCase()) {
    case 'member': return 1;
    case 'vip':
    case 'reseller':
    case 'tukang_bubur': return 2;
    case 'admin':
    case 'partner':
    case 'partner_pribadi': return 3;
    case 'tangan_kiri':
    case 'tangan_kanan':
    case 'developers':
    case 'ceo_utama':
    case 'moderator': return 4;
    case 'forius_utama':
    case 'executorius':
    case 'staff': return 5;
    case 'owner':
    case 'owner_utama': return 6;
    default: return 1;
  }
}

bool _isVerifiedRole(String role) {
  return [
    'executorius', 'forius_utama', 'staff',
    'owner', 'owner_utama',
    'moderator', 'ceo_utama',
  ].contains(role.toLowerCase());
}

String? _roleBadgeEmoji(String role) {
  switch (role.toLowerCase()) {
    case 'vip': return '⭐️';
    case 'reseller': return '🏪';
    case 'tukang_bubur': return '🍜';
    case 'admin': return '🔧';
    case 'partner': return '🤝';
    case 'partner_pribadi': return '💼';
    default: return null;
  }
}

String _roleShort(String role) {
  if (role.isEmpty) return '??';
  return role.substring(0, math.min(2, role.length)).toUpperCase();
}

// ═════════════════════════════════════════════════════════════
// 📖 STORY MODELS
// ═════════════════════════════════════════════════════════════
class StoryUser {
  final String username;
  final String role;
  final String avatar;
  final List<StoryItem> stories;
  StoryUser({
    required this.username, required this.role,
    required this.avatar, required this.stories,
  });

  factory StoryUser.fromJson(Map<String, dynamic> j) {
    final list = (j['stories'] as List? ?? [])
        .map((e) => StoryItem.fromJson(Map<String, dynamic>.from(e)))
        .toList();
    return StoryUser(
      username: j['username'] ?? 'User',
      role: j['role'] ?? 'member',
      avatar: j['avatar'] ?? '',
      stories: list,
    );
  }
}

class StoryItem {
  final String id;
  final String username;
  final String role;
  final String avatar;
  final String type;
  final String content;
  final String caption;
  final int createdAt;
  final List<dynamic> views;
  StoryItem({
    required this.id, required this.username, required this.role,
    required this.avatar, required this.type, required this.content,
    required this.caption, required this.createdAt, required this.views,
  });

  factory StoryItem.fromJson(Map<String, dynamic> j) => StoryItem(
    id: j['id'] ?? '',
    username: j['username'] ?? 'User',
    role: j['role'] ?? 'member',
    avatar: j['avatar'] ?? '',
    type: j['type'] ?? 'text',
    content: j['content'] ?? '',
    caption: j['caption'] ?? '',
    createdAt: j['createdAt'] ?? 0,
    views: j['views'] ?? [],
  );
}

// ═════════════════════════════════════════════════════════════
// DATA MODELS
// ═════════════════════════════════════════════════════════════
class _QuickActionData {
  final IconData icon;
  final IconData bgIcon;
  final String title;
  final String subtitle;
  final List<Color> gradient;
  final VoidCallback onTap;
  const _QuickActionData({
    required this.icon, required this.bgIcon,
    required this.title, required this.subtitle,
    required this.gradient, required this.onTap,
  });
}

class _NavItem {
  final IconData icon;
  final String label;
  const _NavItem({required this.icon, required this.label});
}

// ═════════════════════════════════════════════════════════════
// DASHBOARD PAGE
// ═════════════════════════════════════════════════════════════
class DashboardPage extends StatefulWidget {
  final String username, password, role, expiredDate, sessionKey;
  final List<Map<String, dynamic>> listBug, listDoos;
  final List<dynamic> news;
  const DashboardPage({
    super.key, required this.username, required this.password,
    required this.role, required this.expiredDate, required this.listBug,
    required this.listDoos, required this.sessionKey, required this.news,
  });
  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {

  late String sessionKey, username, password, role, expiredDate;
  late List<Map<String, dynamic>> listBug, listDoos;
  late List<dynamic> newsList;

  WebSocketChannel? channel;
  String androidId = 'unknown';
  File? _profileImage;
  VideoPlayerController? _menuVideoCtrl;

  int _navIndex = 0;
  Widget _body = const SizedBox();
  int onlineUsers = 0, activeConns = 0;

  // TTS
  final FlutterTts _tts = FlutterTts();
  bool _hasSpokenWelcome = false;

  // System dashboard
  final Battery _battery = Battery();
  final Connectivity _connectivity = Connectivity();
  StreamSubscription<BatteryState>? _batteryStateSub;
  StreamSubscription<List<ConnectivityResult>>? _connectivitySub;
  Timer? _batteryLevelTimer;
  Timer? _memInfoTimer;
  Timer? _sessionTickTimer;

  int _batteryLevel = 0;
  BatteryState _batteryState = BatteryState.unknown;
  List<ConnectivityResult> _connectivityResult = [ConnectivityResult.none];
  int _signalPercent = 0;

  double _totalRamMB = 0;
  double _usedRamMB = 0;
  double _totalStorageMB = 0;
  double _usedStorageMB = 0;

  AndroidDeviceInfo? _androidInfo;
  DateTime? _sessionStartedAt;
  Duration _sessionElapsed = Duration.zero;

  int totalUsers = 0;
  int totalSender = 0;
  bool _statsLoading = true;

  // Story
  List<StoryUser> _storyUsers = [];
  bool _storyLoading = true;
  Timer? _storyTimer;

  // Public chat preview
  Timer? _chatPreviewTimer;
  String _chatPreviewMessage = 'Belum ada pesan terbaru';
  String _chatPreviewUser = 'Public Chat';
  String _chatPreviewTime = '';
  String _chatPreviewType = 'text';

  late PageController _qaPageCtrl;
  double _currentQaPage = 0.0;

  late AnimationController _bgCtrl, _pageCtrl, _pulseCtrl, _ringCtrl;
  late Animation<double> _pageFade, _pulse;
  late Animation<Offset> _pageSlide;

  // Prayer
  bool _detectingLocation = false;
  String _prayerCity = 'Jakarta';
  Map<String, String> _prayerTimes = {};
  String _nextPrayerLabel = '';
  String _nextPrayerTime = '';
  bool _prayerLoading = true;

  Color get primaryColor => _MC.red;
  Color get accentColor => _MC.brightRed;
  Color get cardColor => _MC.redSoft;
  Color get backgroundColor => _MC.redDeep;

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    _qaPageCtrl = PageController();

    _bgCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 20))..repeat();
    _pageCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 400));
    _pulseCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);
    _ringCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 8))..repeat();

    _pageFade = CurvedAnimation(parent: _pageCtrl, curve: Curves.easeOut);
    _pageSlide = Tween<Offset>(begin: const Offset(0, 0.05), end: Offset.zero)
        .animate(CurvedAnimation(parent: _pageCtrl, curve: Curves.easeOutCubic));
    _pulse = Tween<double>(begin: 0.6, end: 1.0)
        .animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _body = _homeDashboard();
    _pageCtrl.forward();
    _initAndroidId();
    _loadProfileImage();
    _initMenuVideo();
    _fetchPrayerTimes();
    _fetchStats();
    _initSystemDashboard();
    _loadStories();
    _storyTimer = Timer.periodic(
        const Duration(minutes: 5), (_) => _loadStories());
    _loadChatPreview();
    _chatPreviewTimer = Timer.periodic(
        const Duration(seconds: 8), (_) => _loadChatPreview());

    _initTts();
    WidgetsBinding.instance.addPostFrameCallback((_) => _speakWelcome());
  }

  // ═══════════════════════════════════════════════════════════
  // 🔊 TTS WELCOME
  // ═══════════════════════════════════════════════════════════
  Future<void> _initTts() async {
    try {
      await _tts.setLanguage("en-US");
      await _tts.setSpeechRate(0.4);
      await _tts.setVolume(1.0);
      await _tts.setPitch(0.5);
    } catch (_) {}
  }

  Future<void> _speakWelcome() async {
    if (_hasSpokenWelcome) return;
    _hasSpokenWelcome = true;
    try {
      await _tts.stop();
      await _tts.setPitch(0.45);
      await _tts.setSpeechRate(0.4);
      await _tts.speak("WELCOME TO X SPYDER, TQ FOR YOU LOVE ME");
    } catch (_) {}
  }

  @override
  void dispose() {
    try { channel?.sink.close(status.goingAway); } catch (_) {}
    _bgCtrl.dispose();
    _pageCtrl.dispose();
    _pulseCtrl.dispose();
    _ringCtrl.dispose();
    _qaPageCtrl.dispose();
    _menuVideoCtrl?.dispose();
    _batteryStateSub?.cancel();
    _connectivitySub?.cancel();
    _batteryLevelTimer?.cancel();
    _memInfoTimer?.cancel();
    _sessionTickTimer?.cancel();
    _storyTimer?.cancel();
    _chatPreviewTimer?.cancel();
    _tts.stop();
    super.dispose();
  }

  Animation<double> get _pulseAnim => _pulse;

  // ═══════════════════════════════════════════════════════════
  // 💬 PUBLIC CHAT PREVIEW
  // ═══════════════════════════════════════════════════════════
  Future<void> _loadChatPreview() async {
    try {
      final uri = Uri.parse('$kStoryBaseUrl/api/chat/messages?limit=1');
      final res = await http.get(
        uri,
        headers: {
          'Accept': 'application/json',
          if (sessionKey.isNotEmpty) 'Authorization': 'Bearer $sessionKey',
          if (sessionKey.isNotEmpty) 'X-Session-Key': sessionKey,
        },
      ).timeout(const Duration(seconds: 6));
      if (res.statusCode != 200) return;
      final raw = jsonDecode(res.body);
      final list = raw is List
          ? raw
          : (raw is Map ? (raw['messages'] ?? raw['data'] ?? []) : []);
      if (list is! List || list.isEmpty || !mounted) return;
      final m = Map<String, dynamic>.from(list.first as Map);
      setState(() {
        _chatPreviewMessage = (m['text'] ?? m['message'] ?? (m['imageUrl'] != null ? '📷 Foto' : 'Pesan')).toString();
        _chatPreviewUser = (m['username'] ?? m['user'] ?? 'User').toString();
        _chatPreviewType = (m['type'] ?? (m['imageUrl'] != null ? 'image' : 'text')).toString();
        final rawTime = m['createdAt'] ?? m['timestamp'] ?? m['time'];
        _chatPreviewTime = _formatChatPreviewTime(rawTime);
      });
    } catch (_) {}
  }

  String _formatChatPreviewTime(dynamic value) {
    if (value == null || value.toString().isEmpty) return '';
    DateTime? dt;
    if (value is int) {
      dt = DateTime.fromMillisecondsSinceEpoch(
        value < 1000000000000 ? value * 1000 : value,
        isUtc: false,
      ).toLocal();
    } else {
      dt = DateTime.tryParse(value.toString())?.toLocal();
    }
    if (dt == null) return value.toString();
    final now = DateTime.now();
    final sameDay = now.year == dt.year && now.month == dt.month && now.day == dt.day;
    final hh = dt.hour.toString().padLeft(2, '0');
    final mm = dt.minute.toString().padLeft(2, '0');
    if (sameDay) return '$hh:$mm';
    return '${dt.day.toString().padLeft(2, '0')}/${dt.month.toString().padLeft(2, '0')} • $hh:$mm';
  }

  Widget _buildPublicChatPreview() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: GestureDetector(
        onTap: () {
          Navigator.push(
            context,
            _slideRoute(ChatRoomPage(
              username: username,
              role: role,
              sessionKey: sessionKey,
            )),
          ).then((_) => _loadChatPreview());
        },
        child: Container(
          height: 72,
          padding: const EdgeInsets.symmetric(horizontal: 14),
          decoration: BoxDecoration(
            color: _MC.redSoft,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: _MC.comicBlack, width: 3.5),
            boxShadow: const [
              BoxShadow(
                color: _MC.comicBlack,
                offset: Offset(5, 5),
                blurRadius: 0,
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 43, height: 43,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _MC.red,
                  border: Border.all(color: _MC.comicBlack, width: 3),
                ),
                child: const Icon(Icons.forum_rounded,
                    color: _MC.white, size: 22),
              ),
              const SizedBox(width: 11),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Text('CHAT PUBLIC', style: TextStyle(
                          color: _MC.white, fontSize: 10,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.3, fontFamily: 'Astral',
                        )),
                        const SizedBox(width: 6),
                        Container(
                          width: 6, height: 6,
                          decoration: const BoxDecoration(
                              color: _MC.greenLite,
                              shape: BoxShape.circle),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      _chatPreviewType == 'image'
                          ? '$_chatPreviewUser • 📷 Foto'
                          : '$_chatPreviewUser • $_chatPreviewMessage',
                      maxLines: 1, overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          color: _MC.textGrey, fontSize: 11,
                          fontFamily: 'Astral'),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(_chatPreviewTime.isEmpty ? 'OPEN' : _chatPreviewTime,
                    style: const TextStyle(
                        color: _MC.textLight, fontSize: 9,
                        fontWeight: FontWeight.w800)),
                  const SizedBox(height: 4),
                  const Icon(Icons.arrow_forward_ios_rounded,
                      color: _MC.textGrey, size: 13),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // 📖 STORY
  // ═══════════════════════════════════════════════════════════
  Future<void> _loadStories() async {
    try {
      final res = await http
          .get(Uri.parse('$kStoryBaseUrl/api/story/list'))
          .timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['success'] == true) {
          final users = (data['users'] as List? ?? [])
              .map((e) => StoryUser.fromJson(Map<String, dynamic>.from(e)))
              .toList();
          if (mounted) {
            setState(() {
              _storyUsers = users;
              _storyLoading = false;
            });
          }
          return;
        }
      }
    } catch (_) {}
    if (mounted) setState(() => _storyLoading = false);
  }

  Future<void> _showAddStorySheet() async {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => _AddStorySheet(
        username: username,
        role: role,
        sessionKey: sessionKey,
        avatar: _profileImage?.path ?? '',
        onCreated: _loadStories,
      ),
    );
  }

  void _openStoryViewer(int userIndex) {
    Navigator.push(
      context,
      PageRouteBuilder(
        opaque: false,
        pageBuilder: (_, __, ___) => _StoryViewer(
          users: _storyUsers,
          initialUserIndex: userIndex,
          currentUsername: username,
          sessionKey: sessionKey,
          onRefresh: _loadStories,
        ),
        transitionsBuilder: (_, a, __, c) =>
            FadeTransition(opacity: a, child: c),
        transitionDuration: const Duration(milliseconds: 280),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // API
  // ═══════════════════════════════════════════════════════════
  Future<void> _fetchStats() async {
    try {
      final response = await http.get(
        Uri.parse('http://shinoa-cpanelpanel.xtxintax.my.id:2003/api/stats?key=$sessionKey'),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (mounted) {
          setState(() {
            totalUsers = data['totalUsers'] ?? 0;
            totalSender = data['totalSender'] ?? 0;
            _statsLoading = false;
          });
        }
      } else {
        setState(() {
          totalUsers = listBug.length;
          totalSender = listDoos.length;
          _statsLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        totalUsers = listBug.length;
        totalSender = listDoos.length;
        _statsLoading = false;
      });
    }
  }

  void _initMenuVideo() {
    _menuVideoCtrl = VideoPlayerController.asset('assets/videos/landing.mp4')
      ..initialize().then((_) {
        if (mounted) setState(() {});
        _menuVideoCtrl?.setLooping(true);
        _menuVideoCtrl?.setVolume(1.0);
        _menuVideoCtrl?.play();
      });
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final path = prefs.getString('profile_image_$username');
    if (path != null && path.isNotEmpty && mounted) {
      setState(() => _profileImage = File(path));
    }
  }

  Future<void> _fetchPrayerTimes() async {
    if (!mounted) return;
    setState(() => _prayerLoading = true);
    final data = await PrayerTimeService.fetchPrayerTimes(_prayerCity);
    if (!mounted) return;
    if (data.isNotEmpty && data['data'] != null) {
      final timings = data['data']['timings'] ?? {};
      final Map<String, String> times = {
        'Subuh': timings['Fajr'] ?? '--:--',
        'Dzuhur': timings['Dhuhr'] ?? '--:--',
        'Ashar': timings['Asr'] ?? '--:--',
        'Maghrib': timings['Maghrib'] ?? '--:--',
        'Isya': timings['Isha'] ?? '--:--',
      };
      final now = TimeOfDay.now();
      String nextLabel = 'Isya';
      String nextTime = times['Isya'] ?? '--:--';
      for (final entry in times.entries) {
        final parts = entry.value.split(':');
        if (parts.length >= 2) {
          final h = int.tryParse(parts[0]) ?? 0;
          final m = int.tryParse(parts[1]) ?? 0;
          if (h > now.hour || (h == now.hour && m > now.minute)) {
            nextLabel = entry.key;
            nextTime = entry.value;
            break;
          }
        }
      }
      setState(() {
        _prayerTimes = times;
        _nextPrayerLabel = nextLabel;
        _nextPrayerTime = nextTime;
        _prayerLoading = false;
      });
    } else {
      setState(() => _prayerLoading = false);
    }
  }

  Future<void> _autoDetectLocationAndFetchPrayer() async {
    if (_detectingLocation) return;
    setState(() => _detectingLocation = true);
    try {
      final city = await PrayerTimeService.detectLocationByGPS();
      if (mounted) {
        setState(() {
          _prayerCity = city;
          _detectingLocation = false;
        });
        await _fetchPrayerTimes();
      }
    } catch (e) {
      if (mounted) setState(() => _detectingLocation = false);
    }
  }

  void _showChangeCityDialog() {
    final ctrl = TextEditingController(text: _prayerCity);
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: _MC.redSoft,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _MC.comicBlack, width: 3.5),
            boxShadow: const [
              BoxShadow(
                  color: _MC.comicBlack,
                  offset: Offset(6, 8),
                  blurRadius: 0),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('GANTI LOKASI',
                  style: TextStyle(
                    color: _MC.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Astral',
                    letterSpacing: 1.5,
                  )),
              const SizedBox(height: 16),
              Container(
                decoration: BoxDecoration(
                  color: _MC.redDeep,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _MC.comicBlack, width: 3),
                ),
                child: TextField(
                  controller: ctrl,
                  style: const TextStyle(
                      color: _MC.white,
                      fontWeight: FontWeight.w700),
                  cursorColor: _MC.brightRed,
                  decoration: const InputDecoration(
                    hintText: 'Nama kota',
                    hintStyle:
                        TextStyle(color: _MC.textLight, fontSize: 13),
                    filled: true,
                    fillColor: Colors.transparent,
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(
                        horizontal: 14, vertical: 16),
                    prefixIcon: Icon(Icons.location_city_rounded,
                        color: _MC.brightRed),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 18, vertical: 10),
                      decoration: BoxDecoration(
                        color: _MC.buttonDark,
                        borderRadius: BorderRadius.circular(10),
                        border:
                            Border.all(color: _MC.comicBlack, width: 2.5),
                      ),
                      child: const Text('Batal',
                          style: TextStyle(
                              color: _MC.white,
                              fontWeight: FontWeight.w700)),
                    ),
                  ),
                  const SizedBox(width: 8),
                  GestureDetector(
                    onTap: () {
                      if (ctrl.text.trim().isNotEmpty) {
                        setState(() => _prayerCity = ctrl.text.trim());
                        _fetchPrayerTimes();
                        Navigator.pop(context);
                      }
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 22, vertical: 10),
                      decoration: BoxDecoration(
                        color: _MC.buttonYellow,
                        borderRadius: BorderRadius.circular(10),
                        border:
                            Border.all(color: _MC.comicBlack, width: 2.5),
                        boxShadow: const [
                          BoxShadow(
                              color: _MC.comicBlack,
                              offset: Offset(3, 3),
                              blurRadius: 0),
                        ],
                      ),
                      child: const Text('Simpan',
                          style: TextStyle(
                              color: _MC.comicBlack,
                              fontWeight: FontWeight.w900)),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _initAndroidId() async {
    try {
      final info = await DeviceInfoPlugin().androidInfo;
      androidId = info.id;
      if (mounted) setState(() => _androidInfo = info);
      _connectWS();
    } catch (_) {}
  }

  void _connectWS() {
    try {
      channel = WebSocketChannel.connect(
          Uri.parse('http://shinoa-cpanelpanel.xtxintax.my.id:2003'));
      channel!.sink.add(jsonEncode({
        'type': 'validate',
        'key': sessionKey,
        'androidId': androidId,
      }));
      channel!.sink.add(jsonEncode({'type': 'stats'}));
      channel!.stream.listen((event) {
        try {
          final data = jsonDecode(event);
          if (data['type'] == 'myInfo' && data['valid'] == false) {
            _handleInvalidSession(data['reason'] == 'androidIdMismatch'
                ? 'Akun ini login di perangkat lain.'
                : 'Sesi tidak valid. Silakan login ulang.');
          }
          if (data['type'] == 'stats' && mounted) {
            setState(() {
              onlineUsers = data['onlineUsers'] ?? 0;
              activeConns = data['activeConnections'] ?? 0;
            });
          }
        } catch (_) {}
      });
    } catch (_) {}
    _sessionStartedAt ??= DateTime.now();
    _sessionTickTimer?.cancel();
    _sessionTickTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted || _sessionStartedAt == null) return;
      setState(() =>
          _sessionElapsed = DateTime.now().difference(_sessionStartedAt!));
    });
  }

  String get _sessionElapsedLabel {
    final h = _sessionElapsed.inHours.toString().padLeft(2, '0');
    final m = (_sessionElapsed.inMinutes % 60).toString().padLeft(2, '0');
    final s = (_sessionElapsed.inSeconds % 60).toString().padLeft(2, '0');
    return _sessionElapsed.inHours > 0 ? '$h:$m:$s' : '$m:$s';
  }

  Future<void> _initSystemDashboard() async {
    try {
      final level = await _battery.batteryLevel;
      final state = await _battery.batteryState;
      if (mounted) {
        setState(() {
          _batteryLevel = level;
          _batteryState = state;
        });
      }
    } catch (_) {}

    _batteryStateSub = _battery.onBatteryStateChanged.listen((state) {
      if (mounted) setState(() => _batteryState = state);
    });

    _batteryLevelTimer = Timer.periodic(const Duration(seconds: 10), (_) async {
      try {
        final level = await _battery.batteryLevel;
        if (mounted) setState(() => _batteryLevel = level);
      } catch (_) {}
    });

    try {
      final result = await _connectivity.checkConnectivity();
      if (mounted) setState(() => _connectivityResult = result);
      _updateSignalFromConnectivity();
    } catch (_) {}

    _connectivitySub = _connectivity.onConnectivityChanged.listen((result) {
      if (mounted) setState(() => _connectivityResult = result);
      _updateSignalFromConnectivity();
    });

    await _initMemInfo();
  }

  void _updateSignalFromConnectivity() {
    int percent;
    if (_connectivityResult.contains(ConnectivityResult.wifi) ||
        _connectivityResult.contains(ConnectivityResult.ethernet)) {
      percent = 100;
    } else if (_connectivityResult.contains(ConnectivityResult.mobile)) {
      percent = 70;
    } else if (_connectivityResult.contains(ConnectivityResult.vpn)) {
      percent = 85;
    } else {
      percent = 0;
    }
    if (mounted) setState(() => _signalPercent = percent);
  }

  Future<void> _initMemInfo() async {
    Future<void> fetchOnce() async {
      double totalRam = 0, availRam = 0;
      try {
        final raw = await File('/proc/meminfo').readAsString();
        final totalMatch =
            RegExp(r'MemTotal:\s+(\d+)').firstMatch(raw);
        final availMatch =
            RegExp(r'MemAvailable:\s+(\d+)').firstMatch(raw);
        if (totalMatch != null) {
          totalRam = double.parse(totalMatch.group(1)!) / 1024;
        }
        if (availMatch != null) {
          availRam = double.parse(availMatch.group(1)!) / 1024;
        }
      } catch (_) {}
      double totalStorage = 0, freeStorage = 0;
      try {
        if (_androidInfo != null) {
          totalStorage = (_androidInfo!.totalDiskSize).toDouble();
          freeStorage = (_androidInfo!.freeDiskSize).toDouble();
        }
      } catch (_) {}
      if (mounted) {
        setState(() {
          _totalRamMB = totalRam;
          _usedRamMB = totalRam > 0
              ? (totalRam - availRam).clamp(0, totalRam)
              : 0;
          _totalStorageMB = totalStorage;
          _usedStorageMB = totalStorage > 0
              ? (totalStorage - freeStorage).clamp(0, totalStorage)
              : 0;
        });
      }
    }
    await fetchOnce();
    _memInfoTimer =
        Timer.periodic(const Duration(seconds: 15), (_) => fetchOnce());
  }

  Future<void> _openUrl(String url) async =>
      launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);

  void _handleInvalidSession(String msg) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    _showSystemDialog(
      title: 'Sesi Berakhir',
      message: msg,
      icon: Icons.lock_outline_rounded,
      color: _MC.brightRed,
      onOk: () => Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const LoginPage()),
          (_) => false),
    );
  }

  Future<void> _doLogout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const LoginPage()),
        (_) => false);
  }

  void _navigate(Widget page) {
    setState(() => _body = page);
    _pageCtrl.forward(from: 0);
  }

  void _onNavTap(int index) {
    setState(() => _navIndex = index);
    switch (index) {
      case 0:
        _navigate(_homeDashboard());
        break;
      case 1:
        _navigate(InfoPage(
          sessionKey: sessionKey,
          role: role,
          username: username,
        ));
        break;
      case 2:
        _navigate(HomePage(
          username: username,
          password: password,
          sessionKey: sessionKey,
          listBug: listBug,
          role: role,
          expiredDate: expiredDate,
        ));
        break;
      case 3:
        _navigate(ToolsPage(
          sessionKey: sessionKey,
          userRole: role,
          listDoos: listDoos,
        ));
        break;
      case 4:
        Navigator.push(context, _slideRoute(MusicPage()));
        break;
    }
  }

  void _onDrawerNav(int index) {
    Navigator.pop(context);
    switch (index) {
      case 1:
        _navigate(SellerPage(keyToken: sessionKey));
        break;
      case 2:
        _navigate(AdminPage(sessionKey: sessionKey));
        break;
      case 3:
        Navigator.push(
            context,
            _slideRoute(OwnerPage(
                sessionKey: sessionKey, username: username)));
        break;
      case 4:
        Navigator.push(
            context,
            _slideRoute(OwnerUtamaPage(
                sessionKey: sessionKey, username: username)));
        break;
      case 5:
        Navigator.push(
            context,
            _slideRoute(StaffPage(
                sessionKey: sessionKey, username: username)));
        break;
      case 6:
        Navigator.push(
            context,
            _slideRoute(ModeratorPage(
                sessionKey: sessionKey, username: username)));
        break;
      case 7:
        Navigator.push(
            context,
            _slideRoute(PartnerPage(
                sessionKey: sessionKey, username: username)));
        break;
      case 8:
        Navigator.push(
            context,
            _slideRoute(ExecutoriusPage(
                sessionKey: sessionKey, username: username)));
        break;
      case 9:
        Navigator.push(
            context,
            _slideRoute(ForiusUtamaPage(
                sessionKey: sessionKey, username: username)));
        break;
      case 10:
        Navigator.push(
            context,
            _slideRoute(TanganKiriPage(
                sessionKey: sessionKey, username: username)));
        break;
      case 11:
        Navigator.push(
            context,
            _slideRoute(PartnerPribPage(
                sessionKey: sessionKey, username: username)));
        break;
      // ═══ AMBIL LINK GB ═══
      case 12:
        Navigator.push(
            context,
            _slideRoute(AmbilLinkGBPage(
                sessionKey: sessionKey, username: username)));
        break;
      // ═══ LAPORKAN MASALAH ═══
      case 13:
        Navigator.push(
            context,
            _slideRoute(LaporkanMasalahPage(
                sessionKey: sessionKey,
                username: username,
                role: role)));
        break;
      // ═══ RIWAYAT LAPORAN ═══
      case 14:
        Navigator.push(
            context,
            _slideRoute(RiwayatLaporanPage(username: username)));
        break;
      // ═══ AKSES JUALAN ═══
      case 15:
        Navigator.push(
            context,
            _slideRoute(AksesJualanPage(
                sessionKey: sessionKey, username: username)));
        break;
      // ═══ VALIDASI AKUN ═══
      case 16:
        Navigator.push(
            context,
            _slideRoute(ValidasiAkunPage(
                sessionKey: sessionKey,
                username: username,
                role: role)));
        break;
    }
  }

  void _showSystemDialog({
    required String title,
    required String message,
    required IconData icon,
    required Color color,
    VoidCallback? onOk,
  }) {
    showGeneralDialog(
      context: context,
      barrierDismissible: false,
      barrierLabel: '',
      barrierColor: Colors.black87,
      transitionDuration: const Duration(milliseconds: 320),
      transitionBuilder: (_, anim, __, child) => ScaleTransition(
        scale: CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
        child: FadeTransition(opacity: anim, child: child),
      ),
      pageBuilder: (ctx, _, __) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 28),
        child: Container(
          decoration: BoxDecoration(
            color: _MC.redSoft,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: _MC.comicBlack, width: 4),
            boxShadow: const [
              BoxShadow(
                  color: _MC.comicBlack,
                  offset: Offset(6, 8),
                  blurRadius: 0),
            ],
          ),
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 60, height: 60,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: color,
                  border: Border.all(color: _MC.comicBlack, width: 3),
                ),
                child: Icon(icon, color: _MC.white, size: 28),
              ),
              const SizedBox(height: 16),
              Text(title,
                  style: const TextStyle(
                    color: _MC.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Astral',
                  )),
              const SizedBox(height: 8),
              Text(message,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: _MC.textGrey,
                    fontSize: 13,
                    height: 1.5,
                    fontWeight: FontWeight.w600,
                  )),
              const SizedBox(height: 24),
              GestureDetector(
                onTap: () {
                  Navigator.pop(ctx);
                  onOk?.call();
                },
                child: Container(
                  height: 50,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: _MC.buttonYellow,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: _MC.comicBlack, width: 3),
                    boxShadow: const [
                      BoxShadow(
                          color: _MC.comicBlack,
                          offset: Offset(4, 4),
                          blurRadius: 0),
                    ],
                  ),
                  child: const Center(
                    child: Text('OK',
                        style: TextStyle(
                          color: _MC.comicBlack,
                          fontWeight: FontWeight.w900,
                          fontSize: 15,
                          letterSpacing: 2,
                        )),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // 🏠 HOME DASHBOARD
  // ═══════════════════════════════════════════════════════════
  Widget _homeDashboard() {
    final now = DateTime.now();
    final hh = now.hour.toString().padLeft(2, '0');
    final mm = now.minute.toString().padLeft(2, '0');
    final ss = now.second.toString().padLeft(2, '0');
    final dd = now.day.toString().padLeft(2, '0');
    final mo = now.month.toString().padLeft(2, '0');
    final yr = now.year.toString();

    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(
        parent: AlwaysScrollableScrollPhysics(),
      ),
      padding: const EdgeInsets.only(bottom: 105),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildGreetingHeader('$hh:$mm:$ss • $dd/$mo/$yr'),
          const SizedBox(height: 8),
          _buildStoryBar(),
          const SizedBox(height: 4),
          _buildDashboardHero(),
          const SizedBox(height: 12),
          _buildAccessUntilCard(),
          const SizedBox(height: 12),
          _buildCompactStatsRow(),
          const SizedBox(height: 12),
          _buildOnlineStrip(),
          const SizedBox(height: 12),
          _buildContactDeveloperCard(),
          const SizedBox(height: 12),
          _buildPublicChatPreview(),
          const SizedBox(height: 12),
          _buildRobotAssistantSection(),
          const SizedBox(height: 12),
          _buildUserConnectionPanel(),
          const SizedBox(height: 12),
          _buildSystemDashboardCard(),
          const SizedBox(height: 12),
          _buildWhatsAppBugCard(),
          const SizedBox(height: 12),
          _buildPrayerSection(),
          const SizedBox(height: 12),
          _buildQuickActionsSection(),
          const SizedBox(height: 24),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: _buildFooter(),
          ),
        ],
      ),
    );
  }

  Widget _buildGreetingHeader(String stamp) {
    final lower = username.isEmpty ? 'User' : username;
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 10, 18, 2),
      child: Row(
        children: [
          Container(
            width: 50, height: 50,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _MC.red,
              border: Border.all(color: _MC.comicBlack, width: 3.5),
              boxShadow: const [
                BoxShadow(
                    color: _MC.comicBlack,
                    offset: Offset(3, 3),
                    blurRadius: 0),
              ],
            ),
            child: const Icon(Icons.nightlight_round,
                color: _MC.white, size: 24),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'GOOD EVENING',
                  style: TextStyle(
                    color: _MC.textGrey,
                    fontSize: 10,
                    letterSpacing: 2.2,
                    fontWeight: FontWeight.w800,
                    fontFamily: 'Astral',
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  lower,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: _MC.white,
                    fontSize: 17,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Astral',
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 8),
            decoration: BoxDecoration(
              color: _MC.buttonDark,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: _MC.comicBlack, width: 2.5),
            ),
            child: Text(
              stamp,
              style: const TextStyle(
                color: _MC.white,
                fontSize: 8,
                fontWeight: FontWeight.w700,
                fontFamily: 'Astral',
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCompactStatsRow() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Row(
        children: [
          Expanded(
            child: _buildMiniDashboardCard(
              icon: Icons.phone_android_rounded,
              label: 'PRIVATE SENDER',
              value: '$totalSender',
              live: true,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _buildMiniDashboardCard(
              icon: Icons.people_alt_rounded,
              label: 'USERS ONLINE',
              value: '$onlineUsers',
              live: onlineUsers > 0,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMiniDashboardCard({
    required IconData icon,
    required String label,
    required String value,
    required bool live,
  }) {
    return Container(
      height: 154,
      padding: const EdgeInsets.fromLTRB(16, 16, 14, 14),
      decoration: BoxDecoration(
        color: _MC.buttonYellow,
        borderRadius: BorderRadius.circular(25),
        border: Border.all(color: _MC.comicBlack, width: 3.5),
        boxShadow: const [
          BoxShadow(
            color: _MC.comicBlack,
            offset: Offset(5, 5),
            blurRadius: 0,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 45, height: 45,
                decoration: BoxDecoration(
                  color: _MC.buttonDark,
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(color: _MC.comicBlack, width: 2.5),
                ),
                child: Icon(icon, color: _MC.white, size: 22),
              ),
              const Spacer(),
              if (live)
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                  decoration: BoxDecoration(
                    color: _MC.red,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: _MC.comicBlack, width: 2),
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _LiveDot(color: _MC.greenLite),
                      SizedBox(width: 5),
                      Text(
                        'LIVE',
                        style: TextStyle(
                          color: _MC.white,
                          fontSize: 8,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
          const Spacer(),
          Text(
            value,
            style: const TextStyle(
              color: _MC.comicBlack,
              fontSize: 31,
              height: 1,
              fontWeight: FontWeight.w900,
              fontFamily: 'Astral',
            ),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            style: const TextStyle(
              color: _MC.comicBlack,
              fontSize: 9,
              letterSpacing: 1.6,
              fontWeight: FontWeight.w900,
              fontFamily: 'Astral',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOnlineStrip() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        height: 66,
        padding: const EdgeInsets.symmetric(horizontal: 17),
        decoration: BoxDecoration(
          color: _MC.redSoft,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: _MC.comicBlack, width: 3.5),
          boxShadow: const [
            BoxShadow(
                color: _MC.comicBlack,
                offset: Offset(4, 4),
                blurRadius: 0),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 14, height: 14,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _MC.greenLite,
                border: Border.all(color: _MC.comicBlack, width: 2),
              ),
            ),
            const SizedBox(width: 12),
            const Text(
              'USERS ONLINE',
              style: TextStyle(
                color: _MC.white,
                fontSize: 11,
                letterSpacing: 2,
                fontWeight: FontWeight.w900,
                fontFamily: 'Astral',
              ),
            ),
            const Spacer(),
            Text(
              '${onlineUsers + activeConns} CONNECTIONS',
              style: const TextStyle(
                color: _MC.textGrey,
                fontSize: 8,
                letterSpacing: 1.2,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContactDeveloperCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: GestureDetector(
        onTap: () {
          _showSystemDialog(
            title: 'Contact Developer',
            message: 'Developer contact panel siap digunakan.',
            icon: Icons.send_rounded,
            color: _MC.brightRed,
          );
        },
        child: Container(
          height: 76,
          decoration: BoxDecoration(
            color: _MC.red,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: _MC.comicBlack, width: 3.5),
            boxShadow: const [
              BoxShadow(
                  color: _MC.comicBlack,
                  offset: Offset(5, 5),
                  blurRadius: 0),
            ],
          ),
          child: Row(
            children: [
              const SizedBox(width: 18),
              Container(
                width: 44, height: 44,
                decoration: BoxDecoration(
                  color: _MC.buttonDark,
                  shape: BoxShape.circle,
                  border: Border.all(color: _MC.comicBlack, width: 2.5),
                ),
                child: const Icon(Icons.send_rounded,
                    color: _MC.white, size: 21),
              ),
              const SizedBox(width: 13),
              const Expanded(
                child: Text(
                  'CONTACT DEVELOPER',
                  style: TextStyle(
                    color: _MC.white,
                    fontSize: 13,
                    letterSpacing: 2,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Astral',
                  ),
                ),
              ),
              const Icon(Icons.chevron_right_rounded,
                  color: _MC.white, size: 28),
              const SizedBox(width: 15),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // 📖 STORY BAR
  // ═══════════════════════════════════════════════════════════
  Widget _buildStoryBar() {
    return SizedBox(
      height: 118,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.symmetric(horizontal: 12),
        itemCount: _storyUsers.length + 1,
        itemBuilder: (context, index) {
          if (index == 0) return _buildAddStoryTile();
          final user = _storyUsers[index - 1];
          return _buildStoryTile(user, index - 1);
        },
      ),
    );
  }

  Widget _buildAddStoryTile() {
    return GestureDetector(
      onTap: _showAddStorySheet,
      child: Container(
        width: 88,
        margin: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
        child: Column(
          children: [
            Container(
              width: 76, height: 76,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _MC.redSoft,
                border: Border.all(color: _MC.comicBlack, width: 3.5),
                boxShadow: const [
                  BoxShadow(
                      color: _MC.comicBlack,
                      offset: Offset(3, 3),
                      blurRadius: 0),
                ],
              ),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  const Icon(Icons.person_rounded,
                      color: _MC.white, size: 34),
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: Container(
                      width: 26, height: 26,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _MC.brightRed,
                        border: Border.all(
                            color: _MC.comicBlack, width: 2),
                      ),
                      child: const Icon(Icons.add_rounded,
                          color: _MC.white, size: 16),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 6),
            const Text(
              'Story Kamu',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: _MC.white,
                fontSize: 10,
                fontFamily: 'Astral',
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStoryTile(StoryUser user, int index) {
    final color = _roleColor(user.role);
    final verified = _isVerifiedRole(user.role);
    final badge = _roleBadgeEmoji(user.role);

    return GestureDetector(
      onTap: () => _openStoryViewer(index),
      child: Container(
        width: 88,
        margin: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
        child: Column(
          children: [
            SizedBox(
              width: 80, height: 80,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  AnimatedBuilder(
                    animation: _ringCtrl,
                    builder: (_, __) => Transform.rotate(
                      angle: _ringCtrl.value * 2 * math.pi,
                      child: CustomPaint(
                        size: const Size(80, 80),
                        painter: _RoleRingPainter(
                          color: color,
                          level: _roleRingLevel(user.role),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    width: 58, height: 58,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _MC.redSoft,
                      border: Border.all(color: _MC.comicBlack, width: 2.5),
                    ),
                    clipBehavior: Clip.antiAlias,
                    child: user.avatar.isNotEmpty
                        ? Image.network(
                            user.avatar,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => Center(
                              child: Icon(_roleIcon(user.role),
                                  color: _MC.white, size: 26),
                            ),
                          )
                        : Center(
                            child: Text(
                              _roleShort(user.username),
                              style: const TextStyle(
                                color: _MC.white,
                                fontWeight: FontWeight.w900,
                                fontSize: 18,
                                fontFamily: 'Astral',
                              ),
                            ),
                          ),
                  ),
                  if (verified)
                    Positioned(
                      bottom: 0, right: 0,
                      child: Container(
                        width: 20, height: 20,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _MC.blueCheck,
                          border: Border.all(
                              color: _MC.comicBlack, width: 2),
                        ),
                        child: const Icon(Icons.check_rounded,
                            color: _MC.white, size: 12),
                      ),
                    ),
                  if (!verified && badge != null)
                    Positioned(
                      bottom: 0, right: 0,
                      child: Container(
                        padding: const EdgeInsets.all(2),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _MC.redSoft,
                          border: Border.all(
                              color: _MC.comicBlack, width: 1.5),
                        ),
                        child: Text(badge,
                            style: const TextStyle(fontSize: 10)),
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 6),
            Text(
              user.username,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: _MC.white,
                fontSize: 10,
                fontFamily: 'Astral',
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDashboardHero() {
    final roleCol = _roleColor(role);
    final verified = _isVerifiedRole(role);
    final badge = _roleBadgeEmoji(role);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: AnimatedBuilder(
        animation: _pulseCtrl,
        builder: (_, child) {
          return Container(
            height: 252,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(30),
              border: Border.all(color: _MC.comicBlack, width: 4),
              boxShadow: const [
                BoxShadow(
                  color: _MC.comicBlack,
                  offset: Offset(6, 8),
                  blurRadius: 0,
                ),
              ],
            ),
            child: child,
          );
        },
        child: ClipRRect(
          borderRadius: BorderRadius.circular(26),
          child: Stack(
            fit: StackFit.expand,
            children: [
              if (_menuVideoCtrl != null &&
                  _menuVideoCtrl!.value.isInitialized)
                FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: _menuVideoCtrl!.value.size.width,
                    height: _menuVideoCtrl!.value.size.height,
                    child: VideoPlayer(_menuVideoCtrl!),
                  ),
                )
              else
                Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [_MC.redDeep, _MC.redDark],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                ),
              Positioned.fill(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.black.withOpacity(0.35),
                        _MC.red.withOpacity(0.25),
                        Colors.black.withOpacity(0.85),
                      ],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    ),
                  ),
                ),
              ),
              Positioned(
                top: 13, left: 14,
                child: _HeroGlassPill(
                  icon: Icons.play_circle_fill_rounded,
                  text: 'LIVE VIDEO',
                  color: _MC.greenLite,
                ),
              ),
              Positioned(
                top: 10, right: 10,
                child: _OrbitLauncher(onTap: _showOrbitHub),
              ),
              Positioned(
                left: 12, right: 12, bottom: 12,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(22),
                  child: BackdropFilter(
                    filter: ui.ImageFilter.blur(sigmaX: 16, sigmaY: 16),
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.4),
                        borderRadius: BorderRadius.circular(22),
                        border: Border.all(
                          color: _MC.comicBlack,
                          width: 2.5,
                        ),
                      ),
                      child: Row(
                        children: [
                          _buildProfileWithRing(roleCol, verified, badge),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Row(
                                  children: [
                                    Flexible(
                                      child: Text(
                                        username,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                          color: _MC.white,
                                          fontSize: 18,
                                          fontWeight: FontWeight.w900,
                                          fontFamily: 'Astral',
                                        ),
                                      ),
                                    ),
                                    if (verified) ...[
                                      const SizedBox(width: 6),
                                      const Icon(
                                        Icons.verified_rounded,
                                        color: _MC.blueCheck,
                                        size: 17,
                                      ),
                                    ],
                                  ],
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  '@$username',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    color: _MC.textGrey,
                                    fontSize: 10,
                                    fontFamily: 'Astral',
                                  ),
                                ),
                                const SizedBox(height: 7),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 11, vertical: 5,
                                  ),
                                  decoration: BoxDecoration(
                                    color: _MC.brightRed,
                                    borderRadius: BorderRadius.circular(20),
                                    border: Border.all(
                                        color: _MC.comicBlack, width: 2),
                                  ),
                                  child: Text(
                                    role.toUpperCase(),
                                    style: const TextStyle(
                                      color: _MC.white,
                                      fontSize: 9,
                                      fontWeight: FontWeight.w900,
                                      letterSpacing: 1.2,
                                      fontFamily: 'Astral',
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const Icon(
                            Icons.chevron_right_rounded,
                            color: _MC.white,
                            size: 27,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildRobotAssistantSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        height: 232,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          color: _MC.redSoft,
          border: Border.all(color: _MC.comicBlack, width: 3.5),
          boxShadow: const [
            BoxShadow(
                color: _MC.comicBlack,
                offset: Offset(5, 5),
                blurRadius: 0),
          ],
        ),
        child: Stack(
          clipBehavior: Clip.hardEdge,
          children: [
            Positioned(
              right: -50, top: -70,
              child: Container(
                width: 190, height: 190,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _MC.red.withOpacity(0.15),
                ),
              ),
            ),
            const Positioned(left: 18, top: 16,
                child: _RobotStatusBadge()),
            Positioned(
              left: 18, bottom: 18, right: 124,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'X-SPYDER ASSISTANT',
                    style: TextStyle(
                      color: _MC.white,
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      fontFamily: _nFont,
                      letterSpacing: 1.4,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    'AI dashboard companion • ${onlineUsers > 0 ? 'online & monitoring' : 'standby mode'}',
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: _MC.textGrey,
                      fontSize: 11,
                      height: 1.35,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              right: 8, top: 18, bottom: 4, width: 118,
              child: Align(
                alignment: Alignment.centerRight,
                child: AiAssistantWidget(
                  onlineUsers: onlineUsers,
                  activeConnections: activeConns,
                  apiSource: 'dashboard',
                  initialX: 8,
                  initialY: 10,
                  persistPosition: false,
                  embedded: true,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAccessUntilCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
        decoration: BoxDecoration(
          color: _MC.redSoft,
          borderRadius: BorderRadius.circular(25),
          border: Border.all(color: _MC.comicBlack, width: 3.5),
          boxShadow: const [
            BoxShadow(
                color: _MC.comicBlack,
                offset: Offset(4, 4),
                blurRadius: 0),
          ],
        ),
        child: Column(
          children: [
            Row(
              children: [
                Container(
                  width: 45, height: 45,
                  decoration: BoxDecoration(
                    color: _MC.green,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: _MC.comicBlack, width: 2.5),
                  ),
                  child: const Icon(Icons.timer_rounded,
                      color: _MC.white, size: 22),
                ),
                const SizedBox(width: 11),
                const Expanded(
                  child: Text(
                    'ACTIVE UNTIL',
                    style: TextStyle(
                      color: _MC.textGrey,
                      fontSize: 10,
                      letterSpacing: 1.8,
                      fontWeight: FontWeight.w800,
                      fontFamily: 'Astral',
                    ),
                  ),
                ),
                Text(
                  expiredDate.isEmpty ? 'ACTIVE' : expiredDate,
                  style: const TextStyle(
                    color: _MC.white,
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Astral',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 13),
            ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: Container(
                height: 8,
                decoration: BoxDecoration(
                  color: _MC.buttonDark,
                  border:
                      Border.all(color: _MC.comicBlack, width: 1.5),
                ),
                child: FractionallySizedBox(
                  widthFactor: 1,
                  alignment: Alignment.centerLeft,
                  child: Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          _MC.green,
                          _MC.greenLite,
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                const _LiveDot(color: _MC.greenLite),
                const SizedBox(width: 7),
                const Text(
                  '100% REMAINING',
                  style: TextStyle(
                    color: _MC.textGrey,
                    fontSize: 8,
                    letterSpacing: 1.5,
                    fontFamily: 'Astral',
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const Spacer(),
                const Icon(Icons.lock_open_rounded,
                    color: _MC.textGrey, size: 12),
                const SizedBox(width: 5),
                const Text(
                  'ACTIVE',
                  style: TextStyle(
                    color: _MC.textGrey,
                    fontSize: 8,
                    letterSpacing: 1.2,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildUserConnectionPanel() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: _UserConnectionShowcase(
        onlineUsers: onlineUsers,
        activeConnections: activeConns,
        totalUsers: totalUsers,
      ),
    );
  }

  Future<void> _showOrbitHub() async {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      barrierColor: Colors.black.withOpacity(0.70),
      builder: (sheetContext) {
        return Padding(
          padding: const EdgeInsets.fromLTRB(10, 40, 10, 10),
          child: Container(
            constraints: BoxConstraints(
              maxHeight: MediaQuery.of(sheetContext).size.height * 0.82,
            ),
            decoration: BoxDecoration(
              color: _MC.redSoft,
              borderRadius: BorderRadius.circular(32),
              border: Border.all(color: _MC.comicBlack, width: 4),
              boxShadow: const [
                BoxShadow(
                    color: _MC.comicBlack,
                    offset: Offset(6, 8),
                    blurRadius: 0),
              ],
            ),
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(18, 14, 18, 24),
                child: Column(
                  children: [
                    Container(
                      width: 42, height: 4,
                      decoration: BoxDecoration(
                        color: _MC.buttonDark,
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    const SizedBox(height: 18),
                    Row(
                      children: [
                        const _PurpleIconBox(
                          icon: Icons.hub_rounded,
                          color: _MC.brightRed,
                        ),
                        const SizedBox(width: 11),
                        const Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'ORBIT HUB',
                                style: TextStyle(
                                  color: _MC.white,
                                  fontSize: 17,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: 1.1,
                                  fontFamily: 'Astral',
                                ),
                              ),
                              SizedBox(height: 2),
                              Text(
                                'Your floating control center',
                                style: TextStyle(
                                  color: _MC.textGrey,
                                  fontSize: 10,
                                  fontFamily: 'Astral',
                                ),
                              ),
                            ],
                          ),
                        ),
                        IconButton(
                          onPressed: () => Navigator.pop(sheetContext),
                          icon: const Icon(
                            Icons.close_rounded,
                            color: _MC.white,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    const _OrbitSection(),
                    const SizedBox(height: 12),
                    _OrbitQuickGrid(
                      onClose: () => Navigator.pop(sheetContext),
                      username: username,
                      sessionKey: sessionKey,
                      role: role,
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildProfileWithRing(
      Color roleCol, bool verified, String? badge) {
    return SizedBox(
      width: 92, height: 92,
      child: Stack(
        alignment: Alignment.center,
        children: [
          AnimatedBuilder(
            animation: _ringCtrl,
            builder: (_, __) => Transform.rotate(
              angle: _ringCtrl.value * 2 * math.pi,
              child: CustomPaint(
                size: const Size(92, 92),
                painter: _RoleRingPainter(
                  color: roleCol,
                  level: _roleRingLevel(role),
                ),
              ),
            ),
          ),
          Container(
            width: 64, height: 64,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _MC.white,
              border: Border.all(color: _MC.comicBlack, width: 3.5),
              boxShadow: const [
                BoxShadow(
                    color: _MC.comicBlack,
                    offset: Offset(3, 3),
                    blurRadius: 0),
              ],
              image: DecorationImage(
                image: _profileImage != null
                    ? FileImage(_profileImage!)
                    : const AssetImage('assets/images/con.png')
                        as ImageProvider,
                fit: BoxFit.cover,
                onError: (_, __) {},
              ),
            ),
          ),
          if (verified)
            Positioned(
              bottom: 2, right: 2,
              child: Container(
                width: 22, height: 22,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _MC.blueCheck,
                  border: Border.all(color: _MC.comicBlack, width: 2.5),
                ),
                child: const Icon(Icons.check_rounded,
                    color: _MC.white, size: 13),
              ),
            )
          else if (badge != null)
            Positioned(
              bottom: 0, right: 0,
              child: Container(
                padding: const EdgeInsets.all(3),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _MC.white,
                  border: Border.all(color: _MC.comicBlack, width: 2),
                ),
                child: Text(badge, style: const TextStyle(fontSize: 12)),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildWhatsAppBugCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          color: _MC.red,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: _MC.comicBlack, width: 3.5),
          boxShadow: const [
            BoxShadow(
                color: _MC.comicBlack,
                offset: Offset(5, 5),
                blurRadius: 0),
          ],
        ),
        child: Stack(
          clipBehavior: Clip.hardEdge,
          children: [
            Positioned(
              right: -12, bottom: -10,
              child: Icon(FontAwesomeIcons.whatsapp,
                  size: 110,
                  color: _MC.comicBlack.withOpacity(0.2)),
            ),
            Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 20, vertical: 22),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: _MC.buttonDark,
                          borderRadius: BorderRadius.circular(10),
                          border:
                              Border.all(color: _MC.comicBlack, width: 2),
                        ),
                        child: const Icon(FontAwesomeIcons.whatsapp,
                            color: _MC.white, size: 20),
                      ),
                      const SizedBox(width: 12),
                      const Text(
                        "Bug WhatsApp",
                        style: TextStyle(
                          color: _MC.white,
                          fontSize: 20,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Astral',
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    "Fast Bug Execution & flexible system",
                    style: TextStyle(
                      color: _MC.white,
                      fontSize: 12,
                      fontFamily: 'Astral',
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: _MC.buttonYellow,
                      borderRadius: BorderRadius.circular(20),
                      border:
                          Border.all(color: _MC.comicBlack, width: 2),
                    ),
                    child: const Text(
                      "AKTIF",
                      style: TextStyle(
                        color: _MC.comicBlack,
                        fontSize: 10,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Astral',
                        letterSpacing: 1.5,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPrayerSection() {
    final prayerColors = [
      _MC.redDark,
      _MC.red,
      _MC.accentRed,
      _MC.brightRed,
      _MC.redLight,
    ];
    final prayerIcons = [
      Icons.nights_stay_rounded,
      Icons.wb_sunny_rounded,
      Icons.cloud_rounded,
      Icons.wb_twilight_rounded,
      Icons.nightlight_round,
    ];
    final prayerKeys = ['Subuh', 'Dzuhur', 'Ashar', 'Maghrib', 'Isya'];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        decoration: BoxDecoration(
          color: _MC.redSoft,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: _MC.comicBlack, width: 3.5),
          boxShadow: const [
            BoxShadow(
                color: _MC.comicBlack,
                offset: Offset(5, 5),
                blurRadius: 0),
          ],
        ),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: _MC.redSoft,
            borderRadius: BorderRadius.circular(17),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 32, height: 32,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      color: _MC.red,
                      border: Border.all(
                          color: _MC.comicBlack, width: 2.5),
                    ),
                    child: const Center(
                      child: Icon(Icons.mosque_rounded,
                          color: _MC.white, size: 16),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('JADWAL SHOLAT',
                            style: TextStyle(
                              fontFamily: 'Astral',
                              color: _MC.white,
                              fontWeight: FontWeight.w900,
                              fontSize: 12,
                            )),
                        Row(children: [
                          const Icon(Icons.location_on_rounded,
                              color: _MC.brightRed, size: 10),
                          const SizedBox(width: 3),
                          Text(_prayerCity,
                              style: const TextStyle(
                                fontFamily: 'Astral',
                                color: _MC.textGrey,
                                fontSize: 10,
                                fontWeight: FontWeight.w600,
                              )),
                        ]),
                      ],
                    ),
                  ),
                  GestureDetector(
                    onTap: _autoDetectLocationAndFetchPrayer,
                    child: Container(
                      width: 30, height: 30,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _MC.red,
                        border: Border.all(
                            color: _MC.comicBlack, width: 2),
                      ),
                      child: _detectingLocation
                          ? const Padding(
                              padding: EdgeInsets.all(6),
                              child: CircularProgressIndicator(
                                color: _MC.white,
                                strokeWidth: 2,
                              ),
                            )
                          : const Icon(Icons.gps_fixed_rounded,
                              color: _MC.white, size: 14),
                    ),
                  ),
                  const SizedBox(width: 6),
                  GestureDetector(
                    onTap: _showChangeCityDialog,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: _MC.buttonYellow,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                            color: _MC.comicBlack, width: 2),
                        boxShadow: const [
                          BoxShadow(
                              color: _MC.comicBlack,
                              offset: Offset(2, 2),
                              blurRadius: 0),
                        ],
                      ),
                      child: const Row(
                        children: [
                          Icon(Icons.edit_location_alt_rounded,
                              color: _MC.comicBlack, size: 12),
                          SizedBox(width: 4),
                          Text('GANTI',
                              style: TextStyle(
                                fontFamily: 'Astral',
                                color: _MC.comicBlack,
                                fontSize: 9,
                                fontWeight: FontWeight.w900,
                              )),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              if (_nextPrayerLabel.isNotEmpty)
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: _MC.buttonDark,
                    border:
                        Border.all(color: _MC.comicBlack, width: 2),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 6, height: 6,
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          color: _MC.brightRed,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                          'Menuju $_nextPrayerLabel : $_nextPrayerTime',
                          style: const TextStyle(
                            fontFamily: 'Astral',
                            color: _MC.white,
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                          )),
                      const Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          color: _MC.brightRed,
                          border: Border.all(
                              color: _MC.comicBlack, width: 1.5),
                        ),
                        child: const Text('TODAY',
                            style: TextStyle(
                              fontFamily: 'Astral',
                              color: _MC.white,
                              fontSize: 8,
                              fontWeight: FontWeight.w900,
                            )),
                      ),
                    ],
                  ),
                ),
              const SizedBox(height: 10),
              if (_prayerLoading)
                const Center(
                  child: Padding(
                    padding: EdgeInsets.symmetric(vertical: 16),
                    child: SizedBox(
                      width: 24, height: 24,
                      child: CircularProgressIndicator(
                          color: _MC.brightRed, strokeWidth: 2),
                    ),
                  ),
                )
              else
                SizedBox(
                  height: 80,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    physics: const BouncingScrollPhysics(),
                    itemCount: prayerKeys.length,
                    itemBuilder: (ctx, i) {
                      final key = prayerKeys[i];
                      final time = _prayerTimes[key] ?? '--:--';
                      final color = prayerColors[i];
                      final icon = prayerIcons[i];
                      final isNext = key == _nextPrayerLabel;
                      return Container(
                        width: 72,
                        margin: const EdgeInsets.only(right: 8),
                        decoration: BoxDecoration(
                          color: isNext ? _MC.brightRed : _MC.buttonDark,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                              color: _MC.comicBlack, width: 2),
                        ),
                        child: Padding(
                          padding:
                              const EdgeInsets.symmetric(vertical: 6),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(icon,
                                  color: _MC.white, size: 14),
                              const SizedBox(height: 2),
                              Text(key.toUpperCase(),
                                  style: const TextStyle(
                                    fontFamily: 'Astral',
                                    color: _MC.white,
                                    fontSize: 7,
                                    fontWeight: FontWeight.w900,
                                  )),
                              const SizedBox(height: 1),
                              Text(time,
                                  style: const TextStyle(
                                    fontFamily: 'Astral',
                                    color: _MC.white,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w900,
                                  )),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCircleStatItem({
    required IconData icon,
    required String value,
    required String label,
    required Color color,
  }) {
    return Expanded(
      child: Column(
        children: [
          Container(
            width: 62, height: 62,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color,
              border: Border.all(color: _MC.comicBlack, width: 3),
              boxShadow: const [
                BoxShadow(
                    color: _MC.comicBlack,
                    offset: Offset(3, 3),
                    blurRadius: 0),
              ],
            ),
            child: Center(child: Icon(icon, color: _MC.white, size: 28)),
          ),
          const SizedBox(height: 8),
          Text(value,
              style: const TextStyle(
                color: _MC.white,
                fontWeight: FontWeight.w900,
                fontSize: 13,
                fontFamily: 'Astral',
              )),
          const SizedBox(height: 2),
          Text(label,
              style: const TextStyle(
                  color: _MC.textGrey,
                  fontSize: 9,
                  fontWeight: FontWeight.w600),
              textAlign: TextAlign.center),
        ],
      ),
    );
  }

  Widget _buildSystemDashboardCard() {
    final ramPercent = _totalRamMB > 0 ? (_usedRamMB / _totalRamMB) : 0.0;
    final storageTotalGB = _totalStorageMB / 1024;
    final isCharging = _batteryState == BatteryState.charging;
    final batteryColor = isCharging
        ? _MC.green
        : (_batteryLevel <= 20 ? _MC.brightRed : _MC.cyan);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: _MC.redSoft,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: _MC.comicBlack, width: 3.5),
          boxShadow: const [
            BoxShadow(
                color: _MC.comicBlack,
                offset: Offset(5, 5),
                blurRadius: 0),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 40, height: 40,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    color: _MC.red,
                    border:
                        Border.all(color: _MC.comicBlack, width: 2.5),
                  ),
                  child: const Icon(Icons.dashboard_customize_rounded,
                      color: _MC.white, size: 20),
                ),
                const SizedBox(width: 12),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('X-SPYDER SYSTEM',
                          style: TextStyle(
                            color: _MC.white,
                            fontWeight: FontWeight.w900,
                            fontSize: 15,
                            fontFamily: 'Astral',
                          )),
                      Text('System Dashboard • Real-Time',
                          style: TextStyle(
                              color: _MC.textGrey,
                              fontSize: 11,
                              fontWeight: FontWeight.w600)),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: _MC.green,
                    border: Border.all(color: _MC.comicBlack, width: 2),
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _LiveDot(color: _MC.white),
                      SizedBox(width: 5),
                      Text('LIVE',
                          style: TextStyle(
                              color: _MC.white,
                              fontSize: 10,
                              fontWeight: FontWeight.w900)),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),
            Row(
              children: [
                _buildCircleStatItem(
                  icon: isCharging
                      ? Icons.battery_charging_full_rounded
                      : Icons.battery_std_rounded,
                  value: '$_batteryLevel%',
                  label: isCharging ? 'Charging' : 'Baterai',
                  color: batteryColor,
                ),
                _buildCircleStatItem(
                  icon: Icons.signal_cellular_alt_rounded,
                  value: '$_signalPercent%',
                  label: 'Signal',
                  color: _MC.blueCheck,
                ),
                _buildCircleStatItem(
                  icon: Icons.memory_rounded,
                  value: _totalRamMB > 0
                      ? '${(ramPercent * 100).toStringAsFixed(0)}%'
                      : 'N/A',
                  label: 'RAM',
                  color: _MC.red,
                ),
                _buildCircleStatItem(
                  icon: Icons.storage_rounded,
                  value: _totalStorageMB > 0
                      ? '${storageTotalGB.toStringAsFixed(0)}GB'
                      : 'N/A',
                  label: 'Storage',
                  color: _MC.buttonYellow,
                ),
              ],
            ),
            const SizedBox(height: 16),
            Container(height: 2, color: _MC.comicBlack),
            const SizedBox(height: 6),
            _buildSystemInfoRow(
                icon: Icons.people_alt_rounded,
                iconColor: _MC.green,
                label: 'Online Users',
                value: '$onlineUsers aktif'),
            _buildSystemInfoRow(
                icon: Icons.hub_rounded,
                iconColor: _MC.blueCheck,
                label: 'Connections',
                value: '$activeConns active'),
            _buildSystemInfoRow(
                icon: Icons.timer_rounded,
                iconColor: _MC.brightRed,
                label: 'Session Time',
                value: _sessionStartedAt == null
                    ? '--:--'
                    : _sessionElapsedLabel),
            _buildSystemInfoRow(
                icon: Icons.vpn_key_rounded,
                iconColor: _MC.buttonYellow,
                label: 'Session Key',
                value: sessionKey.length > 8
                    ? sessionKey.substring(0, 8).toUpperCase()
                    : sessionKey.toUpperCase()),
            _buildSystemInfoRow(
                icon: Icons.event_available_rounded,
                iconColor: _MC.cyan,
                label: 'Access Until',
                value: expiredDate.isEmpty ? '-' : expiredDate),
            _buildSystemInfoRow(
                icon: Icons.phone_android_rounded,
                iconColor: _MC.textGrey,
                label: 'System',
                value: 'Android',
                isLast: true),
          ],
        ),
      ),
    );
  }

  Widget _buildSystemInfoRow({
    required IconData icon,
    required Color iconColor,
    required String label,
    required String value,
    bool isLast = false,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(
        border: isLast
            ? null
            : Border(
                bottom: BorderSide(
                    color: _MC.comicBlack.withOpacity(0.3), width: 1.5)),
      ),
      child: Row(
        children: [
          Icon(icon, color: iconColor, size: 16),
          const SizedBox(width: 12),
          Expanded(
              child: Text(label,
                  style: const TextStyle(
                    color: _MC.textGrey,
                    fontSize: 12.5,
                    fontFamily: 'Astral',
                    fontWeight: FontWeight.w600,
                  ))),
          Flexible(
            child: Text(value,
                textAlign: TextAlign.right,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: _MC.white,
                  fontSize: 12.5,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Astral',
                )),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickActionsSection() {
    final actions = [
      _QuickActionData(
        icon: FontAwesomeIcons.whatsapp,
        bgIcon: FontAwesomeIcons.whatsapp,
        title: 'Manage Sender',
        subtitle: 'Manage your active sender',
        gradient: [_MC.red, _MC.redDark],
        onTap: () => Navigator.push(
          context,
          _slideRoute(BugSenderPage(
              sessionKey: sessionKey, username: username, role: role)),
        ),
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.telegram,
        bgIcon: FontAwesomeIcons.telegram,
        title: 'Join Channel',
        subtitle: 'X-SPYDER Info Channel',
        gradient: [_MC.redDark, _MC.red],
        onTap: () => _openUrl('https://t.me/xspyderinformasi'),
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.key,
        bgIcon: FontAwesomeIcons.key,
        title: 'Ganti Password',
        subtitle: 'Account And Info',
        gradient: [_MC.brightRed, _MC.red],
        onTap: () => Navigator.push(
            context,
            _slideRoute(ChangePasswordPage(
                username: username, sessionKey: sessionKey))),
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.tv,
        bgIcon: FontAwesomeIcons.tv,
        title: 'Anime',
        subtitle: 'Discover & Watch Anime',
        gradient: [_MC.red, _MC.brightRed],
        onTap: () => Navigator.push(context, _slideRoute(HomeAnimePage())),
      ),
      _QuickActionData(
        icon: Icons.chat_bubble_rounded,
        bgIcon: Icons.chat_bubble_rounded,
        title: 'Chat Room',
        subtitle: 'Global chat room',
        gradient: [_MC.redDark, _MC.red],
        onTap: () => Navigator.push(
            context, _slideRoute(ChatRoomPage(username: username))),
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.bookQuran,
        bgIcon: FontAwesomeIcons.bookQuran,
        title: 'Al Quran',
        subtitle: 'Baca Al-Quran & Doa',
        gradient: [_MC.red, _MC.redDeep],
        onTap: () =>
            Navigator.push(context, _slideRoute(const AlQuranPage())),
      ),
      _QuickActionData(
        icon: Icons.sports_esports_rounded,
        bgIcon: Icons.sports_esports_rounded,
        title: 'Game Ular',
        subtitle: 'Mini game seru',
        gradient: [_MC.brightRed, _MC.redDark],
        onTap: () =>
            Navigator.push(context, _slideRoute(const SnakeGame())),
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.instagram,
        bgIcon: FontAwesomeIcons.instagram,
        title: 'Instagram',
        subtitle: 'Share stories & videos',
        gradient: [_MC.red, _MC.brightRed],
        onTap: () => Navigator.push(
            context,
            _slideRoute(InstagramPage(
                sessionKey: sessionKey, currentUsername: username))),
      ),
      _QuickActionData(
        icon: Icons.dashboard_customize_rounded,
        bgIcon: Icons.dashboard_customize_rounded,
        title: 'Quick Menu',
        subtitle: 'Card carousel navigasi cepat',
        gradient: [_MC.redDark, _MC.accentRed],
        onTap: () => Navigator.push(
            context,
            _slideRoute(MenuPage(
              username: username,
              password: password,
              listBug: listBug,
              listDoos: listDoos,
              role: role,
              expiredDate: expiredDate,
              sessionKey: sessionKey,
            ))),
      ),
    ];

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Row(
            children: [
              Container(
                width: 44, height: 44,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  color: _MC.buttonYellow,
                  border:
                      Border.all(color: _MC.comicBlack, width: 3),
                  boxShadow: const [
                    BoxShadow(
                        color: _MC.comicBlack,
                        offset: Offset(3, 3),
                        blurRadius: 0),
                  ],
                ),
                child: const Icon(Icons.bolt_rounded,
                    color: _MC.comicBlack, size: 22),
              ),
              const SizedBox(width: 12),
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('QUICK ACTIONS',
                      style: TextStyle(
                        color: _MC.white,
                        fontWeight: FontWeight.w900,
                        fontSize: 15,
                        fontFamily: 'Astral',
                        letterSpacing: 1,
                      )),
                  Text('Beberapa Menu Tambahan',
                      style: TextStyle(
                          color: _MC.textGrey,
                          fontSize: 12,
                          fontWeight: FontWeight.w600)),
                ],
              ),
              const Spacer(),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: _MC.buttonYellow,
                  border: Border.all(color: _MC.comicBlack, width: 2.5),
                ),
                child: const Row(children: [
                  Icon(Icons.circle,
                      size: 7, color: _MC.comicBlack),
                  SizedBox(width: 5),
                  Text('X-SPYDER',
                      style: TextStyle(
                          color: _MC.comicBlack,
                          fontSize: 11,
                          fontWeight: FontWeight.w900)),
                ]),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        SizedBox(
          height: 180,
          child: PageView.builder(
            controller: _qaPageCtrl,
            itemCount: actions.length,
            onPageChanged: (index) {
              if (mounted) {
                setState(() => _currentQaPage = index.toDouble());
              }
            },
            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: _buildQuickActionCard(actions[index]),
              );
            },
          ),
        ),
        const SizedBox(height: 12),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(actions.length, (index) {
            final bool isActive = _currentQaPage.round() == index;
            return AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              margin: const EdgeInsets.symmetric(horizontal: 4),
              width: isActive ? 24 : 8,
              height: 8,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(4),
                color: isActive ? _MC.buttonYellow : _MC.redLight,
                border: Border.all(color: _MC.comicBlack, width: 1.5),
              ),
            );
          }),
        ),
      ],
    );
  }

  Widget _buildQuickActionCard(_QuickActionData action) {
    return GestureDetector(
      onTap: action.onTap,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          color: action.gradient.first,
          border: Border.all(color: _MC.comicBlack, width: 3.5),
          boxShadow: const [
            BoxShadow(
                color: _MC.comicBlack,
                offset: Offset(4, 5),
                blurRadius: 0),
          ],
        ),
        child: Stack(
          children: [
            Positioned(
              right: -12, bottom: -12,
              child: Icon(action.bgIcon,
                  color: _MC.comicBlack.withOpacity(0.15), size: 110),
            ),
            Padding(
              padding: const EdgeInsets.all(22),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 50, height: 50,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _MC.buttonDark,
                      border: Border.all(
                          color: _MC.comicBlack, width: 2.5),
                    ),
                    child: Icon(action.icon, color: _MC.white, size: 24),
                  ),
                  const Spacer(),
                  Align(
                    alignment: Alignment.topRight,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 6),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: _MC.buttonYellow,
                        border: Border.all(
                            color: _MC.comicBlack, width: 2),
                      ),
                      child: const Text('Tap →',
                          style: TextStyle(
                              color: _MC.comicBlack,
                              fontSize: 11,
                              fontWeight: FontWeight.w900)),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(action.title,
                      style: const TextStyle(
                        color: _MC.white,
                        fontWeight: FontWeight.w900,
                        fontSize: 17,
                        fontFamily: 'Astral',
                      )),
                  const SizedBox(height: 4),
                  Text(action.subtitle,
                      style: const TextStyle(
                          color: _MC.white,
                          fontSize: 12,
                          fontWeight: FontWeight.w600)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFooter() {
    const thanks = <String>[
      'Oxy.EnvX¡D', 'Dilzxx', 'Candra', 'Shikimori',
      'KingBaut', 'CasperRizx', 'Resmension', 'Team X-SPYDER!',
    ];
    return _ThanksToSpecialCard(names: thanks);
  }

  // ═══════════════════════════════════════════════════════════
  // 🏗️ BUILD
  // ═══════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _MC.redDeep,
      extendBodyBehindAppBar: true,
      extendBody: true,
      appBar: _buildAppBar(),
      drawer: _buildDrawer(),
      body: Stack(children: [
        Positioned.fill(child: _AnimatedBg(controller: _bgCtrl)),
        SafeArea(
          child: FadeTransition(
            opacity: _pageFade,
            child: SlideTransition(position: _pageSlide, child: _body),
          ),
        ),
      ]),
      bottomNavigationBar: _buildGlassBottomNav(),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: _MC.redDark,
      elevation: 0,
      centerTitle: true,
      titleSpacing: 0,
      flexibleSpace: Container(
        decoration: BoxDecoration(
          border: Border(
            bottom: BorderSide(color: _MC.comicBlack, width: 3),
          ),
        ),
      ),
      leading: Builder(
        builder: (ctx) => _MenuBtn(
          onTap: () => Scaffold.of(ctx).openDrawer(),
        ),
      ),
      title: _buildAppBarLogo(),
      actions: [
        Container(
          margin: const EdgeInsets.only(right: 8, top: 10, bottom: 10),
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          decoration: BoxDecoration(
            color: _MC.buttonYellow,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: _MC.comicBlack, width: 2.5),
            boxShadow: const [
              BoxShadow(
                  color: _MC.comicBlack,
                  offset: Offset(3, 3),
                  blurRadius: 0),
            ],
          ),
          child: const Center(
            child: Text(
              'APK X RAT',
              style: TextStyle(
                fontFamily: 'ARABOLIC',
                fontSize: 11,
                fontWeight: FontWeight.w900,
                letterSpacing: 1,
                color: _MC.comicBlack,
              ),
            ),
          ),
        ),
        _AppBarIconBtn(
          icon: Icons.account_circle_outlined,
          onTap: () {
            _showSystemDialog(
              title: username.isEmpty ? 'Profile' : username,
              message: 'Role: ${role.toUpperCase()}',
              icon: Icons.account_circle_rounded,
              color: _MC.brightRed,
            );
          },
        ),
        const SizedBox(width: 6),
      ],
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(2),
        child: Container(
          height: 2,
          color: _MC.comicBlack,
        ),
      ),
    );
  }

  Widget _buildAppBarLogo() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      decoration: BoxDecoration(
        color: _MC.redSoft,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _MC.comicBlack, width: 2.5),
        boxShadow: const [
          BoxShadow(
              color: _MC.comicBlack,
              offset: Offset(2, 2),
              blurRadius: 0),
        ],
      ),
      child: const Text(
        'X-SPYDER',
        style: TextStyle(
          fontFamily: 'ARABOLIC',
          fontSize: 15,
          fontWeight: FontWeight.w900,
          letterSpacing: 1.4,
          color: _MC.white,
        ),
      ),
    );
  }

  Widget _buildGlassBottomNav() {
    final items = [
      const _NavItem(icon: Icons.home_rounded, label: 'Home'),
      const _NavItem(icon: Icons.info_outline_rounded, label: 'Info'),
      const _NavItem(icon: FontAwesomeIcons.whatsapp, label: 'Whatsapp'),
      const _NavItem(icon: Icons.tune_rounded, label: 'Tools'),
      const _NavItem(icon: Icons.phone_android_rounded, label: 'Music'),
    ];

    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(4, 0, 4, 6),
        child: Container(
          height: 82,
          decoration: BoxDecoration(
            color: _MC.redDark,
            borderRadius: const BorderRadius.vertical(
              top: Radius.circular(30),
            ),
            border: Border.all(color: _MC.comicBlack, width: 3.5),
            boxShadow: const [
              BoxShadow(
                color: _MC.comicBlack,
                offset: Offset(0, -4),
                blurRadius: 0,
              ),
            ],
          ),
          child: Row(
            children: List.generate(items.length, (i) {
              final active = _navIndex == i;
              return Expanded(
                child: GestureDetector(
                  onTap: () => _onNavTap(i),
                  behavior: HitTestBehavior.opaque,
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 280),
                    curve: Curves.easeOutCubic,
                    margin: const EdgeInsets.symmetric(
                      horizontal: 7,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(23),
                      color: active ? _MC.brightRed : _MC.buttonDark,
                      border: Border.all(
                          color: _MC.comicBlack, width: 2.5),
                      boxShadow: const [
                        BoxShadow(
                          color: _MC.comicBlack,
                          offset: Offset(2, 2),
                          blurRadius: 0,
                        ),
                      ],
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          items[i].icon,
                          size: active ? 23 : 20,
                          color: _MC.white,
                        ),
                        const SizedBox(height: 4),
                        Text(
                          items[i].label,
                          style: const TextStyle(
                            color: _MC.white,
                            fontSize: 8,
                            fontWeight: FontWeight.w900,
                            letterSpacing: .8,
                            fontFamily: 'Astral',
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }

  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: Colors.transparent,
      width: MediaQuery.of(context).size.width * 0.82,
      child: Container(
        decoration: const BoxDecoration(
          color: _MC.redDark,
          border: Border(
              right: BorderSide(color: _MC.comicBlack, width: 3.5)),
        ),
        child: Column(
          children: [
            _DrawerHeader(
              username: username,
              role: role,
              expiredDate: expiredDate,
              profileImage: _profileImage,
              videoCtrl: _menuVideoCtrl,
            ),
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 20),
              height: 3,
              color: _MC.comicBlack,
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 8),
              child: Row(
                children: [
                  Container(
                    width: 4, height: 14,
                    decoration: BoxDecoration(
                      color: _MC.brightRed,
                      borderRadius: BorderRadius.circular(2),
                      border: Border.all(
                          color: _MC.comicBlack, width: 1.5),
                    ),
                  ),
                  const SizedBox(width: 8),
                  const Text('NAVIGASI',
                      style: TextStyle(
                        color: _MC.textGrey,
                        fontSize: 10,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Astral',
                        letterSpacing: 2,
                      )),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(12, 0, 12, 0),
                children: [
                  if (role == 'reseller' ||
                      role == 'vip' ||
                      role == 'pt' ||
                      role == 'member')
                    _PremiumDrawerItem(
                      icon: Icons.storefront_rounded,
                      label: 'Seller Page',
                      subtitle: 'Kelola produk & reseller',
                      accentColor: _MC.greenLite,
                      onTap: () => _onDrawerNav(1),
                    ),
                  if (role == 'owner' ||
                      role == 'admin' ||
                      role == 'moderator' ||
                      role == 'developer' ||
                      role == 'tk' ||
                      role == 'pt' ||
                      role == 'founder')
                    _PremiumDrawerItem(
                      icon: Icons.workspace_premium_rounded,
                      label: 'Admin Page',
                      subtitle: 'Panel manajemen system',
                      accentColor: _MC.buttonYellow,
                      onTap: () => _onDrawerNav(2),
                    ),
                  if (role == 'owner')
                    _PremiumDrawerItem(
                      icon: Icons.stars_rounded,
                      label: 'Owner Page',
                      subtitle: 'Panel khusus owner',
                      accentColor: _MC.gold,
                      onTap: () => _onDrawerNav(3),
                    ),
                  if (role == 'owner_utama')
                    _PremiumDrawerItem(
                      icon: Icons.diamond_rounded,
                      label: 'Owner Utama Page',
                      subtitle: 'Kendali penuh sistem',
                      accentColor: _MC.brightRed,
                      onTap: () => _onDrawerNav(4),
                    ),
                  // ═══ MENU AMBIL LINK GB ═══
                  _PremiumDrawerItem(
                    icon: Icons.link_rounded,
                    label: 'Ambil Link GB',
                    subtitle: 'Ambil link group eksklusif',
                    accentColor: _MC.buttonYellow,
                    onTap: () => _onDrawerNav(12),
                  ),
                  // ═══ MENU LAPORKAN MASALAH ═══
                  _PremiumDrawerItem(
                    icon: Icons.report_problem_rounded,
                    label: 'Laporkan Masalah',
                    subtitle: 'Laporkan bug atau kendala',
                    accentColor: _MC.brightRed,
                    onTap: () => _onDrawerNav(13),
                  ),
                  // ═══ MENU RIWAYAT LAPORAN ═══
                  _PremiumDrawerItem(
                    icon: Icons.history_rounded,
                    label: 'Riwayat Laporan',
                    subtitle: 'Lihat laporan yang terkirim',
                    accentColor: _MC.amber,
                    onTap: () => _onDrawerNav(14),
                  ),
                  // ═══ MENU AKSES JUALAN ═══
                  _PremiumDrawerItem(
                    icon: Icons.sell_rounded,
                    label: 'Akses Jualan',
                    subtitle: 'Kelola akun buyer & penjualan',
                    accentColor: _MC.greenLite,
                    onTap: () => _onDrawerNav(15),
                  ),
                  // ═══ MENU VALIDASI AKUN ═══
                  _PremiumDrawerItem(
                    icon: Icons.verified_user_rounded,
                    label: 'Validasi Akun',
                    subtitle: 'ACC / Tolak akun buyer',
                    accentColor: _MC.brightRed,
                    onTap: () => _onDrawerNav(16),
                  ),
                  if (role == 'staff')
                    _PremiumDrawerItem(
                      icon: Icons.badge_rounded,
                      label: 'Staff Page',
                      subtitle: 'Panel operasional staff',
                      accentColor: _MC.blueCheck,
                      onTap: () => _onDrawerNav(5),
                    ),
                  if (role == 'moderator')
                    _PremiumDrawerItem(
                      icon: Icons.shield_rounded,
                      label: 'Moderator Page',
                      subtitle: 'Moderasi & pengawasan',
                      accentColor: _MC.red,
                      onTap: () => _onDrawerNav(6),
                    ),
                  if (role == 'partner')
                    _PremiumDrawerItem(
                      icon: Icons.handshake_rounded,
                      label: 'Partner Page',
                      subtitle: 'Panel kemitraan',
                      accentColor: _MC.brightRed,
                      onTap: () => _onDrawerNav(7),
                    ),
                  if (role == 'executorius')
                    _PremiumDrawerItem(
                      icon: Icons.gavel_rounded,
                      label: 'Executorius Page',
                      subtitle: 'Eksekusi & kontrol tinggi',
                      accentColor: _MC.amber,
                      onTap: () => _onDrawerNav(8),
                    ),
                  if (role == 'forius_utama')
                    _PremiumDrawerItem(
                      icon: Icons.security_rounded,
                      label: 'Forius Utama Page',
                      subtitle: 'Kendali forium utama',
                      accentColor: _MC.brightRed,
                      onTap: () => _onDrawerNav(9),
                    ),
                  if (role == 'tangan_kiri')
                    _PremiumDrawerItem(
                      icon: Icons.back_hand_rounded,
                      label: 'Tangan Kiri Page',
                      subtitle: 'Panel tangan kiri',
                      accentColor: _MC.accentRed,
                      onTap: () => _onDrawerNav(10),
                    ),
                  if (role == 'partner_pribadi')
                    _PremiumDrawerItem(
                      icon: Icons.person_pin_rounded,
                      label: 'Partner Pribadi Page',
                      subtitle: 'Panel kemitraan pribadi',
                      accentColor: _MC.brightRed,
                      onTap: () => _onDrawerNav(11),
                    ),
                  _PremiumDrawerItem(
                    icon: Icons.headset_mic_rounded,
                    label: 'Contact Support',
                    subtitle: 'Hubungi tim X-SPYDER',
                    accentColor: _MC.blueCheck,
                    onTap: () {
                      Navigator.pop(context);
                      _openUrl('https://t.me/KayzzScarry');
                    },
                  ),
                  const SizedBox(height: 16),
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 8),
                    height: 3,
                    color: _MC.comicBlack,
                  ),
                  const SizedBox(height: 12),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(8, 0, 8, 8),
                    child: Row(
                      children: [
                        Container(
                          width: 4, height: 14,
                          decoration: BoxDecoration(
                            color: _MC.brightRed,
                            borderRadius: BorderRadius.circular(2),
                            border: Border.all(
                                color: _MC.comicBlack, width: 1.5),
                          ),
                        ),
                        const SizedBox(width: 8),
                        const Text('SISTEM',
                            style: TextStyle(
                              color: _MC.textGrey,
                              fontSize: 10,
                              fontWeight: FontWeight.w900,
                              fontFamily: 'Astral',
                              letterSpacing: 2,
                            )),
                      ],
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.fromLTRB(8, 0, 8, 12),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: _MC.redSoft,
                      borderRadius: BorderRadius.circular(12),
                      border:
                          Border.all(color: _MC.comicBlack, width: 2.5),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 32, height: 32,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8),
                            color: _MC.red,
                            border: Border.all(
                                color: _MC.comicBlack, width: 2),
                          ),
                          child: const Icon(Icons.info_outline_rounded,
                              color: _MC.white, size: 16),
                        ),
                        const SizedBox(width: 10),
                        const Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('X-SPYDER',
                                style: TextStyle(
                                  color: _MC.white,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w900,
                                  fontFamily: 'Astral',
                                )),
                            Text('V6 • By X-SPYDER Team',
                                style: TextStyle(
                                  color: _MC.textGrey,
                                  fontSize: 9,
                                  fontFamily: 'Astral',
                                  fontWeight: FontWeight.w600,
                                )),
                          ],
                        ),
                        const Spacer(),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 7, vertical: 3),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(6),
                            color: _MC.green,
                            border: Border.all(
                                color: _MC.comicBlack, width: 1.5),
                          ),
                          child: const Text('LIVE',
                              style: TextStyle(
                                color: _MC.white,
                                fontSize: 8,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Astral',
                                letterSpacing: 1,
                              )),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 20),
              height: 3,
              color: _MC.comicBlack,
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 28),
              child: GestureDetector(
                onTap: () async {
                  Navigator.pop(context);
                  await _doLogout();
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 16, vertical: 13),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    color: _MC.brightRed,
                    border: Border.all(color: _MC.comicBlack, width: 3),
                    boxShadow: const [
                      BoxShadow(
                          color: _MC.comicBlack,
                          offset: Offset(4, 4),
                          blurRadius: 0),
                    ],
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 36, height: 36,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: _MC.buttonDark,
                          border: Border.all(
                              color: _MC.comicBlack, width: 2),
                        ),
                        child: const Icon(Icons.logout_rounded,
                            color: _MC.white, size: 18),
                      ),
                      const SizedBox(width: 12),
                      const Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Keluar',
                              style: TextStyle(
                                color: _MC.white,
                                fontSize: 13,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Astral',
                              )),
                          Text('Logout dari akun ini',
                              style: TextStyle(
                                color: _MC.white,
                                fontSize: 9,
                                fontFamily: 'Astral',
                                fontWeight: FontWeight.w600,
                              )),
                        ],
                      ),
                      const Spacer(),
                      const Icon(Icons.arrow_forward_ios_rounded,
                          color: _MC.white, size: 12),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═════════════════════════════════════════════════════════════
// 🎨 ROLE RING PAINTER (COMIC OUTLINE)
// ═════════════════════════════════════════════════════════════
class _RoleRingPainter extends CustomPainter {
  final Color color;
  final int level;
  _RoleRingPainter({required this.color, required this.level});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 3;

    final outlinePaint = Paint()
      ..color = _MC.comicBlack
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;
    canvas.drawCircle(center, radius + 2, outlinePaint);

    final mainPaint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.5 + (level * 0.3)
      ..strokeCap = StrokeCap.round;
    canvas.drawCircle(center, radius, mainPaint);

    if (level >= 2) {
      final innerPaint = Paint()
        ..color = color
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5;
      canvas.drawCircle(center, radius - 5, innerPaint);
    }

    if (level >= 3) {
      final dotCount = 4 + (level - 3) * 2;
      final dotPaint = Paint()
        ..color = color
        ..style = PaintingStyle.fill;
      final dotRadius = 2.0 + (level * 0.15);
      for (int i = 0; i < dotCount; i++) {
        final angle = (i / dotCount) * 2 * math.pi;
        final dx = center.dx + radius * math.cos(angle);
        final dy = center.dy + radius * math.sin(angle);
        canvas.drawCircle(Offset(dx, dy), dotRadius, dotPaint);
      }
    }

    if (level >= 4) {
      final dashPaint = Paint()
        ..color = color
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.2
        ..strokeCap = StrokeCap.round;
      const segments = 8;
      const gap = 0.6;
      for (int i = 0; i < segments; i++) {
        final startAngle = (i / segments) * 2 * math.pi;
        final sweepAngle = (2 * math.pi / segments) - gap * 0.4;
        canvas.drawArc(
          Rect.fromCircle(center: center, radius: radius - 3),
          startAngle,
          sweepAngle,
          false,
          dashPaint,
        );
      }
    }

    if (level >= 5) {
      final tickPaint = Paint()
        ..color = color
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..strokeCap = StrokeCap.round;
      const tickCount = 12;
      for (int i = 0; i < tickCount; i++) {
        final angle = (i / tickCount) * 2 * math.pi;
        final outer = Offset(
          center.dx + (radius + 2) * math.cos(angle),
          center.dy + (radius + 2) * math.sin(angle),
        );
        final inner = Offset(
          center.dx + (radius - 2) * math.cos(angle),
          center.dy + (radius - 2) * math.sin(angle),
        );
        canvas.drawLine(outer, inner, tickPaint);
      }
    }

    if (level >= 6) {
      for (int i = 0; i < 8; i++) {
        final angle = (i / 8) * 2 * math.pi;
        final dx = center.dx + (radius + 6) * math.cos(angle);
        final dy = center.dy + (radius + 6) * math.sin(angle);
        _drawStar(canvas, Offset(dx, dy), 3.5, 1.8,
            Paint()..color = _MC.white);
      }
    }
  }

  void _drawStar(Canvas canvas, Offset center, double outer, double inner,
      Paint paint) {
    final path = Path();
    for (int i = 0; i < 8; i++) {
      final r = i.isEven ? outer : inner;
      final angle = (i / 8) * 2 * math.pi - math.pi / 2;
      final x = center.dx + r * math.cos(angle);
      final y = center.dy + r * math.sin(angle);
      i == 0 ? path.moveTo(x, y) : path.lineTo(x, y);
    }
    path.close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(_RoleRingPainter old) =>
      old.color != color || old.level != level;
}

// ═════════════════════════════════════════════════════════════
// 🤖 ROBOT STATUS BADGE
// ═════════════════════════════════════════════════════════════
class _RobotStatusBadge extends StatelessWidget {
  const _RobotStatusBadge();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: _MC.red,
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: _MC.comicBlack, width: 2.5),
        boxShadow: const [
          BoxShadow(
              color: _MC.comicBlack,
              offset: Offset(2, 2),
              blurRadius: 0),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 7, height: 7,
            decoration: const BoxDecoration(
                shape: BoxShape.circle, color: _MC.greenLite),
          ),
          const SizedBox(width: 6),
          const Text(
            'ROBOT ONLINE',
            style: TextStyle(
              color: _MC.white,
              fontSize: 9,
              fontWeight: FontWeight.w900,
              letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }
}

class _ThanksToSpecialCard extends StatefulWidget {
  final List<String> names;
  const _ThanksToSpecialCard({required this.names});

  @override
  State<_ThanksToSpecialCard> createState() => _ThanksToSpecialCardState();
}

class _ThanksToSpecialCardState extends State<_ThanksToSpecialCard>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<Offset> _slide;
  int _index = 0;
  Timer? _rotationTimer;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 650));
    _slide = Tween<Offset>(begin: const Offset(0.8, 0), end: Offset.zero).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic),
    );
    _controller.forward();
    _rotationTimer = Timer.periodic(const Duration(seconds: 3), (_) => _next());
  }

  void _next() {
    setState(() => _index = (_index + 1) % widget.names.length);
    _controller.forward(from: 0);
  }

  @override
  void dispose() { _rotationTimer?.cancel(); _controller.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 12),
      decoration: BoxDecoration(
        color: _MC.redSoft,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: _MC.comicBlack, width: 3.5),
        boxShadow: const [
          BoxShadow(
              color: _MC.comicBlack,
              offset: Offset(5, 5),
              blurRadius: 0),
        ],
      ),
      child: Column(
        children: [
          const Text('THANKS TO SPECIAL ✦', style: TextStyle(color: _MC.white, fontSize: 14, fontWeight: FontWeight.w900, fontFamily: _nFont, letterSpacing: 2.2)),
          const SizedBox(height: 5),
          const Text('A little appreciation for the people behind the journey.', textAlign: TextAlign.center, style: TextStyle(color: _MC.textGrey, fontSize: 10, fontWeight: FontWeight.w600)),
          const SizedBox(height: 14),
          ClipRect(
            child: SizedBox(
              height: 44,
              child: SlideTransition(
                position: _slide,
                child: FadeTransition(
                  opacity: _controller,
                  child: Center(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
                      decoration: BoxDecoration(
                        color: _MC.red,
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: _MC.comicBlack, width: 2.5),
                      ),
                      child: Text(widget.names[_index], textAlign: TextAlign.center, style: const TextStyle(color: _MC.white, fontSize: 13, fontWeight: FontWeight.w900, fontFamily: _nFont)),
                    ),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 4),
          IconButton(onPressed: _next, tooltip: 'Next special thanks', icon: const Icon(Icons.swipe_rounded, color: _MC.brightRed, size: 20)),
        ],
      ),
    );
  }
}

// ═════════════════════════════════════════════════════════════
// 🧩 HELPER WIDGETS
// ═════════════════════════════════════════════════════════════
class _PremiumDrawerItem extends StatefulWidget {
  final IconData icon;
  final String label;
  final String subtitle;
  final Color accentColor;
  final VoidCallback onTap;
  const _PremiumDrawerItem({
    required this.icon, required this.label,
    required this.subtitle, required this.accentColor, required this.onTap,
  });
  @override
  State<_PremiumDrawerItem> createState() => _PremiumDrawerItemState();
}

class _PremiumDrawerItemState extends State<_PremiumDrawerItem> {
  bool _pressed = false;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 130),
        margin: const EdgeInsets.fromLTRB(8, 0, 8, 8),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: _pressed ? _MC.brightRed : _MC.redSoft,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _MC.comicBlack, width: 2.5),
          boxShadow: const [
            BoxShadow(
                color: _MC.comicBlack,
                offset: Offset(3, 3),
                blurRadius: 0),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 38, height: 38,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: _MC.buttonDark,
                border: Border.all(color: _MC.comicBlack, width: 2),
              ),
              child: Icon(widget.icon,
                  color: _MC.white, size: 18),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(widget.label,
                      style: const TextStyle(
                        color: _MC.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Astral',
                      )),
                  const SizedBox(height: 2),
                  Text(widget.subtitle,
                      style: const TextStyle(
                        color: _MC.textGrey,
                        fontSize: 10,
                        fontFamily: 'Astral',
                        fontWeight: FontWeight.w600,
                      )),
                ],
              ),
            ),
            const Icon(Icons.arrow_forward_ios_rounded,
                color: _MC.textGrey, size: 11),
          ],
        ),
      ),
    );
  }
}

class _DrawerHeader extends StatefulWidget {
  final String username, role, expiredDate;
  final File? profileImage;
  final VideoPlayerController? videoCtrl;
  const _DrawerHeader({
    required this.username,
    required this.role,
    required this.expiredDate,
    required this.profileImage,
    required this.videoCtrl,
  });
  @override
  State<_DrawerHeader> createState() => _DrawerHeaderState();
}

class _DrawerHeaderState extends State<_DrawerHeader>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;
  late Animation<double> _fade;
  late Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 550),
    );
    _fade = CurvedAnimation(parent: _c, curve: Curves.easeOut);
    _slide = Tween<Offset>(
      begin: const Offset(0, 0.18),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _c, curve: Curves.easeOutCubic));
    _c.forward();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final rColor = _roleColor(widget.role);

    return Container(
      height: 230,
      clipBehavior: Clip.hardEdge,
      decoration: const BoxDecoration(
        color: _MC.redSoft,
        border: Border(
          bottom: BorderSide(color: _MC.comicBlack, width: 3),
        ),
      ),
      child: Stack(
        children: <Widget>[
          if (widget.videoCtrl != null &&
              widget.videoCtrl!.value.isInitialized)
            Positioned.fill(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: widget.videoCtrl!.value.size.width,
                  height: widget.videoCtrl!.value.size.height,
                  child: VideoPlayer(widget.videoCtrl!),
                ),
              ),
            ),
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: <Color>[
                    _MC.redDeep.withOpacity(0.5),
                    _MC.redDeep.withOpacity(0.95),
                  ],
                ),
              ),
            ),
          ),
          Positioned.fill(
            child: SafeArea(
              child: FadeTransition(
                opacity: _fade,
                child: SlideTransition(
                  position: _slide,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Stack(
                        children: <Widget>[
                          Container(
                            width: 74, height: 74,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: rColor,
                              border: Border.all(
                                color: _MC.comicBlack,
                                width: 3.5,
                              ),
                              boxShadow: const [
                                BoxShadow(
                                    color: _MC.comicBlack,
                                    offset: Offset(3, 3),
                                    blurRadius: 0),
                              ],
                            ),
                            child: ClipOval(
                              child: widget.profileImage != null
                                  ? Image.file(
                                      widget.profileImage!,
                                      fit: BoxFit.cover,
                                    )
                                  : Icon(
                                      _roleIcon(widget.role),
                                      size: 32,
                                      color: _MC.white,
                                    ),
                            ),
                          ),
                          Positioned(
                            right: 0, bottom: 0,
                            child: Container(
                              padding: const EdgeInsets.all(4),
                              decoration: BoxDecoration(
                                color: rColor,
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: _MC.comicBlack,
                                  width: 2.5,
                                ),
                              ),
                              child: Icon(
                                _roleIcon(widget.role),
                                size: 9,
                                color: _MC.white,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Text(
                        widget.username,
                        style: const TextStyle(
                          color: _MC.white,
                          fontSize: 17,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Astral',
                        ),
                      ),
                      const SizedBox(height: 4),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: _MC.red,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                              color: _MC.comicBlack, width: 2),
                        ),
                        child: Text(
                          widget.role.toUpperCase(),
                          style: const TextStyle(
                            color: _MC.white,
                            fontSize: 10,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1,
                            fontFamily: 'Astral',
                          ),
                        ),
                      ),
                      const SizedBox(height: 5),
                      Text(
                        'Exp: ${widget.expiredDate}',
                        style: const TextStyle(
                          color: _MC.textGrey,
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _MenuBtn extends StatefulWidget {
  final VoidCallback onTap;
  const _MenuBtn({required this.onTap});
  @override
  State<_MenuBtn> createState() => _MenuBtnState();
}

class _MenuBtnState extends State<_MenuBtn> {
  bool _down = false;
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10),
      child: GestureDetector(
        onTapDown: (_) => setState(() => _down = true),
        onTapUp: (_) {
          setState(() => _down = false);
          widget.onTap();
        },
        onTapCancel: () => setState(() => _down = false),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 110),
          decoration: BoxDecoration(
            color: _down ? _MC.brightRed : _MC.buttonDark,
            borderRadius: BorderRadius.circular(9),
            border: Border.all(color: _MC.comicBlack, width: 2.5),
          ),
          child: const Icon(Icons.menu_rounded, color: _MC.white, size: 19),
        ),
      ),
    );
  }
}

class _AppBarIconBtn extends StatefulWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _AppBarIconBtn({required this.icon, required this.onTap});
  @override
  State<_AppBarIconBtn> createState() => _AppBarIconBtnState();
}

class _AppBarIconBtnState extends State<_AppBarIconBtn> {
  bool _down = false;
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 10),
      child: GestureDetector(
        onTapDown: (_) => setState(() => _down = true),
        onTapUp: (_) {
          setState(() => _down = false);
          widget.onTap();
        },
        onTapCancel: () => setState(() => _down = false),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 110),
          width: 34, height: 34,
          decoration: BoxDecoration(
            color: _down ? _MC.brightRed : _MC.buttonDark,
            borderRadius: BorderRadius.circular(9),
            border: Border.all(color: _MC.comicBlack, width: 2.5),
          ),
          child: Icon(widget.icon, color: _MC.white, size: 17),
        ),
      ),
    );
  }
}

class _AnimatedBg extends StatelessWidget {
  final AnimationController controller;
  const _AnimatedBg({required this.controller});
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) => CustomPaint(
          painter: _BgPainter(controller.value), size: Size.infinite),
    );
  }
}

class _BgPainter extends CustomPainter {
  final double t;
  _BgPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height),
        Paint()..color = _MC.redDeep);

    final gridPaint = Paint()
      ..color = _MC.red.withOpacity(0.15)
      ..strokeWidth = 1
      ..style = PaintingStyle.stroke;
    const hexSize = 36.0;
    final hexW = hexSize * math.sqrt(3);
    final hexH = hexSize * 2;
    final rows = (size.height / (hexH * 0.75)).ceil() + 2;
    final cols = (size.width / hexW).ceil() + 2;
    for (int row = -1; row < rows; row++) {
      for (int col = -1; col < cols; col++) {
        final dx = col * hexW + (row.isOdd ? hexW / 2 : 0);
        final dy = row * hexH * 0.75;
        _drawHex(canvas, Offset(dx, dy), hexSize, gridPaint);
      }
    }

    canvas.drawCircle(
      Offset(size.width / 2, -size.height * 0.1),
      size.width * 0.8,
      Paint()
        ..shader = RadialGradient(colors: [
          _MC.brightRed
              .withOpacity(0.08 + math.sin(t * math.pi * 2) * 0.03),
          Colors.transparent,
        ], radius: 0.6)
            .createShader(Rect.fromCircle(
                center: Offset(size.width / 2, -size.height * 0.1),
                radius: size.width * 0.8)),
    );

    canvas.drawCircle(
      Offset(size.width * 0.15, size.height),
      size.width * 0.5,
      Paint()
        ..shader = RadialGradient(colors: [
          _MC.red
              .withOpacity(0.06 + math.sin(t * math.pi * 2 + 1) * 0.02),
          Colors.transparent,
        ], radius: 0.5)
            .createShader(Rect.fromCircle(
                center: Offset(size.width * 0.15, size.height),
                radius: size.width * 0.5)),
    );
  }

  void _drawHex(
      Canvas canvas, Offset center, double size, Paint paint) {
    final path = Path();
    for (int i = 0; i < 6; i++) {
      final angle = (math.pi / 180) * (60 * i - 30);
      final x = center.dx + size * math.cos(angle);
      final y = center.dy + size * math.sin(angle);
      i == 0 ? path.moveTo(x, y) : path.lineTo(x, y);
    }
    path.close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(_BgPainter old) => old.t != t;
}

class _LiveDot extends StatefulWidget {
  final Color color;
  const _LiveDot({required this.color});

  @override
  State<_LiveDot> createState() => _LiveDotState();
}

class _LiveDotState extends State<_LiveDot>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1100),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (_, __) {
        return Container(
          width: 7 + (_controller.value * 2),
          height: 7 + (_controller.value * 2),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: widget.color,
          ),
        );
      },
    );
  }
}

class _HeroGlassPill extends StatelessWidget {
  final IconData icon;
  final String text;
  final Color color;
  const _HeroGlassPill({
    required this.icon,
    required this.text,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
      decoration: BoxDecoration(
        color: _MC.buttonDark,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _MC.comicBlack, width: 2.5),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _LiveDot(color: color),
          const SizedBox(width: 6),
          Icon(icon, color: _MC.white, size: 12),
          const SizedBox(width: 4),
          Text(
            text,
            style: const TextStyle(
              color: _MC.white,
              fontSize: 8.5,
              fontWeight: FontWeight.w900,
              letterSpacing: 0.8,
              fontFamily: 'Astral',
            ),
          ),
        ],
      ),
    );
  }
}

class _OrbitLauncher extends StatefulWidget {
  final VoidCallback onTap;
  const _OrbitLauncher({required this.onTap});

  @override
  State<_OrbitLauncher> createState() => _OrbitLauncherState();
}

class _OrbitLauncherState extends State<_OrbitLauncher>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (_, __) {
        final scale = 0.96 + (_controller.value * 0.07);
        return Transform.scale(
          scale: scale,
          child: GestureDetector(
            onTap: widget.onTap,
            child: Container(
              width: 54, height: 54,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _MC.brightRed,
                border: Border.all(
                    color: _MC.comicBlack, width: 3),
                boxShadow: const [
                  BoxShadow(
                      color: _MC.comicBlack,
                      offset: Offset(3, 3),
                      blurRadius: 0),
                ],
              ),
              child: const Icon(
                Icons.apps_rounded,
                color: _MC.white,
                size: 27,
              ),
            ),
          ),
        );
      },
    );
  }
}

class _PurpleIconBox extends StatelessWidget {
  final IconData icon;
  final Color color;
  const _PurpleIconBox({
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 42, height: 42,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        color: color,
        border: Border.all(color: _MC.comicBlack, width: 3),
        boxShadow: const [
          BoxShadow(
              color: _MC.comicBlack,
              offset: Offset(3, 3),
              blurRadius: 0),
        ],
      ),
      child: Icon(icon, color: _MC.white, size: 20),
    );
  }
}

class _UserConnectionShowcase extends StatefulWidget {
  final int onlineUsers;
  final int activeConnections;
  final int totalUsers;

  const _UserConnectionShowcase({
    required this.onlineUsers,
    required this.activeConnections,
    required this.totalUsers,
  });

  @override
  State<_UserConnectionShowcase> createState() =>
      _UserConnectionShowcaseState();
}

class _UserConnectionShowcaseState extends State<_UserConnectionShowcase> {
  late final PageController _controller;
  Timer? _timer;
  int _page = 0;

  static const List<String> _images = [
    'assets/images/slide.png',
    'assets/images/slider.png',
    'assets/images/orbit.png',
  ];

  @override
  void initState() {
    super.initState();
    _controller = PageController();
    _timer = Timer.periodic(const Duration(seconds: 4), (_) {
      if (!mounted || !_controller.hasClients) return;
      final next = (_page + 1) % _images.length;
      _controller.animateToPage(
        next,
        duration: const Duration(milliseconds: 700),
        curve: Curves.easeOutCubic,
      );
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: _MC.redSoft,
        borderRadius: BorderRadius.circular(25),
        border: Border.all(color: _MC.comicBlack, width: 3.5),
        boxShadow: const [
          BoxShadow(
              color: _MC.comicBlack,
              offset: Offset(5, 5),
              blurRadius: 0),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const _PurpleIconBox(
                icon: Icons.hub_rounded,
                color: _MC.brightRed,
              ),
              const SizedBox(width: 10),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'USER CONNECTION',
                      style: TextStyle(
                        color: _MC.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.1,
                        fontFamily: 'Astral',
                      ),
                    ),
                    SizedBox(height: 2),
                    Text(
                      'Live network activity',
                      style: TextStyle(
                        color: _MC.textGrey,
                        fontSize: 9.5,
                        fontFamily: 'Astral',
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              const _HeroGlassPill(
                icon: Icons.wifi_rounded,
                text: 'LIVE',
                color: _MC.greenLite,
              ),
            ],
          ),
          const SizedBox(height: 13),
          SizedBox(
            height: 132,
            child: Row(
              children: [
                Expanded(
                  flex: 5,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(19),
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        PageView.builder(
                          controller: _controller,
                          itemCount: _images.length,
                          onPageChanged: (index) {
                            if (mounted) setState(() => _page = index);
                          },
                          itemBuilder: (_, index) {
                            return Image.asset(
                              _images[index],
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => Container(
                                color: _MC.red,
                                child: const Icon(
                                  Icons.image_rounded,
                                  color: _MC.white,
                                  size: 30,
                                ),
                              ),
                            );
                          },
                        ),
                        Positioned.fill(
                          child: IgnorePointer(
                            child: DecoratedBox(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    Colors.transparent,
                                    Colors.black.withOpacity(0.5),
                                  ],
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter,
                                ),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          left: 9, bottom: 8,
                          child: Row(
                            children: List.generate(
                              _images.length,
                              (index) => AnimatedContainer(
                                duration: const Duration(milliseconds: 220),
                                margin: const EdgeInsets.only(right: 4),
                                width: index == _page ? 15 : 5,
                                height: 5,
                                decoration: BoxDecoration(
                                  color: index == _page
                                      ? _MC.white
                                      : _MC.white.withOpacity(0.4),
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(
                                      color: _MC.comicBlack, width: 1),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  flex: 6,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _ConnectionMetric(
                        icon: Icons.people_alt_rounded,
                        label: 'Online Users',
                        value: '${widget.onlineUsers}',
                        color: _MC.greenLite,
                      ),
                      const SizedBox(height: 7),
                      _ConnectionMetric(
                        icon: Icons.link_rounded,
                        label: 'Connections',
                        value: '${widget.activeConnections}',
                        color: _MC.blueCheck,
                      ),
                      const SizedBox(height: 7),
                      _ConnectionMetric(
                        icon: Icons.groups_rounded,
                        label: 'Total Users',
                        value: '${widget.totalUsers}',
                        color: _MC.brightRed,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ConnectionMetric extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;

  const _ConnectionMetric({
    required this.icon,
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 7),
      decoration: BoxDecoration(
        color: _MC.buttonDark,
        borderRadius: BorderRadius.circular(13),
        border: Border.all(color: _MC.comicBlack, width: 2),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 15),
          const SizedBox(width: 7),
          Expanded(
            child: Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: _MC.textGrey,
                fontSize: 8.5,
                fontFamily: 'Astral',
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          Text(
            value,
            style: const TextStyle(
              color: _MC.white,
              fontSize: 12,
              fontWeight: FontWeight.w900,
              fontFamily: 'Astral',
            ),
          ),
        ],
      ),
    );
  }
}

class _OrbitQuickGrid extends StatelessWidget {
  final VoidCallback onClose;
  final String username;
  final String sessionKey;
  final String role;

  const _OrbitQuickGrid({
    required this.onClose,
    required this.username,
    required this.sessionKey,
    required this.role,
  });

  @override
  Widget build(BuildContext context) {
    final items = [
      const [Icons.auto_awesome_rounded, 'Quick Menu', 'Open shortcuts'],
      const [Icons.chat_bubble_rounded, 'Chat Room', 'Global community'],
      const [Icons.verified_user_rounded, 'Profile', 'Account details'],
      const [Icons.settings_rounded, 'System', 'Dashboard status'],
    ];

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: items.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 9,
        mainAxisSpacing: 9,
        childAspectRatio: 1.9,
      ),
      itemBuilder: (_, index) {
        final item = items[index];
        return GestureDetector(
          onTap: () {
            Navigator.pop(context);
            if (index == 1) {
              Navigator.push(
                context,
                _slideRoute(ChatRoomPage(username: username)),
              );
            } else {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('${item[1]} siap dibuka')),
              );
            }
          },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              color: _MC.redSoft,
              border: Border.all(color: _MC.comicBlack, width: 2.5),
              boxShadow: const [
                BoxShadow(
                    color: _MC.comicBlack,
                    offset: Offset(3, 3),
                    blurRadius: 0),
              ],
            ),
            child: Row(
              children: [
                Container(
                  width: 34, height: 34,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _MC.brightRed,
                    border: Border.all(
                        color: _MC.comicBlack, width: 2),
                  ),
                  child: Icon(
                    item[0] as IconData,
                    color: _MC.white,
                    size: 17,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        item[1] as String,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: _MC.white,
                          fontSize: 9.5,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Astral',
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        item[2] as String,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: _MC.textGrey,
                          fontSize: 7.5,
                          fontFamily: 'Astral',
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _OrbitSection extends StatefulWidget {
  const _OrbitSection();

  @override
  State<_OrbitSection> createState() => _OrbitSectionState();
}

class _OrbitSectionState extends State<_OrbitSection>
    with SingleTickerProviderStateMixin {
  late final AnimationController _orbitCtrl;

  static const List<_OrbitItemData> _items = [
    _OrbitItemData(
      label: 'Encrypt',
      icon: Icons.enhanced_encryption_rounded,
      color: Color(0xFF4ECDC4),
    ),
    _OrbitItemData(
      label: 'Fashion',
      icon: Icons.checkroom_rounded,
      color: Color(0xFFEC4899),
    ),
    _OrbitItemData(
      label: 'Combo UIX',
      icon: Icons.auto_awesome_mosaic_rounded,
      color: Color(0xFFF59E0B),
    ),
  ];

  @override
  void initState() {
    super.initState();
    _orbitCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 16),
    )..repeat();
  }

  @override
  void dispose() {
    _orbitCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 18),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(26),
          color: _MC.redSoft,
          border: Border.all(color: _MC.comicBlack, width: 3.5),
        ),
        child: Column(
          children: [
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  _PurpleIconBox(
                    icon: Icons.blur_circular_rounded,
                    color: _MC.brightRed,
                  ),
                  SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'ORBIT HUB',
                          style: TextStyle(
                            color: _MC.white,
                            fontWeight: FontWeight.w900,
                            fontSize: 15,
                            fontFamily: 'Astral',
                            letterSpacing: 1,
                          ),
                        ),
                        Text(
                          'Fitur unggulan berputar di sekitarmu',
                          style: TextStyle(
                              color: _MC.textGrey,
                              fontSize: 11,
                              fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            SizedBox(
              width: 260, height: 260,
              child: AnimatedBuilder(
                animation: _orbitCtrl,
                builder: (context, _) {
                  final t = _orbitCtrl.value * 2 * math.pi;
                  return Stack(
                    alignment: Alignment.center,
                    children: [
                      Container(
                        width: 226, height: 226,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                              color: _MC.comicBlack, width: 2),
                        ),
                      ),
                      Container(
                        width: 150, height: 150,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                              color: _MC.comicBlack, width: 2),
                        ),
                      ),
                      Transform.scale(
                        scale: 1 + 0.04 * math.sin(t),
                        child: Container(
                          width: 92, height: 92,
                          padding: const EdgeInsets.all(3),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: _MC.brightRed,
                            border: Border.all(
                                color: _MC.comicBlack, width: 3),
                            boxShadow: const [
                              BoxShadow(
                                  color: _MC.comicBlack,
                                  offset: Offset(3, 3),
                                  blurRadius: 0),
                            ],
                          ),
                          child: ClipOval(
                            child: Container(
                              color: _MC.redDeep,
                              child: Image.asset(
                                'assets/images/orbit.png',
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => const Icon(
                                    Icons.person_rounded,
                                    color: _MC.white,
                                    size: 40),
                              ),
                            ),
                          ),
                        ),
                      ),
                      for (int i = 0; i < _items.length; i++)
                        _buildSatellite(
                          _items[i],
                          t + (i * (2 * math.pi / _items.length)),
                          108,
                        ),
                    ],
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSatellite(_OrbitItemData data, double angle, double radius) {
    final dx = radius * math.cos(angle);
    final dy = radius * math.sin(angle);
    return Transform.translate(
      offset: Offset(dx, dy),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 54, height: 54,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: data.color,
              border: Border.all(color: _MC.comicBlack, width: 3),
              boxShadow: const [
                BoxShadow(
                    color: _MC.comicBlack,
                    offset: Offset(3, 3),
                    blurRadius: 0),
              ],
            ),
            child: Icon(data.icon, color: _MC.white, size: 24),
          ),
          const SizedBox(height: 4),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
            decoration: BoxDecoration(
              color: _MC.buttonDark,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _MC.comicBlack, width: 1.5),
            ),
            child: Text(
              data.label,
              style: const TextStyle(
                color: _MC.white,
                fontSize: 9,
                fontWeight: FontWeight.w900,
                fontFamily: 'Astral',
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _OrbitItemData {
  final String label;
  final IconData icon;
  final Color color;
  const _OrbitItemData(
      {required this.label, required this.icon, required this.color});
}

// ═════════════════════════════════════════════════════════════
// 📖 ADD STORY SHEET
// ═════════════════════════════════════════════════════════════
class _AddStorySheet extends StatefulWidget {
  final String username, role, sessionKey, avatar;
  final VoidCallback onCreated;
  const _AddStorySheet({
    required this.username, required this.role,
    required this.sessionKey, required this.avatar,
    required this.onCreated,
  });
  @override
  State<_AddStorySheet> createState() => _AddStorySheetState();
}

class _AddStorySheetState extends State<_AddStorySheet> {
  final _captionCtrl = TextEditingController();
  String _type = 'text';
  String? _pickedFile;
  bool _uploading = false;

  @override
  void dispose() {
    _captionCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    try {
      final picker = ImagePicker();
      final file = await picker.pickImage(source: ImageSource.gallery);
      if (file != null && mounted) {
        setState(() {
          _pickedFile = file.path;
          _type = 'photo';
        });
      }
    } catch (_) {}
  }

  Future<void> _pickVideo() async {
    try {
      final picker = ImagePicker();
      final file = await picker.pickVideo(source: ImageSource.gallery);
      if (file != null && mounted) {
        setState(() {
          _pickedFile = file.path;
          _type = 'video';
        });
      }
    } catch (_) {}
  }

  Future<void> _uploadStory() async {
    if (_type == 'text' && _captionCtrl.text.trim().isEmpty) return;
    if ((_type == 'photo' || _type == 'video') && _pickedFile == null) return;

    setState(() => _uploading = true);
    try {
      String content = _captionCtrl.text.trim();
      if (_pickedFile != null) content = _pickedFile!;

      final res = await http
          .post(
            Uri.parse('$kStoryBaseUrl/api/story/create'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'username': widget.username,
              'role': widget.role,
              'avatar': widget.avatar,
              'type': _type,
              'content': content,
              'caption': _captionCtrl.text.trim(),
              'session_key': widget.sessionKey,
            }),
          )
          .timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);
      if (data['success'] == true && mounted) {
        widget.onCreated();
        Navigator.pop(context);
      }
    } catch (_) {}
    if (mounted) setState(() => _uploading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(
        left: 20, right: 20, top: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 24,
      ),
      decoration: const BoxDecoration(
        color: _MC.redSoft,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        border: Border(
          top: BorderSide(color: _MC.comicBlack, width: 4),
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Container(
              width: 44, height: 4,
              decoration: BoxDecoration(
                color: _MC.comicBlack,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          const SizedBox(height: 16),
          const Text('Buat Story',
              style: TextStyle(
                color: _MC.white,
                fontSize: 18,
                fontWeight: FontWeight.w900,
                fontFamily: 'Astral',
              )),
          const SizedBox(height: 4),
          const Text('Story akan hilang otomatis dalam 23 jam',
              style: TextStyle(
                  color: _MC.textGrey,
                  fontSize: 11,
                  fontWeight: FontWeight.w600)),
          const SizedBox(height: 18),
          Row(
            children: [
              _typeBtn('Teks', Icons.text_fields_rounded, 'text', () {
                setState(() {
                  _type = 'text';
                  _pickedFile = null;
                });
              }),
              const SizedBox(width: 8),
              _typeBtn('Foto', Icons.image_rounded, 'photo', _pickImage),
              const SizedBox(width: 8),
              _typeBtn('Video', Icons.videocam_rounded, 'video', _pickVideo),
            ],
          ),
          const SizedBox(height: 14),
          Container(
            decoration: BoxDecoration(
              color: _MC.redDeep,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _MC.comicBlack, width: 3),
            ),
            child: TextField(
              controller: _captionCtrl,
              maxLines: 4,
              minLines: 2,
              style: const TextStyle(
                  color: _MC.white,
                  fontSize: 14,
                  fontWeight: FontWeight.w700),
              cursorColor: _MC.brightRed,
              decoration: const InputDecoration(
                hintText: 'Tulis caption atau isi story...',
                hintStyle:
                    TextStyle(color: _MC.textLight, fontSize: 13),
                border: InputBorder.none,
                contentPadding: EdgeInsets.all(14),
              ),
            ),
          ),
          if (_pickedFile != null) ...[
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: _MC.buttonDark,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _MC.comicBlack, width: 2),
              ),
              child: Row(
                children: [
                  Icon(
                    _type == 'video'
                        ? Icons.videocam_rounded
                        : Icons.image_rounded,
                    color: _MC.brightRed,
                    size: 18,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      _pickedFile!.split('/').last,
                      style: const TextStyle(
                          color: _MC.white,
                          fontSize: 11,
                          fontWeight: FontWeight.w700),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  GestureDetector(
                    onTap: () => setState(() {
                      _pickedFile = null;
                      _type = 'text';
                    }),
                    child: const Icon(Icons.close_rounded,
                        color: _MC.brightRed, size: 18),
                  ),
                ],
              ),
            ),
          ],
          const SizedBox(height: 18),
          GestureDetector(
            onTap: _uploading ? null : _uploadStory,
            child: Container(
              height: 52,
              decoration: BoxDecoration(
                color: _MC.buttonYellow,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: _MC.comicBlack, width: 3),
                boxShadow: const [
                  BoxShadow(
                      color: _MC.comicBlack,
                      offset: Offset(4, 4),
                      blurRadius: 0),
                ],
              ),
              child: Center(
                child: _uploading
                    ? const SizedBox(
                        width: 22, height: 22,
                        child: CircularProgressIndicator(
                            color: _MC.comicBlack, strokeWidth: 3),
                      )
                    : const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.upload_rounded,
                              color: _MC.comicBlack, size: 20),
                          SizedBox(width: 8),
                          Text('Upload Story',
                              style: TextStyle(
                                color: _MC.comicBlack,
                                fontSize: 15,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Astral',
                                letterSpacing: 1.5,
                              )),
                        ],
                      ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _typeBtn(
      String label, IconData icon, String value, VoidCallback onTap) {
    final active = _type == value;
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: active ? _MC.brightRed : _MC.buttonDark,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _MC.comicBlack, width: 2.5),
            boxShadow: const [
              BoxShadow(
                  color: _MC.comicBlack,
                  offset: Offset(2, 2),
                  blurRadius: 0),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: _MC.white, size: 16),
              const SizedBox(width: 6),
              Text(label,
                  style: const TextStyle(
                    color: _MC.white,
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                  )),
            ],
          ),
        ),
      ),
    );
  }
}

// ═════════════════════════════════════════════════════════════
// 📖 STORY VIEWER
// ═════════════════════════════════════════════════════════════
class _StoryViewer extends StatefulWidget {
  final List<StoryUser> users;
  final int initialUserIndex;
  final String currentUsername;
  final String sessionKey;
  final VoidCallback onRefresh;
  const _StoryViewer({
    required this.users, required this.initialUserIndex,
    required this.currentUsername, required this.sessionKey,
    required this.onRefresh,
  });
  @override
  State<_StoryViewer> createState() => _StoryViewerState();
}

class _StoryViewerState extends State<_StoryViewer> {
  late int _userIdx;
  int _itemIdx = 0;
  Timer? _timer;
  double _progress = 0.0;

  @override
  void initState() {
    super.initState();
    _userIdx = widget.initialUserIndex;
    _startTimer();
    _markViewed();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  StoryUser get _user => widget.users[_userIdx];
  StoryItem get _item => _user.stories[_itemIdx];

  void _startTimer() {
    _timer?.cancel();
    _progress = 0.0;
    const frame = Duration(milliseconds: 50);
    const total = Duration(seconds: 5);
    _timer = Timer.periodic(frame, (t) {
      if (!mounted) return;
      setState(() {
        _progress += frame.inMilliseconds / total.inMilliseconds;
        if (_progress >= 1.0) _next();
      });
    });
  }

  void _next() {
    if (_itemIdx < _user.stories.length - 1) {
      setState(() => _itemIdx++);
      _startTimer();
      _markViewed();
    } else if (_userIdx < widget.users.length - 1) {
      setState(() {
        _userIdx++;
        _itemIdx = 0;
      });
      _startTimer();
      _markViewed();
    } else {
      Navigator.pop(context);
    }
  }

  void _prev() {
    if (_itemIdx > 0) {
      setState(() => _itemIdx--);
      _startTimer();
    } else if (_userIdx > 0) {
      setState(() {
        _userIdx--;
        _itemIdx = widget.users[_userIdx].stories.length - 1;
      });
      _startTimer();
    }
  }

  Future<void> _markViewed() async {
    try {
      await http
          .post(
            Uri.parse('$kStoryBaseUrl/api/story/view'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'story_id': _item.id,
              'viewer': widget.currentUsername,
            }),
          )
          .timeout(const Duration(seconds: 5));
    } catch (_) {}
  }

  Future<void> _deleteStory() async {
    try {
      await http
          .post(
            Uri.parse('$kStoryBaseUrl/api/story/delete'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'story_id': _item.id,
              'username': widget.currentUsername,
              'session_key': widget.sessionKey,
            }),
          )
          .timeout(const Duration(seconds: 5));
      widget.onRefresh();
      Navigator.pop(context);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final roleCol = _roleColor(_user.role);
    final isMyStory = _user.username == widget.currentUsername;
    return Scaffold(
      backgroundColor: _MC.redDeep,
      body: Stack(
        children: [
          Positioned.fill(
            child: GestureDetector(
              onTapUp: (details) {
                final w = MediaQuery.of(context).size.width;
                if (details.localPosition.dx < w / 2) {
                  _prev();
                } else {
                  _next();
                }
              },
              child: _buildContent(),
            ),
          ),
          Positioned(
            top: MediaQuery.of(context).padding.top + 8,
            left: 12, right: 12,
            child: Row(
              children: List.generate(_user.stories.length, (i) {
                return Expanded(
                  child: Container(
                    height: 3,
                    margin: const EdgeInsets.symmetric(horizontal: 2),
                    decoration: BoxDecoration(
                      color: _MC.comicBlack,
                      borderRadius: BorderRadius.circular(2),
                    ),
                    child: FractionallySizedBox(
                      alignment: Alignment.centerLeft,
                      widthFactor: i < _itemIdx
                          ? 1.0
                          : (i == _itemIdx ? _progress : 0.0),
                      child: Container(
                        decoration: BoxDecoration(
                          color: _MC.brightRed,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                  ),
                );
              }),
            ),
          ),
          Positioned(
            top: MediaQuery.of(context).padding.top + 24,
            left: 12, right: 12,
            child: Row(
              children: [
                Container(
                  width: 40, height: 40,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _MC.white,
                    border: Border.all(color: _MC.comicBlack, width: 2.5),
                  ),
                  child: Center(
                    child: Text(_roleShort(_user.username),
                        style: const TextStyle(
                          color: _MC.comicBlack,
                          fontWeight: FontWeight.w900,
                          fontSize: 14,
                        )),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(_user.username,
                              style: const TextStyle(
                                color: _MC.white,
                                fontWeight: FontWeight.w900,
                                fontSize: 14,
                              )),
                          if (_isVerifiedRole(_user.role)) ...[
                            const SizedBox(width: 6),
                            Container(
                              width: 16, height: 16,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: _MC.blueCheck,
                                border: Border.all(
                                    color: _MC.comicBlack, width: 1.5),
                              ),
                              child: const Icon(Icons.check_rounded,
                                  color: _MC.white, size: 10),
                            ),
                          ],
                        ],
                      ),
                      Text(
                        '${_timeAgo(_item.createdAt)}  •  ${_user.role}',
                        style: const TextStyle(
                          color: _MC.textGrey,
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
                if (isMyStory)
                  IconButton(
                    onPressed: _deleteStory,
                    icon: const Icon(Icons.delete_rounded,
                        color: _MC.white),
                  ),
                IconButton(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.close_rounded,
                      color: _MC.white),
                ),
              ],
            ),
          ),
          Positioned(
            bottom: MediaQuery.of(context).padding.bottom + 20,
            left: 20, right: 20,
            child: _item.caption.isNotEmpty
                ? Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 12),
                    decoration: BoxDecoration(
                      color: _MC.buttonDark,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                          color: _MC.comicBlack, width: 2.5),
                    ),
                    child: Text(_item.caption,
                        style: const TextStyle(
                            color: _MC.white,
                            fontSize: 14,
                            fontWeight: FontWeight.w700)),
                  )
                : const SizedBox.shrink(),
          ),
        ],
      ),
    );
  }

  Widget _buildContent() {
    if (_item.type == 'photo' && _item.content.startsWith('http')) {
      return Image.network(_item.content,
          fit: BoxFit.contain,
          errorBuilder: (_, __, ___) => _fallbackText());
    }
    if (_item.type == 'video' && _item.content.startsWith('http')) {
      return _VideoStory(url: _item.content);
    }
    return _fallbackText();
  }

  Widget _fallbackText() {
    return Container(
      color: _MC.redDeep,
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Text(
            _item.content.isNotEmpty ? _item.content : 'Story',
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: _MC.white,
              fontSize: 22,
              fontWeight: FontWeight.w900,
              fontFamily: 'Astral',
            ),
          ),
        ),
      ),
    );
  }

  String _timeAgo(int ts) {
    final diff = DateTime.now().millisecondsSinceEpoch - ts;
    final min = diff ~/ 60000;
    if (min < 1) return 'Baru saja';
    if (min < 60) return '$min mnt lalu';
    final hr = min ~/ 60;
    if (hr < 24) return '$hr jam lalu';
    return '${hr ~/ 24} hari lalu';
  }
}

class _VideoStory extends StatefulWidget {
  final String url;
  const _VideoStory({required this.url});
  @override
  State<_VideoStory> createState() => _VideoStoryState();
}

class _VideoStoryState extends State<_VideoStory> {
  late VideoPlayerController _ctrl;
  @override
  void initState() {
    super.initState();
    _ctrl = VideoPlayerController.networkUrl(Uri.parse(widget.url))
      ..initialize().then((_) {
        if (mounted) setState(() {});
        _ctrl.setLooping(true);
        _ctrl.play();
      });
  }
  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    if (_ctrl.value.isInitialized) {
      return Center(
          child: AspectRatio(
              aspectRatio: _ctrl.value.aspectRatio,
              child: VideoPlayer(_ctrl)));
    }
    return const Center(
        child: CircularProgressIndicator(color: _MC.white));
  }
}

// ═════════════════════════════════════════════════════════════
// 🌐 PRAYER TIME SERVICE
// ═════════════════════════════════════════════════════════════
class PrayerTimeService {
  static Future<Map<String, dynamic>> fetchPrayerTimes(String city) async {
    final now = DateTime.now();
    final uri = Uri.https('api.aladhan.com', '/v1/timingsByCity', {
      'city': city, 'country': 'ID', 'method': '11',
      'day': '${now.day}', 'month': '${now.month}', 'year': '${now.year}',
    });
    try {
      final res =
          await http.get(uri).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return {};
  }

  static Future<String> detectLocationByGPS() async {
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) return await detectLocationByIP();
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          return await detectLocationByIP();
        }
      }
      if (permission == LocationPermission.deniedForever) {
        return await detectLocationByIP();
      }
      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.medium,
      ).timeout(const Duration(seconds: 15));
      final placemarks = await placemarkFromCoordinates(
        position.latitude, position.longitude,
      );
      if (placemarks.isNotEmpty) {
        final place = placemarks.first;
        final city = (place.subAdministrativeArea?.isNotEmpty == true)
            ? place.subAdministrativeArea!
            : (place.administrativeArea?.isNotEmpty == true)
                ? place.administrativeArea!
                : 'Jakarta';
        return city;
      }
    } catch (e) {}
    return await detectLocationByIP();
  }

  static Future<String> detectLocationByIP() async {
    try {
      final response = await http
          .get(Uri.parse('http://ip-api.com/json/'))
          .timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == 'success') {
          String city = data['city'] ?? '';
          if (city.isNotEmpty) return city;
        }
      }
    } catch (e) {}
    try {
      final response = await http
          .get(Uri.parse('https://ipapi.co/json/'))
          .timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        String city = data['city'] ?? '';
        if (city.isNotEmpty) return city;
      }
    } catch (e) {}
    return 'Jakarta';
  }
}

// SHARED
PageRoute _slideRoute(Widget page) => PageRouteBuilder(
      pageBuilder: (_, __, ___) => page,
      transitionDuration: const Duration(milliseconds: 320),
      transitionsBuilder: (_, anim, __, child) => SlideTransition(
        position: Tween<Offset>(
                begin: const Offset(1, 0), end: Offset.zero)
            .animate(
                CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
        child: FadeTransition(opacity: anim, child: child),
      ),
    );