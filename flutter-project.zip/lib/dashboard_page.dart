import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'dart:math' show Random;
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:audioplayers/audioplayers.dart';
import 'api_config.dart';
import 'nik_check.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'staf_page.dart';
import 'mods_page.dart';
import 'patner_page.dart';
import 'home_page.dart';
import 'bug_group.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'al_quran.dart';
import 'anime_home.dart';
import 'zenzo_song.dart';
import 'game_zone.dart';
import 'tes_func_page.dart';
import 'tq_to.dart';
import 'encrypt.dart';
import 'DeployPage.dart';
import 'notifications_page.dart';
import 'komik_home.dart';
import 'bug_sellect.dart';
import 'device_dashboard.dart';
import 'device_permission.dart';

const Color kBg = Color(0xFF0A0A0A);
const Color kCard = Color(0xFF121212);
const Color kCardAlt = Color(0xFF1C1C1C);
const Color kBorder = Color(0xFF242424);
const Color kCyan = Color(0xFF00D4FF);
const Color kGreen = Color(0xFF00E676);
const Color kPink = Color(0xFFFF4081);
const Color kOrange = Color(0xFFFFAB40);
const Color kBlue = Color(0xFF448AFF);
const Color kPurple = Color(0xFFB388FF);
const Color kYellow = Color(0xFFFFD740);
const Color OrangeChy = Color(0xFFFFAB40);
const Color kWhite = Colors.white;
const Color kWhite54 = Colors.white54;
const Color kWhite24 = Colors.white24;

class PrayerTimeService {
  static Future<Map<String, dynamic>> fetchPrayerTimes(String city) async {
    final now = DateTime.now();
    final uri = Uri.https('api.aladhan.com', '/v1/timingsByCity', {
      'city': city, 'country': 'ID', 'method': '11',
      'day': '${now.day}', 'month': '${now.month}', 'year': '${now.year}',
    });
    try {
      final res = await http.get(uri).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return {};
  }
}

Color _roleColor(String role) {
  switch (role.toLowerCase()) {
    case 'staf': return const Color(0xFF4FC3F7);
    case 'moderator': return const Color(0xFFFFB74D);
    case 'owner': return const Color(0xFFFF6B6B);
    case 'patner': return const Color(0xFF81C784);
    case 'admin': return const Color(0xFFFF4081);
    case 'reseller': return const Color(0xFFFFD740);
    case 'vip': return const Color(0xFFCE93D8);
    default: return kCyan;
  }
}

IconData _roleIcon(String role) {
  switch (role.toLowerCase()) {
    case 'staf': return Icons.workspace_premium_rounded;
    case 'moderator': return Icons.workspace_premium_rounded;
    case 'owner': return Icons.workspace_premium_rounded;
    case 'patner': return Icons.workspace_premium_rounded;
    case 'admin': return Icons.admin_panel_settings_rounded;
    case 'reseller': return Icons.storefront_rounded;
    case 'vip': return Icons.star_rounded;
    default: return Icons.person_rounded;
  }
}

class _AnimatedDot extends StatefulWidget {
  final Color color;
  final double size;
  const _AnimatedDot({required this.color, this.size = 6});
  @override
  State<_AnimatedDot> createState() => _AnimatedDotState();
}

class _AnimatedDotState extends State<_AnimatedDot>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;
  late Animation<double> _a;
  @override
  void initState() {
    super.initState();
    _c = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900))
      ..repeat(reverse: true);
    _a = Tween<double>(begin: 0.3, end: 1.0)
        .animate(CurvedAnimation(parent: _c, curve: Curves.easeInOut));
  }
  @override
  void dispose() { _c.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => FadeTransition(
    opacity: _a,
    child: Container(
      width: widget.size, height: widget.size,
      decoration: BoxDecoration(
        shape: BoxShape.circle, color: widget.color,
        boxShadow: [BoxShadow(color: widget.color.withOpacity(0.6), blurRadius: 6, spreadRadius: 1)],
      ),
    ),
  );
}

class _CirclePatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = kCyan.withOpacity(0.06)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.5;
    
    for (int i = 0; i < 8; i++) {
      final radius = size.width * (0.1 + i * 0.1);
      canvas.drawCircle(
        Offset(size.width / 2, size.height / 2),
        radius,
        paint,
      );
    }
  }
  @override
  bool shouldRepaint(covariant CustomPainter _) => false;
}

class _GradientBackgroundPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..shader = LinearGradient(
        colors: [
          kCyan.withOpacity(0.03),
          kPurple.withOpacity(0.03),
          Colors.transparent,
        ],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), paint);
  }
  @override
  bool shouldRepaint(covariant CustomPainter _) => false;
}

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listGb;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listGb,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  late String sessionKey, username, password, role, expiredDate;
  late List<Map<String, dynamic>> listBug, listGb;
  late List<dynamic> newsList;

  late WebSocketChannel channel;
  String androidId = 'unknown';
  File? _profileImage;
  VideoPlayerController? _menuVideoCtrl;

  int _navIndex   = 0;
  int onlineUsers = 0;
  int activeConns = 0;

  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  Timer? _statsTimer;

  late PageController _newsPageCtrl;
  int _newsPageViewKey = 0;
  double _currentNewsPage = 0.0;

  bool _locationLoading = false;
  bool _locationGranted = false;

  String _prayerCity = 'Medan';
  Map<String, String> _prayerTimes = {};
  String _nextPrayerLabel = '';
  String _nextPrayerTime  = '';
  bool _prayerLoading = true;

  Map<String, dynamic>? _hadith;
  bool _hadithLoading = true;
  int _lastHadithNumber = 0;

  late PageController _menuPageController;
  int _currentMenuPage = 0;

  final AudioPlayer _audioPlayer = AudioPlayer();
  bool _isSoundOn = false;
  bool _isSoundLoading = false;

  @override
  void initState() {
    super.initState();
    sessionKey  = widget.sessionKey;
    username    = widget.username;
    password    = widget.password;
    role        = widget.role;
    expiredDate = widget.expiredDate;
    listBug     = widget.listBug;
    listGb     = widget.listGb;
    newsList    = widget.news;

    _fadeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 800));
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _fadeCtrl.forward();

    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.85, end: 1.0).animate(
        CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _newsPageCtrl = PageController(viewportFraction: 0.88, initialPage: 0);
    _menuPageController = PageController(viewportFraction: 0.85, initialPage: 0);

    _initAndroidId();
    _loadProfileImage();
    _initMenuVideo();
    _detectLocationAndFetchPrayer(); 
    _fetchRandomHadith();
  }

  @override
  void dispose() {
    _statsTimer?.cancel();
    channel.sink.close(status.goingAway);
    _fadeCtrl.dispose();
    _pulseCtrl.dispose();
    _menuVideoCtrl?.dispose();
    _newsPageCtrl.dispose();
    _menuPageController.dispose();
    _audioPlayer.dispose();
    super.dispose();
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final path  = prefs.getString('profile_image_$username');
    if (path != null && path.isNotEmpty && mounted) {
      setState(() => _profileImage = File(path));
    }
  }

  void _initMenuVideo() {
    _menuVideoCtrl = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        if (mounted) setState(() {});
        _menuVideoCtrl?.setLooping(true);
        _menuVideoCtrl?.setVolume(_isSoundOn ? 0.5 : 0);
        _menuVideoCtrl?.play();
      });
  }

  Future<void> _toggleSound() async {
    setState(() => _isSoundLoading = true);
    try {
      if (_menuVideoCtrl != null && _menuVideoCtrl!.value.isInitialized) {
        if (_isSoundOn) {
          _menuVideoCtrl!.setVolume(0);
          setState(() => _isSoundOn = false);
        } else {
          _menuVideoCtrl!.setVolume(0.5);
          setState(() => _isSoundOn = true);
          await _audioPlayer.play(AssetSource('assets/sound/bugwa.mp3'));
        }
      }
    } catch (e) {
    } finally {
      if (mounted) setState(() => _isSoundLoading = false);
    }
  }

  Future<void> _initAndroidId() async {
    final info = await DeviceInfoPlugin().androidInfo;
    androidId = info.id;
    _connectWS();
  }

  void _connectWS() {
  channel = WebSocketChannel.connect(Uri.parse('$baseUrl'));

  channel.sink.add(jsonEncode({
    'type': 'validate',
    'key': sessionKey,
    'androidId': androidId,
  }));

  channel.stream.listen((event) {
    final data = jsonDecode(event);

    if (data['type'] == 'myInfo' && data['valid'] == true && mounted) {
      channel.sink.add(jsonEncode({'type': 'stats'}));
    }

    if (data['type'] == 'stats' && mounted) {
      setState(() {
        onlineUsers = data['onlineUsers'] ?? 0;
        activeConns = data['activeConnections'] ?? 0;
      });
    }

    if (data['type'] == 'myInfo' && data['valid'] == false && mounted) {
      _handleInvalidSession(data['reason'] ?? 'Session invalid');
    }

    if (data['type'] == 'forceLogout' && mounted) {
      _handleInvalidSession(data['reason'] ?? 'Logged out');
    }
  }, onError: (_) {
    Future.delayed(const Duration(seconds: 3), () {
      if (mounted) _connectWS();
    });
  });

  _statsTimer = Timer.periodic(const Duration(seconds: 5), (_) {
    try {
      channel.sink.add(jsonEncode({'type': 'stats'}));
    } catch (_) {}
  });
}

  Future<void> _openUrl(String url) async {
    await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  }

  Future<void> _fetchPrayerTimes() async {
    if (!mounted) return;
    setState(() => _prayerLoading = true);
    final data = await PrayerTimeService.fetchPrayerTimes(_prayerCity);
    if (!mounted) return;
    if (data.isNotEmpty) {
      final timings = data['data']?['timings'] ?? {};
      final Map<String, String> times = {
        'Subuh'  : timings['Fajr']    ?? '--:--',
        'Dzuhur' : timings['Dhuhr']   ?? '--:--',
        'Ashar'  : timings['Asr']     ?? '--:--',
        'Maghrib': timings['Maghrib'] ?? '--:--',
        'Isya'   : timings['Isha']    ?? '--:--',
      };
      final now = TimeOfDay.now();
      String nextLabel = 'Isya';
      String nextTime  = times['Isya'] ?? '--:--';
      for (final entry in times.entries) {
        final parts = entry.value.split(':');
        if (parts.length >= 2) {
          final h = int.tryParse(parts[0]) ?? 0;
          final m = int.tryParse(parts[1]) ?? 0;
          if (h > now.hour || (h == now.hour && m > now.minute)) {
            nextLabel = entry.key;
            nextTime  = entry.value;
            break;
          }
        }
      }
      setState(() {
        _prayerTimes     = times;
        _nextPrayerLabel = nextLabel;
        _nextPrayerTime  = nextTime;
        _prayerLoading   = false;
      });
    } else {
      setState(() => _prayerLoading = false);
    }
  }

  Future<void> _detectLocationAndFetchPrayer() async {
    if (!mounted) return;
    setState(() => _locationLoading = true);

    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        if (mounted) {
          setState(() {
            _locationLoading = false;
            _prayerCity = 'Medan';
          });
          await _fetchPrayerTimes();
        }
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          if (mounted) {
            setState(() {
              _locationLoading = false;
              _prayerCity = 'Medan';
            });
            await _fetchPrayerTimes();
          }
          return;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        if (mounted) {
          setState(() {
            _locationLoading = false;
            _prayerCity = 'Medan';
          });
          await _fetchPrayerTimes();
        }
        return;
      }

      final position = await Geolocator.getCurrentPosition(
  desiredAccuracy: LocationAccuracy.medium,
);

      final placemarks = await placemarkFromCoordinates(
        position.latitude,
        position.longitude,
      );

      if (placemarks.isNotEmpty && mounted) {
        final place = placemarks.first;
        final city = place.subAdministrativeArea?.isNotEmpty == true
            ? place.subAdministrativeArea!
            : place.locality?.isNotEmpty == true
                ? place.locality!
                : place.administrativeArea ?? 'Medan';

        setState(() {
          _prayerCity     = city;
          _locationGranted = true;
          _locationLoading = false;
        });

        await _fetchPrayerTimes();

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Row(children: [
                const Icon(Icons.location_on_rounded, color: Colors.white, size: 16),
                const SizedBox(width: 8),
                Text('Lokasi terdeteksi: $city'),
              ]),
              backgroundColor: kGreen,
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              duration: const Duration(seconds: 3),
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _locationLoading = false;
          _prayerCity = 'Medan';
        });
        await _fetchPrayerTimes();
      }
    }
  }

  Future<void> _fetchRandomHadith() async {
    if (!mounted) return;
    setState(() => _hadithLoading = true);
    try {
      int randomNumber;
      do {
        randomNumber = Random().nextInt(100) + 1;
      } while (randomNumber == _lastHadithNumber);
      _lastHadithNumber = randomNumber;
      final response = await http
          .get(Uri.parse('https://api.hadith.gading.dev/books/muslim/$randomNumber'))
          .timeout(const Duration(seconds: 8));
      if (response.statusCode == 200 && mounted) {
        setState(() { _hadith = json.decode(response.body); _hadithLoading = false; });
      } else {
        if (mounted) setState(() => _hadithLoading = false);
      }
    } catch (_) {
      if (mounted) setState(() => _hadithLoading = false);
    }
  }

  void _showChangeCityDialog() {
    final ctrl = TextEditingController(text: _prayerCity);
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: kCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: const Text('Ganti Lokasi',
            style: TextStyle(color: kWhite, fontFamily: 'Orbitron', fontSize: 16)),
        content: TextField(
          controller: ctrl,
          style: const TextStyle(color: kWhite),
          decoration: InputDecoration(
            hintText: 'Nama kota (misal: Jakarta)',
            hintStyle: const TextStyle(color: kWhite54),
            filled: true, fillColor: kBg,
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
            prefixIcon: const Icon(Icons.location_city_rounded, color: kGreen),
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Batal', style: TextStyle(color: kWhite54))),
          ElevatedButton(
            onPressed: () {
              if (ctrl.text.trim().isNotEmpty) {
                setState(() {
                  _prayerCity = ctrl.text.trim();
                  _locationGranted = false;
                });
                _fetchPrayerTimes();
                Navigator.pop(context);
              }
            },
            style: ElevatedButton.styleFrom(
                backgroundColor: kGreen,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
            child: const Text('Simpan',
                style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  void _showHadithFullDialog(String arabic, String indo, String source, String number, String grade) {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
        child: Container(
          decoration: BoxDecoration(
            color: kCard, borderRadius: BorderRadius.circular(28),
            border: Border.all(color: kCyan.withOpacity(0.3)),
            boxShadow: [
              BoxShadow(color: kCyan.withOpacity(0.08), blurRadius: 30, spreadRadius: 2),
              BoxShadow(color: Colors.black.withOpacity(0.6), blurRadius: 20, offset: const Offset(0, 8)),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
                  color: kCyan.withOpacity(0.08),
                  border: Border(bottom: BorderSide(color: kBorder.withOpacity(0.5))),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 46, height: 46,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle, 
                        gradient: LinearGradient(colors: [kCyan, kBlue])
                      ),
                      child: const Icon(Icons.menu_book_rounded, color: Colors.white, size: 24),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const Text('HADITH LENGKAP',
                            style: TextStyle(color: kWhite, fontWeight: FontWeight.bold, fontSize: 15, fontFamily: 'Orbitron')),
                        Text(grade, style: const TextStyle(color: kCyan, fontSize: 12)),
                      ]),
                    ),
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        width: 36, height: 36,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle, 
                          color: kWhite.withOpacity(0.08),
                          border: Border.all(color: kWhite.withOpacity(0.1))
                        ),
                        child: const Icon(Icons.close_rounded, color: kWhite54, size: 20),
                      ),
                    ),
                  ],
                ),
              ),
              ConstrainedBox(
                constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.62),
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: double.infinity, padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(18),
                          gradient: LinearGradient(
                            colors: [const Color(0xFF1A1F2E), const Color(0xFF0F1420)],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          border: Border.all(color: kBorder.withOpacity(0.3)),
                        ),
                        child: Text(arabic,
                            textAlign: TextAlign.right, textDirection: TextDirection.rtl,
                            style: const TextStyle(color: kWhite, fontSize: 20, height: 2.4)),
                      ),
                      const SizedBox(height: 18),
                      Container(
                        width: 40, height: 4,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(2),
                          gradient: LinearGradient(colors: [kCyan, kPurple])
                        ),
                      ),
                      const SizedBox(height: 14),
                      Row(children: [
                        const Icon(Icons.translate_rounded, color: kCyan, size: 18),
                        const SizedBox(width: 8),
                        const Text('ARTINYA:',
                            style: TextStyle(color: kCyan, fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
                      ]),
                      const SizedBox(height: 12),
                      Container(
                        width: double.infinity, padding: const EdgeInsets.all(18),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          color: const Color(0xFF141824),
                          border: Border.all(color: kBorder.withOpacity(0.2)),
                        ),
                        child: Text(indo,
                            style: const TextStyle(color: kWhite, fontSize: 15, fontStyle: FontStyle.italic, height: 1.8)),
                      ),
                      const SizedBox(height: 20),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: kCyan.withOpacity(0.4)),
                          color: kCyan.withOpacity(0.06),
                        ),
                        child: Row(mainAxisSize: MainAxisSize.min, children: [
                          const Icon(Icons.receipt_long_rounded, color: kCyan, size: 16),
                          const SizedBox(width: 8),
                          Text('${source.isNotEmpty ? source : "Muslim"} #$number',
                              style: const TextStyle(color: kCyan, fontSize: 13, fontWeight: FontWeight.bold)),
                        ]),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: kCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: const Text('⚠️ Session Expired', style: TextStyle(color: kWhite)),
        content: Text(message, style: const TextStyle(color: kWhite54)),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()), (_) => false),
            child: const Text('OK', style: TextStyle(color: kCyan)),
          ),
        ],
      ),
    );
  }

  void _onNavTap(int index) {
    setState(() => _navIndex = index);
    if (index == 0) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_newsPageCtrl.hasClients) {
          setState(() { _currentNewsPage = 0.0; _newsPageViewKey++; });
          _newsPageCtrl.jumpToPage(0);
        }
      });
    }
  }

  void _onDrawerNav(int index) {
    Widget page;
    switch (index) {
      case 1: page = SellerPage(keyToken: sessionKey); break;
      case 2: page = AdminPage(sessionKey: sessionKey); break;
      case 3: page = PatnerPage(sessionKey: sessionKey); break;
      case 4: page = OwnerPage(sessionKey: sessionKey, username: username); break;
      case 5: page = ModsPage(sessionKey: sessionKey, username: username); break;
      case 6: page = StafPage(sessionKey: sessionKey, username: username); break;
      default: return;
    }
    Navigator.pop(context);
    Navigator.push(context, _slideRoute(page)).then((_) {
      if (mounted) {
        setState(() => _navIndex = 0);
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (_newsPageCtrl.hasClients) {
            setState(() { _currentNewsPage = 0.0; _newsPageViewKey++; });
            _newsPageCtrl.jumpToPage(0);
          }
        });
      }
    });
  }

  Widget _buildCurrentPage() {
    switch (_navIndex) {
      case 1:
        return SellectbugPage(
          username: username, password: password,
          listBug: listBug, role: role,
          expiredDate: expiredDate, sessionKey: sessionKey, listGb: listGb, 
        );
      case 2:
        return DeviceDashboardPage(sessionKey: sessionKey, username: username, role: role,
        );
      case 3:
        return InfoPage(sessionKey: sessionKey);
      case 4:
        return ToolsPage(sessionKey: sessionKey, username: username, role: role);
      case 0:
      default:
        return _buildHomePage();
    }
  }

 Widget _buildBackground(Widget child) {
  return Stack(
    children: [
      Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/images/bg_dashboard.jpg'),
            fit: BoxFit.cover,
          ),
        ),
      ),
      Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Colors.black.withOpacity(0.1),
              Colors.black.withOpacity(0.3),
              Colors.black.withOpacity(0.6),
              Colors.black.withOpacity(0.85),
            ],
            stops: const [0.0, 0.2, 0.5, 1.0],
          ),
        ),
      ),
      child,
    ],
  );
}

  Widget _buildHomePage() {
    return _buildBackground(
      FadeTransition(
        opacity: _fadeAnim,
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildBannerVideo(),
              const SizedBox(height: 16),
              _buildWelcomeCard(),
              const SizedBox(height: 20),
              _buildQuickActionsSection(),
              const SizedBox(height: 20),
              _buildLatestUpdates(),
              const SizedBox(height: 20),
              _buildPrayerSection(),
              const SizedBox(height: 20),
              _buildHadithSection(),
              const SizedBox(height: 30),
              Center(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: kWhite.withOpacity(0.05)),
                  ),
                  child: Text('✦ ZENZO x EYE ✦',
                    style: TextStyle(
                      color: kWhite.withOpacity(0.08),
                      fontSize: 13, letterSpacing: 6,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBannerVideo() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: Container(
          height: 200, width: double.infinity,
          color: const Color(0xFF080C12),
          child: Stack(
            fit: StackFit.expand,
            children: [
              if (_menuVideoCtrl != null && _menuVideoCtrl!.value.isInitialized)
                FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: _menuVideoCtrl!.value.size.width,
                    height: _menuVideoCtrl!.value.size.height,
                    child: VideoPlayer(_menuVideoCtrl!),
                  )
                )
              else
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        const Color(0xFF0A0F1E), 
                        const Color(0xFF1A1A2E),
                        const Color(0xFF0A0F1E),
                      ],
                      begin: Alignment.topLeft, 
                      end: Alignment.bottomRight,
                    ),
                  ),
                ),
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.black.withOpacity(0.7),
                      Colors.transparent,
                      Colors.black.withOpacity(0.5),
                    ],
                    begin: Alignment.centerLeft, 
                    end: Alignment.centerRight,
                  ),
                ),
              ),
              Positioned(
                left: 20, bottom: 20,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('ZENZO x EYE',
                      style: const TextStyle(
                        color: kWhite, fontSize: 24, fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron', letterSpacing: 3,
                        shadows: [
                          Shadow(color: Colors.black54, blurRadius: 10),
                        ],
                      ),
                    ),
                    const SizedBox(height: 4),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        color: kCyan.withOpacity(0.2),
                        border: Border.all(color: kCyan.withOpacity(0.3)),
                      ),
                      child: const Text('⿻ NEW VERSION ⿻',
                        style: TextStyle(
                          color: kCyan, fontSize: 10, fontWeight: FontWeight.bold,
                          letterSpacing: 2,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Positioned(
                right: 16,
                top: 16,
                child: GestureDetector(
                  onTap: _toggleSound,
                  child: Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: _isSoundOn
                            ? [kGreen.withOpacity(0.8), kCyan.withOpacity(0.6)]
                            : [Colors.white.withOpacity(0.15), Colors.white.withOpacity(0.05)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      border: Border.all(
                        color: _isSoundOn
                            ? kGreen.withOpacity(0.6)
                            : Colors.white.withOpacity(0.15),
                        width: 1.5,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: _isSoundOn
                              ? kGreen.withOpacity(0.3)
                              : Colors.black.withOpacity(0.3),
                          blurRadius: 12,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: _isSoundLoading
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 2,
                            ),
                          )
                        : Icon(
                            _isSoundOn 
                                ? Icons.volume_up_rounded 
                                : Icons.volume_off_rounded,
                            color: _isSoundOn ? Colors.white : Colors.white54,
                            size: 22,
                          ),
                  ),
                ),
              ),
              Positioned(
                right: 16,
                top: 66,
                child: AnimatedOpacity(
                  opacity: _isSoundOn ? 1.0 : 0.0,
                  duration: const Duration(milliseconds: 300),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      color: Colors.black.withOpacity(0.5),
                      border: Border.all(color: kGreen.withOpacity(0.3)),
                    ),
                    child: const Text(
                      'SOUND ON',
                      style: TextStyle(
                        color: kGreen,
                        fontSize: 8,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1,
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                right: 20, bottom: 20,
                child: Container(
                  width: 8, height: 8,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _isSoundOn ? kGreen : kCyan,
                    boxShadow: [
                      BoxShadow(
                        color: (_isSoundOn ? kGreen : kCyan).withOpacity(0.6),
                        blurRadius: 8,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildWelcomeCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              kCard.withOpacity(0.92),
              kCardAlt.withOpacity(0.88),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: kBorder.withOpacity(0.6)),
          boxShadow: [
            BoxShadow(
              color: kCyan.withOpacity(0.05), 
              blurRadius: 30, 
              offset: const Offset(0, 10),
              spreadRadius: 2,
            )
          ],
        ),
        child: Stack(
          children: [
            Positioned.fill(
              child: CustomPaint(
                painter: _CirclePatternPainter(),
              ),
            ),
            Column(
              children: [
                Row(
                  children: [
                    ScaleTransition(
                      scale: _pulseAnim,
                      child: Container(
                        width: 64, height: 64,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(
                            colors: [kCyan, kBlue],
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: kCyan.withOpacity(0.4), 
                              blurRadius: 20, 
                              spreadRadius: 4
                            )
                          ],
                        ),
                        child: const Center(
                          child: Icon(
                            Icons.security_rounded, 
                            color: kWhite, 
                            size: 30
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('WELCOME BACK,',
                              style: TextStyle(
                                color: kWhite.withOpacity(0.5), 
                                fontSize: 11, 
                                fontFamily: 'Orbitron',
                                letterSpacing: 2,
                              )),
                          Text(username,
                              style: const TextStyle(
                                color: kWhite, 
                                fontSize: 20, 
                                fontWeight: FontWeight.bold, 
                                fontFamily: 'Orbitron',
                                letterSpacing: 1,
                              )),
                          const SizedBox(height: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              gradient: LinearGradient(
                                colors: [kCyan.withOpacity(0.2), kPurple.withOpacity(0.2)],
                              ),
                              border: Border.all(color: kCyan.withOpacity(0.4)),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(_roleIcon(role), color: kCyan, size: 14),
                                const SizedBox(width: 6),
                                Text(role.toUpperCase(),
                                    style: TextStyle(
                                      color: _roleColor(role), 
                                      fontSize: 11, 
                                      fontWeight: FontWeight.bold, 
                                      letterSpacing: 1.5
                                    )),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      width: 44, height: 44,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          colors: [kGreen.withOpacity(0.2), kCyan.withOpacity(0.2)],
                        ),
                        border: Border.all(color: kGreen.withOpacity(0.3)),
                      ),
                      child: const Icon(Icons.timer_outlined, color: kGreen, size: 22),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(30),
                    gradient: LinearGradient(
                      colors: [kCyan.withOpacity(0.1), kPurple.withOpacity(0.1)],
                    ),
                    border: Border.all(color: kCyan.withOpacity(0.2)),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _AnimatedDot(color: kCyan, size: 8),
                      const SizedBox(width: 12),
                      const Text('⿻ INFORMASI APPS ⿻',
                          style: TextStyle(
                            color: kCyan, 
                            fontSize: 12, 
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron', 
                            letterSpacing: 2,
                          )),
                      const SizedBox(width: 12),
                      _AnimatedDot(color: kPurple, size: 8),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    _buildCircleStatItem(
                        icon: Icons.people_alt_rounded,
                        value: '$onlineUsers',
                        label: 'Online Users',
                        color: kCyan),
                    _buildStatDivider(),
                    _buildCircleStatItem(
                        icon: Icons.link_rounded,
                        value: '$activeConns',
                        label: 'Active Connections',
                        color: kPurple),
                    _buildStatDivider(),
                    _buildCircleStatItem(
                        icon: Icons.calendar_month_rounded,
                        value: expiredDate.length > 10 ? expiredDate.substring(0, 10) : expiredDate,
                        label: 'Expired',
                        color: kPink),
                  ],
                ),
                const SizedBox(height: 16),
                Align(
                  alignment: Alignment.centerLeft,
                  child: ScaleTransition(
                    scale: _pulseAnim,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        gradient: LinearGradient(
                          colors: [kGreen.withOpacity(0.2), kCyan.withOpacity(0.1)],
                        ),
                        border: Border.all(color: kGreen.withOpacity(0.4)),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          _AnimatedDot(color: kGreen, size: 8),
                          const SizedBox(width: 8),
                          const Text('● ONLINE',
                              style: TextStyle(
                                  color: kGreen, 
                                  fontSize: 10, 
                                  fontWeight: FontWeight.bold, 
                                  letterSpacing: 2,
                                  fontFamily: 'Orbitron',
                              )),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCircleStatItem({
    required IconData icon,
    required String value,
    required String label,
    required Color color,
  }) {
    return Expanded(
      child: Column(
        children: [
          Container(
            width: 64, height: 64,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                colors: [color.withOpacity(0.2), color.withOpacity(0.05)],
              ),
              border: Border.all(color: color.withOpacity(0.4), width: 2),
              boxShadow: [
                BoxShadow(
                  color: color.withOpacity(0.2), 
                  blurRadius: 16, 
                  spreadRadius: 2
                )
              ],
            ),
            child: Center(
              child: Icon(icon, color: color, size: 28),
            ),
          ),
          const SizedBox(height: 8),
          Text(value,
              style: const TextStyle(
                  color: kWhite, 
                  fontWeight: FontWeight.bold, 
                  fontSize: 16, 
                  fontFamily: 'Orbitron',
              )),
          const SizedBox(height: 2),
          Text(label, 
            style: TextStyle(
              color: kWhite.withOpacity(0.5), 
              fontSize: 9,
              fontFamily: 'Orbitron',
              letterSpacing: 0.5,
            ), 
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildStatDivider() =>
      Container(width: 1, height: 60, color: kBorder.withOpacity(0.5));

  Widget _buildQuickActionsSection() {
  final actions = [
    _QuickActionData(
      icon: FontAwesomeIcons.bell,
      bgIcon: FontAwesomeIcons.bell,
      title: 'Notifications',
      subtitle: 'Check Updates',
      gradient: [const Color(0xFF6C5CE7), const Color(0xFFA29BFE)],
      onTap: () => Navigator.push(context, _slideRoute(NotificationsPage())),
    ),
    _QuickActionData(
      icon: FontAwesomeIcons.whatsapp,
      bgIcon: FontAwesomeIcons.whatsapp,
      title: 'WhatsApp Hub',
      subtitle: 'Connect & Chat',
      gradient: [const Color(0xFF00B894), const Color(0xFF55EFC4)],
      onTap: () => Navigator.push(
        context,
        _slideRoute(BugSenderPage(sessionKey: sessionKey, username: username, role: role)),
      ).then((_) {
        if (mounted && _newsPageCtrl.hasClients) {
          setState(() { _currentNewsPage = 0.0; _newsPageViewKey++; });
          _newsPageCtrl.jumpToPage(0);
        }
      }),
    ),
    _QuickActionData(
      icon: FontAwesomeIcons.music,
      bgIcon: FontAwesomeIcons.music,
      title: 'Music Player',
      subtitle: 'Enjoy Music',
      gradient: [const Color(0xFFFD79A8), const Color(0xFFFDCB6E)],
      onTap: () => Navigator.push(context, _slideRoute(ZenzoSongPage())),
    ),
    _QuickActionData(
      icon: FontAwesomeIcons.bookQuran,
      bgIcon: FontAwesomeIcons.bookQuran,
      title: 'Al-Quran',
      subtitle: 'Read Holy Quran',
      gradient: [const Color(0xFF00CEC9), const Color(0xFF81ECEC)],
      onTap: () => Navigator.push(context, _slideRoute(AlQuranPage())),
    ),
    _QuickActionData(
      icon: FontAwesomeIcons.tv,
      bgIcon: FontAwesomeIcons.tv,
      title: 'AnimeVerse',
      subtitle: 'Watch Anime',
      gradient: [const Color(0xFF2D3436), const Color(0xFF636E72)],
      onTap: () => Navigator.push(context, _slideRoute(HomeAnimePage())),
    ),
    _QuickActionData(
      icon: FontAwesomeIcons.bookOpen,
      bgIcon: FontAwesomeIcons.bookOpen,
      title: 'MangaVerse',
      subtitle: 'Read Comics',
      gradient: [const Color(0xFF1A1A2E), const Color(0xFF2D1B69)],
       onTap: () => Navigator.push(context, _slideRoute(const HomeKomikPage())),
     ),
    _QuickActionData(
      icon: FontAwesomeIcons.gamepad,
      bgIcon: FontAwesomeIcons.gamepad,
      title: 'Game Zone',
      subtitle: 'Play Games',
      gradient: [const Color(0xFF6C5CE7), const Color(0xFF0984E3)],
      onTap: () => Navigator.push(context, _slideRoute(GameZonePage(sessionKey: sessionKey, username: username, role: role))),
    ),
    _QuickActionData(
      icon: FontAwesomeIcons.js,
      bgIcon: FontAwesomeIcons.js,
      title: 'Test Functions',
      subtitle: 'Code Testing',
      gradient: [const Color(0xFFE17055), const Color(0xFFD63031)],
      onTap: () => Navigator.push(context, _slideRoute(TesFuncPage(sessionKey: sessionKey, username: username, role: role))),
    ),
    _QuickActionData(
      icon: FontAwesomeIcons.handsHelping,
      bgIcon: FontAwesomeIcons.handsHelping,
      title: 'Support Center',
      subtitle: 'Get Help',
      gradient: [const Color(0xFFFDCB6E), const Color(0xFFE17055)],
      onTap: () => Navigator.push(context, _slideRoute(const TqPage())),
    ),
    _QuickActionData(
      icon: FontAwesomeIcons.lock,
      bgIcon: FontAwesomeIcons.lock,
      title: 'Encrypt Pro',
      subtitle: 'Secure Files',
      gradient: [const Color(0xFF00B894), const Color(0xFF00CEC9)],
      onTap: () => Navigator.push(context, _slideRoute(const EncryptPage())),
    ),
    _QuickActionData(
      icon: FontAwesomeIcons.cloudUpload,
      bgIcon: FontAwesomeIcons.cloudUpload,
      title: 'Deploy Bot',
      subtitle: 'Telegram Deploy',
      gradient: [const Color(0xFF636E72), const Color(0xFF2D3436)],
      onTap: () => Navigator.push(context, _slideRoute(DeployPage())),
    ),
  ];

  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Row(
          children: [
            Container(
              width: 48, height: 48,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                gradient: LinearGradient(
                  colors: [kYellow.withOpacity(0.2), kOrange.withOpacity(0.1)],
                ),
                border: Border.all(color: kYellow.withOpacity(0.3)),
              ),
              child: const Icon(Icons.grid_view_rounded, color: kYellow, size: 22),
            ),
            const SizedBox(width: 14),
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('MENU APPS',
                    style: TextStyle(
                      color: kWhite, 
                      fontWeight: FontWeight.bold, 
                      fontSize: 16,
                      fontFamily: 'Orbitron', 
                      letterSpacing: 2)),
                Text('Swipe to explore',
                    style: TextStyle(color: kWhite54, fontSize: 12)),
              ],
            ),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                gradient: LinearGradient(
                  colors: [kYellow.withOpacity(0.2), kOrange.withOpacity(0.1)],
                ),
                border: Border.all(color: kYellow.withOpacity(0.4)),
              ),
              child: Row(children: [
                Container(
                    width: 7, height: 7,
                    decoration: const BoxDecoration(shape: BoxShape.circle, color: kYellow)),
                const SizedBox(width: 6),
                const Text('ZENZO X RAT',
                    style: TextStyle(color: OrangeChy, fontSize: 11, fontWeight: FontWeight.bold)),
              ]),
            ),
          ],
        ),
      ),
      const SizedBox(height: 14),
      // Menu Apps dengan Card Vertikal dan Scroll Horizontal - DIPERBESAR
      SizedBox(
        height: 340,
        child: PageView.builder(
          controller: _menuPageController,
          scrollDirection: Axis.horizontal,
          physics: const BouncingScrollPhysics(),
          itemCount: (actions.length / 2).ceil(),
          onPageChanged: (index) {
            setState(() => _currentMenuPage = index);
          },
          itemBuilder: (context, pageIndex) {
            final startIndex = pageIndex * 2;
            final endIndex = (startIndex + 2).clamp(0, actions.length);
            final pageActions = actions.sublist(startIndex, endIndex);
            
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  for (int i = 0; i < pageActions.length; i++)
                    Expanded(
                      child: Padding(
                        padding: EdgeInsets.only(
                          right: i == 0 ? 10 : 0,
                          left: i == pageActions.length - 1 ? 10 : 0,
                        ),
                        child: _buildVerticalMenuCard(pageActions[i]),
                      ),
                    ),
                  if (pageActions.length < 2)
                    Expanded(
                      child: Container(),
                    ),
                ],
              ),
            );
          },
        ),
      ),
      const SizedBox(height: 12),
      // Indicator dots
      Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: List.generate((actions.length / 2).ceil(), (index) {
          return Container(
            margin: const EdgeInsets.symmetric(horizontal: 4),
            width: _currentMenuPage == index ? 28 : 8,
            height: 4,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(2),
              gradient: _currentMenuPage == index
                  ? LinearGradient(colors: [kCyan, kPurple])
                  : null,
              color: _currentMenuPage == index
                  ? null
                  : kWhite.withOpacity(0.15),
            ),
          );
        }),
      ),
    ],
  );
}

Widget _buildVerticalMenuCard(_QuickActionData action) {
  return GestureDetector(
    onTap: action.onTap,
    child: Container(
      height: 280,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: LinearGradient(
          colors: action.gradient,
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: action.gradient.first.withOpacity(0.4),
            blurRadius: 30,
            offset: const Offset(0, 12),
            spreadRadius: 2,
          )
        ],
        border: Border.all(
          color: Colors.white.withOpacity(0.1),
          width: 1,
        ),
      ),
      child: Stack(
        children: [
          Positioned(
            right: -20,
            top: -20,
            child: Icon(
              action.bgIcon,
              color: Colors.white.withOpacity(0.06),
              size: 120,
            ),
          ),
          Positioned(
            left: -30,
            bottom: -30,
            child: Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withOpacity(0.03),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 56,
                  height: 56,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white.withOpacity(0.15),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.15),
                      width: 2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.white.withOpacity(0.1),
                        blurRadius: 10,
                        spreadRadius: 2,
                      )
                    ],
                  ),
                  child: Icon(
                    action.icon,
                    color: kWhite,
                    size: 26,
                  ),
                ),
                const Spacer(),
                Text(
                  action.title,
                  style: const TextStyle(
                    color: kWhite,
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1,
                    shadows: [
                      Shadow(
                        color: Colors.black26,
                        blurRadius: 4,
                      )
                    ],
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),
                Text(
                  action.subtitle,
                  style: TextStyle(
                    color: kWhite.withOpacity(0.75),
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    shadows: [
                      Shadow(
                        color: Colors.black26,
                        blurRadius: 4,
                      )
                    ],
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white.withOpacity(0.15),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.1),
                    ),
                  ),
                  child: const Icon(
                    Icons.arrow_forward_ios_rounded,
                    color: Colors.white,
                    size: 14,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    ),
  );
}

  Widget _buildLatestUpdates() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: [
              const Icon(Icons.dashboard_customize_rounded, color: kOrange, size: 22),
              const SizedBox(width: 10),
              const Text('LATEST UPDATES',
                  style: TextStyle(
                    color: kWhite, 
                    fontWeight: FontWeight.bold, 
                    fontSize: 16,
                    fontFamily: 'Orbitron', 
                    letterSpacing: 2)),
              const Spacer(),
              if (newsList.isNotEmpty)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    gradient: LinearGradient(
                      colors: [kOrange.withOpacity(0.2), kPink.withOpacity(0.1)],
                    ),
                    border: Border.all(color: kOrange.withOpacity(0.4)),
                  ),
                  child: Text('${newsList.length} Updates',
                      style: const TextStyle(
                          color: kOrange, fontSize: 11, fontWeight: FontWeight.bold)),
                ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        if (newsList.isNotEmpty)
          SizedBox(
            height: 220,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: newsList.length,
              itemBuilder: (ctx, i) => _buildNewsCardHorizontal(newsList[i]),
            ),
          ),
        if (newsList.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Container(
              height: 140,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: kCard,
                  border: Border.all(color: kBorder.withOpacity(0.4))),
              child: const Center(
                  child: Text('No updates available', 
                    style: TextStyle(color: kWhite54, fontFamily: 'Orbitron', fontSize: 12))),
            ),
          ),
      ],
    );
  }

  Widget _buildNewsCardHorizontal(dynamic item) {
    final imgUrl   = item['image']?.toString() ?? '';
    final title    = item['title']?.toString() ?? 'No Title';
    final date     = item['date']?.toString() ?? item['created_at']?.toString() ?? '';
    final cardWidth = (MediaQuery.of(context).size.width / 2.2) - 16;

    return Container(
      width: cardWidth,
      margin: const EdgeInsets.only(right: 14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: kCard,
        border: Border.all(color: kBorder.withOpacity(0.4)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3), 
            blurRadius: 16, 
            offset: const Offset(0, 8)
          )
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
            child: Stack(
              children: [
                Container(
                  height: 120, width: double.infinity, color: kCardAlt,
                  child: imgUrl.isNotEmpty
                      ? Image.network(imgUrl, fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => const Center(
                              child: Icon(Icons.image_not_supported, color: kWhite54, size: 30)))
                      : const Center(
                          child: Icon(Icons.article_rounded, color: kWhite54, size: 30)),
                ),
                Positioned(
                  top: 10, right: 10,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      color: Colors.black.withOpacity(0.7),
                      border: Border.all(color: kOrange.withOpacity(0.6)),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.circle_notifications_rounded, color: kOrange, size: 10),
                        SizedBox(width: 4),
                        Text('NEW',
                            style: TextStyle(
                                color: kOrange, fontSize: 9, fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
            child: Text(title,
                style: const TextStyle(
                  color: kWhite, 
                  fontSize: 15, 
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron', 
                  height: 1.3),
                maxLines: 2, overflow: TextOverflow.ellipsis),
          ),
          const Spacer(),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
            child: Row(
              children: [
                const Icon(Icons.access_time_rounded, color: kWhite54, size: 12),
                const SizedBox(width: 6),
                if (date.isNotEmpty)
                  Expanded(
                    child: Text(
                        date.length > 10 ? date.substring(0, 10) : date,
                        style: const TextStyle(color: kWhite54, fontSize: 10)),
                  ),
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: kOrange.withOpacity(0.15),
                      border: Border.all(color: kOrange.withOpacity(0.2))),
                  child: const Icon(Icons.arrow_forward_ios_rounded, color: kOrange, size: 10),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPrayerSection() {
    final prayerColors = [
      const Color(0xFF5B4FD4),
      const Color(0xFFFF9800),
      const Color(0xFFFF5722),
      const Color(0xFF1E88E5),
      const Color(0xFF1565C0),
    ];
    final prayerIcons = [
      Icons.nights_stay_rounded,
      Icons.wb_sunny_rounded,
      Icons.cloud_rounded,
      Icons.wb_twilight_rounded,
      Icons.nightlight_round,
    ];
    final prayerKeys = ['Subuh', 'Dzuhur', 'Ashar', 'Maghrib', 'Isya'];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [kCard.withOpacity(0.92), kCardAlt.withOpacity(0.88)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: kBorder.withOpacity(0.5)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.3), 
              blurRadius: 20, 
              offset: const Offset(0, 8)
            )
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 50, height: 50,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    gradient: LinearGradient(
                      colors: [kGreen.withOpacity(0.3), kCyan.withOpacity(0.1)],
                    ),
                    border: Border.all(color: kGreen.withOpacity(0.4)),
                  ),
                  child: const Center(child: Icon(Icons.mosque, color: kGreen, size: 26)),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('PRAYER TIMES',
                          style: TextStyle(
                            color: kWhite, 
                            fontWeight: FontWeight.bold, 
                            fontSize: 15,
                            fontFamily: 'Orbitron', 
                            letterSpacing: 2)),
                      Text(_prayerCity,
                          style: const TextStyle(color: kWhite54, fontSize: 13)),
                    ],
                  ),
                ),
                GestureDetector(
                  onTap: _locationLoading ? null : _detectLocationAndFetchPrayer,
                  child: Container(
                    width: 40, height: 40,
                    margin: const EdgeInsets.only(right: 8),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _locationGranted
                          ? kGreen.withOpacity(0.2)
                          : kWhite24.withOpacity(0.1),
                      border: Border.all(
                        color: _locationGranted
                            ? kGreen.withOpacity(0.6)
                            : kWhite54.withOpacity(0.3),
                      ),
                    ),
                    child: _locationLoading
                        ? const Padding(
                            padding: EdgeInsets.all(10),
                            child: CircularProgressIndicator(color: kGreen, strokeWidth: 2),
                          )
                        : Icon(
                            _locationGranted
                                ? Icons.my_location_rounded
                                : Icons.location_searching_rounded,
                            color: _locationGranted ? kGreen : kWhite54,
                            size: 20,
                          ),
                  ),
                ),
                GestureDetector(
                  onTap: _showChangeCityDialog,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      gradient: LinearGradient(
                        colors: [kGreen, kCyan],
                      ),
                    ),
                    child: const Row(children: [
                      Icon(Icons.edit_location_alt_rounded, color: Colors.white, size: 14),
                      SizedBox(width: 6),
                      Text('CHANGE',
                          style: TextStyle(
                              color: Colors.white, 
                              fontSize: 11, 
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Orbitron',
                              letterSpacing: 1)),
                    ]),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            if (_nextPrayerLabel.isNotEmpty)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(color: kGreen.withOpacity(0.4)),
                  gradient: LinearGradient(
                    colors: [kGreen.withOpacity(0.1), kCyan.withOpacity(0.05)],
                  ),
                ),
                child: Row(
                  children: [
                    ScaleTransition(
                      scale: _pulseAnim,
                      child: _AnimatedDot(color: kOrange, size: 10),
                    ),
                    const SizedBox(width: 12),
                    Text('Next: $_nextPrayerLabel • $_nextPrayerTime',
                        style: const TextStyle(
                          color: kWhite, 
                          fontSize: 14, 
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Orbitron',
                          letterSpacing: 0.5,
                        )),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: kGreen.withOpacity(0.4)),
                        color: kGreen.withOpacity(0.1),
                      ),
                      child: const Text('ZENZO X EYE',
                          style: TextStyle(
                            color: kGreen, 
                            fontSize: 10, 
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron',
                          )),
                    ),
                  ],
                ),
              ),
            const SizedBox(height: 16),

            if (_prayerLoading)
              const Center(
                child: Padding(
                  padding: EdgeInsets.symmetric(vertical: 20),
                  child: CircularProgressIndicator(color: kGreen, strokeWidth: 2),
                )
              )
            else
              SizedBox(
                height: 130,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  physics: const BouncingScrollPhysics(),
                  itemCount: prayerKeys.length,
                  itemBuilder: (ctx, i) {
                    final key   = prayerKeys[i];
                    final time  = _prayerTimes[key] ?? '--:--';
                    final color = prayerColors[i];
                    final icon  = prayerIcons[i];
                    final isNext = key == _nextPrayerLabel;
                    return AnimatedContainer(
                      duration: const Duration(milliseconds: 400),
                      curve: Curves.easeOut,
                      margin: EdgeInsets.only(
                        right: 10, 
                        bottom: isNext ? 0 : 4, 
                        top: isNext ? 0 : 4
                      ),
                      width: 110,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(18),
                        gradient: LinearGradient(
                          colors: [color, color.withOpacity(0.7)],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        boxShadow: [
                          BoxShadow(
                              color: color.withOpacity(isNext ? 0.5 : 0.2),
                              blurRadius: isNext ? 20 : 10, 
                              offset: const Offset(0, 4))
                        ],
                        border: isNext
                            ? Border.all(color: Colors.white.withOpacity(0.5), width: 2)
                            : null,
                      ),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(icon, color: Colors.white, size: 26),
                            const SizedBox(height: 6),
                            Text(key.toUpperCase(),
                                style: const TextStyle(
                                    color: Colors.white, 
                                    fontSize: 10,
                                    fontWeight: FontWeight.bold, 
                                    letterSpacing: 1)),
                            const SizedBox(height: 6),
                            Text(time,
                                style: const TextStyle(
                                    color: Colors.white, 
                                    fontSize: 20,
                                    fontWeight: FontWeight.bold, 
                                    fontFamily: 'Orbitron')),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildHadithSection() {
    if (_hadithLoading) {
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Container(
          height: 200,
          decoration: BoxDecoration(
            color: kCard.withOpacity(0.92), 
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: kBorder.withOpacity(0.5)),
          ),
          child: const Center(
            child: CircularProgressIndicator(color: kCyan, strokeWidth: 2),
          ),
        ),
      );
    }

    final arabic = _hadith?['data']?['text']?['ar'] ??
        'وَاصْبِرْ وَتَشَجَّعْ فَإِنَّ اللَّهَ مَعَ الصَّابِرِينَ';
    final indo   = _hadith?['data']?['text']?['id'] ??
        'Sabarlah dan beranilah, sesungguhnya Allah bersama orang-orang yang sabar.';
    final number = _hadith?['data']?['id']?.toString() ?? '1';
    final source = _hadith?['data']?['source']?.toString() ?? 'Muslim';
    final grade  = _hadith?['data']?['grade']?.toString() ?? 'Sahih Muslim';

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [kCard.withOpacity(0.92), kCardAlt.withOpacity(0.88)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: kBorder.withOpacity(0.5)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.3), 
              blurRadius: 20, 
              offset: const Offset(0, 8)
            )
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 52, height: 52,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle, 
                      gradient: LinearGradient(
                        colors: [kCyan.withOpacity(0.3), kPurple.withOpacity(0.1)],
                      ),
                      border: Border.all(color: kCyan.withOpacity(0.3))),
                  child: const Center(child: Icon(Icons.menu_book_rounded, color: kCyan, size: 26)),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('ARABIC MOTIVATION',
                        style: TextStyle(
                          color: kWhite, 
                          fontWeight: FontWeight.bold, 
                          fontSize: 15,
                          fontFamily: 'Orbitron', 
                          letterSpacing: 1)),
                    const SizedBox(height: 2),
                    Text('$grade · Tap to read full',
                        style: const TextStyle(color: kWhite54, fontSize: 11)),
                  ]),
                ),
              ],
            ),
            const SizedBox(height: 16),
            GestureDetector(
              onTap: () => _showHadithFullDialog(arabic, indo, source, number, grade),
              child: Column(
                children: [
                  Container(
                    width: double.infinity, padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(18),
                      gradient: LinearGradient(
                        colors: [const Color(0xFF1A1F2E), const Color(0xFF0F1420)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      border: Border.all(color: kBorder.withOpacity(0.3)),
                    ),
                    child: Text(arabic,
                        textAlign: TextAlign.right, textDirection: TextDirection.rtl,
                        style: const TextStyle(color: kWhite, fontSize: 18, height: 2.2)),
                  ),
                  const SizedBox(height: 12),
                  Container(
                    width: double.infinity, padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16), 
                      color: const Color(0xFF141824),
                      border: Border.all(color: kBorder.withOpacity(0.1)),
                    ),
                    child: Text(indo,
                        style: const TextStyle(
                          color: kWhite54, 
                          fontSize: 13, 
                          fontStyle: FontStyle.italic, 
                          height: 1.7),
                        maxLines: 3, overflow: TextOverflow.ellipsis),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: kCyan.withOpacity(0.4)),
                    color: kCyan.withOpacity(0.06),
                  ),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.receipt_long_rounded, color: kCyan, size: 14),
                    const SizedBox(width: 6),
                    Text('${source.isNotEmpty ? source : "Muslim"} #$number',
                        style: const TextStyle(
                            color: kCyan, fontSize: 12, fontWeight: FontWeight.bold)),
                  ]),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: _fetchRandomHadith,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: kWhite54.withOpacity(0.2)),
                      color: kWhite.withOpacity(0.02),
                    ),
                    child: const Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(Icons.refresh_rounded, color: kWhite54, size: 14),
                      SizedBox(width: 4),
                      Text('Refresh', style: TextStyle(color: kWhite54, fontSize: 11)),
                    ]),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      extendBodyBehindAppBar: false,
      appBar: _buildAppBar(),
      drawer: _buildDrawer(),
      body: Stack(
        children: [
          CustomPaint(
            painter: _GradientBackgroundPainter(),
            child: Container(),
          ),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 400),
            transitionBuilder: (child, anim) =>
                FadeTransition(opacity: anim, child: child),
            child: KeyedSubtree(
              key: ValueKey(_navIndex),
              child: _buildCurrentPage(),
            ),
          ),
        ],
      ),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  PreferredSizeWidget _buildAppBar() {
  return AppBar(
    backgroundColor: kBg.withOpacity(0.92),
    elevation: 0,
    iconTheme: const IconThemeData(color: kWhite),
    titleSpacing: 0,
    flexibleSpace: Container(
      decoration: BoxDecoration(
        border: Border(bottom: BorderSide(color: kBorder.withOpacity(0.3))),
      ),
    ),
    title: Row(
      children: [
        const SizedBox(width: 4),
        Container(
          width: 40, height: 40,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: kCyan.withOpacity(0.3)),
            gradient: LinearGradient(
              colors: [kCyan.withOpacity(0.1), kPurple.withOpacity(0.1)],
            ),
          ),
          child: ClipOval(
            child: Image.asset(
              'assets/images/logo.png',
              width: 40,
              height: 40,
              fit: BoxFit.cover,
            ),
          ),
        ),
        const SizedBox(width: 10),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('ZENZO X EYE',
                style: TextStyle(
                  color: kWhite,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 2,
                )),
            Text(role.toUpperCase(),
                style: TextStyle(
                  color: _roleColor(role).withOpacity(0.7),
                  fontSize: 9,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1,
                )),
          ],
        ),
      ],
    ),
    actions: [
      GestureDetector(
        onTap: () => Navigator.push(
          context,
          _slideRoute(ProfilePage(
            username: username, password: password,
            role: role, expiredDate: expiredDate, sessionKey: sessionKey,
          )),
        ).then((_) {
          if (mounted && _newsPageCtrl.hasClients) {
            setState(() { _currentNewsPage = 0.0; _newsPageViewKey++; });
            _newsPageCtrl.jumpToPage(0);
          }
        }),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            color: kWhite.withOpacity(0.03),
          ),
          child: Row(
            children: [
              Text(username,
                  style: const TextStyle(
                      color: kWhite, fontSize: 13, fontWeight: FontWeight.bold)),
              const SizedBox(width: 6),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    color: Colors.red.withOpacity(0.15),
                    border: Border.all(color: Colors.red.withOpacity(0.3))),
                child: Text('$expiredDate',
                    style: const TextStyle(
                        color: Colors.red, fontSize: 9, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ),
      ),
      const SizedBox(width: 4),
      GestureDetector(
        onTap: () => Navigator.push(
          context,
          _slideRoute(ProfilePage(
            username: username, password: password,
            role: role, expiredDate: expiredDate, sessionKey: sessionKey,
          )),
        ),
        child: Container(
          width: 40, height: 40,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: kCyan.withOpacity(0.4), width: 2),
            gradient: LinearGradient(
              colors: [kCyan.withOpacity(0.2), kPurple.withOpacity(0.1)],
            ),
          ),
          child: ClipOval(
            child: _profileImage != null
                ? Image.file(_profileImage!, fit: BoxFit.cover)
                : Icon(FontAwesomeIcons.userAstronaut, 
                    color: kCyan.withOpacity(0.7), size: 20),
          ),
        ),
      ),
      const SizedBox(width: 4),
      GestureDetector(
        onTap: () => Navigator.push(context, _slideRoute(const ContactPage())),
        child: Container(
          padding: const EdgeInsets.all(8),
          margin: const EdgeInsets.only(right: 8),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: kWhite.withOpacity(0.03),
          ),
          child: const Icon(Icons.headset_mic_outlined, color: kWhite, size: 22),
        ),
      ),
      const SizedBox(width: 4),
    ],
  );
}

  Widget _buildBottomNav() {
    final items = [
      _NavItem(icon: FontAwesomeIcons.house, label: 'Home'),
      _NavItem(icon: FontAwesomeIcons.bolt, label: 'Bug'),
      _NavItem(icon: Icons.devices_rounded, label: 'Rat'),
      _NavItem(icon: Icons.info_outline_rounded, label: 'Info'),
      _NavItem(icon: Icons.build_circle_outlined, label: 'Tools'),
    ];

    return Container(
      margin: const EdgeInsets.fromLTRB(20, 0, 20, 16),
      decoration: BoxDecoration(
        color: const Color(0xFF1A2035),
        borderRadius: BorderRadius.circular(30),
        boxShadow: [
          BoxShadow(
            color: kCyan.withOpacity(0.1), 
            blurRadius: 20, 
            offset: const Offset(0, 8),
            spreadRadius: 2,
          ),
        ],
        border: Border.all(
          color: kCyan.withOpacity(0.1),
        ),
      ),
      child: SizedBox(
        height: 68,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: List.generate(items.length, (i) {
            final isActive = _navIndex == i;
            return GestureDetector(
              onTap: () => _onNavTap(i),
              child: SizedBox(
                width: 70,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: isActive 
                            ? kCyan.withOpacity(0.15) 
                            : Colors.transparent,
                      ),
                      child: Icon(items[i].icon,
                          color: isActive ? kCyan : kWhite54, 
                          size: 22),
                    ),
                    const SizedBox(height: 4),
                    Text(items[i].label,
                        style: TextStyle(
                          color: isActive ? kCyan : kWhite54,
                          fontSize: 9,
                          fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                          fontFamily: isActive ? 'Orbitron' : null,
                          letterSpacing: isActive ? 1 : 0,
                        )),
                    if (isActive)
                      Container(
                        width: 20, height: 2,
                        margin: const EdgeInsets.only(top: 4),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [kCyan, kPurple],
                          ),
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                  ],
                ),
              ),
            );
          }),
        ),
      ),
    );
  }

  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: kBg,
      width: MediaQuery.of(context).size.width * 0.82,
      child: Column(
        children: [
          Container(
            height: 250,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  const Color(0xFF0A0F1E),
                  const Color(0xFF1A1A2E),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: Stack(
              children: [
                if (_menuVideoCtrl != null && _menuVideoCtrl!.value.isInitialized)
                  SizedBox.expand(
                    child: FittedBox(
                      fit: BoxFit.cover,
                      child: SizedBox(
                        width: _menuVideoCtrl!.value.size.width,
                        height: _menuVideoCtrl!.value.size.height,
                        child: VideoPlayer(_menuVideoCtrl!),
                      ),
                    ),
                  ),
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter, 
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.black.withOpacity(0.2), 
                        Colors.black.withOpacity(0.85)
                      ],
                    ),
                  ),
                ),
                SafeArea(
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 90, height: 90,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: kCyan.withOpacity(0.4), width: 3),
                            boxShadow: [
                              BoxShadow(
                                color: kCyan.withOpacity(0.2), 
                                blurRadius: 20, 
                                spreadRadius: 4
                              )
                            ],
                          ),
                          child: ClipOval(
                            child: _profileImage != null
                                ? Image.file(_profileImage!, fit: BoxFit.cover)
                                : Icon(FontAwesomeIcons.userAstronaut, 
                                    size: 40, color: kWhite.withOpacity(0.8)),
                          ),
                        ),
                        const SizedBox(height: 14),
                        Text(username,
                            style: const TextStyle(
                                color: kWhite, 
                                fontSize: 18, 
                                fontWeight: FontWeight.bold, 
                                fontFamily: 'Orbitron',
                                letterSpacing: 1)),
                        const SizedBox(height: 4),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            color: kCyan.withOpacity(0.1),
                            border: Border.all(color: kCyan.withOpacity(0.3)),
                          ),
                          child: Text(role.toUpperCase(),
                              style: TextStyle(
                                color: _roleColor(role), 
                                fontSize: 11, 
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Orbitron',
                                letterSpacing: 2,
                              )),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Container(
              color: kBg,
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
                children: [
                  if (role == 'reseller')
                    _buildDrawerItem(
                        icon: Icons.storefront_rounded,
                        label: 'Seller Dashboard',
                        onTap: () => _onDrawerNav(1)),
                  if (role == 'admin')
                    _buildDrawerItem(
                        icon: Icons.admin_panel_settings_rounded,
                        label: 'Admin Panel',
                        onTap: () => _onDrawerNav(2)),
                   if (role == 'patner')
                    _buildDrawerItem(
                        icon: Icons.admin_panel_settings_rounded,
                        label: 'Partner Panel',
                        onTap: () => _onDrawerNav(3)),
                  if (role == 'owner')
                    _buildDrawerItem(
                        icon: Icons.workspace_premium_rounded,
                        label: 'Owner Panel',
                        onTap: () => _onDrawerNav(4)),
                    if (role == 'moderator')
                    _buildDrawerItem(
                        icon: Icons.workspace_premium_rounded,
                        label: 'Moderator Panel',
                        onTap: () => _onDrawerNav(5)),
                        if (role == 'staf')
                    _buildDrawerItem(
                        icon: Icons.workspace_premium_rounded,
                        label: 'Staff Panel',
                        onTap: () => _onDrawerNav(6)),
                  _buildDrawerItem(
                    icon: Icons.history_rounded,
                    label: 'Activity History',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                          context,
                          _slideRoute(RiwayatPage(sessionKey: sessionKey, role: role))).then((_) {
                        if (mounted && _newsPageCtrl.hasClients) {
                          setState(() { _currentNewsPage = 0.0; _newsPageViewKey++; });
                          _newsPageCtrl.jumpToPage(0);
                        }
                      });
                    },
                  ),
                  _buildDrawerItem(
                    icon: Icons.lock_outline_rounded,
                    label: 'Change Password',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        _slideRoute(ChangePasswordPage(username: username, sessionKey: sessionKey)),
                      );
                    },
                  ),
                  const SizedBox(height: 16),
                  _buildDrawerItem(
                    icon: Icons.logout_rounded,
                    label: 'Logout',
                    isLogout: true,
                    onTap: () async {
                      Navigator.pop(context);
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.clear();
                      if (!mounted) return;
                      Navigator.of(context).pushAndRemoveUntil(
                          MaterialPageRoute(builder: (_) => const LoginPage()), (_) => false);
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool isLogout = false,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 4),
      decoration: BoxDecoration(
        color: isLogout 
            ? Colors.red.withOpacity(0.06) 
            : kCard.withOpacity(0.5),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
            color: isLogout 
                ? Colors.red.withOpacity(0.2) 
                : kBorder.withOpacity(0.3)),
      ),
      child: ListTile(
        leading: Icon(icon, 
            color: isLogout ? Colors.redAccent : kCyan, 
            size: 20),
        title: Text(label,
            style: TextStyle(
                color: isLogout ? Colors.redAccent : kWhite,
                fontWeight: FontWeight.w600, 
                fontSize: 14,
                fontFamily: 'Orbitron',
                letterSpacing: 0.5)),
        trailing: isLogout 
            ? null 
            : Icon(Icons.arrow_forward_ios_rounded, 
                color: kWhite.withOpacity(0.2), 
                size: 14),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        onTap: onTap,
      ),
    );
  }
}

class _QuickActionData {
  final IconData icon;
  final IconData bgIcon;
  final String title;
  final String subtitle;
  final List<Color> gradient;
  final VoidCallback onTap;
  const _QuickActionData({
    required this.icon,
    required this.bgIcon,
    required this.title,
    required this.subtitle,
    required this.gradient,
    required this.onTap,
  });
}

class _NavItem {
  final IconData icon;
  final String label;
  const _NavItem({required this.icon, required this.label});
}

PageRoute _slideRoute(Widget page) => PageRouteBuilder(
  pageBuilder: (_, __, ___) => page,
  transitionDuration: const Duration(milliseconds: 400),
  transitionsBuilder: (_, anim, __, child) => SlideTransition(
    position: Tween<Offset>(begin: const Offset(1, 0), end: Offset.zero)
        .animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
    child: FadeTransition(opacity: anim, child: child),
  ),
);

class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});
  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _ctrl;
  bool _isVideo(String url) =>
      url.endsWith('.mp4') || url.endsWith('.webm') ||
      url.endsWith('.mov') || url.endsWith('.mkv');
  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _ctrl = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          if (mounted) setState(() {});
          _ctrl?.setLooping(true);
          _ctrl?.setVolume(0.0);
          _ctrl?.play();
        });
    }
  }
  @override
  void dispose() { _ctrl?.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_ctrl != null && _ctrl!.value.isInitialized) {
        return AspectRatio(aspectRatio: _ctrl!.value.aspectRatio, child: VideoPlayer(_ctrl!));
      }
      return const Center(child: CircularProgressIndicator(color: kCyan, strokeWidth: 2));
    }
    return Image.network(
      widget.url, fit: BoxFit.cover,
      errorBuilder: (_, __, ___) =>
          Container(color: kCard, child: const Icon(Icons.error_rounded, color: kWhite24)),
    );
  }
}