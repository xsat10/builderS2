import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'api_config.dart';

// ═══════════════════════════════════════════════════════════════════════════
// PARTNER PAGE — Tema "Rose Elegant"
// UI: Kartu lembut dengan gradasi rose-pink, sudut membulat besar,
// nuansa hangat & ramah untuk relasi partner/mitra.
// ═══════════════════════════════════════════════════════════════════════════

const String _apiBase = 'http://shinoa-cpanelpanel.xtxintax.my.id:2003';

class PartnerPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const PartnerPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<PartnerPage> createState() => _PartnerPageState();
}

class _PartnerPageState extends State<PartnerPage> {
  late String sessionKey;
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];

  final List<String> roleOptions = [
  'partner',
  'admin',
  'reseller',
  'tukang_bubur',
  'vip',
  'member',
];
  String selectedRole = 'member';

  int currentPage = 1;
  int itemsPerPage = 25;

  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  final deleteController = TextEditingController();
  final editUsernameController = TextEditingController();
  final editDayController = TextEditingController();

  String newUserRole = 'member';
  bool isLoading = false;

  // ── TEMA ROSE ELEGANT ──
  final Color bgDark = const Color(0xFF120A10);
  final Color primaryRose = const Color(0xFFEC4899);
  final Color accentPink = const Color(0xFFF9A8D4);
  final Color primaryWhite = Colors.white;
  final Color textGrey = Colors.grey.shade400;
  final Color cardDark = const Color(0xFF1C1017);
  final Color borderRose = const Color(0xFFEC4899).withOpacity(0.22);

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    _fetchUsers();
  }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse('$_apiBase/listUsers?key=$sessionKey'));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _alert("Info", data['message'] ?? 'Gagal memuat user.');
      }
    } catch (_) {
      _alert("Error", "Gagal terhubung ke server.");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList = fullUserList.where((u) => u['role'] == selectedRole).toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = (start + itemsPerPage);
    return filteredList.sublist(start, end > filteredList.length ? filteredList.length : end);
  }

  int get totalPages => (filteredList.length / itemsPerPage).ceil().clamp(1, 9999);

  Future<void> _deleteUser() async {
    final username = deleteController.text.trim();
    if (username.isEmpty) {
      _alert("Peringatan", "Masukkan username yang ingin dihapus.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse('$_apiBase/deleteUser?key=$sessionKey&username=$username'));
      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        _alert("Sukses", "User berhasil dihapus.");
        deleteController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal menghapus user.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _createAccount() async {
    final u = createUsernameController.text.trim();
    final p = createPasswordController.text.trim();
    final d = createDayController.text.trim();
    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final url = Uri.parse('$_apiBase/userAdd?key=$sessionKey&username=$u&password=$p&day=$d&role=$newUserRole');
      final res = await http.get(url);
      final data = jsonDecode(res.body);
      if (data['created'] == true) {
        _alert("Sukses", "Akun berhasil dibuat sebagai ${newUserRole.toUpperCase()}.");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        newUserRole = 'member';
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal membuat akun.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _editUser() async {
    final u = editUsernameController.text.trim();
    final d = editDayController.text.trim();
    if (u.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final url = Uri.parse('$_apiBase/editUser?key=$sessionKey&username=$u&addDays=$d');
      final res = await http.get(url);
      final data = jsonDecode(res.body);
      if (data['edited'] == true) {
        _alert("Sukses", "Durasi berhasil diperbarui.");
        editUsernameController.clear();
        editDayController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal mengubah durasi.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  void _alert(String title, String message) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: cardDark,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22), side: BorderSide(color: borderRose)),
        title: Row(children: [
          Icon(FontAwesomeIcons.handshake, color: accentPink, size: 18),
          const SizedBox(width: 10),
          Text(title, style: TextStyle(color: primaryWhite)),
        ]),
        content: Text(message, style: TextStyle(color: textGrey)),
        actions: [
          Center(
            child: Container(
              decoration: BoxDecoration(gradient: LinearGradient(colors: [primaryRose, accentPink]), borderRadius: BorderRadius.circular(14)),
              child: TextButton(onPressed: () => Navigator.pop(context), child: Text("OK", style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold))),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInput({required String label, required TextEditingController controller, required IconData icon, TextInputType type = TextInputType.text}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextField(
        controller: controller,
        keyboardType: type,
        style: TextStyle(color: primaryWhite),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: accentPink),
          prefixIcon: Icon(icon, color: accentPink, size: 18),
          filled: true,
          fillColor: Colors.white.withOpacity(0.035),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: BorderSide(color: borderRose)),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: BorderSide(color: borderRose)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: BorderSide(color: accentPink, width: 1.6)),
        ),
      ),
    );
  }

  // Kartu bersudut sangat membulat (pill-style), nuansa hangat
  Widget _buildSoftCard({required String title, required IconData icon, required List<Widget> children}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 22),
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: cardDark,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: borderRose),
        gradient: LinearGradient(
          begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: [primaryRose.withOpacity(0.07), Colors.transparent],
        ),
        boxShadow: [BoxShadow(color: primaryRose.withOpacity(0.08), blurRadius: 24, offset: const Offset(0, 10))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(11),
                decoration: BoxDecoration(gradient: LinearGradient(colors: [primaryRose, accentPink]), shape: BoxShape.circle),
                child: Icon(icon, color: primaryWhite, size: 17),
              ),
              const SizedBox(width: 12),
              Text(title, style: TextStyle(color: primaryWhite, fontSize: 15, fontWeight: FontWeight.bold, letterSpacing: 1)),
            ],
          ),
          const SizedBox(height: 20),
          ...children,
        ],
      ),
    );
  }

  Widget _buildUserItem(Map user) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(color: Colors.white.withOpacity(0.03), borderRadius: BorderRadius.circular(20), border: Border.all(color: borderRose)),
      child: Row(
        children: [
          Container(
            width: 38, height: 38,
            decoration: BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [primaryRose, accentPink])),
            child: const Icon(FontAwesomeIcons.userGroup, color: Colors.white, size: 15),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(user['username'] ?? '-', style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold, fontSize: 14)),
                const SizedBox(height: 3),
                Text("ROLE: ${(user['role'] ?? '-').toString().toUpperCase()} | EXP: ${user['expiredDate'] ?? '-'}", style: TextStyle(color: textGrey, fontSize: 11.5)),
              ],
            ),
          ),
          IconButton(
            icon: Icon(FontAwesomeIcons.trashCan, color: accentPink.withOpacity(0.85), size: 16),
            onPressed: () async {
              final confirm = await showDialog<bool>(
                context: context,
                builder: (_) => AlertDialog(
                  backgroundColor: cardDark,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: BorderSide(color: borderRose)),
                  title: Text("Konfirmasi", style: TextStyle(color: primaryWhite)),
                  content: Text("Hapus user ini?", style: TextStyle(color: textGrey)),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context, false), child: Text("Batal", style: TextStyle(color: textGrey))),
                    TextButton(onPressed: () => Navigator.pop(context, true), child: Text("Hapus", style: TextStyle(color: accentPink))),
                  ],
                ),
              );
              if (confirm == true) {
                deleteController.text = user['username'];
                _deleteUser();
              }
            },
          ),
        ],
      ),
    );
  }

  Widget _buildPagination() {
    return Wrap(
      spacing: 8, runSpacing: 8,
      children: List.generate(totalPages, (index) {
        final page = index + 1;
        final active = currentPage == page;
        return GestureDetector(
          onTap: () => setState(() => currentPage = page),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 9),
            decoration: BoxDecoration(
              gradient: active ? LinearGradient(colors: [primaryRose, accentPink]) : null,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: active ? Colors.transparent : borderRose),
            ),
            child: Text("$page", style: TextStyle(color: active ? Colors.white : textGrey, fontSize: 12)),
          ),
        );
      }),
    );
  }

  Widget _buildRoseButton({required String label, required IconData icon, required VoidCallback? onPressed}) {
    return Container(
      height: 52,
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [primaryRose, accentPink]),
        borderRadius: BorderRadius.circular(26),
        boxShadow: [BoxShadow(color: primaryRose.withOpacity(0.35), blurRadius: 18, offset: const Offset(0, 8))],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(26),
          onTap: onPressed,
          child: Center(
            child: isLoading
                ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [Icon(icon, size: 17, color: Colors.white), const SizedBox(width: 8), Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 1))],
                  ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter, end: Alignment.bottomCenter,
            colors: [bgDark, primaryRose.withOpacity(0.07), bgDark],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 20),
            child: Column(
              children: [
                Row(children: [
                  IconButton(icon: Icon(Icons.arrow_back_ios_new_rounded, color: accentPink, size: 18), onPressed: () => Navigator.pop(context)),
                ]),
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(colors: [primaryRose.withOpacity(0.35), accentPink.withOpacity(0.1)]),
                    boxShadow: [BoxShadow(color: primaryRose.withOpacity(0.35), blurRadius: 26, spreadRadius: 3)],
                  ),
                  child: const Icon(FontAwesomeIcons.handshake, color: Colors.white, size: 32),
                ),
                const SizedBox(height: 14),
                Text(
                  "PARTNER PANEL",
                  style: TextStyle(color: primaryWhite, fontSize: 22, fontWeight: FontWeight.w900, letterSpacing: 2, shadows: [Shadow(color: primaryRose.withOpacity(0.7), blurRadius: 14)]),
                ),
                const SizedBox(height: 4),
                Text("Kolaborasi & manajemen akun mitra", style: TextStyle(color: textGrey, fontSize: 12.5)),
                const SizedBox(height: 30),

                _buildSoftCard(
                  title: "DELETE USER",
                  icon: FontAwesomeIcons.userSlash,
                  children: [
                    _buildInput(label: "Username Target", controller: deleteController, icon: FontAwesomeIcons.user),
                    const SizedBox(height: 6),
                    _buildRoseButton(label: "DELETE ACCOUNT", icon: FontAwesomeIcons.trashCan, onPressed: isLoading ? null : _deleteUser),
                  ],
                ),

                _buildSoftCard(
                  title: "CREATE ACCOUNT",
                  icon: FontAwesomeIcons.userPlus,
                  children: [
                    _buildInput(label: "Username", controller: createUsernameController, icon: FontAwesomeIcons.user),
                    _buildInput(label: "Password", controller: createPasswordController, icon: FontAwesomeIcons.lock),
                    _buildInput(label: "Durasi (Hari)", controller: createDayController, icon: FontAwesomeIcons.calendarDay, type: TextInputType.number),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                      decoration: BoxDecoration(color: Colors.white.withOpacity(0.035), borderRadius: BorderRadius.circular(20), border: Border.all(color: borderRose)),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                          value: newUserRole,
                          dropdownColor: cardDark,
                          isExpanded: true,
                          style: TextStyle(color: primaryWhite),
                          items: roleOptions.map((role) => DropdownMenuItem(value: role, child: Text(role.toUpperCase()))).toList(),
                          onChanged: (val) => setState(() => newUserRole = val ?? 'member'),
                        ),
                      ),
                    ),
                    const SizedBox(height: 18),
                    _buildRoseButton(label: "CREATE ACCOUNT", icon: FontAwesomeIcons.userPlus, onPressed: isLoading ? null : _createAccount),
                  ],
                ),

                _buildSoftCard(
                  title: "EXTEND DURATION",
                  icon: FontAwesomeIcons.clock,
                  children: [
                    _buildInput(label: "Username Target", controller: editUsernameController, icon: FontAwesomeIcons.userPen),
                    _buildInput(label: "Tambah Hari", controller: editDayController, icon: FontAwesomeIcons.calendarPlus, type: TextInputType.number),
                    const SizedBox(height: 6),
                    _buildRoseButton(label: "ADD DAYS", icon: FontAwesomeIcons.calendarPlus, onPressed: isLoading ? null : _editUser),
                  ],
                ),

                _buildSoftCard(
                  title: "USER LIST",
                  icon: FontAwesomeIcons.users,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                      decoration: BoxDecoration(color: Colors.white.withOpacity(0.035), borderRadius: BorderRadius.circular(20), border: Border.all(color: borderRose)),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                          value: selectedRole,
                          dropdownColor: cardDark,
                          isExpanded: true,
                          style: TextStyle(color: primaryWhite),
                          items: roleOptions.map((role) => DropdownMenuItem(value: role, child: Text(role.toUpperCase()))).toList(),
                          onChanged: (val) {
                            if (val != null) {
                              selectedRole = val;
                              _filterAndPaginate();
                            }
                          },
                        ),
                      ),
                    ),
                    const SizedBox(height: 18),
                    isLoading
                        ? Padding(padding: const EdgeInsets.all(20), child: Center(child: CircularProgressIndicator(color: accentPink)))
                        : filteredList.isEmpty
                            ? Padding(padding: const EdgeInsets.symmetric(vertical: 30), child: Center(child: Text("Tidak ada user pada role ini", style: TextStyle(color: textGrey))))
                            : Column(children: [..._getCurrentPageData().map((u) => _buildUserItem(u)).toList(), const SizedBox(height: 16), _buildPagination()]),
                  ],
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
