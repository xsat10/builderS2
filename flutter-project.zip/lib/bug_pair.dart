import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'api_config.dart';

class SpamPairPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final String role;
  final String expiredDate;

  const SpamPairPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<SpamPairPage> createState() => _SpamPairPageState();
}

class _SpamPairPageState extends State<SpamPairPage> with TickerProviderStateMixin {
  late AnimationController _pulseController;
  late AnimationController _resultCtrl;
  late Animation<double> _resultFade;
  late Animation<Offset> _resultSlide;

  final targetController = TextEditingController();
  final jumlahController = TextEditingController(text: '10');

  bool _isSending = false;
  String? _responseMessage;
  int _progress = 0;
  int _totalRequest = 0;
  bool _showProgress = false;
  String _statusText = 'Siap mengirim spam...';
  
  List<Map<String, dynamic>> _terminalLogs = [];
  ScrollController _terminalScrollController = ScrollController();
  bool _isTerminalExpanded = true;

  final Color _primaryGold = const Color(0xFFFFD700);
  final Color _secondaryGreen = const Color(0xFF00FF88);
  final Color _textWhite = Colors.white;
  final Color _textGrey = const Color(0xFFB0B0B0);
  final Color _darkBg = const Color(0xFF0A0A0A);
  final Color _errorRed = const Color(0xFFFF4444);
  final Color _terminalBg = const Color(0xFF001100);

  @override
  void initState() {
    super.initState();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _resultCtrl = AnimationController(
      vsync: this, 
      duration: const Duration(milliseconds: 450)
    );
    _resultFade = CurvedAnimation(parent: _resultCtrl, curve: Curves.easeOut);
    _resultSlide = Tween<Offset>(begin: const Offset(0, 0.12), end: Offset.zero)
        .animate(CurvedAnimation(parent: _resultCtrl, curve: Curves.easeOutCubic));
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _resultCtrl.dispose();
    targetController.dispose();
    jumlahController.dispose();
    _terminalScrollController.dispose();
    super.dispose();
  }

  String? formatPhoneNumber(String input) {
    var cleaned = input.replaceAll(RegExp(r'\D'), '');
    if (cleaned.length < 8) return null;
    if (input.trim().startsWith('+')) {
      return cleaned;
    }
    return '+$cleaned';
  }

  void _setResponse(String type, String msg) {
    if (!mounted) return;
    setState(() => _responseMessage = '$type|$msg');
    _resultCtrl.forward(from: 0);
  }

  void _addTerminalLog(String message, {bool isSuccess = true, bool isError = false, bool isInfo = false}) {
    setState(() {
      _terminalLogs.add({
        'time': DateTime.now().toString().substring(11, 19),
        'message': message,
        'isSuccess': isSuccess,
        'isError': isError,
        'isInfo': isInfo,
      });
      if (_terminalLogs.length > 200) {
        _terminalLogs.removeAt(0);
      }
    });
    // Scroll ke bawah
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_terminalScrollController.hasClients) {
        _terminalScrollController.animateTo(
          _terminalScrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: AlertDialog(
          backgroundColor: Colors.white.withOpacity(0.08),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
            side: BorderSide(color: _primaryGold.withOpacity(0.4), width: 1.5),
          ),
          title: Text(
            title,
            style: TextStyle(
              color: _primaryGold,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.bold,
            ),
          ),
          content: Text(
            msg, 
            style: TextStyle(color: _textGrey, fontFamily: 'Orbitron'),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(
                "OK",
                style: TextStyle(
                  color: _primaryGold,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _sendSpam() async {
    final rawInput = targetController.text.trim();
    final jumlahInput = jumlahController.text.trim();
    final key = widget.sessionKey;

    final formattedNumber = formatPhoneNumber(rawInput);
    if (formattedNumber == null) {
      _showAlert("❌ Nomor Tidak Valid",
          "Gunakan format internasional.\nContoh: +62812xxxxxxxx");
      return;
    }

    int requestCount = int.tryParse(jumlahInput) ?? 10;
    if (requestCount < 10) {
      _showAlert("❌ Jumlah Tidak Valid", "Minimal 10 kali spam.");
      return;
    }
    if (requestCount > 100) {
      _showAlert("❌ Terlalu Banyak", "Maksimal 100 kali spam per sesi.");
      return;
    }

    setState(() {
      _terminalLogs.clear();
      _isSending = true;
      _responseMessage = null;
      _progress = 0;
      _totalRequest = requestCount;
      _showProgress = true;
      _statusText = '⏳ Mengirim spam...';
    });
    _resultCtrl.reset();
    _addTerminalLog('═══════════════════════════════════════════', isInfo: true);
    _addTerminalLog('🚀 MEMULAI SPAM PAIRING', isInfo: true);
    _addTerminalLog('📱 Target: $rawInput', isInfo: true);
    _addTerminalLog('📨 Total: $requestCount kali', isInfo: true);
    _addTerminalLog('═══════════════════════════════════════════', isInfo: true);

    int successCount = 0;
    int failedCount = 0;

    try {
      final url = Uri.parse(
        '$baseUrl/spamPair?key=$key&number=$formattedNumber&count=$requestCount'
      );
      
      _addTerminalLog('📡 Menghubungi server...', isInfo: true);
      
      final response = await http.get(url).timeout(
        const Duration(seconds: 120),
      );

      final data = jsonDecode(response.body);

      if (data['valid'] == false) {
        _setResponse('error', 'Session key tidak valid. Silakan login ulang.');
        setState(() => _statusText = '❌ Gagal mengirim spam');
        _addTerminalLog('❌ Session key tidak valid', isError: true);
      } else if (data['cooldown'] == true) {
        final wait = data['wait'] ?? 0;
        _setResponse('warning', 'Cooldown aktif! Tunggu $wait detik lagi.');
        setState(() => _statusText = '⏳ Cooldown $wait detik');
        _addTerminalLog('⏳ Cooldown $wait detik', isError: true);
      } else if (data['success'] == true) {
        successCount = data['success_count'] ?? requestCount;
        failedCount = data['failed_count'] ?? 0;
        
        for (int i = 1; i <= successCount; i++) {
          _addTerminalLog('✅ [$i/$requestCount] Berhasil mengirim ke $rawInput', isSuccess: true);
        }
        for (int i = 1; i <= failedCount; i++) {
          _addTerminalLog('❌ Gagal mengirim ke $rawInput', isError: true);
        }

        setState(() {
          _progress = successCount + failedCount;
          _statusText = '✅ Spam selesai!';
        });

        _addTerminalLog('═══════════════════════════════════════════', isInfo: true);
        _addTerminalLog('✅ SELESAI!', isInfo: true);
        _addTerminalLog('📨 Berhasil: $successCount kali', isSuccess: true);
        _addTerminalLog('❌ Gagal: $failedCount kali', isError: true);
        _addTerminalLog('═══════════════════════════════════════════', isInfo: true);

        _setResponse('success', 
          '✅ Spam Pairing berhasil!\n'
          '📱 Target: $rawInput\n'
          '📨 Berhasil: $successCount kali\n'
          '❌ Gagal: $failedCount kali'
        );
        targetController.clear();
      } else {
        _setResponse('error', data['message'] ?? 'Gagal mengirim spam. Server error.');
        setState(() => _statusText = '❌ Gagal mengirim spam');
        _addTerminalLog('❌ ${data['message'] ?? 'Server error'}', isError: true);
      }
    } on Exception catch (e) {
      if (e.toString().contains('TimeoutException')) {
        _setResponse('error', 'Request timeout. Periksa koneksi internet.');
        _addTerminalLog('❌ Timeout - Periksa koneksi', isError: true);
      } else {
        _setResponse('error', 'Koneksi error. Periksa jaringan dan coba lagi.');
        _addTerminalLog('❌ Error: ${e.toString()}', isError: true);
      }
      setState(() => _statusText = '❌ Error koneksi');
    } finally {
      if (mounted) {
        setState(() {
          _isSending = false;
          _showProgress = false;
        });
      }
    }
  }

  Widget _glassCard({
    required Widget child,
    EdgeInsets padding = const EdgeInsets.all(16),
    BorderRadius? borderRadius,
    Color? borderColor,
    double blurSigma = 12,
    Color? bgColor,
  }) {
    return ClipRRect(
      borderRadius: borderRadius ?? BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: blurSigma, sigmaY: blurSigma),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: bgColor ?? Colors.white.withOpacity(0.07),
            borderRadius: borderRadius ?? BorderRadius.circular(20),
            border: Border.all(
              color: borderColor ?? Colors.white.withOpacity(0.15),
              width: 1.2,
            ),
          ),
          child: child,
        ),
      ),
    );
  }

  Widget _buildTopAppBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _primaryGold.withOpacity(0.2),
              border: Border.all(color: _primaryGold, width: 1.5),
            ),
            child: Icon(
              FontAwesomeIcons.bolt,
              color: _primaryGold,
              size: 18,
            ),
          ),
          const SizedBox(width: 10),
          Text(
            'SPAM PAIR',
            style: TextStyle(
              color: _textWhite,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.w900,
              fontSize: 18,
              letterSpacing: 2,
            ),
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _primaryGold, width: 1.5),
              color: Colors.transparent,
            ),
            child: Text(
              'V2.0',
              style: TextStyle(
                color: _primaryGold,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold,
                fontSize: 12,
                letterSpacing: 1,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return _glassCard(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: _primaryGold, width: 2.5),
              gradient: const LinearGradient(
                colors: [Color(0xFFFFD700), Color(0xFFFF8C00)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: ClipOval(
              child: Container(
                color: Colors.transparent,
                child: Icon(
                  Icons.person,
                  color: Colors.black87,
                  size: 28,
                ),
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.username.toUpperCase(),
                  style: const TextStyle(
                    color: Colors.white,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.w900,
                    fontSize: 16,
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Container(
                      width: 8,
                      height: 8,
                      decoration: const BoxDecoration(
                        color: Color(0xFF00FF88),
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      widget.role.toUpperCase(),
                      style: TextStyle(
                        color: _primaryGold,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                        letterSpacing: 2,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.4),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.white.withOpacity(0.15)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.access_time_rounded, color: _textGrey, size: 13),
                const SizedBox(width: 5),
                Text(
                  widget.expiredDate,
                  style: TextStyle(
                    color: _textWhite,
                    fontFamily: 'Orbitron',
                    fontSize: 10,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInputPanel() {
    return _glassCard(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Target Number
          Row(
            children: [
              Icon(Icons.phone_android_rounded, color: _primaryGold, size: 18),
              const SizedBox(width: 8),
              Text(
                'NOMOR TARGET',
                style: TextStyle(
                  color: _textWhite,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                  letterSpacing: 2,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(14),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.3),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: Colors.white.withOpacity(0.12), width: 1),
                ),
                child: TextField(
                  controller: targetController,
                  style: TextStyle(
                    color: _textWhite, 
                    fontFamily: 'Orbitron', 
                    fontSize: 15
                  ),
                  cursorColor: _primaryGold,
                  keyboardType: TextInputType.phone,
                  decoration: InputDecoration(
                    hintText: 'Contoh: +62812xxxxxxxx',
                    hintStyle: TextStyle(
                      color: _textGrey.withOpacity(0.5), 
                      fontFamily: 'Orbitron'
                    ),
                    prefixIcon: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 14),
                      child: Icon(
                        Icons.language_rounded, 
                        color: _textGrey, 
                        size: 20
                      ),
                    ),
                    prefixIconConstraints: const BoxConstraints(minWidth: 50, minHeight: 50),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Jumlah Spam
          Row(
            children: [
              Icon(Icons.repeat_rounded, color: _primaryGold, size: 18),
              const SizedBox(width: 8),
              Text(
                'JUMLAH SPAM',
                style: TextStyle(
                  color: _textWhite,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                  letterSpacing: 2,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(14),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.3),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: Colors.white.withOpacity(0.12), width: 1),
                ),
                child: Row(
                  children: [
                    IconButton(
                      onPressed: () {
                        int current = int.tryParse(jumlahController.text) ?? 10;
                        if (current > 1) {
                          jumlahController.text = (current - 1).toString();
                        }
                      },
                      icon: Icon(Icons.remove_circle_outline, color: _primaryGold),
                    ),
                    Expanded(
                      child: TextField(
                        controller: jumlahController,
                        style: TextStyle(
                          color: _textWhite, 
                          fontFamily: 'Orbitron', 
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                        cursorColor: _primaryGold,
                        keyboardType: TextInputType.number,
                        textAlign: TextAlign.center,
                        decoration: const InputDecoration(
                          border: InputBorder.none,
                          contentPadding: EdgeInsets.symmetric(vertical: 12),
                        ),
                      ),
                    ),
                    IconButton(
                      onPressed: () {
                        int current = int.tryParse(jumlahController.text) ?? 10;
                        if (current < 100) {
                          jumlahController.text = (current + 1).toString();
                        }
                      },
                      icon: Icon(Icons.add_circle_outline, color: _primaryGold),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildQuickAmount(1),
              _buildQuickAmount(5),
              _buildQuickAmount(10),
              _buildQuickAmount(25),
              _buildQuickAmount(50),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildQuickAmount(int amount) {
    return GestureDetector(
      onTap: () => jumlahController.text = amount.toString(),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.3),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: jumlahController.text == amount.toString() 
              ? _primaryGold 
              : Colors.white.withOpacity(0.1),
          ),
        ),
        child: Text(
          amount.toString(),
          style: TextStyle(
            color: jumlahController.text == amount.toString() 
              ? _primaryGold 
              : _textGrey,
            fontFamily: 'Orbitron',
            fontSize: 12,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  Widget _buildStatusPanel() {
    return _glassCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.info_outline_rounded, color: _primaryGold, size: 18),
              const SizedBox(width: 8),
              Text(
                'STATUS',
                style: TextStyle(
                  color: _textWhite,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                  letterSpacing: 2,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.3),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.white.withOpacity(0.08)),
            ),
            child: Row(
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: _isSending ? Colors.amber : _secondaryGreen,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    _statusText,
                    style: TextStyle(
                      color: _textWhite,
                      fontFamily: 'Orbitron',
                      fontSize: 12,
                    ),
                  ),
                ),
                if (_showProgress)
                  SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      valueColor: AlwaysStoppedAnimation<Color>(_primaryGold),
                    ),
                  ),
              ],
            ),
          ),
          // Progress bar
          if (_totalRequest > 0)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Column(
                children: [
                  LinearProgressIndicator(
                    value: _progress / _totalRequest,
                    backgroundColor: Colors.white.withOpacity(0.1),
                    valueColor: AlwaysStoppedAnimation<Color>(_primaryGold),
                    minHeight: 4,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '$_progress / $_totalRequest',
                    style: TextStyle(
                      color: _textGrey,
                      fontFamily: 'Orbitron',
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (context, child) {
        return Container(
          height: 62,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            gradient: const LinearGradient(
              colors: [Color(0xFFFFD700), Color(0xFFFF8C00)],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
            boxShadow: [
              BoxShadow(
                color: _primaryGold.withOpacity(0.25 + _pulseController.value * 0.35),
                blurRadius: 24 + _pulseController.value * 12,
                spreadRadius: 1,
              ),
            ],
          ),
          child: ElevatedButton(
            onPressed: _isSending ? null : _sendSpam,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.transparent,
              shadowColor: Colors.transparent,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18)
              ),
              elevation: 0,
            ),
            child: _isSending
              ? const SizedBox(
                  width: 26,
                  height: 26,
                  child: CircularProgressIndicator(
                    color: Colors.black87, 
                    strokeWidth: 3
                  ),
                )
              : Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      FontAwesomeIcons.bolt,
                      color: Colors.black87, 
                      size: 20,
                    ),
                    const SizedBox(width: 10),
                    const Text(
                      'SPAM PAIR',
                      style: TextStyle(
                        color: Colors.black87,
                        fontWeight: FontWeight.w900,
                        fontSize: 16,
                        fontFamily: 'Orbitron',
                        letterSpacing: 2,
                      ),
                    ),
                  ],
                ),
          ),
        );
      },
    );
  }

  Widget _buildResponseMessage() {
    if (_responseMessage == null) return const SizedBox.shrink();

    final parts = _responseMessage!.split('|');
    final type = parts[0];
    final msg = parts.length > 1 ? parts[1] : '';

    Color color;
    IconData icon;
    String title;
    switch (type) {
      case 'success':
        color = _secondaryGreen;
        icon = Icons.check_circle_outline;
        title = 'Berhasil';
        break;
      case 'warning':
        color = Colors.amber;
        icon = Icons.warning_rounded;
        title = 'Peringatan';
        break;
      default:
        color = _errorRed;
        icon = Icons.error_outline;
        title = 'Gagal';
    }

    return FadeTransition(
      opacity: _resultFade,
      child: SlideTransition(
        position: _resultSlide,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(14),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
            child: Container(
              margin: const EdgeInsets.only(top: 12),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: color.withOpacity(0.4)),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: color.withOpacity(0.12)
                    ),
                    child: Icon(icon, color: color, size: 18),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title,
                          style: TextStyle(
                            color: color,
                            fontFamily: 'Orbitron',
                            fontSize: 13,
                            fontWeight: FontWeight.bold
                          ),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          msg,
                          style: TextStyle(
                            color: _textGrey,
                            fontFamily: 'Orbitron',
                            fontSize: 12,
                            height: 1.4,
                          ),
                        ),
                      ],
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      setState(() => _responseMessage = null);
                      _resultCtrl.reset();
                    },
                    child: Icon(
                      Icons.close_rounded, 
                      color: _textGrey, 
                      size: 16
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ─── Terminal Log ─────────────────────────────────────────────────────────
  Widget _buildTerminal() {
    return _glassCard(
      padding: const EdgeInsets.all(12),
      borderRadius: BorderRadius.circular(16),
      borderColor: _primaryGold.withOpacity(0.3),
      bgColor: _terminalBg.withOpacity(0.9),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Terminal Header
          GestureDetector(
            onTap: () => setState(() => _isTerminalExpanded = !_isTerminalExpanded),
            child: Row(
              children: [
                Container(
                  width: 10,
                  height: 10,
                  decoration: const BoxDecoration(
                    color: Color(0xFFFF4444),
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 6),
                Container(
                  width: 10,
                  height: 10,
                  decoration: const BoxDecoration(
                    color: Color(0xFFFFD700),
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 6),
                Container(
                  width: 10,
                  height: 10,
                  decoration: const BoxDecoration(
                    color: Color(0xFF00FF88),
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 10),
                Text(
                  'TERMINAL LOG',
                  style: TextStyle(
                    color: _primaryGold,
                    fontFamily: 'Orbitron',
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1,
                  ),
                ),
                const Spacer(),
                Text(
                  _terminalLogs.length.toString(),
                  style: TextStyle(
                    color: _textGrey,
                    fontFamily: 'Orbitron',
                    fontSize: 10,
                  ),
                ),
                const SizedBox(width: 8),
                Icon(
                  _isTerminalExpanded 
                    ? Icons.keyboard_arrow_down_rounded 
                    : Icons.keyboard_arrow_up_rounded,
                  color: _textGrey,
                  size: 20,
                ),
              ],
            ),
          ),
          if (_isTerminalExpanded) ...[
            const Divider(color: Colors.white10, height: 12),
            // Terminal Content
            Container(
              height: 200,
              child: ListView.builder(
                controller: _terminalScrollController,
                itemCount: _terminalLogs.length,
                itemBuilder: (context, index) {
                  final log = _terminalLogs[index];
                  Color textColor;
                  if (log['isError'] == true) {
                    textColor = _errorRed;
                  } else if (log['isSuccess'] == true) {
                    textColor = _secondaryGreen;
                  } else if (log['isInfo'] == true) {
                    textColor = _primaryGold;
                  } else {
                    textColor = _textGrey;
                  }
                  
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 1.5),
                    child: Row(
                      children: [
                        Text(
                          '[${log['time']}]',
                          style: TextStyle(
                            color: _textGrey.withOpacity(0.5),
                            fontFamily: 'Orbitron',
                            fontSize: 9,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            log['message'],
                            style: TextStyle(
                              color: textColor,
                              fontFamily: 'Orbitron',
                              fontSize: 10,
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
            // Terminal Actions
            if (_terminalLogs.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    GestureDetector(
                      onTap: () {
                        setState(() => _terminalLogs.clear());
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.05),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: Colors.white.withOpacity(0.1)),
                        ),
                        child: Text(
                          'CLEAR',
                          style: TextStyle(
                            color: _textGrey,
                            fontFamily: 'Orbitron',
                            fontSize: 9,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ],
      ),
    );
  }

  // ─── Build ────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              const Color(0xFF1A0A00),
              const Color(0xFF0A0A0A),
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildTopAppBar(),
              Container(height: 1, color: Colors.white.withOpacity(0.08)),
              Expanded(
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      _buildHeader(),
                      const SizedBox(height: 14),
                      _buildInputPanel(),
                      const SizedBox(height: 14),
                      _buildStatusPanel(),
                      const SizedBox(height: 14),
                      _buildSendButton(),
                      _buildResponseMessage(),
                      const SizedBox(height: 14),
                      _buildTerminal(),
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}