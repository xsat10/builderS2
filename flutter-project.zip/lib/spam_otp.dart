import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'api_config.dart';

class SpamOtpPage extends StatefulWidget {
  @override
  _SpamOtpPageState createState() => _SpamOtpPageState();
}

class _SpamOtpPageState extends State<SpamOtpPage> with SingleTickerProviderStateMixin {
  final TextEditingController _numberController = TextEditingController();
  bool _isRunning = false;
  int _successCount = 0;
  int _failCount = 0;
  Timer? _timer;
  List<Map<String, dynamic>> _logs = [];
  late AnimationController _animationController;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 1500),
    )..repeat(reverse: true);
    
    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.1).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );
  }

  Future<void> _sendOtp(String number) async {
    final timestamp = DateTime.now();
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api/spam-otp'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'number': number}),
      );

      if (response.statusCode == 200) {
        setState(() {
          _successCount++;
          _logs.insert(0, {
            'message': 'OTP berhasil dikirim',
            'time': timestamp,
            'type': 'success',
          });
          if (_logs.length > 100) _logs.removeLast();
        });
      } else {
        setState(() {
          _failCount++;
          _logs.insert(0, {
            'message': 'Gagal: ${response.body}',
            'time': timestamp,
            'type': 'error',
          });
          if (_logs.length > 100) _logs.removeLast();
        });
      }
    } catch (e) {
      setState(() {
        _failCount++;
        _logs.insert(0, {
          'message': 'Error: $e',
          'time': timestamp,
          'type': 'error',
        });
        if (_logs.length > 100) _logs.removeLast();
      });
    }
  }

  void _startSpam() {
    final number = _numberController.text.trim();
    if (number.isEmpty) {
      _showCustomSnackbar('Nomor target wajib diisi', isError: true);
      return;
    }

    setState(() {
      _isRunning = true;
      _successCount = 0;
      _failCount = 0;
      _logs.clear();
    });

    _timer = Timer.periodic(Duration(seconds: 2), (timer) {
      _sendOtp(number);
    });
  }

  void _stopSpam() {
    _timer?.cancel();
    _animationController.stop();
    setState(() {
      _isRunning = false;
    });
  }

  void _showCustomSnackbar(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              isError ? Icons.error_outline : Icons.check_circle_outline,
              color: Colors.white,
            ),
            SizedBox(width: 12),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: isError ? Colors.red.shade800 : Colors.green.shade800,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        duration: Duration(seconds: 2),
      ),
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    _numberController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        primaryColor: Colors.blue.shade700,
        scaffoldBackgroundColor: Color(0xFF0A0E1A),
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.transparent,
          elevation: 0,
          titleTextStyle: TextStyle(
            color: Colors.white,
            fontSize: 24,
            fontWeight: FontWeight.bold,
            letterSpacing: 1.2,
          ),
          centerTitle: true,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            padding: EdgeInsets.symmetric(horizontal: 32, vertical: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            elevation: 0,
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Color(0xFF1A2040),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide(color: Colors.blue.shade700.withOpacity(0.3)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide(color: Colors.blue.shade700, width: 2),
          ),
          labelStyle: TextStyle(color: Colors.white70, fontSize: 16),
          prefixIconColor: Colors.blue.shade700,
        ),
        cardTheme: CardThemeData(
          color: Color(0xFF121828),
          shape: RoundedRectangleBorder(
           borderRadius: BorderRadius.circular(20),
           ),
           elevation: 8,
           shadowColor: Colors.blue.shade700.withOpacity(0.2),
         ),
      ),
      home: Scaffold(
        appBar: AppBar(
          title: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.security, color: Colors.blue.shade400, size: 28),
              SizedBox(width: 12),
              Text('SPAM OTP'),
            ],
          ),
          bottom: PreferredSize(
            preferredSize: Size.fromHeight(1),
            child: Container(
              height: 1,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.transparent, Colors.blue.shade700, Colors.transparent],
                ),
              ),
            ),
          ),
        ),
        body: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            children: [
              // Card untuk input dan kontrol
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(24.0),
                  child: Column(
                    children: [
                      TextField(
                        controller: _numberController,
                        decoration: InputDecoration(
                          labelText: 'Nomor Target',
                          hintText: 'Contoh: 08123456789',
                          prefixIcon: Icon(Icons.phone_android, color: Colors.blue.shade400),
                          suffixIcon: _numberController.text.isNotEmpty
                              ? IconButton(
                                  icon: Icon(Icons.clear, color: Colors.white54),
                                  onPressed: () => _numberController.clear(),
                                )
                              : null,
                        ),
                        style: TextStyle(color: Colors.white, fontSize: 16),
                        keyboardType: TextInputType.phone,
                      ),
                      SizedBox(height: 20),
                      Row(
                        children: [
                          Expanded(
                            child: AnimatedBuilder(
                              animation: _pulseAnimation,
                              builder: (context, child) {
                                return Transform.scale(
                                  scale: _isRunning ? _pulseAnimation.value : 1.0,
                                  child: ElevatedButton(
                                    onPressed: _isRunning ? null : _startSpam,
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: _isRunning 
                                          ? Colors.grey.shade700 
                                          : Colors.blue.shade700,
                                      minimumSize: Size(double.infinity, 56),
                                      foregroundColor: Colors.white,
                                    ),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Icon(_isRunning ? Icons.play_circle_outline : Icons.play_arrow),
                                        SizedBox(width: 12),
                                        Text(
                                          _isRunning ? 'PROSES' : 'START',
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            letterSpacing: 1.5,
                                            fontSize: 16,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                          SizedBox(width: 16),
                          Expanded(
                            child: ElevatedButton(
                              onPressed: _isRunning ? _stopSpam : null,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: _isRunning ? Colors.red.shade700 : Colors.grey.shade700,
                                minimumSize: Size(double.infinity, 56),
                                foregroundColor: Colors.white,
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(_isRunning ? Icons.stop : Icons.stop_circle_outlined),
                                  SizedBox(width: 12),
                                  Text(
                                    _isRunning ? 'STOP' : 'STOP',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 1.5,
                                      fontSize: 16,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              
              SizedBox(height: 16),
              
              // Statistik
              Row(
                children: [
                  _buildStatCard(
                    'Berhasil',
                    _successCount.toString(),
                    Icons.check_circle,
                    Colors.green.shade400,
                    Colors.green.shade900,
                  ),
                  SizedBox(width: 12),
                  _buildStatCard(
                    'Gagal',
                    _failCount.toString(),
                    Icons.error,
                    Colors.red.shade400,
                    Colors.red.shade900,
                  ),
                  SizedBox(width: 12),
                  _buildStatCard(
                    'Total',
                    (_successCount + _failCount).toString(),
                    Icons.track_changes,
                    Colors.blue.shade400,
                    Colors.blue.shade900,
                  ),
                ],
              ),
              
              SizedBox(height: 16),
              
              // Log
              Expanded(
                child: Card(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                Icon(Icons.terminal, color: Colors.blue.shade400, size: 20),
                                SizedBox(width: 8),
                                Text(
                                  'LOG AKTIVITAS',
                                  style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white70,
                                    letterSpacing: 1.2,
                                  ),
                                ),
                              ],
                            ),
                            if (_logs.isNotEmpty)
                              TextButton.icon(
                                onPressed: () {
                                  setState(() => _logs.clear());
                                },
                                icon: Icon(Icons.delete_outline, size: 18),
                                label: Text('Hapus'),
                                style: TextButton.styleFrom(
                                  foregroundColor: Colors.white54,
                                ),
                              ),
                          ],
                        ),
                      ),
                      Divider(height: 1, color: Colors.grey.shade800),
                      Expanded(
                        child: _logs.isEmpty
                            ? Center(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(
                                      Icons.inbox,
                                      size: 48,
                                      color: Colors.white24,
                                    ),
                                    SizedBox(height: 12),
                                    Text(
                                      'Belum ada aktivitas',
                                      style: TextStyle(color: Colors.white24),
                                    ),
                                  ],
                                ),
                              )
                            : ListView.builder(
                                reverse: true,
                                padding: EdgeInsets.symmetric(vertical: 4),
                                itemCount: _logs.length,
                                itemBuilder: (context, index) {
                                  final log = _logs[index];
                                  final isSuccess = log['type'] == 'success';
                                  final time = log['time'] as DateTime;
                                  
                                  return Container(
                                    margin: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                                    padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                                    decoration: BoxDecoration(
                                      color: isSuccess 
                                          ? Colors.green.shade900.withOpacity(0.2) 
                                          : Colors.red.shade900.withOpacity(0.2),
                                      borderRadius: BorderRadius.circular(12),
                                      border: Border.all(
                                        color: isSuccess 
                                            ? Colors.green.shade700.withOpacity(0.3) 
                                            : Colors.red.shade700.withOpacity(0.3),
                                        width: 1,
                                      ),
                                    ),
                                    child: Row(
                                      children: [
                                        Icon(
                                          isSuccess ? Icons.check_circle : Icons.error_outline,
                                          color: isSuccess ? Colors.green.shade400 : Colors.red.shade400,
                                          size: 18,
                                        ),
                                        SizedBox(width: 12),
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                log['message'],
                                                style: TextStyle(
                                                  color: isSuccess ? Colors.green.shade300 : Colors.red.shade300,
                                                  fontSize: 13,
                                                ),
                                              ),
                                              Text(
                                                '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}:${time.second.toString().padLeft(2, '0')}',
                                                style: TextStyle(
                                                  color: Colors.white38,
                                                  fontSize: 10,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                },
                              ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatCard(String label, String value, IconData icon, Color color, Color bgColor) {
    return Expanded(
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: bgColor.withOpacity(0.2),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withOpacity(0.3), width: 1),
        ),
        child: Column(
          children: [
            Icon(icon, color: color, size: 20),
            SizedBox(height: 4),
            Text(
              value,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
            Text(
              label,
              style: TextStyle(
                fontSize: 10,
                color: Colors.white54,
                letterSpacing: 0.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}