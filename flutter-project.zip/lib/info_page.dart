// ============================================================
// 📖 X-SPYDER PROJECT — INFO / GUIDE PAGE
// Red Crimson Edition • Modern • Smooth • Responsive
// File: info_page.dart
// ============================================================

import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'api_config.dart';

// ============================================================
// 🔴 RED CRIMSON PALETTE
// ============================================================

class _MC {
  static const red = Color(0xFFEF4444);
  static const redDark = Color(0xFFB91C1C);
  static const redDeep = Color(0xFF7F1D1D);
  static const redLight = Color(0xFFFCA5A5);
  static const redSoft = Color(0xFFFEF2F2);

  static const crimson = Color(0xFFDC2626);
  static const rose = Color(0xFFE11D48);

  static const white = Color(0xFFFFFFFF);
  static const bg = Color(0xFFFBF7F7);

  static const textDark = Color(0xFF1F1313);
  static const textGrey = Color(0xFF756464);
  static const textLight = Color(0xFFA59494);

  static const green = Color(0xFF22C55E);
  static const greenDark = Color(0xFF15803D);

  static const orange = Color(0xFFF97316);
  static const amber = Color(0xFFF59E0B);
  static const blue = Color(0xFF3B82F6);
  static const pink = Color(0xFFEC4899);
  static const cyan = Color(0xFF06B6D4);
}

// ============================================================
// 🎭 ROLE HELPERS
// ============================================================

Color _roleColor(String role) {
  switch (role.toLowerCase().trim()) {
    case 'owner_utama':
      return const Color(0xFFDC2626);

    case 'owner':
      return const Color(0xFFF59E0B);

    case 'staff':
      return const Color(0xFFEF4444);

    case 'executorius':
      return const Color(0xFFF97316);

    case 'forius_utama':
      return const Color(0xFFFF8F00);

    case 'moderator':
      return const Color(0xFFE11D48);

    case 'ceo_utama':
      return const Color(0xFF6366F1);

    case 'tangan_kanan':
      return const Color(0xFF06B6D4);

    case 'tangan_kiri':
      return const Color(0xFF22D3EE);

    case 'developers':
      return const Color(0xFF38BDF8);

    case 'partner_pribadi':
      return const Color(0xFF22C55E);

    case 'partner':
      return const Color(0xFF16A34A);

    case 'admin':
      return const Color(0xFF14B8A6);

    case 'tukang_bubur':
      return const Color(0xFFFBBF24);

    case 'reseller':
      return const Color(0xFF84CC16);

    case 'vip':
      return const Color(0xFFFACC15);

    default:
      return const Color(0xFF94A3B8);
  }
}

int _roleLevel(String role) {
  switch (role.toLowerCase().trim()) {
    case 'member':
      return 1;

    case 'vip':
      return 2;

    case 'reseller':
    case 'tukang_bubur':
      return 3;

    case 'admin':
    case 'partner':
    case 'partner_pribadi':
      return 4;

    case 'tangan_kiri':
    case 'tangan_kanan':
    case 'developers':
    case 'ceo_utama':
    case 'moderator':
      return 5;

    case 'forius_utama':
    case 'executorius':
    case 'staff':
      return 6;

    case 'owner':
      return 7;

    case 'owner_utama':
      return 8;

    default:
      return 1;
  }
}

bool _isVerifiedRole(String role) {
  const verified = [
    'executorius',
    'forius_utama',
    'staff',
    'owner',
    'owner_utama',
    'moderator',
    'ceo_utama',
  ];

  return verified.contains(role.toLowerCase().trim());
}

String _roleName(String role) {
  if (role.trim().isEmpty) return 'Member';

  return role
      .replaceAll('_', ' ')
      .split(' ')
      .map(
        (word) => word.isEmpty
            ? word
            : '${word[0].toUpperCase()}${word.substring(1).toLowerCase()}',
      )
      .join(' ');
}

// ============================================================
// 📚 GUIDE DATA
// ============================================================

enum _GuideCategory {
  all,
  gettingStarted,
  account,
  tools,
  transaction,
  chat,
  security,
  troubleshooting,
  rules,
}

class _GuideItem {
  final String title;
  final String description;
  final String detail;
  final IconData icon;
  final Color color;
  final _GuideCategory category;
  final List<String> points;

  const _GuideItem({
    required this.title,
    required this.description,
    required this.detail,
    required this.icon,
    required this.color,
    required this.category,
    this.points = const [],
  });
}

const List<_GuideItem> _guides = [
  // ==========================================================
  // GETTING STARTED
  // ==========================================================

  _GuideItem(
    title: 'Cara Memulai APK',
    description: 'Panduan awal setelah berhasil masuk ke aplikasi.',
    detail:
        'Setelah login berhasil, pengguna dapat menggunakan menu utama sesuai '
        'role dan akses yang dimiliki.',
    icon: Icons.rocket_launch_rounded,
    color: _MC.red,
    category: _GuideCategory.gettingStarted,
    points: [
      'Pastikan koneksi internet aktif.',
      'Login menggunakan akun yang terdaftar.',
      'Periksa status server pada halaman utama.',
      'Gunakan menu yang tersedia sesuai akses akun.',
      'Baca informasi dan aturan sebelum menggunakan fitur transaksi.',
    ],
  ),

  _GuideItem(
    title: 'Mengenal Dashboard',
    description: 'Pahami fungsi menu utama aplikasi.',
    detail:
        'Dashboard merupakan pusat navigasi aplikasi. Setiap tombol dapat '
        'membawa pengguna ke fitur tertentu.',
    icon: Icons.dashboard_customize_rounded,
    color: _MC.blue,
    category: _GuideCategory.gettingStarted,
    points: [
      'Home untuk melihat informasi utama.',
      'Tools untuk mengakses fitur yang tersedia.',
      'Chat untuk diskusi publik jika tersedia.',
      'Info untuk membaca panduan dan peraturan.',
      'Profile untuk melihat informasi akun.',
    ],
  ),

  _GuideItem(
    title: 'Status Server',
    description: 'Cara membaca status API dan ping server.',
    detail:
        'Status server digunakan untuk mengetahui apakah API sedang dapat '
        'diakses oleh aplikasi.',
    icon: Icons.speed_rounded,
    color: _MC.green,
    category: _GuideCategory.gettingStarted,
    points: [
      'Hijau berarti server merespons.',
      'Ping rendah biasanya menunjukkan respons lebih cepat.',
      'Jika Offline, periksa koneksi internet terlebih dahulu.',
      'Jika terus Offline, server mungkin sedang mengalami gangguan.',
    ],
  ),

  // ==========================================================
  // ACCOUNT
  // ==========================================================

  _GuideItem(
    title: 'Informasi Akun',
    description: 'Kenali username, session, dan role akun.',
    detail:
        'Setiap akun memiliki identitas dan role yang menentukan fitur yang '
        'dapat digunakan.',
    icon: Icons.account_circle_rounded,
    color: _MC.pink,
    category: _GuideCategory.account,
    points: [
      'Username digunakan sebagai identitas pengguna.',
      'Role menentukan tingkat akses.',
      'Session digunakan aplikasi untuk mempertahankan login.',
      'Jangan membagikan session atau token kepada orang lain.',
    ],
  ),

  _GuideItem(
    title: 'Role & Permission',
    description: 'Pahami sistem tingkatan role dalam aplikasi.',
    detail:
        'Role dapat memiliki hak akses berbeda. Fitur tertentu mungkin hanya '
        'tersedia untuk role tertentu.',
    icon: Icons.workspace_premium_rounded,
    color: _MC.amber,
    category: _GuideCategory.account,
    points: [
      'Member merupakan akses dasar.',
      'VIP dan reseller memiliki akses tambahan sesuai sistem.',
      'Admin dan partner memiliki akses pengelolaan tertentu.',
      'Developer, moderator, staff, dan executive memiliki akses khusus.',
      'Owner memiliki tingkat kontrol tertinggi sesuai sistem.',
    ],
  ),

  _GuideItem(
    title: 'Menjaga Akun',
    description: 'Langkah dasar agar akun tetap aman.',
    detail:
        'Keamanan akun merupakan tanggung jawab bersama. Jangan memberikan '
        'data autentikasi kepada pihak lain.',
    icon: Icons.shield_rounded,
    color: _MC.green,
    category: _GuideCategory.account,
    points: [
      'Jangan memberikan password.',
      'Jangan membagikan session key.',
      'Jangan screenshot data sensitif.',
      'Gunakan perangkat yang dipercaya.',
      'Logout jika menggunakan perangkat milik orang lain.',
    ],
  ),

  // ==========================================================
  // TOOLS
  // ==========================================================

  _GuideItem(
    title: 'Tools Gateway',
    description: 'Panduan menggunakan pusat tools aplikasi.',
    detail:
        'Tools Gateway berfungsi sebagai pusat berbagai fitur yang tersedia '
        'di dalam aplikasi.',
    icon: Icons.build_circle_rounded,
    color: _MC.red,
    category: _GuideCategory.tools,
    points: [
      'Pilih tool yang ingin digunakan.',
      'Baca deskripsi tool sebelum menjalankannya.',
      'Masukkan data sesuai format yang diminta.',
      'Tunggu proses sampai selesai.',
      'Jangan menekan tombol berkali-kali saat proses berjalan.',
    ],
  ),

  _GuideItem(
    title: 'Menjalankan Tool',
    description: 'Langkah umum saat menjalankan sebuah tool.',
    detail:
        'Setiap tool dapat memiliki input dan proses berbeda. Ikuti instruksi '
        'yang tampil pada halaman tool.',
    icon: Icons.play_circle_fill_rounded,
    color: _MC.cyan,
    category: _GuideCategory.tools,
    points: [
      'Buka Tools Gateway.',
      'Pilih tool.',
      'Masukkan input yang diperlukan.',
      'Tekan tombol proses.',
      'Tunggu response dari server.',
    ],
  ),

  _GuideItem(
    title: 'Tool Sedang Loading',
    description: 'Apa yang dilakukan ketika proses terlalu lama?',
    detail:
        'Jangan langsung mengulangi request. Periksa koneksi dan status API '
        'terlebih dahulu.',
    icon: Icons.hourglass_top_rounded,
    color: _MC.orange,
    category: _GuideCategory.tools,
    points: [
      'Tunggu beberapa detik.',
      'Periksa indikator server.',
      'Jangan spam tombol proses.',
      'Jika gagal, coba kembali setelah koneksi stabil.',
    ],
  ),

  // ==========================================================
  // TRANSACTION
  // ==========================================================

  _GuideItem(
    title: 'Panduan Transaksi',
    description: 'Hal penting sebelum melakukan transaksi.',
    detail:
        'Pastikan semua informasi transaksi sudah benar sebelum melakukan '
        'pembayaran atau mengirim data.',
    icon: Icons.payments_rounded,
    color: _MC.green,
    category: _GuideCategory.transaction,
    points: [
      'Pastikan tujuan transaksi benar.',
      'Periksa nominal sebelum konfirmasi.',
      'Simpan bukti transaksi.',
      'Jangan mengirim pembayaran kepada pihak yang tidak terverifikasi.',
      'Jika ada masalah, hubungi pihak yang berwenang.',
    ],
  ),

  _GuideItem(
    title: 'Bukti Pembayaran',
    description: 'Cara menyimpan bukti transaksi.',
    detail:
        'Bukti transaksi dapat digunakan sebagai referensi apabila terjadi '
        'masalah atau diperlukan proses verifikasi.',
    icon: Icons.receipt_long_rounded,
    color: _MC.blue,
    category: _GuideCategory.transaction,
    points: [
      'Simpan screenshot atau bukti resmi.',
      'Pastikan tanggal dan nominal terlihat.',
      'Jangan mengedit bukti transaksi.',
      'Kirim hanya kepada pihak yang berwenang.',
    ],
  ),

  _GuideItem(
    title: 'Setoran',
    description: 'Panduan umum proses pengajuan setoran.',
    detail:
        'Jika aplikasi memiliki fitur setoran, ikuti alur yang ditampilkan '
        'pada halaman setoran dan tunggu proses approval.',
    icon: Icons.account_balance_wallet_rounded,
    color: _MC.amber,
    category: _GuideCategory.transaction,
    points: [
      'Buka halaman Setoran.',
      'Masukkan informasi yang diperlukan.',
      'Upload bukti jika diminta.',
      'Kirim pengajuan.',
      'Tunggu proses verifikasi atau approval.',
    ],
  ),

  // ==========================================================
  // CHAT
  // ==========================================================

  _GuideItem(
    title: 'Public Chat',
    description: 'Gunakan ruang chat untuk berdiskusi dengan pengguna.',
    detail:
        'Public Chat digunakan untuk komunikasi dan diskusi antar pengguna '
        'sesuai aturan komunitas.',
    icon: Icons.forum_rounded,
    color: _MC.red,
    category: _GuideCategory.chat,
    points: [
      'Gunakan bahasa yang sopan.',
      'Jangan melakukan spam.',
      'Jangan membagikan data pribadi.',
      'Gunakan chat sesuai topik.',
      'Hormati pengguna lain.',
    ],
  ),

  _GuideItem(
    title: 'Kirim Foto',
    description: 'Cara menggunakan fitur media pada chat.',
    detail:
        'Jika fitur foto tersedia, pengguna dapat memilih gambar dari perangkat '
        'untuk dikirim ke ruang chat.',
    icon: Icons.photo_library_rounded,
    color: _MC.pink,
    category: _GuideCategory.chat,
    points: [
      'Tekan tombol lampiran atau foto.',
      'Pilih gambar.',
      'Periksa gambar sebelum dikirim.',
      'Tekan kirim.',
      'Gunakan media yang aman dan relevan.',
    ],
  ),

  _GuideItem(
    title: 'Reaksi Pesan',
    description: 'Gunakan reaction untuk merespons pesan.',
    detail:
        'Reaction dapat digunakan sebagai respons singkat tanpa harus mengirim '
        'pesan baru.',
    icon: Icons.favorite_rounded,
    color: _MC.crimson,
    category: _GuideCategory.chat,
    points: [
      'Tekan atau gunakan gesture sesuai UI chat.',
      'Pilih reaction yang tersedia.',
      'Gunakan reaction secara wajar.',
      'Hindari spam reaction.',
    ],
  ),

  // ==========================================================
  // SECURITY
  // ==========================================================

  _GuideItem(
    title: 'Keamanan Session',
    description: 'Session key adalah data yang harus dijaga.',
    detail:
        'Session atau token autentikasi dapat digunakan untuk mengakses akun. '
        'Karena itu jangan pernah membagikannya kepada pihak lain.',
    icon: Icons.key_rounded,
    color: _MC.redDark,
    category: _GuideCategory.security,
    points: [
      'Jangan kirim session melalui chat publik.',
      'Jangan upload session ke media sosial.',
      'Jangan memberikan session kepada orang yang mengaku admin.',
      'Jika session dicurigai bocor, lakukan tindakan keamanan sesuai sistem.',
    ],
  ),

  _GuideItem(
    title: 'Anti Scam',
    description: 'Kenali tanda-tanda penipuan.',
    detail:
        'Selalu verifikasi pihak yang meminta pembayaran, data akun, atau '
        'informasi sensitif.',
    icon: Icons.gpp_bad_rounded,
    color: _MC.red,
    category: _GuideCategory.security,
    points: [
      'Jangan percaya screenshot sebagai satu-satunya bukti.',
      'Verifikasi username atau identitas pihak terkait.',
      'Jangan memberikan OTP.',
      'Jangan memberikan password.',
      'Jangan memberikan session key.',
    ],
  ),

  _GuideItem(
    title: 'Privasi Data',
    description: 'Lindungi informasi pribadi.',
    detail:
        'Data seperti nomor telepon, password, token, alamat, dan informasi '
        'pembayaran sebaiknya tidak dibagikan secara publik.',
    icon: Icons.visibility_off_rounded,
    color: _MC.rose,
    category: _GuideCategory.security,
    points: [
      'Hindari membagikan data pribadi.',
      'Gunakan chat privat jika memang diperlukan.',
      'Jangan upload dokumen sensitif.',
      'Periksa kembali file sebelum dikirim.',
    ],
  ),

  // ==========================================================
  // TROUBLESHOOTING
  // ==========================================================

  _GuideItem(
    title: 'Tidak Bisa Login',
    description: 'Solusi dasar jika login gagal.',
    detail:
        'Login dapat gagal karena koneksi, session, server, atau kredensial '
        'yang tidak sesuai.',
    icon: Icons.login_rounded,
    color: _MC.orange,
    category: _GuideCategory.troubleshooting,
    points: [
      'Periksa koneksi internet.',
      'Pastikan username dan data login benar.',
      'Periksa status API.',
      'Restart aplikasi.',
      'Jika tetap gagal, hubungi administrator.',
    ],
  ),

  _GuideItem(
    title: 'Server Offline',
    description: 'Apa yang harus dilakukan saat API offline?',
    detail:
        'Jika indikator API menunjukkan Offline, aplikasi mungkin tidak dapat '
        'mengambil atau mengirim data ke server.',
    icon: Icons.cloud_off_rounded,
    color: _MC.redDark,
    category: _GuideCategory.troubleshooting,
    points: [
      'Periksa koneksi internet.',
      'Tunggu beberapa saat.',
      'Coba buka kembali halaman.',
      'Jangan melakukan request berulang.',
      'Hubungi administrator jika gangguan berlanjut.',
    ],
  ),

  _GuideItem(
    title: 'Data Tidak Muncul',
    description: 'Solusi jika informasi belum tampil.',
    detail:
        'Data dapat belum muncul karena request belum selesai, API sedang '
        'sibuk, atau terjadi masalah koneksi.',
    icon: Icons.data_object_rounded,
    color: _MC.blue,
    category: _GuideCategory.troubleshooting,
    points: [
      'Tunggu proses loading.',
      'Refresh halaman.',
      'Periksa status server.',
      'Pastikan session masih aktif.',
      'Login kembali jika session telah berakhir.',
    ],
  ),

  // ==========================================================
  // RULES
  // ==========================================================

  _GuideItem(
    title: 'Dilarang Barter Akun',
    description: 'Akun tidak boleh ditukar dengan akun atau barang lain.',
    detail:
        'Akun bersifat personal. Jangan melakukan pertukaran akun kecuali '
        'sistem secara resmi mengizinkannya.',
    icon: Icons.swap_horiz_rounded,
    color: _MC.amber,
    category: _GuideCategory.rules,
    points: [
      'Tidak melakukan barter akun.',
      'Tidak menukar akun dengan barang.',
      'Tidak menukar akun dengan jasa.',
      'Ikuti kebijakan resmi aplikasi.',
    ],
  ),

  _GuideItem(
    title: 'Dilarang Membagikan Akun',
    description: 'Jangan memberikan akses akun kepada orang lain.',
    detail:
        'Membagikan akun dapat menyebabkan keamanan akun terganggu dan '
        'aktivitas sulit dilacak.',
    icon: Icons.share_rounded,
    color: _MC.blue,
    category: _GuideCategory.rules,
    points: [
      'Satu akun digunakan oleh pemiliknya.',
      'Jangan memberikan password.',
      'Jangan memberikan session.',
      'Jangan memberikan token.',
    ],
  ),

  _GuideItem(
    title: 'Larangan Menjual Akun',
    description: 'Penjualan akun hanya boleh mengikuti ketentuan resmi.',
    detail:
        'Pengguna tidak diperbolehkan melakukan penjualan akun apabila tidak '
        'mendapatkan izin dari sistem atau pihak yang berwenang.',
    icon: Icons.sell_rounded,
    color: _MC.red,
    category: _GuideCategory.rules,
    points: [
      'Jangan menjual akun secara ilegal.',
      'Jangan menawarkan akun di public chat.',
      'Ikuti ketentuan role dan sistem.',
      'Hubungi pihak berwenang jika membutuhkan klarifikasi.',
    ],
  ),

  _GuideItem(
    title: 'Larangan Banting Harga',
    description: 'Jangan merusak harga yang telah ditentukan.',
    detail:
        'Aktivitas transaksi harus mengikuti ketentuan harga yang berlaku '
        'di dalam sistem.',
    icon: Icons.trending_down_rounded,
    color: _MC.green,
    category: _GuideCategory.rules,
    points: [
      'Ikuti harga resmi.',
      'Jangan melakukan perang harga.',
      'Jangan membuat transaksi yang merugikan pihak lain.',
      'Gunakan jalur resmi untuk perubahan harga.',
    ],
  ),
];

// ============================================================
// 📖 INFO PAGE
// ============================================================

class InfoPage extends StatefulWidget {
  final String sessionKey;
  final String role;
  final String username;

  const InfoPage({
    super.key,
    required this.sessionKey,
    this.role = 'member',
    this.username = 'User',
  });

  @override
  State<InfoPage> createState() => _InfoPageState();
}

class _InfoPageState extends State<InfoPage>
    with TickerProviderStateMixin {
  bool _apiOnline = false;
  int _pingMs = 0;
  String _pingStatus = 'Checking...';

  Timer? _pingTimer;

  late final AnimationController _bgController;
  late final AnimationController _entranceController;
  late final AnimationController _pulseController;
  late final AnimationController _ringController;
  late final AnimationController _shimmerController;

  _GuideCategory _selectedCategory = _GuideCategory.all;

  int? _expandedIndex;

  @override
  void initState() {
    super.initState();

    _bgController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 18),
    )..repeat();

    _entranceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    _ringController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 10),
    )..repeat();

    _shimmerController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2500),
    )..repeat();

    _entranceController.forward();

    _startPingLoop();
  }

  @override
  void dispose() {
    _pingTimer?.cancel();

    _bgController.dispose();
    _entranceController.dispose();
    _pulseController.dispose();
    _ringController.dispose();
    _shimmerController.dispose();

    super.dispose();
  }

  // ==========================================================
  // 📡 API PING
  // ==========================================================

  void _startPingLoop() {
    _checkPing();

    _pingTimer = Timer.periodic(
      const Duration(seconds: 8),
      (_) => _checkPing(),
    );
  }

  Future<void> _checkPing() async {
    if (widget.sessionKey.trim().isEmpty) {
      if (!mounted) return;

      setState(() {
        _apiOnline = false;
        _pingMs = 0;
        _pingStatus = 'No Session';
      });

      return;
    }

    final stopwatch = Stopwatch()..start();

    try {
      final uri = Uri.parse(
        '$baseUrl/ping?key=${Uri.encodeQueryComponent(widget.sessionKey)}',
      );

      final response = await http
          .get(uri)
          .timeout(const Duration(seconds: 4));

      stopwatch.stop();

      final ms = stopwatch.elapsedMilliseconds;

      if (!mounted) return;

      if (response.statusCode >= 200 &&
          response.statusCode < 300) {
        setState(() {
          _apiOnline = true;
          _pingMs = ms;
          _pingStatus = '${ms}ms';
        });
      } else {
        setState(() {
          _apiOnline = false;
          _pingMs = 0;
          _pingStatus = 'HTTP ${response.statusCode}';
        });
      }
    } catch (_) {
      stopwatch.stop();

      if (!mounted) return;

      setState(() {
        _apiOnline = false;
        _pingMs = 0;
        _pingStatus = 'Offline';
      });
    }
  }

  // ==========================================================
  // 📊 PING COLOR
  // ==========================================================

  Color get _pingColor {
    if (!_apiOnline) return _MC.redDark;

    if (_pingMs < 200) return _MC.green;

    if (_pingMs < 500) return _MC.amber;

    return _MC.orange;
  }

  String get _pingLabel {
    if (!_apiOnline) return 'OFFLINE';

    if (_pingMs < 200) return 'EXCELLENT';

    if (_pingMs < 500) return 'GOOD';

    return 'SLOW';
  }

  // ==========================================================
  // 📚 FILTER
  // ==========================================================

  List<_GuideItem> get _filteredGuides {
    if (_selectedCategory == _GuideCategory.all) {
      return _guides;
    }

    return _guides
        .where((item) => item.category == _selectedCategory)
        .toList();
  }

  // ==========================================================
  // 🏗️ BUILD
  // ==========================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _MC.bg,
      body: Stack(
        children: [
          Positioned.fill(
            child: _AnimatedRedBackground(
              controller: _bgController,
            ),
          ),

          SafeArea(
            child: FadeTransition(
              opacity: CurvedAnimation(
                parent: _entranceController,
                curve: Curves.easeOutCubic,
              ),
              child: SlideTransition(
                position: Tween<Offset>(
                  begin: const Offset(0, 0.04),
                  end: Offset.zero,
                ).animate(
                  CurvedAnimation(
                    parent: _entranceController,
                    curve: Curves.easeOutCubic,
                  ),
                ),
                child: CustomScrollView(
                  physics: const BouncingScrollPhysics(),
                  slivers: [
                    SliverToBoxAdapter(
                      child: _buildTopBar(),
                    ),

                    SliverPadding(
                      padding: const EdgeInsets.fromLTRB(
                        16,
                        8,
                        16,
                        40,
                      ),
                      sliver: SliverList(
                        delegate: SliverChildListDelegate(
                          [
                            _buildHeroCard(),

                            const SizedBox(height: 16),

                            _buildUserCard(),

                            const SizedBox(height: 16),

                            _buildServerCard(),

                            const SizedBox(height: 22),

                            _buildSectionTitle(),

                            const SizedBox(height: 12),

                            _buildCategorySelector(),

                            const SizedBox(height: 18),

                            ..._buildGuideCards(),

                            const SizedBox(height: 22),

                            _buildImportantCard(),

                            const SizedBox(height: 18),

                            _buildFooter(),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==========================================================
  // 🔝 TOP BAR
  // ==========================================================

  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 10),
      child: Row(
        children: [
          _glassIcon(
            icon: Icons.menu_book_rounded,
            color: _MC.red,
          ),

          const SizedBox(width: 12),

          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'X-SPYDER PROJECT',
                  style: TextStyle(
                    color: _MC.textDark,
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.2,
                  ),
                ),
                SizedBox(height: 2),
                Text(
                  'FULL SYSTEM GUIDE',
                  style: TextStyle(
                    color: _MC.red,
                    fontSize: 9,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.4,
                  ),
                ),
              ],
            ),
          ),

          _glassIcon(
            icon: Icons.help_outline_rounded,
            color: _MC.redDark,
          ),
        ],
      ),
    );
  }

  Widget _glassIcon({
    required IconData icon,
    required Color color,
  }) {
    return Container(
      width: 42,
      height: 42,
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.7),
        shape: BoxShape.circle,
        border: Border.all(
          color: color.withOpacity(0.3),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.14),
            blurRadius: 18,
          ),
        ],
      ),
      child: Icon(
        icon,
        color: color,
        size: 20,
      ),
    );
  }

  // ==========================================================
  // 🚀 HERO
  // ==========================================================

  Widget _buildHeroCard() {
    return AnimatedBuilder(
      animation: _shimmerController,
      builder: (_, __) {
        return Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(30),
            gradient: const LinearGradient(
              colors: [
                _MC.redDeep,
                _MC.redDark,
                _MC.crimson,
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            boxShadow: [
              BoxShadow(
                color: _MC.red.withOpacity(0.4),
                blurRadius: 32,
                offset: const Offset(0, 14),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(30),
            child: Stack(
              children: [
                Positioned(
                  right: -35,
                  top: -45,
                  child: _glowCircle(150),
                ),

                Positioned(
                  left: -60,
                  bottom: -70,
                  child: _glowCircle(180),
                ),

                // Shimmer sweep
                Positioned.fill(
                  child: IgnorePointer(
                    child: AnimatedBuilder(
                      animation: _shimmerController,
                      builder: (_, __) {
                        return Transform.translate(
                          offset: Offset(
                            (_shimmerController.value * 2 - 1) * 280,
                            0,
                          ),
                          child: Transform.rotate(
                            angle: 0.35,
                            child: Container(
                              width: 60,
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    Colors.white.withOpacity(0),
                                    Colors.white.withOpacity(0.1),
                                    Colors.white.withOpacity(0),
                                  ],
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter,
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),

                Positioned(
                  right: 18,
                  bottom: 12,
                  child: Icon(
                    Icons.menu_book_rounded,
                    size: 110,
                    color: Colors.white.withOpacity(0.07),
                  ),
                ),

                Padding(
                  padding: const EdgeInsets.all(24),
                  child: Row(
                    children: [
                      AnimatedBuilder(
                        animation: _ringController,
                        builder: (_, __) {
                          return Transform.rotate(
                            angle: _ringController.value * math.pi * 2,
                            child: Container(
                              width: 74,
                              height: 74,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: Colors.white.withOpacity(0.6),
                                  width: 2.2,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.white.withOpacity(0.1),
                                    blurRadius: 14,
                                  ),
                                ],
                              ),
                              child: const Center(
                                child: Icon(
                                  Icons.auto_stories_rounded,
                                  color: Colors.white,
                                  size: 30,
                                ),
                              ),
                            ),
                          );
                        },
                      ),

                      const SizedBox(width: 18),

                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'PANDUAN LENGKAP',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 1.4,
                              ),
                            ),
                            SizedBox(height: 8),
                            Text(
                              'Pelajari cara menggunakan sistem, '
                              'fitur, keamanan, transaksi, chat, '
                              'dan aturan aplikasi.',
                              style: TextStyle(
                                color: Color(0xFFFEE2E2),
                                fontSize: 11,
                                height: 1.55,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _glowCircle(double size) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: Colors.white.withOpacity(0.07),
      ),
    );
  }

  // ==========================================================
  // 👤 USER CARD
  // ==========================================================

  Widget _buildUserCard() {
    final roleColor = _roleColor(widget.role);
    final roleName = _roleName(widget.role);
    final verified = _isVerifiedRole(widget.role);
    final level = _roleLevel(widget.role);

    return _GlassCard(
      child: Row(
        children: [
          _buildRoleAvatar(
            roleColor: roleColor,
            verified: verified,
            level: level,
          ),

          const SizedBox(width: 14),

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'ACCOUNT INFORMATION',
                  style: TextStyle(
                    color: _MC.textLight,
                    fontSize: 9,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.2,
                  ),
                ),

                const SizedBox(height: 4),

                Text(
                  widget.username.isEmpty
                      ? 'User'
                      : widget.username,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: _MC.textDark,
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                  ),
                ),

                const SizedBox(height: 7),

                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 9,
                        vertical: 5,
                      ),
                      decoration: BoxDecoration(
                        color: roleColor.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: roleColor.withOpacity(0.35),
                        ),
                      ),
                      child: Text(
                        roleName,
                        style: TextStyle(
                          color: roleColor,
                          fontSize: 10,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),

                    const SizedBox(width: 7),

                    if (verified)
                      const Icon(
                        Icons.verified_rounded,
                        color: _MC.blue,
                        size: 17,
                      ),
                  ],
                ),
              ],
            ),
          ),

          Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 9,
              vertical: 7,
            ),
            decoration: BoxDecoration(
              color: roleColor.withOpacity(0.08),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              'LV.$level',
              style: TextStyle(
                color: roleColor,
                fontSize: 10,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==========================================================
  // 🧿 ROLE AVATAR
  // ==========================================================

  Widget _buildRoleAvatar({
    required Color roleColor,
    required bool verified,
    required int level,
  }) {
    return SizedBox(
      width: 66,
      height: 66,
      child: Stack(
        alignment: Alignment.center,
        children: [
          AnimatedBuilder(
            animation: _ringController,
            builder: (_, __) {
              return Transform.rotate(
                angle: _ringController.value * math.pi * 2,
                child: CustomPaint(
                  size: const Size(66, 66),
                  painter: _RoleRingPainter(
                    color: roleColor,
                    level: level,
                  ),
                ),
              );
            },
          ),

          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white,
              border: Border.all(
                color: roleColor.withOpacity(0.55),
                width: 2,
              ),
              boxShadow: [
                BoxShadow(
                  color: roleColor.withOpacity(0.28),
                  blurRadius: 16,
                ),
              ],
            ),
            child: ClipOval(
              child: Image.asset(
                'assets/images/bug.png',
                fit: BoxFit.contain,
                errorBuilder: (_, __, ___) {
                  return Icon(
                    Icons.person_rounded,
                    color: roleColor,
                    size: 26,
                  );
                },
              ),
            ),
          ),

          if (verified)
            Positioned(
              right: 0,
              bottom: 1,
              child: Container(
                width: 19,
                height: 19,
                decoration: BoxDecoration(
                  color: _MC.blue,
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: Colors.white,
                    width: 2,
                  ),
                ),
                child: const Icon(
                  Icons.check_rounded,
                  color: Colors.white,
                  size: 11,
                ),
              ),
            ),
        ],
      ),
    );
  }

  // ==========================================================
  // 📡 SERVER CARD
  // ==========================================================

  Widget _buildServerCard() {
    final color = _pingColor;

    return AnimatedBuilder(
      animation: _pulseController,
      builder: (_, __) {
        final pulse = _apiOnline
            ? 0.08 + (_pulseController.value * 0.08)
            : 0.05;

        return _GlassCard(
          borderColor: color.withOpacity(0.35),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: color.withOpacity(pulse + 0.08),
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(
                    color: color.withOpacity(0.45),
                    width: 1.5,
                  ),
                ),
                child: Icon(
                  _apiOnline
                      ? Icons.cloud_done_rounded
                      : Icons.cloud_off_rounded,
                  color: color,
                  size: 23,
                ),
              ),

              const SizedBox(width: 13),

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'API SERVER',
                      style: TextStyle(
                        color: _MC.textLight,
                        fontSize: 9,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.2,
                      ),
                    ),

                    const SizedBox(height: 4),

                    Text(
                      _apiOnline
                          ? 'ONLINE • $_pingLabel'
                          : 'SERVER $_pingStatus',
                      style: TextStyle(
                        color: color,
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ],
                ),
              ),

              Container(
                width: 62,
                height: 52,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: color.withOpacity(0.25),
                  ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      _apiOnline ? '$_pingMs' : '--',
                      style: TextStyle(
                        color: color,
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const Text(
                      'PING',
                      style: TextStyle(
                        color: _MC.textLight,
                        fontSize: 7,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ==========================================================
  // 📚 SECTION TITLE
  // ==========================================================

  Widget _buildSectionTitle() {
    return Row(
      children: [
        Container(
          width: 5,
          height: 25,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [_MC.red, _MC.crimson],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
            borderRadius: BorderRadius.circular(4),
          ),
        ),

        const SizedBox(width: 10),

        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'SYSTEM GUIDE',
                style: TextStyle(
                  color: _MC.textDark,
                  fontSize: 17,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1,
                ),
              ),
              SizedBox(height: 2),
              Text(
                'Pilih kategori untuk melihat panduan',
                style: TextStyle(
                  color: _MC.textGrey,
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),

        Container(
          padding: const EdgeInsets.symmetric(
            horizontal: 9,
            vertical: 6,
          ),
          decoration: BoxDecoration(
            color: _MC.red.withOpacity(0.1),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Text(
            '${_filteredGuides.length} GUIDE',
            style: const TextStyle(
              color: _MC.redDark,
              fontSize: 8,
              fontWeight: FontWeight.w900,
            ),
          ),
        ),
      ],
    );
  }

  // ==========================================================
  // 🗂️ CATEGORY SELECTOR
  // ==========================================================

  Widget _buildCategorySelector() {
    final categories = [
      _CategoryData(
        category: _GuideCategory.all,
        title: 'ALL',
        subtitle: 'Semua',
        icon: Icons.apps_rounded,
        color: _MC.red,
      ),
      _CategoryData(
        category: _GuideCategory.gettingStarted,
        title: 'START',
        subtitle: 'Mulai',
        icon: Icons.rocket_launch_rounded,
        color: _MC.blue,
      ),
      _CategoryData(
        category: _GuideCategory.account,
        title: 'ACCOUNT',
        subtitle: 'Akun',
        icon: Icons.person_rounded,
        color: _MC.pink,
      ),
      _CategoryData(
        category: _GuideCategory.tools,
        title: 'TOOLS',
        subtitle: 'Tools',
        icon: Icons.build_rounded,
        color: _MC.redDark,
      ),
      _CategoryData(
        category: _GuideCategory.transaction,
        title: 'PAYMENT',
        subtitle: 'Transaksi',
        icon: Icons.payments_rounded,
        color: _MC.green,
      ),
      _CategoryData(
        category: _GuideCategory.chat,
        title: 'CHAT',
        subtitle: 'Public Chat',
        icon: Icons.forum_rounded,
        color: _MC.cyan,
      ),
      _CategoryData(
        category: _GuideCategory.security,
        title: 'SECURITY',
        subtitle: 'Keamanan',
        icon: Icons.shield_rounded,
        color: _MC.crimson,
      ),
      _CategoryData(
        category: _GuideCategory.troubleshooting,
        title: 'FIX',
        subtitle: 'Trouble',
        icon: Icons.build_circle_rounded,
        color: _MC.orange,
      ),
      _CategoryData(
        category: _GuideCategory.rules,
        title: 'RULES',
        subtitle: 'Aturan',
        icon: Icons.gavel_rounded,
        color: _MC.amber,
      ),
    ];

    return SizedBox(
      height: 78,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        itemCount: categories.length,
        separatorBuilder: (_, __) => const SizedBox(width: 9),
        itemBuilder: (context, index) {
          final item = categories[index];

          final selected =
              _selectedCategory == item.category;

          return GestureDetector(
            onTap: () {
              setState(() {
                _selectedCategory = item.category;
                _expandedIndex = null;
              });
            },
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              curve: Curves.easeOutCubic,
              width: selected ? 112 : 96,
              padding: const EdgeInsets.symmetric(
                horizontal: 10,
                vertical: 9,
              ),
              decoration: BoxDecoration(
                color: selected
                    ? item.color.withOpacity(0.95)
                    : Colors.white.withOpacity(0.7),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(
                  color: selected
                      ? item.color
                      : item.color.withOpacity(0.22),
                  width: selected ? 1.8 : 1,
                ),
                boxShadow: [
                  BoxShadow(
                    color: item.color.withOpacity(
                      selected ? 0.28 : 0.08,
                    ),
                    blurRadius: selected ? 18 : 10,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Container(
                    width: 38,
                    height: 38,
                    decoration: BoxDecoration(
                      color: selected
                          ? Colors.white.withOpacity(0.18)
                          : item.color.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(
                      item.icon,
                      color: selected
                          ? Colors.white
                          : item.color,
                      size: 18,
                    ),
                  ),

                  const SizedBox(width: 7),

                  Expanded(
                    child: Column(
                      mainAxisAlignment:
                          MainAxisAlignment.center,
                      crossAxisAlignment:
                          CrossAxisAlignment.start,
                      children: [
                        Text(
                          item.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: selected
                                ? Colors.white
                                : _MC.textDark,
                            fontSize: 9.5,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 0.6,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          item.subtitle,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: selected
                                ? Colors.white.withOpacity(0.8)
                                : _MC.textGrey,
                            fontSize: 8,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // ==========================================================
  // 📋 GUIDE CARDS
  // ==========================================================

  List<Widget> _buildGuideCards() {
    final guides = _filteredGuides;

    if (guides.isEmpty) {
      return [
        _buildEmptyGuide(),
      ];
    }

    return List.generate(
      guides.length,
      (index) {
        final guide = guides[index];

        return Padding(
          padding: const EdgeInsets.only(bottom: 11),
          child: _GuideCard(
            item: guide,
            number: index + 1,
            expanded: _expandedIndex == index,
            onTap: () {
              setState(() {
                _expandedIndex =
                    _expandedIndex == index ? null : index;
              });
            },
          ),
        );
      },
    );
  }

  // ==========================================================
  // EMPTY
  // ==========================================================

  Widget _buildEmptyGuide() {
    return _GlassCard(
      child: Padding(
        padding: const EdgeInsets.all(25),
        child: Column(
          children: [
            Icon(
              Icons.menu_book_rounded,
              color: _MC.red.withOpacity(0.6),
              size: 42,
            ),
            const SizedBox(height: 10),
            const Text(
              'Panduan Tidak Ditemukan',
              style: TextStyle(
                color: _MC.textDark,
                fontSize: 15,
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(height: 5),
            const Text(
              'Belum ada panduan pada kategori ini.',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: _MC.textGrey,
                fontSize: 11,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ==========================================================
  // ⚠️ IMPORTANT CARD
  // ==========================================================

  Widget _buildImportantCard() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: LinearGradient(
          colors: [
            _MC.redDeep.withOpacity(0.98),
            _MC.redDark.withOpacity(0.95),
            _MC.crimson.withOpacity(0.9),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: _MC.red.withOpacity(0.3),
            blurRadius: 26,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: Stack(
          children: [
            Positioned(
              right: -30,
              top: -30,
              child: Container(
                width: 120,
                height: 120,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white.withOpacity(0.05),
                ),
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                children: [
                  Row(
                    children: [
                      Container(
                        width: 43,
                        height: 43,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.13),
                          borderRadius: BorderRadius.circular(13),
                          border: Border.all(
                            color: Colors.white.withOpacity(0.2),
                          ),
                        ),
                        child: const Icon(
                          Icons.priority_high_rounded,
                          color: Colors.white,
                          size: 22,
                        ),
                      ),

                      const SizedBox(width: 12),

                      const Expanded(
                        child: Text(
                          'PENTING UNTUK DIPERHATIKAN',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 13,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 0.7,
                          ),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 14),

                  _importantRow(
                    Icons.lock_rounded,
                    'Jaga password, token, dan session.',
                  ),

                  _importantRow(
                    Icons.block_rounded,
                    'Jangan melakukan spam terhadap server.',
                  ),

                  _importantRow(
                    Icons.verified_user_rounded,
                    'Gunakan fitur sesuai role dan izin akun.',
                  ),

                  _importantRow(
                    Icons.forum_rounded,
                    'Hormati pengguna lain di public chat.',
                  ),

                  _importantRow(
                    Icons.menu_book_rounded,
                    'Baca panduan sebelum menggunakan fitur.',
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _importantRow(
    IconData icon,
    String text,
  ) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 9),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            icon,
            color: _MC.redLight,
            size: 16,
          ),
          const SizedBox(width: 9),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(
                color: Color(0xFFFEE2E2),
                fontSize: 10.5,
                height: 1.45,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==========================================================
  // 🦶 FOOTER
  // ==========================================================

  Widget _buildFooter() {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.62),
            borderRadius: BorderRadius.circular(17),
            border: Border.all(
              color: _MC.red.withOpacity(0.14),
            ),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(
                Icons.info_outline_rounded,
                color: _MC.red,
                size: 19,
              ),
              const SizedBox(width: 10),
              const Expanded(
                child: Text(
                  'Dengan menggunakan aplikasi ini, pengguna dianggap '
                  'telah memahami panduan dan bersedia mengikuti ketentuan '
                  'yang berlaku.',
                  style: TextStyle(
                    color: _MC.textGrey,
                    fontSize: 10.5,
                    height: 1.5,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 17),

        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 28,
              height: 2,
              decoration: BoxDecoration(
                color: _MC.red,
                borderRadius: BorderRadius.circular(2),
              ),
            ),

            const SizedBox(width: 9),

            const Text(
              'X-SPYDER PROJECT • 2026',
              style: TextStyle(
                color: _MC.textLight,
                fontSize: 8.5,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.2,
              ),
            ),

            const SizedBox(width: 9),

            Container(
              width: 28,
              height: 2,
              decoration: BoxDecoration(
                color: _MC.red,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

// ============================================================
// 🧊 GLASS CARD
// ============================================================

class _GlassCard extends StatelessWidget {
  final Widget child;
  final Color? borderColor;

  const _GlassCard({
    required this.child,
    this.borderColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.68),
        borderRadius: BorderRadius.circular(21),
        border: Border.all(
          color: borderColor ??
              Colors.white.withOpacity(0.8),
          width: 1.2,
        ),
        boxShadow: [
          BoxShadow(
            color: _MC.red.withOpacity(0.07),
            blurRadius: 22,
            offset: const Offset(0, 9),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(15),
        child: child,
      ),
    );
  }
}

// ============================================================
// 📋 GUIDE CARD
// ============================================================

class _GuideCard extends StatelessWidget {
  final _GuideItem item;
  final int number;
  final bool expanded;
  final VoidCallback onTap;

  const _GuideCard({
    required this.item,
    required this.number,
    required this.expanded,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final color = item.color;

    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOutCubic,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(
            expanded ? 0.86 : 0.68,
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: expanded
                ? color.withOpacity(0.6)
                : Colors.white.withOpacity(0.8),
            width: expanded ? 1.6 : 1,
          ),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(
                expanded ? 0.18 : 0.06,
              ),
              blurRadius: expanded ? 22 : 13,
              offset: const Offset(0, 7),
            ),
          ],
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                children: [
                  // NUMBER
                  Container(
                    width: 34,
                    height: 34,
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: color.withOpacity(0.25),
                      ),
                    ),
                    child: Center(
                      child: Text(
                        number.toString().padLeft(2, '0'),
                        style: TextStyle(
                          color: color,
                          fontSize: 9.5,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(width: 10),

                  // ICON
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          color.withOpacity(0.18),
                          color.withOpacity(0.06),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(13),
                    ),
                    child: Icon(
                      item.icon,
                      color: color,
                      size: 20,
                    ),
                  ),

                  const SizedBox(width: 11),

                  // TITLE
                  Expanded(
                    child: Column(
                      crossAxisAlignment:
                          CrossAxisAlignment.start,
                      children: [
                        Text(
                          item.title,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: _MC.textDark,
                            fontSize: 12.5,
                            fontWeight: FontWeight.w900,
                            height: 1.25,
                          ),
                        ),

                        const SizedBox(height: 4),

                        Text(
                          item.description,
                          maxLines: expanded ? 3 : 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: _MC.textGrey,
                            fontSize: 9.5,
                            height: 1.3,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(width: 7),

                  AnimatedRotation(
                    turns: expanded ? 0.5 : 0,
                    duration: const Duration(
                      milliseconds: 280,
                    ),
                    curve: Curves.easeOutCubic,
                    child: Icon(
                      Icons.keyboard_arrow_down_rounded,
                      color: expanded
                          ? color
                          : _MC.textLight,
                      size: 21,
                    ),
                  ),
                ],
              ),
            ),

            AnimatedCrossFade(
              duration: const Duration(milliseconds: 280),
              sizeCurve: Curves.easeOutCubic,
              firstChild: const SizedBox.shrink(),
              secondChild: _buildExpandedContent(),
              crossFadeState: expanded
                  ? CrossFadeState.showSecond
                  : CrossFadeState.showFirst,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildExpandedContent() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        14,
        0,
        14,
        14,
      ),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: item.color.withOpacity(0.055),
          borderRadius: BorderRadius.circular(15),
          border: Border.all(
            color: item.color.withOpacity(0.14),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              item.detail,
              style: const TextStyle(
                color: _MC.textGrey,
                fontSize: 10.5,
                height: 1.5,
                fontWeight: FontWeight.w600,
              ),
            ),

            if (item.points.isNotEmpty) ...[
              const SizedBox(height: 12),

              ...item.points.map(
                (point) => Padding(
                  padding: const EdgeInsets.only(
                    bottom: 7,
                  ),
                  child: Row(
                    crossAxisAlignment:
                        CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: const EdgeInsets.only(
                          top: 4,
                        ),
                        width: 6,
                        height: 6,
                        decoration: BoxDecoration(
                          color: item.color,
                          shape: BoxShape.circle,
                        ),
                      ),

                      const SizedBox(width: 9),

                      Expanded(
                        child: Text(
                          point,
                          style: const TextStyle(
                            color: _MC.textDark,
                            fontSize: 10,
                            height: 1.4,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

// ============================================================
// 🗂️ CATEGORY DATA
// ============================================================

class _CategoryData {
  final _GuideCategory category;
  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;

  const _CategoryData({
    required this.category,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.color,
  });
}

// ============================================================
// 🌌 ANIMATED RED BACKGROUND
// ============================================================

class _AnimatedRedBackground extends StatelessWidget {
  final AnimationController controller;

  const _AnimatedRedBackground({
    required this.controller,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) {
        return CustomPaint(
          painter: _RedBackgroundPainter(
            controller.value,
          ),
        );
      },
    );
  }
}

class _RedBackgroundPainter extends CustomPainter {
  final double t;

  _RedBackgroundPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(
      Offset.zero & size,
      Paint()..color = _MC.bg,
    );

    // --------------------------------------------------------
    // GRID
    // --------------------------------------------------------

    final gridPaint = Paint()
      ..color = _MC.redLight.withOpacity(0.1)
      ..strokeWidth = 0.6;

    const gridSize = 42.0;

    for (
      double x = 0;
      x <= size.width;
      x += gridSize
    ) {
      canvas.drawLine(
        Offset(x, 0),
        Offset(x, size.height),
        gridPaint,
      );
    }

    for (
      double y = 0;
      y <= size.height;
      y += gridSize
    ) {
      canvas.drawLine(
        Offset(0, y),
        Offset(size.width, y),
        gridPaint,
      );
    }

    // --------------------------------------------------------
    // TOP GLOW
    // --------------------------------------------------------

    final topPulse =
        math.sin(t * math.pi * 2) * 0.02;

    final topGradient = RadialGradient(
      colors: [
        _MC.red.withOpacity(
          0.12 + topPulse,
        ),
        Colors.transparent,
      ],
      radius: 0.8,
    );

    final topRect = Rect.fromCircle(
      center: Offset(
        size.width * 0.2,
        size.height * 0.08,
      ),
      radius: size.width * 0.8,
    );

    canvas.drawCircle(
      Offset(
        size.width * 0.2,
        size.height * 0.08,
      ),
      size.width * 0.8,
      Paint()
        ..shader = topGradient.createShader(topRect),
    );

    // --------------------------------------------------------
    // BOTTOM GLOW
    // --------------------------------------------------------

    final bottomGradient = RadialGradient(
      colors: [
        _MC.redDark.withOpacity(0.08),
        Colors.transparent,
      ],
      radius: 0.75,
    );

    final bottomCenter = Offset(
      size.width * 0.9,
      size.height * 0.88,
    );

    final bottomRect = Rect.fromCircle(
      center: bottomCenter,
      radius: size.width * 0.6,
    );

    canvas.drawCircle(
      bottomCenter,
      size.width * 0.6,
      Paint()
        ..shader =
            bottomGradient.createShader(bottomRect),
    );

    // --------------------------------------------------------
    // FLOATING DOTS
    // --------------------------------------------------------

    final dotPaint = Paint()
      ..color = _MC.red.withOpacity(0.13);

    for (int i = 0; i < 14; i++) {
      final x = (i * 91.0) % size.width;

      final y =
          ((i * 137.0) +
                  math.sin(
                        t * math.pi * 2 +
                            i,
                      ) *
                      18) %
              size.height;

      canvas.drawCircle(
        Offset(x, y),
        1.5 + (i % 3),
        dotPaint,
      );
    }
  }

  @override
  bool shouldRepaint(
    _RedBackgroundPainter oldDelegate,
  ) {
    return oldDelegate.t != t;
  }
}

// ============================================================
// 🧿 ROLE RING PAINTER
// ============================================================

class _RoleRingPainter extends CustomPainter {
  final Color color;
  final int level;

  _RoleRingPainter({
    required this.color,
    required this.level,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(
      size.width / 2,
      size.height / 2,
    );

    final radius = size.width / 2 - 3;

    // --------------------------------------------------------
    // GLOW
    // --------------------------------------------------------

    final glow = Paint()
      ..color = color.withOpacity(
        0.18 + (level * 0.025),
      )
      ..style = PaintingStyle.stroke
      ..strokeWidth = 5 + level.toDouble()
      ..maskFilter = const MaskFilter.blur(
        BlurStyle.normal,
        7,
      );

    canvas.drawCircle(
      center,
      radius,
      glow,
    );

    // --------------------------------------------------------
    // MAIN RING
    // --------------------------------------------------------

    final main = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.8 + (level * 0.22)
      ..strokeCap = StrokeCap.round;

    canvas.drawCircle(
      center,
      radius,
      main,
    );

    // --------------------------------------------------------
    // INNER RING
    // --------------------------------------------------------

    if (level >= 2) {
      final inner = Paint()
        ..color = color.withOpacity(0.35)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1;

      canvas.drawCircle(
        center,
        radius - 4,
        inner,
      );
    }

    // --------------------------------------------------------
    // DOTS
    // --------------------------------------------------------

    if (level >= 3) {
      final count = 4 + ((level - 3) * 2);

      final dotPaint = Paint()..color = color;

      for (int i = 0; i < count; i++) {
        final angle =
            (i / count) * math.pi * 2;

        final offset = Offset(
          center.dx +
              radius * math.cos(angle),
          center.dy +
              radius * math.sin(angle),
        );

        canvas.drawCircle(
          offset,
          1.4 + (level * 0.12),
          dotPaint,
        );
      }
    }

    // --------------------------------------------------------
    // HIGH LEVEL RING
    // --------------------------------------------------------

    if (level >= 6) {
      final outer = Paint()
        ..color = color.withOpacity(0.55)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.2;

      canvas.drawCircle(
        center,
        radius + 3,
        outer,
      );
    }

    // --------------------------------------------------------
    // CROWN
    // --------------------------------------------------------

    if (level >= 7) {
      final crownPaint = Paint()
        ..color = color;

      for (int i = -1; i <= 1; i++) {
        final angle =
            -math.pi / 2 + (i * 0.35);

        final point = Offset(
          center.dx +
              (radius + 5) *
                  math.cos(angle),
          center.dy +
              (radius + 5) *
                  math.sin(angle),
        );

        canvas.drawCircle(
          point,
          2.5,
          crownPaint,
        );
      }
    }

    // --------------------------------------------------------
    // OWNER EFFECT
    // --------------------------------------------------------

    if (level >= 8) {
      final corona = Paint()
        ..color = color.withOpacity(0.22)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 5
        ..maskFilter = const MaskFilter.blur(
          BlurStyle.normal,
          8,
        );

      canvas.drawCircle(
        center,
        radius + 2,
        corona,
      );
    }
  }

  @override
  bool shouldRepaint(
    _RoleRingPainter oldDelegate,
  ) {
    return oldDelegate.color != color ||
        oldDelegate.level != level;
  }
}