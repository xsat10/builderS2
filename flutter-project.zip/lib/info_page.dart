import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'api_config.dart';

class _C {
  static const bg = Color(0xFF060B14);
  static const surface = Color(0xFF0C1424);
  static const card = Color(0xFF101A2E);
  static const cardAlt = Color(0xFF162040);
  static const border = Color(0xFF1A2D4A);
  static const borderLit = Color(0xFF1E3A5F);
  static const blue = Color(0xFF1B6FBD);
  static const blueMid = Color(0xFF2D8FE8);
  static const blueLight = Color(0xFF56AEF5);
  static const green = Color(0xFF22C55E);
  static const amber = Color(0xFFF59E0B);
  static const red = Color(0xFFEF4444);
  static const purple = Color(0xFFA78BFA);
  static const text = Color(0xFFE2EDF9);
  static const textSub = Color(0xFF7A9BBF);
  static const textAmbr = Color(0xFFFFC107);
  static const Color gold = Color(0xFFD4A84C);
  static const Color rose = Color(0xFFC97A7A);
  static const Color sapphire = Color(0xFF4A7AAA);
  static const Color emerald = Color(0xFF4A9A6A);

  static const LinearGradient btnGrad = LinearGradient(
    colors: [blueMid, blueLight],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  static const LinearGradient goldGrad = LinearGradient(
    colors: [Color(0xFFD4A84C), Color(0xFFF5D78A)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

const _rules = [
  _Rule(
    title: 'Larangan Barter Akun',
    desc:  'Akun dan aplikasi Dilarang ditukar kan dengan aplikasi lain, mau barang, dan lain lain.',
    icon:  Icons.swap_horiz_rounded,
    color: Color(0xFFD4A84C),
  ),
  _Rule(
    title: 'Larangan Membagikan Akun',
    desc: 'Setiap akun dilarang di bagikan secara free, atau hadiah.',
    icon:  Icons.share_rounded,
    color: Color(0xFF4A7AAA),
  ),
  _Rule(
    title: 'Larangan Menjual Akun',
    desc:  'Akses bawahan seperti MEMBER, Dilarang keras menjual apk.',
    icon:  Icons.sell_rounded,
    color: Color(0xFFC97A7A),
  ),
  _Rule(
    title: 'Larangan Jual Durasi Ilegal',
    desc: 'Dilarang menjual aplikasi secara ilegal, misalnya buyyer membeli 1h kamu buat 99+h, itu di larang keras!.',
    icon:  Icons.timer_off_rounded,
    color: Color(0xFFA78BFA),
  ),
  _Rule(
    title: 'Larangan Banting Harga',
    desc:  'Dilarang merusak atau menurunkan harga yang telah ditentukan di bawah ketentuan Zenzo X Rat.',
    icon:  Icons.trending_down_rounded,
    color: Color(0xFF4A9A6A),
  ),
];

class _Rule {
  final String title;
  final String desc;
  final IconData icon;
  final Color color;
  const _Rule({required this.title, required this.desc,
      required this.icon, required this.color});
}

const _fallbackServerInfo = {
  'name': 'Zenzo X Rat',
  'version': '4.0',
  'status': 'online',
};

class InfoPage extends StatefulWidget {
  final String sessionKey;
  const InfoPage({super.key, required this.sessionKey});

  @override
  State<InfoPage> createState() => _InfoPageState();
}

class _InfoPageState extends State<InfoPage> with TickerProviderStateMixin {
  Map<String, dynamic> serverInfo = _fallbackServerInfo;
  bool isLoading = false;

  bool   _apiOnline   = false;
  int    _pingMs      = 0;
  String _pingStatus  = 'Checking...';
  Timer? _pingTimer;

  late AnimationController _bgCtrl;
  late AnimationController _entranceCtrl;
  late AnimationController _pingDotCtrl;
  late AnimationController _sanctionCtrl;
  late AnimationController _pulseCtrl;
  late AnimationController _glowCtrl;

  late Animation<double> _entrance;
  late Animation<double> _pingDot;
  late Animation<double> _sanctionGlow;
  late Animation<double> _pulseAnim;
  late Animation<double> _glowAnim;

  int? _expandedRule;

  @override
  void initState() {
    super.initState();

    _bgCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 18))
      ..repeat();

    _entranceCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 700));
    _entrance = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOutCubic);

    _pingDotCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1200))
      ..repeat(reverse: true);
    _pingDot = Tween<double>(begin: 0.3, end: 1.0)
        .animate(CurvedAnimation(parent: _pingDotCtrl, curve: Curves.easeInOut));

    _sanctionCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 2000))
      ..repeat(reverse: true);
    _sanctionGlow = Tween<double>(begin: 0.2, end: 0.6)
        .animate(CurvedAnimation(parent: _sanctionCtrl, curve: Curves.easeInOut));

    _pulseCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.5, end: 1.0)
        .animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));
        
    _glowCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 3))
      ..repeat(reverse: true);
    _glowAnim = Tween<double>(begin: 0.0, end: 1.0)
        .animate(CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut));

    _fetchServerInfo();
    _startPingLoop();
    
    _entranceCtrl.forward();
  }

  @override
  void dispose() {
    _pingTimer?.cancel();
    _bgCtrl.dispose();
    _entranceCtrl.dispose();
    _pingDotCtrl.dispose();
    _sanctionCtrl.dispose();
    _pulseCtrl.dispose();
    _glowCtrl.dispose();
    super.dispose();
  }

  Future<void> _fetchServerInfo() async {
    try {
      final res = await http.get(Uri.parse(
          '$baseUrl/getServerInfo?key=${widget.sessionKey}'));
      if (res.statusCode == 200 && mounted) {
        setState(() { serverInfo = jsonDecode(res.body); });
      }
    } catch (_) {}
  }

  void _startPingLoop() {
    _checkPing();
    _pingTimer = Timer.periodic(const Duration(seconds: 5), (_) => _checkPing());
  }

  Future<void> _checkPing() async {
    final start = DateTime.now();
    try {
      final res = await http.get(Uri.parse(
              '$baseUrl/ping?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 3));
      final ms = DateTime.now().difference(start).inMilliseconds;
      if (res.statusCode == 200 && mounted) {
        setState(() {
          _apiOnline  = true;
          _pingMs     = ms;
          _pingStatus = '${ms}ms';
        });
      } else {
        throw Exception();
      }
    } catch (_) {
      if (mounted) setState(() { 
        _apiOnline = false; 
        _pingMs = 0; 
        _pingStatus = 'Offline'; 
      });
    }
  }

  Color get _pingColor {
    if (!_apiOnline) return _C.red;
    if (_pingMs < 200) return _C.green;
    if (_pingMs < 500) return _C.amber;
    return const Color(0xFFF97316);
  }

  String get _pingLabel {
    if (!_apiOnline) return 'OFFLINE';
    if (_pingMs < 200) return 'EXCELLENT';
    if (_pingMs < 500) return 'GOOD';
    return 'SLOW';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      extendBodyBehindAppBar: true,
      appBar: _buildAppBar(),
      body: Stack(
        children: [
          Positioned.fill(child: _AnimatedBg(controller: _bgCtrl)),
          SafeArea(
            child: FadeTransition(
              opacity: _entrance,
              child: ListView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 48),
                children: [
                  _buildHeroHeader(),
                  const SizedBox(height: 20),
                  _buildStatusCardModern(),
                  const SizedBox(height: 24),
                  _buildRulesHeader(),
                  const SizedBox(height: 16),
                  ..._rules.asMap().entries.map((e) =>
                    Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: _ElegantRuleCard(
                        rule: e.value,
                        number: e.key + 1,
                        isExpanded: _expandedRule == e.key,
                        onTap: () => setState(() {
                          _expandedRule = _expandedRule == e.key ? null : e.key;
                        }),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  _buildSanctionCardModern(),
                  const SizedBox(height: 24),
                  _buildFooter(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeroHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [_C.gold.withOpacity(0.2), _C.gold.withOpacity(0.05)],
                  ),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: _C.gold.withOpacity(0.2)),
                ),
                child: const Icon(Icons.gavel_rounded, color: _C.gold, size: 24),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ShaderMask(
                      shaderCallback: (rect) => LinearGradient(
                        colors: [_C.text, _C.gold],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ).createShader(rect),
                      child: const Text('Regulations',
                          style: TextStyle(
                            color: _C.text,
                            fontSize: 26,
                            fontWeight: FontWeight.w800,
                            letterSpacing: -0.5,
                          )),
                    ),
                    const Text('Zenzo Rules & Guidelines',
                        style: TextStyle(color: _C.textSub, fontSize: 12,
                            letterSpacing: 0.5)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [_C.gold.withOpacity(0.08), _C.gold.withOpacity(0.02)],
              ),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _C.gold.withOpacity(0.1)),
            ),
            child: Row(
              children: [
                Icon(Icons.info_outline_rounded, color: _C.gold, size: 16),
                const SizedBox(width: 10),
                const Expanded(
                  child: Text('Patuhi aturan untuk kenyamanan bersama',
                      style: TextStyle(color: _C.textSub, fontSize: 12,
                          fontWeight: FontWeight.w500)),
                ),
                Container(
                  width: 6,
                  height: 6,
                  decoration: BoxDecoration(
                    color: _C.gold,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(color: _C.gold.withOpacity(0.4), blurRadius: 8),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusCardModern() {
    return AnimatedBuilder(
      animation: _pulseAnim,
      builder: (_, __) => Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [_C.card, _C.surface],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: _apiOnline ? _pingColor.withOpacity(0.2) : _C.red.withOpacity(0.2),
            width: 0.8,
          ),
          boxShadow: [
            BoxShadow(
              color: (_apiOnline ? _pingColor : _C.red).withOpacity(0.05),
              blurRadius: 30,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 56,
              height: 56,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    (_apiOnline ? _pingColor : _C.red).withOpacity(0.12),
                    (_apiOnline ? _pingColor : _C.red).withOpacity(0.04),
                  ],
                ),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: (_apiOnline ? _pingColor : _C.red).withOpacity(0.15),
                  width: 0.8,
                ),
              ),
              child: Icon(
                _apiOnline ? Icons.check_circle_rounded : Icons.error_rounded,
                color: _apiOnline ? _pingColor : _C.red,
                size: 28,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('SERVER STATUS',
                      style: TextStyle(
                          color: _C.textAmbr, fontSize: 10,
                          fontWeight: FontWeight.w700, letterSpacing: 1.2)),
                  const SizedBox(height: 6),
                  Text(_apiOnline ? 'Online' : 'Offline',
                      style: TextStyle(
                          color: _apiOnline ? _pingColor : _C.red,
                          fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 4),
                  Text(_apiOnline ? 'Connected & Active' : 'Connection Lost',
                      style: TextStyle(color: _C.textSub, fontSize: 11)),
                ],
              ),
            ),
            Container(
              width: 60,
              height: 60,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  SizedBox(
                    width: 54,
                    height: 54,
                    child: CircularProgressIndicator(
                      value: _apiOnline ? (_pingMs / 500).clamp(0.0, 1.0) : 0,
                      strokeWidth: 3,
                      backgroundColor: _C.border,
                      color: _pingColor,
                    ),
                  ),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(_apiOnline ? '$_pingMs' : '--',
                          style: TextStyle(
                              color: _pingColor, fontSize: 14,
                              fontWeight: FontWeight.bold)),
                      Text('ms',
                          style: TextStyle(
                              color: _C.textSub, fontSize: 8,
                              fontWeight: FontWeight.w500)),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRulesHeader() {
    return Row(
      children: [
        Container(
          width: 3,
          height: 24,
          decoration: BoxDecoration(
            gradient: _C.goldGrad,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 12),
        const Text('RULES',
            style: TextStyle(color: _C.text, fontSize: 17,
                fontWeight: FontWeight.w700, letterSpacing: 1.5)),
        const Spacer(),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [_C.gold.withOpacity(0.15), _C.gold.withOpacity(0.05)],
            ),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: _C.gold.withOpacity(0.2)),
          ),
          child: Row(
            children: [
              Icon(Icons.list_alt_rounded, color: _C.gold, size: 12),
              const SizedBox(width: 4),
              Text('${_rules.length}',
                  style: const TextStyle(color: _C.gold, fontSize: 12,
                      fontWeight: FontWeight.bold)),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildSanctionCardModern() {
    return AnimatedBuilder(
      animation: _sanctionCtrl,
      builder: (_, __) => Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [_C.card, _C.surface],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: _C.red.withOpacity(0.15 + _sanctionGlow.value * 0.15),
            width: 0.8,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [_C.red.withOpacity(0.12), _C.red.withOpacity(0.04)],
                      ),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: _C.red.withOpacity(0.15)),
                    ),
                    child: Icon(Icons.warning_rounded,
                        color: _C.red.withOpacity(0.7 + _sanctionGlow.value * 0.3),
                        size: 22),
                  ),
                  const SizedBox(width: 14),
                  const Expanded(
                    child: Text('SANCTIONS',
                        style: TextStyle(color: _C.red, fontSize: 15,
                            fontWeight: FontWeight.w700, letterSpacing: 1)),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: _C.red.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: _C.red.withOpacity(0.2)),
                    ),
                    child: Text('PERMANENT',
                        style: TextStyle(color: _C.red, fontSize: 9,
                            fontWeight: FontWeight.w700, letterSpacing: 0.8)),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: _C.surface,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: _C.border),
                ),
                child: Row(
                  children: [
                    Icon(Icons.block_rounded, color: _C.red, size: 20),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Text('Akun dihapus & BlackList Permanent',
                          style: TextStyle(color: _C.text, fontSize: 13,
                              fontWeight: FontWeight.w600)),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  _sanctionChip(Icons.account_balance_wallet_rounded, 'No Reff'),
                  const SizedBox(width: 6),
                  _sanctionChip(Icons.sync_disabled_rounded, 'Tanpa Kasihan'),
                  const SizedBox(width: 6),
                  _sanctionChip(Icons.person_off_rounded, 'BlackList'),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _sanctionChip(IconData icon, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: _C.red.withOpacity(0.06),
        border: Border.all(color: _C.red.withOpacity(0.12)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: _C.red, size: 11),
          const SizedBox(width: 4),
          Text(label,
              style: const TextStyle(color: _C.textSub, fontSize: 9,
                  fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }

  Widget _buildFooter() {
    return Column(children: [
      Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [_C.card, _C.surface],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _C.border),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(Icons.shield_moon_rounded, color: _C.gold, size: 18),
            const SizedBox(width: 12),
            const Expanded(
              child: Text(
                'Terimakasih telah memakai dan membeli apk ini. '
                'Saya harap pengguna sudah menyetujui seluruh rules yang berlaku.',
                style: TextStyle(color: _C.textSub, fontSize: 11, height: 1.6),
              ),
            ),
          ],
        ),
      ),
      const SizedBox(height: 16),
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        Container(
          height: 1.5, width: 24,
          decoration: BoxDecoration(
            gradient: _C.goldGrad,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 10),
        Text('✦ ZENZO x RAT ✦',
            style: TextStyle(color: _C.gold, fontSize: 10,
                fontWeight: FontWeight.w600, letterSpacing: 0.5)),
        const SizedBox(width: 10),
        Container(
          height: 1.5, width: 24,
          decoration: BoxDecoration(
            gradient: _C.goldGrad,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
      ]),
    ]);
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      automaticallyImplyLeading: false,
      title: const SizedBox.shrink(),
    );
  }
}

class _ElegantRuleCard extends StatelessWidget {
  final _Rule rule;
  final int number;
  final bool isExpanded;
  final VoidCallback onTap;

  const _ElegantRuleCard({
    required this.rule,
    required this.number,
    required this.isExpanded,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final color = rule.color;

    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 350),
        curve: Curves.easeInOut,
        decoration: BoxDecoration(
          gradient: isExpanded 
              ? LinearGradient(
                  colors: [color.withOpacity(0.06), _C.card],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : null,
          color: isExpanded ? null : _C.card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isExpanded ? color.withOpacity(0.3) : _C.border,
            width: isExpanded ? 1.2 : 0.8,
          ),
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(14),
              child: Row(
                children: [
                  Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [color.withOpacity(0.15), color.withOpacity(0.04)],
                      ),
                      shape: BoxShape.circle,
                      border: Border.all(color: color.withOpacity(0.2)),
                    ),
                    child: Center(
                      child: Text('$number',
                          style: TextStyle(color: color, fontSize: 12,
                              fontWeight: FontWeight.bold)),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Container(
                    width: 34,
                    height: 34,
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.06),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(rule.icon, color: color, size: 17),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(rule.title,
                        style: TextStyle(
                          color: isExpanded ? color : _C.text,
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          letterSpacing: 0.3,
                        )),
                  ),
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    transform: Matrix4.rotationZ(isExpanded ? math.pi : 0),
                    child: Container(
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: isExpanded ? color.withOpacity(0.1) : Colors.transparent,
                      ),
                      child: Icon(Icons.keyboard_arrow_down_rounded,
                          color: isExpanded ? color : _C.textAmbr, size: 18),
                    ),
                  ),
                ],
              ),
            ),
            AnimatedCrossFade(
              firstChild: const SizedBox(width: double.infinity),
              secondChild: Padding(
                padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
                child: Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [_C.surface, _C.bg],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: color.withOpacity(0.08)),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: 2,
                        height: 28,
                        decoration: BoxDecoration(
                          color: color,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(rule.desc,
                            style: TextStyle(color: _C.textSub, fontSize: 12,
                                height: 1.6, letterSpacing: 0.2)),
                      ),
                    ],
                  ),
                ),
              ),
              crossFadeState: isExpanded
                  ? CrossFadeState.showSecond
                  : CrossFadeState.showFirst,
              duration: const Duration(milliseconds: 350),
            ),
          ],
        ),
      ),
    );
  }
}

class _AnimatedBg extends StatelessWidget {
  final AnimationController controller;
  const _AnimatedBg({required this.controller});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) =>
          CustomPaint(painter: _BgPainter(controller.value)),
    );
  }
}

class _BgPainter extends CustomPainter {
  final double t;
  _BgPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()
      ..color = _C.border.withOpacity(0.15)
      ..strokeWidth = 0.3;
    const step = 36.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
    
    final glow = Paint()
      ..shader = RadialGradient(colors: [
        _C.gold.withOpacity(0.04 + math.sin(t * math.pi * 2) * 0.015),
        Colors.transparent,
      ], radius: 0.8).createShader(Rect.fromCircle(
          center: Offset(size.width * 0.3, size.height * 0.2),
          radius: size.width * 0.6));
    canvas.drawCircle(
        Offset(size.width * 0.3, size.height * 0.2), size.width * 0.6, glow);
        
    final glow2 = Paint()
      ..shader = RadialGradient(colors: [
        _C.blueMid.withOpacity(0.03 + math.cos(t * math.pi * 2) * 0.01),
        Colors.transparent,
      ], radius: 0.6).createShader(Rect.fromCircle(
          center: Offset(size.width * 0.8, size.height * 0.8),
          radius: size.width * 0.4));
    canvas.drawCircle(
        Offset(size.width * 0.8, size.height * 0.8), size.width * 0.4, glow2);
  }

  @override
  bool shouldRepaint(_BgPainter old) => old.t != t;
}