import 'package:flutter/material.dart';
import 'webview_tool_shell.dart';

class McHubPage extends StatelessWidget {
  const McHubPage({super.key});

  @override
  Widget build(BuildContext context) => const McWebViewShell(
        title: 'McHub',
        subtitle: 'GitHub Web • Real-time',
        initialUrl: 'https://github.com/',
        accent: Color(0xFFEDEDED),
        icon: Icons.code_rounded,
      );
}
