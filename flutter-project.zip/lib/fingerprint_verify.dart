import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:local_auth/local_auth.dart';

// ═══════════════════════════════════════════════════════════════════
// PALETTE — HITAM + PUTIH GLOW
// ═══════════════════════════════════════════════════════════════════
class _FPC {
  static const bg            = Color(0xFF000000);
  static const surface       = Color(0xFF121212);
  static const card          = Color(0xFF1A1A1A);
  static const cardAlt       = Color(0xFF222222);

  static const border        = Color(0xFFFFFFFF);
  static const borderLit     = Color(0xFFE0E0E0);
  static const primary       = Color(0xFFFFFFFF);
  static const primaryMid    = Color(0xFFE0E0E0);
  static const primaryLight  = Color(0xFFFFFFFF);
  static const accent        = Color(0xFFFFFFFF);

  static const text          = Color(0xFFFFFFFF);
  static const textSub       = Color(0xFFB0B0B0);
  static const textDim       = Color(0xFF808080);

  static const luxeGrad = LinearGradient(
    colors: [Color(0xFFFFFFFF), Color(0xFFE0E0E0)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const softGrad = LinearGradient(
    colors: [Color(0xFF000000), Color(0xFF0A0A0A), Color(0xFF000000)],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );

  static const textGrad = LinearGradient(
    colors: [Color(0xFFFFFFFF), Color(0xFFE0E0E0)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

// ═══════════════════════════════════════════════════════════════════
// STATE AUTH
// ═══════════════════════════════════════════════════════════════════
enum _AuthState { idle, scanning, success, failed, unavailable }

// ═══════════════════════════════════════════════════════════════════
// HALAMAN VERIFIKASI SIDIK JARI
// ═══════════════════════════════════════════════════════════════════
class FingerprintVerifyPage extends StatefulWidget {
  final VoidCallback onVerified;
  final VoidCallback? onCancel;
  final Duration duration;
  final String title;
  final String subtitle;

  const FingerprintVerifyPage({
    super.key,
    required this.onVerified,
    this.onCancel,
    this.duration = const Duration(milliseconds: 1800),
    this.title = 'VERIFIKASI SIDIK JARI',
    this.subtitle = 'Scan sidik jari kamu untuk lanjut',
  });

  @override
  State<FingerprintVerifyPage> createState() => _FingerprintVerifyPageState();
}

class _FingerprintVerifyPageState extends State<FingerprintVerifyPage>
    with TickerProviderStateMixin {

  final _auth = LocalAuthentication();

  _AuthState _state = _AuthState.idle;
  String _failMsg   = '';
  double _progress  = 0.0;

  late AnimationController _glowController;
  late AnimationController _rotateController;
  late AnimationController _pulseController;

  @override
  void initState() {
    super.initState();

    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);

    _rotateController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 3000),
    )..repeat();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );

    // Auto-trigger biometrik setelah page siap
    Future.delayed(const Duration(milliseconds: 400), _checkAndAuth);
  }

  @override
  void dispose() {
    _glowController.dispose();
    _rotateController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  // ─── Cek ketersediaan lalu auth ───
  Future<void> _checkAndAuth() async {
    if (!mounted) return;

    try {
      final canCheck  = await _auth.canCheckBiometrics;
      final supported = await _auth.isDeviceSupported();

      if (!canCheck && !supported) {
        if (mounted) {
          setState(() {
            _state   = _AuthState.unavailable;
            _failMsg = 'Perangkat tidak mendukung sidik jari';
          });
        }
        return;
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          _state   = _AuthState.unavailable;
          _failMsg = 'Biometrik tidak tersedia di HP ini';
        });
      }
      return;
    }

    await _authenticate();
  }

  // ─── Jalankan autentikasi sidik jari ───
  Future<void> _authenticate() async {
    if (!mounted) return;

    setState(() {
      _state   = _AuthState.scanning;
      _failMsg = '';
    });

    _pulseController.repeat(reverse: true);
    _animateProgress(to: 0.5);

    try {
      final bool ok = await _auth.authenticate(
        localizedReason: 'Verifikasi sidik jari untuk masuk ke aplikasi',
        options: const AuthenticationOptions(
          stickyAuth: true,
          biometricOnly: false, // bisa fallback ke PIN kalau perlu
        ),
      );

      if (!mounted) return;
      _pulseController.stop();
      _pulseController.reset();

      if (ok) {
        _animateProgress(to: 1.0);
        setState(() => _state = _AuthState.success);
        HapticFeedback.heavyImpact();
        Future.delayed(const Duration(milliseconds: 600), () {
          if (mounted) widget.onVerified();
        });
      } else {
        _animateProgress(to: 0.0);
        setState(() {
          _state   = _AuthState.failed;
          _failMsg = 'Sidik jari tidak dikenali';
        });
        HapticFeedback.vibrate();
      }

    } on PlatformException catch (e) {
      if (!mounted) return;
      _pulseController.stop();
      _pulseController.reset();
      _animateProgress(to: 0.0);

      String msg;
      switch (e.code) {
        case 'NotEnrolled':
          msg = 'Belum ada sidik jari terdaftar di HP ini';
        case 'LockedOut':
        case 'PermanentlyLockedOut':
          msg = 'Terlalu banyak percobaan gagal, coba nanti';
        case 'NotAvailable':
          msg = 'Sidik jari tidak tersedia';
        default:
          msg = 'Verifikasi gagal, coba lagi';
      }

      setState(() {
        _state   = _AuthState.failed;
        _failMsg = msg;
      });
      HapticFeedback.vibrate();

    } catch (_) {
      if (!mounted) return;
      _pulseController.stop();
      _pulseController.reset();
      _animateProgress(to: 0.0);
      setState(() {
        _state   = _AuthState.failed;
        _failMsg = 'Verifikasi gagal';
      });
    }
  }

  // ─── Animasi progress arc ───
  void _animateProgress({required double to}) {
    final start     = _progress;
    final startTime = DateTime.now();
    const durationMs = 300;

    Timer.periodic(const Duration(milliseconds: 16), (t) {
      if (!mounted) { t.cancel(); return; }
      final elapsed = DateTime.now().difference(startTime).inMilliseconds;
      final factor  = (elapsed / durationMs).clamp(0.0, 1.0);
      setState(() => _progress = start + (to - start) * factor);
      if (elapsed >= durationMs) t.cancel();
    });
  }

  // ─── Batal → ke halaman login ───
  void _goToLogin() {
    widget.onCancel?.call();
    Navigator.pushReplacementNamed(context, '/login');
  }

  @override
  Widget build(BuildContext context) {
    const size = 240.0;

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _goToLogin();
      },
      child: Scaffold(
        backgroundColor: _FPC.bg,
        body: Stack(
          children: [
            // ─── Background gradient ───
            Positioned.fill(
              child: Container(
                decoration: const BoxDecoration(gradient: _FPC.softGrad),
              ),
            ),
            Positioned.fill(
              child: CustomPaint(painter: _FpGridPainter()),
            ),

            SafeArea(
              child: Column(
                children: [
                  // ─── Header ───
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
                    child: Row(
                      children: [
                        GestureDetector(
                          onTap: _goToLogin,
                          child: Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: _FPC.card,
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(color: _FPC.border, width: 2),
                              boxShadow: [
                                BoxShadow(
                                  color: _FPC.primary.withOpacity(0.25),
                                  blurRadius: 10,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                            ),
                            child: const Icon(
                              Icons.arrow_back_rounded,
                              color: _FPC.primary,
                              size: 20,
                            ),
                          ),
                        ),
                        const Spacer(),
                      ],
                    ),
                  ),

                  const Spacer(),

                  // ─── Judul ───
                  AnimatedBuilder(
                    animation: _rotateController,
                    builder: (context, _) {
                      return ShaderMask(
                        shaderCallback: (b) => LinearGradient(
                          begin: Alignment(
                              -1.0 + _rotateController.value * 2, 0.0),
                          end: Alignment(
                              1.0 + _rotateController.value * 2, 0.0),
                          colors: const [
                            Color(0xFF808080),
                            Color(0xFFFFFFFF),
                            Color(0xFFFFFFFF),
                            Color(0xFFFFFFFF),
                            Color(0xFF808080),
                          ],
                          stops: const [0.0, 0.3, 0.5, 0.7, 1.0],
                        ).createShader(b),
                        child: Text(
                          widget.title,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Orbitron',
                            letterSpacing: 3,
                            shadows: [
                              Shadow(color: Colors.white, blurRadius: 15),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 12),

                  // ─── Subtitle dinamis per state ───
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 300),
                    child: Text(
                      _state == _AuthState.scanning
                          ? 'Tempelkan jari ke sensor...'
                          : _state == _AuthState.success
                              ? 'Terverifikasi!'
                              : _state == _AuthState.failed
                                  ? _failMsg
                                  : _state == _AuthState.unavailable
                                      ? _failMsg
                                      : widget.subtitle,
                      key: ValueKey(_state),
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: _state == _AuthState.success
                            ? const Color(0xFF00FF00)
                            : _state == _AuthState.failed ||
                                    _state == _AuthState.unavailable
                                ? const Color(0xFFFF4444)
                                : _FPC.textSub,
                        fontSize: 13,
                        fontFamily: 'Aktura',
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),

                  const SizedBox(height: 60),

                  // ─── Ring animasi ───
                  AnimatedBuilder(
                    animation: Listenable.merge([
                      _glowController,
                      _rotateController,
                      _pulseController,
                    ]),
                    builder: (context, _) {
                      final glow    = _glowController.value;
                      final rotate  = _rotateController.value;
                      final scanProgress = _state == _AuthState.scanning
                          ? 0.3 + _pulseController.value * 0.45
                          : _progress;
                      final pulse   = _state == _AuthState.scanning
                          ? (0.92 + _pulseController.value * 0.10)
                          : 1.0;

                      return Transform.scale(
                        scale: pulse,
                        child: SizedBox(
                          width: size,
                          height: size,
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              // Glow outer
                              Container(
                                width: size,
                                height: size,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  boxShadow: [
                                    BoxShadow(
                                      color: _state == _AuthState.success
                                          ? const Color(0xFF00FF00)
                                              .withOpacity(0.4)
                                          : _state == _AuthState.failed
                                              ? const Color(0xFFFF4444)
                                                  .withOpacity(0.3)
                                              : _FPC.primary.withOpacity(
                                                  0.25 +
                                                      glow * 0.35 +
                                                      scanProgress * 0.4,
                                                ),
                                      blurRadius:
                                          30 + glow * 20 + scanProgress * 30,
                                      spreadRadius: 2 + scanProgress * 4,
                                    ),
                                  ],
                                ),
                              ),

                              // Ring painter
                              CustomPaint(
                                size: const Size(size, size),
                                painter: _FingerprintRingPainter(
                                  rotation: rotate * 2 * math.pi,
                                  progress: scanProgress,
                                  stateColor: _state == _AuthState.success
                                      ? const Color(0xFF00FF00)
                                      : _state == _AuthState.failed
                                          ? const Color(0xFFFF4444)
                                          : Colors.white,
                                ),
                              ),

                              // Inner circle
                              Container(
                                width: size - 20,
                                height: size - 20,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: _FPC.card,
                                  border: Border.all(
                                    color: _FPC.border.withOpacity(
                                      0.5 + glow * 0.4 + scanProgress * 0.5,
                                    ),
                                    width: 2.5,
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: _FPC.primary.withOpacity(0.3),
                                      blurRadius: 20,
                                      offset: const Offset(0, 8),
                                    ),
                                  ],
                                ),
                              ),

                              // Icon
                              Icon(
                                _state == _AuthState.success
                                    ? Icons.check_rounded
                                    : _state == _AuthState.failed ||
                                            _state == _AuthState.unavailable
                                        ? Icons.fingerprint_rounded
                                        : Icons.fingerprint_rounded,
                                size: size * 0.4,
                                color: _state == _AuthState.success
                                    ? const Color(0xFF00FF00)
                                    : _state == _AuthState.failed ||
                                            _state == _AuthState.unavailable
                                        ? const Color(0xFFFF4444)
                                            .withOpacity(0.8)
                                        : _FPC.primary,
                                shadows: [
                                  Shadow(
                                    color: (_state == _AuthState.success
                                            ? const Color(0xFF00FF00)
                                            : _FPC.primary)
                                        .withOpacity(0.7 + glow * 0.3),
                                    blurRadius: 20 + scanProgress * 20,
                                  ),
                                ],
                              ),

                              // Persentase / status
                              Positioned(
                                bottom: size * 0.10,
                                child: AnimatedSwitcher(
                                  duration: const Duration(milliseconds: 300),
                                  child: _state == _AuthState.scanning
                                      ? Text(
                                          '${(scanProgress * 100).toInt()}%',
                                          key: const ValueKey('pct'),
                                          style: const TextStyle(
                                            color: _FPC.primary,
                                            fontSize: 16,
                                            fontWeight: FontWeight.w900,
                                            fontFamily: 'Orbitron',
                                            letterSpacing: 1,
                                            shadows: [
                                              Shadow(
                                                color: Colors.white,
                                                blurRadius: 10,
                                              ),
                                            ],
                                          ),
                                        )
                                      : const SizedBox.shrink(
                                          key: ValueKey('empty'),
                                        ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),

                  const SizedBox(height: 30),

                  // ─── Status bar bawah ring ───
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 300),
                    child: _buildStatusChip(),
                  ),

                  const Spacer(),

                  // ─── Tombol aksi ───
                  _buildActionButtons(),

                  const SizedBox(height: 40),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusChip() {
    String label;
    switch (_state) {
      case _AuthState.scanning:
        label = 'MEMINDAI...';
      case _AuthState.success:
        label = 'BERHASIL ✓';
      case _AuthState.failed:
        label = 'GAGAL — COBA LAGI';
      case _AuthState.unavailable:
        label = 'SIDIK JARI TIDAK TERSEDIA';
      case _AuthState.idle:
        label = 'SIAP MEMINDAI';
    }

    return Container(
      key: ValueKey(_state),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      decoration: BoxDecoration(
        color: _FPC.card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: _state == _AuthState.success
              ? const Color(0xFF00FF00)
              : _state == _AuthState.failed || _state == _AuthState.unavailable
                  ? const Color(0xFFFF4444)
                  : _FPC.border,
          width: 2,
        ),
        boxShadow: [
          BoxShadow(
            color: _FPC.primary.withOpacity(0.25),
            blurRadius: 12,
          ),
        ],
      ),
      child: Text(
        label,
        style: TextStyle(
          color: _state == _AuthState.success
              ? const Color(0xFF00FF00)
              : _state == _AuthState.failed || _state == _AuthState.unavailable
                  ? const Color(0xFFFF4444)
                  : _FPC.primary,
          fontSize: 12,
          fontWeight: FontWeight.w800,
          fontFamily: 'Orbitron',
          letterSpacing: 2,
          shadows: const [Shadow(color: Colors.white, blurRadius: 10)],
        ),
      ),
    );
  }

  Widget _buildActionButtons() {
    if (_state == _AuthState.scanning || _state == _AuthState.success) {
      return const SizedBox.shrink();
    }

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Tombol Coba Lagi (kalau failed)
        if (_state == _AuthState.failed) ...[
          GestureDetector(
            onTap: _authenticate,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
              decoration: BoxDecoration(
                color: _FPC.card,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: _FPC.border, width: 2),
                boxShadow: [
                  BoxShadow(
                    color: _FPC.primary.withOpacity(0.25),
                    blurRadius: 12,
                  ),
                ],
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.refresh_rounded, color: _FPC.primary, size: 16),
                  SizedBox(width: 8),
                  Text(
                    'COBA LAGI',
                    style: TextStyle(
                      color: _FPC.primary,
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                      fontFamily: 'Orbitron',
                      letterSpacing: 2,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
        ],

        // Tombol Login dengan Password (selalu ada waktu failed/unavailable/idle)
        GestureDetector(
          onTap: _goToLogin,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
            decoration: BoxDecoration(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                  color: _FPC.border.withOpacity(0.4), width: 1.5),
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.lock_open_rounded,
                    color: _FPC.textSub, size: 16),
                SizedBox(width: 8),
                Text(
                  'LOGIN DENGAN PASSWORD',
                  style: TextStyle(
                    color: _FPC.textSub,
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// PAINTER: RING BERPUTAR + PROGRESS ARC
// ═══════════════════════════════════════════════════════════════════
class _FingerprintRingPainter extends CustomPainter {
  final double rotation;
  final double progress;
  final Color  stateColor;

  _FingerprintRingPainter({
    required this.rotation,
    required this.progress,
    this.stateColor = Colors.white,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 4;

    // ─── 1. Ring putih berputar ───
    final sweepPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.5
      ..strokeCap = StrokeCap.round
      ..shader = SweepGradient(
        transform: GradientRotation(rotation),
        colors: [
          Colors.transparent,
          stateColor,
          stateColor,
          Colors.transparent,
        ],
        stops: const [0.0, 0.3, 0.7, 1.0],
      ).createShader(Rect.fromCircle(center: center, radius: radius));

    canvas.drawCircle(center, radius, sweepPaint);

    // ─── 2. Glow ring ───
    final glowPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 8
      ..strokeCap = StrokeCap.round
      ..shader = SweepGradient(
        transform: GradientRotation(rotation),
        colors: [
          Colors.transparent,
          stateColor.withOpacity(0.7),
          Colors.transparent,
        ],
        stops: const [0.0, 0.5, 1.0],
      ).createShader(Rect.fromCircle(center: center, radius: radius))
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6);

    canvas.drawCircle(center, radius, glowPaint);

    // ─── 3. Track background ───
    final trackPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 5
      ..color = stateColor.withOpacity(0.15);
    canvas.drawCircle(center, radius - 10, trackPaint);

    // ─── 4. Progress arc ───
    if (progress > 0) {
      final progressPaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 6
        ..strokeCap = StrokeCap.round
        ..color = stateColor;

      final rect = Rect.fromCircle(center: center, radius: radius - 10);
      canvas.drawArc(rect, -math.pi / 2, progress * 2 * math.pi, false,
          progressPaint);

      // ─── 5. Glow progress ───
      final glowProgress = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 10
        ..strokeCap = StrokeCap.round
        ..color = stateColor.withOpacity(0.5)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8);

      canvas.drawArc(rect, -math.pi / 2, progress * 2 * math.pi, false,
          glowProgress);

      // ─── 6. Titik ujung progress ───
      final endAngle = -math.pi / 2 + progress * 2 * math.pi;
      final dotX = center.dx + (radius - 10) * math.cos(endAngle);
      final dotY = center.dy + (radius - 10) * math.sin(endAngle);

      canvas.drawCircle(
        Offset(dotX, dotY),
        8,
        Paint()
          ..color = stateColor.withOpacity(0.5)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
      );
      canvas.drawCircle(
          Offset(dotX, dotY), 4, Paint()..color = stateColor);
      canvas.drawCircle(
          Offset(dotX, dotY), 2, Paint()..color = Colors.black);
    }

    // ─── 7. Partikel titik berputar ───
    if (progress > 0.1) {
      final dotPaint = Paint()..color = stateColor.withOpacity(0.9);
      final dots = (progress * 12).round();
      for (int i = 0; i < dots; i++) {
        final angle = (i / dots) * 2 * math.pi + rotation;
        final pos = Offset(
          center.dx + (radius + 8) * math.cos(angle),
          center.dy + (radius + 8) * math.sin(angle),
        );
        canvas.drawCircle(pos, 2, dotPaint);
      }
    }
  }

  @override
  bool shouldRepaint(_FingerprintRingPainter old) =>
      old.rotation != rotation ||
      old.progress != progress ||
      old.stateColor != stateColor;
}

// ═══════════════════════════════════════════════════════════════════
// PAINTER: GRID PUTIH
// ═══════════════════════════════════════════════════════════════════
class _FpGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()
      ..color = _FPC.border.withOpacity(0.10)
      ..strokeWidth = 0.5;
    const step = 45.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

// ═══════════════════════════════════════════════════════════════════
// WIDGET INLINE: TEKAN & TAHAN (tidak berubah — untuk penggunaan lain)
// ═══════════════════════════════════════════════════════════════════
class FingerprintVerifyWidget extends StatefulWidget {
  final VoidCallback onVerified;
  final double size;
  final Duration duration;

  const FingerprintVerifyWidget({
    super.key,
    required this.onVerified,
    this.size = 220,
    this.duration = const Duration(milliseconds: 1800),
  });

  @override
  State<FingerprintVerifyWidget> createState() =>
      _FingerprintVerifyWidgetState();
}

class _FingerprintVerifyWidgetState extends State<FingerprintVerifyWidget>
    with TickerProviderStateMixin {
  double _progress = 0.0;
  bool _pressing = false;
  bool _verified = false;
  Timer? _timer;
  DateTime? _pressStartTime;
  int _lastPercent = 0;

  late AnimationController _glowController;
  late AnimationController _rotateController;
  late AnimationController _pulseController;

  @override
  void initState() {
    super.initState();

    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);

    _rotateController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 3000),
    )..repeat();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    _glowController.dispose();
    _rotateController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  void _startPress() {
    if (_verified || _pressing) return;
    HapticFeedback.mediumImpact();
    _pressStartTime = DateTime.now();
    setState(() {
      _pressing = true;
      _progress = 0.0;
      _lastPercent = 0;
    });
    if (!_pulseController.isAnimating) _pulseController.repeat(reverse: true);
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(milliseconds: 16), (t) {
      if (!mounted || !_pressing || _verified) { t.cancel(); return; }
      final elapsed = DateTime.now().difference(_pressStartTime!);
      final totalMs = widget.duration.inMilliseconds;
      final newProgress = (elapsed.inMilliseconds / totalMs).clamp(0.0, 1.0);
      final currentPercent = (newProgress * 100).toInt();
      if (currentPercent ~/ 10 > _lastPercent ~/ 10) HapticFeedback.selectionClick();
      _lastPercent = currentPercent;
      setState(() => _progress = newProgress);
      if (newProgress >= 1.0) { t.cancel(); _onComplete(); }
    });
  }

  void _endPress() {
    if (_verified) return;
    _timer?.cancel();
    _pressStartTime = null;
    if (_progress >= 1.0) return;
    if (_progress > 0.0) {
      HapticFeedback.lightImpact();
      final start = _progress;
      const resetDurationMs = 200;
      final startTime = DateTime.now();
      Timer.periodic(const Duration(milliseconds: 16), (t) {
        if (!mounted) { t.cancel(); return; }
        final elapsed = DateTime.now().difference(startTime).inMilliseconds;
        final factor = (1.0 - (elapsed / resetDurationMs)).clamp(0.0, 1.0);
        setState(() => _progress = start * factor);
        if (elapsed >= resetDurationMs) {
          t.cancel();
          if (mounted) setState(() => _progress = 0.0);
        }
      });
    }
    if (mounted) setState(() => _pressing = false);
    _pulseController.stop();
    _pulseController.reset();
  }

  void _onComplete() {
    if (_verified) return;
    _verified = true;
    _pressing = false;
    HapticFeedback.heavyImpact();
    _pulseController.stop();
    setState(() => _progress = 1.0);
    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted) widget.onVerified();
    });
  }

  @override
  Widget build(BuildContext context) {
    final size = widget.size;
    return Listener(
      behavior: HitTestBehavior.opaque,
      onPointerDown: (_) => _startPress(),
      onPointerUp: (_) => _endPress(),
      onPointerCancel: (_) => _endPress(),
      child: AnimatedBuilder(
        animation: Listenable.merge([
          _glowController,
          _rotateController,
          _pulseController,
        ]),
        builder: (context, _) {
          final glow   = _glowController.value;
          final rotate = _rotateController.value;
          final pulse  = _pressing ? (0.9 + _pulseController.value * 0.15) : 1.0;
          return Transform.scale(
            scale: pulse,
            child: SizedBox(
              width: size,
              height: size,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    width: size,
                    height: size,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: _FPC.primary.withOpacity(
                              0.25 + glow * 0.35 + _progress * 0.4),
                          blurRadius: 30 + glow * 20 + _progress * 30,
                          spreadRadius: 2 + _progress * 4,
                        ),
                      ],
                    ),
                  ),
                  CustomPaint(
                    size: Size(size, size),
                    painter: _FingerprintRingPainter(
                      rotation: rotate * 2 * math.pi,
                      progress: _progress,
                    ),
                  ),
                  Container(
                    width: size - 20,
                    height: size - 20,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _FPC.card,
                      border: Border.all(
                        color: _FPC.border.withOpacity(
                            0.5 + glow * 0.4 + _progress * 0.5),
                        width: 2.5,
                      ),
                    ),
                  ),
                  Icon(
                    _verified ? Icons.check_rounded : Icons.fingerprint_rounded,
                    size: size * 0.4,
                    color: _FPC.primary,
                  ),
                  Positioned(
                    bottom: size * 0.12,
                    child: Text(
                      '${(_progress * 100).toInt()}%',
                      style: const TextStyle(
                        color: _FPC.primary,
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1,
                        shadows: [Shadow(color: Colors.white, blurRadius: 10)],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
