import 'package:flutter/material.dart';
import 'webview_tool_shell.dart';

class ChroomPage extends StatelessWidget {
  const ChroomPage({super.key});

  @override
  Widget build(BuildContext context) => const McWebViewShell(
        title: 'Chroom',
        subtitle: 'Web Browser • Real-time',
        initialUrl: 'https://www.google.com/',
        accent: Color(0xFF4285F4),
        icon: Icons.language_rounded,
      );
}
