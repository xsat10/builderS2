import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'api_config.dart';

class NotificationsPage extends StatefulWidget {
  @override
  _NotificationsPageState createState() => _NotificationsPageState();
}

class _NotificationsPageState extends State<NotificationsPage> {
  List<dynamic> _notifications = [];
  bool _isLoading = true;
  bool _hasError = false;
  String _errorMessage = '';

  Future<void> fetchNotifications() async {
    try {
      setState(() {
        _isLoading = true;
        _hasError = false;
      });

      final res = await http.get(
        Uri.parse("$baseUrl/notifications")
      ).timeout(const Duration(seconds: 10));

      if (res.statusCode == 200) {
        final data = json.decode(res.body);
        setState(() {
          _notifications = data;
          _isLoading = false;
          _hasError = false;
        });
      } else {
        throw Exception('Failed to load notifications');
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
        _hasError = true;
        _errorMessage = 'Failed to connect to server: ${e.toString()}';
      });
    }
  }

  @override
  void initState() {
    super.initState();
    fetchNotifications();

    // Polling with proper error handling and backoff
    _startPolling();
  }

  void _startPolling() {
    Future.delayed(Duration.zero, () async {
      int retryCount = 0;
      while (mounted) {
        // Exponential backoff: 5s, 10s, 20s, max 30s
        int delay = 5 * (1 << retryCount).clamp(1, 6);
        await Future.delayed(Duration(seconds: delay));
        await fetchNotifications();
        
        if (_hasError) {
          retryCount = (retryCount + 1).clamp(0, 5);
        } else {
          retryCount = 0;
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        backgroundColor: Colors.redAccent,
        centerTitle: true,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(FontAwesomeIcons.bell, color: Colors.white, size: 20),
            SizedBox(width: 8),
            Text(
              "Zenzo Notifications",
              style: TextStyle(
                fontFamily: "Orbitron",
                fontWeight: FontWeight.bold,
                fontSize: 20,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation<Color>(Colors.redAccent),
        ),
      );
    }

    if (_hasError) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline, size: 60, color: Colors.red),
            SizedBox(height: 10),
            Text(
              "Connection Error",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 5),
            Text(
              _errorMessage,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 14, color: Colors.grey[700]),
            ),
            SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: fetchNotifications,
              icon: Icon(Icons.refresh),
              label: Text("Retry"),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.redAccent,
                foregroundColor: Colors.white,
              ),
            ),
          ],
        ),
      );
    }

    if (_notifications.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.notifications_off, size: 60, color: Colors.grey),
            SizedBox(height: 10),
            Text(
              "Belum ada notifikasi dari owner",
              style: TextStyle(fontSize: 16, color: Colors.grey),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: fetchNotifications,
      color: Colors.redAccent,
      child: ListView.builder(
        padding: EdgeInsets.all(12),
        itemCount: _notifications.length,
        itemBuilder: (context, index) {
          final notif = _notifications[index];
          return Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            elevation: 4,
            margin: EdgeInsets.symmetric(vertical: 8),
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: Colors.redAccent,
                child: Icon(Icons.notifications_active, color: Colors.white),
              ),
              title: Text(
                notif["title"] ?? "Notification",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),
              subtitle: Text(
                notif["body"] ?? "",
                style: TextStyle(color: Colors.black54),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              trailing: Icon(Icons.arrow_forward_ios,
                  size: 16, color: Colors.grey),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => NotificationDetailPage(notif: notif),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}

class NotificationDetailPage extends StatelessWidget {
  final Map<String, dynamic> notif;

  NotificationDetailPage({required this.notif});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Detail Notifikasi"),
        backgroundColor: Colors.redAccent,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "📌 Judul:",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              notif["title"] ?? "No Title",
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 20),
            Text(
              "📝 Isi:",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              notif["body"] ?? "No Content",
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 20),
            Text(
              "📅 Waktu:",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              DateTime.fromMillisecondsSinceEpoch(notif["id"] ?? 0)
                  .toString()
                  .substring(0, 19),
              style: TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}