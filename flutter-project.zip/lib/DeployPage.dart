import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:url_launcher/url_launcher.dart';
import 'api_config.dart';

class DeployPage extends StatefulWidget {
  const DeployPage({Key? key}) : super(key: key);

  @override
  _DeployPageState createState() => _DeployPageState();
}

class _DeployPageState extends State<DeployPage> {
  final TextEditingController _tokenController = TextEditingController();
  final TextEditingController _ownerController = TextEditingController();
  String? _botUsername;
  bool _loading = false;

  Future<void> deployBot() async {
    setState(() => _loading = true);

    final res = await http.post(
     Uri.parse("$baseUrl/deploybot"),
     headers: {"Content-Type": "application/json"},
     body: jsonEncode({
       "token": _tokenController.text,
       "ownerId": _ownerController.text,
      }),
    );

    final data = jsonDecode(res.body);
    setState(() => _loading = false);

    if (data['ok']) {
      setState(() => _botUsername = data['username']);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Bot aktif: @${data['username']}")),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Gagal: ${data['msg']}")),
      );
    }
  }

  Future<void> openBot() async {
    final url = "https://t.me/$_botUsername";
    if (await canLaunchUrl(Uri.parse(url))) {
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      appBar: AppBar(
        title: const Text(
          "Deploy Bot Telegram",
          style: TextStyle(
            fontFamily: "Orbitron",
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: const Color(0xFF121212),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _tokenController,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                labelText: "Bot Token",
                labelStyle: const TextStyle(color: Colors.white70),
                filled: true,
                fillColor: const Color(0xFF1C1C1C),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: const BorderSide(color: Colors.white24),
                ),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _ownerController,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                labelText: "Owner ID",
                labelStyle: const TextStyle(color: Colors.white70),
                filled: true,
                fillColor: const Color(0xFF1C1C1C),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: const BorderSide(color: Colors.white24),
                ),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF2E2E2E),
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              ),
              onPressed: _loading ? null : deployBot,
              icon: const Icon(Icons.cloud_upload, color: Colors.redAccent),
              label: _loading
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Text(
                      "Deploy",
                      style: TextStyle(
                        fontFamily: "Orbitron",
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
            ),
            if (_botUsername != null) ...[
              const SizedBox(height: 20),
              ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                ),
                onPressed: openBot,
                icon: const Icon(Icons.open_in_new, color: Colors.white),
                label: const Text(
                  "Open Bot",
                  style: TextStyle(
                    fontFamily: "Orbitron",
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            ]
          ],
        ),
      ),
    );
  }
}