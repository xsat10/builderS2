// ignore_for_file: use_build_context_synchronously, deprecated_member_use
// ignore_for_file: use_build_context_synchronously, deprecated_member_use
import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:audioplayers/audioplayers.dart';
import 'audio_service.dart';

// ── Tema Spotify ─────────────────────────────────────────────────────────────
const Color _primaryColor = Color(0xFF1DB954);
const Color _backgroundColor = Color(0xFF0A0A0A);
const Color _surfaceColor = Color(0xFF141414);
const Color _cardColor = Color(0xFF1C1C1C);
const Color _textColor = Colors.white;
const Color _subtitleColor = Color(0xFF808080);

// ── ENDPOINT API ────────────────────────────────────────────────────────────
const String _kSearchEndpoint = "https://api.deezer.com/search";
const String _kTopChartEndpoint = "https://api.deezer.com/chart/0/tracks?limit=25";

class MusicPage extends StatefulWidget {
  const MusicPage({super.key});

  @override
  State<MusicPage> createState() => _MusicPageState();
}

class _MusicPageState extends State<MusicPage> with TickerProviderStateMixin {
  final TextEditingController _searchCtrl = TextEditingController();
  final FocusNode _searchFocus = FocusNode();
  final AudioService _audioService = AudioService();

  List<_Track> _searchResults = [];
  List<_Track> _topTracks = [];

  bool _isSearching = false;
  bool _hasSearched = false;
  bool _isLoadingTop = true;
  String? _topError;
  String? _searchError;

  String? _currentlyPlayingId;
  bool _isPlaying = false;
  Duration _currentPosition = Duration.zero;
  Duration _currentDuration = Duration.zero;
  _Track? _currentTrack;

  Timer? _debounce;

  late AnimationController _entryAnim;

  // Playlist & Favorites
  List<_Track> _playlist = [];
  List<_Track> _favorites = [];
  int _currentIndex = -1;
  bool _isShuffle = false;
  bool _isRepeat = false;
  double _volume = 0.5;
  double _playbackSpeed = 1.0;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();

    _entryAnim = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    )..forward();

    _fetchTopTracks();

    _searchCtrl.addListener(() => _onSearchChanged(_searchCtrl.text));

    _audioService.player.onPlayerComplete.listen((_) {
      if (!mounted) return;
      _handleTrackCompletion();
    });
    _audioService.player.onDurationChanged.listen((d) {
      if (!mounted) return;
      setState(() => _currentDuration = d);
    });
    _audioService.player.onPositionChanged.listen((p) {
      if (!mounted) return;
      setState(() => _currentPosition = p);
    });
    _audioService.player.onPlayerStateChanged.listen((state) {
      if (!mounted) return;
      setState(() => _isPlaying = state == PlayerState.playing);
    });
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _entryAnim.dispose();
    _searchCtrl.dispose();
    _searchFocus.dispose();
    super.dispose();
  }

  Future<void> _fetchTopTracks() async {
    setState(() {
      _isLoadingTop = true;
      _topError = null;
    });
    try {
      final res = await http
          .get(Uri.parse(_kTopChartEndpoint))
          .timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) {
        final body = jsonDecode(res.body) as Map<String, dynamic>;
        final raw = (body['data'] as List?) ?? const [];
        final list = raw
            .whereType<Map<String, dynamic>>()
            .map(_Track.fromDeezer)
            .where((t) => t.previewUrl.isNotEmpty)
            .toList();
        if (mounted) {
          setState(() {
            _topTracks = list;
            _isLoadingTop = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            _isLoadingTop = false;
            _topError = "Gagal memuat (HTTP ${res.statusCode})";
          });
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isLoadingTop = false;
          _topError = "Gagal memuat: $e";
        });
      }
    }
  }

  Future<void> _searchMusic(String query) async {
    final q = query.trim();
    if (q.isEmpty) {
      setState(() {
        _searchResults = [];
        _isSearching = false;
        _hasSearched = false;
        _searchError = null;
      });
      return;
    }

    setState(() {
      _isSearching = true;
      _hasSearched = true;
      _searchError = null;
    });

    try {
      final uri = Uri.parse(
          "$_kSearchEndpoint?q=${Uri.encodeQueryComponent(q)}&limit=40");
      final res = await http.get(uri).timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) {
        final body = jsonDecode(res.body) as Map<String, dynamic>;
        final raw = (body['data'] as List?) ?? const [];
        final list = raw
            .whereType<Map<String, dynamic>>()
            .map(_Track.fromDeezer)
            .toList();
        if (mounted) {
          setState(() {
            _searchResults = list;
            _isSearching = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            _isSearching = false;
            _searchError = "Gagal mencari (HTTP ${res.statusCode})";
          });
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isSearching = false;
          _searchError = "Gagal mencari: $e";
        });
      }
    }
  }

  void _onSearchChanged(String q) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 500), () => _searchMusic(q));
  }

  Future<void> _togglePlay(_Track track) async {
    if (track.previewUrl.isEmpty) {
      _showSnack("Preview audio tidak tersedia untuk lagu ini.");
      return;
    }
    try {
      if (_currentlyPlayingId == track.id && _audioService.isPlaying) {
        await _audioService.pause();
        if (mounted) setState(() => _isPlaying = false);
        return;
      }
      if (_currentlyPlayingId == track.id && !_audioService.isPlaying) {
        await _audioService.player.resume();
        if (mounted) setState(() => _isPlaying = true);
        return;
      }
      await _audioService.play(track.previewUrl, track.id);
      if (mounted) {
        setState(() {
          _currentlyPlayingId = track.id;
          _currentTrack = track;
          _isPlaying = true;
          _addToPlaylist(track);
          _currentIndex = _playlist.length - 1;
        });
      }
    } catch (e) {
      _showSnack("Gagal memutar: $e");
    }
  }

  Future<void> _stopPlayer() async {
    await _audioService.stop();
    if (mounted) {
      setState(() {
        _isPlaying = false;
        _currentlyPlayingId = null;
        _currentTrack = null;
        _currentPosition = Duration.zero;
      });
    }
  }

  void _handleTrackCompletion() {
    if (_isRepeat && _currentTrack != null) {
      _togglePlay(_currentTrack!);
    } else if (_playlist.isNotEmpty) {
      _playNext();
    } else {
      if (mounted) {
        setState(() {
          _isPlaying = false;
          _currentPosition = Duration.zero;
        });
      }
    }
  }

  void _playNext() {
    if (_playlist.isEmpty || _currentIndex == -1) return;
    
    int nextIndex;
    if (_isShuffle) {
      do {
        nextIndex = _getRandomIndex();
      } while (nextIndex == _currentIndex && _playlist.length > 1);
    } else {
      nextIndex = (_currentIndex + 1) % _playlist.length;
    }
    
    if (nextIndex < _playlist.length) {
      setState(() => _currentIndex = nextIndex);
      _togglePlay(_playlist[nextIndex]);
    }
  }

  void _playPrevious() {
    if (_playlist.isEmpty || _currentIndex <= 0) return;
    
    final prevIndex = _currentIndex - 1;
    setState(() => _currentIndex = prevIndex);
    _togglePlay(_playlist[prevIndex]);
  }

  int _getRandomIndex() => _playlist.isEmpty ? 0 : DateTime.now().microsecondsSinceEpoch % _playlist.length;

  void _addToPlaylist(_Track track) {
    if (!_playlist.any((item) => item.id == track.id)) {
      setState(() => _playlist.add(track));
    }
  }

  void _removeFromPlaylist(int index) {
    if (index < 0 || index >= _playlist.length) return;
    
    setState(() {
      final removedId = _playlist[index].id;
      if (_currentIndex == index) {
        _currentIndex = -1;
        _currentTrack = null;
        _currentlyPlayingId = null;
        _audioService.stop();
      } else if (_currentIndex > index) {
        _currentIndex--;
      }
      _playlist.removeAt(index);
    });
  }

  void _toggleFavorite(_Track track) {
    setState(() {
      if (_favorites.any((f) => f.id == track.id)) {
        _favorites.removeWhere((f) => f.id == track.id);
        _showSnack("Removed from favorites");
      } else {
        _favorites.add(track);
        _showSnack("Added to favorites");
      }
    });
  }

  void _toggleShuffle() {
    setState(() => _isShuffle = !_isShuffle);
  }

  void _toggleRepeat() {
    setState(() => _isRepeat = !_isRepeat);
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: _cardColor,
        content: Text(
          msg,
          style: const TextStyle(color: Colors.white),
        ),
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    final isSmallScreen = screenHeight < 700;

    return DefaultTabController(
      length: 3,
      child: Scaffold(
        backgroundColor: _backgroundColor,
        appBar: AppBar(
          backgroundColor: _backgroundColor,
          elevation: 0,
          title: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 28,
                height: 28,
                decoration: BoxDecoration(
                  color: _primaryColor,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(Icons.music_note_rounded, color: Colors.black, size: 16),
              ),
              const SizedBox(width: 10),
              Text(
                "GHOST Music",
                style: TextStyle(
                  color: _textColor,
                  fontWeight: FontWeight.w800,
                  fontSize: 18,
                  letterSpacing: -0.3,
                ),
              ),
            ],
          ),
          centerTitle: true,
          bottom: PreferredSize(
            preferredSize: Size.fromHeight(isSmallScreen ? 120 : 136),
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Container(
                    height: 48,
                    decoration: BoxDecoration(
                      color: _cardColor,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: Colors.white.withOpacity(0.06)),
                    ),
                    child: TextField(
                      controller: _searchCtrl,
                      style: TextStyle(color: _textColor, fontSize: 14, fontWeight: FontWeight.w500),
                      decoration: InputDecoration(
                        hintText: "Search songs, artists...",
                        hintStyle: TextStyle(color: _subtitleColor, fontSize: 14),
                        filled: true,
                        fillColor: Colors.transparent,
                        prefixIcon: Icon(Icons.search_rounded, color: _subtitleColor, size: 20),
                        suffixIcon: _searchCtrl.text.isNotEmpty
                            ? GestureDetector(
                                onTap: () {
                                  _searchCtrl.clear();
                                  if (mounted) setState(() => _searchResults.clear());
                                },
                                child: Icon(Icons.close_rounded, color: _subtitleColor, size: 18),
                              )
                            : null,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(14),
                          borderSide: BorderSide.none,
                        ),
                        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                      ),
                      onChanged: _onSearchChanged,
                      onSubmitted: _searchMusic,
                    ),
                  ),
                ),
                SizedBox(
                  height: isSmallScreen ? 48 : 56,
                  child: TabBar(
                    indicatorColor: _primaryColor,
                    indicatorWeight: 2.5,
                    dividerColor: Colors.transparent,
                    labelColor: _primaryColor,
                    unselectedLabelColor: _subtitleColor,
                    indicatorSize: TabBarIndicatorSize.label,
                    labelStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12, letterSpacing: 0.2),
                    unselectedLabelStyle: const TextStyle(fontWeight: FontWeight.w500, fontSize: 12),
                    tabs: const [
                      Tab(icon: Icon(Icons.search_rounded, size: 20), text: "Search"),
                      Tab(icon: Icon(Icons.queue_music_rounded, size: 20), text: "Playlist"),
                      Tab(icon: Icon(Icons.favorite_rounded, size: 20), text: "Favorites"),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        body: Stack(
          children: [
            TabBarView(
              children: [
                _buildSearchTab(),
                _buildPlaylistTab(),
                _buildFavoritesTab(),
              ],
            ),
            if (_currentTrack != null)
              Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                child: _buildMiniPlayer(),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildSearchTab() {
    if (_isSearching && _searchResults.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(color: _primaryColor, strokeWidth: 2),
            const SizedBox(height: 16),
            Text("Searching...", style: TextStyle(color: _subtitleColor, fontSize: 14, fontWeight: FontWeight.w500)),
          ],
        ),
      );
    }

    if (_searchResults.isEmpty && _hasSearched) {
      return _buildEmptyState(Icons.search_off_rounded, "No results found", "Try different keywords");
    }

    if (_searchResults.isEmpty) {
      // Tampilkan top tracks ketika belum search
      return _buildTopTracksTab();
    }

    return ListView.builder(
      physics: const BouncingScrollPhysics(),
      padding: EdgeInsets.only(
        top: 12,
        bottom: _currentTrack != null ? 100 : 60,
        left: 12,
        right: 12,
      ),
      itemCount: _searchResults.length,
      itemBuilder: (context, index) {
        final item = _searchResults[index];
        final isCurrent = _currentTrack?.id == item.id;
        final isFavorite = _favorites.any((f) => f.id == item.id);
        return _buildTrackCard(
          item: item,
          isCurrent: isCurrent,
          onTap: () => _togglePlay(item),
          trailing: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              GestureDetector(
                onTap: () => _toggleFavorite(item),
                child: Icon(
                  isFavorite ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                  color: isFavorite ? Colors.red : _subtitleColor,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              GestureDetector(
                onTap: () {
                  _addToPlaylist(item);
                  _showSnack("Added to playlist");
                },
                child: Icon(Icons.playlist_add_rounded, color: _subtitleColor, size: 20),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildTopTracksTab() {
    if (_isLoadingTop) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(color: _primaryColor, strokeWidth: 2),
            const SizedBox(height: 16),
            Text("Loading...", style: TextStyle(color: _subtitleColor, fontSize: 14, fontWeight: FontWeight.w500)),
          ],
        ),
      );
    }

    if (_topError != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline_rounded, color: Colors.redAccent, size: 48),
            const SizedBox(height: 16),
            Text(
              _topError!,
              style: TextStyle(color: _subtitleColor, fontSize: 14),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _fetchTopTracks,
              style: ElevatedButton.styleFrom(
                backgroundColor: _primaryColor,
                foregroundColor: Colors.black,
              ),
              child: const Text("Retry"),
            ),
          ],
        ),
      );
    }

    if (_topTracks.isEmpty) {
      return _buildEmptyState(Icons.music_note_rounded, "No tracks available", "Please try again later");
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
          child: Row(
            children: [
              Icon(Icons.local_fire_department_rounded, color: _primaryColor, size: 20),
              const SizedBox(width: 8),
              Text(
                "TOP TRACKS",
                style: TextStyle(
                  color: _textColor,
                  fontSize: 16,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: ListView.builder(
            physics: const BouncingScrollPhysics(),
            padding: EdgeInsets.only(
              bottom: _currentTrack != null ? 100 : 20,
              left: 12,
              right: 12,
            ),
            itemCount: _topTracks.length,
            itemBuilder: (context, index) {
              final item = _topTracks[index];
              final isCurrent = _currentTrack?.id == item.id;
              final isFavorite = _favorites.any((f) => f.id == item.id);
              return _buildTrackCard(
                item: item,
                isCurrent: isCurrent,
                onTap: () => _togglePlay(item),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    GestureDetector(
                      onTap: () => _toggleFavorite(item),
                      child: Icon(
                        isFavorite ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                        color: isFavorite ? Colors.red : _subtitleColor,
                        size: 20,
                      ),
                    ),
                    const SizedBox(width: 12),
                    GestureDetector(
                      onTap: () {
                        _addToPlaylist(item);
                        _showSnack("Added to playlist");
                      },
                      child: Icon(Icons.playlist_add_rounded, color: _subtitleColor, size: 20),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildTrackCard({
    required _Track item,
    required bool isCurrent,
    required VoidCallback onTap,
    Widget? trailing,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 4),
      decoration: BoxDecoration(
        color: isCurrent ? _primaryColor.withOpacity(0.1) : _cardColor,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isCurrent ? _primaryColor.withOpacity(0.3) : Colors.white.withOpacity(0.05),
          width: 1,
        ),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          splashColor: _primaryColor.withOpacity(0.05),
          highlightColor: Colors.white.withOpacity(0.02),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(10),
            child: Row(
              children: [
                Stack(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: SizedBox(
                        width: 54,
                        height: 54,
                        child: item.thumbnail.isNotEmpty
                            ? Image.network(
                                item.thumbnail,
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => _buildDefaultArt(54),
                              )
                            : _buildDefaultArt(54),
                      ),
                    ),
                    if (isCurrent)
                      Positioned.fill(
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: Container(
                            color: Colors.black.withOpacity(0.65),
                            child: Icon(
                              _isPlaying ? Icons.equalizer_rounded : Icons.play_arrow_rounded,
                              color: _primaryColor,
                              size: 22,
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        item.title,
                        style: TextStyle(
                          color: isCurrent ? _primaryColor : _textColor,
                          fontWeight: FontWeight.w600,
                          fontSize: 13.5,
                          letterSpacing: -0.1,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 3),
                      Text(
                        item.artist,
                        style: TextStyle(
                          color: isCurrent ? _primaryColor.withOpacity(0.8) : _subtitleColor,
                          fontSize: 12,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.06),
                          borderRadius: BorderRadius.circular(5),
                        ),
                        child: Text(
                          _fmtDuration(item.duration),
                          style: TextStyle(
                            color: _subtitleColor,
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                if (trailing != null) trailing,
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPlaylistTab() {
    if (_playlist.isEmpty) {
      return _buildEmptyState(
        Icons.queue_music_rounded,
        "Your playlist is empty",
        "Add songs from search results to build your playlist",
      );
    }

    return Column(
      children: [
        _buildListHeader(
          label: "CURRENT PLAYLIST",
          count: "${_playlist.length} ${_playlist.length == 1 ? 'song' : 'songs'}",
          actions: [
            _buildIconChip(
              icon: Icons.shuffle_rounded,
              active: _isShuffle,
              color: _isShuffle ? _primaryColor : _subtitleColor,
              onTap: _toggleShuffle,
            ),
          ],
        ),
        Expanded(
          child: ListView.builder(
            physics: const BouncingScrollPhysics(),
            padding: EdgeInsets.only(
              top: 8,
              bottom: _currentTrack != null ? 100 : 60,
              left: 12,
              right: 12,
            ),
            itemCount: _playlist.length,
            itemBuilder: (context, index) {
              final item = _playlist[index];
              final isCurrent = index == _currentIndex;
              return _buildTrackCard(
                item: item,
                isCurrent: isCurrent,
                onTap: () {
                  setState(() => _currentIndex = index);
                  _togglePlay(item);
                },
                trailing: GestureDetector(
                  onTap: () => _removeFromPlaylist(index),
                  child: Padding(
                    padding: const EdgeInsets.all(4),
                    child: Icon(Icons.close_rounded, color: _subtitleColor, size: 18),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildFavoritesTab() {
    if (_favorites.isEmpty) {
      return _buildEmptyState(
        Icons.favorite_border_rounded,
        "No favorites yet",
        "Tap the heart icon on any song to add it to favorites",
      );
    }

    return Column(
      children: [
        _buildListHeader(
          label: "YOUR FAVORITES",
          count: "${_favorites.length} ${_favorites.length == 1 ? 'song' : 'songs'}",
          actions: [],
        ),
        Expanded(
          child: ListView.builder(
            physics: const BouncingScrollPhysics(),
            padding: EdgeInsets.only(
              top: 8,
              bottom: _currentTrack != null ? 100 : 60,
              left: 12,
              right: 12,
            ),
            itemCount: _favorites.length,
            itemBuilder: (context, index) {
              final item = _favorites[index];
              final isCurrent = _currentTrack?.id == item.id;
              return _buildTrackCard(
                item: item,
                isCurrent: isCurrent,
                onTap: () => _togglePlay(item),
                trailing: GestureDetector(
                  onTap: () {
                    setState(() {
                      _favorites.removeAt(index);
                      if (_currentTrack?.id == item.id) {
                        // Update favorite status if needed
                      }
                    });
                    _showSnack("Removed from favorites");
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(4),
                    child: Icon(Icons.favorite_rounded, color: Colors.red, size: 20),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildListHeader({
    required String label,
    required String count,
    required List<Widget> actions,
  }) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
      decoration: BoxDecoration(
        color: _backgroundColor,
        border: Border(
          bottom: BorderSide(color: Colors.white.withOpacity(0.05)),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    color: _subtitleColor,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.2,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  count,
                  style: TextStyle(
                    color: _textColor,
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    letterSpacing: -0.3,
                  ),
                ),
              ],
            ),
          ),
          ...actions,
        ],
      ),
    );
  }

  Widget _buildIconChip({
    required dynamic icon,
    required bool active,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: active ? color.withOpacity(0.15) : _cardColor,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: active ? color.withOpacity(0.4) : Colors.white.withOpacity(0.08),
          ),
        ),
        child: Icon(icon, color: color, size: 18),
      ),
    );
  }

  Widget _buildMiniPlayer() {
    if (_currentTrack == null) return const SizedBox.shrink();
    
    final progress = _currentDuration.inSeconds > 0
        ? (_currentPosition.inSeconds / _currentDuration.inSeconds).clamp(0.0, 1.0)
        : 0.0;

    return ClipRRect(
      borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
          decoration: BoxDecoration(
            color: _surfaceColor.withOpacity(0.95),
            border: Border(
              top: BorderSide(color: _primaryColor.withOpacity(0.3), width: 1),
            ),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: SizedBox(
                      width: 42,
                      height: 42,
                      child: _currentTrack!.thumbnail.isNotEmpty
                          ? Image.network(
                              _currentTrack!.thumbnail,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => _buildDefaultArt(42),
                            )
                          : _buildDefaultArt(42),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _currentTrack!.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 13,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 1),
                        Text(
                          _currentTrack!.artist,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: _subtitleColor,
                            fontSize: 11,
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: Icon(
                      _isPlaying
                          ? Icons.pause_circle_filled_rounded
                          : Icons.play_circle_filled_rounded,
                      color: _primaryColor,
                      size: 36,
                    ),
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                    onPressed: () => _togglePlay(_currentTrack!),
                  ),
                  const SizedBox(width: 4),
                  IconButton(
                    icon: Icon(Icons.skip_next_rounded,
                        color: _playlist.length > 1 ? Colors.white : _subtitleColor.withOpacity(0.3),
                        size: 24),
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                    onPressed: _playlist.length > 1 ? _playNext : null,
                  ),
                ],
              ),
              const SizedBox(height: 4),
              ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: progress,
                  minHeight: 3,
                  backgroundColor: Colors.white12,
                  valueColor: const AlwaysStoppedAnimation(_primaryColor),
                ),
              ),
              const SizedBox(height: 2),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    _fmtMs(_currentPosition),
                    style: const TextStyle(
                      color: Colors.white60,
                      fontSize: 10,
                    ),
                  ),
                  Text(
                    _fmtMs(_currentDuration),
                    style: const TextStyle(
                      color: Colors.white60,
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState(dynamic icon, String title, String subtitle) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 64, color: _subtitleColor.withOpacity(0.4)),
            const SizedBox(height: 20),
            Text(
              title,
              style: TextStyle(
                color: _textColor,
                fontSize: 18,
                fontWeight: FontWeight.w700,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              subtitle,
              textAlign: TextAlign.center,
              style: TextStyle(color: _subtitleColor, fontSize: 13),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDefaultArt(double size) {
    return Container(
      width: size,
      height: size,
      color: _surfaceColor,
      child: Icon(Icons.music_note_rounded, color: _subtitleColor, size: size * 0.4),
    );
  }

  String _fmtDuration(int seconds) {
    if (seconds <= 0) return "--:--";
    final m = seconds ~/ 60;
    final s = seconds % 60;
    return "$m:${s.toString().padLeft(2, '0')}";
  }

  String _fmtMs(Duration d) {
    final m = d.inMinutes;
    final s = d.inSeconds % 60;
    return "$m:${s.toString().padLeft(2, '0')}";
  }
}

class _Track {
  final String id;
  final String title;
  final String artist;
  final String album;
  final String thumbnail;
  final String previewUrl;
  final int duration;
  final int rank;

  _Track({
    required this.id,
    required this.title,
    required this.artist,
    required this.album,
    required this.thumbnail,
    required this.previewUrl,
    required this.duration,
    required this.rank,
  });

  factory _Track.fromDeezer(Map<String, dynamic> json) {
    final artistMap = json['artist'];
    final albumMap = json['album'];
    String thumb = '';
    if (albumMap is Map) {
      thumb = (albumMap['cover_xl'] ??
              albumMap['cover_big'] ??
              albumMap['cover_medium'] ??
              albumMap['cover'] ??
              '')
          .toString();
    }
    return _Track(
      id: (json['id'] ?? '').toString(),
      title: (json['title_short'] ?? json['title'] ?? '').toString(),
      artist: (artistMap is Map ? (artistMap['name'] ?? '') : '').toString(),
      album: (albumMap is Map ? (albumMap['title'] ?? '') : '').toString(),
      thumbnail: thumb,
      previewUrl: (json['preview'] ?? '').toString(),
      duration: (json['duration'] is int)
          ? json['duration'] as int
          : int.tryParse((json['duration'] ?? '0').toString()) ?? 0,
      rank: (json['rank'] is int)
          ? json['rank'] as int
          : int.tryParse((json['rank'] ?? '0').toString()) ?? 0,
    );
  }
}