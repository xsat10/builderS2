class ApiConfig {
  static const String baseUrl = 'http://private-one.jhonaleystore.id:2758';
  static const Duration shortTimeout = Duration(seconds: 20);
  static const Duration longTimeout = Duration(seconds: 60);
  static const String tokenKey = 'lanz_token';
}
