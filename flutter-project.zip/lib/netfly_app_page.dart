import 'package:flutter/material.dart';
import 'webview_tool_shell.dart';

class NetflyAppPage extends StatelessWidget {
  const NetflyAppPage({super.key});

  @override
  Widget build(BuildContext context) => const McWebViewShell(
        title: 'NetflyApp',
        subtitle: 'Netflix Web • Real-time',
        initialUrl: 'https://www.netflix.com/',
        accent: Color(0xFFE50914),
        icon: Icons.movie_filter_rounded,
      );
}
