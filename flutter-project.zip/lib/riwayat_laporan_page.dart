// ============================================================
// 📋 RIWAYAT LAPORAN — Dark Red Comic 3D Edition
// File: riwayat_laporan_page.dart
// ============================================================
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class _MC {
  static const red          = Color(0xFF8B0000);
  static const redDeep      = Color(0xFF1A0A0A);
  static const redDark      = Color(0xFF4A0000);
  static const redSoft      = Color(0xFF2A0E0E);
  static const brightRed    = Color(0xFFFF3B3B);
  static const buttonYellow = Color(0xFFB8860B);
  static const buttonDark   = Color(0xFF1A1A1A);
  static const comicBlack   = Color(0xFF000000);
  static const white        = Color(0xFFFFF5F5);
  static const textGrey     = Color(0xFFC9A0A0);
  static const textLight    = Color(0xFF8A6060);
  static const green        = Color(0xFF22C55E);
  static const greenLite    = Color(0xFF4ADE80);
  static const amber        = Color(0xFFFBBF24);
}

class RiwayatLaporanPage extends StatefulWidget {
  final String username;
  const RiwayatLaporanPage({super.key, required this.username});

  @override
  State<RiwayatLaporanPage> createState() => _RiwayatLaporanPageState();
}

class _RiwayatLaporanPageState extends State<RiwayatLaporanPage> {
  List<Map<String, dynamic>> _reports = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadReports();
  }

  Future<void> _loadReports() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final list = prefs.getStringList('reports_${widget.username}') ?? [];
      final reports = list
          .map((e) {
            try {
              return Map<String, dynamic>.from(jsonDecode(e));
            } catch (_) {
              return <String, dynamic>{};
            }
          })
          .where((e) => e.isNotEmpty)
          .toList();

      if (mounted) {
        setState(() {
          _reports = reports;
          _loading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _deleteReport(String id) async {
    final prefs = await SharedPreferences.getInstance();
    final listKey = 'reports_${widget.username}';
    final existing = prefs.getStringList(listKey) ?? [];
    final updated = existing.where((e) {
      try {
        final data = jsonDecode(e);
        return data['id'] != id;
      } catch (_) {
        return false;
      }
    }).toList();
    await prefs.setStringList(listKey, updated);
    _loadReports();
  }

  String _formatDate(int ts) {
    try {
      final dt = DateTime.fromMillisecondsSinceEpoch(ts);
      return '${dt.day}/${dt.month}/${dt.year} ${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
    } catch (_) {
      return '-';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _MC.redDeep,
      appBar: AppBar(
        backgroundColor: _MC.redDark,
        elevation: 0,
        centerTitle: true,
        leading: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            margin: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: _MC.buttonDark,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: _MC.comicBlack, width: 2.5),
              boxShadow: const [
                BoxShadow(
                    color: _MC.comicBlack,
                    offset: Offset(2, 2),
                    blurRadius: 0),
              ],
            ),
            child: const Icon(Icons.arrow_back_ios_new_rounded,
                color: _MC.white, size: 16),
          ),
        ),
        title: Container(
          padding:
              const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
          decoration: BoxDecoration(
            color: _MC.buttonDark,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: _MC.comicBlack, width: 2.5),
            boxShadow: const [
              BoxShadow(
                  color: _MC.comicBlack,
                  offset: Offset(3, 3),
                  blurRadius: 0),
            ],
          ),
          child: const Text(
            'RIWAYAT LAPORAN',
            style: TextStyle(
              color: _MC.white,
              fontWeight: FontWeight.w900,
              fontSize: 13,
              letterSpacing: 2,
              fontFamily: 'Astral',
            ),
          ),
        ),
      ),
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(color: _MC.brightRed))
          : _reports.isEmpty
              ? _buildEmptyState()
              : _buildReportList(),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _MC.redSoft,
                border: Border.all(color: _MC.comicBlack, width: 3.5),
                boxShadow: const [
                  BoxShadow(
                      color: _MC.comicBlack,
                      offset: Offset(4, 4),
                      blurRadius: 0),
                ],
              ),
              child: const Icon(Icons.inbox_rounded,
                  color: _MC.brightRed, size: 50),
            ),
            const SizedBox(height: 20),
            const Text(
              'BELUM ADA LAPORAN',
              style: TextStyle(
                color: _MC.white,
                fontWeight: FontWeight.w900,
                fontSize: 16,
                letterSpacing: 2,
                fontFamily: 'Astral',
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Laporan yang kamu kirim akan muncul di sini',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: _MC.textGrey,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildReportList() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: _MC.redSoft,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _MC.comicBlack, width: 3),
              boxShadow: const [
                BoxShadow(
                    color: _MC.comicBlack,
                    offset: Offset(4, 4),
                    blurRadius: 0),
              ],
            ),
            child: Row(
              children: [
                const Icon(Icons.list_alt_rounded,
                    color: _MC.brightRed, size: 18),
                const SizedBox(width: 10),
                Text(
                  'Total: ${_reports.length} laporan',
                  style: const TextStyle(
                    color: _MC.white,
                    fontSize: 12,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Astral',
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          ..._reports.map((r) => _buildReportCard(r)),
        ],
      ),
    );
  }

  Widget _buildReportCard(Map<String, dynamic> r) {
    final category = (r['category'] ?? 'LAINNYA').toString();
    final message = (r['message'] ?? '').toString();
    final timestamp = r['timestamp'] ?? 0;
    final status = (r['status'] ?? 'pending').toString();
    final id = (r['id'] ?? '').toString();

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _MC.redSoft,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _MC.comicBlack, width: 3),
        boxShadow: const [
          BoxShadow(
              color: _MC.comicBlack,
              offset: Offset(4, 4),
              blurRadius: 0),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: _MC.brightRed,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _MC.comicBlack, width: 2),
                ),
                child: Text(
                  category,
                  style: const TextStyle(
                    color: _MC.white,
                    fontSize: 9,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.8,
                  ),
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: status == 'pending'
                      ? _MC.amber
                      : _MC.green,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _MC.comicBlack, width: 2),
                ),
                child: Text(
                  status == 'pending' ? 'PENDING' : 'DIBACA',
                  style: const TextStyle(
                    color: _MC.comicBlack,
                    fontSize: 8.5,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.8,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            message,
            style: const TextStyle(
              color: _MC.white,
              fontSize: 12,
              height: 1.5,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: _MC.buttonDark,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: _MC.comicBlack, width: 2),
            ),
            child: Row(
              children: [
                const Icon(Icons.access_time_rounded,
                    color: _MC.textGrey, size: 12),
                const SizedBox(width: 6),
                Text(
                  _formatDate(timestamp),
                  style: const TextStyle(
                    color: _MC.textGrey,
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: () => _deleteReport(id),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: _MC.red,
                      borderRadius: BorderRadius.circular(6),
                      border:
                          Border.all(color: _MC.comicBlack, width: 1.5),
                    ),
                    child: const Row(
                      children: [
                        Icon(Icons.delete_rounded,
                            color: _MC.white, size: 11),
                        SizedBox(width: 4),
                        Text(
                          'HAPUS',
                          style: TextStyle(
                            color: _MC.white,
                            fontSize: 8.5,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}