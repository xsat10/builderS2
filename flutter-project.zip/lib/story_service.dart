import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'api_config.dart';

class StoryService {
  // ── Ambil semua story aktif dari server ──────────────────────────────
  static Future<List<Map<String, dynamic>>> fetchStories({
    required String sessionKey,
  }) async {
    try {
      final res = await http.get(
        Uri.parse('http://deylegal-panel.pterodactylxcz.my.id:2151/api/stories'),
        headers: {
          'Authorization': 'Bearer $sessionKey',
          'Content-Type': 'application/json',
        },
      ).timeout(const Duration(seconds: 15));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['success'] == true && data['stories'] != null) {
          return List<Map<String, dynamic>>.from(
            (data['stories'] as List).map((e) => Map<String, dynamic>.from(e)),
          );
        }
      }
    } catch (e) {
      print('fetchStories error: $e');
    }
    return [];
  }

  // ── Upload story (image/video/text) ke server ────────────────────────
  static Future<Map<String, dynamic>?> uploadStory({
    required String sessionKey,
    required String username,
    required String type, // 'image' | 'video' | 'text'
    String? textContent,
    File? mediaFile,
    Function(double progress)? onProgress,
  }) async {
    try {
      final uri = Uri.parse('http://deylegal-panel.pterodactylxcz.my.id:2151/api/stories/upload');
      final request = http.MultipartRequest('POST', uri);

      request.headers['Authorization'] = 'Bearer $sessionKey';
      request.fields['username'] = username;
      request.fields['type'] = type;

      if (type == 'text' && textContent != null) {
        request.fields['content'] = textContent;
      }

      if (mediaFile != null) {
        final stream = http.ByteStream(mediaFile.openRead());
        final length = await mediaFile.length();
        final multipartFile = http.MultipartFile(
          type == 'image' ? 'image' : 'video',
          stream,
          length,
          filename: mediaFile.path.split('/').last,
        );
        request.files.add(multipartFile);
      }

      final streamedResponse = await request.send();
      final response = await http.Response.fromStream(streamedResponse);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) {
          return Map<String, dynamic>.from(data['story']);
        }
      }
      print('uploadStory failed: ${response.statusCode} - ${response.body}');
    } catch (e) {
      print('uploadStory error: $e');
    }
    return null;
  }

  // ── Hapus story (hanya milik sendiri) ────────────────────────────────
  static Future<bool> deleteStory({
    required String sessionKey,
    required String storyId,
  }) async {
    try {
      final res = await http.delete(
        Uri.parse('http://deylegal-panel.pterodactylxcz.my.id:2151/api/stories/$storyId'),
        headers: {'Authorization': 'Bearer $sessionKey'},
      ).timeout(const Duration(seconds: 10));
      return res.statusCode == 200;
    } catch (e) {
      print('deleteStory error: $e');
      return false;
    }
  }

  // ── Cache lokal untuk fallback offline ───────────────────────────────
  static Future<void> cacheStories(List<Map<String, dynamic>> stories) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('cached_stories', jsonEncode(stories));
  }

  static Future<List<Map<String, dynamic>>> getCachedStories() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('cached_stories');
    if (raw == null) return [];
    try {
      return List<Map<String, dynamic>>.from(
        (jsonDecode(raw) as List).map((e) => Map<String, dynamic>.from(e)),
      );
    } catch (_) {
      return [];
    }
  }
}