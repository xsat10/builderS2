// ignore_for_file: use_build_context_synchronously, deprecated_member_use
import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';

import 'home_page.dart';
import 'home_page2.dart';
import 'bug_group.dart';

// ══════════════════════════════════════════════════════════════════════════════
// CONSTANTS
// ══════════════════════════════════════════════════════════════════════════════
const Color _bgBlue     = Color(0xFF1E3A5F);
const Color _blueAccent = Color(0xFF2E75B6);
const Color _blueRing   = Color(0xFF4A90D9);

class NetraxPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final String role;
  final String expiredDate;
  final List<Map<String, dynamic>> listPayload;

  const NetraxPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.role,
    required this.expiredDate,
    required this.listPayload,
  });

  @override
  State<NetraxPage> createState() => _NetraxPageState();
}

class _NetraxPageState extends State<NetraxPage>
    with TickerProviderStateMixin {
  late PageController _pageController;
  late AnimationController _ringController;
  late AnimationController _clockController;
  int _currentPage = 0;
  DateTime _now = DateTime.now();

  @override
  void initState() {
    super.initState();
    _pageController = PageController(viewportFraction: 0.85, initialPage: 0);

    // Ring muter — 4 detik per putaran
    _ringController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat(); // ← KUNCI MUTER

    // Update jam tiap detik
    _clockController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1),
    )..repeat();
    _clockController.addListener(() {
      if (mounted) {
        final newNow = DateTime.now();
        if (newNow.second != _now.second) {
          setState(() => _now = newNow);
        }
      }
    });
  }

  @override
  void dispose() {
    _pageController.dispose();
    _ringController.dispose();
    _clockController.dispose();
    super.dispose();
  }

  // ── Helper: hari dalam Indonesia ──
  String get _hari {
    const hari = [
      'SENIN',
      'SELASA',
      'RABU',
      'KAMIS',
      'JUMAT',
      'SABTU',
      'MINGGU'
    ];
    return hari[_now.weekday - 1];
  }

  String get _hariSingkat {
    const hari = ['SEN', 'SEL', 'RAB', 'KAM', 'JUM', 'SAB', 'MIN'];
    return hari[_now.weekday - 1];
  }

  String get _bulan {
    const bulan = [
      'JAN',
      'FEB',
      'MAR',
      'APR',
      'MEI',
      'JUN',
      'JUL',
      'AGU',
      'SEP',
      'OKT',
      'NOV',
      'DES'
    ];
    return bulan[_now.month - 1];
  }

  String get _jam {
    final h = _now.hour.toString().padLeft(2, '0');
    final m = _now.minute.toString().padLeft(2, '0');
    return '$h:$m';
  }

  String get _waktuHari {
    final h = _now.hour;
    if (h >= 4 && h < 11) return 'Pagi';
    if (h >= 11 && h < 15) return 'Siang';
    if (h >= 15 && h < 18) return 'Sore';
    return 'Malam';
  }

  // ── Data Menu ──
  List<_MenuData> get _menus => [
        _MenuData(
          title: 'install Panel',
          subtitle: 'Termux/VPS · Panel + Wings',
          badge: 'PANEL',
          icon: Icons.dns_rounded,
          onStart: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => HomePage(
                  username: widget.username,
                  password: widget.password,
                  sessionKey: widget.sessionKey,
                  listBug: widget.listPayload,
                  role: widget.role,
                  expiredDate: widget.expiredDate,
                ),
              ),
            );
          },
        ),
        _MenuData(
          title: 'Bug & Spam',
          subtitle: 'Delay & Loops Custom',
          badge: 'WA2',
          icon: Icons.chat_bubble_rounded,
          onStart: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => AttackPage2(
                  username: widget.username,
                  password: widget.password,
                  sessionKey: widget.sessionKey,
                  listBug: widget.listPayload,
                  role: widget.role,
                  expiredDate: widget.expiredDate,
                ),
              ),
            );
          },
        ),
        _MenuData(
          title: 'Bug & Group',
          subtitle: 'Serangan Grup WhatsApp',
          badge: 'GRUP',
          icon: Icons.groups_rounded,
          onStart: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => GroupBugPage(
                  username: widget.username,
                  password: widget.password,
                  sessionKey: widget.sessionKey,
                  role: widget.role,
                  expiredDate: widget.expiredDate,
                ),
              ),
            );
          },
        ),
      ];

  @override
  Widget build(BuildContext context) {
    final menus = _menus;

    return Scaffold(
      backgroundColor: _bgBlue,
      body: Stack(
        children: [
          // ── Background menu_bg.png ──
          Positioned.fill(
            child: Image.asset(
              'assets/images/menu_bg.png',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFF234A78), Color(0xFF12263F)],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                ),
              ),
            ),
          ),

          // ── Konten ──
          SafeArea(
            child: Column(
              children: [
                // ── Header: JUDUL + Luffy ──
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 14, 20, 0),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'MENU UTAMA',
                              style: TextStyle(
                                color: Color(0xFF0F2547),
                                fontSize: 30,
                                fontWeight: FontWeight.w900,
                                fontStyle: FontStyle.italic,
                                letterSpacing: 1,
                                height: 1,
                              ),
                            ),
                            SizedBox(height: 4),
                            Text(
                              '· Termux & VPS',
                              style: TextStyle(
                                color: Color(0xFF1A3A5C),
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                                letterSpacing: 0.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Transform.translate(
                        offset: const Offset(0, -10),
                        child: Image.asset(
                          'assets/images/kontol.jpg',
                          width: 80,
                          height: 80,
                          fit: BoxFit.contain,
                          errorBuilder: (_, __, ___) => const SizedBox(),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 16),

                // ── Card Jam & Tanggal ──
                _buildClockCard(),

                const SizedBox(height: 30),

                // ── PageView Menu ──
                Expanded(
                  child: PageView.builder(
                    controller: _pageController,
                    onPageChanged: (i) => setState(() => _currentPage = i),
                    itemCount: menus.length,
                    itemBuilder: (context, i) {
                      return _buildMenuCard(menus[i], i);
                    },
                  ),
                ),

                const SizedBox(height: 8),

                // ── Dot Indicator ──
                Center(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(menus.length, (i) {
                      final active = _currentPage == i;
                      return AnimatedContainer(
                        duration: const Duration(milliseconds: 300),
                        margin: const EdgeInsets.symmetric(horizontal: 4),
                        width: active ? 26 : 8,
                        height: 8,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(4),
                          color: active
                              ? _blueAccent
                              : Colors.white.withValues(alpha: 0.4),
                        ),
                      );
                    }),
                  ),
                ),

                const SizedBox(height: 14),

                // ── GESER MENU (x/y) ──
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 22, vertical: 8),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.85),
                    borderRadius: BorderRadius.circular(30),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.1),
                        blurRadius: 8,
                        offset: const Offset(0, 3),
                      ),
                    ],
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.chevron_left_rounded,
                          color: Color(0xFF1A3A5C), size: 18),
                      const SizedBox(width: 6),
                      Text(
                        'GESER MENU (${_currentPage + 1}/${menus.length})',
                        style: const TextStyle(
                          color: Color(0xFF1A3A5C),
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1.2,
                        ),
                      ),
                      const SizedBox(width: 6),
                      const Icon(Icons.chevron_right_rounded,
                          color: Color(0xFF1A3A5C), size: 18),
                    ],
                  ),
                ),

                const SizedBox(height: 14),

                // ── Card Info Bawah ──
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: _buildBottomInfoCard(menus[_currentPage]),
                ),

                const SizedBox(height: 10),

                // ── Tombol Buka ──
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 14),
                  child: GestureDetector(
                    onTap: menus[_currentPage].onStart,
                    child: Container(
                      height: 54,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFF4A90D9), Color(0xFF2E75B6)],
                        ),
                        borderRadius: BorderRadius.circular(28),
                        boxShadow: [
                          BoxShadow(
                            color: _blueAccent.withValues(alpha: 0.4),
                            blurRadius: 14,
                            offset: const Offset(0, 6),
                          ),
                        ],
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.bolt_rounded,
                              color: Colors.white, size: 22),
                          const SizedBox(width: 8),
                          Text(
                            'Buka ${menus[_currentPage].title}',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 0.5,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════════
  //  CLOCK CARD — jam realtime + tanggal realtime
  // ═══════════════════════════════════════════════════════════════════════
  Widget _buildClockCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.08),
              blurRadius: 14,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Column(
          children: [
            Row(
              children: [
                Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    color: const Color(0xFFF0F4FA),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: const Color(0xFFD5E0EE),
                      width: 1.5,
                    ),
                  ),
                  child: const Icon(Icons.access_time_rounded,
                      color: Color(0xFF2E75B6), size: 26),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _jam,
                        style: const TextStyle(
                          color: Color(0xFF0F2547),
                          fontSize: 26,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.5,
                          height: 1,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        'WiFi · ${_waktuHari}',
                        style: const TextStyle(
                          color: Color(0xFF6B7B8D),
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  width: 1,
                  height: 50,
                  color: const Color(0xFFE0E6EE),
                ),
                const SizedBox(width: 14),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: const Color(0xFF2E75B6),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        _hariSingkat,
                        style: const TextStyle(
                          color: Colors.white70,
                          fontSize: 9,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 0.5,
                        ),
                      ),
                      Text(
                        '${_now.day}',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.w900,
                          height: 1,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      _hari,
                      style: const TextStyle(
                        color: Color(0xFF0F2547),
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.5,
                      ),
                    ),
                    Text(
                      '$_bulan ${_now.year}',
                      style: const TextStyle(
                        color: Color(0xFF6B7B8D),
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ],
            ),

            const SizedBox(height: 12),
            Container(height: 1, color: const Color(0xFFE0E6EE)),
            const SizedBox(height: 10),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildInfoItem(Icons.dns_rounded, 'infra Termux/VPS',
                    const Color(0xFF2E75B6)),
                Container(
                    width: 1,
                    height: 16,
                    color: const Color(0xFFE0E6EE)),
                _buildInfoItem(Icons.security_rounded, 'SYAM',
                    const Color(0xFF2E75B6)),
                Container(
                    width: 1,
                    height: 16,
                    color: const Color(0xFFE0E6EE)),
                _buildInfoItem(Icons.bolt_rounded, 'Full Fitur',
                    const Color(0xFF2E75B6)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoItem(IconData icon, String label, Color color) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, color: color, size: 14),
        const SizedBox(width: 4),
        Text(
          label,
          style: const TextStyle(
            color: Color(0xFF0F2547),
            fontSize: 10,
            fontWeight: FontWeight.w700,
            letterSpacing: 0.3,
          ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════════════════
  //  CARD MENU — icon PUTIH + ring biru MUTER (CustomPaint + Transform.rotate)
  // ═══════════════════════════════════════════════════════════════════════
  Widget _buildMenuCard(_MenuData menu, int index) {
    final bool isActive = _currentPage == index;

    return AnimatedScale(
      duration: const Duration(milliseconds: 350),
      scale: isActive ? 1.0 : 0.9,
      child: AnimatedOpacity(
        duration: const Duration(milliseconds: 350),
        opacity: isActive ? 1.0 : 0.6,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // ══════════════════════════════════════════════════
            //  ICON + RING MUTER
            // ══════════════════════════════════════════════════
            SizedBox(
              width: 120,
              height: 120,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  // ── Ring MUTER (CustomPaint + Transform.rotate) ──
                  AnimatedBuilder(
                    animation: _ringController,
                    builder: (context, child) {
                      return Transform.rotate(
                        angle: _ringController.value * 2 * math.pi,
                        child: CustomPaint(
                          size: const Size(120, 120),
                          painter: _RingPainter(),
                        ),
                      );
                    },
                  ),
                  // ── Lingkaran biru solid + icon putih ──
                  Container(
                    width: 92,
                    height: 92,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      color: Color(0xFF2E75B6),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x66000000),
                          blurRadius: 12,
                          offset: Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Icon(
                      menu.icon,
                      color: Colors.white,
                      size: 44,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 26),

            // ── Card putih ──
            Container(
              padding: const EdgeInsets.fromLTRB(24, 20, 24, 20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(22),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.08),
                    blurRadius: 18,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    menu.title,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Color(0xFF0F2547),
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 0.3,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    menu.subtitle,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Color(0xFF6B7B8D),
                      fontSize: 12,
                      letterSpacing: 0.2,
                    ),
                  ),
                  const SizedBox(height: 14),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 18, vertical: 6),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFF4A90D9), Color(0xFF2E75B6)],
                      ),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      menu.badge,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1.8,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════════
  //  CARD INFO BAWAH
  // ═══════════════════════════════════════════════════════════════════════
  Widget _buildBottomInfoCard(_MenuData menu) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: const Color(0xFFF0F4FA),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: const Color(0xFFD5E0EE),
                width: 1,
              ),
            ),
            child: Icon(menu.icon,
                color: const Color(0xFF2E75B6), size: 22),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  menu.title,
                  style: const TextStyle(
                    color: Color(0xFF0F2547),
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  menu.subtitle,
                  style: const TextStyle(
                    color: Color(0xFF6B7B8D),
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
          const Icon(Icons.arrow_forward_ios_rounded,
              color: Color(0xFF9CA3AF), size: 14),
        ],
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
// RING PAINTER — 2 busur + 2 dot biru (jelas keliatan muter)
// ══════════════════════════════════════════════════════════════════════════════
class _RingPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 4;

    // ── Background ring tipis ──
    final bgPaint = Paint()
      ..color = const Color(0xFF4A90D9).withValues(alpha: 0.15)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;

    canvas.drawCircle(center, radius, bgPaint);

    // ── Arc biru (2 busur di seberang) ──
    final arcPaint = Paint()
      ..color = const Color(0xFF4A90D9)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4
      ..strokeCap = StrokeCap.round;

    // Busur 1 (kanan)
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      0,
      math.pi / 2,
      false,
      arcPaint,
    );

    // Busur 2 (kiri)
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      math.pi,
      math.pi / 2,
      false,
      arcPaint,
    );

    // ── Dot di ujung busur ──
    final dotPaint = Paint()..color = const Color(0xFF4A90D9);

    // Dot kanan
    canvas.drawCircle(
      Offset(center.dx + radius, center.dy),
      5,
      dotPaint,
    );

    // Dot kiri
    canvas.drawCircle(
      Offset(center.dx - radius, center.dy),
      5,
      dotPaint,
    );

    // ── Dot kecil di tengah busur (biar keliatan muter) ──
    final smallDot = Paint()
      ..color = const Color(0xFF4A90D9).withValues(alpha: 0.6);

    // Dot kanan atas
    canvas.drawCircle(
      Offset(
        center.dx + radius * math.cos(math.pi / 4),
        center.dy + radius * math.sin(math.pi / 4),
      ),
      3,
      smallDot,
    );

    // Dot kiri bawah
    canvas.drawCircle(
      Offset(
        center.dx + radius * math.cos(math.pi + math.pi / 4),
        center.dy + radius * math.sin(math.pi + math.pi / 4),
      ),
      3,
      smallDot,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ══════════════════════════════════════════════════════════════════════════════
// DATA MODEL
// ══════════════════════════════════════════════════════════════════════════════
class _MenuData {
  final String title;
  final String subtitle;
  final String badge;
  final IconData icon;
  final VoidCallback onStart;

  _MenuData({
    required this.title,
    required this.subtitle,
    required this.badge,
    required this.icon,
    required this.onStart,
  });
}