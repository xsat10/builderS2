import 'dart:math';
import 'package:flutter/material.dart';

class SlidingPuzzle extends StatefulWidget {
  const SlidingPuzzle({super.key});

  @override
  State<SlidingPuzzle> createState() => _SlidingPuzzleState();
}

class _SlidingPuzzleState extends State<SlidingPuzzle> {
  List<int> tiles = List.generate(16, (i) => i)..shuffle();

  void move(int i) {
    int empty = tiles.indexOf(0);
    if ((i - empty).abs() == 1 || (i - empty).abs() == 4) {
      setState(() {
        tiles[empty] = tiles[i];
        tiles[i] = 0;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Sliding Puzzle")),
      body: GridView.builder(
        itemCount: 16,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 4),
        itemBuilder: (context, i) => GestureDetector(
          onTap: () => move(i),
          child: Container(
            margin: const EdgeInsets.all(4),
            color: tiles[i] == 0 ? Colors.black : Colors.blue,
            child: Center(
              child: Text(
                tiles[i] == 0 ? "" : tiles[i].toString(),
                style: const TextStyle(fontSize: 24),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
