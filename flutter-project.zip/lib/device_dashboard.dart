import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'dart:math' as math;
import 'controlleradmin.dart';

// ═══════════════════════════════════════════════════════════════════════════════
// COMIX 3D PALETTE
// ═══════════════════════════════════════════════════════════════════════════════
const Color comixBg = Color(0xFFFFF8E7);
const Color comixInk = Color(0xFF1A1A2E);
const Color comixWhite = Colors.white;
const Color comixRed = Color(0xFFFF3B30);
const Color comixBlue = Color(0xFF007AFF);
const Color comixYellow = Color(0xFFFFD600);
const Color comixGreen = Color(0xFF34C759);
const Color comixPurple = Color(0xFFAF52DE);
const Color comixOrange = Color(0xFFFF9500);
const Color comixPink = Color(0xFFFF2D8D);
const Color comixCyan = Color(0xFF32ADE6);
const Color comixTextSub = Color(0xFF4B5563);
const Color comixTextDim = Color(0xFF6B7280);

// legacy aliases (backward-compat)
class _C {
  static const bg = comixBg;
  static const surface = Colors.white;
  static const card = Colors.white;
  static const cardInner = Colors.white;
  static const border = comixInk;
  static const borderLit = comixInk;
  static const steel = comixBlue;
  static const blueMid = comixBlue;
  static const blueLight = comixCyan;
  static const chrome = comixCyan;
  static const frost = comixCyan;
  static const red = comixRed;
  static const amber = comixOrange;
  static const green = comixGreen;
  static const purple = comixPurple;
  static const pink = comixPink;
  static const teal = comixCyan;
  static const blue = comixBlue;
  static const text = comixInk;
  static const textSub = comixTextSub;
  static const textDim = comixTextDim;
  static const white = Colors.white;
}

// ═══════════════════════════════════════════════════════════════════════════════
// COMIX REUSABLE WIDGETS
// ═══════════════════════════════════════════════════════════════════════════════
class ComixPanel extends StatelessWidget {
  final Widget child;
  final Color bgColor;
  final Color shadowColor;
  final double borderWidth;
  final double shadowOffset;
  final BorderRadius radius;
  final EdgeInsets padding;

  const ComixPanel({
    Key? key,
    required this.child,
    this.bgColor = Colors.white,
    this.shadowColor = comixInk,
    this.borderWidth = 3,
    this.shadowOffset = 6,
    this.radius = const BorderRadius.all(Radius.circular(20)),
    this.padding = const EdgeInsets.all(16),
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: radius,
        boxShadow: [
          BoxShadow(
            color: shadowColor,
            offset: Offset(shadowOffset, shadowOffset),
            blurRadius: 0,
          ),
        ],
      ),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: radius,
          border: Border.all(color: comixInk, width: borderWidth),
        ),
        child: child,
      ),
    );
  }
}

class ComixChip extends StatelessWidget {
  final Widget child;
  final Color bgColor;
  const ComixChip({Key? key, required this.child, this.bgColor = comixYellow})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: comixInk, width: 2.5),
        boxShadow: const [
          BoxShadow(color: comixInk, offset: Offset(2.5, 2.5), blurRadius: 0),
        ],
      ),
      child: child,
    );
  }
}

class _HalftonePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = comixInk.withOpacity(0.07);
    const spacing = 16.0;
    for (double y = 0; y < size.height; y += spacing) {
      for (double x = 0; x < size.width; x += spacing) {
        canvas.drawCircle(Offset(x, y), 1.5, paint);
      }
    }
  }
  @override
  bool shouldRepaint(covariant CustomPainter _) => false;
}

class _SpeedLinesPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = comixInk.withOpacity(0.035)
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;
    final center = Offset(size.width / 2, size.height / 2);
    const count = 16;
    for (int i = 0; i < count; i++) {
      final angle = (i / count) * 2 * math.pi;
      final start = Offset(
        center.dx + 80 * math.cos(angle),
        center.dy + 80 * math.sin(angle),
      );
      final end = Offset(
        center.dx + 900 * math.cos(angle),
        center.dy + 900 * math.sin(angle),
      );
      canvas.drawLine(start, end, paint);
    }
  }
  @override
  bool shouldRepaint(covariant CustomPainter _) => false;
}

// ═══════════════════════════════════════════════════════════════════════════════
// DEVICE DASHBOARD PAGE
// ═══════════════════════════════════════════════════════════════════════════════
class DeviceDashboardPage extends StatefulWidget {
  final String sessionKey; // <-- TAMBAHKAN PARAMETER INI

  const DeviceDashboardPage({super.key, required this.sessionKey});

  @override
  State<DeviceDashboardPage> createState() => _DeviceDashboardPageState();
}

class _DeviceDashboardPageState extends State<DeviceDashboardPage> {
  List<dynamic> _devices = [];
  bool _isLoading = true;
  String? _errorMessage;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _fetchDevices();
    _timer = Timer.periodic(
        const Duration(seconds: 10), (timer) => _fetchDevices());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _fetchDevices() async {
    // Jika sedang loading awal, tampilkan spinner. Jika refresh berkala, biarkan data lama.
    if (_devices.isEmpty && mounted) {
      setState(() {
        _isLoading = true;
        _errorMessage = null;
      });
    }

    try {
      final response = await http.get(
        Uri.parse("http://dotszprivate.r-cloud.my.id:3447/api/list-targets"),
        headers: {
          "x-auth-token": widget.sessionKey, // <-- SERTAKAN TOKEN
        },
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (mounted) {
          setState(() {
            _devices = data is List ? data : [];
            _isLoading = false;
            _errorMessage = null;
          });
        }
      } else if (response.statusCode == 401) {
        if (mounted) {
          setState(() {
            _isLoading = false;
            _errorMessage = "Sesi login kadaluarsa (401)";
          });
        }
      } else {
        if (mounted) {
          setState(() {
            _isLoading = false;
            _errorMessage = "Server Error: ${response.statusCode}";
          });
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isLoading = false;
          _errorMessage = "Gagal terhubung ke server.";
        });
      }
      debugPrint("Error fetching devices: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    int activeCount = _devices.isNotEmpty ? _devices.length : 0;

    return Scaffold(
      backgroundColor: comixBg,
      body: Stack(
        children: [
          // Halftone dots
          Positioned.fill(
            child: IgnorePointer(
                child: CustomPaint(painter: _HalftonePainter())),
          ),
          // Speed lines
          Positioned.fill(
            child: IgnorePointer(
                child: CustomPaint(painter: _SpeedLinesPainter())),
          ),
          SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildHeader(activeCount),
                const SizedBox(height: 14),
                _buildSubHeader(),
                const SizedBox(height: 12),
                Expanded(
                  child: _isLoading
                      ? const Center(
                          child: CircularProgressIndicator(
                              color: comixBlue, strokeWidth: 3))
                      : _errorMessage != null
                          ? _buildErrorState()
                          : _devices.isEmpty
                              ? _buildEmptyState()
                              : RefreshIndicator(
                                  color: comixBlue,
                                  onRefresh: _fetchDevices,
                                  child: GridView.builder(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 14, vertical: 8),
                                    gridDelegate:
                                        const SliverGridDelegateWithFixedCrossAxisCount(
                                      crossAxisCount: 2,
                                      crossAxisSpacing: 14,
                                      mainAxisSpacing: 14,
                                      childAspectRatio: 0.82,
                                    ),
                                    itemCount: _devices.length,
                                    itemBuilder: (context, index) =>
                                        _buildDeviceCard(_devices[index], index),
                                  ),
                                ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // HEADER
  // ═══════════════════════════════════════════════════════════════════════════
  Widget _buildHeader(int activeCount) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 8),
      child: ComixPanel(
        bgColor: comixBlue,
        shadowColor: comixInk,
        shadowOffset: 8,
        borderWidth: 3.5,
        radius: const BorderRadius.all(Radius.circular(22)),
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            // Back button
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: comixYellow,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: comixInk, width: 2.5),
                  boxShadow: const [
                    BoxShadow(
                        color: comixInk,
                        offset: Offset(2.5, 2.5),
                        blurRadius: 0),
                  ],
                ),
                child: const Icon(Icons.arrow_back_rounded,
                    color: comixInk, size: 20),
              ),
            ),
            const SizedBox(width: 12),

            // Icon
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: comixInk, width: 2.5),
                boxShadow: const [
                  BoxShadow(
                      color: comixInk,
                      offset: Offset(2.5, 2.5),
                      blurRadius: 0),
                ],
              ),
              child: const Icon(Icons.devices_rounded,
                  color: comixBlue, size: 22),
            ),
            const SizedBox(width: 12),

            // Title
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Stack(
                    children: [
                      Transform.translate(
                        offset: const Offset(1.5, 1.5),
                        child: const Text(
                          'DEVICE HUB',
                          style: TextStyle(
                              color: comixInk,
                              fontSize: 15,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 1,
                              fontFamily: 'Orbitron'),
                        ),
                      ),
                      const Text(
                        'DEVICE HUB',
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1,
                            fontFamily: 'Orbitron',
                            shadows: [
                              Shadow(
                                  color: comixInk, offset: Offset(1.5, 1.5)),
                            ]),
                      ),
                    ],
                  ),
                  const SizedBox(height: 2),
                  Text('Control Center',
                      style: TextStyle(
                          color: Colors.white.withOpacity(0.85),
                          fontSize: 10,
                          fontWeight: FontWeight.w700)),
                ],
              ),
            ),

            // Active counter
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: comixInk,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.white, width: 2.5),
                boxShadow: const [
                  BoxShadow(
                      color: comixInk,
                      offset: Offset(2.5, 2.5),
                      blurRadius: 0),
                ],
              ),
              child: Column(
                children: [
                  Text('$activeCount',
                      style: const TextStyle(
                          color: comixYellow,
                          fontSize: 18,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Orbitron',
                          height: 1)),
                  const Text('ACTIVE',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 8,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1,
                          fontFamily: 'ShareTechMono')),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // SUB HEADER
  // ═══════════════════════════════════════════════════════════════════════════
  Widget _buildSubHeader() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Container(
                width: 4,
                height: 18,
                color: comixInk,
                margin: const EdgeInsets.only(right: 8),
              ),
              const Text(
                "CONNECTED DEVICES",
                style: TextStyle(
                  color: comixInk,
                  fontSize: 11.5,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5,
                  fontFamily: 'Orbitron',
                ),
              ),
            ],
          ),
          ComixChip(
            bgColor: comixYellow,
            child: Text('${_devices.length} TOTAL',
                style: const TextStyle(
                    color: comixInk,
                    fontSize: 9,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Orbitron')),
          ),
        ],
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // ERROR STATE
  // ═══════════════════════════════════════════════════════════════════════════
  Widget _buildErrorState() {
    return Center(
      child: ComixPanel(
        bgColor: Colors.white,
        shadowOffset: 8,
        borderWidth: 3.5,
        radius: const BorderRadius.all(Radius.circular(24)),
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: comixRed,
                shape: BoxShape.circle,
                border: Border.all(color: comixInk, width: 3),
                boxShadow: const [
                  BoxShadow(
                      color: comixInk,
                      offset: Offset(3, 3),
                      blurRadius: 0),
                ],
              ),
              child: const Icon(Icons.error_outline_rounded,
                  color: Colors.white, size: 36),
            ),
            const SizedBox(height: 16),
            const Text(
              "GAGAL MEMUAT",
              style: TextStyle(
                  color: comixInk,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5,
                  fontSize: 13,
                  fontFamily: 'Orbitron'),
            ),
            const SizedBox(height: 4),
            Text(
              _errorMessage ?? "Terjadi kesalahan",
              textAlign: TextAlign.center,
              style: const TextStyle(
                  color: comixTextSub,
                  fontSize: 11,
                  fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 12),
            GestureDetector(
              onTap: _fetchDevices,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: comixBlue,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: comixInk, width: 2),
                ),
                child: const Text("COBA LAGI",
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 12)),
              ),
            )
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // EMPTY STATE
  // ═══════════════════════════════════════════════════════════════════════════
  Widget _buildEmptyState() {
    return Center(
      child: ComixPanel(
        bgColor: Colors.white,
        shadowOffset: 8,
        borderWidth: 3.5,
        radius: const BorderRadius.all(Radius.circular(24)),
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: comixYellow,
                shape: BoxShape.circle,
                border: Border.all(color: comixInk, width: 3),
                boxShadow: const [
                  BoxShadow(
                      color: comixInk,
                      offset: Offset(3, 3),
                      blurRadius: 0),
                ],
              ),
              child: const Icon(Icons.devices_rounded,
                  color: comixInk, size: 36),
            ),
            const SizedBox(height: 16),
            const Text(
              "NO DEVICES FOUND",
              style: TextStyle(
                  color: comixInk,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5,
                  fontSize: 13,
                  fontFamily: 'Orbitron'),
            ),
            const SizedBox(height: 4),
            const Text(
              "Tidak ada device terhubung",
              style: TextStyle(
                  color: comixTextSub,
                  fontSize: 11,
                  fontWeight: FontWeight.w600),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // DEVICE CARD
  // ═══════════════════════════════════════════════════════════════════════════
  Widget _buildDeviceCard(dynamic device, int index) {
    bool isOnline = device['status'] == 'online' || index == 0;
    Color statusColor = isOnline ? comixGreen : comixRed;
    String statusText = isOnline ? "ONLINE" : "OFFLINE";

    return GestureDetector(
      onTap: () {
        // PERBAIKAN: Kirim data device langsung ke constructor ControlPanelPage
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ControlPanelPage(
              device: device is Map<String, dynamic> ? device : null,
            ),
          ),
        );
      },
      child: ComixPanel(
        bgColor: Colors.white,
        shadowOffset: 5,
        borderWidth: 2.5,
        radius: const BorderRadius.all(Radius.circular(18)),
        padding: const EdgeInsets.all(10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ─── Header: Icon + Status ───
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: isOnline ? comixBlue : comixInk.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: comixInk, width: 2),
                  ),
                  child: Icon(
                    Icons.phone_android_rounded,
                    color: isOnline ? Colors.white : comixInk,
                    size: 18,
                  ),
                ),
                ComixChip(
                  bgColor: statusColor,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 6,
                        height: 6,
                        decoration: const BoxDecoration(
                            color: Colors.white, shape: BoxShape.circle),
                      ),
                      const SizedBox(width: 4),
                      Text(
                        statusText,
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 8,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 0.5,
                            fontFamily: 'ShareTechMono'),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const Spacer(),

            // ─── Device Name ───
            Text(
              device['model'] ?? "Unknown Device",
              style: const TextStyle(
                  color: comixInk,
                  fontSize: 12,
                  fontWeight: FontWeight.w900,
                  height: 1.2),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 4),

            // ─── Device ID ───
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
              decoration: BoxDecoration(
                color: comixYellow.withOpacity(0.4),
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: comixInk, width: 1.5),
              ),
              child: Text(
                device['id'] ?? "NO-ID",
                style: const TextStyle(
                    color: comixInk,
                    fontSize: 8,
                    fontWeight: FontWeight.w800,
                    fontFamily: 'ShareTechMono'),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            const Spacer(),

            // ─── Battery & IP ───
            Row(
              children: [
                const Icon(Icons.battery_charging_full_rounded,
                    color: comixGreen, size: 12),
                const SizedBox(width: 3),
                Text(
                  "${device['battery'] ?? '100'}%",
                  style: const TextStyle(
                      color: comixInk,
                      fontSize: 9.5,
                      fontWeight: FontWeight.w800),
                ),
                const SizedBox(width: 8),
                const Icon(Icons.wifi_rounded, color: comixBlue, size: 12),
                const SizedBox(width: 3),
                Expanded(
                  child: Text(
                    device['ip'] ?? "192.168.1.1",
                    style: const TextStyle(
                        color: comixTextSub,
                        fontSize: 9,
                        fontWeight: FontWeight.w700,
                        fontFamily: 'ShareTechMono'),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),

            // ─── Control Button ───
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 8),
              decoration: BoxDecoration(
                color: isOnline ? comixRed : comixInk.withOpacity(0.15),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: comixInk, width: 2.5),
                boxShadow: const [
                  BoxShadow(
                      color: comixInk,
                      offset: Offset(2, 2),
                      blurRadius: 0),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "CONTROL",
                    style: TextStyle(
                        color: isOnline ? Colors.white : comixInk,
                        fontSize: 9.5,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1,
                        fontFamily: 'Orbitron'),
                  ),
                  const SizedBox(width: 4),
                  Icon(
                    Icons.arrow_forward_rounded,
                    color: isOnline ? Colors.white : comixInk,
                    size: 11,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}