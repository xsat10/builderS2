import 'dart:async';

import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

/// mclarenGram — real-time Telegram Web client inside Flutter.
///
/// The page intentionally keeps Telegram's own web UI rendered by WebView,
/// while Flutter owns the surrounding navigation chrome and loading states.
class TelegramPlayerPage extends StatefulWidget {
  const TelegramPlayerPage({super.key});

  @override
  State<TelegramPlayerPage> createState() => _TelegramPlayerPageState();
}

class _TelegramPlayerPageState extends State<TelegramPlayerPage>
    with SingleTickerProviderStateMixin {
  static final Uri _telegramUri = Uri.parse('https://web.telegram.org/a/');

  late final WebViewController _controller;
  late final AnimationController _pulseController;

  int _progress = 0;
  bool _isLoading = true;
  bool _hasError = false;
  bool _canGoBack = false;
  bool _canGoForward = false;
  String _pageTitle = 'Telegram X-SPYDER';
  String _currentUrl = _telegramUri.toString();

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);

    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF07070B))
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (progress) {
            if (!mounted) return;
            setState(() => _progress = progress.clamp(0, 100));
          },
          onPageStarted: (url) {
            if (!mounted) return;
            setState(() {
              _isLoading = true;
              _hasError = false;
              _currentUrl = url;
            });
          },
          onPageFinished: (url) async {
            await _refreshNavigationState();
            if (!mounted) return;
            setState(() {
              _isLoading = false;
              _progress = 100;
              _currentUrl = url;
            });
          },
          onWebResourceError: (error) {
            // Subresources can fail without the main document being broken.
            if (error.isForMainFrame != true) return;
            if (!mounted) return;
            setState(() {
              _isLoading = false;
              _hasError = true;
            });
          },
          onNavigationRequest: (request) {
            // Telegram's web client uses multiple origins/resources. Let the
            // WebView handle them instead of opening an external browser.
            return NavigationDecision.navigate;
          },
        ),
      )
      ..loadRequest(_telegramUri);
  }

  Future<void> _refreshNavigationState() async {
    final results = await Future.wait([
      _controller.canGoBack(),
      _controller.canGoForward(),
      _controller.getTitle(),
      _controller.currentUrl(),
    ]);

    if (!mounted) return;
    setState(() {
      _canGoBack = results[0] as bool;
      _canGoForward = results[1] as bool;
      _pageTitle = ((results[2] as String?)?.trim().isNotEmpty ?? false)
          ? results[2] as String
          : 'Telegram X-SPYDER';
      _currentUrl = results[3] as String? ?? _currentUrl;
    });
  }

  Future<void> _goBack() async {
    if (!await _controller.canGoBack()) return;
    await _controller.goBack();
    await _refreshNavigationState();
  }

  Future<void> _goForward() async {
    if (!await _controller.canGoForward()) return;
    await _controller.goForward();
    await _refreshNavigationState();
  }

  Future<void> _reload() async {
    setState(() {
      _hasError = false;
      _isLoading = true;
      _progress = 0;
    });
    await _controller.reload();
  }

  Future<void> _home() async {
    setState(() {
      _hasError = false;
      _isLoading = true;
      _progress = 0;
    });
    await _controller.loadRequest(_telegramUri);
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;

    return Scaffold(
      backgroundColor: const Color(0xFF07070B),
      body: SafeArea(
        child: Column(
          children: [
            _buildTopBar(scheme),
            _buildProgressBar(),
            Expanded(
              child: Stack(
                fit: StackFit.expand,
                children: [
                  WebViewWidget(controller: _controller),
                  if (_hasError) _buildErrorOverlay(scheme),
                ],
              ),
            ),
            _buildBottomBar(scheme),
          ],
        ),
      ),
    );
  }

  Widget _buildTopBar(ColorScheme scheme) {
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 10),
      decoration: BoxDecoration(
        color: const Color(0xFF0D0D13).withOpacity(.97),
        border: Border(bottom: BorderSide(color: Colors.white.withOpacity(.07))),
      ),
      child: Row(
        children: [
          Semantics(
            button: true,
            label: 'Kembali',
            child: IconButton(
              tooltip: 'Kembali',
              onPressed: () => Navigator.of(context).maybePop(),
              icon: const Icon(Icons.arrow_back_rounded),
            ),
          ),
          const SizedBox(width: 4),
          AnimatedBuilder(
            animation: _pulseController,
            builder: (context, child) => Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF35C6FF), Color(0xFF2377FF)],
                ),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF35C6FF).withOpacity(.20 +
                        (_pulseController.value * .18)),
                    blurRadius: 16,
                    spreadRadius: 1,
                  ),
                ],
              ),
              child: const Icon(Icons.send_rounded, color: Colors.white, size: 22),
            ),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Flexible(
                      child: Text(
                        'Telegram X-SPYDER',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              color: Colors.white,
                              fontWeight: FontWeight.w800,
                              letterSpacing: -.2,
                            ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    _liveBadge(),
                  ],
                ),
                const SizedBox(height: 2),
                Text(
                  _pageTitle == 'Telegram X-SPYDER' ? 'Telegram Web • Real-time' : _pageTitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Colors.white.withOpacity(.48),
                      ),
                ),
              ],
            ),
          ),
          IconButton(
            tooltip: 'Refresh',
            onPressed: _reload,
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
    );
  }

  Widget _liveBadge() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
      decoration: BoxDecoration(
        color: const Color(0xFF22C55E).withOpacity(.13),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: const Color(0xFF22C55E).withOpacity(.32)),
      ),
      child: const Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.circle, size: 6, color: Color(0xFF4ADE80)),
          SizedBox(width: 4),
          Text(
            'LIVE',
            style: TextStyle(
              color: Color(0xFF86EFAC),
              fontSize: 9,
              fontWeight: FontWeight.w900,
              letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProgressBar() {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 220),
      height: _isLoading ? 2.5 : 1,
      alignment: Alignment.centerLeft,
      decoration: BoxDecoration(color: Colors.white.withOpacity(.04)),
      child: FractionallySizedBox(
        widthFactor: _isLoading ? (_progress / 100).clamp(.02, 1) : 1,
        child: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF35C6FF), Color(0xFF7C5CFF)],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildBottomBar(ColorScheme scheme) {
    return Container(
      padding: const EdgeInsets.fromLTRB(10, 8, 10, 9),
      decoration: BoxDecoration(
        color: const Color(0xFF0D0D13).withOpacity(.98),
        border: Border(top: BorderSide(color: Colors.white.withOpacity(.07))),
      ),
      child: Row(
        children: [
          _navButton(Icons.arrow_back_ios_new_rounded, 'Back', _canGoBack, _goBack),
          _navButton(Icons.arrow_forward_ios_rounded, 'Forward', _canGoForward, _goForward),
          _navButton(Icons.home_rounded, 'Home', true, _home),
          const Spacer(),
          Flexible(
            child: Text(
              _currentUrl,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.right,
              style: const TextStyle(fontSize: 10, color: Colors.white38),
            ),
          ),
        ],
      ),
    );
  }

  Widget _navButton(
    IconData icon,
    String label,
    bool enabled,
    VoidCallback onPressed,
  ) {
    return Semantics(
      button: true,
      enabled: enabled,
      label: label,
      child: IconButton(
        tooltip: label,
        onPressed: enabled ? onPressed : null,
        icon: Icon(icon, size: 19),
      ),
    );
  }

  Widget _buildErrorOverlay(ColorScheme scheme) {
    return ColoredBox(
      color: const Color(0xFF07070B),
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 440),
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(.045),
                borderRadius: BorderRadius.circular(28),
                border: Border.all(color: Colors.white.withOpacity(.09)),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 64,
                    height: 64,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: const Color(0xFF35C6FF).withOpacity(.12),
                    ),
                    child: const Icon(
                      Icons.cloud_off_rounded,
                      color: Color(0xFF70D7FF),
                      size: 30,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Telegram X-SPYDER offline',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          color: Colors.white,
                          fontWeight: FontWeight.w800,
                        ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Telegram Web tidak dapat dimuat. Periksa koneksi lalu muat ulang.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white60, height: 1.45),
                  ),
                  const SizedBox(height: 20),
                  FilledButton.icon(
                    onPressed: _reload,
                    icon: const Icon(Icons.refresh_rounded),
                    label: const Text('Muat ulang'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
