import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

// ============================================================
// 🎨 DESIGN SYSTEM — RED PREMIUM
// ============================================================
class AppColors {
  static const Color bg0 = Color(0xFF08080A);
  static const Color bg1 = Color(0xFF101014);
  static const Color bg2 = Color(0xFF17171C);

  static const Color text0 = Color(0xFFFFFFFF);
  static const Color text2 = Color(0xFFA1A1AA);
  static const Color text3 = Color(0xFF71717A);

  static const Color accent = Color(0xFFEF4444);
  static const Color accentLight = Color(0xFFF87171);
  static const Color accentDark = Color(0xFFB91C1C);
}

// ============================================================
// 📱 LANDING PAGE
// ============================================================
class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with TickerProviderStateMixin {
  static const String TELEGRAM_URL = 'https://t.me/jaaxnv';
  static const String LOGIN_PAGE = 'login_page.html';

  // --- Animation Controllers ---
  final List<AnimationController> _controllers = [];
  final List<Animation<double>> _fadeAnims = [];
  final List<Animation<Offset>> _slideAnims = [];

  @override
  void initState() {
    super.initState();
    _initAnimations();
  }

  @override
  void dispose() {
    for (var c in _controllers) {
      c.dispose();
    }
    super.dispose();
  }

  void _initAnimations() {
    // 7 animations (anim-0 sampai anim-6)
    final delays = [0, 100, 160, 220, 280, 340, 420];

    for (int i = 0; i < 7; i++) {
      final controller = AnimationController(
        vsync: this,
        duration: const Duration(milliseconds: 800),
      );

      final fadeAnim = CurvedAnimation(
        parent: controller,
        curve: Curves.easeOut,
      );

      final slideAnim = Tween<Offset>(
        begin: const Offset(0, 0.15),
        end: Offset.zero,
      ).animate(CurvedAnimation(
        parent: controller,
        curve: Curves.easeOut,
      ));

      _controllers.add(controller);
      _fadeAnims.add(fadeAnim);
      _slideAnims.add(slideAnim);

      // Start with delay
      Future.delayed(Duration(milliseconds: delays[i]), () {
        if (mounted) controller.forward();
      });
    }
  }

  // ============================================================
  // 🎨 BUILD
  // ============================================================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg0,
      body: SafeArea(
        top: false,
        bottom: false,
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildAnimated(0, _buildBanner()),
              const SizedBox(height: 0),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 22),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 16),
                    _buildAnimated(1, _buildTitle()),
                    const SizedBox(height: 8),
                    _buildAnimated(2, _buildSubtitle()),
                    const SizedBox(height: 22),
                    _buildAnimated(3, _buildInfoBox()),
                    const SizedBox(height: 18),
                    _buildAnimated(4, _buildSignInBtn()),
                    const SizedBox(height: 12),
                    _buildAnimated(5, _buildDevOwnerRow()),
                    const SizedBox(height: 20),
                    _buildAnimated(6, _buildFooterBox()),
                    const SizedBox(height: 36),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAnimated(int index, Widget child) {
    return FadeTransition(
      opacity: _fadeAnims[index],
      child: SlideTransition(
        position: _slideAnims[index],
        child: child,
      ),
    );
  }

  // ============================================================
  // 🖼 BANNER
  // ============================================================
  Widget _buildBanner() {
    return SizedBox(
      height: 290,
      width: double.infinity,
      child: Stack(
        children: [
          // Image background
          Positioned.fill(
            child: Image.asset(
              'assets/images/am.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                color: AppColors.bg1,
                child: const Center(
                  child: Icon(
                    Icons.image_outlined,
                    color: AppColors.text3,
                    size: 60,
                  ),
                ),
              ),
            ),
          ),

          // Red radial glow di atas
          Positioned(
            top: -150,
            left: 0,
            right: 0,
            child: Center(
              child: Container(
                width: 400,
                height: 400,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      AppColors.accent.withOpacity(0.25),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
          ),

          // Bottom gradient
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            height: 90,
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  colors: [AppColors.bg0, Colors.transparent],
                ),
              ),
            ),
          ),

          // Left gradient
          Positioned(
            top: 0,
            bottom: 0,
            left: 0,
            width: 30,
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                  colors: [
                    Colors.black.withOpacity(0.4),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),

          // Right gradient
          Positioned(
            top: 0,
            bottom: 0,
            right: 0,
            width: 30,
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.centerRight,
                  end: Alignment.centerLeft,
                  colors: [
                    Colors.black.withOpacity(0.4),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),

          // Top gradient
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            height: 60,
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withOpacity(0.5),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // 📝 TITLE
  // ============================================================
  Widget _buildTitle() {
    return RichText(
      text: const TextSpan(
        style: TextStyle(
          fontSize: 36,
          fontWeight: FontWeight.w900,
          letterSpacing: 2,
          height: 1.1,
          fontFamily: 'Orbitron',
        ),
        children: [
          TextSpan(
            text: 'Whisper ',
            style: TextStyle(
              color: AppColors.text0,
              shadows: [
                Shadow(
                  color: Color(0x26FFFFFF),
                  blurRadius: 30,
                ),
              ],
            ),
          ),
          TextSpan(
            text: 'Low',
            style: TextStyle(
              color: AppColors.accent,
              shadows: [
                Shadow(
                  color: Color(0x99EF4444),
                  blurRadius: 30,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // 📄 SUBTITLE
  // ============================================================
  Widget _buildSubtitle() {
    return const Text(
      'Aplikasi Yang Dikembangkan Whisper Team',
      style: TextStyle(
        color: AppColors.text2,
        fontSize: 12,
        letterSpacing: 0.8,
        height: 1.5,
        fontWeight: FontWeight.w400,
      ),
    );
  }

  // ============================================================
  // ℹ️ INFO BOX
  // ============================================================
  Widget _buildInfoBox() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF1A0A0A), Color(0xFF101014)],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.accent.withOpacity(0.25)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            blurRadius: 24,
            offset: const Offset(0, 8),
          ),
          BoxShadow(
            color: AppColors.accent.withOpacity(0.08),
            blurRadius: 40,
          ),
        ],
      ),
      child: Stack(
        children: [
          // Top accent line
          Positioned(
            top: -18,
            left: 0,
            right: 0,
            child: Center(
              child: Container(
                height: 2,
                width: double.infinity,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.transparent,
                      AppColors.accent,
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      color: AppColors.accent.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                          color: AppColors.accent.withOpacity(0.3)),
                    ),
                    child: const Icon(
                      FontAwesomeIcons.circleInfo,
                      color: AppColors.accentLight,
                      size: 14,
                    ),
                  ),
                  const SizedBox(width: 10),
                  const Text(
                    'Tentang Whisper',
                    style: TextStyle(
                      color: AppColors.text0,
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.8,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              const Text(
                'Whisper Low adalah platform tools canggih yang dirancang untuk memberikan performa terbaik. Dikembangkan secara profesional oleh tim Whisper dengan teknologi mutakhir dan sistem keamanan tinggi.',
                style: TextStyle(
                  color: AppColors.text2,
                  fontSize: 12,
                  height: 1.65,
                  fontWeight: FontWeight.w400,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ============================================================
  // 🔴 SIGN IN BUTTON
  // ============================================================
  Widget _buildSignInBtn() {
    return GestureDetector(
      onTap: () {
        // Ganti dengan navigasi ke login page
        // Navigator.pushNamed(context, '/login');
        _showInfo('Sign In');
      },
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [AppColors.accent, AppColors.accentDark],
          ),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: AppColors.accent.withOpacity(0.4),
              blurRadius: 28,
              offset: const Offset(0, 10),
            ),
            BoxShadow(
              color: Colors.black.withOpacity(0.4),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            const Icon(
              FontAwesomeIcons.rightToBracket,
              color: Colors.white,
              size: 18,
            ),
            const SizedBox(width: 14),
            const Expanded(
              child: Text(
                'SIGN-IN TO WHISPER',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.2,
                ),
              ),
            ),
            Icon(
              FontAwesomeIcons.chevronRight,
              color: Colors.white.withOpacity(0.7),
              size: 14,
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // ✈️ DEVELOPER + OWNER ROW
  // ============================================================
  Widget _buildDevOwnerRow() {
    return Row(
      children: [
        Expanded(
          child: _buildHalfBtn(
            label: 'Developer',
            onTap: _openTelegram,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _buildHalfBtn(
            label: 'Owner',
            onTap: _openTelegram,
          ),
        ),
      ],
    );
  }

  Widget _buildHalfBtn({
    required String label,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF1A0A0A), Color(0xFF101014)],
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.accent.withOpacity(0.25), width: 1.5),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.4),
              blurRadius: 20,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              FontAwesomeIcons.telegram,
              color: AppColors.accentLight,
              size: 18,
            ),
            const SizedBox(width: 8),
            Flexible(
              child: Text(
                label.toUpperCase(),
                style: const TextStyle(
                  color: AppColors.text0,
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.8,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // 📦 FOOTER BOX
  // ============================================================
  Widget _buildFooterBox() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 22),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF1A0A0A), Color(0xFF101014)],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.accent.withOpacity(0.2)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.5),
            blurRadius: 24,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Stack(
        children: [
          // Top accent line
          Positioned(
            top: -22,
            left: 0,
            right: 0,
            child: Center(
              child: Container(
                height: 2,
                width: double.infinity,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.transparent,
                      AppColors.accent.withOpacity(0.5),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
          ),
          const Column(
            children: [
              Text(
                'By : Jaa Cool',
                style: TextStyle(
                  color: AppColors.accent,
                  fontSize: 14,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2.5,
                  shadows: [
                    Shadow(
                      color: Color(0x66EF4444),
                      blurRadius: 20,
                    ),
                  ],
                ),
              ),
              SizedBox(height: 6),
              Text(
                '© 2026 Whisper Team — All Rights Reserved',
                style: TextStyle(
                  color: AppColors.text3,
                  fontSize: 10,
                  letterSpacing: 0.8,
                  fontWeight: FontWeight.w400,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ============================================================
  // 🔧 HELPERS
  // ============================================================
  Future<void> _openTelegram() async {
    final uri = Uri.parse(TELEGRAM_URL);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      _showInfo('Telegram: $TELEGRAM_URL');
    }
  }

  void _showInfo(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: AppColors.bg2,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: const BorderSide(color: AppColors.accent),
        ),
      ),
    );
  }
}