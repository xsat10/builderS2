import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

// ============================================================
// 🎨 DESIGN SYSTEM
// ============================================================
class AppColors {
  static const Color bg = Color(0xFF050507);

  static const Color text0 = Color(0xFFFFFFFF);
  static const Color text1 = Color(0xFFE4E4E7);
  static const Color text2 = Color(0xFFA1A1AA);
  static const Color text3 = Color(0xFF52525B);

  static const Color red = Color(0xFFEF4444);
  static const Color redLight = Color(0xFFF87171);
  static const Color redDark = Color(0xFF7F1D1D);

  static const Color blue = Color(0xFF3B82F6);
  static const Color blueLight = Color(0xFF60A5FA);
  static const Color blueDark = Color(0xFF1E3A8A);

  static const Color bgCard = Color(0xFF0F0F13);
  static const Color bgCardHover = Color(0xFF16161C);
}

// ============================================================
// 📱 LANDING PAGE
// ============================================================
class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with TickerProviderStateMixin {
  static const String TELEGRAM_URL = 'https://t.me/jaaxnv';

  // Animation controllers
  late AnimationController _rainbowController;
  late AnimationController _entryController;

  // Fade + slide animations (staggered)
  late Animation<double> _fadeBanner;
  late Animation<double> _fadeHero;
  late Animation<double> _fadeCTA;
  late Animation<double> _fadeLinks;
  late Animation<double> _fadeFooter;

  @override
  void initState() {
    super.initState();

    // Rainbow animation — biru-merah, 8 detik
    _rainbowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    )..repeat();

    // Entry animation (staggered)
    _entryController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _fadeBanner = CurvedAnimation(
      parent: _entryController,
      curve: const Interval(0.0, 0.5, curve: Curves.easeOut),
    );
    _fadeHero = CurvedAnimation(
      parent: _entryController,
      curve: const Interval(0.1, 0.6, curve: Curves.easeOut),
    );
    _fadeCTA = CurvedAnimation(
      parent: _entryController,
      curve: const Interval(0.3, 0.8, curve: Curves.easeOut),
    );
    _fadeLinks = CurvedAnimation(
      parent: _entryController,
      curve: const Interval(0.4, 0.9, curve: Curves.easeOut),
    );
    _fadeFooter = CurvedAnimation(
      parent: _entryController,
      curve: const Interval(0.5, 1.0, curve: Curves.easeOut),
    );

    _entryController.forward();
  }

  @override
  void dispose() {
    _rainbowController.dispose();
    _entryController.dispose();
    super.dispose();
  }

  // ============================================================
  // 🌈 RAINBOW SHADER — BIRU-MERAH
  // ============================================================
  static const List<Color> _rainbowColors = [
    Color(0xFF3B82F6), // biru
    Color(0xFF60A5FA), // biru muda
    Color(0xFFFFFFFF), // putih
    Color(0xFFF87171), // merah muda
    Color(0xFFEF4444), // merah
    Color(0xFFF87171), // merah muda
    Color(0xFFFFFFFF), // putih
    Color(0xFF60A5FA), // biru muda
    Color(0xFF3B82F6), // biru
  ];

  Shader _rainbowShader(Rect bounds) {
    final shift = _rainbowController.value;
    return LinearGradient(
      begin: Alignment(-1.0 + shift * 2, 0),
      end: Alignment(1.0 + shift * 2, 0),
      colors: _rainbowColors,
      stops: const [
        0.0,
        0.125,
        0.25,
        0.375,
        0.5,
        0.625,
        0.75,
        0.875,
        1.0,
      ],
    ).createShader(bounds);
  }

  // ============================================================
  // 🎨 WIDGET HELPERS
  // ============================================================
  Widget _fadeSlide({
    required Animation<double> anim,
    required Widget child,
    double offsetY = 15,
  }) {
    return AnimatedBuilder(
      animation: anim,
      builder: (_, __) => Opacity(
        opacity: anim.value.clamp(0.0, 1.0),
        child: Transform.translate(
          offset: Offset(0, offsetY * (1.0 - anim.value)),
          child: child,
        ),
      ),
    );
  }

  Widget _rainbowText({
    required String text,
    required double fontSize,
  }) {
    return AnimatedBuilder(
      animation: _rainbowController,
      builder: (context, _) {
        return ShaderMask(
          shaderCallback: _rainbowShader,
          blendMode: BlendMode.srcIn,
          child: Text(
            text,
            style: TextStyle(
              color: Colors.white,
              fontSize: fontSize,
              fontWeight: FontWeight.w800,
              fontFamily: 'SpaceGrotesk',
              letterSpacing: -2,
              height: 0.95,
            ),
          ),
        );
      },
    );
  }

  // ============================================================
  // 🎬 BUILD
  // ============================================================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        top: false,
        bottom: false,
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ═══════════════════════════════════════════════════
              // BANNER + BRAND
              // ═══════════════════════════════════════════════════
              _fadeSlide(
                anim: _fadeBanner,
                offsetY: 0,
                child: _buildBanner(),
              ),

              // ═══════════════════════════════════════════════════
              // HERO (TITLE + SUBTITLE)
              // ═══════════════════════════════════════════════════
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Transform.translate(
                  offset: const Offset(0, -90),
                  child: _fadeSlide(
                    anim: _fadeHero,
                    child: _buildHero(),
                  ),
                ),
              ),

              // ═══════════════════════════════════════════════════
              // CTA + LINKS + FOOTER
              // ═══════════════════════════════════════════════════
              Transform.translate(
                offset: const Offset(0, -50),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      _fadeSlide(
                        anim: _fadeCTA,
                        child: _buildCTA(),
                      ),
                      const SizedBox(height: 12),
                      _fadeSlide(
                        anim: _fadeLinks,
                        child: _buildLinks(),
                      ),
                      const SizedBox(height: 40),
                      _fadeSlide(
                        anim: _fadeFooter,
                        child: _buildFooter(),
                      ),
                      const SizedBox(height: 32),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // 🖼 BANNER
  // ============================================================
  Widget _buildBanner() {
    return SizedBox(
      width: double.infinity,
      height: 320,
      child: Stack(
        children: [
          // Gambar
          Positioned.fill(
            child: Image.asset(
              'assets/images/am.jpg',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                color: AppColors.bg,
              ),
            ),
          ),

          // Gradient fade ke bawah
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            height: 160,
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  colors: [
                    AppColors.bg,
                    Colors.transparent,
                  ],
                  stops: [0.05, 1.0],
                ),
              ),
            ),
          ),

          // Brand (atas kiri)
          Positioned(
            top: 24,
            left: 20,
            child: _buildBrand(),
          ),
        ],
      ),
    );
  }

  Widget _buildBrand() {
    return Row(
      children: [
        Container(
          width: 34,
          height: 34,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [AppColors.red, AppColors.redDark],
            ),
            borderRadius: BorderRadius.circular(10),
            boxShadow: [
              BoxShadow(
                color: AppColors.red.withOpacity(0.5),
                blurRadius: 16,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: const Icon(
            Icons.bolt_rounded,
            color: Colors.white,
            size: 18,
          ),
        ),
        const SizedBox(width: 10),
        const Text(
          'WHISPER',
          style: TextStyle(
            color: AppColors.text0,
            fontSize: 12,
            fontWeight: FontWeight.w700,
            letterSpacing: 3,
            shadows: [
              Shadow(
                color: Colors.black87,
                blurRadius: 8,
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ============================================================
  // 🎯 HERO
  // ============================================================
  Widget _buildHero() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // "Whisper" — putih
        const Text(
          'Whisper',
          style: TextStyle(
            color: AppColors.text0,
            fontSize: 54,
            fontWeight: FontWeight.w800,
            fontFamily: 'SpaceGrotesk',
            letterSpacing: -2,
            height: 0.95,
          ),
        ),

        // "Low" — rainbow biru-merah
        _rainbowText(
          text: 'Low',
          fontSize: 54,
        ),

        const SizedBox(height: 16),

        // Subtitle
        const Text(
          'Platform tools yang dirancang untuk performa terbaik.',
          style: TextStyle(
            color: AppColors.text2,
            fontSize: 13.5,
            fontWeight: FontWeight.w400,
            fontFamily: 'JetBrainsMono',
            letterSpacing: 0.2,
            height: 1.6,
          ),
        ),
      ],
    );
  }

  // ============================================================
  // 🚀 CTA BUTTON
  // ============================================================
  Widget _buildCTA() {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: _goToLogin,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 20),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [AppColors.red, AppColors.redDark],
            ),
            borderRadius: BorderRadius.circular(18),
            boxShadow: [
              BoxShadow(
                color: AppColors.red.withOpacity(0.35),
                blurRadius: 32,
                offset: const Offset(0, 12),
              ),
              BoxShadow(
                color: Colors.black.withOpacity(0.3),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Row(
            children: [
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Sign-In',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.3,
                      ),
                    ),
                    SizedBox(height: 3),
                    Text(
                      'MASUK KE DASHBOARD',
                      style: TextStyle(
                        color: Color(0xBFFFFFFF),
                        fontSize: 10.5,
                        fontFamily: 'JetBrainsMono',
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(
                Icons.arrow_forward_rounded,
                color: Color(0xD9FFFFFF),
                size: 20,
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // 🔗 LINK BUTTONS
  // ============================================================
  Widget _buildLinks() {
    return Row(
      children: [
        Expanded(
          child: _buildLinkBtn(
            icon: FontAwesomeIcons.telegram,
            label: 'Developer',
            url: TELEGRAM_URL,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _buildLinkBtn(
            icon: FontAwesomeIcons.telegram,
            label: 'Owner',
            url: TELEGRAM_URL,
          ),
        ),
      ],
    );
  }

  Widget _buildLinkBtn({
    required IconData icon,
    required String label,
    required String url,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () => _openUrl(url),
        borderRadius: BorderRadius.circular(14),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 14),
          decoration: BoxDecoration(
            color: AppColors.bgCard,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: Colors.white.withOpacity(0.08),
              width: 1,
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: AppColors.redLight, size: 14),
              const SizedBox(width: 8),
              Text(
                label,
                style: const TextStyle(
                  color: AppColors.text1,
                  fontSize: 12.5,
                  fontWeight: FontWeight.w500,
                  letterSpacing: 0.3,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // 📝 FOOTER
  // ============================================================
  Widget _buildFooter() {
    return Center(
      child: RichText(
        textAlign: TextAlign.center,
        text: TextSpan(
          style: const TextStyle(
            fontFamily: 'JetBrainsMono',
            fontSize: 10,
            color: AppColors.text3,
            letterSpacing: 1,
            height: 1.8,
          ),
          children: const [
            TextSpan(text: 'BY '),
            TextSpan(
              text: 'JAA COOL',
              style: TextStyle(
                color: AppColors.redLight,
                fontWeight: FontWeight.w500,
              ),
            ),
            TextSpan(text: ' · © 2026 WHISPER TEAM'),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // 🔧 HELPERS
  // ============================================================
  Future<void> _goToLogin() async {
    HapticFeedback.lightImpact();
    // TODO: Navigate ke LoginPage
    // Navigator.pushReplacement(
    //   context,
    //   MaterialPageRoute(builder: (_) => const LoginPage()),
    // );
    debugPrint('Go to login');
  }

  Future<void> _openUrl(String url) async {
    HapticFeedback.lightImpact();
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }
}