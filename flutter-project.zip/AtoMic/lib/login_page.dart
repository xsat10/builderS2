import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

// ============================================================
// 🎨 DESIGN SYSTEM — RED PREMIUM
// ============================================================
class AppColors {
  static const Color bg0 = Color(0xFF08080A);
  static const Color bg1 = Color(0xFF101014);
  static const Color bg2 = Color(0xFF17171C);

  static const Color text0 = Color(0xFFFFFFFF);
  static const Color text2 = Color(0xFFA1A1AA);
  static const Color text3 = Color(0xFF71717A);
  static const Color text4 = Color(0xFF52525B);

  static const Color accent = Color(0xFFEF4444);
  static const Color accentLight = Color(0xFFF87171);
  static const Color accentDark = Color(0xFFB91C1C);

  static const Color info = Color(0xFF3B82F6);
  static const Color infoLight = Color(0xFF60A5FA);

  static const Color border2 = Color(0x14FFFFFF);
  static const Color border3 = Color(0x1FFFFFFF);
}

// ============================================================
// 📱 LOGIN PAGE
// ============================================================
class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with TickerProviderStateMixin {
  static const String BASE_URL = 'http://freepanelbygua.panel-xsat.my.id:3655';
  static const String TELEGRAM_URL = 'https://t.me/jaaxnv';

  // --- Controllers ---
  final userController = TextEditingController();
  final passController = TextEditingController();

  // --- State ---
  bool isLoading = false;
  bool _obscurePassword = true;
  String? _androidId;

  // --- Animations ---
  late AnimationController _logoPulseController;
  late AnimationController _logoShineController;
  late AnimationController _fadeUpController;
  late Animation<double> _fadeUpAnim;

  @override
  void initState() {
    super.initState();
    _initAnimations();
    _initAutoLogin();
  }

  @override
  void dispose() {
    _logoPulseController.dispose();
    _logoShineController.dispose();
    _fadeUpController.dispose();
    userController.dispose();
    passController.dispose();
    super.dispose();
  }

  // ============================================================
  // 🎬 ANIMATIONS
  // ============================================================
  void _initAnimations() {
    // Logo pulse (glow)
    _logoPulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true);

    // Logo shine sweep
    _logoShineController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat();

    // Fade up entry
    _fadeUpController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    );
    _fadeUpAnim = CurvedAnimation(
      parent: _fadeUpController,
      curve: const Cubic(0.22, 1, 0.36, 1),
    );
    _fadeUpController.forward();
  }

  // ============================================================
  // 🔐 AUTO LOGIN
  // ============================================================
  Future<void> _initAutoLogin() async {
    _androidId = await _getAndroidId();

    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString('username');
    final savedPass = prefs.getString('password');
    final savedKey = prefs.getString('key');

    if (savedUser == null || savedPass == null || savedKey == null) return;

    final url = Uri.parse(
        '$BASE_URL/myInfo?username=${Uri.encodeComponent(savedUser)}&password=${Uri.encodeComponent(savedPass)}&androidId=$_androidId&key=$savedKey');

    try {
      final res = await http.get(url);
      final data = jsonDecode(res.body);

      if (data['valid'] == true) {
        if (!mounted) return;
        // TODO: Navigate ke DashboardPage
        // Navigator.pushReplacement(
        //   context,
        //   MaterialPageRoute(builder: (_) => const DashboardPage()),
        // );
        _showSnack('Auto login berhasil — redirect ke dashboard');
      }
    } catch (_) {
      // Silent fail — biarin user login manual
    }
  }

  Future<String> _getAndroidId() async {
    final prefs = await SharedPreferences.getInstance();
    String? id = prefs.getString('device_id');
    if (id == null) {
      id = 'web_${DateTime.now().millisecondsSinceEpoch}_${(1000 + (DateTime.now().microsecond % 9000))}';
      await prefs.setString('device_id', id);
    }
    return id;
  }

  // ============================================================
  // 🔑 LOGIN
  // ============================================================
  Future<void> _login() async {
    final username = userController.text.trim();
    final password = passController.text.trim();

    if (username.isEmpty || password.isEmpty) {
      _showPopup('info', 'Peringatan', 'Username dan password wajib diisi.');
      return;
    }

    setState(() => isLoading = true);

    try {
      final androidId = _androidId ?? await _getAndroidId();

      final res = await http.post(
        Uri.parse('$BASE_URL/validate'),
        body: {
          'username': username,
          'password': password,
          'androidId': androidId,
        },
      );

      final data = jsonDecode(res.body);

      if (data['expired'] == true) {
        _showPopup(
          'error',
          'Access Expired',
          'Masa akses Anda telah habis.\nSilakan perpanjang akses.',
          showContact: true,
        );
      } else if (data['valid'] != true) {
        final errorMsg = (data['message'] ?? '').toString().toLowerCase();
        if (errorMsg.contains('perangkat') ||
            errorMsg.contains('device') ||
            errorMsg.contains('another')) {
          _showPopup(
            'error',
            'Sesi Aktif',
            'Akun ini sedang login di perangkat lain.\nSilakan logout di perangkat lama.',
          );
        } else {
          _showPopup(
            'error',
            'Login Gagal',
            'Username atau password salah.',
          );
        }
      } else {
        // Save session
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('username', username);
        await prefs.setString('password', password);
        await prefs.setString('key', data['key'] ?? '');
        await prefs.setString('role', data['role'] ?? '');
        await prefs.setString('expiredDate', data['expiredDate'] ?? '');
        await prefs.setString('listBug', jsonEncode(data['listBug'] ?? []));
        await prefs.setString('listDDoS', jsonEncode(data['listDDoS'] ?? []));
        await prefs.setString('news', jsonEncode(data['news'] ?? []));

        if (!mounted) return;
        // TODO: Navigate ke DashboardPage
        // Navigator.pushReplacement(
        //   context,
        //   MaterialPageRoute(builder: (_) => const DashboardPage()),
        // );
        _showSnack('Login berhasil — redirect ke dashboard');
      }
    } catch (_) {
      _showPopup('error', 'Connection Error', 'Gagal terhubung ke server.');
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  // ============================================================
  // 🎨 BUILD
  // ============================================================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg0,
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: const Alignment(0, -1),
            radius: 1.5,
            colors: [
              AppColors.accent.withOpacity(0.12),
              Colors.transparent,
            ],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.all(24),
              child: FadeTransition(
                opacity: _fadeUpAnim,
                child: SlideTransition(
                  position: Tween<Offset>(
                    begin: const Offset(0, 0.06),
                    end: Offset.zero,
                  ).animate(_fadeUpAnim),
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 400),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        _buildLogoSection(),
                        const SizedBox(height: 36),
                        _buildForm(),
                        const SizedBox(height: 32),
                        _buildFooter(),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ============================================================
  // 🎯 LOGO SECTION
  // ============================================================
  Widget _buildLogoSection() {
    return Column(
      children: [
        // Animated logo box
        AnimatedBuilder(
          animation: Listenable.merge([
            _logoPulseController,
            _logoShineController,
          ]),
          builder: (ctx, child) {
            final pulseValue = _logoPulseController.value;
            final shineValue = _logoShineController.value;

            return Container(
              width: 110,
              height: 110,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [AppColors.accent, AppColors.accentDark],
                ),
                borderRadius: BorderRadius.circular(28),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.accent.withOpacity(0.4 + (pulseValue * 0.2)),
                    blurRadius: 60 + (pulseValue * 20),
                    offset: const Offset(0, 20),
                  ),
                  BoxShadow(
                    color: Colors.black.withOpacity(0.5),
                    blurRadius: 24,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(28),
                child: Stack(
                  children: [
                    const Center(
                      child: Icon(
                        Icons.workspace_premium_rounded,
                        color: Colors.white,
                        size: 52,
                      ),
                    ),
                    // Shine sweep
                    Positioned.fill(
                      child: Transform.translate(
                        offset: Offset(
                          (-1 + shineValue * 3) * 110,
                          0,
                        ),
                        child: Transform.rotate(
                          angle: 0.78,
                          child: Container(
                            width: 60,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Colors.transparent,
                                  Colors.white.withOpacity(0.15),
                                  Colors.transparent,
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
        const SizedBox(height: 24),
        // Welcome title
        const Text(
          'Welcome To\nWhisper Low',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: AppColors.text0,
            fontSize: 26,
            fontWeight: FontWeight.w900,
            letterSpacing: -0.8,
            height: 1.15,
          ),
        ),
        const SizedBox(height: 8),
        const Text(
          'Please enter your details to sign in',
          style: TextStyle(
            color: AppColors.text3,
            fontSize: 14,
            fontWeight: FontWeight.w400,
            height: 1.5,
          ),
        ),
      ],
    );
  }

  // ============================================================
  // 📝 FORM
  // ============================================================
  Widget _buildForm() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // Username
        _buildInputField(
          label: 'Username',
          controller: userController,
          hint: 'Enter your username',
          icon: Icons.person_outline_rounded,
          keyboardType: TextInputType.text,
        ),
        const SizedBox(height: 16),

        // Password
        _buildInputField(
          label: 'Password',
          controller: passController,
          hint: 'Enter your password',
          icon: Icons.lock_outline_rounded,
          obscure: _obscurePassword,
          isPassword: true,
        ),
        const SizedBox(height: 28),

        // Sign In button
        _buildSignInBtn(),
        const SizedBox(height: 14),

        // Buy button
        _buildBuyBtn(),
      ],
    );
  }

  Widget _buildInputField({
    required String label,
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    TextInputType keyboardType = TextInputType.text,
    bool obscure = false,
    bool isPassword = false,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 2, bottom: 8),
          child: Text(
            label.toUpperCase(),
            style: const TextStyle(
              color: AppColors.text2,
              fontSize: 11,
              fontWeight: FontWeight.w700,
              letterSpacing: 1.2,
            ),
          ),
        ),
        Container(
          decoration: BoxDecoration(
            color: AppColors.bg1,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: AppColors.border2, width: 1.5),
          ),
          child: TextField(
            controller: controller,
            obscureText: obscure,
            keyboardType: keyboardType,
            style: const TextStyle(
              color: AppColors.text0,
              fontSize: 15,
              fontWeight: FontWeight.w500,
            ),
            cursorColor: AppColors.accent,
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: const TextStyle(
                color: AppColors.text4,
                fontSize: 15,
                fontWeight: FontWeight.w400,
              ),
              prefixIcon: Padding(
                padding: const EdgeInsets.only(left: 18, right: 12),
                child: Icon(
                  icon,
                  color: AppColors.text3,
                  size: 20,
                ),
              ),
              prefixIconConstraints:
                  const BoxConstraints(minWidth: 50, minHeight: 50),
              suffixIcon: isPassword
                  ? IconButton(
                      icon: Icon(
                        _obscurePassword
                            ? Icons.visibility_off_outlined
                            : Icons.visibility_outlined,
                        color: AppColors.text3,
                        size: 20,
                      ),
                      onPressed: () {
                        setState(
                            () => _obscurePassword = !_obscurePassword);
                      },
                    )
                  : null,
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(
                vertical: 18,
                horizontal: 16,
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ============================================================
  // 🔴 SIGN IN BUTTON
  // ============================================================
  Widget _buildSignInBtn() {
    return GestureDetector(
      onTap: isLoading ? null : _login,
      child: Container(
        height: 58,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: isLoading
                ? [
                    AppColors.accent.withOpacity(0.6),
                    AppColors.accentDark.withOpacity(0.6),
                  ]
                : [AppColors.accent, AppColors.accentDark],
          ),
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
              color: AppColors.accent.withOpacity(0.4),
              blurRadius: 32,
              offset: const Offset(0, 12),
            ),
            BoxShadow(
              color: Colors.black.withOpacity(0.3),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Center(
          child: isLoading
              ? const SizedBox(
                  width: 22,
                  height: 22,
                  child: CircularProgressIndicator(
                    color: Colors.white,
                    strokeWidth: 2.5,
                  ),
                )
              : const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'SIGN IN',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1.2,
                      ),
                    ),
                    SizedBox(width: 10),
                    Icon(
                      Icons.arrow_forward_rounded,
                      color: Colors.white,
                      size: 18,
                    ),
                  ],
                ),
        ),
      ),
    );
  }

  // ============================================================
  // 🛒 BUY BUTTON
  // ============================================================
  Widget _buildBuyBtn() {
    return GestureDetector(
      onTap: _openBuy,
      child: Container(
        height: 52,
        decoration: BoxDecoration(
          color: Colors.transparent,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppColors.border3, width: 1.5),
        ),
        child: const Center(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.shopping_cart_outlined,
                color: AppColors.text2,
                size: 18,
              ),
              SizedBox(width: 10),
              Text(
                'No Access? Buy Here',
                style: TextStyle(
                  color: AppColors.text2,
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // 📄 FOOTER
  // ============================================================
  Widget _buildFooter() {
    return const Padding(
      padding: EdgeInsets.symmetric(horizontal: 20),
      child: Text(
        'By continuing, you agree to our Terms of Service',
        textAlign: TextAlign.center,
        style: TextStyle(
          color: AppColors.text4,
          fontSize: 11,
          height: 1.5,
        ),
      ),
    );
  }

  // ============================================================
  // 🎬 MODAL POPUP
  // ============================================================
  void _showPopup(
    String type,
    String title,
    String message, {
    bool showContact = false,
  }) {
    final isError = type == 'error';

    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.8),
      builder: (ctx) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Dialog(
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: Container(
            constraints: const BoxConstraints(maxWidth: 360),
            padding: const EdgeInsets.fromLTRB(24, 28, 24, 24),
            decoration: BoxDecoration(
              color: AppColors.bg1,
              borderRadius: BorderRadius.circular(28),
              border: Border.all(color: AppColors.border2, width: 1.5),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.6),
                  blurRadius: 60,
                  offset: const Offset(0, 24),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Icon
                Container(
                  width: 72,
                  height: 72,
                  decoration: BoxDecoration(
                    color: isError
                        ? AppColors.accent.withOpacity(0.12)
                        : AppColors.info.withOpacity(0.12),
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: isError
                          ? AppColors.accent.withOpacity(0.35)
                          : AppColors.info.withOpacity(0.35),
                      width: 1.5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: isError
                            ? AppColors.accent.withOpacity(0.25)
                            : AppColors.info.withOpacity(0.25),
                        blurRadius: 40,
                      ),
                    ],
                  ),
                  child: Icon(
                    isError
                        ? Icons.cancel_outlined
                        : Icons.info_outline_rounded,
                    color: isError ? AppColors.accentLight : AppColors.infoLight,
                    size: 32,
                  ),
                ),
                const SizedBox(height: 18),
                // Title
                Text(
                  title,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: AppColors.text0,
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                    letterSpacing: -0.3,
                  ),
                ),
                const SizedBox(height: 10),
                // Message
                Text(
                  message,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: AppColors.text2,
                    fontSize: 14,
                    height: 1.6,
                  ),
                ),
                const SizedBox(height: 24),

                // Confirm button
                SizedBox(
                  width: double.infinity,
                  child: GestureDetector(
                    onTap: () {
                      Navigator.pop(ctx);
                      if (showContact) _openTelegram();
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 15),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [AppColors.accent, AppColors.accentDark],
                        ),
                        borderRadius: BorderRadius.circular(14),
                        boxShadow: [
                          BoxShadow(
                            color: AppColors.accent.withOpacity(0.4),
                            blurRadius: 20,
                            offset: const Offset(0, 6),
                          ),
                        ],
                      ),
                      child: Center(
                        child: Text(
                          showContact
                              ? 'CONTACT ADMIN'
                              : 'CLOSE',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 13,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 1.2,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),

                // Cancel button (kalo showContact)
                if (showContact) ...[
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: GestureDetector(
                      onTap: () => Navigator.pop(ctx),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 15),
                        decoration: BoxDecoration(
                          color: Colors.transparent,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                              color: AppColors.border3, width: 1.5),
                        ),
                        child: const Center(
                          child: Text(
                            'CLOSE',
                            style: TextStyle(
                              color: AppColors.text2,
                              fontSize: 13,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 1.2,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ============================================================
  // 🔧 HELPERS
  // ============================================================
  Future<void> _openBuy() async {
    _openTelegram();
  }

  Future<void> _openTelegram() async {
    final uri = Uri.parse(TELEGRAM_URL);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      _showSnack('Telegram: $TELEGRAM_URL');
    }
  }

  void _showSnack(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: AppColors.bg2,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: const BorderSide(color: AppColors.accent),
        ),
      ),
    );
  }
}