import 'package:flutter/material.dart';
import 'set.dart';
import 'tap.dart';

class SplashVideoPage extends StatefulWidget {
  final Widget nextPage;
  final String username;

  const SplashVideoPage({
    super.key,
    required this.nextPage,
    required this.username,
  });

  @override
  State<SplashVideoPage> createState() => _SplashVideoPageState();
}

class _OnboardStep {
  final String badge;
  final String title;
  final String subtitle;
  final String buttonLabel;
  final bool filledButton;

  const _OnboardStep({
    required this.badge,
    required this.title,
    required this.subtitle,
    required this.buttonLabel,
    this.filledButton = false,
  });
}

class _SplashVideoPageState extends State<SplashVideoPage>
    with TickerProviderStateMixin {
  late final PageController _pageController;
  late final AnimationController _introController;
  late final AnimationController _pulseController;
  late final AnimationController _rainbowController;

  double _page = 0;
  bool _navigated = false;

  // ─── TEMA WARNA — DARK PREMIUM RED ──────────────────────────────────────
  static const Color bgMain      = Color(0xFF08080A);
  static const Color bgCard      = Color(0xFF1A0A0A);
  static const Color accentRed   = Color(0xFFEF4444);
  static const Color borderRed   = Color(0xFFF87171);
  static const Color textMain    = Colors.white;
  static const Color textSub     = Color(0xFFA1A1AA);

  // ─── RAINBOW MERAH-PUTIH PALETTE ──────────────────────────────────────
  static const List<Color> rainbowColors = [
    Color(0xFFFFFFFF), // putih
    Color(0xFFF87171), // merah muda
    Color(0xFFEF4444), // merah
    Color(0xFFB91C1C), // merah gelap
    Color(0xFFEF4444), // merah
    Color(0xFFF87171), // merah muda
    Color(0xFFFFFFFF), // putih
  ];

  late final List<_OnboardStep> _steps = [
    _OnboardStep(
      badge: "WELCOME !!!",
      title: "Welcome To Whisper Low\n${widget.username.toUpperCase()}",
      subtitle: "Nikmati pengalaman terbaik bersama kami",
      buttonLabel: "LANJUT",
    ),
    const _OnboardStep(
      badge: "TERIMA KASIH YA !!",
      title: "SETIA DENGAN KAMI",
      subtitle:
          "Terima kasih telah mensupport kami, walaupun terkadang project kami sering ampas / error, tapi kalian hebat selalu setia dengan Whisper Low",
      buttonLabel: "LANJUT",
    ),
    const _OnboardStep(
      badge: "ARE YOU READY??",
      title: "ENTER DASHBOARD",
      subtitle: "Putar musiknya rayakan bersama bro!!",
      buttonLabel: "MULAI SEKARANG",
      filledButton: true,
    ),
  ];

  @override
  void initState() {
    super.initState();

    _pageController = PageController()
      ..addListener(() {
        setState(() {
          _page = _pageController.page ?? 0;
        });
      });

    _introController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1100),
    )..forward();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2200),
    )..repeat(reverse: true);

    // Rainbow animation — gerakan warna pelangi merah-putih
    _rainbowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat();
  }

  @override
  void dispose() {
    _pageController.dispose();
    _introController.dispose();
    _pulseController.dispose();
    _rainbowController.dispose();
    super.dispose();
  }

  int get _currentIndex => _page.round().clamp(0, _steps.length - 1);

  void _next() {
    if (_currentIndex < _steps.length - 1) {
      _pageController.nextPage(
        duration: const Duration(milliseconds: 550),
        curve: Curves.easeOutCubic,
      );
    } else {
      _goNext();
    }
  }

  void _skip() => _goNext();

  void _goNext() {
    if (_navigated) return;
    _navigated = true;
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 650),
        pageBuilder: (_, animation, __) => widget.nextPage,
        transitionsBuilder: (_, animation, __, child) {
          final curved = CurvedAnimation(
            parent: animation,
            curve: Curves.easeOutCubic,
          );
          return FadeTransition(
            opacity: curved,
            child: ScaleTransition(
              scale: Tween(begin: 0.97, end: 1.0).animate(curved),
              child: child,
            ),
          );
        },
      ),
    );
  }

  // interval helper – animasi masuk bertahap (staggered)
  Animation<double> _staggered(double start, double end) {
    return CurvedAnimation(
      parent: _introController,
      curve: Interval(start, end, curve: Curves.easeOutCubic),
    );
  }

  // ─── RAINBOW GRADIENT SHADER ──────────────────────────────────────────
  Shader rainbowShader(Rect bounds) {
    final shift = _rainbowController.value;
    return LinearGradient(
      begin: Alignment(-1.0 + shift * 2, -0.5),
      end: Alignment(1.0 + shift * 2, 0.5),
      colors: rainbowColors,
      stops: const [0.0, 0.16, 0.32, 0.5, 0.68, 0.84, 1.0],
    ).createShader(bounds);
  }

  // ─── RAINBOW TEXT WIDGET ──────────────────────────────────────────────
  Widget rainbowText({
    required String text,
    required double fontSize,
    FontWeight fontWeight = FontWeight.w800,
    double letterSpacing = 1.2,
    double height = 1.35,
    TextAlign textAlign = TextAlign.center,
    int maxLines = 3,
  }) {
    return AnimatedBuilder(
      animation: _rainbowController,
      builder: (context, _) {
        return ShaderMask(
          shaderCallback: rainbowShader,
          blendMode: BlendMode.srcIn,
          child: Text(
            text,
            textAlign: textAlign,
            maxLines: maxLines,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontFamily: 'Orbitron',
              color: Colors.white,
              fontSize: fontSize,
              fontWeight: fontWeight,
              letterSpacing: letterSpacing,
              height: height,
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final bgFade     = _staggered(0.0,  0.55);
    final topFade    = _staggered(0.15, 0.65);
    final cardFade   = _staggered(0.30, 0.85);
    final bottomFade = _staggered(0.45, 1.0);

    return GlobalTouchWrapper(
      child: Scaffold(
        backgroundColor: bgMain,
        body: Stack(
          fit: StackFit.expand,
          children: [
            // ── BACKGROUND SOLID HITAM ────────────────────────────────────
            FadeTransition(
              opacity: bgFade,
              child: Container(color: bgMain),
            ),

            // ── OVERLAY GRADIENT LEMBUT (hitam ke merah gelap) ─────────────
            Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    stops: const [0.0, 0.35, 0.65, 1.0],
                    colors: [
                      accentRed.withOpacity(0.10),
                      bgMain,
                      bgMain,
                      const Color(0xFF150505),
                    ],
                  ),
                ),
              ),
            ),

            // ── AMBIENT GLOW KIRI (merah blur) ─────────────────────────────
            Positioned(
              left: -80,
              top: MediaQuery.of(context).size.height * 0.15,
              child: Container(
                width: 200,
                height: 200,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      accentRed.withOpacity(0.25),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),

            // ── AMBIENT GLOW KANAN (merah blur) ────────────────────────────
            Positioned(
              right: -100,
              bottom: MediaQuery.of(context).size.height * 0.10,
              child: Container(
                width: 240,
                height: 240,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      accentRed.withOpacity(0.18),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),

            // ── KONTEN UTAMA ─────────────────────────────────────────────────
            SafeArea(
              child: Column(
                children: [
                  // ── LOGO (icon) & TOMBOL LEWATI ────────────────────────────
                  FadeTransition(
                    opacity: topFade,
                    child: SlideTransition(
                      position: Tween<Offset>(
                        begin: const Offset(0, -0.3),
                        end: Offset.zero,
                      ).animate(topFade),
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            // Logo icon
                            Container(
                              width: 42,
                              height: 42,
                              decoration: BoxDecoration(
                                color: bgCard,
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(
                                  color: Colors.black,
                                  width: 1.5,
                                ),
                                boxShadow: const [
                                  BoxShadow(
                                    color: Colors.black,
                                    blurRadius: 0,
                                    offset: Offset(3, 3),
                                  ),
                                ],
                              ),
                              child: const Icon(
                                Icons.bolt_rounded,
                                color: accentRed,
                                size: 22,
                              ),
                            ),

                            // Tombol LEWATI
                            GestureDetector(
                              onTap: _skip,
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 16, vertical: 8),
                                decoration: BoxDecoration(
                                  color: bgCard,
                                  borderRadius: BorderRadius.circular(14),
                                  border: Border.all(
                                    color: Colors.black,
                                    width: 1.5,
                                  ),
                                  boxShadow: const [
                                    BoxShadow(
                                      color: Colors.black,
                                      blurRadius: 0,
                                      offset: Offset(3, 3),
                                    ),
                                  ],
                                ),
                                child: Text(
                                  "LEWATI",
                                  style: TextStyle(
                                    fontFamily: 'Orbitron',
                                    color: textMain,
                                    fontSize: 12,
                                    letterSpacing: 1,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),

                  const Spacer(),

                  // ── KARTU ONBOARDING (PageView) ────────────────────────────
                  FadeTransition(
                    opacity: cardFade,
                    child: SlideTransition(
                      position: Tween<Offset>(
                        begin: const Offset(0, 0.15),
                        end: Offset.zero,
                      ).animate(cardFade),
                      child: SizedBox(
                        height: 245,
                        child: PageView.builder(
                          controller: _pageController,
                          physics: const BouncingScrollPhysics(),
                          itemCount: _steps.length,
                          itemBuilder: (context, index) {
                            final distance =
                                (index - _page).abs().clamp(0.0, 1.0);
                            final scale   = 1.0 - (distance * 0.08);
                            final opacity = 1.0 - (distance * 0.6);

                            return Transform.scale(
                              scale: scale,
                              child: Opacity(
                                opacity: opacity.clamp(0.0, 1.0),
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 20),
                                  child: _buildCard(_steps[index], index),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 22),

                  // ── HINT SWIPE + DOTS ────────────────────────────────────
                  FadeTransition(
                    opacity: bottomFade,
                    child: Column(
                      children: [
                        Text(
                          "Geser untuk lanjut",
                          style: TextStyle(
                            fontFamily: 'Orbitron',
                            color: textSub,
                            fontSize: 11,
                            letterSpacing: 0.6,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: List.generate(_steps.length, (i) {
                            final active = i == _currentIndex;
                            return AnimatedContainer(
                              duration: const Duration(milliseconds: 350),
                              curve: Curves.easeOutCubic,
                              margin: const EdgeInsets.symmetric(horizontal: 4),
                              width:  active ? 22 : 7,
                              height: 7,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(6),
                                color: active
                                    ? accentRed
                                    : Colors.white.withOpacity(0.18),
                                boxShadow: active
                                    ? [
                                        BoxShadow(
                                          color: accentRed.withOpacity(0.6),
                                          blurRadius: 8,
                                          spreadRadius: 0.5,
                                        ),
                                      ]
                                    : null,
                              ),
                            );
                          }),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 18),

                  // ── TOMBOL AKSI (LANJUT / MULAI SEKARANG) ───────────────
                  FadeTransition(
                    opacity: bottomFade,
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
                      child: GestureDetector(
                        onTap: _next,
                        child: AnimatedBuilder(
                          animation: _pulseController,
                          builder: (context, child) {
                            final pulse    = _pulseController.value;
                            final isFilled = _steps[_currentIndex].filledButton;
                            return AnimatedContainer(
                              duration: const Duration(milliseconds: 450),
                              curve: Curves.easeOutCubic,
                              width: double.infinity,
                              height: 52,
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(16),
                                color: isFilled
                                    ? Color.lerp(
                                        accentRed, borderRed, pulse * 0.4)
                                    : bgCard,
                                border: Border.all(
                                  color: Colors.black,
                                  width: 1.5,
                                ),
                                boxShadow: [
                                  // Neubrutalism: hard offset shadow
                                  const BoxShadow(
                                    color: Colors.black,
                                    blurRadius: 0,
                                    offset: Offset(4, 4),
                                  ),
                                  if (isFilled)
                                    BoxShadow(
                                      color: accentRed.withOpacity(
                                          0.35 + 0.15 * pulse),
                                      blurRadius: 18 + 6 * pulse,
                                      spreadRadius: 0,
                                    ),
                                ],
                              ),
                              child: AnimatedSwitcher(
                                duration: const Duration(milliseconds: 300),
                                child: Text(
                                  _steps[_currentIndex].buttonLabel,
                                  key: ValueKey(
                                      _steps[_currentIndex].buttonLabel),
                                  style: TextStyle(
                                    fontFamily: 'Orbitron',
                                    color: isFilled ? Colors.white : textMain,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: 1.5,
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCard(_OnboardStep step, int index) {
    return Container(
      padding: const EdgeInsets.fromLTRB(24, 18, 24, 20),
      decoration: BoxDecoration(
        color: bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Colors.black,
          width: 1.5,
        ),
        boxShadow: [
          // Neubrutalism: hard offset shadow
          const BoxShadow(
            color: Colors.black,
            blurRadius: 0,
            offset: Offset(4, 4),
          ),
          BoxShadow(
            color: accentRed.withOpacity(0.18),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        mainAxisSize: MainAxisSize.min,
        children: [
          // ── GARIS ATAS KARTU (aksen merah) ─────────────────────────────
          Container(
            width: 34,
            height: 3,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [borderRed, accentRed],
              ),
              borderRadius: BorderRadius.circular(6),
            ),
          ),
          const SizedBox(height: 16),

          // ── BADGE ────────────────────────────────────────────────────
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: accentRed.withOpacity(0.10),
              border: Border.all(color: accentRed.withOpacity(0.45)),
            ),
            child: Text(
              step.badge,
              style: const TextStyle(
                fontFamily: 'Orbitron',
                color: accentRed,
                fontSize: 11,
                letterSpacing: 1,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          const SizedBox(height: 14),

          // ── JUDUL — RAINBOW MERAH-PUTIH ANIMASI ──────────────────────
          rainbowText(
            text: step.title,
            fontSize: 20,
            fontWeight: FontWeight.w800,
            letterSpacing: 1.2,
            height: 1.35,
            maxLines: 3,
          ),
          const SizedBox(height: 10),

          // ── SUBJUDUL ─────────────────────────────────────────────────
          Text(
            step.subtitle,
            textAlign: TextAlign.center,
            maxLines: 3,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontFamily: 'Orbitron',
              color: textSub,
              fontSize: 12.5,
              height: 1.5,
              letterSpacing: 0.3,
            ),
          ),
          const SizedBox(height: 12),

          // ── INDIKATOR HALAMAN "1 / 3" ─────────────────────────────
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.05),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(
              "${index + 1} / ${_steps.length}",
              style: TextStyle(
                fontFamily: 'Orbitron',
                color: textSub,
                fontSize: 10.5,
              ),
            ),
          ),
        ],
      ),
    );
  }
}