import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'widgets/custom_popup.dart';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  late AnimationController _pulseController;
  late AnimationController _rainbowController;
  String selectedBugId = "";
  VideoPlayerController? _videoController;
  FixedExtentScrollController? _wheelController;

  // --- State Baru: Mode Target ---
  String _selectedBugMode = "number"; // 'number' atau 'group'

  // --- State Baru: Mode Sender ---
  String _senderMode = "private"; // 'private' atau 'global'
  int _privateSenderCount = 0;
  int _globalSenderCount = 0;

  bool _isSending = false;

  // --- Tema RED PREMIUM ---
  static const Color bgMain = Color(0xFF08080A);
  static const Color bgSurface = Color(0xFF17171C);
  static const Color bgCard = Color(0xFF1A0A0A);

  static const Color textMain = Color(0xFFFFFFFF);
  static const Color textSub = Color(0xFFA1A1AA);

  static const Color accentColor = Color(0xFFEF4444);
  static const Color borderLight = Color(0xFFF87171);

  // --- Rainbow Merah-Putih Palette ---
  static const List<Color> rainbowColors = [
    Color(0xFFFFFFFF),
    Color(0xFFF87171),
    Color(0xFFEF4444),
    Color(0xFFB91C1C),
    Color(0xFFEF4444),
    Color(0xFFF87171),
    Color(0xFFFFFFFF),
  ];

  @override
  void initState() {
    super.initState();

    _videoController = VideoPlayerController.asset('assets/videos/bug.mp4')
      ..initialize().then((_) {
        setState(() {});
        _videoController?.setVolume(1.0);
        _videoController?.setLooping(true);
        _videoController?.play();
      });

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _rainbowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat();

    // Filter bug default
    if (widget.listBug.isNotEmpty) {
      final initialBugs = _getFilteredBugs();
      if (initialBugs.isNotEmpty) {
        selectedBugId = initialBugs[0]['bug_id'];
        _wheelController = FixedExtentScrollController(initialItem: 0);
      }
    }

    _fetchSenderStats();
  }

  // --- FUNGSI: Filter Bug ---
  List<Map<String, dynamic>> _getFilteredBugs() {
    if (_selectedBugMode == "group") {
      return widget.listBug.where((b) => b['bug_id'].contains('_group')).toList();
    } else {
      return widget.listBug.where((b) => !b['bug_id'].contains('_group')).toList();
    }
  }

  // --- FUNGSI: Ambil Statistik Sender ---
  Future<void> _fetchSenderStats() async {
    try {
      final res = await http.get(Uri.parse(
          "http://raxzykasep.zyrovex.my.id:2000/getSenderStats?key=${widget.sessionKey}"));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          setState(() {
            _privateSenderCount = data['private'] ?? 0;
            _globalSenderCount = data['global'] ?? 0;
          });
        }
      }
    } catch (e) {
      debugPrint("Error fetching sender stats: $e");
    }
  }

  @override
  void dispose() {
    _videoController?.dispose();
    _pulseController.dispose();
    _rainbowController.dispose();
    _wheelController?.dispose();
    targetController.dispose();
    super.dispose();
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('') || cleaned.length < 8) return null;
    return cleaned;
  }

  bool isValidGroupLink(String input) {
    return input.contains('chat.whatsapp.com') && input.contains('https://');
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final key = widget.sessionKey;

    if (_selectedBugMode == "number") {
      final target = formatPhoneNumber(rawInput);
      if (target == null || key.isEmpty) {
        _showAlert("Invalid Number", "Gunakan nomor internasional (misal: +62, 1, 44), bukan 08xxx.");
        return;
      }
    } else {
      if (!isValidGroupLink(rawInput)) {
        _showAlert("Invalid Link", "Masukkan link group WA yang valid (contoh: https://chat.whatsapp.com/...).");
        return;
      }
    }

    final currentBugs = _getFilteredBugs();
    if (!currentBugs.any((b) => b['bug_id'] == selectedBugId)) {
      if (currentBugs.isNotEmpty) {
        setState(() {
          selectedBugId = currentBugs[0]['bug_id'];
        });
      } else {
        _showAlert("Error", "Tidak ada bug tersedia untuk mode ini.");
        return;
      }
    }

    setState(() {
      _isSending = true;
    });

    final effectiveSenderMode = (widget.role == 'owner' || widget.role == 'vip' || widget.role == 'moderator')
        ? _senderMode
        : 'private';

    try {
      final res = await http.get(Uri.parse(
          "http://raxzykasep.zyrovex.my.id:2000/sendBug?key=$key&target=$rawInput&bug=$selectedBugId&senderMode=$effectiveSenderMode"));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        _showAlert("⏳ Cooldown", "Tunggu beberapa saat sebelum mengirim lagi.");
      } else if (data["valid"] == false) {
        _showAlert("❌ Key Invalid", "Sesi Anda tidak valid. Silakan login ulang.");
      } else if (data["sended"] == false) {
        _showAlert("⚠️ Gagal", "Server sedang maintenance atau terjadi kegagalan.");
      } else {
        _showAlert("✅ Berhasil", "Bug sukses dikirim ke target!");
        targetController.clear();
        _fetchSenderStats();
      }
    } catch (_) {
      _showAlert("❌ Error", "Terjadi kesalahan pada sistem. Coba lagi nanti.");
    } finally {
      setState(() {
        _isSending = false;
      });
    }
  }

  void _showAlert(String title, String msg) {
    if (!mounted) return;
    CustomPopup.show(
      context,
      title: title,
      message: msg,
      icon: title.contains("✅") ? Icons.check_circle_outline : Icons.error_outline,
      iconColor: title.contains("✅") ? Colors.green : accentColor,
      confirmText: "Close",
    );
  }

  // --- RAINBOW SHADER ---
  Shader _rainbowShader(Rect bounds) {
    final shift = _rainbowController.value;
    return LinearGradient(
      begin: Alignment(-1.0 + shift * 2, -0.5),
      end: Alignment(1.0 + shift * 2, 0.5),
      colors: rainbowColors,
      stops: const [0.0, 0.16, 0.32, 0.5, 0.68, 0.84, 1.0],
    ).createShader(bounds);
  }

  // --- RAINBOW TEXT WIDGET ---
  Widget _rainbowText({
    required String text,
    required double fontSize,
    FontWeight fontWeight = FontWeight.w900,
    double letterSpacing = 1.0,
    TextAlign textAlign = TextAlign.start,
    int maxLines = 1,
  }) {
    return AnimatedBuilder(
      animation: _rainbowController,
      builder: (context, _) {
        return ShaderMask(
          shaderCallback: _rainbowShader,
          blendMode: BlendMode.srcIn,
          child: Text(
            text,
            textAlign: textAlign,
            maxLines: maxLines,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: Colors.white,
              fontWeight: fontWeight,
              fontSize: fontSize,
              fontFamily: 'Orbitron',
              letterSpacing: letterSpacing,
            ),
          ),
        );
      },
    );
  }

  Widget _buildTopHeader() {
    // [DIHAPUS] Widget Launchpad sudah dihapus dari UI
    return const SizedBox.shrink();
  }

  Widget _buildTopHeaderOld() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.black, width: 1.2),
        boxShadow: [
          const BoxShadow(color: Colors.black, blurRadius: 0, offset: Offset(3, 3)),
          BoxShadow(
            color: accentColor.withOpacity(0.06),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Icon(Icons.bug_report_outlined, color: accentColor, size: 30),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _rainbowText(
                  text: "WHISPER LOW",
                  fontSize: 14,
                  letterSpacing: 1.2,
                ),
                const SizedBox(height: 2),
                Text(
                  "Ready to send payload",
                  style: TextStyle(
                    color: textSub,
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAccountOverlay() {
    return Stack(
      fit: StackFit.expand,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: VideoPlayer(_videoController!),
        ),
        Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            gradient: LinearGradient(
              begin: Alignment.bottomLeft,
              end: Alignment.topRight,
              colors: [
                Colors.black.withOpacity(0.7),
                accentColor.withOpacity(0.15),
              ],
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _rainbowText(
                        text: widget.username.toUpperCase(),
                        fontSize: 14,
                        letterSpacing: 1,
                      ),
                      const SizedBox(height: 4),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: accentColor.withOpacity(0.25),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: accentColor.withOpacity(0.5), width: 0.8),
                        ),
                        child: Text(
                          widget.role.toUpperCase(),
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                            fontFamily: 'ShareTechMono',
                            letterSpacing: 0.5,
                          ),
                        ),
                      ),
                    ],
                  ),
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: accentColor.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: accentColor.withOpacity(0.4), width: 0.8),
                    ),
                    child: Icon(Icons.check_circle_outline, color: accentColor, size: 20),
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "SISA MASA BERLAKU",
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.8),
                          fontSize: 9,
                          fontFamily: 'Orbitron',
                          letterSpacing: 0.5,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        widget.expiredDate,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'ShareTechMono',
                        ),
                      ),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        "STATUS",
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.8),
                          fontSize: 9,
                          fontFamily: 'Orbitron',
                          letterSpacing: 0.5,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: Colors.green.withOpacity(0.3),
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: Colors.green.withOpacity(0.6), width: 0.8),
                        ),
                        child: const Text(
                          "ACTIVE",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                            fontFamily: 'ShareTechMono',
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  String _cleanBugName(String bugName) {
    return bugName
        .replaceAll(RegExp(r'^bug_|_group$'), '')
        .replaceAll('_', ' ')
        .toUpperCase();
  }

  Widget _buildSelectionButton({
    required String title,
    required String value,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return _PressableScale(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: bgCard,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: accentColor.withOpacity(0.3), width: 1.2),
          boxShadow: [
            BoxShadow(
              color: accentColor.withOpacity(0.08),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: accentColor.withOpacity(0.15),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: accentColor.withOpacity(0.3), width: 0.8),
              ),
              child: Icon(icon, color: accentColor, size: 18),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      color: textSub,
                      fontSize: 10,
                      fontFamily: 'Orbitron',
                      letterSpacing: 0.8,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    value,
                    style: TextStyle(
                      color: textMain,
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ),
            Icon(Icons.chevron_right, color: accentColor, size: 20),
          ],
        ),
      ),
    );
  }

  void _showTargetTypePopup() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: _rainbowText(
          text: "PILIH MODE TARGET",
          fontSize: 16,
          letterSpacing: 1.0,
        ),
        backgroundColor: bgCard,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: accentColor.withOpacity(0.3), width: 1.2),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildPopupOption(
              label: "BUG NOMOR",
              isSelected: _selectedBugMode == "number",
              onTap: () {
                setState(() {
                  _selectedBugMode = "number";
                  targetController.clear();
                  final newBugs = _getFilteredBugs();
                  if (newBugs.isNotEmpty) {
                    selectedBugId = newBugs[0]['bug_id'];
                  }
                });
                Navigator.pop(ctx);
                _wheelController?.animateToItem(
                  0,
                  duration: const Duration(milliseconds: 350),
                  curve: Curves.easeOutCubic,
                );
              },
            ),
            const SizedBox(height: 10),
            _buildPopupOption(
              label: "BUG GROUP",
              isSelected: _selectedBugMode == "group",
              onTap: () {
                setState(() {
                  _selectedBugMode = "group";
                  targetController.clear();
                  final newBugs = _getFilteredBugs();
                  if (newBugs.isNotEmpty) {
                    selectedBugId = newBugs[0]['bug_id'];
                  }
                });
                Navigator.pop(ctx);
                _wheelController?.animateToItem(
                  0,
                  duration: const Duration(milliseconds: 350),
                  curve: Curves.easeOutCubic,
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPopupOption({
    required String label,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: isSelected ? accentColor.withOpacity(0.15) : Colors.transparent,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: isSelected ? accentColor : Colors.white.withOpacity(0.2),
            width: isSelected ? 1.5 : 1,
          ),
        ),
        child: Row(
          children: [
            Text(
              label,
              style: TextStyle(
                color: isSelected ? accentColor : textMain,
                fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                fontSize: 13,
              ),
            ),
            const Spacer(),
            if (isSelected)
              Icon(Icons.check_circle, color: accentColor, size: 18),
          ],
        ),
      ),
    );
  }

  Widget _buildModernWheelPicker(List<Map<String, dynamic>> availableBugs) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // --- LABEL PAYLOAD ---
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 10),
          child: _rainbowText(
            text: "SELECT PAYLOAD",
            fontSize: 12,
            letterSpacing: 1.5,
          ),
        ),

        // --- WHEEL PICKER CONTAINER ---
        Container(
          height: 112,
          clipBehavior: Clip.antiAlias,
          decoration: BoxDecoration(
            color: bgCard,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: accentColor.withOpacity(0.3), width: 1.2),
            boxShadow: [
              BoxShadow(
                color: accentColor.withOpacity(0.08),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Stack(
            children: [
              ListWheelScrollView.useDelegate(
                controller: _wheelController,
                itemExtent: 32,
                diameterRatio: 6.0,
                perspective: 0.001,
                offAxisFraction: 0,
                physics: const BouncingScrollPhysics(),
                useMagnifier: false,
                magnification: 1.0,
                onSelectedItemChanged: (index) {
                  setState(() {
                    selectedBugId = availableBugs[index]['bug_id'];
                  });
                },
                childDelegate: ListWheelChildBuilderDelegate(
                  childCount: availableBugs.length,
                  builder: (context, index) {
                    final bug = availableBugs[index];
                    final isSelected = bug['bug_id'] == selectedBugId;

                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 0),
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          _cleanBugName(bug['bug_name'] ?? 'Unknown'),
                          textAlign: TextAlign.left,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: isSelected
                                ? accentColor
                                : Colors.white.withOpacity(0.3),
                            fontSize: isSelected ? 14 : 11,
                            fontWeight: isSelected ? FontWeight.w800 : FontWeight.w400,
                            fontFamily: 'ShareTechMono',
                            letterSpacing: 0.2,
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),

              // --- OVERLAY GRADASI HITAM DI BAGIAN BAWAH ---
              Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                height: 26,
                child: IgnorePointer(
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.black.withOpacity(0.0),
                          Colors.black.withOpacity(0.5),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 16),

        // --- SENDER MODE BUTTONS ---
        if (widget.role == 'owner' || widget.role == 'vip' || widget.role == 'moderator') ...[
          Padding(
            padding: const EdgeInsets.only(left: 4, bottom: 10),
            child: _rainbowText(
              text: "SENDER MODE",
              fontSize: 12,
              letterSpacing: 1.5,
            ),
          ),
          Row(
            children: [
              Expanded(
                child: _buildSenderModeButton(
                  label: "PRIVATE",
                  icon: Icons.person_outline,
                  count: _privateSenderCount,
                  isSelected: _senderMode == 'private',
                  onTap: () => setState(() => _senderMode = 'private'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildSenderModeButton(
                  label: "GLOBAL",
                  icon: Icons.public,
                  count: _globalSenderCount,
                  isSelected: _senderMode == 'global',
                  onTap: () => setState(() => _senderMode = 'global'),
                ),
              ),
            ],
          ),
        ],
      ],
    );
  }

  Widget _buildSenderModeButton({
    required String label,
    required IconData icon,
    required int count,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    return _PressableScale(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        curve: Curves.easeOut,
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
        decoration: BoxDecoration(
          color: isSelected ? accentColor.withOpacity(0.15) : bgCard,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected ? accentColor : Colors.white.withOpacity(0.2),
            width: isSelected ? 1.3 : 1.2,
          ),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: accentColor.withOpacity(0.15),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ]
              : [],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 220),
              child: Icon(
                icon,
                key: ValueKey(isSelected),
                color: isSelected ? accentColor : Colors.white54,
                size: 18,
              ),
            ),
            const SizedBox(height: 4),
            AnimatedDefaultTextStyle(
              duration: const Duration(milliseconds: 220),
              style: TextStyle(
                color: isSelected ? accentColor : textSub,
                fontSize: 10,
                fontWeight: isSelected ? FontWeight.w800 : FontWeight.w600,
                fontFamily: 'Orbitron',
                letterSpacing: 0.6,
              ),
              child: Text(label),
            ),
            const SizedBox(height: 2),
            AnimatedDefaultTextStyle(
              duration: const Duration(milliseconds: 220),
              style: TextStyle(
                color: isSelected ? accentColor : Colors.white38,
                fontSize: 11,
                fontWeight: FontWeight.w700,
                fontFamily: 'ShareTechMono',
              ),
              child: Text(count.toString()),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInputPanel() {
    final availableBugs = _getFilteredBugs();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _buildSelectionButton(
          title: "TARGET TYPE",
          value: _selectedBugMode == "number" ? "BUG NOMOR" : "BUG GROUP",
          icon: _selectedBugMode == "number" ? Icons.phone_android_rounded : Icons.group_add,
          onTap: _showTargetTypePopup,
        ),
        const SizedBox(height: 16),

        // LABEL INPUT TARGET — RAINBOW
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 8),
          child: _rainbowText(
            text: _selectedBugMode == "number" ? "TARGET NUMBER" : "WHATSAPP GROUP LINK",
            fontSize: 12,
            letterSpacing: 1.5,
          ),
        ),

        // TEXTFIELD TARGET
        TextField(
          controller: targetController,
          style: const TextStyle(color: Colors.white, fontSize: 16),
          cursorColor: accentColor,
          keyboardType: _selectedBugMode == "number" ? TextInputType.phone : TextInputType.url,
          decoration: InputDecoration(
            hintText: _selectedBugMode == "number"
                ? "e.g. +628xxxxxxxx"
                : "e.g. https://chat.whatsapp.com/...",
            hintStyle: TextStyle(color: textSub.withOpacity(0.5)),
            filled: true,
            fillColor: bgSurface,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: accentColor.withOpacity(0.3), width: 1.2),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: accentColor.withOpacity(0.3), width: 1.2),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: accentColor, width: 1.5),
            ),
            prefixIcon: Icon(
              _selectedBugMode == "number" ? Icons.phone_android_rounded : Icons.link,
              color: accentColor.withOpacity(0.7),
            ),
            contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 18),
          ),
        ),

        const SizedBox(height: 20),

        // --- MODERN WHEEL PICKER ---
        _buildModernWheelPicker(availableBugs),
      ],
    );
  }

  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (context, child) {
        return _PressableScale(
          child: Container(
            height: 56,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: accentColor, width: 1.3),
              color: accentColor.withOpacity(0.12),
              boxShadow: [
                BoxShadow(
                  color: accentColor.withOpacity(0.3 * _pulseController.value),
                  blurRadius: 18,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: ElevatedButton(
              onPressed: _isSending ? null : _sendBug,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
                elevation: 0,
                shadowColor: Colors.transparent,
              ),
              child: _isSending
                  ? SizedBox(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(
                        color: accentColor,
                        strokeWidth: 2,
                      ),
                    )
                  : Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.rocket_launch_outlined, color: accentColor, size: 18),
                        const SizedBox(width: 10),
                        AnimatedBuilder(
                          animation: _rainbowController,
                          builder: (context, _) => ShaderMask(
                            shaderCallback: _rainbowShader,
                            blendMode: BlendMode.srcIn,
                            child: const Text(
                              "LAUNCH ATTACK",
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w900,
                                fontSize: 14,
                                letterSpacing: 1.8,
                                fontFamily: 'Orbitron',
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgMain,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Video dengan account info overlay
              if (_videoController != null && _videoController!.value.isInitialized)
                Container(
                  height: 200,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: accentColor.withOpacity(0.5), width: 1.2),
                    boxShadow: [
                      BoxShadow(
                        color: accentColor.withOpacity(0.2),
                        blurRadius: 16,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(14),
                    child: _buildAccountOverlay(),
                  ),
                ),
              const SizedBox(height: 18),

              _buildInputPanel(),
              const SizedBox(height: 24),

              _buildSendButton(),
              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }
}

// --- Aksen animasi: efek scale halus saat tombol ditekan ---
class _PressableScale extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;

  const _PressableScale({required this.child, this.onTap});

  @override
  State<_PressableScale> createState() => _PressableScaleState();
}

class _PressableScaleState extends State<_PressableScale> {
  double _scale = 1.0;

  void _setPressed(bool pressed) {
    if (!mounted) return;
    setState(() => _scale = pressed ? 0.96 : 1.0);
  }

  @override
  Widget build(BuildContext context) {
    return Listener(
      onPointerDown: (_) => _setPressed(true),
      onPointerUp: (_) => _setPressed(false),
      onPointerCancel: (_) => _setPressed(false),
      child: GestureDetector(
        onTap: widget.onTap,
        behavior: HitTestBehavior.opaque,
        child: AnimatedScale(
          scale: _scale,
          duration: const Duration(milliseconds: 120),
          curve: Curves.easeOut,
          child: widget.child,
        ),
      ),
    );
  }
}