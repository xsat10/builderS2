plugins {
    id("com.android.application")
    id("kotlin-android")
    // The Flutter Gradle Plugin must be applied after the Android and Kotlin Gradle plugins.
    id("dev.flutter.flutter-gradle-plugin")
}

// ── Patch awesome_notifications 0.10.0 DartBackgroundExecutor.java ──────────
// This file references PluginRegistrantCallback which was removed in Flutter v2 embedding.
// We patch it before compilation to remove the broken reference.
fun patchDartBackgroundExecutor() {
    val pubHome = System.getProperty("user.home") + "/.pub-cache/hosted/pub.dev"
    val targetPath = "$pubHome/awesome_notifications-0.10.0/android/src/main/java/me/carda/awesome_notifications/DartBackgroundExecutor.java"
    val targetFile = file(targetPath)

    if (!targetFile.exists()) {
        println("[PATCH] DartBackgroundExecutor.java not found at: $targetPath")
        return
    }

    val original = targetFile.readText()
    if (!original.contains("PluginRegistrantCallback")) {
        println("[PATCH] Already patched or clean — skipping")
        return
    }

    // Replace the field declaration
    var patched = original.replace(
        Regex("private static io\\.flutter\\.plugin\\.common\\.PluginRegistry\\.PluginRegistrantCallback\\s+\\w+;"),
        "// PATCHED(Flutter-v2): PluginRegistrantCallback removed"
    )
    // Replace method that accepts callback
    patched = patched.replace(
        Regex("public static void setPluginRegistrant\\(\\s*io\\.flutter\\.plugin\\.common\\.PluginRegistry\\.PluginRegistrantCallback\\s+callback\\s*\\)\\s*\\{[^}]*\\}"),
        "// PATCHED(Flutter-v2): setPluginRegistrant removed"
    )
    // Remove any invocation
    patched = patched.replace("sPluginRegistrantCallback.registerWith(registry);", "// PATCHED: no-op")
    patched = patched.replace("sPluginRegistrantCallback = callback;", "// PATCHED: no-op")

    targetFile.writeText(patched)
    println("[PATCH] DartBackgroundExecutor.java patched successfully!")
}

// Run patch EAGERLY at configuration time (before tasks are created)
patchDartBackgroundExecutor()

android {
    namespace = "com.nullx.cyber"
    compileSdk = 36
    ndkVersion = "27.0.12077973"

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    defaultConfig {
        applicationId = "com.nullx.cyber"
        // Bumped to 23: required by geolocator, geocoding, permission_handler
        minSdk = 23
        targetSdk = 36
        versionCode = flutter.versionCode
        versionName = flutter.versionName

        // Required for awesome_notifications background dispatch
        multiDexEnabled = true
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("debug")
            isMinifyEnabled = false
            isShrinkResources = false
        }
    }
}

flutter {
    source = "../.."
}

dependencies {
    implementation("androidx.multidex:multidex:2.0.1")
}
