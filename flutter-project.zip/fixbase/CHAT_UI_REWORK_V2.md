# DARK LIGHT Chat UI Rework V2

## Added
- Global chat: long-press own text message -> Edit / Delete.
- Private chat: long-press own text message -> Edit / Delete.
- Media messages can be deleted (text can be edited; media is not editable).
- Profile editor for reseller and higher roles: display name, about, avatar.
- Profile role restriction is enforced by API, not only UI.
- Private user list/header can display profile avatar.
- Global messages can carry display name/avatar metadata.

## Preserved
- Global/private text chat.
- Global/private photo, video, audio/VN and file sending.
- Private voice call and video call signaling/pages were not modified.
