import 'package:otax/core/data/settings.dart';
import 'package:otax/core/data/preferences.dart';
import 'package:otax/ui/theme/types.dart';
import 'package:flutter/material.dart';

UserSettings? currentUserSettings;
UserPreferencesData? userPreferences;

AnimeStreamTheme appTheme = AnimeStreamTheme(
  accentColor: const Color(0xFF84CC16),
  textMainColor: const Color(0xFFE8F5D0),
  textSubColor: const Color(0xFF9CB56A),
  backgroundColor: const Color(0xFF0D1306),
  backgroundSubColor: const Color(0xFF1A2B0D),
  modalSheetBackgroundColor: const Color(0xFF141F09),
  onAccent: const Color(0xFF0D1306),
);
