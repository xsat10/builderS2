import 'package:shared_preferences/shared_preferences.dart';

Future<int> getTheme() async {
  final prefs = await SharedPreferences.getInstance();
  return prefs.getInt('themeId') ?? 1;
}

Future<void> setTheme(int id) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.setInt('themeId', id);
}

void showToast(String message) {
  // no-op stub
}
