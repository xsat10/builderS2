import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:image_picker/image_picker.dart';
import 'package:record/record.dart';
import 'package:path_provider/path_provider.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:http/http.dart' as http;
import 'main.dart';
import 'api_config.dart';


class GlobalChatPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const GlobalChatPage({
    super.key,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<GlobalChatPage> createState() => _GlobalChatPageState();
}

class _GlobalChatPageState extends State<GlobalChatPage> {
  final TextEditingController msgCtrl = TextEditingController();
  final ScrollController scrollCtrl = ScrollController();
  final FocusNode focusNode = FocusNode();
  final ImagePicker imagePicker = ImagePicker();
  final AudioRecorder voiceRecorder = AudioRecorder();
  final AudioPlayer audioPlayer = AudioPlayer();
  bool isRecordingVoice = false;
  String? playingAudioUrl;
  VideoPlayerController? _videoController;
  String? _playingVideoUrl;

  List<Map<String, dynamic>> chats = [];
  bool loading = true;
  bool isSending = false;
  bool showSendButton = false;
  bool showScrollButton = false;
  String? errorMessage;
  String _profileRole = 'member';
  String _profileDisplayName = '';
  String _profileAbout = '';
  String _profileAvatarUrl = '';
  Map<String, dynamic>? _replyingTo;
  final GlobalKey<RefreshIndicatorState> refreshKey = GlobalKey<RefreshIndicatorState>();
  Timer? _pollTimer;

  final Color primaryColor = const Color(0xFF19E6C1);
  final Color secondaryColor = const Color(0xFF101826);
  final Color backgroundColor = const Color(0xFF05080F);
  final Color bubbleOutgoing = const Color(0xFF0B4D46);
  final Color bubbleIncoming = const Color(0xFF111A27);
  final Color accentColor = const Color(0xFF00A884);
  final Color textColor = Colors.white;
  final Color subtitleColor = Colors.grey[400]!;

  @override
  void initState() {
    super.initState();
    _loadProfile();
    _loadChats();
    _pollTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (mounted && !loading) _loadChats(showLoader: false);
    });
    focusNode.addListener(_onFocusChange);
    scrollCtrl.addListener(_scrollListener);
  }

  @override
  void dispose() {
    focusNode.removeListener(_onFocusChange);
    scrollCtrl.removeListener(_scrollListener);
    _pollTimer?.cancel();
    msgCtrl.dispose();
    scrollCtrl.dispose();
    focusNode.dispose();
    voiceRecorder.dispose();
    audioPlayer.dispose();
    _videoController?.dispose();
    super.dispose();
  }

  void _scrollListener() {
    final offset = scrollCtrl.offset;
    final maxScroll = scrollCtrl.position.maxScrollExtent;
    
    if (maxScroll - offset > 300 && !showScrollButton) {
      setState(() => showScrollButton = true);
    } else if (maxScroll - offset <= 300 && showScrollButton) {
      setState(() => showScrollButton = false);
    }
  }

  void _onFocusChange() {
    if (focusNode.hasFocus) {
      Future.delayed(const Duration(milliseconds: 300), _scrollToBottom);
    }
  }

  int _messageTimestamp(dynamic value) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    if (value is String) {
      final parsed = DateTime.tryParse(value);
      if (parsed != null) return parsed.toLocal().millisecondsSinceEpoch;
      return int.tryParse(value) ?? DateTime.now().millisecondsSinceEpoch;
    }
    return DateTime.now().millisecondsSinceEpoch;
  }

  List<Map<String, dynamic>> _normalizeMessages(dynamic body) {
    dynamic data = body;
    if (body is Map<String, dynamic>) {
      data = body['messages'] ?? body['data'] ?? body['chats'] ?? [];
    }
    if (data is! List) return [];
    return data
        .whereType<Map>()
        .map((raw) {
          final item = Map<String, dynamic>.from(raw);
          item['from'] = (item['from'] ?? 'Unknown').toString();
          item['message'] = (item['message'] ?? '').toString();
          item['time'] = _messageTimestamp(item['time'] ?? item['created_at']);
          item['status'] = item['status'] ?? 'terkirim';
          return item;
        })
        .where((item) => item['message'].toString().isNotEmpty)
        .toList();
  }

  bool get _canEditProfile => true;

  Future<void> _loadProfile() async {
    try {
      final r = await http.get(
        Uri.parse('$baseUrl/api/chat/profile').replace(queryParameters: {'session_key': widget.sessionKey}),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
      ).timeout(const Duration(seconds: 12));
      
      if (r.statusCode == 401) {
        if (!mounted) return;
        setState(() => errorMessage = 'Session expired. Login again.');
        return;
      }
      if (r.statusCode != 200) return;
      
      final b = jsonDecode(r.body);
      final p = b is Map && b['profile'] is Map ? Map<String,dynamic>.from(b['profile']) : <String,dynamic>{};
      if (!mounted) return;
      setState(() {
        _profileRole = (p['role'] ?? 'member').toString();
        _profileDisplayName = (p['display_name'] ?? widget.username).toString();
        _profileAbout = (p['about'] ?? '').toString();
        _profileAvatarUrl = (p['avatar_url'] ?? '').toString();
      });
    } catch (_) {}
  }

  String _accountDate(dynamic value, {bool dateOnly = false}) {
    final raw = (value ?? '').toString().trim();
    if (raw.isEmpty) return 'Tidak tersedia';
    final dt = DateTime.tryParse(raw);
    if (dt == null) return raw;
    final local = dt.toLocal();
    String two(int n) => n.toString().padLeft(2, '0');
    final d = '${two(local.day)}/${two(local.month)}/${local.year}';
    if (dateOnly) return d;
    return '$d • ${two(local.hour)}:${two(local.minute)}';
  }

  Widget _profileInfoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(width: 38, height: 38, decoration: BoxDecoration(color: const Color(0xFF202C33), borderRadius: BorderRadius.circular(12)), child: Icon(icon, color: const Color(0xFF00A884), size: 19)),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: const TextStyle(color: Colors.white54, fontSize: 11)),
          const SizedBox(height: 3),
          Text(value, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600)),
        ])),
      ]),
    );
  }

  Future<void> _showUserProfile(String username) async {
    if (username.trim().isEmpty) return;
    try {
      final r = await http.get(Uri.parse('$baseUrl/api/chat/profile/user').replace(
        queryParameters: {'session_key': widget.sessionKey, 'username': username},
      )).timeout(const Duration(seconds: 10));
      if (r.statusCode != 200) { if (mounted) setState(() => errorMessage = 'Profil pengguna tidak tersedia'); return; }
      final b = jsonDecode(r.body);
      final p = b is Map && b['profile'] is Map ? Map<String,dynamic>.from(b['profile']) : <String,dynamic>{};
      if (!mounted) return;
      final display = (p['display_name'] ?? username).toString();
      final about = (p['about'] ?? '').toString();
      final role = (p['role'] ?? 'member').toString();
      final avatar = (p['avatar_url'] ?? '').toString();
      final created = _accountDate(p['created_at']);
      final expiryRaw = (p['expired_date'] ?? '').toString();
      final expiry = expiryRaw.isEmpty || expiryRaw.toLowerCase() == 'permanent' ? 'PERMANEN' : _accountDate(expiryRaw, dateOnly: true);
      final expired = DateTime.tryParse(expiryRaw)?.isBefore(DateTime.now()) ?? false;
      showModalBottomSheet<void>(
        context: context, isScrollControlled: true, backgroundColor: const Color(0xFF111B21),
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(30))),
        builder: (ctx) => SafeArea(child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 10, 20, 28),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(width: 42, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(8))),
            const SizedBox(height: 20),
            _buildAvatar(username, avatarUrl: avatar, isOnline: false),
            const SizedBox(height: 12),
            Text(display, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.w900)),
            const SizedBox(height: 3),
            Text('@$username', style: const TextStyle(color: Colors.white54, fontSize: 13)),
            const SizedBox(height: 18),
            Container(width: double.infinity, padding: const EdgeInsets.fromLTRB(16, 5, 16, 5), decoration: BoxDecoration(color: const Color(0xFF182229), borderRadius: BorderRadius.circular(18)), child: Column(children: [
              _profileInfoRow(Icons.info_outline_rounded, 'Tentang', about.isEmpty ? 'Belum ada bio.' : about),
              const Divider(color: Colors.white10, height: 1),
              _profileInfoRow(Icons.calendar_today_rounded, 'Akun dibuat', created),
              const Divider(color: Colors.white10, height: 1),
              _profileInfoRow(expired ? Icons.warning_amber_rounded : Icons.event_available_rounded, 'Akun berakhir', expiry),
            ])),
            const SizedBox(height: 12),
            Row(children: [
              const Icon(Icons.verified_user_outlined, color: Color(0xFF00A884), size: 16),
              const SizedBox(width: 7),
              Text('Role: ${role.toUpperCase()}  •  Password disembunyikan', style: const TextStyle(color: Colors.white38, fontSize: 11)),
            ]),
          ]),
        )),
      );
    } catch (_) { if (mounted) setState(() => errorMessage = 'Gagal memuat profil pengguna'); }
  }

  Future<void> _showProfileEditor() async {
    if (!_canEditProfile) {
      if (mounted) setState(() => errorMessage = 'Profil dapat diubah dari semua akun');
      return;
    }
    final nameCtrl = TextEditingController(text: _profileDisplayName.isEmpty ? widget.username : _profileDisplayName);
    final aboutCtrl = TextEditingController(text: _profileAbout);
    XFile? picked;
    try {
      await showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        backgroundColor: const Color(0xFF111B21),
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
        builder: (sheet) => StatefulBuilder(builder: (ctx, setSheet) => Padding(
          padding: EdgeInsets.fromLTRB(20, 14, 20, MediaQuery.of(ctx).viewInsets.bottom + 24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(width: 42, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(8))),
            const SizedBox(height: 18),
            const Align(alignment: Alignment.centerLeft, child: Text('Edit Profil', style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w900))),
            const SizedBox(height: 16),
            GestureDetector(
              onTap: () async {
                final x = await imagePicker.pickImage(source: ImageSource.gallery, imageQuality: 88);
                if (x != null) setSheet(() => picked = x);
              },
              child: Stack(alignment: Alignment.bottomRight, children: [
                CircleAvatar(radius: 48, backgroundImage: picked != null ? FileImage(File(picked!.path)) : (_profileAvatarUrl.isNotEmpty ? NetworkImage(_profileAvatarUrl) : null) as ImageProvider?, child: (picked == null && _profileAvatarUrl.isEmpty) ? Text(widget.username.isEmpty ? '?' : widget.username[0].toUpperCase(), style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w800)) : null),
                Container(width: 34, height: 34, decoration: const BoxDecoration(color: Color(0xFF00A884), shape: BoxShape.circle), child: const Icon(Icons.camera_alt_rounded, color: Colors.white, size: 18)),
              ]),
            ),
            const SizedBox(height: 16),
            TextField(controller: nameCtrl, style: const TextStyle(color: Colors.white), decoration: _profileDecoration('Nama tampilan', Icons.person_outline_rounded)),
            const SizedBox(height: 10),
            TextField(controller: aboutCtrl, maxLength: 120, style: const TextStyle(color: Colors.white), decoration: _profileDecoration('Tentang', Icons.info_outline_rounded)),
            const SizedBox(height: 6),
            SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: () async {
              final nav = Navigator.of(ctx);
              try {
                final req = http.MultipartRequest('POST', Uri.parse('$baseUrl/api/chat/profile'));
                req.fields.addAll({'session_key': widget.sessionKey, 'display_name': nameCtrl.text.trim(), 'about': aboutCtrl.text.trim()});
                if (picked != null) req.files.add(await http.MultipartFile.fromPath('avatar', picked!.path, filename: picked!.name));
                final r = await req.send().timeout(const Duration(seconds: 60));
                if (r.statusCode >= 200 && r.statusCode < 300) { await _loadProfile(); if (mounted) nav.pop(); }
                else if (mounted) setState(() => errorMessage = 'Profil gagal disimpan');
              } catch (_) { if (mounted) setState(() => errorMessage = 'Profil gagal disimpan'); }
            }, icon: const Icon(Icons.save_rounded), label: const Text('Simpan Profil'))),
          ]),
        )),
      );
    } finally { nameCtrl.dispose(); aboutCtrl.dispose(); }
  }

  InputDecoration _profileDecoration(String hint, IconData icon) => InputDecoration(prefixIcon: Icon(icon, color: Colors.white54), hintText: hint, hintStyle: const TextStyle(color: Colors.white38), filled: true, fillColor: const Color(0xFF202C33), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none));


  Future<void> _loadChats({bool showLoader = true}) async {
    if (showLoader && mounted) {
      setState(() {
        loading = true;
        errorMessage = null;
      });
    }

    try {
      final uri = Uri.parse('$baseUrl/api/chat/messages').replace(
        queryParameters: {'session_key': widget.sessionKey},
      );
      final res = await http.get(
        uri,
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
      ).timeout(const Duration(seconds: 12));

      if (res.statusCode == 200) {
        final body = jsonDecode(res.body);
        final data = _normalizeMessages(body);
        if (!mounted) return;
        setState(() {
          chats = data;
          loading = false;
          errorMessage = null;
        });
        WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());
      } else if (res.statusCode == 401) {
        if (!mounted) return;
        setState(() {
          errorMessage = 'Session expired. Login again.';
          loading = false;
        });
      } else {
        String message = 'Gagal memuat chat (HTTP ${res.statusCode})';
        try {
          final body = jsonDecode(res.body);
          if (body is Map && body['message'] != null) {
            message = body['message'].toString();
          }
        } catch (_) {}
        if (!mounted) return;
        setState(() {
          loading = false;
          errorMessage = message;
        });
      }
    } catch (e) {
      debugPrint('Error memuat chat global: $e');
      if (!mounted) return;
      setState(() {
        loading = false;
        errorMessage = 'Tidak dapat terhubung ke server chat';
      });
    }
  }

  Future<void> _refreshChats() async {
    await _loadChats(showLoader: false);
  }

  Future<void> _editGlobalMessage(Map<String,dynamic> item) async {
    if (item['from']?.toString() != widget.username || (item['media_type'] ?? 'text') != 'text') return;
    final c=TextEditingController(text:(item['message']??'').toString());
    final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(backgroundColor:const Color(0xFF202C33),title:const Text('Edit pesan',style:TextStyle(color:Colors.white)),content:TextField(controller:c,autofocus:true,maxLines:4,style:const TextStyle(color:Colors.white),decoration:_profileDecoration('Pesan',Icons.edit_rounded)),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Batal')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Simpan'))]));
    if(ok!=true || c.text.trim().isEmpty) { c.dispose(); return; }
    try { final r=await http.post(Uri.parse('$baseUrl/api/chat/edit'),headers:{'Content-Type':'application/json'},body:jsonEncode({'session_key':widget.sessionKey,'id':item['id'],'message':c.text.trim()})).timeout(const Duration(seconds:15)); if(r.statusCode<300) await _loadChats(showLoader:false); else if(mounted)setState(()=>errorMessage='Pesan gagal diedit'); } catch(_){if(mounted)setState(()=>errorMessage='Pesan gagal diedit');} finally{c.dispose();}
  }
  Future<void> _deleteGlobalMessage(Map<String,dynamic> item) async {
    final yes=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(backgroundColor:const Color(0xFF202C33),title:const Text('Hapus pesan?',style:TextStyle(color:Colors.white)),content:const Text('Pesan akan dihapus dari chat.',style:TextStyle(color:Colors.white70)),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Batal')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Hapus'))]));
    if(yes!=true || item['id']==null)return;
    try{final r=await http.post(Uri.parse('$baseUrl/api/chat/delete'),headers:{'Content-Type':'application/json'},body:jsonEncode({'session_key':widget.sessionKey,'id':item['id']})).timeout(const Duration(seconds:15));if(r.statusCode<300)await _loadChats(showLoader:false);else if(mounted)setState(()=>errorMessage='Pesan gagal dihapus');}catch(_){if(mounted)setState(()=>errorMessage='Pesan gagal dihapus');}
  }
  Future<void> _copyGlobalMessage(Map<String,dynamic> item) async { final text=(item['message']??item['file_name']??'').toString(); if(text.isEmpty)return; await Clipboard.setData(ClipboardData(text:text)); if(mounted)setState(()=>errorMessage='Pesan disalin'); }
  Future<void> _reactGlobal(Map<String,dynamic> item,String emoji) async { try{final r=await http.post(Uri.parse('$baseUrl/api/chat/reaction'),headers:{'Content-Type':'application/json'},body:jsonEncode({'session_key':widget.sessionKey,'id':item['id'],'reaction':emoji})).timeout(const Duration(seconds:10));if(r.statusCode<300)await _loadChats(showLoader:false);else if(mounted)setState(()=>errorMessage='Reaction gagal');}catch(_){if(mounted)setState(()=>errorMessage='Reaction gagal');} }
  Future<void> _forwardGlobal(Map<String,dynamic> item) async { try{final r=await http.post(Uri.parse('$baseUrl/api/chat/forward'),headers:{'Content-Type':'application/json'},body:jsonEncode({'session_key':widget.sessionKey,'id':item['id']})).timeout(const Duration(seconds:15));if(r.statusCode<300){if(mounted)setState(()=>errorMessage='Pesan diteruskan ke chat global');}else if(mounted)setState(()=>errorMessage='Gagal meneruskan pesan');}catch(_){if(mounted)setState(()=>errorMessage='Gagal meneruskan pesan');} }
  void _startGlobalReply(Map<String,dynamic> item){setState(()=>_replyingTo=item);focusNode.requestFocus();}

  void _showGlobalMessageActions(Map<String,dynamic> item) {
    final mine = item['from']?.toString() == widget.username;
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF111B21),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        final reactions = <String>['❤️', '😂', '👍', '😮', '😢', '🔥'];
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: reactions.map<Widget>((e) {
                    return IconButton(
                      onPressed: () {
                        Navigator.pop(ctx);
                        _reactGlobal(item, e);
                      },
                      icon: Text(e, style: const TextStyle(fontSize: 25)),
                    );
                  }).toList(),
                ),
              ),
              ListTile(
                leading: const Icon(Icons.reply_rounded, color: Colors.white),
                title: const Text('Balas', style: TextStyle(color: Colors.white)),
                onTap: () { Navigator.pop(ctx); _startGlobalReply(item); },
              ),
              ListTile(
                leading: const Icon(Icons.copy_rounded, color: Colors.white),
                title: const Text('Salin', style: TextStyle(color: Colors.white)),
                onTap: () { Navigator.pop(ctx); _copyGlobalMessage(item); },
              ),
              ListTile(
                leading: const Icon(Icons.forward_rounded, color: Colors.white),
                title: const Text('Teruskan', style: TextStyle(color: Colors.white)),
                onTap: () { Navigator.pop(ctx); _forwardGlobal(item); },
              ),
              if (mine && (item['media_type'] ?? 'text') == 'text')
                ListTile(
                  leading: const Icon(Icons.edit_rounded, color: Colors.white),
                  title: const Text('Edit pesan', style: TextStyle(color: Colors.white)),
                  onTap: () { Navigator.pop(ctx); _editGlobalMessage(item); },
                ),
              if (mine)
                ListTile(
                  leading: const Icon(Icons.delete_outline_rounded, color: Colors.redAccent),
                  title: const Text('Hapus pesan', style: TextStyle(color: Colors.redAccent)),
                  onTap: () { Navigator.pop(ctx); _deleteGlobalMessage(item); },
                ),
              const SizedBox(height: 8),
            ],
          ),
        );
      },
    );
  }

  Future<void> _sendMessage() async {
    final msg = msgCtrl.text.trim();
    if (msg.isEmpty || isSending) return;

    final optimistic = <String, dynamic>{
      'from': widget.username,
      'message': msg,
      'time': DateTime.now().millisecondsSinceEpoch,
      'status': 'mengirim',
    };

    setState(() {
      isSending = true;
      showSendButton = false;
      chats.add(optimistic);
    });
    msgCtrl.clear();
    if (mounted) setState(() => _replyingTo = null);
    _scrollToBottom();

    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api/chat/send'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'session_key': widget.sessionKey,
          'username': widget.username,
          'message': msg,
          if (_replyingTo != null) 'reply_to': _replyingTo!['id'],
        }),
      ).timeout(const Duration(seconds: 10));

      if (!mounted) return;
      final index = chats.indexOf(optimistic);
      if (response.statusCode >= 200 && response.statusCode < 300) {
        Map<String, dynamic>? serverMessage;
        try {
          final body = jsonDecode(response.body);
          if (body is Map && body['message'] is Map) {
            serverMessage = Map<String, dynamic>.from(body['message']);
            serverMessage['time'] = _messageTimestamp(
              serverMessage['time'] ?? serverMessage['created_at'],
            );
            serverMessage['status'] = 'terkirim';
          }
        } catch (_) {}

        setState(() {
          if (index >= 0 && index < chats.length) {
            chats[index] = serverMessage ?? {...optimistic, 'status': 'terkirim'};
          }
          errorMessage = null;
        });
      } else {
        String message = 'Pesan gagal dikirim';
        try {
          final body = jsonDecode(response.body);
          if (body is Map && body['message'] != null) message = body['message'].toString();
        } catch (_) {}
        setState(() {
          if (index >= 0 && index < chats.length) chats[index]['status'] = 'gagal';
          errorMessage = message;
        });
      }
    } catch (e) {
      debugPrint('Error mengirim chat global: $e');
      if (!mounted) return;
      final index = chats.indexOf(optimistic);
      setState(() {
        if (index >= 0 && index < chats.length) chats[index]['status'] = 'gagal';
        errorMessage = 'Tidak dapat terhubung ke server chat';
      });
    } finally {
      if (mounted) setState(() => isSending = false);
    }
  }

  Future<void> _sendMedia(String path, String type, String name) async {
    if (isSending) return;
    setState(() => isSending = true);
    try {
      final req = http.MultipartRequest('POST', Uri.parse('$baseUrl/api/chat/upload'));
      req.fields.addAll({
        'session_key': widget.sessionKey,
        'username': widget.username,
        'media_type': type,
      });
      req.files.add(await http.MultipartFile.fromPath('media', path, filename: name));
      final res = await req.send().timeout(const Duration(seconds: 120));
      final body = await res.stream.bytesToString();
      if (res.statusCode >= 200 && res.statusCode < 300) {
        await _loadChats(showLoader: false);
      } else {
        String msg = 'Media gagal dikirim (HTTP ${res.statusCode})';
        try {
          final b = jsonDecode(body);
          if (b is Map && b['message'] != null) msg = b['message'].toString();
        } catch (_) {}
        if (mounted) setState(() => errorMessage = msg);
      }
    } catch (e) {
      if (mounted) setState(() => errorMessage = 'Gagal upload media: $e');
    } finally {
      if (mounted) setState(() => isSending = false);
    }
  }

  Future<void> _pickPhoto() async {
    try {
      final x = await imagePicker.pickImage(source: ImageSource.gallery, imageQuality: 88);
      if (x != null) await _sendMedia(x.path, 'image', x.name);
    } catch (e) {
      if (mounted) setState(() => errorMessage = 'Foto gagal dipilih: $e');
    }
  }

  Future<void> _pickVideo() async {
    try {
      final x = await imagePicker.pickVideo(source: ImageSource.gallery);
      if (x != null) await _sendMedia(x.path, 'video', x.name);
    } catch (e) {
      if (mounted) setState(() => errorMessage = 'Video gagal dipilih: $e');
    }
  }

  Future<void> _pickFile() async {
    try {
      final result = await FilePicker.platform.pickFiles(withData: false);
      final file = result?.files.single;
      if (file?.path != null) await _sendMedia(file!.path!, 'file', file.name);
    } catch (e) {
      if (mounted) setState(() => errorMessage = 'File gagal dipilih: $e');
    }
  }

  Future<void> _toggleVoice() async {
    if (isSending) return;
    try {
      if (isRecordingVoice) {
        final path = await voiceRecorder.stop();
        if (mounted) setState(() => isRecordingVoice = false);
        if (path != null && path.isNotEmpty) {
          await _sendMedia(path, 'audio', 'VN-${DateTime.now().millisecondsSinceEpoch}.wav');
        }
        return;
      }
      if (!await voiceRecorder.hasPermission()) {
        if (mounted) setState(() => errorMessage = 'Izin mikrofon ditolak');
        return;
      }
      final dir = await getTemporaryDirectory();
      final path = '${dir.path}/vn-${DateTime.now().millisecondsSinceEpoch}.m4a';
      await voiceRecorder.start(
        const RecordConfig(encoder: AudioEncoder.wav, sampleRate: 44100, numChannels: 1),
        path: path,
      );
      if (mounted) setState(() => isRecordingVoice = true);
    } catch (e) {
      if (mounted) {
        setState(() => isRecordingVoice = false);
        setState(() => errorMessage = 'Perekaman VN gagal: $e');
      }
    }
  }

  Future<void> _playAudio(String url) async {
    try {
      if (playingAudioUrl == url) {
        await audioPlayer.stop();
        if (mounted) setState(() => playingAudioUrl = null);
      } else {
        await audioPlayer.play(UrlSource(url), volume: 1.0);
        if (mounted) setState(() => playingAudioUrl = url);
      }
    } catch (e) {
      if (mounted) setState(() => errorMessage = 'VN tidak bisa diputar: $e');
    }
  }

  void _showAttachments() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: secondaryColor,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (sheet) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 12, 18, 24),
          child: Wrap(
            alignment: WrapAlignment.center,
            spacing: 12,
            runSpacing: 12,
            children: [
              _mediaAction(sheet, Icons.photo_rounded, 'Foto', _pickPhoto),
              _mediaAction(sheet, Icons.videocam_rounded, 'Video', _pickVideo),
              _mediaAction(sheet, Icons.insert_drive_file_rounded, 'File', _pickFile),
              _mediaAction(sheet, Icons.mic_rounded, 'VN', _toggleVoice),
            ],
          ),
        ),
      ),
    );
  }

  Widget _mediaAction(BuildContext sheet, IconData icon, String label, Future<void> Function() action) {
    return InkWell(
      onTap: () { Navigator.pop(sheet); action(); },
      borderRadius: BorderRadius.circular(18),
      child: SizedBox(
        width: 76,
        child: Column(
          children: [
            Container(width: 54, height: 54, decoration: BoxDecoration(color: primaryColor.withOpacity(.18), shape: BoxShape.circle), child: Icon(icon, color: Colors.white)),
            const SizedBox(height: 6),
            Text(label, style: const TextStyle(color: Colors.white70, fontSize: 12)),
          ],
        ),
      ),
    );
  }

  void _scrollToBottom() {
    if (scrollCtrl.hasClients) {
      scrollCtrl.animateTo(
        scrollCtrl.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  String _formatTime(dynamic timestamp) {
    final date = DateTime.fromMillisecondsSinceEpoch(_messageTimestamp(timestamp)).toLocal();
    return '${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
  }

  String _formatDate(dynamic timestamp) {
    final date = DateTime.fromMillisecondsSinceEpoch(_messageTimestamp(timestamp)).toLocal();
    final today = DateTime.now();
    
    if (date.year == today.year && date.month == today.month && date.day == today.day) {
      return "Hari Ini";
    } else if (date.year == today.year && date.month == today.month && date.day == today.day - 1) {
      return "Kemarin";
    } else {
      return "${date.day}/${date.month}/${date.year}";
    }
  }

  Widget _buildMessageStatus(String status) {
    switch (status) {
      case "mengirim":
        return SizedBox(
          width: 14,
          height: 14,
          child: CircularProgressIndicator(
            strokeWidth: 2,
            valueColor: AlwaysStoppedAnimation(Colors.grey[400]!),
          ),
        );
      case "terkirim":
        return Icon(Icons.check, size: 16, color: Colors.grey[400]);
      case "diterima":
        return Icon(Icons.done_all, size: 16, color: Colors.grey[400]);
      case "dibaca":
        return Icon(Icons.done_all, size: 16, color: primaryColor);
      case "gagal":
        return Icon(Icons.error_outline, size: 16, color: Colors.red[400]);
      default:
        return Icon(Icons.check, size: 16, color: Colors.grey[400]);
    }
  }

  Widget _buildAvatar(String username, {bool isOnline = true, String avatarUrl = ''}) {
    return Container(
      width: 40,
      height: 40,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          colors: [primaryColor, accentColor],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: primaryColor.withOpacity(0.3),
            blurRadius: 8,
            spreadRadius: 1,
          ),
        ],
      ),
      child: Stack(
        children: [
          avatarUrl.isNotEmpty
              ? ClipOval(child: Image.network(avatarUrl, width: 40, height: 40, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Center(child: Text(username.isEmpty ? '?' : username.substring(0, 1).toUpperCase(), style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)))))
              : Center(
            child: Text(
              username.isEmpty ? '?' : username.substring(0, 1).toUpperCase(),
              style: const TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
                shadows: [
                  Shadow(
                    blurRadius: 2,
                    color: Colors.black26,
                    offset: Offset(1, 1),
                  ),
                ],
              ),
            ),
          ),
          if (isOnline)
            Positioned(
              bottom: 2,
              right: 2,
              child: Container(
                width: 10,
                height: 10,
                decoration: BoxDecoration(
                  color: const Color(0xFF1565C0),
                  shape: BoxShape.circle,
                  border: Border.all(color: backgroundColor, width: 2),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF1565C0).withOpacity(0.5),
                      blurRadius: 4,
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildMessageBubble(Map<String, dynamic> item, bool isMe) {
    final type = (item['media_type'] ?? 'text').toString();
    final url = (item['media_url'] ?? '').toString();
    final name = (item['file_name'] ?? item['message'] ?? 'Media').toString();
    final idx = chats.indexOf(item);
    final isFirstInSequence = idx <= 0 || chats[idx - 1]['from'] != item['from'];
    return GestureDetector(
      onLongPress: () => _showGlobalMessageActions(item),
      child: Padding(
        padding: EdgeInsets.only(top: isFirstInSequence ? 8 : 2, left: 12, right: 12),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          mainAxisAlignment: isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
          children: [
            if (!isMe) ...[
              AnimatedOpacity(
                opacity: isFirstInSequence ? 1 : 0,
                duration: const Duration(milliseconds: 200),
                child: GestureDetector(
                  onTap: () => _showUserProfile(item['from'].toString()),
                  child: _buildAvatar(item['from'], avatarUrl: (item['avatar_url'] ?? '').toString()),
                ),
              ),
              const SizedBox(width: 8),
            ],
            Flexible(
              child: Column(
                crossAxisAlignment: isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                children: [
                  if (!isMe && isFirstInSequence)
                    Padding(
                      padding: const EdgeInsets.only(left: 12, bottom: 4),
                      child: GestureDetector(
                        onTap: () => _showUserProfile(item['from'].toString()),
                        child: Text(
                          (item['display_name'] ?? item['from']).toString(),
                          style: TextStyle(color: Colors.grey[300], fontSize: 12, fontWeight: FontWeight.w700),
                        ),
                      ),
                    ),
                  Container(
                    constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .78),
                    decoration: BoxDecoration(
                      color: isMe ? bubbleOutgoing : bubbleIncoming,
                      borderRadius: BorderRadius.only(
                        topLeft: const Radius.circular(20), topRight: const Radius.circular(20),
                        bottomLeft: isMe ? const Radius.circular(20) : const Radius.circular(4),
                        bottomRight: isMe ? const Radius.circular(4) : const Radius.circular(20),
                        ),
                      boxShadow: [BoxShadow(color: Colors.black.withOpacity(.14), blurRadius: 7, offset: const Offset(0, 2))],
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          if(item['forwarded']==true) const Text('↗ Diteruskan',style:TextStyle(color:Colors.white54,fontSize:10,fontWeight:FontWeight.w700)),
                          if(item['reply_preview'] is Map) Container(width:double.infinity,margin:const EdgeInsets.only(bottom:7),padding:const EdgeInsets.all(8),decoration:BoxDecoration(color:Colors.black.withOpacity(.16),borderRadius:BorderRadius.circular(9)),child:Text('${(item['reply_preview']['from']??'')}: ${(item['reply_preview']['message']??'').toString()}',maxLines:2,overflow:TextOverflow.ellipsis,style:const TextStyle(color:Colors.white70,fontSize:11))),
                          if (type == 'image' && url.isNotEmpty)
                            ClipRRect(
                              borderRadius: BorderRadius.circular(12),
                              child: GestureDetector(
                                onTap: () => _openMedia(url),
                                child: Image.network(url, width: 270, height: 205, fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) => _mediaTile(Icons.broken_image_rounded, name)),
                              ),
                            )
                          else if (type == 'video' && url.isNotEmpty)
                            _videoTile(url, name)
                          else if (type == 'audio' && url.isNotEmpty)
                            _audioTile(url, name)
                          else if (type != 'text')
                            _mediaTile(Icons.insert_drive_file_rounded, name, onTap: url.isNotEmpty ? () => _openMedia(url) : null)
                          else
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Flexible(child: Text(item['message'].toString(), style: const TextStyle(color: Colors.white, fontSize: 15, height: 1.4))),
                                if (item['edited'] == true)
                                  const Padding(padding: EdgeInsets.only(left: 6), child: Text('(diedit)', style: TextStyle(color: Colors.white54, fontSize: 10))),
                              ],
                            ),
                          const SizedBox(height: 6),
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(_formatTime(item['time']), style: TextStyle(color: Colors.grey[400], fontSize: 11)),
                              if (isMe) ...[
                                const SizedBox(width: 6),
                                _buildMessageStatus(item['status'] ?? 'terkirim'),
                              ],
                            ],
                          ),
                          if (item['reactions'] is Map && (item['reactions'] as Map).isNotEmpty) Padding(
                            padding: const EdgeInsets.only(top: 5),
                            child: Wrap(
                              spacing: 3,
                              children: (item['reactions'] as Map).values.map<Widget>((e) {
                                return Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                  decoration: BoxDecoration(color: Colors.black.withOpacity(.18), borderRadius: BorderRadius.circular(10)),
                                  child: Text(e.toString(), style: const TextStyle(fontSize: 12)),
                                );
                              }).toList(),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            if (isMe) const SizedBox(width: 8),
          ],
        ),
      ),
    );
  }

  Widget _mediaTile(IconData icon, String name, {VoidCallback? onTap}) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(14),
    child: Container(width: 250, padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: Colors.black.withOpacity(.16), borderRadius: BorderRadius.circular(14)), child: Row(children: [Icon(icon, color: Colors.white, size: 40), const SizedBox(width: 12), Expanded(child: Text(name, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white70)))])),
  );


  Widget _videoTile(String url, String name) {
    final active = _playingVideoUrl == url && _videoController != null && _videoController!.value.isInitialized;
    if (!active) return InkWell(onTap: () => _playVideo(url), borderRadius: BorderRadius.circular(14), child: Container(width: 270, height: 152, decoration: BoxDecoration(color: Colors.black26, borderRadius: BorderRadius.circular(14)), child: Stack(alignment: Alignment.center, children: [const Icon(Icons.play_circle_fill_rounded, color: Colors.white, size: 58), Positioned(bottom: 8, left: 10, right: 10, child: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white70)))])));
    return ClipRRect(borderRadius: BorderRadius.circular(14), child: AspectRatio(aspectRatio: _videoController!.value.aspectRatio, child: VideoPlayer(_videoController!)));
  }

  Future<void> _playVideo(String url) async {
    try {
      await _videoController?.dispose();
      final c = VideoPlayerController.networkUrl(Uri.parse(url));
      await c.initialize();
      if (!mounted) { await c.dispose(); return; }
      setState(() { _videoController = c; _playingVideoUrl = url; });
      await c.play();
      c.addListener(() { if (mounted && c.value.isInitialized && c.value.position >= c.value.duration && _playingVideoUrl == url) setState(() => _playingVideoUrl = null); });
    } catch (_) { if (mounted) setState(() => errorMessage = 'Video tidak bisa diputar'); }
  }

  Widget _audioTile(String url, String name) => InkWell(
    onTap: () => _playAudio(url),
    borderRadius: BorderRadius.circular(14),
    child: Container(width: 250, padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12), decoration: BoxDecoration(color: Colors.black.withOpacity(.16), borderRadius: BorderRadius.circular(14)), child: Row(children: [CircleAvatar(backgroundColor: Colors.white12, child: Icon(playingAudioUrl == url ? Icons.stop_rounded : Icons.play_arrow_rounded, color: Colors.white)), const SizedBox(width: 10), Expanded(child: Text('🎤 VN • $name', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)))])),
  );

  Future<void> _openMedia(String url) async {
    try { await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication); } catch (_) { if (mounted) setState(() => errorMessage = 'Media tidak bisa dibuka'); }
  }

  Widget _buildDateSeparator(String date) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: Row(
        children: [
          Expanded(
            child: Divider(
              color: Colors.grey[700],
              thickness: 0.5,
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 16),
              decoration: BoxDecoration(
                color: const Color(0xFF18262C),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.white.withOpacity(.06)),
                boxShadow: [BoxShadow(color: Colors.black.withOpacity(.18), blurRadius: 8, offset: const Offset(0, 2))],
              ),
              child: Text(
                date,
                style: TextStyle(
                  color: subtitleColor,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.5,
                ),
              ),
            ),
          ),
          Expanded(
            child: Divider(
              color: Colors.grey[700],
              thickness: 0.5,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light.copyWith(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.light,
        systemNavigationBarColor: backgroundColor,
        systemNavigationBarIconBrightness: Brightness.light,
      ),
      child: Scaffold(
        backgroundColor: backgroundColor,
        body: SafeArea(
          child: Column(
            children: [
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [backgroundColor, secondaryColor.withOpacity(0.8)],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.3),
                      blurRadius: 10,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(10, 6, 8, 8),
                  child: Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.arrow_back_rounded, size: 28),
                        color: Colors.white,
                        onPressed: () => Navigator.pop(context),
                      ),
                      const SizedBox(width: 8),
                      _buildAvatar("Global"),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "🌐 CHAT GLOBAL",
                              style: TextStyle(
                                fontSize: 17,
                                fontWeight: FontWeight.w700,
                                color: Colors.white,
                                letterSpacing: 0.5,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              "Online: ${chats.map((c) => c['from']).toSet().length} • ${chats.length} pesan",
                              style: TextStyle(
                                fontSize: 12,
                                color: subtitleColor,
                              ),
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.attach_file_rounded, size: 24),
                        color: Colors.white,
                        onPressed: _showAttachments,
                      ),
                      IconButton(
                        onPressed: _showProfileEditor,
                        tooltip: 'Profil',
                        icon: const Icon(Icons.account_circle_outlined, size: 24),
                        color: Colors.white,
                      ),
                      IconButton(
                        icon: Icon(Icons.more_vert_rounded, size: 24),
                        color: Colors.white,
                        onPressed: () {},
                      ),
                    ],
                  ),
                ),
              ),

              Expanded(
                child: loading
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            CircularProgressIndicator(
                              valueColor: AlwaysStoppedAnimation(primaryColor),
                              strokeWidth: 3,
                            ),
                            const SizedBox(height: 16),
                            Text(
                              "Memuat percakapan...",
                              style: TextStyle(color: subtitleColor, fontSize: 14),
                            ),
                          ],
                        ),
                      )
                    : errorMessage != null && chats.isEmpty
                        ? Center(
                            child: Padding(
                              padding: const EdgeInsets.all(28),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.cloud_off_rounded, color: Colors.grey[500], size: 52),
                                  const SizedBox(height: 14),
                                  Text(
                                    errorMessage!,
                                    textAlign: TextAlign.center,
                                    style: TextStyle(color: subtitleColor, fontSize: 14),
                                  ),
                                  const SizedBox(height: 16),
                                  ElevatedButton.icon(
                                    onPressed: () => _loadChats(),
                                    icon: const Icon(Icons.refresh_rounded),
                                    label: const Text('Coba Lagi'),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: primaryColor,
                                      foregroundColor: Colors.white,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          )
                        : RefreshIndicator(
                        key: refreshKey,
                        backgroundColor: backgroundColor,
                        color: primaryColor,
                        onRefresh: _refreshChats,
                        child: ListView.builder(
                          controller: scrollCtrl,
                          padding: const EdgeInsets.symmetric(vertical: 8),
                          physics: const AlwaysScrollableScrollPhysics(),
                          itemCount: chats.length + 1,
                          itemBuilder: (context, index) {
                            if (index == 0) {
                              return _buildDateSeparator("Hari Ini");
                            }
                            final item = chats[index - 1];
                            final isMe = item['from'] == widget.username;
                            
                            if (index > 1) {
                              final prevItem = chats[index - 2];
                              final currentDate = _formatDate(item['time']);
                              final prevDate = _formatDate(prevItem['time']);
                              
                              if (currentDate != prevDate) {
                                return Column(
                                  children: [
                                    _buildDateSeparator(currentDate),
                                    _buildMessageBubble(item, isMe),
                                  ],
                                );
                              }
                            }
                            
                            return _buildMessageBubble(item, isMe);
                          },
                        ),
                      ),
              ),

              if (isSending)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8, left: 16),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 10,
                        ),
                        decoration: BoxDecoration(
                          color: bubbleIncoming,
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.1),
                              blurRadius: 4,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: Row(
                          children: [
                            SizedBox(
                              width: 24,
                              height: 24,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                valueColor: AlwaysStoppedAnimation(primaryColor),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Text(
                              "Mengirim...",
                              style: TextStyle(
                                color: subtitleColor,
                                fontSize: 13,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

              Container(
                padding: const EdgeInsets.fromLTRB(10, 7, 10, 9),
                decoration: BoxDecoration(
                  color: const Color(0xFF202C33),
                  border: Border(top: BorderSide(color: Colors.white.withOpacity(.045))),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.3),
                      blurRadius: 15,
                      offset: const Offset(0, -5),
                    ),
                  ],
                ),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  if (_replyingTo != null) Container(width: double.infinity, color: backgroundColor, padding: const EdgeInsets.fromLTRB(14, 7, 7, 7), child: Row(children: [const Icon(Icons.reply_rounded, color: Color(0xFF00A884), size: 18), const SizedBox(width: 8), Expanded(child: Text((_replyingTo!['message'] ?? _replyingTo!['file_name'] ?? 'Media').toString(), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white70, fontSize: 12))), IconButton(onPressed: () { setState(() { _replyingTo = null; }); }, icon: const Icon(Icons.close_rounded, color: Colors.white54, size: 18))])),
                  Row(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        color: backgroundColor,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.2),
                            blurRadius: 4,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: IconButton(
                        icon: const Icon(Icons.emoji_emotions_outlined, size: 22),
                        color: Colors.grey[400],
                        onPressed: () {},
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      decoration: BoxDecoration(
                        color: backgroundColor,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.2),
                            blurRadius: 4,
                          ),
                        ],
                      ),
                      child: IconButton(
                        icon: Icon(Icons.attach_file_rounded, size: 24),
                        color: Colors.grey[400],
                        onPressed: isSending ? null : _showAttachments,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                          color: backgroundColor,
                          borderRadius: BorderRadius.circular(24),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.2),
                              blurRadius: 8,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: TextField(
                          controller: msgCtrl,
                          focusNode: focusNode,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                          ),
                          maxLines: null,
                          onChanged: (value) {
                            setState(() {
                              showSendButton = value.trim().isNotEmpty;
                            });
                          },
                          onSubmitted: (_) => _sendMessage(),
                          decoration: InputDecoration(
                            hintText: "Ketik pesan...",
                            hintStyle: TextStyle(
                              color: Colors.grey[500],
                              fontSize: 15,
                            ),
                            border: InputBorder.none,
                            contentPadding: const EdgeInsets.symmetric(
                              horizontal: 20,
                              vertical: 14,
                            ),
                            suffixIcon: showSendButton
                                ? IconButton(
                                    icon: Icon(
                                      Icons.send_rounded,
                                      color: primaryColor,
                                      size: 24,
                                    ),
                                    onPressed: _sendMessage,
                                  )
                                : null,
                          ),
                        ),
                      ),
                    ),
                    if (!showSendButton) ...[
                      const SizedBox(width: 12),
                      Container(
                        decoration: BoxDecoration(
                          color: primaryColor,
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: primaryColor.withOpacity(0.3),
                              blurRadius: 8,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: IconButton(
                          icon: Icon(isRecordingVoice ? Icons.stop_rounded : Icons.mic_rounded, size: 24),
                          color: Colors.white,
                          onPressed: _toggleVoice,
                        ),
                      ),
                    ],
                  ],
                ),
                ],
                ),
              ),
            ],
          ),
        ),
        floatingActionButton: showScrollButton
            ? FloatingActionButton.small(
                backgroundColor: primaryColor,
                foregroundColor: Colors.white,
                elevation: 4,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                onPressed: _scrollToBottom,
                child: const Icon(Icons.arrow_downward_rounded, size: 20),
              )
            : null,
      ),
    );
  }
}
