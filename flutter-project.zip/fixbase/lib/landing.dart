import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';

class ShadowColors {
  static const bg           = Color(0xFF000000);
  static const surface      = Color(0xFF0A0A0A);
  static const surfaceLight = Color(0xFF1A1A1A);
  static const white        = Color(0xFFFFFFFF);
  static const whiteSoft    = Color(0xFFF5F5F5);
  static const greyLight    = Color(0xFFE0E0E0);
  static const grey         = Color(0xFF9E9E9E);
  static const greyDark     = Color(0xFF616161);
  static const borderGlow   = Color(0xFFFFFFFF);
  static const textMain     = Color(0xFFFFFFFF);
  static const textSub      = Color(0xFFB0B0B0);
  static const success      = Color(0xFF00E676);
  static const hexPattern   = Color(0xFF1A1A1A);
}

class FingerprintScanner extends StatefulWidget {
  final VoidCallback onScanComplete;
  const FingerprintScanner({super.key, required this.onScanComplete});

  @override
  State<FingerprintScanner> createState() => _FingerprintScannerState();
}

class _FingerprintScannerState extends State<FingerprintScanner>
    with TickerProviderStateMixin {
  bool _scanning = false;
  bool _scanSuccess = false;
  bool _isTouching = false;

  late AnimationController _scanLineController;
  late Animation<double> _scanLineAnimation;
  late AnimationController _scanRingController;
  late Animation<double> _scanRingAnimation;
  late AnimationController _rippleController;
  late Animation<double> _rippleAnimation;

  late VideoPlayerController _videoCtrl;
  bool _videoReady = false;

  @override
  void initState() {
    super.initState();

    _initVideoController();
    _initAnimations();
  }

  void _initVideoController() {
    _videoCtrl = VideoPlayerController.asset('assets/videos/landing.mp4')
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _videoReady = true);
          _videoCtrl.setLooping(true);
          _videoCtrl.setVolume(1.0); // ← AKTIFKAN AUDIO
          _videoCtrl.play();
        }
      }).catchError((e) {
        if (mounted) {
          setState(() => _videoReady = false);
          debugPrint('Video error: $e');
        }
      });
  }

  void _initAnimations() {
    _scanLineController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );
    _scanLineAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _scanLineController, curve: Curves.easeInOut),
    );

    _scanRingController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat();
    _scanRingAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _scanRingController, curve: Curves.linear),
    );

    _rippleController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat();
    _rippleAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _rippleController, curve: Curves.easeOut),
    );
  }

  void _startScan() {
    if (_scanning || _scanSuccess) return;
    setState(() {
      _scanning    = true;
      _scanSuccess = false;
      _isTouching  = true;
    });
    _scanLineController.reset();
    _scanLineController.forward().then((_) {
      if (_isTouching && _scanning && mounted) {
        setState(() {
          _scanSuccess = true;
          _scanning    = false;
          _isTouching  = false;
        });
        Future.delayed(const Duration(milliseconds: 1200), widget.onScanComplete);
      }
    });
  }

  void _cancelScan() {
    if (_scanning && !_scanSuccess) {
      setState(() {
        _scanning   = false;
        _isTouching = false;
      });
      _scanLineController.stop();
      _scanLineController.reset();
    }
  }

  @override
  void dispose() {
    _videoCtrl.dispose();
    _scanLineController.dispose();
    _scanRingController.dispose();
    _rippleController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ShadowColors.bg,
      body: Stack(
        children: [
          CustomPaint(
            painter: _HexBgPainter(),
            child: const SizedBox.expand(),
          ),
          SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(32.0),
                    child: AspectRatio(
                      aspectRatio: 16 / 9,
                      child: _buildVideoPlayer(),
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 28.0),
                    child: Column(
                      children: [
                        Expanded(
                          flex: 2,
                          child: Center(child: _buildTopSection()),
                        ),
                        Expanded(
                          flex: 1,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              GestureDetector(
                                onTapDown: (_) => _startScan(),
                                onTapUp:   (_) => _cancelScan(),
                                onTapCancel: _cancelScan,
                                child: _buildFingerprint(),
                              ),
                              const SizedBox(height: 16),
                              _buildStatusText(),
                              if (_scanning) ...[
                                const SizedBox(height: 16),
                                _buildScanEffect(),
                              ],
                              if (_scanSuccess) ...[
                                const SizedBox(height: 16),
                                _buildSuccessEffect(),
                              ],
                              const SizedBox(height: 40),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVideoPlayer() {
    if (!_videoReady) {
      return Container(
        color: Colors.black,
        child: const Center(
          child: CircularProgressIndicator(
            color: Colors.white,
            strokeWidth: 2,
          ),
        ),
      );
    }

    return VideoPlayer(_videoCtrl);
  }

  Widget _buildTopSection() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: Colors.white.withOpacity(0.1),
                blurRadius: 50,
                spreadRadius: 10,
              ),
            ],
          ),
          child: const Icon(
            Icons.lock_outline_rounded,
            size: 90,
            color: Colors.white,
          ),
        ),
        const SizedBox(height: 24),
        const Text(
          'Verifikasi sidik jari',
          style: TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.bold,
            color: Colors.white,
            letterSpacing: 1.5,
          ),
        ),
        const SizedBox(height: 10),
        const Text(
          'Solusi WhatsApp • Sistem Digital',
          style: TextStyle(
            fontSize: 16,
            color: ShadowColors.textSub,
            letterSpacing: 0.5,
          ),
        ),
      ],
    );
  }

  Widget _buildFingerprint() {
    return Stack(
      alignment: Alignment.center,
      children: [
        if (_scanning)
          AnimatedBuilder(
            animation: _rippleAnimation,
            builder: (_, __) {
              final size = 80 + _rippleAnimation.value * 60;
              return Container(
                width: size, height: size,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: Colors.white.withOpacity(0.3 * (1 - _rippleAnimation.value)),
                    width: 2,
                  ),
                ),
              );
            },
          ),
        if (_scanning)
          AnimatedBuilder(
            animation: _rippleAnimation,
            builder: (_, __) {
              final size = 80 + _rippleAnimation.value * 100;
              return Container(
                width: size, height: size,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: Colors.white.withOpacity(0.15 * (1 - _rippleAnimation.value)),
                    width: 1.5,
                  ),
                ),
              );
            },
          ),
        if (_scanning)
          AnimatedBuilder(
            animation: _scanRingAnimation,
            builder: (_, __) {
              return Transform.rotate(
                angle: _scanRingAnimation.value * 2 * math.pi,
                child: Container(
                  width: 110, height: 110,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: Colors.white.withOpacity(0.4),
                      width: 2,
                      strokeAlign: BorderSide.strokeAlignOutside,
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: Colors.white.withOpacity(0.2),
                          width: 1,
                          strokeAlign: BorderSide.strokeAlignOutside,
                        ),
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        Container(
          width: 90, height: 90,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(
              color: _scanSuccess
                  ? ShadowColors.success
                  : _scanning
                      ? Colors.white.withOpacity(0.8)
                      : Colors.white.withOpacity(0.3),
              width: _scanning ? 2.5 : 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: _scanSuccess
                    ? ShadowColors.success.withOpacity(0.4)
                    : _scanning
                        ? Colors.white.withOpacity(0.3)
                        : Colors.white.withOpacity(0.05),
                blurRadius: _scanning ? 35 : 20,
                spreadRadius: _scanning ? 5 : 2,
              ),
            ],
          ),
          child: Icon(
            _scanSuccess ? Icons.check_circle : Icons.fingerprint,
            color: _scanSuccess ? ShadowColors.success : Colors.white,
            size: 50,
          ),
        ),
      ],
    );
  }

  Widget _buildScanEffect() {
    return Column(
      children: [
        Container(
          width: 180, height: 3,
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.1),
            borderRadius: BorderRadius.circular(2),
          ),
          child: AnimatedBuilder(
            animation: _scanLineAnimation,
            builder: (_, __) {
              return FractionallySizedBox(
                heightFactor: 1,
                widthFactor: _scanLineAnimation.value,
                alignment: Alignment.centerLeft,
                child: Container(
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Colors.white, Colors.grey],
                    ),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 8),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(8, (index) {
            return AnimatedBuilder(
              animation: _scanLineAnimation,
              builder: (_, __) {
                final active = index / 8 < _scanLineAnimation.value;
                return Container(
                  margin: const EdgeInsets.symmetric(horizontal: 2),
                  width: 4, height: 4,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: active
                        ? Colors.white.withOpacity(0.8)
                        : Colors.white.withOpacity(0.15),
                  ),
                );
              },
            );
          }),
        ),
      ],
    );
  }

  Widget _buildSuccessEffect() {
    return TweenAnimationBuilder(
      tween: Tween<double>(begin: 0.0, end: 1.0),
      duration: const Duration(milliseconds: 600),
      builder: (_, double value, __) {
        return Column(
          children: [
            Container(
              width: 180, height: 3,
              decoration: BoxDecoration(
                color: ShadowColors.success.withOpacity(0.3),
                borderRadius: BorderRadius.circular(2),
              ),
              child: FractionallySizedBox(
                heightFactor: 1,
                widthFactor: value,
                alignment: Alignment.centerLeft,
                child: Container(
                  decoration: BoxDecoration(
                    color: ShadowColors.success,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(8, (index) {
                final active = index / 8 < value;
                return Container(
                  margin: const EdgeInsets.symmetric(horizontal: 2),
                  width: 4, height: 4,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: active
                        ? ShadowColors.success.withOpacity(0.8)
                        : ShadowColors.success.withOpacity(0.15),
                  ),
                );
              }),
            ),
          ],
        );
      },
    );
  }

  Widget _buildStatusText() {
    String text;
    if (_scanSuccess) {
      text = '✓ Scan Berhasil!';
    } else if (_scanning) {
      text = 'Memindai...';
    } else {
      text = 'Sentuh layar untuk memindai';
    }
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 300),
      child: Text(
        text,
        key: ValueKey(text),
        style: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w600,
          color: _scanSuccess ? ShadowColors.success : Colors.white,
          letterSpacing: 1,
        ),
      ),
    );
  }
}

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});
  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> with TickerProviderStateMixin {
  final PageController _pageCtrl = PageController();
  int _currentPage = 0;

  late VideoPlayerController _videoCtrl;
  bool _videoReady = false;

  late AnimationController _glowCtrl;
  late AnimationController _entranceCtrl;
  late Animation<double> _glow;
  late Animation<double> _fade;
  late Animation<Offset> _slideUp;

  late AnimationController _introCtrl;
  late Animation<double> _welcomeScale;
  late Animation<double> _welcomeFade;

  late AnimationController _transitionCtrl;
  late Animation<double> _transitionFade;
  late Animation<Offset> _transitionSlide;

  bool _fingerprintDone = false;
  bool _showLanding     = false;

  @override
  void initState() {
    super.initState();

    _initVideoController();
    _initAnimations();
  }

  void _initVideoController() {
    _videoCtrl = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _videoReady = true);
          _videoCtrl.setLooping(true);
          _videoCtrl.setVolume(1.0); // ← AKTIFKAN AUDIO
          _videoCtrl.play();
        }
      }).catchError((e) {
        if (mounted) {
          setState(() => _videoReady = false);
          debugPrint('Video init error: $e');
        }
      });
  }

  void _initAnimations() {
    _glowCtrl     = AnimationController(vsync: this, duration: const Duration(milliseconds: 2000))
      ..repeat(reverse: true);
    _entranceCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200));
    _introCtrl    = AnimationController(vsync: this, duration: const Duration(milliseconds: 1800));
    _transitionCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1500));

    _glow    = Tween<double>(begin: 0.3, end: 1.0)
        .animate(CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut));
    _fade    = CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOut);
    _slideUp = Tween<Offset>(begin: const Offset(0, 0.06), end: Offset.zero)
        .animate(CurvedAnimation(parent: _entranceCtrl, curve: Curves.easeOutCubic));

    _welcomeScale = Tween<double>(begin: 0.7, end: 1.0)
        .animate(CurvedAnimation(parent: _introCtrl, curve: Curves.elasticOut));
    _welcomeFade  = Tween<double>(begin: 0.0, end: 1.0)
        .animate(CurvedAnimation(parent: _introCtrl, curve: Curves.easeOut));

    _transitionFade  = Tween<double>(begin: 0.0, end: 1.0)
        .animate(CurvedAnimation(parent: _transitionCtrl, curve: Curves.easeInOutCubic));
    _transitionSlide = Tween<Offset>(begin: const Offset(0, 0.08), end: Offset.zero)
        .animate(CurvedAnimation(parent: _transitionCtrl, curve: Curves.easeOutCubic));
  }

  void _startTransition() {
    if (_showLanding) return;
    setState(() => _showLanding = true);
    _transitionCtrl.forward().then((_) {
      if (mounted) {
        _entranceCtrl.forward();
        Future.delayed(const Duration(milliseconds: 200), () {
          if (mounted) _introCtrl.forward();
        });
      }
    });
  }

  @override
  void dispose() {
    _videoCtrl.dispose();
    _glowCtrl.dispose();
    _entranceCtrl.dispose();
    _introCtrl.dispose();
    _transitionCtrl.dispose();
    _pageCtrl.dispose();
    super.dispose();
  }

  Future<void> _launch(String url) async {
    final u = Uri.parse(url);
    if (await canLaunchUrl(u)) await launchUrl(u, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    if (!_fingerprintDone) {
      return FingerprintScanner(
        onScanComplete: () {
          setState(() => _fingerprintDone = true);
          _startTransition();
        },
      );
    }

    if (!_showLanding) {
      return Scaffold(
        backgroundColor: ShadowColors.bg,
        body: const Center(
          child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
        ),
      );
    }

    return Scaffold(
      backgroundColor: ShadowColors.bg,
      body: FadeTransition(
        opacity: _transitionFade,
        child: SlideTransition(
          position: _transitionSlide,
          child: Stack(children: [
            CustomPaint(painter: _HexBgPainter(), child: const SizedBox.expand()),
            SafeArea(
              child: FadeTransition(
                opacity: _fade,
                child: SlideTransition(
                  position: _slideUp,
                  child: Stack(children: [
                    PageView(
                      controller: _pageCtrl,
                      scrollDirection: Axis.vertical,
                      onPageChanged: (i) => setState(() => _currentPage = i),
                      children: [
                        _buildWelcomePage(),
                        _buildIndonesianPage(),
                        _buildMainLanding(),
                      ],
                    ),
                    Positioned(
                      left: 14,
                      top: 0,
                      bottom: 0,
                      child: Center(child: _buildDotIndicator()),
                    ),
                  ]),
                ),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _buildWelcomePage() {
    return Container(
      decoration: BoxDecoration(
        gradient: RadialGradient(
          center: Alignment.center,
          radius: 0.8,
          colors: [
            Colors.white.withOpacity(0.03),
            Colors.transparent,
          ],
          stops: const [0.0, 1.0],
        ),
      ),
      child: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              AnimatedBuilder(
                animation: _glowCtrl,
                builder: (_, __) => Container(
                  width: 90, height: 90,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: [
                        Colors.white.withOpacity(0.4 * _glow.value),
                        Colors.white.withOpacity(0.0),
                      ],
                      radius: 0.9,
                    ),
                  ),
                  child: const Icon(
                    Icons.hexagon_rounded,
                    color: Colors.white,
                    size: 70,
                  ),
                ),
              ),
              const SizedBox(height: 30),
              ShaderMask(
                shaderCallback: (bounds) => const LinearGradient(
                  colors: [Colors.white, Colors.grey],
                ).createShader(bounds),
                child: AnimatedBuilder(
                  animation: _introCtrl,
                  builder: (_, __) => Transform.scale(
                    scale: _welcomeScale.value,
                    child: Opacity(
                      opacity: _welcomeFade.value,
                      child: const Text(
                        'SELAMAT\nDATANG',
                        textAlign: TextAlign.right,
                        style: TextStyle(
                          fontFamily: 'Orbitron',
                          fontSize: 44,
                          fontWeight: FontWeight.w900,
                          color: Colors.white,
                          letterSpacing: 8,
                          height: 1.1,
                          shadows: [
                            Shadow(
                              blurRadius: 20,
                              color: Colors.white38,
                              offset: Offset(0, 0),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              AnimatedBuilder(
                animation: _introCtrl,
                builder: (_, __) => Opacity(
                  opacity: _welcomeFade.value * 0.8,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.white.withOpacity(0.2)),
                      borderRadius: BorderRadius.circular(30),
                    ),
                    child: const Text(
                      "𝗞𝗘 ZIXTER NIGHT",
                      textAlign: TextAlign.right,
                      style: TextStyle(
                        fontFamily: 'Orbitron',
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: ShadowColors.textSub,
                        letterSpacing: 4,
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 60),
              AnimatedBuilder(
                animation: _glowCtrl,
                builder: (_, __) => Opacity(
                  opacity: 0.3 + 0.7 * _glow.value,
                  child: const Icon(
                    Icons.keyboard_double_arrow_down_rounded,
                    color: Colors.white,
                    size: 32,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildIndonesianPage() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [
            ShadowColors.bg,
            ShadowColors.surface,
            ShadowColors.bg,
          ],
        ),
      ),
      child: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 28),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Row(
                children: [
                  const Text(
                    'ID',
                    style: TextStyle(
                      fontFamily: 'Orbitron',
                      fontSize: 32,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      letterSpacing: 2,
                    ),
                  ),
                  const Spacer(),
                  Container(
                    width: 80, height: 2,
                    color: Colors.white.withOpacity(0.5),
                  ),
                  const SizedBox(width: 10),
                  const Icon(
                    Icons.circle_outlined,
                    color: Colors.white,
                    size: 18,
                  ),
                ],
              ),
              const SizedBox(height: 30),
              ShaderMask(
                shaderCallback: (bounds) => const LinearGradient(
                  colors: [Colors.white, Colors.grey],
                ).createShader(bounds),
                child: const Text(
                  'Selamat menggunakan\naplikasi kami',
                  textAlign: TextAlign.right,
                  style: TextStyle(
                    fontSize: 30,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                    height: 1.3,
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.15),
                    width: 1.5,
                  ),
                  color: ShadowColors.surface.withOpacity(0.5),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.white.withOpacity(0.05),
                      blurRadius: 20,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: const Text(
                  'Selamat datang! Kami sangat senang karena kamu sudah bergabung '
                  'bersama komunitas kami. Di sini, kamu bisa menikmati berbagai fitur '
                  'canggih dan alat digital yang dirancang untuk memudahkan aktivitas '
                  'sehari-hari. Jika ada pertanyaan atau kendala, jangan ragu untuk '
                  'menghubungi tim support kami kapan saja. '
                  'Selamat menikmati pengalaman terbaik bersama The ZIXTER NIGHT!',
                  textAlign: TextAlign.right,
                  style: TextStyle(
                    fontSize: 15,
                    color: ShadowColors.textSub,
                    height: 1.8,
                    letterSpacing: 0.5,
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Align(
                alignment: Alignment.centerLeft,
                child: Container(
                  width: 60, height: 3,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Colors.white, Colors.grey],
                    ),
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMainLanding() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(children: [
        _buildHeroVideo(),
        _buildTitleSection(),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 18),
          child: Column(children: [
            const SizedBox(height: 18),
            _buildAboutCard(),
            const SizedBox(height: 14),
            _buildSignInButton(),
            const SizedBox(height: 10),
            _buildDevOwnerRow(),
            const SizedBox(height: 14),
            _buildFooter(),
            const SizedBox(height: 20),
          ]),
        ),
      ]),
    );
  }

  Widget _buildHeroVideo() {
    return Container(
      height: 280,
      width: double.infinity,
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(32),
        boxShadow: [
          BoxShadow(
            color: Colors.white.withOpacity(0.08),
            blurRadius: 30,
            spreadRadius: 2,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(32),
        child: _buildVideoPlayerWidget(),
      ),
    );
  }

  Widget _buildVideoPlayerWidget() {
    if (!_videoReady) {
      return Container(
        color: const Color(0xFF0A0A0A),
        child: const Center(
          child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
        ),
      );
    }
    return VideoPlayer(_videoCtrl);
  }

  Widget _buildTitleSection() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 0),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF0A0A0A), Color(0xFF1A1A1A)],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          const Text(
            'THE',
            textAlign: TextAlign.right,
            style: TextStyle(
              fontFamily: 'Orbitron',
              fontSize: 34,
              fontWeight: FontWeight.w900,
              color: Colors.white,
              letterSpacing: 6,
              height: 1.1,
            ),
          ),
          ShaderMask(
            shaderCallback: (b) => const LinearGradient(
              colors: [Colors.white, Colors.grey, Colors.white],
            ).createShader(b),
            child: const Text(
              "ZIXTER NIGHT",
              textAlign: TextAlign.right,
              style: TextStyle(
                fontFamily: 'Orbitron',
                fontSize: 34,
                fontWeight: FontWeight.w900,
                color: Colors.white,
                letterSpacing: 4,
                height: 1.1,
              ),
            ),
          ),
          const SizedBox(height: 6),
        ],
      ),
    );
  }

  Widget _buildAboutCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        color: const Color(0xFF1A1A1A).withOpacity(0.92),
        border: Border.all(color: Colors.white.withOpacity(0.3), width: 1),
        boxShadow: [
          BoxShadow(color: Colors.white.withOpacity(0.05), blurRadius: 18),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              const Text(
                "About The ZIXTER NIGHT",
                textAlign: TextAlign.right,
                style: TextStyle(
                  fontFamily: 'Orbitron',
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                  color: ShadowColors.textMain,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                "The ZIXTER NIGHT adalah platform tools yang dirancang untuk memberikan performa terbaik. Dikembangkan semaksimal mungkin oleh ZIXTER NIGHT Team dengan sepenuh hati.",
                textAlign: TextAlign.right,
                style: TextStyle(
                  fontSize: 13,
                  color: ShadowColors.textSub,
                  height: 1.5,
                ),
              ),
            ]),
          ),
          Container(
            margin: const EdgeInsets.only(top: 2, left: 10),
            child: const Icon(Icons.info_outline_rounded, color: Colors.white, size: 20),
          ),
        ],
      ),
    );
  }

  Widget _buildSignInButton() {
    return AnimatedBuilder(
      animation: _glowCtrl,
      builder: (_, __) => GestureDetector(
        onTap: () => Navigator.pushNamed(context, '/login'),
        child: Container(
          width: double.infinity,
          height: 54,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            gradient: LinearGradient(
              colors: [
                Colors.grey[400]!,
                Colors.grey[600]!,
                Colors.grey[800]!,
              ],
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.white.withOpacity(0.3 * _glow.value),
                blurRadius: 24,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Padding(
                padding: EdgeInsets.only(left: 18),
                child: Icon(Icons.chevron_left_rounded, color: Colors.white, size: 24),
              ),
              Padding(
                padding: const EdgeInsets.only(right: 20),
                child: Row(children: [
                  const Text(
                    "Login To ZIXTER NIGHT",
                    style: TextStyle(
                      fontFamily: 'Orbitron',
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                      color: Colors.white,
                      letterSpacing: 2,
                    ),
                  ),
                  const SizedBox(width: 10),
                  const Icon(Icons.login_rounded, color: Colors.white, size: 20),
                ]),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDevOwnerRow() {
    return Row(children: [
      Expanded(child: _buildTelegramButton('Dev utama', 'https://t.me/DIZT_ZIXTER')),
      const SizedBox(width: 10),
      Expanded(child: _buildTelegramButton('Dev kedua', 'https://t.me/ZIXTERCRASHER')),
    ]);
  }

  Widget _buildTelegramButton(String label, String url) {
    return GestureDetector(
      onTap: () => _launch(url),
      child: Container(
        height: 50,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          gradient: LinearGradient(
            colors: [
              Colors.grey[600]!,
              Colors.grey[800]!,
            ],
          ),
          boxShadow: [
            BoxShadow(color: Colors.white.withOpacity(0.2), blurRadius: 14),
          ],
        ),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(
            label,
            style: const TextStyle(
              fontFamily: 'Orbitron',
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: Colors.white,
              letterSpacing: 1.2,
            ),
          ),
          const SizedBox(width: 8),
          const FaIcon(FontAwesomeIcons.telegram, color: Colors.white, size: 17),
        ]),
      ),
    );
  }

  Widget _buildFooter() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        color: const Color(0xFF1A1A1A).withOpacity(0.7),
        border: Border.all(color: Colors.white.withOpacity(0.15), width: 1),
      ),
      child: Column(children: [
        ShaderMask(
          shaderCallback: (bounds) => LinearGradient(
            colors: [
              Colors.white,
              Colors.grey[300]!,
              Colors.white,
            ],
            stops: const [0.0, 0.5, 1.0],
          ).createShader(bounds),
          child: const Text(
            'By : DIZT',
            style: TextStyle(
              fontFamily: 'Orbitron',
              fontSize: 14,
              fontWeight: FontWeight.w900,
              color: Colors.white,
              letterSpacing: 4,
              height: 1.5,
            ),
          ),
        ),
        const SizedBox(height: 6),
        const Text(
          "© 2026 The Zixter Night",
          style: TextStyle(
            fontFamily: 'Orbitron',
            fontSize: 11,
            color: ShadowColors.textSub,
            letterSpacing: 2,
          ),
        ),
      ]),
    );
  }

  Widget _buildDotIndicator() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(3, (i) {
        final isActive = _currentPage == i;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          margin: const EdgeInsets.symmetric(vertical: 3),
          width:  isActive ? 10 : 8,
          height: isActive ? 10 : 8,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: isActive
                ? Colors.white
                : ShadowColors.textSub.withOpacity(0.4),
            boxShadow: isActive
                ? [BoxShadow(color: Colors.white.withOpacity(0.7), blurRadius: 8)]
                : null,
          ),
        );
      }),
    );
  }
}

class _HexBgPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(
      Rect.fromLTWH(0, 0, size.width, size.height),
      Paint()
        ..shader = const LinearGradient(
          colors: [Color(0xFF000000), Color(0xFF0A0A0A), Color(0xFF111111)],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ).createShader(Rect.fromLTWH(0, 0, size.width, size.height)),
    );

    final hexPaint = Paint()
      ..color = const Color(0xFF2A2A2A).withOpacity(0.5)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.8;

    const hexSize = 28.0;
    final hexH = hexSize * math.sqrt(3);
    final hexW = hexSize * 2;

    for (double row = 0; row < size.height / hexH + 2; row++) {
      for (double col = 0; col < size.width / hexW + 2; col++) {
        final cx = col * hexW * 0.75 - hexSize;
        final cy = row * hexH + (col.toInt().isOdd ? hexH / 2 : 0) - hexH;
        _drawHex(canvas, hexPaint, Offset(cx, cy), hexSize);
      }
    }
  }

  void _drawHex(Canvas canvas, Paint paint, Offset center, double size) {
    final path = Path();
    for (int i = 0; i < 6; i++) {
      final angle = math.pi / 180 * (60 * i - 30);
      final x = center.dx + size * math.cos(angle);
      final y = center.dy + size * math.sin(angle);
      if (i == 0) path.moveTo(x, y);
      else path.lineTo(x, y);
    }
    path.close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(_HexBgPainter old) => false;
}