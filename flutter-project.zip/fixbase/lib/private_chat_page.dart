import 'dart:async';
import 'dart:io';
import 'dart:convert';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:record/record.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:video_player/video_player.dart';
import 'package:path_provider/path_provider.dart';
import 'package:socket_io_client/socket_io_client.dart' as io;
import 'package:url_launcher/url_launcher.dart';

import 'api_config.dart';
import 'private_call_page.dart';

class PrivateChatPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const PrivateChatPage({super.key, required this.username, required this.sessionKey});

  @override
  State<PrivateChatPage> createState() => _PrivateChatPageState();
}

class _PrivateChatPageState extends State<PrivateChatPage> {
  final search = TextEditingController();
  final ctrl = TextEditingController();
  final picker = ImagePicker();
  final AudioRecorder voiceRecorder = AudioRecorder();
  final AudioPlayer audioPlayer = AudioPlayer();
  bool isRecordingVoice = false;
  String? playingAudioUrl;
  VideoPlayerController? _videoController;
  String? _playingVideoUrl;

  List<Map<String, dynamic>> users = [];
  List<Map<String, dynamic>> current = [];
  String? selected;
  bool loadingUsers = true;
  bool loadingMessages = false;
  bool sending = false;
  bool isComposing = false;
  io.Socket? socket;
  Timer? poll;
  String _profileRole = 'member';
  String _profileDisplayName = '';
  String _profileAbout = '';
  String _profileAvatarUrl = '';
  Map<String, dynamic>? _replyingTo;

  Uri _u(String path, [Map<String, String>? q]) => Uri.parse('$baseUrl$path').replace(queryParameters: q);
  Map<String, String> get _q => {'session_key': widget.sessionKey};

  @override
  void initState() {
    super.initState();
    ctrl.addListener(_composerChanged);
    _loadProfile();
    _loadUsers();
    _connect();
    poll = Timer.periodic(const Duration(seconds: 3), (_) {
      if (selected != null) _loadMessages(silent: true);
    });
  }

  void _composerChanged() {
    final next = ctrl.text.trim().isNotEmpty;
    if (next != isComposing && mounted) setState(() => isComposing = next);
  }

  @override
  void dispose() {
    poll?.cancel();
    socket?.disconnect();
    search.dispose();
    ctrl.removeListener(_composerChanged);
    ctrl.dispose();
    voiceRecorder.dispose();
    audioPlayer.dispose();
    _videoController?.dispose();
    super.dispose();
  }

  bool get _canEditProfile => true;
  Future<void> _loadProfile() async { try { final r=await http.get(_u('/api/chat/profile',_q)).timeout(const Duration(seconds:10)); if(r.statusCode!=200)return; final b=jsonDecode(r.body); final p=b is Map && b['profile'] is Map?Map<String,dynamic>.from(b['profile']):{}; if(mounted)setState((){_profileRole=(p['role']??'member').toString();_profileDisplayName=(p['display_name']??widget.username).toString();_profileAbout=(p['about']??'').toString();_profileAvatarUrl=(p['avatar_url']??'').toString();}); }catch(_){ } }
  InputDecoration _profileDecoration(String hint, IconData icon)=>InputDecoration(prefixIcon:Icon(icon,color:Colors.white54),hintText:hint,hintStyle:const TextStyle(color:Colors.white38),filled:true,fillColor:const Color(0xFF202C33),border:OutlineInputBorder(borderRadius:BorderRadius.circular(16),borderSide:BorderSide.none));
  String _accountDate(dynamic value, {bool dateOnly = false}) {
    final raw = (value ?? '').toString().trim();
    if (raw.isEmpty) return 'Tidak tersedia';
    final dt = DateTime.tryParse(raw);
    if (dt == null) return raw;
    final local = dt.toLocal();
    String two(int n) => n.toString().padLeft(2, '0');
    final d = '${two(local.day)}/${two(local.month)}/${local.year}';
    if (dateOnly) return d;
    return '$d • ${two(local.hour)}:${two(local.minute)}';
  }

  Widget _profileInfoRow(IconData icon, String label, String value) {
    return Padding(padding: const EdgeInsets.symmetric(vertical: 10), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Container(width: 38, height: 38, decoration: BoxDecoration(color: const Color(0xFF202C33), borderRadius: BorderRadius.circular(12)), child: Icon(icon, color: const Color(0xFF19E6C1), size: 19)),
      const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(label, style: const TextStyle(color: Colors.white54, fontSize: 11)), const SizedBox(height: 3), Text(value, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600))]))
    ]));
  }

  Future<void> _showUserProfile(String username) async {
    if (username.trim().isEmpty) return;
    try {
      final r = await http.get(_u('/api/chat/profile/user', {'session_key': widget.sessionKey, 'username': username})).timeout(const Duration(seconds: 10));
      if (r.statusCode != 200) { _snack('Profil pengguna tidak tersedia'); return; }
      final b = jsonDecode(r.body);
      final p = b is Map && b['profile'] is Map ? Map<String,dynamic>.from(b['profile']) : <String,dynamic>{};
      if (!mounted) return;
      final display = (p['display_name'] ?? username).toString();
      final about = (p['about'] ?? '').toString();
      final role = (p['role'] ?? 'member').toString();
      final avatar = (p['avatar_url'] ?? '').toString();
      final created = _accountDate(p['created_at']);
      final expiryRaw = (p['expired_date'] ?? '').toString();
      final expiry = expiryRaw.isEmpty || expiryRaw.toLowerCase() == 'permanent' ? 'PERMANEN' : _accountDate(expiryRaw, dateOnly: true);
      final expired = DateTime.tryParse(expiryRaw)?.isBefore(DateTime.now()) ?? false;
      showModalBottomSheet<void>(context: context, isScrollControlled: true, backgroundColor: const Color(0xFF111B21), shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(30))), builder: (ctx) => SafeArea(child: Padding(padding: const EdgeInsets.fromLTRB(20,10,20,28), child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(width:42,height:4,decoration:BoxDecoration(color:Colors.white24,borderRadius:BorderRadius.circular(8))), const SizedBox(height:20),
        _avatar(username,radius:56,avatarUrl:avatar), const SizedBox(height:12),
        Text(display,textAlign:TextAlign.center,style:const TextStyle(color:Colors.white,fontSize:23,fontWeight:FontWeight.w900)), const SizedBox(height:3),
        Text('@$username',style:const TextStyle(color:Colors.white54,fontSize:13)), const SizedBox(height:18),
        Container(width:double.infinity,padding:const EdgeInsets.fromLTRB(16,5,16,5),decoration:BoxDecoration(color:const Color(0xFF182229),borderRadius:BorderRadius.circular(18)),child:Column(children:[
          _profileInfoRow(Icons.info_outline_rounded,'Tentang',about.isEmpty?'Belum ada bio.':about), const Divider(color:Colors.white10,height:1),
          _profileInfoRow(Icons.calendar_today_rounded,'Akun dibuat',created), const Divider(color:Colors.white10,height:1),
          _profileInfoRow(expired?Icons.warning_amber_rounded:Icons.event_available_rounded,'Akun berakhir',expiry),
        ])), const SizedBox(height:12),
        Row(children:[const Icon(Icons.verified_user_outlined,color:Color(0xFF00A884),size:16),const SizedBox(width:7),Text('Role: ${role.toUpperCase()}  •  Password disembunyikan',style:const TextStyle(color:Colors.white38,fontSize:11))]),
      ]))));
    } catch (_) { _snack('Gagal memuat profil pengguna'); }
  }

  Future<void> _showProfileEditor() async { if(!_canEditProfile){_snack('Profil dapat diubah dari semua akun');return;} final n=TextEditingController(text:_profileDisplayName.isEmpty?widget.username:_profileDisplayName); final a=TextEditingController(text:_profileAbout); XFile? picked; try{await showModalBottomSheet<void>(context:context,isScrollControlled:true,backgroundColor:const Color(0xFF111B21),shape:const RoundedRectangleBorder(borderRadius:BorderRadius.vertical(top:Radius.circular(28))),builder:(sheet)=>StatefulBuilder(builder:(ctx,setSheet)=>Padding(padding:EdgeInsets.fromLTRB(20,14,20,MediaQuery.of(ctx).viewInsets.bottom+24),child:Column(mainAxisSize:MainAxisSize.min,children:[Container(width:42,height:4,decoration:BoxDecoration(color:Colors.white24,borderRadius:BorderRadius.circular(8))),const SizedBox(height:18),const Align(alignment:Alignment.centerLeft,child:Text('Edit Profil',style:TextStyle(color:Colors.white,fontSize:21,fontWeight:FontWeight.w900))),const SizedBox(height:16),GestureDetector(onTap:()async{final x=await picker.pickImage(source:ImageSource.gallery,imageQuality:88);if(x!=null)setSheet(()=>picked=x);},child:Stack(alignment:Alignment.bottomRight,children:[CircleAvatar(radius:48,backgroundImage:picked!=null?FileImage(File(picked!.path)):(_profileAvatarUrl.isNotEmpty?NetworkImage(_profileAvatarUrl):null) as ImageProvider?,child:picked==null&&_profileAvatarUrl.isEmpty?Text(widget.username.isEmpty?'?':widget.username[0].toUpperCase(),style:const TextStyle(fontSize:34,fontWeight:FontWeight.w800)):null),Container(width:34,height:34,decoration:const BoxDecoration(color:Color(0xFF00A884),shape:BoxShape.circle),child:const Icon(Icons.camera_alt_rounded,color:Colors.white,size:18))])),const SizedBox(height:16),TextField(controller:n,style:const TextStyle(color:Colors.white),decoration:_profileDecoration('Nama tampilan',Icons.person_outline_rounded)),const SizedBox(height:10),TextField(controller:a,maxLength:120,style:const TextStyle(color:Colors.white),decoration:_profileDecoration('Tentang',Icons.info_outline_rounded)),const SizedBox(height:6),SizedBox(width:double.infinity,child:FilledButton.icon(onPressed:()async{final nav=Navigator.of(ctx);try{final req=http.MultipartRequest('POST',_u('/api/chat/profile'));req.fields.addAll({'session_key':widget.sessionKey,'display_name':n.text.trim(),'about':a.text.trim()});if(picked!=null)req.files.add(await http.MultipartFile.fromPath('avatar',picked!.path,filename:picked!.name));final r=await req.send().timeout(const Duration(seconds:60));if(r.statusCode>=200&&r.statusCode<300){await _loadProfile();await _loadUsers();if(mounted)nav.pop();}else{_snack('Profil gagal disimpan');}}catch(_){_snack('Profil gagal disimpan');}},icon:const Icon(Icons.save_rounded),label:const Text('Simpan Profil')))]))));}finally{n.dispose();a.dispose();} }

  Future<void> _loadUsers() async {
    if (mounted) setState(() => loadingUsers = true);
    try {
      final r = await http.get(_u('/api/chat/private/users', _q)).timeout(const Duration(seconds: 10));
      final b = jsonDecode(r.body);
      if (r.statusCode == 200 && b['users'] is List && mounted) {
        setState(() {
          users = List<Map<String, dynamic>>.from(
            (b['users'] as List).map((e) => Map<String, dynamic>.from(e)),
          );
        });
      }
    } catch (_) {
      if (mounted) _snack('Gagal memuat daftar pengguna');
    } finally {
      if (mounted) setState(() => loadingUsers = false);
    }
  }

  void _connect() {
    socket = io.io(
      baseUrl,
      io.OptionBuilder().setTransports(['websocket']).disableAutoConnect().build(),
    );
    socket!.connect();
    socket!.onConnect((_) => socket!.emit('private:auth', {'session_key': widget.sessionKey}));
    socket!.on('private:message', (data) {
      if (!mounted || selected == null || data is! Map || data['message'] is! Map) return;
      final m = Map<String, dynamic>.from(data['message']);
      if (m['from'] == selected || m['to'] == selected) _loadMessages(silent: true);
    });
    socket!.on('private:call', _incomingCall);
    socket!.on('private:call:unavailable', (_) {
      if (mounted) _snack('User sedang offline');
    });
  }

  Future<void> _loadMessages({bool silent = false}) async {
    if (selected == null) return;
    if (!silent && mounted) setState(() => loadingMessages = true);
    try {
      final r = await http.get(
        _u('/api/chat/private/messages', {
          'session_key': widget.sessionKey,
          'with': selected!,
        }),
      ).timeout(const Duration(seconds: 10));
      if (r.statusCode == 200) {
        final b = jsonDecode(r.body);
        if (mounted) {
          setState(() {
            current = List<Map<String, dynamic>>.from(
              (b['messages'] ?? []).map((e) => Map<String, dynamic>.from(e)),
            );
          });
        }
      }
    } catch (_) {
      if (!silent && mounted) _snack('Gagal memuat pesan');
    } finally {
      if (!silent && mounted) setState(() => loadingMessages = false);
    }
  }

  Future<void> _editPrivateMessage(Map<String,dynamic> m) async { if(m['from']?.toString()!=widget.username||(m['media_type']??'text')!='text')return; final c=TextEditingController(text:(m['message']??'').toString()); final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(backgroundColor:const Color(0xFF202C33),title:const Text('Edit pesan',style:TextStyle(color:Colors.white)),content:TextField(controller:c,autofocus:true,maxLines:4,style:const TextStyle(color:Colors.white),decoration:_profileDecoration('Pesan',Icons.edit_rounded)),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Batal')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Simpan'))])); if(ok!=true||c.text.trim().isEmpty){c.dispose();return;} try{final r=await http.post(_u('/api/chat/private/edit'),headers:{'Content-Type':'application/json'},body:jsonEncode({'session_key':widget.sessionKey,'id':m['id'],'message':c.text.trim()})).timeout(const Duration(seconds:15));if(r.statusCode<300)await _loadMessages(silent:true);else _snack('Pesan gagal diedit');}catch(_){_snack('Pesan gagal diedit');}finally{c.dispose();} }
  Future<void> _deletePrivateMessage(Map<String,dynamic> m) async { final yes=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(backgroundColor:const Color(0xFF202C33),title:const Text('Hapus pesan?',style:TextStyle(color:Colors.white)),content:const Text('Pesan akan dihapus dari chat.',style:TextStyle(color:Colors.white70)),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Batal')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Hapus'))]));if(yes!=true||m['id']==null)return;try{final r=await http.post(_u('/api/chat/private/delete'),headers:{'Content-Type':'application/json'},body:jsonEncode({'session_key':widget.sessionKey,'id':m['id']})).timeout(const Duration(seconds:15));if(r.statusCode<300)await _loadMessages(silent:true);else _snack('Pesan gagal dihapus');}catch(_){_snack('Pesan gagal dihapus');}}
  Future<void> _copyPrivateMessage(Map<String,dynamic> m) async {
    final text=(m['message']??m['file_name']??'').toString();
    if(text.isEmpty)return;
    await Clipboard.setData(ClipboardData(text:text));
    _snack('Pesan disalin');
  }
  Future<void> _reactPrivate(Map<String,dynamic> m, String emoji) async {
    try {
      final r=await http.post(_u('/api/chat/private/reaction'),headers:{'Content-Type':'application/json'},body:jsonEncode({'session_key':widget.sessionKey,'id':m['id'],'reaction':emoji})).timeout(const Duration(seconds:10));
      if(r.statusCode<300) await _loadMessages(silent:true); else _snack('Reaction gagal');
    } catch(_){_snack('Reaction gagal');}
  }
  Future<void> _forwardPrivate(Map<String,dynamic> m) async {
    if(users.isEmpty)return;
    final target=await showModalBottomSheet<String>(context:context,backgroundColor:const Color(0xFF111B21),builder:(ctx)=>SafeArea(child:ListView(shrinkWrap:true,children:[const Padding(padding:EdgeInsets.all(18),child:Text('Teruskan ke...',style:TextStyle(color:Colors.white,fontSize:19,fontWeight:FontWeight.w900))),...users.where((u)=>u['username']?.toString()!=widget.username).map((u)=>ListTile(leading:_avatar((u['username']??'').toString(),radius:22,avatarUrl:(u['avatar_url']??'').toString()),title:Text((u['display_name']??u['username']).toString(),style:const TextStyle(color:Colors.white)),subtitle:Text('@${u['username']}',style:const TextStyle(color:Colors.white38)),onTap:()=>Navigator.pop(ctx,u['username'].toString())))])));
    if(target==null)return;
    try{final r=await http.post(_u('/api/chat/private/forward'),headers:{'Content-Type':'application/json'},body:jsonEncode({'session_key':widget.sessionKey,'id':m['id'],'to':target})).timeout(const Duration(seconds:15));if(r.statusCode<300)_snack('Pesan diteruskan');else _snack('Gagal meneruskan pesan');}catch(_){_snack('Gagal meneruskan pesan');}
  }
  void _startReply(Map<String,dynamic> m){setState(()=>_replyingTo=m);}

  void _showPrivateMessageActions(Map<String,dynamic> m) {
    final mine = m['from']?.toString() == widget.username;
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF111B21),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) {
        final reactions = <String>['❤️', '😂', '👍', '😮', '😢', '🔥'];
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: reactions.map<Widget>((e) {
                    return IconButton(
                      onPressed: () { Navigator.pop(ctx); _reactPrivate(m, e); },
                      icon: Text(e, style: const TextStyle(fontSize: 25)),
                    );
                  }).toList(),
                ),
              ),
              ListTile(
                leading: const Icon(Icons.reply_rounded, color: Colors.white),
                title: const Text('Balas', style: TextStyle(color: Colors.white)),
                onTap: () { Navigator.pop(ctx); _startReply(m); },
              ),
              ListTile(
                leading: const Icon(Icons.copy_rounded, color: Colors.white),
                title: const Text('Salin', style: TextStyle(color: Colors.white)),
                onTap: () { Navigator.pop(ctx); _copyPrivateMessage(m); },
              ),
              ListTile(
                leading: const Icon(Icons.forward_rounded, color: Colors.white),
                title: const Text('Teruskan', style: TextStyle(color: Colors.white)),
                onTap: () { Navigator.pop(ctx); _forwardPrivate(m); },
              ),
              if (mine && (m['media_type'] ?? 'text') == 'text')
                ListTile(
                  leading: const Icon(Icons.edit_rounded, color: Colors.white),
                  title: const Text('Edit pesan', style: TextStyle(color: Colors.white)),
                  onTap: () { Navigator.pop(ctx); _editPrivateMessage(m); },
                ),
              if (mine)
                ListTile(
                  leading: const Icon(Icons.delete_outline_rounded, color: Colors.redAccent),
                  title: const Text('Hapus pesan', style: TextStyle(color: Colors.redAccent)),
                  onTap: () { Navigator.pop(ctx); _deletePrivateMessage(m); },
                ),
              const SizedBox(height: 8),
            ],
          ),
        );
      },
    );
  }

  Future<void> _sendText(String text) async {
    if (selected == null || text.trim().isEmpty || sending) return;
    setState(() => sending = true);
    try {
      final r = await http.post(
        _u('/api/chat/private/send'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'session_key': widget.sessionKey,
          'to': selected,
          'message': text.trim(),
          if (_replyingTo != null) 'reply_to': _replyingTo!['id'],
        }),
      ).timeout(const Duration(seconds: 15));
      if (r.statusCode < 300) {
        ctrl.clear();
        if (mounted) setState(() => _replyingTo = null);
        await _loadMessages(silent: true);
      } else {
        _snack('Pesan gagal dikirim');
      }
    } catch (_) {
      _snack('Tidak bisa mengirim pesan');
    } finally {
      if (mounted) setState(() => sending = false);
    }
  }

  Future<void> _sendMedia(String path, String type, String name) async {
    if (selected == null || sending) return;
    setState(() => sending = true);
    try {
      final req = http.MultipartRequest('POST', _u('/api/chat/private/upload'));
      req.fields.addAll({
        'session_key': widget.sessionKey,
        'to': selected!,
        'media_type': type,
      });
      req.files.add(await http.MultipartFile.fromPath('media', path, filename: name));
      final r = await req.send().timeout(const Duration(seconds: 60));
      if (r.statusCode < 300) {
        await _loadMessages(silent: true);
      } else {
        _snack('Media gagal dikirim');
      }
    } catch (_) {
      _snack('Gagal mengirim media');
    } finally {
      if (mounted) setState(() => sending = false);
    }
  }

  Future<void> _toggleVoice() async {
    if (sending) return;
    try {
      if (isRecordingVoice) {
        final path = await voiceRecorder.stop();
        if (mounted) setState(() => isRecordingVoice = false);
        if (path != null && path.isNotEmpty) {
          await _sendMedia(path, 'audio', 'VN-${DateTime.now().millisecondsSinceEpoch}.wav');
        }
        return;
      }
      if (!await voiceRecorder.hasPermission()) {
        _snack('Izin mikrofon ditolak');
        return;
      }
      final dir = await getTemporaryDirectory();
      final path = '${dir.path}/private-vn-${DateTime.now().millisecondsSinceEpoch}.m4a';
      await voiceRecorder.start(
        const RecordConfig(encoder: AudioEncoder.wav, sampleRate: 44100, numChannels: 1),
        path: path,
      );
      if (mounted) setState(() => isRecordingVoice = true);
    } catch (e) {
      if (mounted) setState(() => isRecordingVoice = false);
      _snack('VN gagal direkam: $e');
    }
  }

  Future<void> _pickPhoto() async {
    final x = await picker.pickImage(source: ImageSource.gallery, imageQuality: 88);
    if (x != null) await _sendMedia(x.path, 'image', x.name);
  }

  Future<void> _pickVideo() async {
    final x = await picker.pickVideo(source: ImageSource.gallery);
    if (x != null) await _sendMedia(x.path, 'video', x.name);
  }

  Future<void> _pickFile() async {
    final x = await FilePicker.platform.pickFiles(withData: false);
    if (x != null && x.files.single.path != null) {
      await _sendMedia(x.files.single.path!, 'file', x.files.single.name);
    }
  }

  void _showAttachments() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF101B2B),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
      ),
      builder: (sheet) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 12, 18, 22),
          child: Wrap(
            spacing: 14,
            runSpacing: 14,
            children: [
              const Center(
                child: SizedBox(
                  width: 42,
                  child: Divider(color: Colors.white24, thickness: 3),
                ),
              ),
              _attachTile(Icons.photo_rounded, 'Foto', const Color(0xFF25D366), () {
                Navigator.pop(sheet);
                _pickPhoto();
              }),
              _attachTile(Icons.videocam_rounded, 'Video', const Color(0xFF3B82F6), () {
                Navigator.pop(sheet);
                _pickVideo();
              }),
              _attachTile(Icons.mic_rounded, 'VN', const Color(0xFFEF4444), () {
                Navigator.pop(sheet);
                _toggleVoice();
              }),
              _attachTile(Icons.insert_drive_file_rounded, 'File', const Color(0xFFA855F7), () {
                Navigator.pop(sheet);
                _pickFile();
              }),
            ],
          ),
        ),
      ),
    );
  }

  Widget _attachTile(IconData icon, String title, Color color, VoidCallback onTap) {
    return SizedBox(
      width: 92,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Padding(
          padding: const EdgeInsets.all(8),
          child: Column(
            children: [
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  color: color.withOpacity(.14),
                  shape: BoxShape.circle,
                  border: Border.all(color: color.withOpacity(.28)),
                ),
                child: Icon(icon, color: color),
              ),
              const SizedBox(height: 7),
              Text(title, style: const TextStyle(color: Colors.white70)),
            ],
          ),
        ),
      ),
    );
  }

  void _incomingCall(dynamic data) {
    if (!mounted || data is! Map) return;
    final from = (data['from'] ?? '').toString();
    final id = (data['callId'] ?? '').toString();
    if (from.isEmpty || id.isEmpty) return;
    final video = data['video'] == true;
    final offer = data['offer'] is Map ? Map<String, dynamic>.from(data['offer']) : null;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF101B2B),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: Row(
          children: [
            _avatar(from, radius: 23),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                video ? 'Video call masuk' : 'Panggilan masuk',
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800),
              ),
            ),
          ],
        ),
        content: Text('$from ingin menghubungi kamu.', style: const TextStyle(color: Colors.white70)),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              socket?.emit('private:call:end', {'to': from, 'callId': id});
            },
            child: const Text('Tolak'),
          ),
          FilledButton.icon(
            onPressed: () {
              Navigator.pop(ctx);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => PrivateCallPage(
                    me: widget.username,
                    peer: from,
                    sessionKey: widget.sessionKey,
                    socket: socket!,
                    callId: id,
                    video: video,
                    caller: false,
                    offer: offer,
                  ),
                ),
              );
            },
            icon: Icon(video ? Icons.videocam_rounded : Icons.call_rounded),
            label: const Text('Terima'),
          ),
        ],
      ),
    );
  }

  void _showCallMenu() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF101B2B),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
      ),
      builder: (c) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(width: 42, child: Divider(color: Colors.white24, thickness: 3)),
              ListTile(
                leading: const CircleAvatar(
                  backgroundColor: Color(0x1922C55E),
                  child: Icon(Icons.call_rounded, color: Color(0xFF4ADE80)),
                ),
                title: const Text('Panggilan suara', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                subtitle: const Text('Ngobrol dengan suara', style: TextStyle(color: Colors.white54)),
                onTap: () {
                  Navigator.pop(c);
                  _startCall(false);
                },
              ),
              ListTile(
                leading: const CircleAvatar(
                  backgroundColor: Color(0x193B82F6),
                  child: Icon(Icons.videocam_rounded, color: Color(0xFF60A5FA)),
                ),
                title: const Text('Video call', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                subtitle: const Text('Video + suara dua arah', style: TextStyle(color: Colors.white54)),
                onTap: () {
                  Navigator.pop(c);
                  _startCall(true);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _startCall(bool video) {
    if (selected == null || socket == null) return;
    final id = '${DateTime.now().microsecondsSinceEpoch}-${widget.username}';
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => PrivateCallPage(
          me: widget.username,
          peer: selected!,
          sessionKey: widget.sessionKey,
          socket: socket!,
          callId: id,
          video: video,
          caller: true,
        ),
      ),
    );
  }

  void _openUser(String username) {
    setState(() => selected = username);
    _loadMessages();
  }

  void _backToUsers() {
    FocusScope.of(context).unfocus();
    setState(() {
      selected = null;
      current = [];
    });
    _loadUsers();
  }

  void _snack(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(text), behavior: SnackBarBehavior.floating));
  }

  String _initial(String name) => name.trim().isEmpty ? '?' : name.trim()[0].toUpperCase();

  Widget _avatar(String name, {double radius = 25, String avatarUrl = ''}) {
    return CircleAvatar(
      radius: radius,
      backgroundColor: const Color(0xFF17325B),
      backgroundImage: avatarUrl.isNotEmpty ? NetworkImage(avatarUrl) : null,
      child: avatarUrl.isEmpty
          ? Text(_initial(name), style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: radius * .72))
          : null,
    );
  }

  bool _online(String name) {
    final hit = users.where((u) => u['username']?.toString() == name).toList();
    return hit.isNotEmpty && hit.first['online'] == true;
  }

  @override
  Widget build(BuildContext context) {
    if (selected == null) return _buildUsers();
    return _buildConversation();
  }

  Widget _buildUsers() {
    final query = search.text.trim().toLowerCase();
    final filtered = users.where((u) {
      final name = (u['username'] ?? '').toString();
      final display = (u['display_name'] ?? '').toString();
      return name != widget.username &&
          (name.toLowerCase().contains(query) || display.toLowerCase().contains(query));
    }).toList();

    return Scaffold(
      backgroundColor: const Color(0xFF05080F),
      appBar: AppBar(
        elevation: 0,
        backgroundColor: const Color(0xFF101826),
        foregroundColor: Colors.white,
        titleSpacing: 18,
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('💬 CHAT PRIVAT', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 21)),
            SizedBox(height: 2),
            Text('Pesan langsung antar pengguna', style: TextStyle(fontSize: 11, color: Colors.white54)),
          ],
        ),
        actions: [
          IconButton(onPressed: _showProfileEditor, tooltip: 'Profil', icon: const Icon(Icons.account_circle_outlined)),
          IconButton(onPressed: _loadUsers, icon: const Icon(Icons.refresh_rounded)),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 10),
            child: TextField(
              controller: search,
              onChanged: (_) => setState(() {}),
              style: const TextStyle(color: Colors.white),
              textInputAction: TextInputAction.search,
              decoration: InputDecoration(
                hintText: 'Cari nama atau username...',
                hintStyle: const TextStyle(color: Colors.white38),
                prefixIcon: const Icon(Icons.search_rounded, color: Colors.white54),
                suffixIcon: search.text.isEmpty
                    ? null
                    : IconButton(
                        onPressed: () {
                          search.clear();
                          setState(() {});
                        },
                        icon: const Icon(Icons.close_rounded, color: Colors.white54),
                      ),
                filled: true,
                fillColor: const Color(0xFF0D1929),
                contentPadding: const EdgeInsets.symmetric(vertical: 16),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                  borderSide: BorderSide(color: Colors.white.withOpacity(.05)),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                  borderSide: BorderSide(color: Colors.white.withOpacity(.05)),
                ),
              ),
            ),
          ),
          Expanded(
            child: loadingUsers
                ? const Center(child: CircularProgressIndicator())
                : RefreshIndicator(
                    onRefresh: _loadUsers,
                    child: filtered.isEmpty
                        ? ListView(
                            physics: const AlwaysScrollableScrollPhysics(),
                            children: const [SizedBox(height: 110), _EmptyUsers()],
                          )
                        : ListView.separated(
                            physics: const AlwaysScrollableScrollPhysics(),
                            padding: const EdgeInsets.fromLTRB(12, 4, 12, 24),
                            itemCount: filtered.length,
                            separatorBuilder: (_, __) => const SizedBox(height: 4),
                            itemBuilder: (_, i) {
                              final u = filtered[i];
                              final name = (u['username'] ?? '?').toString();
                              final online = u['online'] == true;
                              return _userTile(name, online, (u['avatar_url'] ?? '').toString(), (u['display_name'] ?? name).toString(), (u['about'] ?? '').toString());
                            },
                          ),
                  ),
          ),
        ],
      ),
    );
  }

  Widget _userTile(String name, bool online, [String avatarUrl = '', String displayName = '', String about = '']) {
    return Material(
      color: const Color(0xFF080D16),
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        onTap: () => _openUser(name),
        borderRadius: BorderRadius.circular(20),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          child: Row(
            children: [
              Stack(
                clipBehavior: Clip.none,
                children: [
                  _avatar(name, radius: 27, avatarUrl: avatarUrl),
                  Positioned(
                    right: -1,
                    bottom: -1,
                    child: Container(
                      width: 15,
                      height: 15,
                      decoration: BoxDecoration(
                        color: online ? const Color(0xFF25D366) : const Color(0xFF64748B),
                        shape: BoxShape.circle,
                        border: Border.all(color: const Color(0xFF080D16), width: 3),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(displayName.isEmpty ? name : displayName, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16)),
                    const SizedBox(height: 3),
                    Text(about.isNotEmpty ? about : (online ? 'Online sekarang' : 'Pengguna terdaftar'), maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: online ? const Color(0xFF25D366) : Colors.white38, fontSize: 12)),
                  ],
                ),
              ),
              IconButton(onPressed: () => _showUserProfile(name), tooltip: 'Lihat profil', icon: const Icon(Icons.info_outline_rounded, color: Colors.white54)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildConversation() {
    final name = selected!;
    final user = users.firstWhere((u) => u['username']?.toString() == name, orElse: () => <String,dynamic>{});
    final displayName = (user['display_name'] ?? name).toString();
    final about = (user['about'] ?? '').toString();
    return Scaffold(
      backgroundColor: const Color(0xFF080D13),
      appBar: AppBar(
        elevation: 0,
        backgroundColor: const Color(0xFF101820),
        foregroundColor: Colors.white,
        leadingWidth: 48,
        leading: IconButton(onPressed: _backToUsers, icon: const Icon(Icons.arrow_back_rounded)),
        titleSpacing: 0,
        title: GestureDetector(
          onTap: () => _showUserProfile(name),
          child: Row(
          children: [
            Stack(
              children: [
                _avatar(name, radius: 20, avatarUrl: (users.firstWhere((u) => u['username']?.toString() == name, orElse: () => const <String,dynamic>{})['avatar_url'] ?? '').toString()),
                if (_online(name))
                  Positioned(
                    right: -1,
                    bottom: -1,
                    child: Container(
                      width: 11,
                      height: 11,
                      decoration: BoxDecoration(
                        color: const Color(0xFF19E6C1),
                        shape: BoxShape.circle,
                        border: Border.all(color: const Color(0xFF202C33), width: 2),
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(displayName, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
                  Text(_online(name) ? 'Online' : (about.isNotEmpty ? about : 'Terdaftar'), maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11, color: _online(name) ? const Color(0xFF25D366) : Colors.white54)),
                ],
              ),
            ),
          ],
          ),
        ),
        actions: [
          IconButton(onPressed: selected == null ? null : () => _startCall(false), tooltip: 'Panggilan suara', icon: const Icon(Icons.call_rounded, color: Color(0xFF9B6CFF))),
          IconButton(onPressed: selected == null ? null : () => _startCall(true), tooltip: 'Video call', icon: const Icon(Icons.videocam_rounded, color: Color(0xFF9B6CFF))),
          IconButton(onPressed: () => _showUserProfile(name), tooltip: 'Info kontak', icon: const Icon(Icons.more_vert_rounded)),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: Stack(
              children: [
                if (current.isEmpty && !loadingMessages)
                  const _EmptyConversation()
                else
                  ListView.builder(
                    reverse: true,
                    padding: const EdgeInsets.fromLTRB(10, 12, 10, 10),
                    itemCount: current.length,
                    itemBuilder: (context, i) {
                      final m = current[current.length - 1 - i];
                      return _messageBubble(m);
                    },
                  ),
                if (loadingMessages)
                  const Positioned(
                    top: 10,
                    left: 0,
                    right: 0,
                    child: Center(child: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))),
                  ),
              ],
            ),
          ),
          _composer(),
        ],
      ),
    );
  }

  Widget _composer() {
    return SafeArea(
      top: false,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (_replyingTo != null) Container(width: double.infinity, color: const Color(0xFF182229), padding: const EdgeInsets.fromLTRB(14,8,8,8), child: Row(children:[const Icon(Icons.reply_rounded,color:Color(0xFF00A884)),const SizedBox(width:8),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Membalas pesan',style:TextStyle(color:Color(0xFF00A884),fontWeight:FontWeight.w800,fontSize:11)),Text((_replyingTo!['message']??_replyingTo!['file_name']??'Media').toString(),maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(color:Colors.white70,fontSize:12))])),IconButton(onPressed:(){setState((){_replyingTo=null;});},icon:const Icon(Icons.close_rounded,color:Colors.white54,size:19))])),
          Container(
        padding: const EdgeInsets.fromLTRB(9, 7, 9, 8),
        decoration: BoxDecoration(
          color: const Color(0xFF0B111C),
          border: Border(top: BorderSide(color: Colors.white.withOpacity(.05))),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            IconButton(
              onPressed: sending ? null : _showAttachments,
              icon: const Icon(Icons.add_circle_outline_rounded, color: Colors.white60),
            ),
            Expanded(
              child: Container(
                constraints: const BoxConstraints(minHeight: 46, maxHeight: 120),
                decoration: BoxDecoration(
                  color: const Color(0xFF111A28),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: Colors.white.withOpacity(.045)),
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(.15), blurRadius: 7, offset: const Offset(0, 2))],
                ),
                child: TextField(
                  controller: ctrl,
                  minLines: 1,
                  maxLines: 5,
                  textCapitalization: TextCapitalization.sentences,
                  style: const TextStyle(color: Colors.white, fontSize: 15),
                  decoration: InputDecoration(
                    hintText: isRecordingVoice ? 'Merekam VN… tekan untuk berhenti' : 'Tulis pesan...',
                    hintStyle: TextStyle(color: Colors.white38),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(horizontal: 17, vertical: 12),
                  ),
                  onSubmitted: (_) {
                    final v = ctrl.text;
                    _sendText(v);
                  },
                ),
              ),
            ),
            const SizedBox(width: 7),
            AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: const Color(0xFF6D35D9),
                shape: BoxShape.circle,
              ),
              child: IconButton(
                onPressed: sending ? null : (isComposing ? () => _sendText(ctrl.text) : _toggleVoice),
                icon: sending
                    ? const SizedBox(width: 19, height: 19, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : Icon(isComposing ? Icons.send_rounded : (isRecordingVoice ? Icons.stop_rounded : Icons.mic_none_rounded), color: Colors.white),
              ),
            ),
          ],
        ),
      ),
        ],
      ),
    );
  }

  Widget _messageBubble(Map<String, dynamic> m) {
    final mine = m['from'] == widget.username;
    final type = m['media_type']?.toString();
    final url = m['media_url']?.toString();
    final body = (m['message'] ?? '').toString();
    final time = _formatTime(m);
    return GestureDetector(
      onLongPress: () => _showPrivateMessageActions(m),
      child: Align(
        alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
        child: Container(
          margin: EdgeInsets.only(left: mine ? 54 : 4, right: mine ? 4 : 54, bottom: 7),
          child: Container(
            padding: const EdgeInsets.fromLTRB(13, 10, 10, 7),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: mine ? const [Color(0xFF6D35D9), Color(0xFF4320A5)] : const [Color(0xFF17202B), Color(0xFF111820)],
                begin: Alignment.topLeft, end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.only(
                topLeft: const Radius.circular(19), topRight: const Radius.circular(19),
                bottomLeft: Radius.circular(mine ? 19 : 5), bottomRight: Radius.circular(mine ? 5 : 19),
              ),
              border: Border.all(color: Colors.white.withOpacity(.045)),
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(.15), blurRadius: 7, offset: const Offset(0, 2))],
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children:[
              if(m['forwarded']==true) const Padding(padding:EdgeInsets.only(bottom:4),child:Text('↗ Diteruskan',style:TextStyle(color:Colors.white54,fontSize:10,fontWeight:FontWeight.w700))),
              if(m['reply_preview'] is Map) Container(width:double.infinity,margin:const EdgeInsets.only(bottom:7),padding:const EdgeInsets.all(8),decoration:BoxDecoration(color:Colors.black.withOpacity(.16),borderRadius:BorderRadius.circular(9)),child:Text('${(m['reply_preview']['from']??'')}: ${(m['reply_preview']['message']??'').toString()}',maxLines:2,overflow:TextOverflow.ellipsis,style:const TextStyle(color:Colors.white70,fontSize:11))),
              type != null && type != 'text' ? _mediaContent(type, url, (m['file_name'] ?? 'Media').toString(), mine, time) : _textContent(body, time, m['edited'] == true),
              if (m['reactions'] is Map && (m['reactions'] as Map).isNotEmpty) Padding(
                padding: const EdgeInsets.only(top: 5),
                child: Wrap(
                  spacing: 3,
                  children: (m['reactions'] as Map).values.map<Widget>((e) {
                    return Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(color: Colors.black.withOpacity(.18), borderRadius: BorderRadius.circular(10)),
                      child: Text(e.toString(), style: const TextStyle(fontSize: 12)),
                    );
                  }).toList(),
                ),
              ),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _textContent(String text, String time, bool edited) {
    return Wrap(
      alignment: WrapAlignment.end,
      crossAxisAlignment: WrapCrossAlignment.end,
      spacing: 8,
      runSpacing: 2,
      children: [
        if (text.isNotEmpty)
          Row(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.end, children: [Flexible(child: Text(text, style: const TextStyle(color: Colors.white, fontSize: 15, height: 1.30))), if (edited) const Padding(padding: EdgeInsets.only(left: 6), child: Text('(diedit)', style: TextStyle(color: Colors.white54, fontSize: 10))) ]),
        Text(time, style: const TextStyle(color: Colors.white54, fontSize: 10)),
      ],
    );
  }

  Widget _mediaContent(String type, String? url, String fileName, bool mine, String time) {
    if (url == null || url.isEmpty) return _mediaFallback(Icons.broken_image_rounded, fileName);
    if (type == 'image') {
      return ClipRRect(
        borderRadius: BorderRadius.circular(13),
        child: GestureDetector(
          onTap: () => _openUrl(url),
          child: Image.network(url, width: 250, height: 190, fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => _mediaFallback(Icons.broken_image_rounded, fileName),
            loadingBuilder: (context, child, progress) => progress == null ? child : const SizedBox(width: 250, height: 150, child: Center(child: CircularProgressIndicator())),
          ),
        ),
      );
    }
    if (type == 'audio') return _audioBubble(url, fileName);
    if (type == 'video') return _videoBubble(url, fileName);
    return _mediaFallback(Icons.insert_drive_file_rounded, fileName);
  }

  Widget _audioBubble(String url, String name) => InkWell(
    onTap: () => _playAudio(url),
    borderRadius: BorderRadius.circular(18),
    child: Container(width: 250, padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10), decoration: BoxDecoration(color: Colors.black.withOpacity(.16), borderRadius: BorderRadius.circular(18)), child: Row(children: [
      CircleAvatar(radius: 21, backgroundColor: Colors.white12, child: Icon(playingAudioUrl == url ? Icons.pause_rounded : Icons.play_arrow_rounded, color: Colors.white)),
      const SizedBox(width: 10), Expanded(child: Text('🎤 VN • $name', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600))),
    ])),
  );

  Future<void> _playAudio(String url) async {
    try {
      if (playingAudioUrl == url) { await audioPlayer.pause(); if (mounted) setState(() => playingAudioUrl = null); return; }
      await audioPlayer.stop();
      await audioPlayer.play(UrlSource(url), volume: 1.0);
      if (mounted) setState(() => playingAudioUrl = url);
      audioPlayer.onPlayerComplete.first.then((_) { if (mounted && playingAudioUrl == url) setState(() => playingAudioUrl = null); });
    } catch (_) { if (mounted) _snack('VN tidak bisa diputar'); }
  }

  Widget _videoBubble(String url, String name) {
    final active = _playingVideoUrl == url && _videoController != null && _videoController!.value.isInitialized;
    if (!active) return InkWell(onTap: () => _playVideo(url), borderRadius: BorderRadius.circular(14), child: Container(width: 250, height: 145, decoration: BoxDecoration(color: Colors.black26, borderRadius: BorderRadius.circular(14)), child: Stack(alignment: Alignment.center, children: [const Icon(Icons.play_circle_fill_rounded, color: Colors.white, size: 58), Positioned(bottom: 8, left: 10, right: 10, child: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white70)))])));
    return ClipRRect(borderRadius: BorderRadius.circular(14), child: AspectRatio(aspectRatio: _videoController!.value.aspectRatio, child: VideoPlayer(_videoController!)));
  }

  Future<void> _playVideo(String url) async {
    try {
      await _videoController?.dispose();
      final c = VideoPlayerController.networkUrl(Uri.parse(url));
      await c.initialize();
      if (!mounted) { await c.dispose(); return; }
      setState(() { _videoController = c; _playingVideoUrl = url; });
      await c.play();
      c.addListener(() { if (mounted && c.value.isInitialized && c.value.position >= c.value.duration && _playingVideoUrl == url) setState(() { _playingVideoUrl = null; }); });
    } catch (_) { if (mounted) _snack('Video tidak bisa diputar'); }
  }

  Widget _mediaFallback(IconData icon, String fileName) {
    return Container(
      width: 250,
      height: 112,
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(.14),
        borderRadius: BorderRadius.circular(13),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: Colors.white70, size: 42),
          const SizedBox(height: 6),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Text(fileName, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white70, fontSize: 12)),
          ),
        ],
      ),
    );
  }

  Future<void> _openUrl(String value) async {
    try {
      final ok = await launchUrl(Uri.parse(value), mode: LaunchMode.externalApplication);
      if (!ok) _snack('Media tidak bisa dibuka');
    } catch (_) {
      _snack('Link media tidak valid');
    }
  }

  String _formatTime(Map<String, dynamic> m) {
    final raw = m['created_at'] ?? m['timestamp'] ?? m['createdAt'] ?? m['time'];
    if (raw == null) return '';
    try {
      DateTime? dt;
      if (raw is num) {
        final n = raw.toInt();
        dt = DateTime.fromMillisecondsSinceEpoch(n < 100000000000 ? n * 1000 : n).toLocal();
      } else {
        dt = DateTime.tryParse(raw.toString())?.toLocal();
      }
      return dt == null ? '' : DateFormat('HH:mm').format(dt);
    } catch (_) {
      return '';
    }
  }
}

class _EmptyUsers extends StatelessWidget {
  const _EmptyUsers();
  @override
  Widget build(BuildContext context) => Column(
        children: [
          Icon(Icons.person_search_rounded, size: 58, color: Colors.white.withOpacity(.18)),
          const SizedBox(height: 12),
          const Text('Belum ada pengguna', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w800)),
          const SizedBox(height: 5),
          const Text('Tarik ke bawah untuk memuat ulang', style: TextStyle(color: Colors.white38, fontSize: 12)),
        ],
      );
}

class _EmptyConversation extends StatelessWidget {
  const _EmptyConversation();
  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(30),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 72,
                height: 72,
                decoration: const BoxDecoration(color: Color(0xFF0E1E35), shape: BoxShape.circle),
                child: const Icon(Icons.forum_rounded, color: Colors.white30, size: 34),
              ),
              const SizedBox(height: 16),
              const Text('Belum ada pesan', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w800, fontSize: 17)),
              const SizedBox(height: 6),
              const Text('Mulai percakapan dengan mengirim pesan.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white38, height: 1.4)),
            ],
          ),
        ),
      );
}
