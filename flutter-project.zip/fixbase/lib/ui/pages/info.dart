import 'package:flutter/material.dart';

class Info extends StatelessWidget {
  final int id;

  const Info({super.key, required this.id});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Info')),
      body: Center(child: Text('Info ID: $id')),
    );
  }
}
