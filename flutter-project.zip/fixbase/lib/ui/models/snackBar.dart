import 'package:flutter/material.dart';

void floatingSnackBar(String message, {Color? color}) {
  // no-op stub — called via static key in AnimeStream widget
}
