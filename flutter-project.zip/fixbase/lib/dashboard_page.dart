import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'dart:math' show Random;
import 'package:video_player/video_player.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:network_info_plus/network_info_plus.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';

import 'api_config.dart';
import 'nik_check.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart' as home;
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'al_quran.dart';
import 'anime_home.dart';
import 'chat_room_page.dart';
import 'notification_page.dart';
import 'bug_group_page.dart';
import 'custom_payload.dart';
import 'story_page.dart';
import 'ular.dart';
import 'savings_page.dart';

// ─── COLORS ────────────────────────────────────────────────────────────────────
const Color kBg      = Color(0xFF09090B);
const Color kCard    = Color(0xFF18181B);
const Color kCardAlt = Color(0xFF1C1C1F);
const Color kBorder  = Color(0xFF27272A);
const Color kBlue    = Color(0xFF1565C0);
const Color kBlueMid = Color(0xFF1976D2);
const Color kBlueLight = Color(0xFF42A5F5);
const Color kPink    = Color(0xFFE91E8C);
const Color kPurple  = Color(0xFF7C4DFF);
const Color kYellow  = Color(0xFFFFD600);
const Color kWhite   = Colors.white;
const Color kWhite54 = Colors.white54;
const Color kWhite24 = Colors.white24;
const Color kNeonGreen = Color(0xFF20F08A);
const Color kNeonGreenSoft = Color(0xFF0FAF6E);
const Color kNavyPanel = Color(0xFF0D1325);
const Color kNeonPurple = Color(0xFF9B5CFF);
const Color kNeonGold = Color(0xFFFFC857);
const Color kNeonCyan = Color(0xFF00E5FF);
const Color kNeonRed = Color(0xFFFF1744);

// ─── PRAYER TIME SERVICE ───────────────────────────────────────────────────────
class PrayerTimeService {
  static Future<Map<String, dynamic>> fetchPrayerTimes(String city) async {
    final now = DateTime.now();
    final uri = Uri.https('api.aladhan.com', '/v1/timingsByCity', {
      'city': city, 'country': 'ID', 'method': '11',
      'day': '${now.day}', 'month': '${now.month}', 'year': '${now.year}',
    });
    try {
      final res = await http.get(uri).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return {};
  }
}

// ─── ROLE HELPERS ─────────────────────────────────────────────────────────────
Color _roleColor(String role) {
  switch (role.toLowerCase()) {
    case 'owner':    return const Color(0xFFF59E0B);
    case 'admin':    return const Color(0xFFEF4444);
    case 'reseller': return kBlue;
    case 'vip':      return kPurple;
    default:         return kBlue;
  }
}

IconData _roleIcon(String role) {
  switch (role.toLowerCase()) {
    case 'owner':    return Icons.workspace_premium_rounded;
    case 'admin':    return Icons.admin_panel_settings_rounded;
    case 'reseller': return Icons.storefront_rounded;
    case 'vip':      return Icons.star_rounded;
    default:         return Icons.person_rounded;
  }
}

// ─── ANIMATED DOT ──────────────────────────────────────────────────────────────
class _AnimatedDot extends StatefulWidget {
  final Color color;
  final double size;
  const _AnimatedDot({required this.color, this.size = 6});
  @override
  State<_AnimatedDot> createState() => _AnimatedDotState();
}

class _AnimatedDotState extends State<_AnimatedDot>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;
  late Animation<double> _a;
  @override
  void initState() {
    super.initState();
    _c = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900))
      ..repeat(reverse: true);
    _a = Tween<double>(begin: 0.3, end: 1.0)
        .animate(CurvedAnimation(parent: _c, curve: Curves.easeInOut));
  }
  @override
  void dispose() { _c.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => FadeTransition(
    opacity: _a,
    child: Container(
      width: widget.size, height: widget.size,
      decoration: BoxDecoration(
        shape: BoxShape.circle, color: widget.color,
        boxShadow: [BoxShadow(color: widget.color.withOpacity(0.6), blurRadius: 6, spreadRadius: 1)],
      ),
    ),
  );
}

// ─── HEXAGON PATTERN PAINTER ──────────────────────────────────────────────────
class _HexagonPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = kBlue.withOpacity(0.12)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.8;

    const double w = 72.0;
    const double h = 52.0;

    for (double row = -1; row * h < size.height + h * 2; row++) {
      for (double col = -1; col * w < size.width + w * 2; col++) {
        final double offsetX = (row.toInt() % 2 == 0) ? 0 : w * 0.5;
        final cx = col * w + offsetX;
        final cy = row * h;
        _drawDiamond(canvas, paint, Offset(cx, cy), w * 0.5, h * 0.5);
      }
    }
  }

  void _drawDiamond(Canvas canvas, Paint paint, Offset center, double hw, double hh) {
    final path = Path()
      ..moveTo(center.dx, center.dy - hh)
      ..lineTo(center.dx + hw, center.dy)
      ..lineTo(center.dx, center.dy + hh)
      ..lineTo(center.dx - hw, center.dy)
      ..close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter _) => false;
}

// ─── GRID PATTERN PAINTER ─────────────────────────────────────────────────────
class _GridPatternPainter extends CustomPainter {
  final Color gridColor;
  final Color lineColor;
  final double spacing;
  const _GridPatternPainter({required this.gridColor, required this.lineColor, required this.spacing});
  @override
  void paint(Canvas canvas, Size size) {
    final paintGrid = Paint()..color = gridColor..strokeWidth = 0.8..style = PaintingStyle.stroke;
    final paintLines = Paint()..color = lineColor..strokeWidth = 0.4..style = PaintingStyle.stroke;
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paintGrid);
    }
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paintGrid);
    }
    for (double x = -size.height; x < size.width + size.height; x += spacing * 2) {
      canvas.drawLine(Offset(x, 0), Offset(x + size.height, size.height), paintLines);
    }
    for (double x = -size.height; x < size.width + size.height; x += spacing * 2) {
      canvas.drawLine(Offset(x, size.height), Offset(x + size.height, 0), paintLines);
    }
  }
  @override
  bool shouldRepaint(covariant CustomPainter _) => false;
}

// ─── NOTCH CLIPPER ────────────────────────────────────────────────────────────
class NotchClipper extends CustomClipper<Path> {
  final double notchOffset;
  final double notchRadius;
  final double barHeight;
  final double totalWidth;

  NotchClipper({
    required this.notchOffset,
    required this.notchRadius,
    required this.barHeight,
    required this.totalWidth,
  });

  @override
  Path getClip(Size size) {
    final path = Path();
    final double radius = 30;
    final double w = size.width;
    final double h = size.height;

    path.moveTo(radius, 0);
    path.arcTo(
      Rect.fromLTWH(0, 0, radius * 2, radius * 2),
      math.pi,
      math.pi / 2,
      false,
    );

    final double notchStart = (notchOffset - notchRadius).clamp(radius, w - radius);
    final double notchEnd = (notchOffset + notchRadius).clamp(radius, w - radius);

    path.lineTo(notchStart, 0);
    final double controlY = notchRadius * 1.2;
    path.quadraticBezierTo(notchOffset - notchRadius * 0.3, controlY, notchOffset, notchRadius * 1.0);
    path.quadraticBezierTo(notchOffset + notchRadius * 0.3, controlY, notchEnd, 0);
    path.lineTo(w - radius, 0);
    path.arcTo(
      Rect.fromLTWH(w - radius * 2, 0, radius * 2, radius * 2),
      math.pi * 1.5,
      math.pi / 2,
      false,
    );
    path.lineTo(w, h - radius);
    path.arcTo(
      Rect.fromLTWH(w - radius * 2, h - radius * 2, radius * 2, radius * 2),
      0,
      math.pi / 2,
      false,
    );
    path.lineTo(radius, h);
    path.arcTo(
      Rect.fromLTWH(0, h - radius * 2, radius * 2, radius * 2),
      math.pi / 2,
      math.pi / 2,
      false,
    );
    path.close();
    return path;
  }

  @override
  bool shouldReclip(covariant NotchClipper oldClipper) {
    return oldClipper.notchOffset != notchOffset ||
        oldClipper.notchRadius != notchRadius ||
        oldClipper.barHeight != barHeight ||
        oldClipper.totalWidth != totalWidth;
  }
}

// ─── ANIMATED NOTCH BOTTOM NAV ──────────────────────────────────────────────
class _AnimatedNotchBottomNav extends StatefulWidget {
  final int currentIndex;
  final ValueChanged<int> onTap;

  const _AnimatedNotchBottomNav({
    required this.currentIndex,
    required this.onTap,
  });

  @override
  _AnimatedNotchBottomNavState createState() => _AnimatedNotchBottomNavState();
}

class _AnimatedNotchBottomNavState extends State<_AnimatedNotchBottomNav> with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late List<Animation<double>> _animations;

  final List<IconData> _icons = [
    Icons.home_rounded,
    Icons.bug_report_rounded,
    Icons.build_rounded,
    Icons.person_rounded,
  ];

  final List<String> _labels = ['Home', 'Bug', 'Tools', 'Profile'];

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 300),
    );
    _animations = List.generate(4, (index) {
      return Tween<double>(begin: 0.0, end: 1.0).animate(
        CurvedAnimation(
          parent: _animationController,
          curve: Interval(
            index * 0.1,
            1.0,
            curve: Curves.easeOutBack,
          ),
        ),
      );
    });
    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final notchOffset = screenWidth / 2;
    const notchRadius = 30.0;
    const barHeight = 70.0;

    return Container(
      height: barHeight + 20,
      margin: EdgeInsets.symmetric(horizontal: 16),
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          // Background with notch
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: ClipPath(
              clipper: NotchClipper(
                notchOffset: notchOffset,
                notchRadius: notchRadius,
                barHeight: barHeight,
                totalWidth: screenWidth - 32,
              ),
              child: Container(
                height: barHeight,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Color(0xFF1A1A2E),
                      Color(0xFF16213E),
                      Color(0xFF0F3460),
                    ],
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: kNeonCyan.withOpacity(0.2),
                      blurRadius: 20,
                      spreadRadius: 0,
                    ),
                  ],
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: List.generate(4, (index) {
                    final isSelected = widget.currentIndex == index;
                    return Expanded(
                      child: GestureDetector(
                        onTap: () => widget.onTap(index),
                        child: Container(
                          padding: EdgeInsets.symmetric(vertical: 8),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              AnimatedBuilder(
                                animation: _animations[index],
                                builder: (context, child) {
                                  return Transform.scale(
                                    scale: 1.0 + (isSelected ? 0.2 : 0.0) * _animations[index].value,
                                    child: Icon(
                                      _icons[index],
                                      color: isSelected ? kNeonCyan : Colors.white54,
                                      size: isSelected ? 28 : 24,
                                    ),
                                  );
                                },
                              ),
                              SizedBox(height: 2),
                              AnimatedDefaultTextStyle(
                                duration: Duration(milliseconds: 200),
                                style: TextStyle(
                                  color: isSelected ? kNeonCyan : Colors.white54,
                                  fontSize: isSelected ? 12 : 10,
                                  fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                                ),
                                child: Text(_labels[index]),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  }),
                ),
              ),
            ),
          ),
          // Floating action button in notch
          Positioned(
            top: -15,
            left: notchOffset - 30,
            child: GestureDetector(
              onTap: () => widget.onTap(2),
              child: Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      kNeonCyan,
                      kNeonPurple,
                    ],
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: kNeonCyan.withOpacity(0.6),
                      blurRadius: 20,
                      spreadRadius: 5,
                    ),
                  ],
                ),
                child: Icon(
                  Icons.build_rounded,
                  color: Colors.white,
                  size: 30,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─── DASHBOARD CONTENT ───────────────────────────────────────────────────────
class _DashboardContent extends StatefulWidget {
  const _DashboardContent();

  @override
  State<_DashboardContent> createState() => _DashboardContentState();
}

class _DashboardContentState extends State<_DashboardContent> {
  // Device Info
  String deviceModel = 'Loading...';
  String deviceManufacturer = 'Loading...';
  String androidVersion = 'Loading...';
  String androidAPI = 'Loading...';
  String deviceID = 'Loading...';
  String role = 'DEVELOPER';
  String expired = '2029-06-28';
  
  // System Info
  String ramUsage = '2.3G';
  String totalRam = '4.0G';
  String storageUsage = '86G';
  String totalStorage = '128G';
  String batteryLevel = '57%';
  String batteryStatus = 'Discharging';
  
  // Network
  String signalStrength = '93%';
  String networkType = 'WiFi';
  String ipAddress = '192.168.1.1';
  String wifiName = 'MyWiFi';
  
  // Session
  String sessionID = '';
  DateTime _loginTime = DateTime.now();
  Timer? _sessionTimer;
  String sessionTime = '00:00:00';
  
  // Active
  int onlineUsers = 99;
  int activeConns = 2;
  bool isOnline = true;
  
  // Notifications
  List<Map<String, dynamic>> _notifications = [];
  bool _hasNewNotif = false;
  
  // Colors
  final Color kNeonCyan = const Color(0xFF00E5FF);
  final Color kNeonPurple = const Color(0xFF9B5CFF);
  final Color kNeonPink = const Color(0xFFFF2D95);

  @override
  void initState() {
    super.initState();
    _getDeviceInfo();
    _getSystemInfo();
    _getNetworkInfo();
    _startSessionTimer();
    _startRealtimeMonitoring();
    _generateSessionID();
  }

  // ─── DEVICE INFO ──────────────────────────────────────────────────────
  Future<void> _getDeviceInfo() async {
    final deviceInfo = DeviceInfoPlugin();
    
    try {
      if (Platform.isAndroid) {
        final androidInfo = await deviceInfo.androidInfo;
        setState(() {
          deviceManufacturer = androidInfo.manufacturer;
          deviceModel = androidInfo.model;
          androidVersion = androidInfo.version.release;
          androidAPI = 'API ${androidInfo.version.sdkInt}';
          deviceID = androidInfo.id;
        });
      } else if (Platform.isIOS) {
        final iosInfo = await deviceInfo.iosInfo;
        setState(() {
          deviceManufacturer = 'Apple';
          deviceModel = iosInfo.model;
          androidVersion = iosInfo.systemVersion;
          androidAPI = 'iOS ${iosInfo.systemVersion}';
          deviceID = iosInfo.identifierForVendor ?? '';
        });
      }
    } catch (e) {
      setState(() {
        deviceModel = 'Unknown Device';
        deviceManufacturer = 'Unknown';
      });
    }
  }

  // ─── SYSTEM INFO ──────────────────────────────────────────────────────
  Future<void> _getSystemInfo() async {
    try {
      // Battery
      final battery = Battery();
      final level = await battery.batteryLevel;
      final state = await battery.batteryState;
      
      setState(() {
        batteryLevel = '$level%';
        batteryStatus = state.toString().split('.').last;
      });
    } catch (e) {
      // Fallback data
      setState(() {
        batteryLevel = '57%';
        batteryStatus = 'Discharging';
      });
    }
  }

  // ─── NETWORK INFO ──────────────────────────────────────────────────────
  Future<void> _getNetworkInfo() async {
    final networkInfo = NetworkInfo();
    final connectivity = Connectivity();
    
    try {
      final results = await connectivity.checkConnectivity();
      final result = results.isNotEmpty ? results.first : ConnectivityResult.none;
      
      final ip = await networkInfo.getWifiIP();
      final name = await networkInfo.getWifiName();
      
      setState(() {
        networkType = _getNetworkType(result);
        ipAddress = ip ?? '0.0.0.0';
        wifiName = name?.replaceAll('"', '') ?? 'Not Connected';
        signalStrength = '${80 + Random().nextInt(15)}%';
        isOnline = result != ConnectivityResult.none;
        activeConns = result == ConnectivityResult.wifi ? 2 : 
                     result == ConnectivityResult.mobile ? 1 : 0;
      });
    } catch (e) {
      setState(() {
        networkType = 'WiFi';
        isOnline = true;
        activeConns = 2;
      });
    }
  }

  String _getNetworkType(ConnectivityResult result) {
    switch (result) {
      case ConnectivityResult.wifi: return 'WiFi';
      case ConnectivityResult.mobile: return 'Mobile Data';
      case ConnectivityResult.ethernet: return 'Ethernet';
      case ConnectivityResult.vpn: return 'VPN';
      case ConnectivityResult.bluetooth: return 'Bluetooth';
      case ConnectivityResult.none: return 'No Connection';
      default: return 'Unknown';
    }
  }

  // ─── SESSION ──────────────────────────────────────────────────────────
  void _generateSessionID() {
    final chars = '0123456789abcdef';
    final random = Random();
    sessionID = List.generate(16, (_) => chars[random.nextInt(chars.length)]).join();
  }

  void _startSessionTimer() {
    _sessionTimer = Timer.periodic(Duration(seconds: 1), (timer) {
      final duration = DateTime.now().difference(_loginTime);
      final hours = duration.inHours.toString().padLeft(2, '0');
      final minutes = (duration.inMinutes % 60).toString().padLeft(2, '0');
      final seconds = (duration.inSeconds % 60).toString().padLeft(2, '0');
      setState(() {
        sessionTime = '$hours:$minutes:$seconds';
      });
    });
  }

  // ─── REALTIME MONITORING ─────────────────────────────────────────────
  void _startRealtimeMonitoring() {
    Timer.periodic(Duration(seconds: 5), (timer) {
      if (mounted) {
        setState(() {
          // Simulasi online users (5-30)
          onlineUsers = 5 + Random().nextInt(25);
          
          // Simulasi aktif connections
          if (isOnline) {
            activeConns = 1 + Random().nextInt(3);
          }
        });
      }
    });
  }

  // ─── UI ──────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ─── DASHBOARD HEADER WITH BANNER ───────────────────────────
          _buildDashboardBanner(),
          SizedBox(height: 20),
          
          // ─── STATUS GRID ─────────────────────────────────────────────
          _buildStatusGrid(),
          SizedBox(height: 20),
          
          // ─── SYSTEM INFO CARDS ──────────────────────────────────────
          _buildSystemInfoGrid(),
          SizedBox(height: 20),
          
          // ─── SESSION INFO ────────────────────────────────────────────
          _buildSessionInfo(),
          SizedBox(height: 20),
          
          // ─── MOTIVASI ────────────────────────────────────────────────
          _buildMotivationCard(),
        ],
      ),
    );
  }

  // ─── DASHBOARD BANNER ──────────────────────────────────────────────
  Widget _buildDashboardBanner() {
    return Container(
      height: 200,
      width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        image: DecorationImage(
          image: AssetImage('assets/user_card.jpg'),
          fit: BoxFit.cover,
          colorFilter: ColorFilter.mode(
            Colors.black.withOpacity(0.5),
            BlendMode.darken,
          ),
        ),
        boxShadow: [
          BoxShadow(
            color: kNeonCyan.withOpacity(0.3),
            blurRadius: 30,
            spreadRadius: 0,
          ),
        ],
      ),
      child: Stack(
        children: [
          // Overlay gradient
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Colors.transparent,
                  Colors.black.withOpacity(0.7),
                ],
              ),
            ),
          ),
          
          // Content
          Padding(
            padding: EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Title with glow
                ShaderMask(
                  shaderCallback: (bounds) => LinearGradient(
                    colors: [kNeonCyan, kNeonPurple],
                  ).createShader(bounds),
                  child: Text(
                    '⚡ DASHBOARD',
                    style: TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                      letterSpacing: 2,
                    ),
                  ),
                ),
                SizedBox(height: 8),
                
                // Subtitle
                Text(
                  'System Control Panel',
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.white70,
                    letterSpacing: 1,
                  ),
                ),
                SizedBox(height: 12),
                
                // Status row
                Row(
                  children: [
                    _buildStatusChip(
                      icon: Icons.circle,
                      label: 'ONLINE',
                      color: kNeonGreen,
                    ),
                    SizedBox(width: 12),
                    _buildStatusChip(
                      icon: Icons.devices,
                      label: '$activeConns ACTIVE',
                      color: kNeonCyan,
                    ),
                    SizedBox(width: 12),
                    _buildStatusChip(
                      icon: Icons.people_alt,
                      label: '$onlineUsers ONLINE',
                      color: kNeonPurple,
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusChip({
    required IconData icon,
    required String label,
    required Color color,
  }) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.2),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.5)),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 12),
          SizedBox(width: 4),
          Text(
            label,
            style: TextStyle(
              color: Colors.white,
              fontSize: 10,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  // ─── STATUS GRID ─────────────────────────────────────────────────────
  Widget _buildStatusGrid() {
    final items = [
      {'icon': Icons.device_hub, 'label': 'DEVICE', 'value': '$deviceManufacturer $deviceModel'},
      {'icon': Icons.battery_full, 'label': 'BATTERY', 'value': batteryLevel},
      {'icon': Icons.wifi, 'label': 'NETWORK', 'value': '$networkType / $signalStrength'},
      {'icon': Icons.memory, 'label': 'RAM', 'value': ramUsage},
      {'icon': Icons.storage, 'label': 'STORAGE', 'value': storageUsage},
      {'icon': Icons.settings_system_daydream, 'label': 'SYSTEM', 'value': androidAPI},
    ];

    return GridView.builder(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 1.2,
      ),
      itemCount: items.length,
      itemBuilder: (context, index) {
        final item = items[index];
        return _buildGlassCard(
          icon: item['icon'] as IconData,
          label: item['label'] as String,
          value: item['value'] as String,
        );
      },
    );
  }

  Widget _buildGlassCard({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.white.withOpacity(0.05),
            Colors.white.withOpacity(0.01),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Colors.white.withOpacity(0.1),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black26,
            blurRadius: 10,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Padding(
        padding: EdgeInsets.all(12),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              color: kNeonCyan,
              size: 24,
            ),
            SizedBox(height: 8),
            Text(
              label,
              style: TextStyle(
                color: Colors.white54,
                fontSize: 10,
                fontWeight: FontWeight.w500,
              ),
            ),
            SizedBox(height: 4),
            Flexible(
              child: Text(
                value,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── SYSTEM INFO GRID ──────────────────────────────────────────────
  Widget _buildSystemInfoGrid() {
    return Row(
      children: [
        Expanded(
          child: _buildInfoCard(
            icon: Icons.engineering,
            label: 'ROLE',
            value: role,
            color: kNeonPurple,
          ),
        ),
        SizedBox(width: 12),
        Expanded(
          child: _buildInfoCard(
            icon: Icons.timer_off,
            label: 'EXPIRED',
            value: expired,
            color: kNeonRed,
          ),
        ),
        SizedBox(width: 12),
        Expanded(
          child: _buildInfoCard(
            icon: Icons.link,
            label: 'CONN',
            value: '$activeConns Active',
            color: kNeonGreen,
          ),
        ),
      ],
    );
  }

  Widget _buildInfoCard({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            color.withOpacity(0.15),
            Colors.transparent,
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: color.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 20),
          SizedBox(height: 6),
          Text(
            label,
            style: TextStyle(
              color: Colors.white54,
              fontSize: 10,
            ),
          ),
          SizedBox(height: 4),
          Text(
            value,
            style: TextStyle(
              color: Colors.white,
              fontSize: 13,
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  // ─── SESSION INFO ────────────────────────────────────────────────────
  Widget _buildSessionInfo() {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.white.withOpacity(0.05),
            Colors.white.withOpacity(0.01),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Colors.white.withOpacity(0.1),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Icon(
            Icons.vpn_key,
            color: kNeonCyan,
            size: 20,
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'SESSION',
                  style: TextStyle(
                    color: Colors.white54,
                    fontSize: 10,
                  ),
                ),
                Text(
                  sessionID,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontFamily: 'monospace',
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: kNeonCyan.withOpacity(0.2),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: kNeonCyan.withOpacity(0.3)),
            ),
            child: Row(
              children: [
                Icon(Icons.timer, color: kNeonCyan, size: 14),
                SizedBox(width: 4),
                Text(
                  sessionTime,
                  style: TextStyle(
                    color: kNeonCyan,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'monospace',
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── MOTIVASI ──────────────────────────────────────────────────────
  Widget _buildMotivationCard() {
    return Container(
      padding: EdgeInsets.all(20),
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            kNeonPurple.withOpacity(0.1),
            kNeonCyan.withOpacity(0.05),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: kNeonPurple.withOpacity(0.2),
          width: 1,
        ),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Icon(Icons.format_quote, color: kNeonPurple, size: 20),
              SizedBox(width: 8),
              Text(
                'PESAN DARI DEV',
                style: TextStyle(
                  color: Colors.white54,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          SizedBox(height: 8),
          Text(
            '"ZIXTER NIGHT terlalu tinggi sampai banyak yang copy."',
            style: TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontStyle: FontStyle.italic,
            ),
          ),
          SizedBox(height: 12),
          Text(
            'CONNECT WITH ZIXTER NIGHT',
            style: TextStyle(
              color: Colors.white24,
              fontSize: 10,
            ),
          ),
          Text(
            '@DIZT_ZIXTER',
            style: TextStyle(
              color: kNeonCyan,
              fontSize: 12,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _sessionTimer?.cancel();
    super.dispose();
  }
}

// ─── MAIN HOME PAGE ──────────────────────────────────────────────────────────
class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _navIndex = 0;
  List<Map<String, dynamic>> _notifications = [];
  bool _hasNewNotif = false;
  bool _developerMessageVisible = true;
  int onlineUsers = 23;
  int activeConns = 2;

  final PageController _pageController = PageController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      body: Stack(
        children: [
          // Background
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color(0xFF0A0A1A),
                  Color(0xFF1A0B2E),
                  Color(0xFF0A0A0F),
                ],
              ),
            ),
          ),
          
          // Hexagon pattern
          Positioned.fill(
            child: CustomPaint(
              painter: _HexagonPatternPainter(),
            ),
          ),

          // Main content
          PageView(
            controller: _pageController,
            onPageChanged: (index) {
              setState(() {
                _navIndex = index;
              });
            },
            children: [
              _DashboardContent(),
              Container(child: Center(child: Text('Bug Page', style: TextStyle(color: Colors.white)))),
              Container(child: Center(child: Text('Tools Page', style: TextStyle(color: Colors.white)))),
              Container(child: Center(child: Text('Profile Page', style: TextStyle(color: Colors.white)))),
            ],
          ),
          
          // Bottom nav
          Positioned(
            bottom: 20,
            left: 0,
            right: 0,
            child: _AnimatedNotchBottomNav(
              currentIndex: _navIndex,
              onTap: (index) {
                setState(() {
                  _navIndex = index;
                });
                _pageController.animateToPage(
                  index,
                  duration: Duration(milliseconds: 300),
                  curve: Curves.easeInOut,
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

// ─── DASHBOARD PAGE ─────────────────────────────────────────────────────────
class _DashStat {
  final IconData icon;
  final String label;
  final String value;
  final Color color;
  const _DashStat(this.icon, this.label, this.value, this.color);
}

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final String uid;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.uid,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  // ── State ────────────────────────────────────────────────────────────────
  late String sessionKey, username, password, role, expiredDate;
  late String uid;
  late List<Map<String, dynamic>> listBug, listDoos;
  late List<dynamic> newsList;

  late WebSocketChannel channel;
  String androidId = 'unknown';
  File? _profileImage;
  int _bannerIndex = 0;
  late PageController _bannerCtrl;
  Timer? _bannerTimer;

  int _navIndex   = 0;
  List<Map<String, dynamic>> _notifications = [];
  bool _hasNewNotif = false;
  // Real online-user count received from the authenticated WebSocket API.
  // Start at 0 so the UI never shows a fake/stale hardcoded number.
  int onlineUsers = 0;
  int activeConns = 0;
  bool _developerMessageVisible = true;

  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  Timer? _statsTimer;
  late PageController _newsPageCtrl;
  int _newsPageViewKey = 0;
  double _currentNewsPage = 0.0;
  late PageController _qaPageCtrl;
  double _currentQaPage = 0.0;

  late PageController _bugPageCtrl;
  double _currentBugPage = 0.0;

  bool _locationLoading = false;
  bool _locationGranted = false;

  String _prayerCity = 'Tangerang';
  Map<String, String> _prayerTimes = {};
  String _nextPrayerLabel = '';
  String _nextPrayerTime  = '';
  bool _prayerLoading = true;

  List<UserStoryGroup> _dashboardStoryGroups = [];
  bool _storiesLoading = true;

  Map<String, dynamic>? _hadith;
  bool _hadithLoading = true;
  int _lastHadithNumber = 0;

  String deviceModel = '';
  String deviceManufacturer = '';
  String androidVersion = '';
  String batteryLevel = '57%';
  String signalStrength = '93%';
  String ramUsage = '2.3G';
  String storageUsage = '86G';
  String sessionTime = '09:00';
  DateTime _loginTime = DateTime.now();
  Timer? _sessionTimer;

  @override
  void initState() {
    super.initState();
    sessionKey  = widget.sessionKey;
    username    = widget.username;
    password    = widget.password;
    role        = widget.role;
    expiredDate = widget.expiredDate;
    uid         = widget.uid;
    listBug     = widget.listBug;
    listDoos    = widget.listDoos;
    newsList    = widget.news;

    _fadeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _fadeCtrl.forward();

    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.85, end: 1.0).animate(
        CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _newsPageCtrl = PageController(viewportFraction: 0.88, initialPage: 0);
    _newsPageCtrl.addListener(() {
      if (mounted) setState(() => _currentNewsPage = _newsPageCtrl.page ?? 0.0);
    });

    _qaPageCtrl = PageController(viewportFraction: 0.88, initialPage: 0);
    _qaPageCtrl.addListener(() {
      if (mounted) setState(() => _currentQaPage = _qaPageCtrl.page ?? 0.0);
    });

    _bugPageCtrl = PageController();
    _bugPageCtrl.addListener(() {
      if (mounted) setState(() => _currentBugPage = _bugPageCtrl.page ?? 0.0);
    });

    _bannerCtrl = PageController();
    _bannerTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (mounted && _bannerCtrl.hasClients) {
        final next = (_bannerIndex + 1) % 2;
        _bannerCtrl.animateToPage(next,
            duration: const Duration(milliseconds: 500), curve: Curves.easeInOut);
        setState(() => _bannerIndex = next);
      }
    });

    _initAndroidId();
    _initDeviceInfo();
    _loadProfileImage();
    _fetchDashboardStories();
    _detectLocationAndFetchPrayer();
    _fetchRandomHadith();

    _sessionTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) {
        final duration = DateTime.now().difference(_loginTime);
        final hours = duration.inHours;
        final minutes = duration.inMinutes.remainder(60);
        setState(() {
          sessionTime = '${hours.toString().padLeft(2, '0')}:${minutes.toString().padLeft(2, '0')}';
        });
      }
    });
  }

  @override
  void dispose() {
    _statsTimer?.cancel();
    _bannerTimer?.cancel();
    _bannerCtrl.dispose();
    _bugPageCtrl.dispose();
    channel.sink.close(status.goingAway);
    _fadeCtrl.dispose();
    _pulseCtrl.dispose();
    _newsPageCtrl.dispose();
    _qaPageCtrl.dispose();
    _sessionTimer?.cancel();
    super.dispose();
  }

  Future<void> _fetchDashboardStories() async {
    try {
      final res = await http.get(
        Uri.parse('$baseUrl/getStories?key=$sessionKey'),
      ).timeout(const Duration(seconds: 12));

      if (res.statusCode != 200) {
        if (mounted) setState(() => _storiesLoading = false);
        return;
      }

      final data = jsonDecode(res.body);
      if (data['valid'] != true) {
        if (mounted) setState(() => _storiesLoading = false);
        return;
      }

      final List allStories = data['stories'] ?? [];
      final items = allStories
          .whereType<Map>()
          .map((e) => StoryItem.fromJson(Map<String, dynamic>.from(e)))
          .toList();

      final Map<String, List<StoryItem>> grouped = {};
      for (final story in items) {
        final name = story.username.trim();
        if (name.isEmpty) continue;
        grouped.putIfAbsent(name, () => []).add(story);
      }

      final groups = grouped.entries.map((entry) {
        return UserStoryGroup(
          username: entry.key,
          stories: entry.value,
          hasUnviewed: entry.value.any((story) => story.viewCount == 0),
        );
      }).toList();

      groups.sort((a, b) {
        if (a.username == username) return -1;
        if (b.username == username) return 1;
        return 0;
      });

      if (mounted) {
        setState(() {
          _dashboardStoryGroups = groups;
          _storiesLoading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _storiesLoading = false);
    }
  }

  void _openDashboardStory(String storyUsername) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => StoryPage(
          sessionKey: sessionKey,
          username: username,
        ),
      ),
    ).then((_) => _fetchDashboardStories());
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final path  = prefs.getString('profile_image_$username');
    if (path != null && path.isNotEmpty && mounted) {
      setState(() => _profileImage = File(path));
    }
  }

  Future<void> _initAndroidId() async {
    final info = await DeviceInfoPlugin().androidInfo;
    androidId = info.id;
    _connectWS();
  }

  Future<void> _initDeviceInfo() async {
    final info = await DeviceInfoPlugin().androidInfo;
    if (mounted) {
      setState(() {
        deviceModel = info.model.isNotEmpty ? info.model : 'Unknown';
        deviceManufacturer = info.manufacturer.isNotEmpty ? info.manufacturer : 'Unknown';
        androidVersion = 'Android API ${info.version.sdkInt ?? 0}';
      });
    }
  }

  void _connectWS() {
    channel = WebSocketChannel.connect(Uri.parse('$baseUrl'));

    channel.sink.add(jsonEncode({
      'type': 'validate',
      'key': sessionKey,
      'androidId': androidId,
    }));

    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'myInfo' && data['valid'] == true && mounted) {
        channel.sink.add(jsonEncode({'type': 'stats'}));
      }
      if (data['type'] == 'stats' && mounted) {
        // The API is the single source of truth. Do not simulate or
        // increment this value locally: it represents users currently
        // active on the server.
        final serverOnlineUsers = data['onlineUsers'];
        final serverActiveConnections = data['activeConnections'];

        setState(() {
          onlineUsers = serverOnlineUsers is num
              ? serverOnlineUsers.toInt()
              : int.tryParse('$serverOnlineUsers') ?? 0;
          activeConns = serverActiveConnections is num
              ? serverActiveConnections.toInt()
              : int.tryParse('$serverActiveConnections') ?? 0;
        });
      }
      if (data['type'] == 'myInfo' && data['valid'] == false && mounted) {
        _handleInvalidSession(data['reason'] ?? 'Session invalid');
      }
      if (data['type'] == 'forceLogout' && mounted) {
        _handleInvalidSession(data['reason'] ?? 'Logged out');
      }
    }, onError: (_) {
      if (mounted) {
        setState(() {
          // No confirmed server connection = no confirmed online count.
          onlineUsers = 0;
          activeConns = 0;
        });
      }
      Future.delayed(const Duration(seconds: 3), () {
        if (mounted) _connectWS();
      });
    }, onDone: () {
      if (mounted) {
        setState(() {
          onlineUsers = 0;
          activeConns = 0;
        });
        Future.delayed(const Duration(seconds: 3), () {
          if (mounted) _connectWS();
        });
      }
    });

    _statsTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      try {
        channel.sink.add(jsonEncode({'type': 'stats'}));
      } catch (_) {}
    });
  }

  Future<void> _openUrl(String url) async {
    await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  }

  Future<void> _fetchPrayerTimes() async {
    if (!mounted) return;
    setState(() => _prayerLoading = true);
    final data = await PrayerTimeService.fetchPrayerTimes(_prayerCity);
    if (!mounted) return;
    if (data.isNotEmpty) {
      final timings = data['data']?['timings'] ?? {};
      final Map<String, String> times = {
        'Subuh'  : timings['Fajr']    ?? '--:--',
        'Dzuhur' : timings['Dhuhr']   ?? '--:--',
        'Ashar'  : timings['Asr']     ?? '--:--',
        'Maghrib': timings['Maghrib'] ?? '--:--',
        'Isya'   : timings['Isha']    ?? '--:--',
      };
      final now = TimeOfDay.now();
      String nextLabel = 'Isya';
      String nextTime  = times['Isya'] ?? '--:--';
      for (final entry in times.entries) {
        final parts = entry.value.split(':');
        if (parts.length >= 2) {
          final h = int.tryParse(parts[0]) ?? 0;
          final m = int.tryParse(parts[1]) ?? 0;
          if (h > now.hour || (h == now.hour && m > now.minute)) {
            nextLabel = entry.key;
            nextTime  = entry.value;
            break;
          }
        }
      }
      setState(() {
        _prayerTimes     = times;
        _nextPrayerLabel = nextLabel;
        _nextPrayerTime  = nextTime;
        _prayerLoading   = false;
      });
    } else {
      setState(() => _prayerLoading = false);
    }
  }

  Future<void> _detectLocationAndFetchPrayer() async {
    if (!mounted) return;
    setState(() => _locationLoading = true);

    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        if (mounted) {
          setState(() {
            _locationLoading = false;
            _prayerCity = 'Tangerang';
          });
          await _fetchPrayerTimes();
        }
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          if (mounted) {
            setState(() {
              _locationLoading = false;
              _prayerCity = 'Tangerang';
            });
            await _fetchPrayerTimes();
          }
          return;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        if (mounted) {
          setState(() {
            _locationLoading = false;
            _prayerCity = 'Tangerang';
          });
          await _fetchPrayerTimes();
        }
        return;
      }

      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.medium,
      );

      final placemarks = await placemarkFromCoordinates(
        position.latitude,
        position.longitude,
      );

      if (placemarks.isNotEmpty && mounted) {
        final place = placemarks.first;
        final city = place.subAdministrativeArea?.isNotEmpty == true
            ? place.subAdministrativeArea!
            : place.locality?.isNotEmpty == true
                ? place.locality!
                : place.administrativeArea ?? 'Tangerang';

        setState(() {
          _prayerCity     = city;
          _locationGranted = true;
          _locationLoading = false;
        });

        await _fetchPrayerTimes();

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Row(children: [
                const Icon(Icons.location_on_rounded, color: Colors.white, size: 16),
                const SizedBox(width: 8),
                Text('Lokasi terdeteksi: $city'),
              ]),
              backgroundColor: kBlue,
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              duration: const Duration(seconds: 3),
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _locationLoading = false;
          _prayerCity = 'Tangerang';
        });
        await _fetchPrayerTimes();
      }
    }
  }

  Future<void> _fetchRandomHadith() async {
    if (!mounted) return;
    setState(() => _hadithLoading = true);
    try {
      int randomNumber;
      do {
        randomNumber = Random().nextInt(100) + 1;
      } while (randomNumber == _lastHadithNumber);
      _lastHadithNumber = randomNumber;
      final response = await http
          .get(Uri.parse('https://api.hadith.gading.dev/books/muslim/$randomNumber'))
          .timeout(const Duration(seconds: 8));
      if (response.statusCode == 200 && mounted) {
        setState(() { _hadith = json.decode(response.body); _hadithLoading = false; });
      } else {
        if (mounted) setState(() => _hadithLoading = false);
      }
    } catch (_) {
      if (mounted) setState(() => _hadithLoading = false);
    }
  }

  void _showChangeCityDialog() {
    final ctrl = TextEditingController(text: _prayerCity);
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: kCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text('Ganti Lokasi',
            style: TextStyle(color: kWhite, fontFamily: 'Orbitron', fontSize: 14)),
        content: TextField(
          controller: ctrl,
          style: const TextStyle(color: kWhite),
          decoration: InputDecoration(
            hintText: 'Nama kota (misal: Jakarta)',
            hintStyle: const TextStyle(color: kWhite54),
            filled: true, fillColor: kBg,
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
            prefixIcon: const Icon(Icons.location_city_rounded, color: kBlue),
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Batal', style: TextStyle(color: kWhite54))),
          ElevatedButton(
            onPressed: () {
              if (ctrl.text.trim().isNotEmpty) {
                setState(() {
                  _prayerCity = ctrl.text.trim();
                  _locationGranted = false;
                });
                _fetchPrayerTimes();
                Navigator.pop(context);
              }
            },
            style: ElevatedButton.styleFrom(
                backgroundColor: kBlue,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            child: const Text('Simpan',
                style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  void _showHadithFullDialog(String arabic, String indo, String source, String number, String grade) {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
        child: Container(
          decoration: BoxDecoration(
            color: kCard, borderRadius: BorderRadius.circular(24),
            border: Border.all(color: kBlue.withOpacity(0.3)),
            boxShadow: [
              BoxShadow(color: kBlue.withOpacity(0.08), blurRadius: 30, spreadRadius: 2),
              BoxShadow(color: Colors.black.withOpacity(0.6), blurRadius: 20, offset: const Offset(0, 8)),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
                  color: kBlue.withOpacity(0.08),
                  border: Border(bottom: BorderSide(color: kBorder.withOpacity(0.5))),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 42, height: 42,
                      decoration: BoxDecoration(shape: BoxShape.circle, color: kBlue.withOpacity(0.2)),
                      child: const Icon(Icons.menu_book_rounded, color: kBlue, size: 22),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const Text('HADITH LENGKAP',
                            style: TextStyle(color: kWhite, fontWeight: FontWeight.bold, fontSize: 14, fontFamily: 'Orbitron')),
                        Text(grade, style: const TextStyle(color: kBlue, fontSize: 11)),
                      ]),
                    ),
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        width: 34, height: 34,
                        decoration: BoxDecoration(shape: BoxShape.circle, color: kWhite.withOpacity(0.08)),
                        child: const Icon(Icons.close_rounded, color: kWhite54, size: 18),
                      ),
                    ),
                  ],
                ),
              ),
              ConstrainedBox(
                constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.62),
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: double.infinity, padding: const EdgeInsets.all(18),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          color: const Color(0xFF18181B),
                          border: Border.all(color: kBorder.withOpacity(0.3)),
                        ),
                        child: Text(arabic,
                            textAlign: TextAlign.right, textDirection: TextDirection.rtl,
                            style: const TextStyle(color: kWhite, fontSize: 19, height: 2.2)),
                      ),
                      const SizedBox(height: 14),
                      Row(children: [
                        Container(width: 3, height: 18,
                            decoration: BoxDecoration(borderRadius: BorderRadius.circular(2), color: kBlue)),
                        const SizedBox(width: 8),
                        const Text('ARTINYA:', style: TextStyle(color: kBlue, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.2)),
                      ]),
                      const SizedBox(height: 10),
                      Container(
                        width: double.infinity, padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          color: const Color(0xFF111113),
                          border: Border.all(color: kBorder.withOpacity(0.2)),
                        ),
                        child: Text(indo,
                            style: const TextStyle(color: kWhite, fontSize: 14, fontStyle: FontStyle.italic, height: 1.8)),
                      ),
                      const SizedBox(height: 16),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: kBlue.withOpacity(0.5)),
                          color: kBlue.withOpacity(0.08),
                        ),
                        child: Row(mainAxisSize: MainAxisSize.min, children: [
                          const Icon(Icons.receipt_long_rounded, color: kBlue, size: 14),
                          const SizedBox(width: 6),
                          Text('${source.isNotEmpty ? source : "Muslim"} #$number',
                              style: const TextStyle(color: kBlue, fontSize: 12, fontWeight: FontWeight.bold)),
                        ]),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: kCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text('⚠️ Session Expired', style: TextStyle(color: kWhite)),
        content: Text(message, style: const TextStyle(color: kWhite54)),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()), (_) => false),
            child: const Text('OK', style: TextStyle(color: kBlue)),
          ),
        ],
      ),
    );
  }

  void _onNavTap(int index) {
    setState(() => _navIndex = index);
    if (index == 0) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_newsPageCtrl.hasClients) {
          setState(() { _currentNewsPage = 0.0; _newsPageViewKey++; });
          _newsPageCtrl.jumpToPage(0);
        }
      });
    }
  }

  void _onDrawerNav(int index) {
    Widget page;
    switch (index) {
      case 1: page = SellerPage(keyToken: sessionKey, userRole: role); break;
      case 2: page = AdminPage(sessionKey: sessionKey); break;
      case 3: page = OwnerPage(sessionKey: sessionKey, username: username); break;
      default: return;
    }
    Navigator.pop(context);
    Navigator.push(context, MaterialPageRoute(builder: (_) => page)).then((_) {
      if (mounted) {
        setState(() => _navIndex = 0);
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (_newsPageCtrl.hasClients) {
            setState(() { _currentNewsPage = 0.0; _newsPageViewKey++; });
            _newsPageCtrl.jumpToPage(0);
          }
        });
      }
    });
  }

  Widget _buildCurrentPage() {
    switch (_navIndex) {
      case 1:
        return _buildWhatsAppMenuPage();
      case 2:
        return ToolsPage(sessionKey: sessionKey, userRole: role, listDoos: listDoos, username: username, uid: uid);
      case 3:
        return ChatRoomPage(username: username, sessionKey: sessionKey);
      case 0:
      default:
        return _buildHomePage();
    }
  }

  Widget _buildWhatsAppMenuPage() {
    final menuOptions = [
      {
        'title': 'ZIXTER NIGHT BUG',
        'subtitle': 'Bug tanpa custom',
        'description': 'Gunakan langsung tanpa custom delay dan loops',
        'icon': Icons.bug_report_rounded,
        'iconColor': const Color(0xFF1565C0),
        'gradient': [const Color(0xFF0A2472), const Color(0xFF1565C0)],
        'badge': 'RECOMMENDED',
        'badgeColor': const Color(0xFF1565C0),
        'features': ['Mudah digunakan', 'Function terbaru', 'All work gacor', 'ZIXTER NIGHT BUG'],
        'onTap': () => Navigator.push(context, _slideRoute(home.HomePage(
          username: username, password: password, listBug: listBug,
          role: role, expiredDate: expiredDate, sessionKey: sessionKey,
        ))),
      },
      {
        'title': 'TOOLS',
        'subtitle': 'Alat bantu system',
        'description': 'Kumpulan tools OSINT dan utilities lengkap',
        'icon': Icons.build_circle_rounded,
        'iconColor': const Color(0xFF6366F1),
        'gradient': [const Color(0xFF1E1B4B), const Color(0xFF6366F1)],
        'badge': 'TOOLS',
        'badgeColor': const Color(0xFF6366F1),
        'features': ['OSINT tools', 'IP scanner', 'Port scanner', 'Utilities'],
        'onTap': () => Navigator.push(context, _slideRoute(ToolsPage(
          sessionKey: sessionKey, userRole: role, listDoos: listDoos, username: username, uid: uid,
        ))),
      },
      {
        'title': 'CUSTOM PAYLOAD',
        'subtitle': 'Custom delay & loops',
        'description': 'Setting custom delay dan jumlah loops sebelum kirim',
        'icon': Icons.tune_rounded,
        'iconColor': const Color(0xFFEC4899),
        'gradient': [const Color(0xFF831843), const Color(0xFFEC4899)],
        'badge': 'CUSTOM',
        'badgeColor': const Color(0xFFEC4899),
        'features': ['Custom delay', 'Custom loops', 'Target spesifik', 'Kontrol penuh'],
        'onTap': () => Navigator.push(context, _slideRoute(CustomPayloadPage(
          sessionKey: sessionKey, role: role, listBug: listBug,
          username: username, password: password, expiredDate: expiredDate,
        ))),
      },
      {
        'title': 'BUG GROUP',
        'subtitle': 'Kirim ke grup WhatsApp',
        'description': 'Target grup WhatsApp dengan berbagai bug pilihan',
        'icon': Icons.group_rounded,
        'iconColor': const Color(0xFF22C55E),
        'gradient': [const Color(0xFF14532D), const Color(0xFF22C55E)],
        'badge': 'GROUP',
        'badgeColor': const Color(0xFF22C55E),
        'features': ['Target grup WA', 'Multi sender', 'Bug pilihan', 'Efektif'],
        'onTap': () => Navigator.push(context, _slideRoute(BugGroupPage(
          sessionKey: sessionKey, role: role,
        ))),
      },
    ];

    return FadeTransition(
      opacity: _fadeAnim,
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [kBlue.withOpacity(0.15), Colors.transparent]),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: kBlue.withOpacity(0.3)),
            ),
            child: Row(children: [
              Container(
                width: 48, height: 48,
                decoration: BoxDecoration(
                  color: kBlue.withOpacity(0.15), shape: BoxShape.circle,
                  border: Border.all(color: kBlue.withOpacity(0.4)),
                ),
                child: const Icon(Icons.security_rounded, color: kBlue, size: 24),
              ),
              const SizedBox(width: 14),
              const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('PILIH MENU BUG', style: TextStyle(
                  color: kWhite, fontFamily: 'Orbitron', fontWeight: FontWeight.w900,
                  fontSize: 14, letterSpacing: 1.5,
                )),
                Text('Geser kiri/kanan untuk memilih metode',
                  style: TextStyle(color: kWhite54, fontSize: 12)),
              ]),
            ]),
          ),
          Expanded(
            child: PageView.builder(
              controller: _bugPageCtrl,
              itemCount: menuOptions.length,
              onPageChanged: (index) {
                if (mounted) setState(() => _currentBugPage = index.toDouble());
              },
              itemBuilder: (context, index) {
                final opt = menuOptions[index];
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  child: GestureDetector(
                    onTap: opt['onTap'] as VoidCallback,
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: (opt['gradient'] as List).cast<Color>(),
                          begin: Alignment.topLeft, end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(24),
                        boxShadow: [BoxShadow(
                          color: (opt['iconColor'] as Color).withOpacity(0.35),
                          blurRadius: 20, offset: const Offset(0, 8),
                        )],
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(24),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(children: [
                              Container(
                                width: 56, height: 56,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.black.withOpacity(0.3),
                                ),
                                child: Icon(opt['icon'] as IconData, color: Colors.white, size: 28),
                              ),
                              const SizedBox(width: 16),
                              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Text(opt['title'] as String, style: const TextStyle(
                                  color: Colors.white, fontFamily: 'Orbitron', fontWeight: FontWeight.w900,
                                  fontSize: 18, letterSpacing: 1,
                                )),
                                Text(opt['subtitle'] as String, style: TextStyle(
                                  color: Colors.white.withOpacity(0.7), fontSize: 14,
                                )),
                              ])),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                decoration: BoxDecoration(
                                  color: Colors.black.withOpacity(0.3),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Text(opt['badge'] as String, style: const TextStyle(
                                  color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold,
                                  fontFamily: 'Orbitron',
                                )),
                              ),
                            ]),
                            const SizedBox(height: 16),
                            Text(opt['description'] as String, style: TextStyle(
                              color: Colors.white.withOpacity(0.7), fontSize: 14, height: 1.5,
                            )),
                            const SizedBox(height: 16),
                            Wrap(
                              spacing: 10, runSpacing: 8,
                              children: (opt['features'] as List<String>).map((f) => Container(
                                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                                decoration: BoxDecoration(
                                  color: Colors.black.withOpacity(0.25),
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(color: Colors.white.withOpacity(0.15)),
                                ),
                                child: Text(f, style: TextStyle(
                                  color: Colors.white.withOpacity(0.9), fontSize: 12,
                                )),
                              )).toList(),
                            ),
                            const Spacer(),
                            Align(
                              alignment: Alignment.bottomRight,
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.15),
                                  borderRadius: BorderRadius.circular(30),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text('BUKA', style: TextStyle(
                                      color: Colors.white.withOpacity(0.9), fontFamily: 'Orbitron',
                                      fontSize: 13, fontWeight: FontWeight.bold, letterSpacing: 1,
                                    )),
                                    const SizedBox(width: 8),
                                    Icon(Icons.arrow_forward_ios_rounded, color: Colors.white.withOpacity(0.9), size: 14),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(menuOptions.length, (index) {
                final isActive = _currentBugPage.round() == index;
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  width: isActive ? 24 : 8,
                  height: 8,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(4),
                    color: isActive ? kBlue : Colors.white24,
                  ),
                );
              }),
            ),
          ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }

  Widget _buildInstagramStories() {
    final myGroup = _dashboardStoryGroups.where((g) => g.username == username).toList();
    final otherGroups = _dashboardStoryGroups.where((g) => g.username != username).toList();

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      child: SizedBox(
        height: 92,
        child: _storiesLoading
            ? const Center(
                child: SizedBox(
                  width: 22,
                  height: 22,
                  child: CircularProgressIndicator(strokeWidth: 2, color: kBlueLight),
                ),
              )
            : ListView.separated(
                scrollDirection: Axis.horizontal,
                physics: const BouncingScrollPhysics(),
                itemCount: 1 + otherGroups.length,
                separatorBuilder: (_, __) => const SizedBox(width: 12),
                itemBuilder: (ctx, i) {
                  if (i == 0) {
                    final hasMine = myGroup.isNotEmpty && myGroup.first.stories.isNotEmpty;
                    final first = hasMine ? myGroup.first.stories.first : null;

                    return GestureDetector(
                      onTap: () => _openDashboardStory(username),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Stack(
                            clipBehavior: Clip.none,
                            children: [
                              Container(
                                width: 62,
                                height: 62,
                                padding: const EdgeInsets.all(2.5),
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: hasMine
                                      ? const LinearGradient(
                                          colors: [Color(0xFFF58529), Color(0xFFDD2A7B), Color(0xFF8134AF)],
                                          begin: Alignment.topLeft,
                                          end: Alignment.bottomRight,
                                        )
                                      : null,
                                  color: hasMine ? null : kCardAlt,
                                  border: hasMine ? null : Border.all(color: kWhite24, width: 2),
                                ),
                                child: ClipOval(
                                  child: first != null && first.mediaType == 'image' && first.mediaUrl.isNotEmpty
                                      ? Image.network(
                                          first.mediaUrl,
                                          fit: BoxFit.cover,
                                          errorBuilder: (_, __, ___) => const Icon(
                                            Icons.person_rounded,
                                            color: kWhite54,
                                            size: 30,
                                          ),
                                        )
                                      : const Icon(
                                          Icons.person_rounded,
                                          color: kWhite54,
                                          size: 30,
                                        ),
                                ),
                              ),
                              Positioned(
                                right: -1,
                                bottom: -1,
                                child: Container(
                                  width: 20,
                                  height: 20,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: kBlue,
                                    border: Border.all(color: kBg, width: 2),
                                  ),
                                  child: const Icon(Icons.add, color: Colors.white, size: 13),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          const Text(
                            'Cerita Saya',
                            style: TextStyle(color: kWhite, fontSize: 10, fontWeight: FontWeight.w400),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    );
                  }

                  final group = otherGroups[i - 1];
                  final first = group.stories.first;
                  return GestureDetector(
                    onTap: () => _openDashboardStory(group.username),
                    child: SizedBox(
                      width: 70,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            width: 62,
                            height: 62,
                            padding: const EdgeInsets.all(2.5),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: group.hasUnviewed
                                  ? const LinearGradient(
                                      colors: [Color(0xFFF58529), Color(0xFFDD2A7B), Color(0xFF8134AF)],
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                    )
                                  : null,
                              color: group.hasUnviewed ? null : kWhite24,
                            ),
                            child: Container(
                              padding: const EdgeInsets.all(2),
                              decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                color: kCardAlt,
                              ),
                              child: ClipOval(
                                child: first.mediaType == 'image' && first.mediaUrl.isNotEmpty
                                    ? Image.network(
                                        first.mediaUrl,
                                        fit: BoxFit.cover,
                                        errorBuilder: (_, __, ___) => Text(
                                          group.username.isNotEmpty
                                              ? group.username[0].toUpperCase()
                                              : '?',
                                          style: const TextStyle(
                                            color: kWhite,
                                            fontSize: 20,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      )
                                    : Center(
                                        child: Text(
                                          group.username.isNotEmpty
                                              ? group.username[0].toUpperCase()
                                              : '?',
                                          style: const TextStyle(
                                            color: kWhite,
                                            fontSize: 20,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            group.username,
                            style: const TextStyle(
                              color: kWhite,
                              fontSize: 10,
                              fontWeight: FontWeight.w400,
                            ),
                            overflow: TextOverflow.ellipsis,
                            maxLines: 1,
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
      ),
    );
  }

  // ─── TARGET DASHBOARD / SOCIAL-STYLE HOME ────────────────────────────────
  // Visual rework only: existing feature widgets are kept and rendered below
  // the new hero/system area so no navigation or feature callback is removed.
  Widget _buildHomePage() {
    return FadeTransition(
      opacity: _fadeAnim,
      child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.only(top: 4, bottom: 18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildInstagramStories(),
            const SizedBox(height: 10),
            _buildTargetHeroBanner(),
            const SizedBox(height: 10),
            _buildDeveloperMessageCard(),
            const SizedBox(height: 12),
            _buildTargetProfileCard(),
            const SizedBox(height: 12),
            _buildTargetSystemCard(),
            const SizedBox(height: 14),
            // Existing features remain available; they are simply placed
            // below the compact hero area to match the requested reference.
            _buildDailyMotivation(),
            const SizedBox(height: 12),
            _buildQuickActionsSection(),
            const SizedBox(height: 14),
            _buildLatestUpdates(),
            const SizedBox(height: 14),
            _buildPrayerSection(),
            const SizedBox(height: 14),
            _buildHadithSection(),
            const SizedBox(height: 24),
            Center(
              child: Text(
                'DARK LIGHT',
                style: TextStyle(
                  color: kWhite.withOpacity(0.12),
                  fontSize: 13,
                  letterSpacing: 4,
                  fontFamily: 'Orbitron',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTargetHeroBanner() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(23),
            child: SizedBox(
              height: 188,
              width: double.infinity,
              child: PageView.builder(
                controller: _bannerCtrl,
                onPageChanged: (i) => setState(() => _bannerIndex = i),
                itemCount: 2,
                itemBuilder: (context, i) {
                  final asset = i == 0
                      ? 'assets/images/ornes_1.png'
                      : 'assets/images/ornes_2.png';
                  return Stack(
                    fit: StackFit.expand,
                    children: [
                      Image.asset(
                        asset,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(color: kCard),
                      ),
                      Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Colors.black.withOpacity(0.06),
                              Colors.black.withOpacity(0.10),
                              Colors.black.withOpacity(0.76),
                            ],
                          ),
                        ),
                      ),
                      Positioned(
                        top: 10,
                        right: 12,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.44),
                            borderRadius: BorderRadius.circular(18),
                            border: Border.all(color: kNeonGold.withOpacity(0.65)),
                          ),
                          child: const Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              _AnimatedDot(color: kNeonGold, size: 5),
                              SizedBox(width: 6),
                              Text(
                                'LIVE',
                                style: TextStyle(
                                  color: kNeonGold,
                                  fontSize: 9,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 1.2,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Positioned(
                        left: 18,
                        bottom: 18,
                        child: Row(
                          children: [
                            Container(
                              width: 42,
                              height: 42,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.black.withOpacity(0.38),
                                border: Border.all(color: kWhite.withOpacity(0.35)),
                              ),
                              child: const Icon(Icons.directions_car_filled_rounded,
                                  color: kWhite, size: 22),
                            ),
                            const SizedBox(width: 10),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'ZIXTER NIGHT',
                                  style: TextStyle(
                                    color: kWhite.withOpacity(0.9),
                                    fontFamily: 'Orbitron',
                                    fontWeight: FontWeight.w700,
                                    fontSize: 11,
                                    letterSpacing: 2.2,
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Text(
                                  i == 0 ? 'DASHBOARD PERFORMANCE' : 'BMW EDITION',
                                  style: const TextStyle(
                                    color: kWhite,
                                    fontFamily: 'Orbitron',
                                    fontWeight: FontWeight.bold,
                                    fontSize: 14,
                                    letterSpacing: 0.8,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(
              2,
              (i) => AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                margin: const EdgeInsets.symmetric(horizontal: 3),
                width: _bannerIndex == i ? 22 : 6,
                height: 5,
                decoration: BoxDecoration(
                  color: _bannerIndex == i ? kWhite : kWhite24,
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDeveloperMessageCard() {
    if (!_developerMessageVisible) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.fromLTRB(12, 12, 10, 12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          gradient: const LinearGradient(
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
            colors: [Color(0xFF1464C5), Color(0xFF0B4DA5)],
          ),
          boxShadow: [
            BoxShadow(color: kBlue.withOpacity(0.25), blurRadius: 18, offset: const Offset(0, 8)),
          ],
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: kWhite.withOpacity(0.14),
                border: Border.all(color: kWhite.withOpacity(0.18)),
              ),
              child: const Icon(Icons.mail_rounded, color: kWhite, size: 22),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: kWhite.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Text('PESAN DEVELOPER',
                            style: TextStyle(color: kWhite, fontSize: 8, fontWeight: FontWeight.bold, letterSpacing: 0.7)),
                      ),
                      const SizedBox(width: 7),
                      Text('dari $username',
                          style: TextStyle(color: kWhite.withOpacity(0.7), fontSize: 9)),
                    ],
                  ),
                  const SizedBox(height: 6),
                  const Text('Pesan dari Developer',
                      style: TextStyle(color: kWhite, fontSize: 14, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 4),
                  const Text(
                    'Jangan lupa nimbrung chat global yah.',
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: Colors.white70, fontSize: 10, height: 1.45),
                  ),
                  const SizedBox(height: 5),
                  Text('ZIXTER NIGHT V7', style: TextStyle(color: kWhite.withOpacity(0.66), fontSize: 9)),
                ],
              ),
            ),
            Column(
              children: [
                const Padding(
                  padding: EdgeInsets.only(top: 2),
                  child: Icon(Icons.volume_up_rounded, color: kWhite, size: 20),
                ),
                const SizedBox(height: 12),
                GestureDetector(
                  onTap: () => setState(() => _developerMessageVisible = false),
                  child: Icon(Icons.close_rounded, color: kWhite.withOpacity(0.72), size: 19),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTargetProfileCard() {
    final exp = expiredDate.trim().isEmpty ? 'PERMANENT' : expiredDate.split(' ').first;
    final roleColor = _roleColor(role);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: Container(
          height: 292,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: kWhite.withOpacity(0.18)),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.38), blurRadius: 24, offset: const Offset(0, 12))],
          ),
          child: Stack(
            fit: StackFit.expand,
            children: [
              Image.asset('assets/images/user_card.jpg', fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(color: kCard)),
              Container(color: Colors.black.withOpacity(0.56)),
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.black.withOpacity(0.12), Colors.black.withOpacity(0.82)],
                  ),
                ),
              ),
              Positioned(
                left: 18,
                top: 18,
                right: 18,
                child: Row(
                  children: [
                    Container(
                      width: 58,
                      height: 58,
                      padding: const EdgeInsets.all(2),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: kWhite.withOpacity(0.8),
                        boxShadow: [BoxShadow(color: kBlue.withOpacity(0.35), blurRadius: 15)],
                      ),
                      child: ClipOval(
                        child: _profileImage != null
                            ? Image.file(_profileImage!, fit: BoxFit.cover)
                            : Image.asset('assets/images/logo.png', fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => const Icon(Icons.person, color: kBg)),
                      ),
                    ),
                    const SizedBox(width: 11),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Ahlan Wa Sahlan,', style: TextStyle(color: kWhite.withOpacity(0.72), fontSize: 10)),
                          const SizedBox(height: 1),
                          Text(username,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(color: kWhite, fontSize: 20, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
                          const SizedBox(height: 5),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: roleColor.withOpacity(0.12),
                              borderRadius: BorderRadius.circular(13),
                              border: Border.all(color: roleColor.withOpacity(0.65)),
                            ),
                            child: Text(role.toUpperCase(),
                                style: TextStyle(color: roleColor, fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1.2)),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Positioned(
                left: 28,
                right: 28,
                top: 112,
                child: Container(
                  height: 44,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.07),
                    borderRadius: BorderRadius.circular(23),
                    border: Border.all(color: kWhite.withOpacity(0.18)),
                  ),
                  child: const Center(
                    child: Text('Spesial Apk By @DIZT_ZIXTER',
                        style: TextStyle(color: kWhite, fontSize: 12, fontFamily: 'Orbitron', letterSpacing: 2.2)),
                  ),
                ),
              ),
              Positioned(
                left: 18,
                right: 18,
                bottom: 18,
                child: Row(
                  children: [
                    _buildTargetCircleStat(Icons.people_alt_rounded, '$onlineUsers', 'Total Users', kNeonGreen),
                    _buildTargetCircleStat(Icons.link_rounded, '$activeConns', 'Dev', kNeonCyan),
                    _buildTargetCircleStat(Icons.calendar_month_rounded, exp.toUpperCase(), 'Expired', kNeonGold),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTargetCircleStat(IconData icon, String value, String label, Color color) {
    return Expanded(
      child: Column(
        children: [
          Container(
            width: 55,
            height: 55,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.black.withOpacity(0.30),
              border: Border.all(color: kWhite.withOpacity(0.34), width: 1.2),
              boxShadow: [BoxShadow(color: color.withOpacity(0.18), blurRadius: 14)],
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                Icon(icon, color: kWhite, size: 21),
                Positioned(
                  right: 7,
                  top: 7,
                  child: Container(width: 7, height: 7,
                      decoration: BoxDecoration(shape: BoxShape.circle, color: color,
                          boxShadow: [BoxShadow(color: color, blurRadius: 7)])),
                ),
              ],
            ),
          ),
          const SizedBox(height: 4),
          Text(value,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: const TextStyle(color: kWhite, fontSize: 12, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
          const SizedBox(height: 1),
          Text(label, style: TextStyle(color: kWhite.withOpacity(0.66), fontSize: 8)),
        ],
      ),
    );
  }

  Widget _buildTargetSystemCard() {
    final device = '${deviceManufacturer.isNotEmpty ? deviceManufacturer : 'Android'} ${deviceModel.isNotEmpty ? deviceModel : 'Device'}';
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(23),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(23),
            border: Border.all(color: kWhite.withOpacity(0.12)),
          ),
          child: Stack(
            children: [
              Positioned.fill(
                child: Image.asset('assets/images/background.jpg', fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => const SizedBox()),
              ),
              Positioned.fill(child: Container(color: Colors.black.withOpacity(0.76))),
              Positioned.fill(child: CustomPaint(painter: _GridPatternPainter(
                gridColor: kNeonCyan.withOpacity(0.045),
                lineColor: kWhite.withOpacity(0.015),
                spacing: 35,
              ))),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 17, 16, 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Text('SYSTEM', style: TextStyle(color: kWhite, fontSize: 15, fontFamily: 'Orbitron', letterSpacing: 1.4)),
                        const SizedBox(width: 7),
                        const _AnimatedDot(color: kNeonGreen, size: 7),
                        const Spacer(),
                        Text(role.toUpperCase(), style: const TextStyle(color: kNeonGold, fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1.1)),
                      ],
                    ),
                    const SizedBox(height: 2),
                    Text(
                      device,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: kWhite.withOpacity(0.48), fontSize: 9),
                    ),
                    const SizedBox(height: 15),
                    Row(
                      children: [
                        _buildSystemRing('Charging', batteryLevel, 0.44, kNeonGreen),
                        _buildSystemRing('Signal', signalStrength, 0.85, kNeonCyan),
                        _buildSystemRing('RAM', ramUsage, 0.62, kNeonPurple),
                        _buildSystemRing('Storage', storageUsage, 0.86, kNeonGold),
                      ],
                    ),
                    const SizedBox(height: 16),
                    _buildTargetSystemRow(Icons.people_alt_rounded, 'Online users', '$onlineUsers aktif', kNeonGreen),
                    _buildTargetSystemRow(Icons.hub_rounded, 'Connections', '$activeConns active', kNeonCyan),
                    _buildTargetSystemRow(Icons.timer_outlined, 'Session time', sessionTime, kNeonPurple),
                    _buildTargetSystemRow(Icons.key_rounded, 'Session key', sessionKey, kNeonGold),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSystemRing(String label, String value, double progress, Color color) {
    return Expanded(
      child: Column(
        children: [
          SizedBox(
            width: 64,
            height: 64,
            child: Stack(
              alignment: Alignment.center,
              children: [
                SizedBox(
                  width: 64,
                  height: 64,
                  child: CircularProgressIndicator(
                    value: progress.clamp(0.0, 1.0),
                    strokeWidth: 4,
                    backgroundColor: kWhite.withOpacity(0.08),
                    valueColor: AlwaysStoppedAnimation<Color>(color),
                  ),
                ),
                Text(value,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: kWhite, fontSize: 10, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
              ],
            ),
          ),
          const SizedBox(height: 5),
          Text(label, style: TextStyle(color: kWhite.withOpacity(0.62), fontSize: 8)),
        ],
      ),
    );
  }

  Widget _buildTargetSystemRow(IconData icon, String label, String value, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 11),
      decoration: BoxDecoration(
        border: Border(top: BorderSide(color: kWhite.withOpacity(0.07))),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 18),
          const SizedBox(width: 12),
          Expanded(child: Text(label, style: TextStyle(color: kWhite.withOpacity(0.58), fontSize: 11))),
          const SizedBox(width: 8),
          Flexible(
            child: Text(value,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.right,
                style: const TextStyle(color: kWhite, fontSize: 10, fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }

  Widget _buildBannerVideo() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Column(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(22),
            child: SizedBox(
              height: 168,
              width: double.infinity,
              child: PageView.builder(
                controller: _bannerCtrl,
                onPageChanged: (i) => setState(() => _bannerIndex = i),
                itemCount: 2,
                itemBuilder: (ctx, i) => Stack(
                  fit: StackFit.expand,
                  children: [
                    Image.asset(
                      i == 0 ? 'assets/images/ornes_1.png' : 'assets/images/ornes_2.png',
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(color: kNavyPanel),
                    ),
                    Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.bottomCenter,
                          end: Alignment.topCenter,
                          colors: [
                            Colors.black.withOpacity(0.72),
                            Colors.black.withOpacity(0.12),
                            Colors.transparent,
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 18,
                      bottom: 16,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'WELCOME BACK',
                            style: TextStyle(
                              color: kNeonGreen,
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 2.2,
                              fontFamily: 'Orbitron',
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            username,
                            style: const TextStyle(
                              color: kWhite,
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Orbitron',
                            ),
                          ),
                        ],
                      ),
                    ),
                    Positioned(
                      right: 14,
                      top: 12,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
                        decoration: BoxDecoration(
                          color: kNeonGreen.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: kNeonGreen.withOpacity(0.55)),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const _AnimatedDot(color: kNeonGreen, size: 6),
                            const SizedBox(width: 6),
                            Text('ONLINE', style: TextStyle(color: kNeonGreen, fontSize: 9, fontWeight: FontWeight.bold)),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(2, (i) => AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              margin: const EdgeInsets.symmetric(horizontal: 3),
              width: _bannerIndex == i ? 22 : 6,
              height: 5,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5),
                color: _bannerIndex == i ? kNeonGreen : kWhite24,
              ),
            )),
          ),
        ],
      ),
    );
  }

  Widget _buildWelcomeCard() {
    final roleLower = role.toLowerCase();
    final roleColor = roleLower == 'owner' ? kNeonPurple : _roleColor(role);
    final exp = expiredDate.trim().isEmpty ? 'PERMANENT' : expiredDate.split(' ').first;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF101A31), Color(0xFF0B1020)],
          ),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: kNeonPurple.withOpacity(0.34)),
          boxShadow: [BoxShadow(color: kNeonGreen.withOpacity(0.07), blurRadius: 26, spreadRadius: 1)],
        ),
        child: Column(
          children: [
            Row(
              children: [
                ScaleTransition(
                  scale: _pulseAnim,
                  child: Container(
                    width: 62,
                    height: 62,
                    padding: const EdgeInsets.all(2),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const LinearGradient(colors: [kNeonGreen, kNeonPurple]),
                      boxShadow: [BoxShadow(color: kNeonGreen.withOpacity(0.28), blurRadius: 18)],
                    ),
                    child: ClipOval(
                      child: _profileImage != null
                          ? Image.file(_profileImage!, fit: BoxFit.cover)
                          : Image.asset('assets/images/logo.png', fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => const Icon(Icons.person_rounded, color: kWhite, size: 28)),
                    ),
                  ),
                ),
                const SizedBox(width: 13),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Selamat Datang,', style: TextStyle(color: kWhite54, fontSize: 11, fontFamily: 'Orbitron')),
                      const SizedBox(height: 3),
                      Text(username, style: const TextStyle(color: kWhite, fontSize: 19, fontWeight: FontWeight.bold, fontFamily: 'Orbitron'), overflow: TextOverflow.ellipsis),
                      const SizedBox(height: 7),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: roleColor.withOpacity(0.10),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: roleColor.withOpacity(0.55)),
                        ),
                        child: Text(role.toUpperCase(), style: TextStyle(color: roleColor, fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1.4)),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 9),
                  decoration: BoxDecoration(
                    color: kNeonGold.withOpacity(0.07),
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(color: kNeonGold.withOpacity(0.45)),
                  ),
                  child: Column(
                    children: [
                      const Icon(Icons.power_settings_new_rounded, color: kNeonGold, size: 15),
                      const SizedBox(height: 3),
                      const Text('EXPIRES', style: TextStyle(color: kNeonGold, fontSize: 7, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 2),
                      Text(exp.toUpperCase(), style: const TextStyle(color: kNeonGold, fontSize: 9, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(17),
                color: kNeonGreen.withOpacity(0.025),
                border: Border.all(color: kNeonGreen.withOpacity(0.18)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const _AnimatedDot(color: kNeonGreen),
                  const SizedBox(width: 9),
                  Text('POWERED BY ZIXTER NIGHT V8', style: TextStyle(color: kNeonGreen.withOpacity(0.85), fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1.3, fontFamily: 'Orbitron')),
                  const SizedBox(width: 9),
                  const _AnimatedDot(color: kNeonGreen),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCircleStatItem({
    required IconData icon,
    required String value,
    required String label,
    required Color color,
  }) {
    return Expanded(
      child: Column(
        children: [
          Container(
            width: 62, height: 62,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color.withOpacity(0.12),
              border: Border.all(color: color.withOpacity(0.5), width: 2),
              boxShadow: [BoxShadow(color: color.withOpacity(0.3), blurRadius: 22, spreadRadius: 2)],
            ),
            child: Center(child: Icon(icon, color: color, size: 28)),
          ),
          const SizedBox(height: 8),
          Text(value,
              style: const TextStyle(
                  color: kWhite, fontWeight: FontWeight.bold, fontSize: 13, fontFamily: 'Orbitron')),
          const SizedBox(height: 2),
          Text(label, style: const TextStyle(color: kWhite54, fontSize: 9), textAlign: TextAlign.center),
        ],
      ),
    );
  }

  Widget _buildStatDivider() =>
      Container(width: 1, height: 60, color: kBorder.withOpacity(0.5));

  Widget _buildSystemInfoCard() {
    final exp = expiredDate.trim().isEmpty ? 'PERMANENT' : expiredDate.split(' ').first;
    final device = '${deviceManufacturer.isNotEmpty ? deviceManufacturer : 'Android'} ${deviceModel.isNotEmpty ? deviceModel : 'Device'}';
    final network = signalStrength.isNotEmpty ? 'WiFi / $signalStrength' : 'Unknown';

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: kNavyPanel.withOpacity(0.96),
          borderRadius: BorderRadius.circular(23),
          border: Border.all(color: kNeonGreen.withOpacity(0.24)),
          boxShadow: [BoxShadow(color: kNeonGreen.withOpacity(0.06), blurRadius: 28, spreadRadius: 1)],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 34, height: 34,
                  decoration: BoxDecoration(color: kNeonGreen.withOpacity(0.10), borderRadius: BorderRadius.circular(10), border: Border.all(color: kNeonGreen.withOpacity(0.3))),
                  child: const Icon(Icons.grid_view_rounded, color: kNeonGreen, size: 19),
                ),
                const SizedBox(width: 10),
                const Expanded(child: Text('DASHBOARD', style: TextStyle(color: kWhite, fontSize: 16, fontWeight: FontWeight.bold, fontFamily: 'Orbitron', letterSpacing: 1.2))),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(color: kNeonPurple.withOpacity(0.10), borderRadius: BorderRadius.circular(15), border: Border.all(color: kNeonPurple.withOpacity(0.45))),
                  child: Text(exp.toUpperCase(), style: const TextStyle(color: kNeonPurple, fontSize: 8, fontWeight: FontWeight.bold, letterSpacing: 1)),
                ),
              ],
            ),
            const SizedBox(height: 13),
            const Text('Remaining Time', style: TextStyle(color: kWhite54, fontSize: 10, fontFamily: 'Orbitron')),
            const SizedBox(height: 7),
            Row(
              children: [
                Expanded(child: Container(height: 7, decoration: BoxDecoration(borderRadius: BorderRadius.circular(8), color: kNeonPurple.withOpacity(0.12)), child: FractionallySizedBox(alignment: Alignment.centerLeft, widthFactor: 1, child: Container(decoration: BoxDecoration(borderRadius: BorderRadius.circular(8), color: kNeonPurple))))),
                const SizedBox(width: 10),
                Text(exp.toUpperCase(), style: const TextStyle(color: kNeonPurple, fontSize: 9, fontWeight: FontWeight.bold)),
              ],
            ),
            const SizedBox(height: 14),
            _buildDashboardGrid([
              _DashStat(Icons.workspace_premium_rounded, 'ROLE', role.toUpperCase(), kNeonPurple),
              _DashStat(Icons.calendar_month_rounded, 'EXPIRED', exp.toUpperCase(), kNeonGold),
              _DashStat(Icons.people_alt_rounded, 'ONLINE', '$onlineUsers Users', kNeonGreen),
              _DashStat(Icons.phone_android_rounded, 'DEVICE', device, const Color(0xFF25D6C8)),
              _DashStat(Icons.battery_full_rounded, 'BATTERY', batteryLevel, kNeonGreen),
              _DashStat(Icons.wifi_rounded, 'NETWORK', network, const Color(0xFF48A8FF)),
              _DashStat(Icons.memory_rounded, 'RAM', ramUsage, const Color(0xFF55D6FF)),
              _DashStat(Icons.storage_rounded, 'STORAGE', storageUsage, const Color(0xFFB66CFF)),
              _DashStat(Icons.android_rounded, 'SYSTEM', androidVersion.isNotEmpty ? androidVersion : 'API 36', kNeonGreen),
              _DashStat(Icons.key_rounded, 'SESSION', sessionKey, kNeonGold),
              _DashStat(Icons.link_rounded, 'CONN', '$activeConns Active', const Color(0xFF37D7FF)),
              _DashStat(Icons.access_time_rounded, 'TIME', sessionTime, kNeonPurple),
            ]),
          ],
        ),
      ),
    );
  }

  Widget _buildDashboardGrid(List<_DashStat> stats) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: stats.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 8,
        mainAxisSpacing: 8,
        childAspectRatio: 1.15,
      ),
      itemBuilder: (_, i) {
        final s = stats[i];
        return Container(
          padding: const EdgeInsets.fromLTRB(9, 9, 8, 8),
          decoration: BoxDecoration(
            color: const Color(0xFF101729),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: s.color.withOpacity(0.28)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(s.icon, color: s.color, size: 15),
              const SizedBox(height: 5),
              Text(s.label, style: TextStyle(color: s.color.withOpacity(0.8), fontSize: 8, fontWeight: FontWeight.bold, letterSpacing: 0.8), maxLines: 1, overflow: TextOverflow.ellipsis),
              const Spacer(),
              Text(s.value, style: const TextStyle(color: kWhite, fontSize: 10, fontWeight: FontWeight.w600), maxLines: 2, overflow: TextOverflow.ellipsis),
            ],
          ),
        );
      },
    );
  }

  Widget _buildDailyMotivation() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [kNeonGreen.withOpacity(0.18), const Color(0xFF06251C)]),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: kNeonGreen.withOpacity(0.28)),
        ),
        child: Row(
          children: [
            Container(width: 42, height: 42, decoration: BoxDecoration(color: kNeonGreen.withOpacity(0.12), borderRadius: BorderRadius.circular(13)), child: const Center(child: Text('“', style: TextStyle(color: kNeonGreen, fontSize: 28, fontWeight: FontWeight.bold)))),
            const SizedBox(width: 12),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('✦ MOTIVASI HARIAN', style: TextStyle(color: kNeonGreen, fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1.1, fontFamily: 'Orbitron')), SizedBox(height: 5), Text('Hari ini lebih baik dari kemarin.', style: TextStyle(color: kWhite, fontSize: 12))])),
          ],
        ),
      ),
    );
  }

  Widget _buildSystemInfoItem(IconData icon, String label, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        color: kBg,
        border: Border.all(color: kBorder.withOpacity(0.5)),
      ),
      child: Row(
        children: [
          Icon(icon, color: kWhite54, size: 14),
          const SizedBox(width: 6),
          Text(label, style: const TextStyle(color: kWhite54, fontSize: 11)),
          const Spacer(),
          Text(value, style: const TextStyle(color: kWhite, fontSize: 12, fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }

  Widget _buildPlayerInfoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Icon(icon, color: kWhite54, size: 14),
          const SizedBox(width: 8),
          Text(label, style: const TextStyle(color: kWhite54, fontSize: 11)),
          const Spacer(),
          Text(value, style: const TextStyle(color: kWhite, fontSize: 12)),
        ],
      ),
    );
  }

  Widget _buildQuickActionsSection() {
    final actions = [
      _QuickActionData(
        icon: FontAwesomeIcons.whatsapp,
        bgIcon: FontAwesomeIcons.whatsapp,
        title: 'Manage Sender',
        subtitle: 'Manage your active sender',
        gradient: [const Color(0xFF9B59B6), const Color(0xFF2C0845)],
        onTap: () => Navigator.push(
          context,
          _slideRoute(BugSenderPage(sessionKey: sessionKey, username: username, role: role)),
        ).then((_) {
          if (mounted && _newsPageCtrl.hasClients) {
            setState(() { _currentNewsPage = 0.0; _newsPageViewKey++; });
            _newsPageCtrl.jumpToPage(0);
          }
        }),
      ),
      _QuickActionData(
        icon: Icons.chat_bubble_rounded,
        bgIcon: Icons.chat_bubble_rounded,
        title: 'Chat Room',
        subtitle: 'Global chat room',
        gradient: [const Color(0xFF0D7377), const Color(0xFF14FFEC)],
        onTap: () => Navigator.push(context, _slideRoute(ChatRoomPage(username: username, sessionKey: sessionKey))),
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.telegram,
        bgIcon: FontAwesomeIcons.telegram,
        title: 'Join Channel',
        subtitle: 'Info Channel',
        gradient: [const Color(0xFF0077B6), const Color(0xFF29B6F6)],
        onTap: () => _openUrl('https://t.me/zixter88'),
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.bookQuran,
        bgIcon: FontAwesomeIcons.bookQuran,
        title: 'Al Quran',
        subtitle: 'Baca Al-Quran & Doa',
        gradient: [const Color(0xFF1A4731), const Color(0xFF22C55E)],
        onTap: () => Navigator.push(context, _slideRoute(AlQuranPage())),
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.tv,
        bgIcon: FontAwesomeIcons.tv,
        title: 'Anime',
        subtitle: 'Discover & Watch Anime',
        gradient: [const Color(0xFF4A0020), const Color(0xFFFF1744)],
        onTap: () => Navigator.push(context, _slideRoute(HomeAnimePage())),
      ),
      _QuickActionData(
        icon: Icons.sports_esports_rounded,
        bgIcon: Icons.sports_esports_rounded,
        title: 'Game Ular',
        subtitle: 'Mini game seru',
        gradient: [const Color(0xFF1A3A1A), const Color(0xFF4CAF50)],
        onTap: () => Navigator.push(context, _slideRoute(const SnakeGame())),
      ),
    ];

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Row(
            children: [
              Container(
                width: 44, height: 44,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  color: const Color(0xFFFFD700).withOpacity(0.12),
                  border: Border.all(color: const Color(0xFFFFD700).withOpacity(0.3)),
                ),
                child: const Icon(Icons.bolt_rounded, color: Color(0xFFFFD700), size: 22),
              ),
              const SizedBox(width: 12),
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('CONNECT WITH ZIXTER NIGHT V8',
                      style: TextStyle(
                        color: kWhite, fontWeight: FontWeight.bold, fontSize: 15,
                        fontFamily: 'Orbitron', letterSpacing: 1)),
                  Text('Selalu nantikan project terbaru dari @DIZT_ZIXTER',
                      style: TextStyle(color: kWhite54, fontSize: 12)),
                ],
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: const Color(0xFFFFD700).withOpacity(0.10),
                  border: Border.all(color: const Color(0xFFFFD700).withOpacity(0.35)),
                ),
                child: Row(children: [
                  Container(
                      width: 7, height: 7,
                      decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xFFFFD700))),
                  const SizedBox(width: 5),
                  const Text('DARK LIGHT',
                      style: TextStyle(color: Color(0xFFFFD700), fontSize: 11, fontWeight: FontWeight.bold)),
                ]),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        SizedBox(
          height: 180,
          child: PageView.builder(
            controller: _qaPageCtrl,
            itemCount: actions.length,
            onPageChanged: (index) {
              if (mounted) setState(() => _currentQaPage = index.toDouble());
            },
            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: _buildQuickActionCard(actions[index]),
              );
            },
          ),
        ),
        const SizedBox(height: 12),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(actions.length, (index) {
            final bool isActive = _currentQaPage.round() == index;
            return AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              margin: const EdgeInsets.symmetric(horizontal: 4),
              width: isActive ? 24 : 8,
              height: 8,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(4),
                color: isActive ? const Color(0xFFFFD700) : Colors.white24,
              ),
            );
          }),
        ),
      ],
    );
  }

  Widget _buildQuickActionCard(_QuickActionData action) {
    return GestureDetector(
      onTap: action.onTap,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: LinearGradient(
              colors: action.gradient,
              begin: Alignment.topLeft,
              end: Alignment.bottomRight),
          boxShadow: [
            BoxShadow(
                color: action.gradient.first.withOpacity(0.25),
                blurRadius: 24, offset: const Offset(0, 10))
          ],
        ),
        child: Stack(
          children: [
            Positioned(
              right: -12, bottom: -12,
              child: Icon(action.bgIcon, color: Colors.white.withOpacity(0.05), size: 110),
            ),
            Padding(
              padding: const EdgeInsets.all(22),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 50, height: 50,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle, color: Colors.white.withOpacity(0.15)),
                    child: Icon(action.icon, color: kWhite, size: 24),
                  ),
                  const Spacer(),
                  Align(
                    alignment: Alignment.topRight,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          color: Colors.white.withOpacity(0.15)),
                      child: const Text('Tap →',
                          style: TextStyle(color: kWhite, fontSize: 11, fontWeight: FontWeight.bold)),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(action.title,
                      style: const TextStyle(
                        color: kWhite, fontWeight: FontWeight.bold, fontSize: 17, fontFamily: 'Orbitron')),
                  const SizedBox(height: 4),
                  Text(action.subtitle,
                      style: TextStyle(color: kWhite.withOpacity(0.8), fontSize: 12)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLatestUpdates() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Row(
            children: [
              const Icon(Icons.dashboard_customize_rounded, color: kBlue, size: 22),
              const SizedBox(width: 8),
              const Text('BERITA TERKINI',
                  style: TextStyle(
                    color: kWhite, fontWeight: FontWeight.bold, fontSize: 15,
                    fontFamily: 'Orbitron', letterSpacing: 1)),
              const Spacer(),
              if (newsList.isNotEmpty)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: kBlue.withOpacity(0.15),
                    border: Border.all(color: kBlue.withOpacity(0.4)),
                  ),
                  child: Text('${newsList.length} Updates',
                      style: const TextStyle(
                          color: kBlue, fontSize: 11, fontWeight: FontWeight.bold)),
                ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        if (newsList.isNotEmpty)
          SizedBox(
            height: 200,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 14),
              itemCount: newsList.length,
              itemBuilder: (ctx, i) => _buildNewsCardHorizontal(newsList[i]),
            ),
          ),
        if (newsList.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: Container(
              height: 120,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  color: kCard,
                  border: Border.all(color: kBorder.withOpacity(0.4))),
              child: const Center(
                  child: Text('No updates available', style: TextStyle(color: kWhite54))),
            ),
          ),
      ],
    );
  }

  Widget _buildNewsCardHorizontal(dynamic item) {
    final imgUrl   = item['image']?.toString() ?? '';
    final title    = item['title']?.toString() ?? 'No Title';
    final date     = item['date']?.toString() ?? item['created_at']?.toString() ?? '';
    final cardWidth = (MediaQuery.of(context).size.width / 2) - 22;

    return Container(
      width: cardWidth,
      margin: const EdgeInsets.only(right: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        color: kCard,
        border: Border.all(color: kBorder.withOpacity(0.4)),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 12, offset: const Offset(0, 6))
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
            child: Stack(
              children: [
                Container(
                  height: 110, width: double.infinity, color: kCardAlt,
                  child: imgUrl.isNotEmpty
                      ? Image.network(imgUrl, fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => const Center(
                              child: Icon(Icons.image_not_supported, color: kWhite54, size: 30)))
                      : const Center(
                          child: Icon(Icons.article_rounded, color: kWhite54, size: 30)),
                ),
                Positioned(
                  top: 8, right: 8,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.black.withOpacity(0.65),
                      border: Border.all(color: kBlue.withOpacity(0.7)),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.circle_notifications_rounded, color: kBlue, size: 10),
                        SizedBox(width: 3),
                        Text('NEW',
                            style: TextStyle(
                                color: kBlue, fontSize: 9, fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 10, 10, 6),
            child: Text(title,
                style: const TextStyle(
                  color: kWhite, fontSize: 16, fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron', height: 1.3),
                maxLines: 2, overflow: TextOverflow.ellipsis),
          ),
          const Spacer(),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 0, 10, 10),
            child: Row(
              children: [
                const Icon(Icons.access_time_rounded, color: kWhite54, size: 11),
                const SizedBox(width: 4),
                if (date.isNotEmpty)
                  Expanded(
                    child: Text(
                        date.length > 10 ? date.substring(0, 10) : date,
                        style: const TextStyle(color: kWhite54, fontSize: 10)),
                  ),
                Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      color: kBlue.withOpacity(0.18)),
                  child: const Icon(Icons.arrow_forward_ios_rounded, color: kBlue, size: 9),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPrayerSection() {
    final prayerColors = [
      const Color(0xFF2D2D3D),
      const Color(0xFF3A3A4A),
      const Color(0xFF353545),
      const Color(0xFF252535),
      const Color(0xFF18181B),
    ];
    final prayerIcons = [
      Icons.nights_stay_rounded,
      Icons.wb_sunny_rounded,
      Icons.cloud_rounded,
      Icons.wb_twilight_rounded,
      Icons.nightlight_round,
    ];
    final prayerKeys = ['Subuh', 'Dzuhur', 'Ashar', 'Maghrib', 'Isya'];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: const Color(0xFF1C1C1E),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFF3A3A3C).withOpacity(0.5)),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.6), blurRadius: 18, offset: const Offset(0, 8))
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 48, height: 48,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    color: const Color(0xFF48484A).withOpacity(0.3),
                    border: Border.all(color: const Color(0xFF48484A).withOpacity(0.5)),
                  ),
                  child: const Center(child: Icon(Icons.mosque, color: Color(0xFF8E8E93), size: 26)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('JADWAL SHOLAT',
                          style: TextStyle(
                            color: Color(0xFFE5E5EA),
                            fontWeight: FontWeight.bold, fontSize: 15,
                            fontFamily: 'Orbitron', letterSpacing: 1)),
                      Text(_prayerCity,
                          style: const TextStyle(color: Color(0xFF636366), fontSize: 12)),
                    ],
                  ),
                ),
                GestureDetector(
                  onTap: _locationLoading ? null : _detectLocationAndFetchPrayer,
                  child: Container(
                    width: 38, height: 38,
                    margin: const EdgeInsets.only(right: 8),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _locationGranted
                          ? const Color(0xFF48484A).withOpacity(0.3)
                          : const Color(0xFF2C2C2E).withOpacity(0.5),
                      border: Border.all(
                        color: _locationGranted
                            ? const Color(0xFF48484A).withOpacity(0.6)
                            : const Color(0xFF3A3A3C).withOpacity(0.3),
                      ),
                    ),
                    child: _locationLoading
                        ? const Padding(
                            padding: EdgeInsets.all(10),
                            child: CircularProgressIndicator(color: Color(0xFF8E8E93), strokeWidth: 2),
                          )
                        : Icon(
                            _locationGranted
                                ? Icons.my_location_rounded
                                : Icons.location_searching_rounded,
                            color: _locationGranted ? const Color(0xFF8E8E93) : const Color(0xFF48484A),
                            size: 18,
                          ),
                  ),
                ),
                GestureDetector(
                  onTap: _showChangeCityDialog,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: const Color(0xFF3A3A3C),
                    ),
                    child: const Row(children: [
                      Icon(Icons.edit_location_alt_rounded, color: Color(0xFFE5E5EA), size: 14),
                      SizedBox(width: 5),
                      Text('GANTI',
                          style: TextStyle(
                              color: Color(0xFFE5E5EA), fontSize: 12, fontWeight: FontWeight.bold)),
                    ]),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),

            if (_nextPrayerLabel.isNotEmpty)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30),
                  color: const Color(0xFF2C2C2E),
                  border: Border.all(color: const Color(0xFF48484A).withOpacity(0.6)),
                ),
                child: Row(
                  children: [
                    ScaleTransition(
                      scale: _pulseAnim,
                      child: _AnimatedDot(color: const Color(0xFF8E8E93), size: 10),
                    ),
                    const SizedBox(width: 10),
                    Text('Menuju $_nextPrayerLabel : $_nextPrayerTime',
                        style: const TextStyle(
                          color: Color(0xFFE5E5EA), fontSize: 13, fontWeight: FontWeight.w600,
                          fontFamily: 'Orbitron')),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: const Color(0xFF636366).withOpacity(0.5)),
                      ),
                      child: const Text('NYTHER',
                          style: TextStyle(color: Color(0xFF636366), fontSize: 10, fontWeight: FontWeight.bold)),
                    ),
                  ],
                ),
              ),
            const SizedBox(height: 14),

            if (_prayerLoading)
              const Center(child: CircularProgressIndicator(color: Color(0xFF8E8E93), strokeWidth: 2))
            else
              SizedBox(
                height: 118,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  physics: const BouncingScrollPhysics(),
                  itemCount: prayerKeys.length,
                  itemBuilder: (ctx, i) {
                    final key   = prayerKeys[i];
                    final time  = _prayerTimes[key] ?? '--:--';
                    final color = prayerColors[i];
                    final icon  = prayerIcons[i];
                    final isNext = key == _nextPrayerLabel;
                    return AnimatedContainer(
                      duration: const Duration(milliseconds: 400),
                      curve: Curves.easeOut,
                      margin: EdgeInsets.only(right: 10, bottom: isNext ? 0 : 6, top: isNext ? 0 : 6),
                      width: 105,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(18),
                        color: color,
                        boxShadow: [
                          BoxShadow(
                              color: color.withOpacity(isNext ? 0.65 : 0.3),
                              blurRadius: isNext ? 18 : 8, offset: const Offset(0, 4))
                        ],
                        border: isNext
                            ? Border.all(color: const Color(0xFF636366).withOpacity(0.8), width: 1.5)
                            : null,
                      ),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(icon, color: const Color(0xFFE5E5EA), size: 24),
                            const SizedBox(height: 5),
                            Text(key.toUpperCase(),
                                style: const TextStyle(
                                    color: Color(0xFF8E8E93), fontSize: 9,
                                    fontWeight: FontWeight.bold, letterSpacing: 0.8)),
                            const SizedBox(height: 5),
                            Text(time,
                                style: const TextStyle(
                                    color: Color(0xFFE5E5EA), fontSize: 19,
                                    fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildHadithSection() {
    if (_hadithLoading) {
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Container(
          height: 200,
          decoration: BoxDecoration(
            color: kCard, borderRadius: BorderRadius.circular(20),
            border: Border.all(color: kBorder.withOpacity(0.5)),
          ),
          child: const Center(child: CircularProgressIndicator(color: kBlue, strokeWidth: 2)),
        ),
      );
    }

    final arabic = _hadith?['data']?['text']?['ar'] ??
        'إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ، وَإِنَّمَا لِكُلِّ امْرِئٍ مَا نَوَى';
    final indo   = _hadith?['data']?['text']?['id'] ??
        'Sesungguhnya setiap amalan tergantung pada niatnya.';
    final number = _hadith?['data']?['id']?.toString() ?? '1';
    final source = _hadith?['data']?['source']?.toString() ?? 'Muslim';
    final grade  = _hadith?['data']?['grade']?.toString() ?? 'Sahih Muslim';

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: kCard, borderRadius: BorderRadius.circular(20),
          border: Border.all(color: kBorder.withOpacity(0.5)),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 18, offset: const Offset(0, 8))
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 50, height: 50,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle, color: kBlue.withOpacity(0.18)),
                  child: const Center(child: Icon(Icons.menu_book_rounded, color: kBlue, size: 26)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('HADITH OF THE DAY',
                        style: TextStyle(
                          color: kWhite, fontWeight: FontWeight.bold, fontSize: 15,
                          fontFamily: 'Orbitron', letterSpacing: 0.5)),
                    const SizedBox(height: 2),
                    Text('$grade · Tap card to read full',
                        style: const TextStyle(color: kWhite54, fontSize: 11)),
                  ]),
                ),
              ],
            ),
            const SizedBox(height: 14),
            GestureDetector(
              onTap: () => _showHadithFullDialog(arabic, indo, source, number, grade),
              child: Column(
                children: [
                  Container(
                    width: double.infinity, padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(14),
                      color: const Color(0xFF18181B),
                      border: Border.all(color: kBorder.withOpacity(0.3)),
                    ),
                    child: Text(arabic,
                        textAlign: TextAlign.right, textDirection: TextDirection.rtl,
                        style: const TextStyle(color: kWhite, fontSize: 17, height: 2.0)),
                  ),
                  const SizedBox(height: 10),
                  Container(
                    width: double.infinity, padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(14), color: const Color(0xFF111113)),
                    child: Text(indo,
                        style: const TextStyle(
                          color: kWhite54, fontSize: 12, fontStyle: FontStyle.italic, height: 1.7),
                        maxLines: 3, overflow: TextOverflow.ellipsis),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: kBlue.withOpacity(0.45)),
                    color: kBlue.withOpacity(0.07),
                  ),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.receipt_long_rounded, color: kBlue, size: 13),
                    const SizedBox(width: 5),
                    Text('${source.isNotEmpty ? source : "Muslim"} #$number',
                        style: const TextStyle(
                            color: kBlue, fontSize: 11, fontWeight: FontWeight.bold)),
                  ]),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: _fetchRandomHadith,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: kWhite54.withOpacity(0.3)),
                    ),
                    child: const Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(Icons.touch_app_rounded, color: kWhite54, size: 14),
                      SizedBox(width: 4),
                      Text('Tap card', style: TextStyle(color: kWhite54, fontSize: 11)),
                    ]),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      extendBodyBehindAppBar: false,
      appBar: _buildAppBar(),
      drawer: _buildDrawer(),
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset('assets/images/background.jpg', fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const SizedBox()),
          ),
          Positioned.fill(
            child: Container(color: Colors.black.withOpacity(0.75)),
          ),
          _buildBackgroundGrid(),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 350),
            transitionBuilder: (child, anim) =>
                FadeTransition(opacity: anim, child: child),
            child: KeyedSubtree(
              key: ValueKey(_navIndex),
              child: _buildCurrentPage(),
            ),
          ),
        ],
      ),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  Widget _buildBackgroundGrid() {
    return CustomPaint(
      size: Size.infinite,
      painter: _GridPatternPainter(
        gridColor: kBlue.withOpacity(0.04),
        lineColor: kPink.withOpacity(0.02),
        spacing: 35,
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: kBg.withOpacity(0.95),
      elevation: 0,
      iconTheme: const IconThemeData(color: kWhite),
      titleSpacing: 0,
      flexibleSpace: Container(
        decoration: BoxDecoration(
          border: Border(bottom: BorderSide(color: kBorder.withOpacity(0.4))),
        ),
      ),
      title: Row(
        children: [
          const SizedBox(width: 8),
          Container(
            width: 36, height: 36,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: kBlue.withOpacity(0.4)),
              color: kBlue.withOpacity(0.1),
            ),
            child: ClipOval(
              child: _profileImage != null
                  ? Image.file(_profileImage!, width: 36, height: 36, fit: BoxFit.cover)
                  : Image.asset('assets/images/logo.png', width: 36, height: 36, fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => const Icon(Icons.person_rounded, color: kBlue, size: 20)),
            ),
          ),
        ],
      ),
      actions: [
        GestureDetector(
          onTap: () => Navigator.push(
            context,
            _slideRoute(ProfilePage(
              username: username, password: password,
              role: role, expiredDate: expiredDate, sessionKey: sessionKey, uid: uid,
            )),
          ).then((_) {
            _loadProfileImage();
            if (mounted && _newsPageCtrl.hasClients) {
              setState(() { _currentNewsPage = 0.0; _newsPageViewKey++; });
              _newsPageCtrl.jumpToPage(0);
            }
          }),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(username,
                  style: const TextStyle(
                      color: kWhite, fontSize: 13, fontWeight: FontWeight.bold)),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(role.toUpperCase(),
                      style: const TextStyle(
                          color: kWhite54, fontSize: 10, fontFamily: 'Orbitron')),
                  const SizedBox(width: 4),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(6),
                        color: Colors.red.withOpacity(0.2),
                        border: Border.all(color: Colors.red.withOpacity(0.4))),
                    child: Text('Exp: $expiredDate',
                        style: const TextStyle(
                            color: Colors.red, fontSize: 9, fontWeight: FontWeight.bold)),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(width: 10),
        GestureDetector(
          onTap: () => Navigator.push(
            context,
            _slideRoute(ProfilePage(
              username: username, password: password,
              role: role, expiredDate: expiredDate, sessionKey: sessionKey, uid: uid,
            )),
          ),
          child: Container(
            width: 38, height: 38,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: Colors.red.withOpacity(0.5), width: 2),
              color: Colors.red.withOpacity(0.2),
            ),
            child: ClipOval(
              child: _profileImage != null
                  ? Image.file(_profileImage!, fit: BoxFit.cover)
                  : const Icon(FontAwesomeIcons.userAstronaut, color: Colors.redAccent, size: 20),
            ),
          ),
        ),
        const SizedBox(width: 4),
        GestureDetector(
          onTap: () => Navigator.push(context, _slideRoute(const ContactPage())),
          child: const Padding(
            padding: EdgeInsets.symmetric(horizontal: 8),
            child: Icon(Icons.headset_mic_outlined, color: kWhite, size: 24),
          ),
        ),
        const SizedBox(width: 4),
      ],
    );
  }

  Widget _buildBottomNav() {
    // Bottom navigation only: existing page routing/indexes are intentionally
    // unchanged.  The fourth item still opens ChatRoomPage (see _buildCurrentPage).
    final icons = const [
      Icons.home_rounded,
      Icons.bug_report_rounded,
      Icons.build_rounded,
      Icons.chat_bubble_rounded,
    ];
    final labels = const ['Home', 'Bug', 'Tools', 'Chat'];
    final accent = const [
      Color(0xFF00E5FF),
      Color(0xFFFF2D8D),
      Color(0xFFFFB300),
      Color(0xFF00E676),
    ];

    return SafeArea(
      top: false,
      child: Container(
        height: 82,
        margin: const EdgeInsets.fromLTRB(12, 0, 12, 10),
        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 7),
        decoration: BoxDecoration(
          // Transparent/glass-like: keep the dashboard/background visible.
          color: const Color(0x55121720),
          borderRadius: BorderRadius.circular(30),
          border: Border.all(color: Colors.white.withOpacity(0.14), width: 1),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.30),
              blurRadius: 18,
              offset: const Offset(0, 7),
            ),
          ],
        ),
        child: Row(
          children: List.generate(4, (index) {
            final selected = _navIndex == index;
            final color = accent[index];
            return Expanded(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => _onNavTap(index),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 260),
                  curve: Curves.easeOutCubic,
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(25),
                    color: selected
                        ? color.withOpacity(0.18)
                        : Colors.white.withOpacity(0.025),
                    border: Border.all(
                      color: selected
                          ? color.withOpacity(0.90)
                          : Colors.white.withOpacity(0.045),
                      width: selected ? 1.2 : 0.7,
                    ),
                    boxShadow: selected
                        ? [
                            BoxShadow(
                              color: color.withOpacity(0.28),
                              blurRadius: 14,
                              spreadRadius: 0,
                            ),
                          ]
                        : const [],
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 260),
                        width: selected ? 38 : 32,
                        height: selected ? 38 : 32,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: selected
                              ? color.withOpacity(0.20)
                              : Colors.transparent,
                          border: Border.all(
                            color: selected
                                ? color.withOpacity(0.72)
                                : Colors.white.withOpacity(0.08),
                            width: 1,
                          ),
                        ),
                        child: Icon(
                          icons[index],
                          color: selected ? color : Colors.white.withOpacity(0.58),
                          size: selected ? 22 : 20,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        labels[index],
                        style: TextStyle(
                          color: selected ? Colors.white : Colors.white.withOpacity(0.55),
                          fontSize: 8.5,
                          fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                          letterSpacing: 0.2,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          }),
        ),
      ),
    );
  }

  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: kBg,
      width: MediaQuery.of(context).size.width * 0.8,
      child: Column(
        children: [
          Container(
            height: 240,
            color: Colors.black,
            child: Stack(
              children: [
                Positioned.fill(
                  child: Image.asset('assets/images/ornes_1.png', fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(color: Colors.black)),
                ),
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter, end: Alignment.bottomCenter,
                      colors: [Colors.black.withOpacity(0.3), Colors.black.withOpacity(0.85)],
                    ),
                  ),
                ),
                SafeArea(
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 80, height: 80,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: kBlue.withOpacity(0.6), width: 2.5),
                            boxShadow: [BoxShadow(color: kBlue.withOpacity(0.3), blurRadius: 14, spreadRadius: 2)],
                          ),
                          child: ClipOval(
                            child: _profileImage != null
                                ? Image.file(_profileImage!, fit: BoxFit.cover)
                                : const Icon(FontAwesomeIcons.userAstronaut, size: 38, color: kWhite),
                          ),
                        ),
                        const SizedBox(height: 12),
                        Text(username,
                            style: const TextStyle(
                                color: kWhite, fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
                        Text(role.toUpperCase(),
                            style: const TextStyle(color: kBlue, fontSize: 12, letterSpacing: 2)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Container(
              color: kBg,
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 16),
                children: [
                  _buildDrawerItem(
                    icon: Icons.notifications_rounded,
                    label: 'Notifikasi',
                    badge: _hasNewNotif,
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(context, _slideRoute(NotificationPage(
                        notifications: _notifications,
                        role: role,
                        onClear: () => setState(() {
                          _notifications.clear();
                          _hasNewNotif = false;
                        }),
                      ))).then((_) => setState(() => _hasNewNotif = false));
                    },
                  ),
                  _buildDrawerItem(
                    icon: Icons.info_outline_rounded,
                    label: 'Informasi App',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(context, _slideRoute(InfoPage(sessionKey: sessionKey)));
                    },
                  ),
                  const Divider(color: Color(0xFF27272A), indent: 16, endIndent: 16),
                  if (['reseller', 'partner', 'tk', 'moderator'].contains(role.toLowerCase()))
                    _buildDrawerItem(
                        icon: Icons.storefront_rounded,
                        label: 'Buat Akun / Seller Page',
                        onTap: () => _onDrawerNav(1)),
                  if (role.toLowerCase() == 'admin')
                    _buildDrawerItem(
                        icon: Icons.admin_panel_settings_rounded,
                        label: 'Admin Page',
                        onTap: () => _onDrawerNav(2)),
                  if (role.toLowerCase() == 'owner')
                    _buildDrawerItem(
                        icon: Icons.workspace_premium_rounded,
                        label: 'Owner Page',
                        onTap: () => _onDrawerNav(3)),
                  if (role.toLowerCase() == 'developer')
                    _buildDrawerItem(
                        icon: Icons.developer_mode_rounded,
                        label: 'Developer Panel',
                        color: const Color(0xFFEC4899),
                        onTap: () => _onDrawerNav(3)),
                  _buildDrawerItem(
                    icon: Icons.savings_rounded,
                    label: 'Tabungan',
                    color: kNeonGreen,
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        _slideRoute(SavingsPage(
                          sessionKey: sessionKey,
                          username: username,
                          role: role,
                        )),
                      );
                    },
                  ),
                  _buildDrawerItem(
                    icon: Icons.history_rounded,
                    label: 'Riwayat Aktivitas',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                          context,
                          _slideRoute(RiwayatPage(sessionKey: sessionKey, role: role))).then((_) {
                        if (mounted && _newsPageCtrl.hasClients) {
                          setState(() { _currentNewsPage = 0.0; _newsPageViewKey++; });
                          _newsPageCtrl.jumpToPage(0);
                        }
                      });
                    },
                  ),
                  _buildDrawerItem(
                    icon: Icons.lock_outline_rounded,
                    label: 'Ganti Password',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        _slideRoute(ChangePasswordPage(username: username, sessionKey: sessionKey)),
                      );
                    },
                  ),
                  const SizedBox(height: 16),
                  _buildDrawerItem(
                    icon: Icons.logout_rounded,
                    label: 'Keluar',
                    isLogout: true,
                    onTap: () async {
                      Navigator.pop(context);
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.clear();
                      if (!mounted) return;
                      Navigator.of(context).pushAndRemoveUntil(
                          MaterialPageRoute(builder: (_) => const LoginPage()), (_) => false);
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool isLogout = false,
    bool badge = false,
    Color? color,
  }) {
    final iconColor = isLogout ? Colors.redAccent : (color ?? kBlue);
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
      decoration: BoxDecoration(
        color: isLogout ? Colors.red.withOpacity(0.08) : kCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
            color: isLogout ? Colors.red.withOpacity(0.3) : kBorder.withOpacity(0.4)),
      ),
      child: ListTile(
        leading: Stack(
          clipBehavior: Clip.none,
          children: [
            Icon(icon, color: iconColor, size: 20),
            if (badge)
              Positioned(top: -4, right: -4,
                child: Container(
                  width: 8, height: 8,
                  decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
                ),
              ),
          ],
        ),
        title: Text(label,
            style: TextStyle(
                color: isLogout ? Colors.redAccent : kWhite,
                fontWeight: FontWeight.w600, fontSize: 14)),
        trailing: const Icon(Icons.arrow_forward_ios_rounded, color: kWhite24, size: 13),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        onTap: onTap,
      ),
    );
  }
}

class _QuickActionData {
  final IconData icon;
  final IconData bgIcon;
  final String title;
  final String subtitle;
  final List<Color> gradient;
  final VoidCallback onTap;
  const _QuickActionData({
    required this.icon,
    required this.bgIcon,
    required this.title,
    required this.subtitle,
    required this.gradient,
    required this.onTap,
  });
}

PageRoute _slideRoute(Widget page) => PageRouteBuilder(
  pageBuilder: (_, __, ___) => page,
  transitionDuration: const Duration(milliseconds: 350),
  transitionsBuilder: (_, anim, __, child) => SlideTransition(
    position: Tween<Offset>(begin: const Offset(1, 0), end: Offset.zero)
        .animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
    child: FadeTransition(opacity: anim, child: child),
  ),
);

class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});
  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _ctrl;
  bool _isVideo(String url) =>
      url.endsWith('.mp4') || url.endsWith('.webm') ||
      url.endsWith('.mov') || url.endsWith('.mkv');
  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _ctrl = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          if (mounted) setState(() {});
          _ctrl?.setLooping(true);
          _ctrl?.setVolume(0.0);
          _ctrl?.play();
        });
    }
  }
  @override
  void dispose() { _ctrl?.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_ctrl != null && _ctrl!.value.isInitialized) {
        return AspectRatio(aspectRatio: _ctrl!.value.aspectRatio, child: VideoPlayer(_ctrl!));
      }
      return const Center(child: CircularProgressIndicator(color: kBlue, strokeWidth: 2));
    }
    return Image.network(
      widget.url, fit: BoxFit.cover,
      errorBuilder: (_, __, ___) =>
          Container(color: kCard, child: const Icon(Icons.error_rounded, color: kWhite24)),
    );
  }
}