import 'package:flutter/material.dart';

/// Lightweight theme state used by the controller/admin UI.
/// Kept independent from MaterialApp so existing screens can subscribe safely.
class ThemeProvider extends ChangeNotifier {
  Color _dxPrimary = const Color(0xFF00E5FF);
  Color _dxSecondary = const Color(0xFF1565C0);

  Color get dxPrimary => _dxPrimary;
  Color get dxSecondary => _dxSecondary;

  void setColors({required Color primary, required Color secondary}) {
    _dxPrimary = primary;
    _dxSecondary = secondary;
    notifyListeners();
  }

  void cycle() {
    if (_dxPrimary == const Color(0xFF00E5FF)) {
      setColors(
        primary: const Color(0xFFFFD600),
        secondary: const Color(0xFFFF8F00),
      );
    } else if (_dxPrimary == const Color(0xFFFFD600)) {
      setColors(
        primary: const Color(0xFFB388FF),
        secondary: const Color(0xFF7C4DFF),
      );
    } else {
      setColors(
        primary: const Color(0xFF00E5FF),
        secondary: const Color(0xFF1565C0),
      );
    }
  }
}
