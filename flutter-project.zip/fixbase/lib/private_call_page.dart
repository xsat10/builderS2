import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'api_config.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:socket_io_client/socket_io_client.dart' as io;

class PrivateCallPage extends StatefulWidget {
  final String me, peer, callId, sessionKey;
  final io.Socket socket;
  final bool video, caller;
  final Map<String,dynamic>? offer;
  const PrivateCallPage({super.key,required this.me,required this.peer,required this.sessionKey,required this.socket,required this.callId,required this.video,required this.caller,this.offer});
  @override State<PrivateCallPage> createState()=>_PrivateCallPageState();
}

class _PrivateCallPageState extends State<PrivateCallPage>{
  final local=RTCVideoRenderer(), remote=RTCVideoRenderer();
  RTCPeerConnection? pc;
  MediaStream? stream;
  Timer? timer, audioRouteTimer;
  int seconds=0;
  bool connected=false, muted=false, cameraOff=false, _ended=false;
  bool _remoteDescriptionSet=false;
  bool _remoteAudioReceived=false;
  final List<RTCIceCandidate> _pendingIce=[];
  List<Map<String,dynamic>> _iceServers=[];

  @override void initState(){
    super.initState();
    _start();
    timer=Timer.periodic(const Duration(seconds:1),(_){if(mounted)setState(()=>seconds++);});
  }

  Future<void> _configureAudio() async {
    try {
      await Helper.setAndroidAudioConfiguration(AndroidAudioConfiguration(
        androidAudioMode: AndroidAudioMode.inCommunication,
        androidAudioFocusMode: AndroidAudioFocusMode.gain,
        forceHandleAudioRouting: true,
      ));
    } catch (_) {}
    try { await Helper.setSpeakerphoneOn(true); } catch (_) {}
  }

  Future<void> _start() async {
    try {
      await local.initialize();
      await remote.initialize();
      await _configureAudio();

      // Xirsys TURN credentials are returned by the API. relay-only is deliberate:
      // it verifies that media can actually traverse TURN instead of only showing
      // a connected signaling screen. This is more reliable across mobile NATs.
      try {
        final r=await http.get(Uri.parse('$baseUrl/api/chat/private/ice').replace(queryParameters:{
          'session_key':widget.sessionKey,
          'relay_only':'1',
        })).timeout(const Duration(seconds:10));
        if(r.statusCode==200){
          final b=jsonDecode(r.body);
          if(b is Map && b['iceServers'] is List){
            _iceServers=List<Map<String,dynamic>>.from((b['iceServers'] as List).map((e)=>Map<String,dynamic>.from(e as Map)));
          } else {
            throw Exception((b is Map ? b['message'] : null)?.toString() ?? 'Format ICE API tidak valid');
          }
        } else {
          try {
            final b=jsonDecode(r.body);
            throw Exception((b is Map ? b['message'] : null)?.toString() ?? 'ICE API HTTP ${r.statusCode}');
          } catch (_) {
            throw Exception('ICE API HTTP ${r.statusCode}');
          }
        }
      } catch (e) {
        throw Exception('ICE API gagal: $e');
      }

      if(_iceServers.isEmpty){
        throw Exception('TURN Xirsys belum tersedia. Cek credential/channel API.');
      }

      final config=<String,dynamic>{
        'iceServers':_iceServers,
        'sdpSemantics':'unified-plan',
        'bundlePolicy':'max-bundle',
        'rtcpMuxPolicy':'require',
        'iceCandidatePoolSize':10,
      };
      // Ask the API to force TURN for the call when it has returned TURN servers.
      if(_iceServers.any((s)=>'${s['urls']}'.toLowerCase().startsWith('turn'))) {
        config['iceTransportPolicy']='relay';
      }

      pc=await createPeerConnection(config);

      pc!.onIceCandidate=(c){
        final cand=c.candidate;
        if(cand==null||cand.isEmpty)return;
        widget.socket.emit('private:call:ice',{
          'to':widget.peer,'callId':widget.callId,
          'candidate':cand,'sdpMid':c.sdpMid,'sdpMLineIndex':c.sdpMLineIndex,
        });
      };

      pc!.onConnectionState=(state){
        final ok=state==RTCPeerConnectionState.RTCPeerConnectionStateConnected;
        if(mounted)setState(()=>connected=ok);
        if(state==RTCPeerConnectionState.RTCPeerConnectionStateFailed){
          _safeEnd();
        }
      };

      pc!.onIceConnectionState=(state) async {
        if(state==RTCIceConnectionState.RTCIceConnectionStateConnected||state==RTCIceConnectionState.RTCIceConnectionStateCompleted){
          await _configureAudio();
          if(mounted)setState(()=>connected=true);
        } else if(state==RTCIceConnectionState.RTCIceConnectionStateDisconnected){
          if(mounted)setState(()=>connected=false);
        } else if(state==RTCIceConnectionState.RTCIceConnectionStateFailed){
          try{await pc?.restartIce();}catch(_){ }
        }
      };

      pc!.onTrack=(e) async {
        if(e.track.kind=='audio'){
          try{e.track.enabled=true;}catch(_){ }
          try{await Helper.setVolume(1.0,e.track);}catch(_){ }
          try{await Helper.setSpeakerphoneOn(true);}catch(_){ }
          _remoteAudioReceived=true;
          if(e.streams.isNotEmpty){
            remote.srcObject=e.streams.first;
            try{remote.muted=false;}catch(_){ }
          }
          if(mounted)setState(()=>connected=true);
        } else if(e.track.kind=='video' && e.streams.isNotEmpty){
          remote.srcObject=e.streams.first;
          if(mounted)setState(()=>connected=true);
        }
      };

      pc!.onAddStream=(s) async {
        remote.srcObject=s;
        for(final t in s.getAudioTracks()){
          try{t.enabled=true;}catch(_){ }
          try{await Helper.setVolume(1.0,t);}catch(_){ }
        }
        await _configureAudio();
        if(mounted)setState(()=>connected=true);
      };

      final audioConstraints=<String,dynamic>{
        'echoCancellation':true,
        'noiseSuppression':true,
        'autoGainControl':true,
        'channelCount':1,
      };
      stream=await navigator.mediaDevices.getUserMedia({
        'audio':audioConstraints,
        'video':widget.video?{
          'facingMode':'user','width':{'ideal':640},'height':{'ideal':480},'frameRate':{'ideal':24}
        }:false,
      });

      for(final t in stream!.getAudioTracks()){
        t.enabled=true;
        try{await Helper.setMicrophoneMute(false,t);}catch(_){ }
      }
      local.srcObject=stream;
      for(final t in stream!.getTracks()) await pc!.addTrack(t,stream!);

      widget.socket.on('private:call:answer',_answer);
      widget.socket.on('private:call:ice',_ice);
      widget.socket.on('private:call:end',_remoteEnd);
      widget.socket.on('private:call:unavailable',_unavailable);
      widget.socket.on('private:call:timeout',_timeout);

      // Keep Android audio focus/output stable. Some Android devices can reroute
      // WebRTC audio a few seconds after a call starts.
      audioRouteTimer=Timer.periodic(const Duration(seconds:2),(_){
        if(!_ended){_configureAudio();}
      });

      if(widget.caller){
        final offer=await pc!.createOffer({'offerToReceiveAudio':true,'offerToReceiveVideo':widget.video});
        await pc!.setLocalDescription(offer);
        widget.socket.emit('private:call',{
          'to':widget.peer,'callId':widget.callId,'video':widget.video,
          'offer':{'sdp':offer.sdp,'type':offer.type}
        });
      }else if(widget.offer!=null){
        final o=widget.offer!;
        await pc!.setRemoteDescription(RTCSessionDescription(o['sdp']?.toString(),o['type']?.toString()));
        _remoteDescriptionSet=true;
        await _flushIce();
        final answer=await pc!.createAnswer({'offerToReceiveAudio':true,'offerToReceiveVideo':widget.video});
        await pc!.setLocalDescription(answer);
        widget.socket.emit('private:call:answer',{
          'to':widget.peer,'callId':widget.callId,
          'answer':{'sdp':answer.sdp,'type':answer.type}
        });
      }
    } catch(e){
      if(mounted){
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Call gagal dimulai: $e')));
        _safeEnd();
      }
    }
  }

  Future<void> _answer(dynamic data)async{
    if(data is! Map||data['callId']!=widget.callId)return;
    final a=Map<String,dynamic>.from(data['answer']??{});
    if(a['sdp']==null)return;
    try{
      await pc?.setRemoteDescription(RTCSessionDescription(a['sdp'].toString(),a['type']?.toString()));
      _remoteDescriptionSet=true;
      await _flushIce();
      await _configureAudio();
    }catch(_){ }
  }

  Future<void> _ice(dynamic data)async{
    if(data is! Map||data['callId']!=widget.callId)return;
    final raw=data['candidate'];
    if(raw==null)return;
    String? cand;
    String? mid;
    int? mline;
    if(raw is Map){
      final c=Map<String,dynamic>.from(raw);
      cand=c['candidate']?.toString();
      mid=(c['sdpMid']??data['sdpMid'])?.toString();
      final v=c['sdpMLineIndex']??data['sdpMLineIndex'];
      mline=v is int?v:int.tryParse('$v');
    }else{
      cand=raw.toString();
      mid=data['sdpMid']?.toString();
      final v=data['sdpMLineIndex'];
      mline=v is int?v:int.tryParse('$v');
    }
    if(cand==null||cand!.isEmpty)return;
    final candidate=RTCIceCandidate(cand,mid,mline);
    if(!_remoteDescriptionSet){_pendingIce.add(candidate);return;}
    try{await pc?.addCandidate(candidate);}catch(_){ }
  }

  Future<void> _flushIce()async{
    final p=pc;if(p==null)return;
    for(final c in List<RTCIceCandidate>.from(_pendingIce)){
      try{await p.addCandidate(c);}catch(_){ }
    }
    _pendingIce.clear();
  }

  void _remoteEnd(dynamic data){if(data is Map&&data['callId']==widget.callId&&mounted)_safeEnd(localOnly:true);}
  void _unavailable(dynamic data){if(data is Map&&data['callId']==widget.callId&&mounted){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('User sedang offline')));_safeEnd(localOnly:true);}}
  void _timeout(dynamic data){if(data is Map&&data['callId']==widget.callId&&mounted){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Panggilan tidak dijawab')));_safeEnd(localOnly:true);}}

  void _safeEnd({bool localOnly=false}){
    if(_ended)return;
    _ended=true;
    if(!localOnly){try{widget.socket.emit('private:call:end',{'to':widget.peer,'callId':widget.callId});}catch(_){ }}
    if(mounted)Navigator.of(context).pop();
  }

  Future<void> _mute() async{
    final next=!muted;
    for(final t in stream?.getAudioTracks()??[]){
      try{await Helper.setMicrophoneMute(next,t);}catch(_){ }
      t.enabled=!next;
    }
    if(mounted)setState(()=>muted=next);
  }

  void _camera(){
    for(final t in stream?.getVideoTracks()??[]){t.enabled=!t.enabled;}
    if(mounted)setState(()=>cameraOff=!cameraOff);
  }

  @override void dispose(){
    _ended=true;
    timer?.cancel();audioRouteTimer?.cancel();
    widget.socket.off('private:call:answer',_answer);
    widget.socket.off('private:call:ice',_ice);
    widget.socket.off('private:call:end',_remoteEnd);
    widget.socket.off('private:call:unavailable',_unavailable);
    widget.socket.off('private:call:timeout',_timeout);
    for(final t in stream?.getTracks()??[]){try{t.stop();}catch(_){ }}
    stream?.dispose();pc?.close();
    try{Helper.setSpeakerphoneOn(false);}catch(_){ }
    local.dispose();remote.dispose();
    super.dispose();
  }

  String _time(){final m=(seconds~/60).toString().padLeft(2,'0'),s=(seconds%60).toString().padLeft(2,'0');return '$m:$s';}

  @override Widget build(BuildContext context){
    final children=<Widget>[];
    if(widget.video&&remote.srcObject!=null){
      children.add(Positioned.fill(child:RTCVideoView(remote,objectFit:RTCVideoViewObjectFit.RTCVideoViewObjectFitCover)));
    }else{
      children.add(Positioned.fill(child:Center(child:Column(mainAxisSize:MainAxisSize.min,children:[
        CircleAvatar(radius:48,child:Text(widget.peer.isNotEmpty?widget.peer[0].toUpperCase():'?',style:const TextStyle(fontSize:40))),
        const SizedBox(height:16),Text(widget.peer,style:const TextStyle(color:Colors.white,fontSize:22,fontWeight:FontWeight.bold)),
        const SizedBox(height:6),Text(connected?_time():'Menghubungkan…',style:const TextStyle(color:Colors.white70)),
        const SizedBox(height:6),Text(_remoteAudioReceived?'Audio tersambung':'Menunggu audio…',style:const TextStyle(color:Colors.white38,fontSize:12)),
      ]))));
    }
    if(widget.video){children.add(Positioned(right:16,top:16,width:110,height:150,child:ClipRRect(borderRadius:BorderRadius.circular(14),child:RTCVideoView(local,mirror:true))));}
    children.add(Positioned(left:0,right:0,bottom:25,child:Row(mainAxisAlignment:MainAxisAlignment.center,children:[
      _btn(muted?Icons.mic_off:Icons.mic,_mute),
      if(widget.video)_btn(cameraOff?Icons.videocam_off:Icons.videocam,_camera),
      _btn(Icons.call_end,()=>_safeEnd(),red:true),
    ])));
    return Scaffold(backgroundColor:Colors.black,body:SafeArea(child:Stack(children:children)));
  }
  Widget _btn(IconData i,VoidCallback f,{bool red=false})=>Padding(padding:const EdgeInsets.all(7),child:FloatingActionButton(backgroundColor:red?Colors.red:Colors.white24,onPressed:f,child:Icon(i,color:Colors.white)));
}
