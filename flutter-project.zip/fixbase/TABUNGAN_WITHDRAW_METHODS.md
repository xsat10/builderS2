# DEY Tabungan - Penarikan

Penarikan tabungan hanya menyediakan dua tujuan:
- DANA
- GoPay

User wajib memilih salah satu metode dan memasukkan nomor tujuan. Backend juga memvalidasi metode agar nilai lain tidak dapat dikirim lewat API.

Penarikan tetap masuk status Pending dan diproses oleh admin/owner. Modul ini tidak mengklaim adanya payout otomatis OpiPay.
