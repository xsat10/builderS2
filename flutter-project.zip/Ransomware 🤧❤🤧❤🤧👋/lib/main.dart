import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:flutter/services.dart';
import 'package:flutter_windowmanager/flutter_windowmanager.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // 1. FULLSCREEN + ANTI SS
  await FlutterWindowManager.addFlags(FlutterWindowManager.FLAG_SECURE);
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CYPHXSEC',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),
      home: LockScreen(),
    );
  }
}

class LockScreen extends StatefulWidget {
  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  late final WebViewController _controller;
  bool _unlocked = false;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.black)
      ..addJavaScriptChannel('UnlockChannel', onMessageReceived: (msg) {
          if(msg.message == "1337") { // PIN DARI HTML
            setState(() { _unlocked = true; });
          }
        })
      ..loadFlutterAsset('assets/index.html');
  }

  Future<bool> _onWillPop() async {
    return _unlocked; // KALO BELUM UNLOCK GABISA BACK
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: _unlocked,
      child: Scaffold(
        backgroundColor: Colors.black,
        body: WebViewWidget(controller: _controller),
      ),
    );
  }
}