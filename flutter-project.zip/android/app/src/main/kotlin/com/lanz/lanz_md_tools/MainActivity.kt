package com.lanz.lanz_md_tools

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
