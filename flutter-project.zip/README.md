# Xyzora Chat — Flutter Client (Android & iOS)

Client Flutter cross-platform untuk backend **Xyzora Chat** (Node.js + Socket.IO + E2EE).

## Fitur yang sudah di-port

| Fitur | Status | Catatan |
|-------|--------|---------|
| Login / Register (REST) | ✅ | Challenge token, validasi usia, guardian |
| Secure session (JWT) | ✅ | `flutter_secure_storage` |
| Theme engine (7 tema) | ✅ | neo, dark, ocean, sakura, mint, minimal, glass |
| Theme switcher di Settings | ✅ | Tersimpan lokal |
| WebSocket / Socket.IO | ✅ | Auto-reconnect, auth JWT |
| Typing indicator | ✅ | Event `typing` |
| Online / Offline presence | ✅ | Event `presence` |
| Read receipt | ✅ | Event `read` |
| Chat bubble + reply | ✅ | UI sesuai tema |
| E2EE (ECDH P-256 + AES-GCM) | ✅ | PointyCastle — setara `e2ee.js` |
| Voice / Video call (WebRTC) | 🔲 | Stub — gunakan `flutter_webrtc` + logika `live.js` |
| Music player sharing | 🔲 | Stub — gunakan `just_audio` + logika `music.js` |
| Upload media | 🔲 | Siap dengan `image_picker` / `file_picker` |

## Struktur

```
lib/
├── core/
│   ├── constants/     # api_endpoints, themes_data
│   ├── network/       # api_service, websocket_client
│   ├── security/      # e2ee_helper, storage_helper
│   └── theme/         # theme_provider
├── features/
│   ├── auth/          # login, register, auth_provider
│   ├── chat/          # chat list, chat room, bubble
│   ├── live_webrtc/   # (siap diisi call page)
│   ├── music_player/  # (siap diisi music bar)
│   └── settings/      # settings + theme picker
└── main.dart
```

## Cara menjalankan

1. **Set backend URL** di `lib/core/constants/api_endpoints.dart`:
   ```dart
   static const String baseUrl = 'https://xyzorachat.exyzogamepoint.xyz';
   ```

2. Install dependencies:
   ```bash
   flutter pub get
   ```

3. Jalankan:
   ```bash
   flutter run          # device / emulator
   flutter build apk    # Android APK
   flutter build ios    # iOS (butuh Mac + Xcode)
   ```

## Dependensi utama

- `provider` — state management
- `http` + `socket_io_client` — REST & realtime
- `flutter_secure_storage` — JWT & E2EE keys
- `pointycastle` + `crypto` — E2EE
- `flutter_webrtc` — voice/video call (siap diintegrasikan)
- `just_audio` — music sharing (siap diintegrasikan)

## E2EE

Implementasi mengikuti skema `public/js/e2ee.js`:

- Key pair **ECDH P-256** per user
- Private key disimpan di secure storage perangkat
- DM: shared secret via ECDH → HKDF → AES-256-GCM
- Group: versioned group key (AES-256-GCM)
- Server **tidak pernah** melihat plaintext

## Catatan keamanan (dari SECURITY-NOTES.md)

- Token halaman (`/api/challenge`) wajib sebelum login/register
- Rate limit & anti brute-force di backend
- Origin check — set `ALLOWED_ORIGINS` di server jika APK pakai domain berbeda
- Gunakan HTTPS di production

## Langkah berikutnya (opsional)

1. Isi `live_webrtc/presentation/pages/call_page.dart` dengan signaling dari `live.js`
2. Isi `music_player/widgets/music_bar.dart` dengan sinkronisasi dari `music.js`
3. Hubungkan daftar chat nyata dari event Socket.IO `chats` / REST `/api/chats`
4. Implementasi upload file ke `/api/upload` + encrypt media

---

Dibuat sebagai client Flutter dari sumber Node.js **Xyzora Chat E2EE v60**.
