# Lanz MD Tools (Flutter)

Aplikasi Android untuk gateway WhatsApp multi-sesi.

## Yang tidak bisa di-generate lewat chat

File biner (`gradle-wrapper.jar`, mipmap PNG, font TTF) tidak ikut di zip source murni. Zip distribusi sudah menyertakan branding hi-res. `gradle-wrapper.jar` perlu dari Flutter SDK.

## Build APK

Prasyarat: Flutter SDK, JDK 17, Android SDK 34.

```bash
flutter create --org com.lanz --project-name lanz_md_tools --platforms android .
flutter pub get
flutter build apk --release
```

APK: `build/app/outputs/flutter-apk/app-release.apk`

Jika folder ini sudah lengkap (setelah `flutter create` menambal wrapper + mipmap), cukup:

```bash
flutter pub get
flutter build apk --release
```

## Konfigurasi

BASE URL ada di `lib/config/api_config.dart`:

```
http://private-one.jhonaleystore.id:2758
```

Login default server: `admin` / `admin123`

Cleartext HTTP sudah diizinkan di `AndroidManifest.xml` + `network_security_config.xml`.

## Layar

- Login — POST `/login`
- Dashboard — GET `/sessions`, DELETE `/session/:id`
- Tambah sesi — POST `/add-session` + pairing code
- Kirim pesan — POST `/send-message`
