Drop your logo here. logo.png is a generated placeholder.
